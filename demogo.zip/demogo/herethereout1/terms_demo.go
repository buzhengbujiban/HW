package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"sort"

)

type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book

	// 成交滑窗数据
	prices     []float64
	vols       []float64
	directions []int8
	askShares []float64
	bidShares []float64
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:  base.New(cfg, sid),
		names: []string{
			"CalmQBot30_S_Qty", "CalmQBot30_S_Amt", "CalmQBot30_S_Prc",
			"CalmQBot30_B_Qty", "CalmQBot30_B_Amt", "CalmQBot30_B_Prc",
			"CalmQBot30_S_orderQty", "CalmQBot30_B_orderQty",
			"CrazyQBot30_S_Qty", "CrazyQBot30_S_Amt", "CrazyQBot30_S_Prc",
			"CrazyQBot30_B_Qty", "CrazyQBot30_B_Amt", "CrazyQBot30_B_Prc",
			"CrazyQBot30_S_orderQty", "CrazyQBot30_B_orderQty",
			"Qtytrans_all", "Amttrans_all",
		},
		outs: make([]float64, 18),
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################


func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	// 记录每个msg的成交量，增加到list中
	// 记录每个msg的价格， 增加到list中
	// 记录每个msg的Dir（主动买入还时主动卖出），增加到list中

	x.outs[16] += msg.Qty
	x.outs[17] += msg.Qty * msg.Prc

	x.prices = append(x.prices, msg.Prc)
	x.directions = append(x.directions, int8(msg.Dir))
	x.vols = append(x.vols, msg.Qty)



	askOrder := x.ob.FindOrder(msg.AskOid, bookmsg.SellSide)
	bidOrder := x.ob.FindOrder(msg.BidOid, bookmsg.BuySide)
	askShare := 0.0
	bidShare := 0.0
	if askOrder != nil {
		askShare = askOrder.Shares()
	}
	if bidOrder != nil {
		bidShare = bidOrder.Shares()
	}
	x.askShares = append(x.askShares, askShare)
	x.bidShares = append(x.bidShares, bidShare)
}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}

func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
}

func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	// 任务1：筛选出成交量在整个区间中低于30分位数的样本，统计这些样本的主卖，主买金额， 筛选出成交量在整个区间中高于70分位数的样本，统计这些样本的主卖，主买金额

	n := len(x.vols)
	if n == 0 {
		return
	}
	sortedVols := append([]float64{}, x.vols...)
	sort.Float64s(sortedVols)
	p30vol := sortedVols[n*30/100]
	p70vol := sortedVols[n*70/100]

	var CalmQBot30_S_PrcAmt, CalmQBot30_B_PrcAmt, CrazyQBot30_B_PrcAmt, CrazyQBot30_S_PrcAmt float64
	for i := 0; i < n; i++ {
		// 任务1：成交量分位聚合
		if x.vols[i] <= p30vol {
			if x.directions[i] == -1 {
				x.outs[0] += x.vols[i]                               // CalmQBot30_S_Qty
				x.outs[1] += x.prices[i] * x.vols[i]                 // CalmQBot30_S_Amt
				CalmQBot30_S_PrcAmt += x.vols[i] * x.prices[i]       // CalmQBot30_S_Prc
				x.outs[6] += x.askShares[i]                          // CalmQBot30_S_orderQty
			} else if x.directions[i] == 1 {
				x.outs[3] += x.vols[i]                               // CalmQBot30_B_Qty
				x.outs[4] += x.prices[i] * x.vols[i]                 // CalmQBot30_B_Amt
				CalmQBot30_B_PrcAmt += x.vols[i] * x.prices[i]       // CalmQBot30_B_Prc
				x.outs[7] += x.bidShares[i]                          // CalmQBot30_B_orderQty
			}
		}
		if x.vols[i] >= p70vol {
			if x.directions[i] == -1 {
				x.outs[8] += x.vols[i]                                // CrazyQBot30_S_Qty
				x.outs[9] += x.prices[i] * x.vols[i]                  // CrazyQBot30_S_Amt
				CrazyQBot30_S_PrcAmt += x.vols[i] * x.prices[i]       // CrazyQBot30_S_Prc
				x.outs[14] += x.askShares[i]                          // CrazyQBot30_S_orderQty
			} else if x.directions[i] == 1 {
				x.outs[11] += x.vols[i]                               // CrazyQBot30_B_Qty
				x.outs[12] += x.prices[i] * x.vols[i]                 // CrazyQBot30_B_Amt
				CrazyQBot30_B_PrcAmt += x.vols[i] * x.prices[i]       // CrazyQBot30_B_Prc
				x.outs[15] += x.bidShares[i]                          // CrazyQBot30_B_orderQty
			}
		}
	}

	if x.outs[0]  > 0 {
		x.outs[2] = CalmQBot30_S_PrcAmt / x.outs[0] 
	}
	if x.outs[3]  > 0 {
		x.outs[5] = CalmQBot30_B_PrcAmt / x.outs[3] 
	}
	if x.outs[8]  > 0 {
		x.outs[10] = CrazyQBot30_S_PrcAmt / x.outs[8] 
	}
	if x.outs[11]  > 0 {
		x.outs[13] = CrazyQBot30_B_PrcAmt / x.outs[11] 
	}
	


	copy(out, x.outs)
	// 初始化
	x.outs = make([]float64, 18)
	x.prices = x.prices[:0]
	x.vols = x.vols[:0]
	x.directions = x.directions[:0]
	x.askShares = x.askShares[:0]
	x.bidShares = x.bidShares[:0]

}


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
