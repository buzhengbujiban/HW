package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	_ "fmt"
	"sort"
)

type TermDemo struct {
	*base.Base

	names     []string // names of the fields
	outs      []float64
	MidPrice  []float64
	// ========== 买方挂单相关 ==========
	TimeepochB      []float64 // 每个买单的时间戳
	DeltaTimeepochB []float64 // 相邻买单之间的时间间隔
	QtyB            []float64 // 对应每个买单的数量
	PrcB            []float64 // 对应每个买单的价格

	// ========== 卖方挂单相关 ==========
	TimeepochS      []float64 // 每个卖单的时间戳
	DeltaTimeepochS []float64 // 相邻卖单之间的时间间隔
	QtyS            []float64 // 对应每个卖单的数量
	PrcS            []float64 // 对应每个卖单的价格

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names:            []string{"dense_B_Qty", "dense_B_AvgPrc", "dense_S_Qty", "dense_S_AvgPrc", "All_B_Qty", "All_S_Qty"},
		outs:             make([]float64, 6),

		TimeepochB:      make([]float64, 0, 1000),
		DeltaTimeepochB: make([]float64, 0, 1000),
		QtyB:            make([]float64, 0, 1000),
		PrcB:            make([]float64, 0, 1000),

		TimeepochS:      make([]float64, 0, 1000),
		DeltaTimeepochS: make([]float64, 0, 1000),
		QtyS:            make([]float64, 0, 1000),
		PrcS:            make([]float64, 0, 1000),
		// MidPrice:  []float64{},
		// Timeepoch: []string{},
		// PrcsumS:   []float64{},
		// PrcsumB:   []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################
func Percentile(data []float64, percentile float64) float64 {
	if len(data) == 0 {
		return 0
	}
	sorted := make([]float64, len(data))
	copy(sorted, data)
	sort.Float64s(sorted)

	k := int(float64(len(sorted)-1) * percentile)
	return sorted[k]
}

func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	x.MidPrice  = append(x.MidPrice, msg.GetMidPrice())
}

func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	
	n := len(x.MidPrice)
	if n == 0 {
		return
	}


	if (msg.OrdType != 0) && (msg.Prc <= 0) {
		if msg.Side == 1 {
			msg.Prc = x.MidPrice[n-1] * 1.05
		} else {
			msg.Prc = x.MidPrice[n-1] * 0.95
		}		
	}


	if msg.Side == bookmsg.BuySide {
		x.outs[4] += msg.Qty
		n := len(x.TimeepochB)
		if n >= 1 {
			delta := msg.SrcEpoch - x.TimeepochB[n-1]
			x.DeltaTimeepochB = append(x.DeltaTimeepochB, delta)
			x.QtyB = append(x.QtyB, msg.Qty)
			x.PrcB = append(x.PrcB, msg.Prc)
		}
		x.TimeepochB = append(x.TimeepochB, msg.SrcEpoch)
	}

	if msg.Side == bookmsg.SellSide {
		x.outs[5] += msg.Qty
		n := len(x.TimeepochS)
		if n >= 1 {
			delta := msg.SrcEpoch - x.TimeepochS[n-1]
			x.DeltaTimeepochS = append(x.DeltaTimeepochS, delta)
			x.QtyS = append(x.QtyS, msg.Qty)
			x.PrcS = append(x.PrcS, msg.Prc)
		}
		x.TimeepochS = append(x.TimeepochS, msg.SrcEpoch)
	}
}




// On Snap ###################################################################
func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	// ========== Part: 密集挂单分析 ==========

	// --- 买方 ---
	pr40B := Percentile(x.DeltaTimeepochB, 0.3)
	var sumQtyB, sumPrcB float64
	var countB int
	for i, dt := range x.DeltaTimeepochB {
		if dt < pr40B {
			sumQtyB += x.QtyB[i]
			sumPrcB += x.PrcB[i]
			countB++
		}
	}
	var avgPrcB float64
	if countB > 0 {
		avgPrcB = sumPrcB / float64(countB)
	}
	x.outs[0] = sumQtyB
	x.outs[1] = avgPrcB

	// --- 卖方 ---
	pr40S := Percentile(x.DeltaTimeepochS, 0.3)
	var sumQtyS, sumPrcS float64
	var countS int
	for i, dt := range x.DeltaTimeepochS {
		if dt < pr40S {
			sumQtyS += x.QtyS[i]
			sumPrcS += x.PrcS[i]
			countS++
		}
	}
	var avgPrcS float64
	if countS > 0 {
		avgPrcS = sumPrcS / float64(countS)
	}
	x.outs[2] = sumQtyS
	x.outs[3] = avgPrcS

	// ========== 输出并清空 ==========

	copy(out, x.outs)

	// 清空中间变量
	x.outs = make([]float64, 6)

	x.TimeepochB = x.TimeepochB[:0]
	x.DeltaTimeepochB = x.DeltaTimeepochB[:0]
	x.QtyB = x.QtyB[:0]
	x.PrcB = x.PrcB[:0]

	x.TimeepochS = x.TimeepochS[:0]
	x.DeltaTimeepochS = x.DeltaTimeepochS[:0]
	x.QtyS = x.QtyS[:0]
	x.PrcS = x.PrcS[:0]
}


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
