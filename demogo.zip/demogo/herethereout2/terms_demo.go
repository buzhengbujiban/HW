package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"sort"
)

type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book

	// 成交滑窗数据
	pricesAll []float64
	cumvols   []float64

	ret25DivVol []float64

	periodvol []float64
	vollast   []float64
	volfirst  []float64
	directions []int8
	prices     []float64
	askShares []float64
	bidShares []float64
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:  base.New(cfg, sid),
		names: []string{
			"NoVolLastDown_B_Qty",
			"NoVolFirstDown_B_Qty",
			"NoPeriodvolDown_B_Qty",
			"NoVolDown_B_Amt",
			"NoVolDown_B_orderQty",
			"NoVolLastDown_S_Qty",
			"NoVolFirstDown_S_Qty",
			"NoPeriodvolDown_S_Qty",
			"NoVolDown_S_Amt",
			"NoVolDown_S_orderQty",
			
			"NoVolLastUp_B_Qty",
			"NoVolFirstUp_B_Qty",
			"NoPeriodvolUp_B_Qty",
			"NoVolUp_B_Amt",
			"NoVolUp_B_orderQty",
			"NoVolLastUp_S_Qty",
			"NoVolFirstUp_S_Qty",
			"NoPeriodvolUp_S_Qty",
			"NoVolUp_S_Amt",
			"NoVolUp_S_orderQty",
			"Qtytrans_all", "Amttrans_all",
		},

		outs: make([]float64, 22),
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################


func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {

	// 如果列表长度大于25了，记录 成交价格的ret25, 并记录这25个回看区间成交笔的总成交量，增加ret25/volsum25到list中
	// 记录每个msg的买卖挂单量，可以通过x.ob.FindOrder(msg.AskOid).Shares， x.ob.FindOrder(msg.BidOid).Shares 得到买卖挂单量
	x.outs[20] += msg.Qty
	x.outs[21] += msg.Qty * msg.Prc


	x.pricesAll = append(x.pricesAll, msg.Prc)
	vol := float64(msg.Qty)
	if len(x.cumvols) == 0 {
		x.cumvols = append(x.cumvols, vol)
	} else {
		last := x.cumvols[len(x.cumvols)-1]
		x.cumvols = append(x.cumvols, last+vol)
	}

	n := len(x.pricesAll)
	if n > 25 {
		ret := x.pricesAll[n-1]/x.pricesAll[n-25] - 1.0
		var volsum float64
		volsum = x.cumvols[n-1] - x.cumvols[n-26]
		ratio := 0.0
		if volsum > 0 {
			ratio = ret / volsum
		}
		x.ret25DivVol = append(x.ret25DivVol, ratio)
		x.periodvol   = append(x.periodvol, volsum)
		x.vollast     = append(x.vollast, x.cumvols[n-1] - x.cumvols[n-2])
		x.volfirst    = append(x.volfirst, x.cumvols[n-25] - x.cumvols[n-26])
		x.prices = append(x.prices, msg.Prc)
		x.directions = append(x.directions, int8(msg.Dir))
		
		askOrder := x.ob.FindOrder(msg.AskOid, bookmsg.SellSide)
		bidOrder := x.ob.FindOrder(msg.BidOid, bookmsg.BuySide)
		askShare := 0.0
		bidShare := 0.0
		if askOrder != nil {
			askShare = askOrder.Shares()
		}
		if bidOrder != nil {
			bidShare = bidOrder.Shares()
		}
		x.askShares = append(x.askShares, askShare)
		x.bidShares = append(x.bidShares, bidShare)

	} 
}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}



func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	
}

func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	// 任务2：筛选出ret25/volsum25, 在整个区间中低于30分位数且小于0的样本（记为无量下跌）， 聚合统计无量下跌样本的主买（Dir==1）成交量，主卖(Dir==-1)总成交量，主买平均成交价，主卖平均成交价，主买平均成交金额，主卖平均成交金额
	// 任务3：筛选出ret25/volsum25, 在整个区间中高于70分位数且大于0的样本（记为无量上涨）， 聚合统计无量上涨样本的主卖（Dir==-1）成交量，主买（Dir==1)总成交量，主买平均成交价，主卖平均成交价，主买平均成交金额，主卖平均成交金额
	// 任务4：聚合统计无量下跌样本对应的卖/买方挂单的：总挂单量，平均挂单价和总挂单金额， 聚合统计无量上涨样本对应的买/卖方挂单的：总挂单量，平均挂单价和总挂单金额


	// 任务2
	sortedRatios := append([]float64{}, x.ret25DivVol...)
	sort.Float64s(sortedRatios)
	ratioCount := len(sortedRatios)
	if ratioCount>5 {
		p30ratio := sortedRatios[ratioCount*30/100]
		p70ratio := sortedRatios[ratioCount*70/100]


		
		for i := 0; i < ratioCount; i++ {
	
			// 判断当前是否是无量下跌样本
			isDown := x.ret25DivVol[i] < p30ratio && x.ret25DivVol[i] < 0
			// 判断是否是无量上涨样本
			isUp :=   x.ret25DivVol[i] > p70ratio && x.ret25DivVol[i] > 0
	
			if isDown {
				if x.directions[i] == 1 {
					x.outs[0] += x.vollast[i]                             // NoVollastDown_B_Qty
					x.outs[1] += x.volfirst[i]                            // NoVolfirstDown_B_Qty
					x.outs[2] += x.periodvol[i]                           // NoperiodvolDown_B_Qty
					x.outs[3] += x.prices[i] * x.vollast[i]               // NoVolDown_B_Amt
					x.outs[4] += x.bidShares[i]                           // NoVolDown_B_orderQty
	
				} else if x.directions[i] == -1 {
					x.outs[5] += x.vollast[i]                             // NoVollastDown_S_Qty
					x.outs[6] += x.volfirst[i]                            // NoVolfirstDown_S_Qty
					x.outs[7] += x.periodvol[i]                           // NoperiodvolDown_S_Qty
					x.outs[8] += x.prices[i] * x.vollast[i]               // NoVolDown_S_Amt
					x.outs[9] += x.askShares[i]                           // NoVolDown_S_orderQty
				}  
			}
	
	
	
			if isUp {
				if x.directions[i] == 1 {
					x.outs[10] += x.vollast[i]                             // NoVollastUp_B_Qty
					x.outs[11] += x.volfirst[i]                            // NoVolfirstUp_B_Qty
					x.outs[12] += x.periodvol[i]                           // NoperiodvolUp_B_Qty
					x.outs[13] += x.prices[i] * x.vollast[i]               // NoVolUp_B_Amt
					x.outs[14] += x.bidShares[i]                           // NoVolUp_B_orderQty
	
				} else if x.directions[i] == -1 {
					x.outs[15] += x.vollast[i]                             // NoVollastUp_S_Qty
					x.outs[16] += x.volfirst[i]                            // NoVolfirstUp_S_Qty
					x.outs[17] += x.periodvol[i]                           // NoperiodvolUp_S_Qty
					x.outs[18] += x.prices[i] * x.vollast[i]               // NoVolUp_S_Amt
					x.outs[19] += x.askShares[i]                           // NoVolUp_S_orderQty
				}  
			}
		}
	
		if x.outs[0]  > 0 {
			x.outs[3] = x.outs[3] / x.outs[0] 
		}
		if x.outs[5]  > 0 {
			x.outs[8] = x.outs[8] / x.outs[5] 
		}
		if x.outs[10]  > 0 {
			x.outs[13] = x.outs[13] / x.outs[10] 
		}
		if x.outs[15]  > 0 {
			x.outs[18] = x.outs[18] / x.outs[15] 
		}
		
	
	}




	copy(out, x.outs)
	// 初始化
	x.outs = make([]float64, 22)

	x.directions = x.directions[:0]
	x.askShares = x.askShares[:0]
	x.bidShares = x.bidShares[:0]
	x.periodvol = x.periodvol[:0]
	x.vollast = x.vollast[:0]
	x.volfirst = x.volfirst[:0]
	x.ret25DivVol = x.ret25DivVol[:0]
	x.prices = x.prices[:0]
}


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
