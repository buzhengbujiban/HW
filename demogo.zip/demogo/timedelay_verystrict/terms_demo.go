package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"math"
	"base/orderbook/cneq"
	"sort"
	"time"
	"fmt"
)


type OrderRecord struct {
	Qty      float64
	Epoch    float64
}



type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook

	MidPricelast float64
	addBuyRecords   map[int]OrderRecord
	addSellRecords  map[int]OrderRecord

	passiveSellDelay []float64
	passiveSellRatio []float64

	passiveBuyDelay []float64
	passiveBuyRatio []float64


	activeBuyQtyOid []int
	activeSellQtyOid []int

	activeOidQtymap map[int]float64
	Oidmax int


}
func init() {
	cneq.UNCORSSING_ON_ADD = false // 关闭 orderbook 在 SZ 主动 add 来到时，自动uncross的功能
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:  base.New(cfg, sid),
		names: []string{
			"Sum_filteract_B_delayl_addQ",
			"Sum_filteract_B_Ratiosl_addQ",
			"Sum_filteract_S_delayl_addQ",
			"Sum_filteract_S_Ratiosl_addQ",
			"Std_filteract_B_delayl_addQ",
			"Std_filteract_B_Ratiosl_addQ",
			"Std_filteract_S_delayl_addQ",
			"Std_filteract_S_Ratiosl_addQ",
			"Qtyadd_all","Qtyrealadd_all", "Qtytrd_all",
		},
		outs:           make([]float64, 11),
		addBuyRecords:  make(map[int]OrderRecord),
		addSellRecords: make(map[int]OrderRecord),
		activeOidQtymap: make(map[int]float64),
		
	}

	ret.Oidmax = 0
	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}


// 不同变这两个函数
func (x *TermDemo) DataType() string {
	return "f64"
}
func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################
func FormatUnixTimestampTime(timestamp float64) string {
    sec := int64(timestamp)
    nsec := int64((timestamp - float64(sec)) * 1e9)
    t := time.Unix(sec, nsec).Local()
    return fmt.Sprintf("%02d:%02d:%02d.%06d", t.Hour(), t.Minute(), t.Second(), t.Nanosecond()/1000)
}


func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	// 对每一个成交单，获取成交单的卖单和买单，找到被动单的挂单时间，计算当前时间-挂单时间作为被动单的成交时延，计算挂单时间-当前时间作为主动单的寻找时延，
	// 并记录每一个单的（BS_side）买/卖，主动/被动(Dir_side)， 成交时延/寻找时延， 挂单价格，挂单量
	// 计算每一个单的成交比例，则成交比例=成交量/挂单量
	// 计算每个被成交的单的卖/买单的挂单时间戳，同时计算并记录，当前事件时间戳与20个事件之前的时间戳的差，作为有效时间间隔

	if x.isSH {
		tstring := FormatUnixTimestampTime(msg.SrcEpoch)
		if ((tstring<="14:59:58") && (tstring>="09:30:00")){
			x.outs[9] += msg.Qty
		}
	}
	x.outs[10] += msg.Qty


	var passiveOid int
	var passiveSide bookmsg.BookSide

	if msg.Dir == bookmsg.DirBuy {
		// 买主动，卖被动
		passiveOid = msg.AskOid
		passiveSide = bookmsg.SellSide

	} else if msg.Dir == bookmsg.DirSell {
		passiveOid = msg.BidOid
		passiveSide = bookmsg.BuySide
	} else {
		return
	}

	var record OrderRecord
	var ok bool
	if passiveSide == bookmsg.SellSide {
		record, ok = x.addSellRecords[passiveOid]
	} else {
		record, ok = x.addBuyRecords[passiveOid]
	}
	if !ok {
		return // 找不到原始挂单信息，跳过
	}


	delay := msg.SrcEpoch - record.Epoch
	ratio := msg.Qty / record.Qty


	// 累加聚合
	if passiveSide == bookmsg.SellSide {

		x.passiveSellDelay = append(x.passiveSellDelay, delay)
		x.passiveSellRatio = append(x.passiveSellRatio, ratio)
		

		x.activeBuyQtyOid = append(x.activeBuyQtyOid, msg.BidOid)


		
	} else {
		x.passiveBuyDelay = append(x.passiveBuyDelay, delay)
		x.passiveBuyRatio = append(x.passiveBuyRatio, ratio)


		x.activeSellQtyOid = append(x.activeSellQtyOid, msg.AskOid)


	}
	if x.isSZ {
		if passiveSide == bookmsg.SellSide {
			record, ok = x.addBuyRecords[msg.BidOid]
			if ok{
				x.activeOidQtymap[msg.BidOid] = record.Qty
			}
		} else {
			record, ok = x.addSellRecords[msg.AskOid]
			if ok{
				x.activeOidQtymap[msg.AskOid] = record.Qty
			}
		}
	}

	if x.isSH {
		if passiveSide == bookmsg.SellSide {
			x.activeOidQtymap[msg.BidOid] += msg.Qty
			x.Oidmax = msg.BidOid
		} else {
			x.activeOidQtymap[msg.AskOid] += msg.Qty
			x.Oidmax = msg.AskOid
		}
	}

}


func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}



func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {

}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	
	var Qtyn float64
	if x.isSH && (msg.Oid == x.Oidmax) {
		x.activeOidQtymap[msg.Oid] += msg.Qty
		Qtyn = x.activeOidQtymap[msg.Oid]
	} else  {
		Qtyn = msg.Qty
	}
	



	record := OrderRecord{
		Qty:      Qtyn,
		Epoch:    msg.SrcEpoch,
	}

	if msg.Side == bookmsg.BuySide {
		x.addBuyRecords[msg.Oid] = record
	} else if msg.Side == bookmsg.SellSide {
		x.addSellRecords[msg.Oid] = record
	}

	x.outs[8] += msg.Qty // QtyAdd_all
	x.outs[9] += msg.Qty

}







func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {

	var filteractBuydelayl_addQ, filteractBuyRatiosl_addQ, filteractSelldelayl_addQ, filteractSellRatiosl_addQ []float64


	sortedDelays := append([]float64{}, x.passiveSellDelay...)
	sort.Float64s(sortedDelays)
	sortedRatios := append([]float64{}, x.passiveSellRatio...)
	sort.Float64s(sortedRatios)

	DelayCount := len(sortedDelays)
	if DelayCount>=5 {
		p70delays := sortedDelays[DelayCount*70/100]
		p70Ratios := sortedRatios[DelayCount*60/100]


	for i := 0; i < DelayCount; i++ {
		if x.passiveSellDelay[i] > p70delays{
			filteractBuydelayl_addQ = append(filteractBuydelayl_addQ, x.activeOidQtymap[x.activeBuyQtyOid[i]])
		}


		if x.passiveSellRatio[i] > p70Ratios{
			filteractBuyRatiosl_addQ = append(filteractBuyRatiosl_addQ, x.activeOidQtymap[x.activeBuyQtyOid[i]])
		}

	}
	}


	sortedDelayBuy := append([]float64{}, x.passiveBuyDelay...)
	sort.Float64s(sortedDelayBuy)
	sortedRatioBuy := append([]float64{}, x.passiveBuyRatio...)
	sort.Float64s(sortedRatioBuy)

	DelayCountBuy := len(sortedDelayBuy)
	if DelayCountBuy>=5 {
		p70delays := sortedDelayBuy[DelayCountBuy*70/100]
		p70Ratios := sortedRatioBuy[DelayCountBuy*60/100]
	
	for i := 0; i < DelayCountBuy; i++ {
		if x.passiveBuyDelay[i] > p70delays{
			filteractSelldelayl_addQ = append(filteractSelldelayl_addQ, x.activeOidQtymap[x.activeSellQtyOid[i]])
		}

		if x.passiveBuyRatio[i] > p70Ratios{
			filteractSellRatiosl_addQ = append(filteractSellRatiosl_addQ, x.activeOidQtymap[x.activeSellQtyOid[i]])
		}

	}
	}


	x.outs[0] = Sum(filteractBuydelayl_addQ)
	x.outs[1] = Sum(filteractBuyRatiosl_addQ)

	x.outs[2] = Sum(filteractSelldelayl_addQ)
	x.outs[3] = Sum(filteractSellRatiosl_addQ)
	
	x.outs[4] = Std(filteractBuydelayl_addQ)
	x.outs[5] = Std(filteractBuyRatiosl_addQ)

	x.outs[6] = Std(filteractSelldelayl_addQ)
	x.outs[7] = Std(filteractSellRatiosl_addQ)

	copy(out, x.outs)

	// 清空
	x.outs = make([]float64, 11)
	// x.addBuyRecords = make(map[int]OrderRecord)
	// x.addSellRecords = make(map[int]OrderRecord)
	x.passiveBuyDelay = x.passiveBuyDelay[:0]
	x.passiveSellDelay = x.passiveSellDelay[:0]
	x.passiveBuyRatio = x.passiveBuyRatio[:0]
	x.passiveSellRatio = x.passiveSellRatio[:0]

	x.activeBuyQtyOid = x.activeBuyQtyOid[:0]
	x.activeSellQtyOid = x.activeSellQtyOid[:0]

	x.activeOidQtymap = make(map[int]float64)

}




func Sum(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	for _, v := range arr {
		sum += v
	}
	return sum 
}



func Mean(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	for _, v := range arr {
		sum += v
	}
	return sum / float64(len(arr))
}


func Std(arr []float64) float64 {
	valid := make([]float64, 0, len(arr))
	for _, v := range arr {
		if !math.IsNaN(v) {
			valid = append(valid, v)
		}
	}
	n := len(valid)
	if n < 3 {
		return 0
	}
	mean := Mean(valid)
	var sum float64
	for _, v := range valid {
		sum += (v - mean) * (v - mean)
	}
	return math.Sqrt(sum / float64(n-1)) // 样本标准差
}



// percentile returns the threshold value for the given ratio (e.g. 0.7 means top 30%)


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
