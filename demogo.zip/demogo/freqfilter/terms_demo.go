package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"sort"
)

type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book

	// 中间变量
	Bid2to6Vols []float64
	Ask2to6Vols []float64
	BookEpochs  []float64

	// 每个挂单记录
	MidPrice       []float64
	directions     []int8
	AddQtys        []float64
	AddPrcs        []float64
	AddIsBuy       []bool
	AddBid2to6Vols []float64
	AddAsk2to6Vols []float64
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:  base.New(cfg, sid),
		names: []string{""},  // 在这里取名字
		outs:  make([]float64, 7),
		// MidPrice: []float64[],
		// Bid2to6Vols:     []float64{},
		// Ask2to6Vols:     []float64{},
		// BookEpochs:      []float64{},
		// AddQtys:         []float64{},
		// AddPrcs:         []float64{},
		// AddIsBuy:        []bool{},
		// AddBid2to6Vols:  []float64{},
		// AddAsk2to6Vols:  []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################

// 大幅度压力产生时候的逆势挂单， 顺势挂单 价量
func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	
	// 观察最后一个x.Press0， x.Press0>0 时候发生主动买入是突然买入，发生主动卖出时正常卖出，记录突然买入，正常卖出的成交量，价格
	// 观察最后一个x.Press0， x.Press0<0 时候发生主动买入是正常买入，发生主动卖出时突然卖出，记录突然卖出，正常买入的成交量，价格

}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {
	// 观察最后一个x.Press0， x.Press0>0 撤买单视为正常撤买单，撤卖单视为异常卖撤单，记录异常撤卖单， 正常撤买单的撤单量，单的价格，1/(挂单价格-MidPrice+5) （单子对盘口的影响压力）
	// 观察最后一个x.Press0， x.Press0<0 撤卖单视为正常撤卖单，撤买单视为异常撤买单，记录异常撤买单， 正常撤卖单的撤单量，单的价格，1/(MidPrice-挂单价格+5) （单子对盘口的影响压力）

}



func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	x.Press0   = msg.GetBsize(0) - msg.GetAsize(0)
	x.MidPrice = msg.GetMidPrice()

}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {

	n := len(x.MidPrice)
	if n <= 0 {
		return
	}
	if (msg.OrdType != 0) && (msg.Prc <= 0) {
		if msg.Side == 1 {
			msg.Prc = x.MidPrice[n-1] * 1.05
		} else {
			msg.Prc = x.MidPrice[n-1] * 0.95
		}		
	}
	// 观察最后一个x.Press0， x.Press0>0 挂卖单视为逆势卖出，挂买单视为顺势买入，记录逆势卖出，顺势买入的单的挂单量，价格，1/(挂单价格-MidPrice+5) （单子对盘口的影响压力）
	// 观察最后一个x.Press0， x.Press0<0 挂买单视为逆势买出，挂卖单视为顺势卖出，记录逆势卖出，顺势卖出的单的挂单量，价格，1/(MidPrice - 挂单价格+5) （单子对盘口的影响压力）

}

func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	// 统计逆势买入，逆势卖出在这个区间中的总量，平均价格，加权平均量 Σ（单子对盘口的影响压力*成交量）/ Σ（单子对盘口的影响压力）
	// 统计逆势买入在这个区间发生的频次，逆势卖出在这个区间发生的频次
	// 统计顺势买入，顺势卖出在这个区间中的总量，平均价格，加权平均量 Σ（单子对盘口的影响压力*成交量）/ Σ（单子对盘口的影响压力）
	// 统计顺势买入在这个区间发生的频次，顺势卖出在这个区间发生的频次

	// 统计正常撤买单，异常撤卖单在这个区间中的总量，平均价格，加权平均量 Σ（单子对盘口的影响压力*成交量）/ Σ（单子对盘口的影响压力）
	// 统计正常撤买单，异常撤卖单在这个区间发生的频次
	// 统计异常撤买单，正常撤卖单在这个区间中的总量，平均价格，加权平均量 Σ（单子对盘口的影响压力*成交量）/ Σ（单子对盘口的影响压力）
	// 统计异常撤买单，正常撤卖单在这个区间发生的频次

	// 统计突然买入，正常卖出在这个区间中的总量，平均价格，加权平均量 Σ（单子对盘口的影响压力*成交量）/ Σ（单子对盘口的影响压力）
	// 统计突然买入，正常卖出在这个区间发生的频次
	// 统计突然卖出，正常买入在这个区间中的总量，平均价格，加权平均量 Σ（单子对盘口的影响压力*成交量）/ Σ（单子对盘口的影响压力）
	// 统计突然卖出，正常买入在这个区间发生的频次


	// 清空中间变量：（Press0， MixPrice，无需清空）

	
}

// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
