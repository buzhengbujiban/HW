package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"sort"
)

type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book

	// 中间变量
	Bid2to6Vols []float64
	Ask2to6Vols []float64
	BookEpochs  []float64

	// 每个挂单记录
	MidPrice       []float64
	directions     []int8
	AddQtys        []float64
	AddPrcs        []float64
	AddIsBuy       []bool
	AddBid2to6Vols []float64
	AddAsk2to6Vols []float64
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:  base.New(cfg, sid),
		names: []string{"oppsiteHuge_S_Qty", "oppsiteHuge_S_Prc", "oppsiteHuge_S_Count", "oppsiteHuge_B_Qty", "oppsiteHuge_B_Prc", "oppsiteHuge_B_Count","QtyAdd_all"},
		outs:  make([]float64, 7),
		// MidPrice: []float64[],
		// Bid2to6Vols:     []float64{},
		// Ask2to6Vols:     []float64{},
		// BookEpochs:      []float64{},
		// AddQtys:         []float64{},
		// AddPrcs:         []float64{},
		// AddIsBuy:        []bool{},
		// AddBid2to6Vols:  []float64{},
		// AddAsk2to6Vols:  []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################

// 订单簿压力与成交价序列的相关系数，订单簿压力的范围
func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	// 记录成交价序列，以及当前时间戳对应的最后一个订单簿压力值
}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {

}



func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	x.Press0 = append(x.Press0, msg.GetAsize(0) - msg.GetBsize(0))   // 记录订单簿压力序列
	x.MidPrice   = append(x.MidPrice, msg.GetMidPrice()) 
	// 另外记录ret20序列

}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {

}

func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	// 在当前区间内，计算成交价序列与对应的订单簿压力序列的相关系数
	// 在当前区间内，计算ret20序列与订单簿压力序列的相关系数

}

// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
