package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"sort"
)

type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book

	// 中间变量
	Bid2to6Vols []float64
	Ask2to6Vols []float64
	BookEpochs  []float64

	// 每个挂单记录
	MidPrice       []float64
	directions     []int8
	AddQtys        []float64
	AddPrcs        []float64
	AddIsBuy       []bool
	AddBid2to6Vols []float64
	AddAsk2to6Vols []float64
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:  base.New(cfg, sid),
		names: []string{"oppsiteHuge_S_Qty", "oppsiteHuge_S_Prc", "oppsiteHuge_S_Count", "oppsiteHuge_B_Qty", "oppsiteHuge_B_Prc", "oppsiteHuge_B_Count","QtyAdd_all"},
		outs:  make([]float64, 7),
		// MidPrice: []float64[],
		// Bid2to6Vols:     []float64{},
		// Ask2to6Vols:     []float64{},
		// BookEpochs:      []float64{},
		// AddQtys:         []float64{},
		// AddPrcs:         []float64{},
		// AddIsBuy:        []bool{},
		// AddBid2to6Vols:  []float64{},
		// AddAsk2to6Vols:  []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################

// 同价波动率
func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	// 记录保存成交价序列，成交量序列， 对应的买单挂单量，对应的卖单挂单量
}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {
	// 对于每一个撤单，分别针对卖买撤单，记录撤单价序列，撤单量序列，撤单时间间隔序列(interval)，撤单距离盘口价差变化序列(Triger).
}



func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	x.Press0 = append(x.Press0, msg.GetAsize(0) - msg.GetBsize(0))   // 记录订单簿压力序列
	x.MidPrice   = append(x.MidPrice, msg.GetMidPrice())   // 记录中间价序列


}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	// 对于每一个挂单，分别针对卖买挂单，记录挂单价序列，挂单量序列， 
}

func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	// 计算当前区间内，挂单价分别：1.处于挂单价格序列的区间30分位数以下时候，2.处于挂单价格区间30分位数-70分位数，3.处于挂单价格区间70分位数以上, 4.处于成交价格最大和最小值区间内的， 5.处于成交价格30-70分位数区间内的，时候，买卖挂单分别对应的QtySum， PrcAvg, AmtSum, Qtystd, Prcstd, Amtstd
	// 计算当前区间内，成交单的价分别：1.处于成交价序列的区间30分位数以下时候，2.处于成交价区间30分位数-70分位数，3.处于成交价区间70分位数以上, 时候，主动买，主动卖成交单分别对应的QtySum， PrcAvg, AmtSum, Qtystd, Prcstd, Amtstd， QshareSum, 
	// 计算当前区间内，撤单的价分别：1.处于撤单价序列的区间30分位数以下时候，2.处于撤单价区间30分位数-70分位数，3.处于撤单价区间70分位数以上, 5.处于成交价格30-70分位数区间内的，时候，撤卖单，撤买单分别对应的QtySum， PrcAvg, AmtSum, Qtystd, Prcstd, Amtstd， intervalAvg, intervalstd
	// 撤卖，买单序列，分别对应的 intervalAvg, intervalStd,  TrigerAvg, TrigerStd, QtyStd, QtySum
}

// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
