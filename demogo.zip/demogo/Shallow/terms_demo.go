package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	_ "fmt"
	"math"
)

type TermDemo struct {
	*base.Base

	names     []string // names of the fields
	outs      []float64
	MidPrices    []float64
	Epochs       []float64
	
	TradePrices  []float64
	TradeQtys    []float64
	Fulltrans_Qty float64
	Fulltran_Num  float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names:            []string{"downshallowtran_Num", "downshallowtran_Qty", "downshallowtran_Prcavg", "upshallowtran_Num", 
									"upshallowtran_Qty", "upshallowtran_Prcavg", "Fulltrans_Nums", "Fulltrans_Qty"},
		outs:             make([]float64, 8),


		// MidPrice:  []float64{},
		// Timeepoch: []string{},
		// PrcsumS:   []float64{},
		// PrcsumB:   []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################

// 记录必要的中间价格！和时间戳
func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	mid := msg.GetMidPrice()
	x.MidPrices = append(x.MidPrices, mid)
	x.Epochs = append(x.Epochs, msg.SrcEpoch)
}

func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	x.TradePrices = append(x.TradePrices, float64(msg.Prc))
	x.TradeQtys = append(x.TradeQtys, float64(msg.Qty))
	x.Fulltrans_Qty += msg.Qty
	x.Fulltran_Num++
}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}


func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {}




// On Snap ###################################################################
func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {

	if len(x.MidPrices) < 2 {
		copy(out, x.outs)
		return
	}

	open := x.MidPrices[0]
	close := x.MidPrices[len(x.MidPrices)-1]
	low := open
	high := open

	for _, price := range x.MidPrices {
		if price < low {
			low = price
		}
		if price > high {
			high = price
		}
	}

	// 下影线区间: min(open, close) ~ (low - 0.02)
	shadowLowStart := low - 0.02
	shadowLowEnd := math.Min(open, close)

	// 上影线区间: (high + 0.02) ~ max(open, close)
	shadowHighStart := math.Max(open, close)
	shadowHighEnd := high + 0.02

	// 统计下影线成交
	var (
		countL, sumQtyL, sumAmtL float64
	)

	// 统计上影线成交
	var (
		countH, sumQtyH, sumAmtH float64
	)

	for i, prc := range x.TradePrices {
		qty := x.TradeQtys[i]
		// fmt.Println(prc, shadowLowStart, shadowLowEnd, "---low")
		// fmt.Println(prc, shadowHighStart, shadowHighEnd, "=--High")
		if prc > shadowLowStart && prc < shadowLowEnd {
			countL += 1
			sumQtyL += qty
			sumAmtL += prc * qty
		}
		if prc > shadowHighStart && prc < shadowHighEnd {
			countH += 1
			sumQtyH += qty
			sumAmtH += prc * qty

		}
	}

	var avgPrcL, avgPrcH float64
	if sumQtyL > 0 {
		avgPrcL = sumAmtL / sumQtyL
	}
	if sumQtyH > 0 {
		avgPrcH = sumAmtH / sumQtyH
	}

	// 存入结果: outs[0~2] 下影线区成交笔数、量、均价；outs[3~5] 上影线区成交笔数、量、均价
	x.outs = []float64{countL, sumQtyL, avgPrcL, countH, sumQtyH, avgPrcH, x.Fulltran_Num, x.Fulltrans_Qty}
	copy(out, x.outs)

	// 清空中间变量
	x.outs = make([]float64, 8)

	x.MidPrices = x.MidPrices[:0]
	x.Epochs = x.Epochs[:0]

	x.TradePrices = x.TradePrices[:0]
	x.TradeQtys = x.TradeQtys[:0]

	x.Fulltran_Num = 0
	x.Fulltrans_Qty = 0

}

// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
