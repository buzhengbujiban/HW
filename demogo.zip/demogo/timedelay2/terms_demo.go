package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"math"
	"base/orderbook/cneq"
	"sort"
	"time"
	"fmt"
)


type OrderRecord struct {
	Qty      float64
	Epoch    float64
}



type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook

	MidPricelast float64
	addBuyRecords   map[int]OrderRecord
	addSellRecords  map[int]OrderRecord

	passiveSellDelay []float64
	passiveSellRatio []float64
	passiveSell20Diff []float64
	passiveBuyDelay []float64
	passiveBuyRatio []float64
	passiveBuy20Diff []float64
	activeSellRatio []float64
	activeBuyRatio []float64

	activeBuyTrTime []float64
	activeSellTrTime []float64




	activeBuyfilPrc []float64
	activeSellfilPrc []float64

	aBtradeQty []float64
	aStradeQty []float64


}
func init() {
	cneq.UNCORSSING_ON_ADD = false // 关闭 orderbook 在 SZ 主动 add 来到时，自动uncross的功能
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:  base.New(cfg, sid),
		names: []string{
			"passive_B_mean_delay", "passive_S_mean_delay",
			"passive_B_mean_ratio", "passive_S_mean_ratio",
			"passive_B_mean_20diff", "passive_S_mean_20diff",
			"QtyAdd_all",
			"passive_B_std_delay", "passive_S_std_delay",
			"passive_B_std_ratio", "passive_S_std_ratio",
			"passive_B_std_20diff", "passive_S_std_20diff",


			"Mean_filteractBuydelayl_addP",
			"Mean_filteractBuydelayl_trQ",

			"Mean_filteractBuyRatiosl_addP",
			"Mean_filteractBuyRatiosl_trQ",

			"Mean_filteractSelldelayl_addP",
			"Mean_filteractSelldelayl_trQ",

			"Mean_filteractSellRatiosl_addP",
			"Mean_filteractSellRatiosl_trQ",

			"Std_filteractBuydelayl_addP",
			"Std_filteractBuydelayl_trQ",

			"Std_filteractBuyRatiosl_addP",
			"Std_filteractBuyRatiosl_trQ",

			"Std_filteractSelldelayl_addP",
			"Std_filteractSelldelayl_trQ",

			"Std_filteractSellRatiosl_addP",
			"Std_filteractSellRatiosl_trQ",
			"Qtyaddreal_all", "Qtytrd_all",
		},
		outs:           make([]float64, 31),
		addBuyRecords:  make(map[int]OrderRecord),
		addSellRecords: make(map[int]OrderRecord),
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}


// 不同变这两个函数
func (x *TermDemo) DataType() string {
	return "f64"
}
func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################

// func FormatUnixTimestampTime(timestamp float64) string {
//     sec := int64(timestamp)
//     nsec := int64((timestamp - float64(sec)) * 1e9)
//     t := time.Unix(sec, nsec).Local()
//     return fmt.Sprintf("%02d:%02d:%02d.%06d", t.Hour(), t.Minute(), t.Second(), t.Nanosecond()/1000)
// }
func FormatUnixTimestampTime(timestamp float64) string {
    sec := int64(timestamp)
    nsec := int64((timestamp - float64(sec)) * 1e9)
    t := time.Unix(sec, nsec).Local()
    return fmt.Sprintf("%02d:%02d:%02d.%06d", t.Hour(), t.Minute(), t.Second(), t.Nanosecond()/1000)
}



func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	// 对每一个成交单，获取成交单的卖单和买单，找到被动单的挂单时间，计算当前时间-挂单时间作为被动单的成交时延，计算挂单时间-当前时间作为主动单的寻找时延，
	// 并记录每一个单的（BS_side）买/卖，主动/被动(Dir_side)， 成交时延/寻找时延， 挂单价格，挂单量
	// 计算每一个单的成交比例，则成交比例=成交量/挂单量
	// 计算每个被成交的单的卖/买单的挂单时间戳，同时计算并记录，当前事件时间戳与20个事件之前的时间戳的差，作为有效时间间隔


	if x.isSH {
		tstring := FormatUnixTimestampTime(msg.SrcEpoch)
		if ((tstring<="14:59:58") && (tstring>="09:30:00")){
			x.outs[29] += msg.Qty
		}
	}
	x.outs[30] += msg.Qty


	var passiveOid int
	var passiveSide bookmsg.BookSide

	if msg.Dir == bookmsg.DirBuy {
		// 买主动，卖被动
		passiveOid = msg.AskOid
		passiveSide = bookmsg.SellSide

	} else if msg.Dir == bookmsg.DirSell {
		passiveOid = msg.BidOid
		passiveSide = bookmsg.BuySide

	} else {
		return
	}

	var record OrderRecord
	var ok bool
	if passiveSide == bookmsg.SellSide {
		record, ok = x.addSellRecords[passiveOid]
	} else {
		record, ok = x.addBuyRecords[passiveOid]
	}
	if !ok {
		return // 找不到原始挂单信息，跳过
	}


	delay := msg.SrcEpoch - record.Epoch
	ratio := msg.Qty / record.Qty


	// 累加聚合
	if passiveSide == -1 {
		x.passiveSellDelay = append(x.passiveSellDelay, delay)
		x.passiveSellRatio = append(x.passiveSellRatio, ratio)
		
		x.aBtradeQty         = append(x.aBtradeQty, msg.Qty)
		x.activeBuyfilPrc = append(x.activeBuyfilPrc, msg.Prc)
		

		x.activeBuyTrTime = append(x.activeBuyTrTime, msg.SrcEpoch)
		nRecordB := len(x.activeBuyTrTime)
		if nRecordB>=20 {
			x.passiveBuy20Diff = append(x.passiveBuy20Diff, msg.SrcEpoch - x.activeBuyTrTime[nRecordB-20])
			x.activeBuyTrTime = x.activeBuyTrTime[1:]
		}
		
	} else {
		x.passiveBuyDelay = append(x.passiveBuyDelay, delay)
		x.passiveBuyRatio = append(x.passiveBuyRatio, ratio)

		x.aStradeQty         = append(x.aStradeQty, msg.Qty)
		x.activeSellfilPrc = append(x.activeSellfilPrc, msg.Prc)


		x.activeSellTrTime = append(x.activeSellTrTime, msg.SrcEpoch)
		nRecordS := len(x.activeSellTrTime)
		if nRecordS>=20 {
			x.passiveSell20Diff = append(x.passiveSell20Diff, msg.SrcEpoch - x.activeSellTrTime[nRecordS-20])
			x.activeSellTrTime = x.activeSellTrTime[1:]
		}
	}
}


func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}



func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {

}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {



	record := OrderRecord{
		Qty:      msg.Qty,
		Epoch:    msg.SrcEpoch,
	}

	if msg.Side == bookmsg.BuySide {
		x.addBuyRecords[msg.Oid] = record
	} else if msg.Side == bookmsg.SellSide {
		x.addSellRecords[msg.Oid] = record
	}

	x.outs[6] += msg.Qty // QtyAdd_all
	x.outs[29] += msg.Qty
}







func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {


	var filteractBuydelayl_addP,filteractBuydelayl_trQ, filteractBuyRatiosl_addP, filteractBuyRatiosl_trQ, filteractSelldelayl_addP, 
		filteractSelldelayl_trQ, filteractSellRatiosl_addP, filteractSellRatiosl_trQ  []float64
	x.outs[0] = Mean(x.passiveBuyDelay)
	x.outs[1] = Mean(x.passiveSellDelay)

	x.outs[2] = Mean(x.passiveBuyRatio)
	x.outs[3] = Mean(x.passiveSellRatio)

	x.outs[4] = Mean(x.passiveBuy20Diff)
	x.outs[5] = Mean(x.passiveSell20Diff)


	x.outs[7] = Std(x.passiveBuyDelay)
	x.outs[8] = Std(x.passiveSellDelay)

	x.outs[9] = Std(x.passiveBuyRatio)
	x.outs[10] = Std(x.passiveSellRatio)

	x.outs[11] = Std(x.passiveBuy20Diff)
	x.outs[12] = Std(x.passiveSell20Diff)


	sortedDelays := append([]float64{}, x.passiveSellDelay...)
	sort.Float64s(sortedDelays)
	sortedRatios := append([]float64{}, x.passiveSellRatio...)
	sort.Float64s(sortedRatios)

	DelayCount := len(sortedDelays)
	if DelayCount>=5 {
		p70delays := sortedDelays[DelayCount*70/100]
		p70Ratios := sortedRatios[DelayCount*60/100]


	for i := 0; i < DelayCount; i++ {
		if x.passiveSellDelay[i] > p70delays{
			filteractBuydelayl_addP = append(filteractBuydelayl_addP, x.activeBuyfilPrc[i])
			filteractBuydelayl_trQ = append(filteractBuydelayl_trQ, x.aBtradeQty[i])
		}


		if x.passiveSellRatio[i] > p70Ratios{
			filteractBuyRatiosl_addP = append(filteractBuyRatiosl_addP, x.activeBuyfilPrc[i])
			filteractBuyRatiosl_trQ = append(filteractBuyRatiosl_trQ, x.aBtradeQty[i])
		}

	}
	}


	sortedDelayBuy := append([]float64{}, x.passiveBuyDelay...)
	sort.Float64s(sortedDelayBuy)
	sortedRatioBuy := append([]float64{}, x.passiveBuyRatio...)
	sort.Float64s(sortedRatioBuy)

	DelayCountBuy := len(sortedDelayBuy)
	if DelayCountBuy>=5 {
		p70delays := sortedDelayBuy[DelayCountBuy*70/100]
		p70Ratios := sortedRatioBuy[DelayCountBuy*60/100]
	
	for i := 0; i < DelayCountBuy; i++ {
		if x.passiveBuyDelay[i] > p70delays{
			
			filteractSelldelayl_addP = append(filteractSelldelayl_addP, x.activeSellfilPrc[i])
			filteractSelldelayl_trQ = append(filteractSelldelayl_trQ, x.aStradeQty[i])
		}

		if x.passiveBuyRatio[i] > p70Ratios{
			
			filteractSellRatiosl_addP = append(filteractSellRatiosl_addP, x.activeSellfilPrc[i])
			filteractSellRatiosl_trQ = append(filteractSellRatiosl_trQ, x.aStradeQty[i])
		}

	}
	}


	x.outs[13] = Mean(filteractBuydelayl_addP)
	x.outs[14] = Sum(filteractBuydelayl_trQ)

	x.outs[15] = Mean(filteractBuyRatiosl_addP)
	x.outs[16] = Sum(filteractBuyRatiosl_trQ)
	

	x.outs[17] = Mean(filteractSelldelayl_addP)
	x.outs[18] = Sum(filteractSelldelayl_trQ)

	x.outs[19] = Mean(filteractSellRatiosl_addP)
	x.outs[20] = Sum(filteractSellRatiosl_trQ)
	


	x.outs[21] = Std(filteractBuydelayl_addP)
	x.outs[22] = Std(filteractBuydelayl_trQ)

	x.outs[23] = Std(filteractBuyRatiosl_addP)
	x.outs[24] = Std(filteractBuyRatiosl_trQ)
	

	x.outs[25] = Std(filteractSelldelayl_addP)
	x.outs[26] = Std(filteractSelldelayl_trQ)

	x.outs[27] = Std(filteractSellRatiosl_addP)
	x.outs[28] = Std(filteractSellRatiosl_trQ)
	


	copy(out, x.outs)

	// 清空
	x.outs = make([]float64, 29)

	// x.addBuyRecords = make(map[int]OrderRecord)
	// x.addSellRecords = make(map[int]OrderRecord)
	x.passiveBuyDelay = x.passiveBuyDelay[:0]
	x.passiveSellDelay = x.passiveSellDelay[:0]
	x.passiveBuyRatio = x.passiveBuyRatio[:0]
	x.passiveSellRatio = x.passiveSellRatio[:0]
	x.passiveBuy20Diff = x.passiveBuy20Diff[:0]
	x.passiveSell20Diff = x.passiveSell20Diff[:0]
	x.activeSellfilPrc = x.activeSellfilPrc[:0]
	x.activeBuyfilPrc = x.activeBuyfilPrc[:0]
	x.aStradeQty  = x.aStradeQty[:0]
	x.aBtradeQty = x.aBtradeQty[:0]

}

func Sum(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	for _, v := range arr {
		sum += v
	}
	return sum 
}



func Mean(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	for _, v := range arr {
		sum += v
	}
	return sum / float64(len(arr))
}


func Std(arr []float64) float64 {
	valid := make([]float64, 0, len(arr))
	for _, v := range arr {
		if !math.IsNaN(v) {
			valid = append(valid, v)
		}
	}
	n := len(valid)
	if n < 3 {
		return 0
	}
	mean := Mean(valid)
	var sum float64
	for _, v := range valid {
		sum += (v - mean) * (v - mean)
	}
	return math.Sqrt(sum / float64(n-1)) // 样本标准差
}



// percentile returns the threshold value for the given ratio (e.g. 0.7 means top 30%)


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
