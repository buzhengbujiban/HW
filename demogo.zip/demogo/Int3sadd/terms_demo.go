package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"fmt"
	"time"
	"strings"
	"math"
)

type TermDemo struct {
	*base.Base

	names     []string // names of the fields
	outs      []float64

	MidPrice  []float64
	Timeepoch []float64
	PrcsumS   []float64
	PrcsumB   []float64
	Prcsum2S  []float64
	Prcsum2B  []float64
	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names:     []string{"allQrt_S", "millisecInt_S_Qty", "millisecInt_B_Qty", "Around3s_S_Qty", "Around3s_B_Qty", 
							"millisecInt_S_Prcavg", "millisecInt_B_Prcavg", "Around3s_S_Prcavg", "Around3s_B_Prcavg", "allQrt_B"},
		outs:      make([]float64, 10),
		// Timeepoch: []string{},
		// PrcsumS:   []float64{},
		// PrcsumB:   []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// FormatUnixTimestampTime 将 float64 类型的 Unix 时间戳转换为格式化的时间字符串（%H:%M:%S.%f）
func FormatUnixTimestampTime(timestamp float64) string {
    sec := int64(timestamp)
    nsec := int64((timestamp - float64(sec)) * 1e9)
    t := time.Unix(sec, nsec).Local()
    return fmt.Sprintf("%02d:%02d:%02d.%06d", t.Hour(), t.Minute(), t.Second(), t.Nanosecond()/1000)
}

func meanNanIgnore(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	count := 0
	for _, val := range arr {
		if !math.IsNaN(val) {
			sum += val
			count++
		}
	}
	if count == 0 {
		return 0 // or return math.NaN() if you prefer
	}
	return sum / float64(count)
}

// On Msg Update ###################################################################
func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	x.Timeepoch = append(x.Timeepoch, msg.SrcEpoch)
	x.MidPrice  = append(x.MidPrice, msg.GetMidPrice())
}

func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {

	n := len(x.MidPrice)
	if n == 0 {
		return
	}

	if (msg.OrdType != 0) && (msg.Prc <= 0) {
		if msg.Side == 1 {
			msg.Prc = x.MidPrice[n-1] * 1.05
		} else {
			msg.Prc = x.MidPrice[n-1] * 0.95
		}		
	}

	if msg.Side == -1 {
		x.outs[0] += msg.Qty
	}
	if msg.Side == 1 {
		x.outs[9] += msg.Qty
	}

	strtime := FormatUnixTimestampTime(msg.SrcEpoch) // 例: "12:34:56.123"
	parts := strings.Split(strtime, ".")
	millisec := ""
	if len(parts) > 1 {
		millisec = parts[1][:3] // 取出毫秒部分的前3位
	}

	int3slist := map[string]struct{}{
		"000": {}, "999": {}, "500": {}, "499": {},
	}

	_, inList := int3slist[millisec]
	if inList && msg.Side == -1 {
		x.outs[1] += msg.Qty
		x.PrcsumS = append(x.PrcsumS, msg.Prc)
	}
	if inList && msg.Side == 1 {
		x.outs[2] += msg.Qty
		x.PrcsumB = append(x.PrcsumB, msg.Prc)
	}


	n := len(x.Timeepoch)
	if n >= 1 {

		diff := msg.SrcEpoch - x.Timeepoch[n-1]
		// fmt.Println(FormatUnixTimestampTime(x.Timeepoch[n-1]), n, strtime, msg.SrcEpoch - x.Timeepoch[n-1], "see___________Timeepch")
		if (diff < 0.65) && (diff > 0) {
			if msg.Side == -1 {
				x.outs[3] += msg.Qty
				x.Prcsum2S = append(x.Prcsum2S, msg.Prc)
			}
			if msg.Side == 1 {
				x.outs[4] += msg.Qty
				x.Prcsum2B = append(x.Prcsum2B, msg.Prc)
			}
		}
	}
}

// On Snap ###################################################################
func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	
	x.outs[5] = meanNanIgnore(x.PrcsumS)
	x.outs[6] = meanNanIgnore(x.PrcsumB)

	x.outs[7] = meanNanIgnore(x.Prcsum2S)
	x.outs[8] = meanNanIgnore(x.Prcsum2B)
	copy(out, x.outs)
	// fmt.Println("-------", x.outs)
	x.outs = make([]float64, 10)
	x.PrcsumS = x.PrcsumS[:0]
	x.PrcsumB = x.PrcsumB[:0]
	x.Prcsum2S = x.PrcsumS[:0]
	x.Prcsum2B = x.PrcsumB[:0]

}


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
