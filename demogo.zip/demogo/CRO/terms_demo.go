package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	_ "fmt"
	"math"
)

type TermDemo struct {
	*base.Base

	names     []string // names of the fields
	outs      []float64
	MidPrice  []float64
	Timeepoch []float64
	Wpressure1 []float64
	// ========== 买方挂单相关 ==========
	TimeepochB      []float64 // 每个买单的时间戳
	QtyB            []float64 // 对应每个买单的数量
	PrcB            []float64 // 对应每个买单的价格

	// ========== 卖方挂单相关 ==========
	TimeepochS      []float64 // 每个卖单的时间戳
	QtyS            []float64 // 对应每个卖单的数量
	PrcS            []float64 // 对应每个卖单的价格
	// ========== Tran挂单相关 ==========
	TimeepochTran   []float64
	PrcTran         []float64
	QtyTran         []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names:            []string{"Trendslop_add_B", "Trendslop_add_S", "autoCorrHalf_add_B_Prc", "autoCorrHalf_add_S_Prc", "autoCorrHalf_add_B_Qty", "autoCorrHalf_add_S_Qty",
		"Trendslop_trans", "Trendslop_Midprice_snap", "Trendslop_Wpressure1_snap"},
		outs:             make([]float64, 9),

		TimeepochB:      make([]float64, 0, 1000),
		QtyB:            make([]float64, 0, 1000),
		PrcB:            make([]float64, 0, 1000),
		TimeepochS:      make([]float64, 0, 1000),
		QtyS:            make([]float64, 0, 1000),
		PrcS:            make([]float64, 0, 1000),
		TimeepochTran:   make([]float64, 0, 1000),
		// MidPrice:  []float64{},
		// Timeepoch: []string{},
		// PrcsumS:   []float64{},
		// PrcsumB:   []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}



func autoCorrHalf(x []float64) float64 {
	n := len(x)
	if n < 4 {
		return 0
	}
	mid := n / 2
	a := x[:mid]
	b := x[mid:]
	return corr(a, b)
}

func corr(x, y []float64) float64 {
	n := len(x)
	if len(y) != n || n < 2 {
		return 0
	}
	var sumX, sumY float64
	for i := 0; i < n; i++ {
		sumX += x[i]
		sumY += y[i]
	}
	meanX := sumX / float64(n)
	meanY := sumY / float64(n)

	var num, denomX, denomY float64
	for i := 0; i < n; i++ {
		dx := x[i] - meanX
		dy := y[i] - meanY
		num += dx * dy
		denomX += dx * dx
		denomY += dy * dy
	}
	if denomX == 0 || denomY == 0 {
		return 0
	}
	return num / math.Sqrt(denomX*denomY)
}




// On Msg Update ###################################################################
func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	x.MidPrice  = append(x.MidPrice, msg.GetMidPrice())
	x.Timeepoch = append(x.Timeepoch, msg.SrcEpoch)
	x.Wpressure1  = append(x.Wpressure1, msg.GetBsize(0) - msg.GetAsize(0))
}

func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	// 采用 Unix 时间提取秒数

	x.TimeepochTran = append(x.TimeepochTran, msg.SrcEpoch)
	x.PrcTran = append(x.PrcTran, msg.Prc)

}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	// 采用 Unix 时间提取秒数
	n := len(x.MidPrice)
	if n == 0 {
		return
	}


	if (msg.OrdType != 0) && (msg.Prc <= 0) {
		if msg.Side == 1 {
			msg.Prc = x.MidPrice[n-1] * 1.05
		} else {
			msg.Prc = x.MidPrice[n-1] * 0.95
		}		
	}


	if msg.Side == 1 {
		x.TimeepochB = append(x.TimeepochB, msg.SrcEpoch)
		x.PrcB = append(x.PrcB, msg.Prc)
		x.QtyB = append(x.QtyB, msg.Qty)
	}
	if msg.Side == -1 {
		x.TimeepochS = append(x.TimeepochS, msg.SrcEpoch)
		x.PrcS = append(x.PrcS, msg.Prc)
		x.QtyS = append(x.QtyS, msg.Qty)
	}
}





// On Snap ###################################################################
func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	//分别计算该区间内买，卖的订单，挂单价格与时间戳的做回归的beta

	// 分别计算该区间内卖买订单，前半段挂单价格序列，与后半段挂单价格序列的自相关系数
	// 分别计算该区间内卖买订单，前半段挂单量序列，与后半段挂单量序列的自相关系数

	// ===== 买方订单量的前后半段自相关 =====
	if len(x.QtyB) >= 6 {
		x.outs[0] = corr(x.TimeepochB, x.PrcB)
		x.outs[2] = autoCorrHalf(x.PrcB)
		x.outs[4] = autoCorrHalf(x.QtyB)

	}
	if len(x.QtyS) >= 6 {
		x.outs[1] = corr(x.TimeepochS, x.PrcS)
		x.outs[3] = autoCorrHalf(x.PrcS)
		x.outs[5] = autoCorrHalf(x.QtyS)
	}

	if len(x.TimeepochTran) >= 6 {
		x.outs[6] = corr(x.TimeepochTran, x.PrcTran)
	}
	if len(x.Timeepoch) >= 6 {
		x.outs[7] = corr(x.Timeepoch, x.MidPrice)
		x.outs[8] = corr(x.Timeepoch, x.Wpressure1)
	}

	copy(out, x.outs)

	// 清空中间变量
	x.outs = make([]float64, 9)

	
	x.TimeepochB = x.TimeepochB[:0]
	x.QtyB = x.QtyB[:0]
	x.PrcB = x.PrcB[:0]

	x.TimeepochS = x.TimeepochS[:0]
	x.QtyS = x.QtyS[:0]
	x.PrcS = x.PrcS[:0]

	x.TimeepochTran = x.TimeepochTran[:0]
	x.PrcTran = x.PrcTran[:0]

	x.Timeepoch = x.Timeepoch[:0]
	x.MidPrice = x.MidPrice[:0]
	x.Wpressure1 = x.Wpressure1[:0]
}


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
