package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"sort"
)

type TermDemo struct {
	*base.Base

	names     []string // names of the fields
	outs      []float64
	MidPrice         []float64
	Timeepoch        []float64
	Ask0Price        []float64
	Bid0Price        []float64

	AddmsgMidPrclist []float64
	Prc_all_B        []float64
	Qty_all_B        []float64
	Prc_all_S        []float64
	Qty_all_S        []float64

	Prc_B_3s  []float64
	Qty_B_3s  []float64
	Prc_S_3s  []float64
	Qty_S_3s  []float64
	Prc_B     []float64
	Qty_B     []float64
	Prc_S     []float64
	Qty_S     []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names:            []string{"Impactret_B_sumQty", "Impactret_B_avgPrc", "Impactret_B_sumAmt", "Impactret_S_sumQty", "Impactret_S_avgPrc", "Impactret_S_sumAmt",
									"Chguseful_B_sumQty", "Chguseful_B_avgPrc", "Chguseful_B_sumAmt", "Chguseful_S_sumQty", "Chguseful_S_avgPrc", "Chguseful_S_sumAmt",
									"Qtyall_B","Qtyall_S"},
		outs:             make([]float64, 14),

		// MidPrice:  []float64{},
		// Timeepoch: []string{},
		// PrcsumS:   []float64{},
		// PrcsumB:   []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################
func Percentile(data []float64, percentile float64) float64 {
	if len(data) == 0 {
		return 0
	}
	sorted := make([]float64, len(data))
	copy(sorted, data)
	sort.Float64s(sorted)

	k := int(float64(len(sorted)-1) * percentile)
	return sorted[k]
}
// 任务1：回看每个订单，计算这一区间末尾的 MidPrice/该订单对应的MidPrice, 记作该订单的retImpact, 对于买单，retImpact>0才予以记录（统计QtySum, PrcAvg, AmtSum(Amt=Qty*Prc)）， 对于卖单， retImpact<0 才予以记录（统计QtySum, PrcAvg, AmtSum(Amt=Qty*Prc)）
// 任务2：只记录Ask0Price发生变化时候, 前3s区间内的Buy订单, 只记录Bid0Price发生变化的时候，前3s区间内的Sell订单，给出聚合后的QtySum, PrcAvg, AmtSum

func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {

	curMid := msg.GetMidPrice()
	curEpoch := msg.SrcEpoch

	x.MidPrice = append(x.MidPrice, curMid)
	x.Timeepoch = append(x.Timeepoch, curEpoch)
	x.Ask0Price = append(x.Ask0Price, msg.GetAsk(0))
	x.Bid0Price = append(x.Bid0Price, msg.GetBid(0))

	n := len(x.Ask0Price)
	if n >= 2 {
		if x.Ask0Price[n-1] != x.Ask0Price[n-2] {
			x.Prc_B = append(x.Prc_B, x.Prc_B_3s...)
			x.Qty_B = append(x.Qty_B, x.Qty_B_3s...)
		}
		if x.Bid0Price[n-1] != x.Bid0Price[n-2] {
			x.Prc_S = append(x.Prc_S, x.Prc_S_3s...)
			x.Qty_S = append(x.Qty_S, x.Qty_S_3s...)
		}
	}

	// 初始化
	x.Prc_B_3s = x.Prc_B_3s[:0]
	x.Qty_B_3s = x.Qty_B_3s[:0]
	x.Prc_S_3s = x.Prc_S_3s[:0]
	x.Qty_S_3s = x.Qty_S_3s[:0]
}


func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	n := len(x.MidPrice)
	if n == 0 {
		return
	}

	if (msg.OrdType != 0) && (msg.Prc <= 0) {
		if msg.Side == 1 {
			msg.Prc = x.MidPrice[n-1] * 1.05
		} else {
			msg.Prc = x.MidPrice[n-1] * 0.95
		}		
	}

	lastMid := x.MidPrice[n-1]

	if msg.Side == 1 {
		x.AddmsgMidPrclist = append(x.AddmsgMidPrclist, lastMid)
		x.Prc_all_B = append(x.Prc_all_B, msg.Prc)
		x.Qty_all_B = append(x.Qty_all_B, msg.Qty)

		x.Prc_B_3s = append(x.Prc_B_3s, msg.Prc)
		x.Qty_B_3s = append(x.Qty_B_3s, msg.Qty)

		x.outs[12] += msg.Qty
	}

	if msg.Side == -1 {
		x.AddmsgMidPrclist = append(x.AddmsgMidPrclist, lastMid)
		x.Prc_all_S = append(x.Prc_all_S, msg.Prc)
		x.Qty_all_S = append(x.Qty_all_S, msg.Qty)

		x.Prc_S_3s = append(x.Prc_S_3s, msg.Prc)
		x.Qty_S_3s = append(x.Qty_S_3s, msg.Qty)
		x.outs[13] += msg.Qty
	}
}




// On Snap ###################################################################
func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	n := len(x.MidPrice)
	if n == 0 {
		return
	}
	finalMid := x.MidPrice[n-1]

	var (
		sumQtyB, sumAmtB, sumPrcB float64
		sumQtyS, sumAmtS, sumPrcS float64
	)

	// 任务1：订单收益影响计算
	for i := 0; i < len(x.AddmsgMidPrclist); i++ {
		impact := finalMid / x.AddmsgMidPrclist[i]

		// 买单
		if i < len(x.Prc_all_B) && i < len(x.Qty_all_B) {
			if impact > 1.0 {
				q := x.Qty_all_B[i]
				p := x.Prc_all_B[i]
				sumQtyB += q
				sumAmtB += q * p
				sumPrcB += p * q
			}
		}

		// 卖单
		if i < len(x.Prc_all_S) && i < len(x.Qty_all_S) {
			if impact < 1.0 {
				q := x.Qty_all_S[i]
				p := x.Prc_all_S[i]
				sumQtyS += q
				sumAmtS += q * p
				sumPrcS += p * q
			}
		}
	}

	// 任务2：盘口变动前的3s挂单聚合
	var sumQtyB3s, sumAmtB3s, sumPrcB3s float64
	var sumQtyS3s, sumAmtS3s, sumPrcS3s float64

	for i := range x.Prc_B {
		q := x.Qty_B[i]
		p := x.Prc_B[i]
		sumQtyB3s += q
		sumAmtB3s += q * p
		sumPrcB3s += p * q
	}

	for i := range x.Prc_S {
		q := x.Qty_S[i]
		p := x.Prc_S[i]
		sumQtyS3s += q
		sumAmtS3s += q * p
		sumPrcS3s += p * q
	}

	// 存结果
	x.outs[0] = sumQtyB
	x.outs[1] = safeDiv(sumPrcB, sumQtyB)
	x.outs[2] = sumAmtB
	x.outs[3] = sumQtyS
	x.outs[4] = safeDiv(sumPrcS, sumQtyS)
	x.outs[5] = sumAmtS

	x.outs[6] = sumQtyB3s
	x.outs[7] = safeDiv(sumPrcB3s, sumQtyB3s)
	x.outs[8] = sumAmtB3s
	x.outs[9] = sumQtyS3s
	x.outs[10] = safeDiv(sumPrcS3s, sumQtyS3s)
	x.outs[11] = sumAmtS3s


	copy(out, x.outs)
	// 清空
	x.outs = make([]float64, 14)
	x.MidPrice = x.MidPrice[:0]
	x.Timeepoch = x.Timeepoch[:0]
	x.Ask0Price = x.Ask0Price[:0]
	x.Bid0Price = x.Bid0Price[:0]

	x.AddmsgMidPrclist = x.AddmsgMidPrclist[:0]
	x.Prc_all_B = x.Prc_all_B[:0]
	x.Qty_all_B = x.Qty_all_B[:0]
	x.Prc_all_S = x.Prc_all_S[:0]
	x.Qty_all_S = x.Qty_all_S[:0]

	x.Prc_B_3s = x.Prc_B_3s[:0]
	x.Qty_B_3s = x.Qty_B_3s[:0]
	x.Prc_S_3s = x.Prc_S_3s[:0]
	x.Qty_S_3s = x.Qty_S_3s[:0]
	x.Prc_B = x.Prc_B[:0]
	x.Qty_B = x.Qty_B[:0]
	x.Prc_S = x.Prc_S[:0]
	x.Qty_S = x.Qty_S[:0]
}

func safeDiv(a, b float64) float64 {
	if b == 0 {
		return 0
	}
	return a / b
}



// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
