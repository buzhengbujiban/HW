package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"sort"
	"time"
	"fmt"
	"math"
)

type TermDemo struct {
	*base.Base
	names []string
	outs  []float64

	isSH bool
	isSZ bool
	ob   ob.IOrderBook

	// 中间记录每3秒内的变量（用于1分钟聚合）

	curTradeQtyBuy  []float64
	curTradeQtySell []float64
	curAddQtyBuy    []float64
	curAddQtySell   []float64

	OidmaxSell int
	OidmaxBuy int


	addQtyBuy3s 	[]float64
	addNumBuy3s	    []float64

	tradeQtyBuy3s  []float64
	tradeNumBuy3s  []float64

	addQtySell3s   []float64
	addNumSell3s   []float64

	tradeQtySell3s []float64
	tradeNumSell3s []float64


	addQtyStdBuy3s 	 []float64
	addQNavgBuy3s 	 []float64
	
	tradeQtyStdBuy3s []float64
	tradeQNavgBuy3s  []float64
	
	addQtyStdSell3s  []float64
	addQNavgSell3s   []float64
	
	tradeQtyStdSell3s []float64
	tradeQNavgSell3s  []float64
	
	

}




func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:  base.New(cfg, sid),
		names: []string{    "statMean_addQtyBuy3s", "statStd_addQtyBuy3s", "decay_addQtyBuy3s",
		"statMean_tradeQtyBuy3s", "statStd_tradeQtyBuy3s", "decay_tradeQtyBuy3s",
		"statMean_addNumBuy3s", "statStd_addNumBuy3s", "decay_addNumBuy3s",
		"statMean_tradeNumBuy3s", "statStd_tradeNumBuy3s", "decay_tradeNumBuy3s",
		"statMean_addQtySell3s", "statStd_addQtySell3s", "decay_addQtySell3s",
		"statMean_tradeQtySell3s", "statStd_tradeQtySell3s", "decay_tradeQtySell3s",
		"statMean_addNumSell3s", "statStd_addNumSell3s", "decay_addNumSell3s",
		"statMean_tradeNumSell3s", "statStd_tradeNumSell3s", "decay_tradeNumSell3s",
		"statStd_addQtyStdBuy3s", "decay_addQtyStdBuy3s",
		"statStd_tradeQtyStdBuy3s", "decay_tradeQtyStdBuy3s",
		"statStd_addQNavgBuy3s", "decay_addQNavgBuy3s",
		"statStd_tradeQNavgBuy3s", "decay_tradeQNavgBuy3s",
		"statMean_addQtyStdSell3s", "statStd_addQtyStdSell3s",
		"statMean_tradeQtyStdSell3s", "statStd_tradeQtyStdSell3s",
		"statMean_addQNavgSell3s", "statStd_addQNavgSell3s",
		"statMean_tradeQNavgSell3s", "statStd_tradeQNavgSell3s",
		"statMean_filter_addQtySell3s", "statStd_filter_addQtySell3s",
		"statMean_filter_addNumSell3s", "statStd_filter_addNumSell3s",
		"statMean_filter_addQtySell3s_2", "statStd_filter_addQtySell3s_2",
		"statMean_filter_addNumSell3s_2", "statStd_filter_addNumSell3s_2",
		"statMean_filter_addQtyBuy3s", "statStd_filter_addQtyBuy3s",
		"statMean_filter_addNumBuy3s", "statStd_filter_addNumBuy3s",
		"statMean_filter_addQtyBuy3s_2", "statStd_filter_addQtyBuy3s_2",
		"statMean_filter_addNumBuy3s_2", "statStd_filter_addNumBuy3s_2",
		},
		outs:         make([]float64, 56),
		OidmaxBuy: 0,
		OidmaxSell: 0,
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}


func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################

func FormatUnixTimestampTime(timestamp float64) string {
    sec := int64(timestamp)
    nsec := int64((timestamp - float64(sec)) * 1e9)
    t := time.Unix(sec, nsec).Local()
    return fmt.Sprintf("%02d:%02d:%02d.%06d", t.Hour(), t.Minute(), t.Second(), t.Nanosecond()/1000)
}

func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {

	if x.isSH {
		tstring := FormatUnixTimestampTime(msg.SrcEpoch)
		if ((tstring<="14:59:58") && (tstring>="09:30:00")){
			if msg.AskOid < msg.BidOid{
				x.curAddQtyBuy = append(x.curAddQtyBuy, msg.Qty)
				x.OidmaxBuy = msg.BidOid
			} else if msg.BidOid < msg.AskOid {
				x.curAddQtySell = append(x.curAddQtySell, msg.Qty)
				x.OidmaxSell = msg.AskOid
			}
		}
	}
	
	if msg.Dir == 1 {
		x.curTradeQtyBuy = append(x.curTradeQtyBuy, msg.Qty)
	} else if msg.Dir == -1 {
		x.curTradeQtySell = append(x.curTradeQtySell, msg.Qty)
	}
}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}



func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	// 该事件每3s触发一次，观察这个3s内 买卖挂单分别的数量
	// 观察这个3s内，成交事件的个数， 买方订单的未成交量，卖方订单的未成交量。

	addBuy3ssum := statMean(x.curAddQtyBuy)
	addBuy3snum := float64(len(x.curAddQtyBuy))
	
	x.addQtyBuy3s = append(x.addQtyBuy3s, addBuy3ssum)
	x.addNumBuy3s = append(x.addNumBuy3s, addBuy3snum)
	x.addQtyStdBuy3s = append(x.addQtyStdBuy3s, statStd(x.curAddQtyBuy))
	x.addQNavgBuy3s = append(x.addQNavgBuy3s, addBuy3ssum / addBuy3snum)




	trdBuy3ssum := statMean(x.curTradeQtyBuy)
	trdBuy3snum := float64(len(x.curTradeQtyBuy))
	
	x.tradeQtyBuy3s = append(x.tradeQtyBuy3s, trdBuy3ssum)
	x.tradeNumBuy3s = append(x.tradeNumBuy3s, trdBuy3snum)
	x.tradeQtyStdBuy3s = append(x.tradeQtyStdBuy3s, statStd(x.curTradeQtyBuy))
	x.tradeQNavgBuy3s = append(x.tradeQNavgBuy3s, trdBuy3ssum / trdBuy3snum)





	addSell3ssum := statMean(x.curAddQtySell)
	addSell3snum := float64(len(x.curAddQtySell))
	
	x.addQtySell3s = append(x.addQtySell3s, addSell3ssum)
	x.addNumSell3s = append(x.addNumSell3s, addSell3snum)
	x.addQtyStdSell3s = append(x.addQtyStdSell3s, statStd(x.curAddQtySell))
	x.addQNavgSell3s = append(x.addQNavgSell3s, addSell3ssum / addSell3snum)
	
	
	
	trdSell3ssum := statMean(x.curTradeQtySell)
	trdSell3snum := float64(len(x.curTradeQtySell))
	
	x.tradeQtySell3s = append(x.tradeQtySell3s, trdSell3ssum)
	x.tradeNumSell3s = append(x.tradeNumSell3s, trdSell3snum)
	x.tradeQtyStdSell3s = append(x.tradeQtyStdSell3s, statStd(x.curTradeQtySell))
	x.tradeQNavgSell3s = append(x.tradeQNavgSell3s, trdSell3ssum / trdSell3snum)
	
	


	// 清空当前窗口数据
	x.curAddQtyBuy = x.curAddQtyBuy[:0]
	x.curAddQtySell = x.curAddQtySell[:0]
	x.curTradeQtySell = x.curTradeQtySell[:0]
	x.curTradeQtyBuy = x.curTradeQtyBuy[:0]

}
	

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	// 记录每个挂单的挂单量，挂单价格，挂单的买卖方向， 买卖单分别的时间戳

	if x.isSH {
		if x.OidmaxBuy == msg.Oid {
			n := len(x.curAddQtyBuy)
			if n>0 {
				x.curAddQtyBuy[n-1] += msg.Qty
				return
			}
		}
		if x.OidmaxSell == msg.Oid {
			n := len(x.curAddQtySell)
			if n>0 {
				x.curAddQtySell[n-1] += msg.Qty
				return
			}
		}
	}

	if msg.Side == bookmsg.BuySide {
		x.curAddQtyBuy = append(x.curAddQtyBuy, msg.Qty)
	} else if msg.Side == bookmsg.SellSide {
		x.curAddQtySell = append(x.curAddQtySell, msg.Qty)
	}
}
	

func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {

	// 根据每个3s区间获取的数组，分买卖， 分别计算挂单数量的标准差，平均值，经过时间衰减加权后的平均值
	// 根据每个3s区间获取的数组，分买卖， 分别计算订单的未成交量的标准差，平均值，经过时间衰减加权后的平均值

	decay := func(arr []float64) float64 {
		n := len(arr)
		if n == 0 {
			return 0
		}
		weightSum := 0.0
		weighted := 0.0
		for i, v := range arr {
			w := math.Exp(-float64(n-i-1) / 2.0) // 越近越大
			weightSum += w
			weighted += v * w
		}
		return weighted / weightSum
	}

	// 输出字段
	x.outs[0] = statMean(x.addQtyBuy3s)
	x.outs[1] = statStd(x.addQtyBuy3s)
	x.outs[2] = decay(x.addQtyBuy3s)
	x.outs[3] = statMean(x.tradeQtyBuy3s)
	x.outs[4] = statStd(x.tradeQtyBuy3s)
	x.outs[5] = decay(x.tradeQtyBuy3s)
	x.outs[6] = statMean(x.addNumBuy3s)
	x.outs[7] = statStd(x.addNumBuy3s)
	x.outs[8] = decay(x.addNumBuy3s)
	x.outs[9] = statMean(x.tradeNumBuy3s)
	x.outs[10] = statStd(x.tradeNumBuy3s)
	x.outs[11] = decay(x.tradeNumBuy3s)



	x.outs[12] = statMean(x.addQtySell3s)
	x.outs[13] = statStd(x.addQtySell3s)
	x.outs[14] = decay(x.addQtySell3s)
	x.outs[15] = statMean(x.tradeQtySell3s)
	x.outs[16] = statStd(x.tradeQtySell3s)
	x.outs[17] = decay(x.tradeQtySell3s)
	x.outs[18] = statMean(x.addNumSell3s)
	x.outs[19] = statStd(x.addNumSell3s)
	x.outs[20] = decay(x.addNumSell3s)
	x.outs[21] = statMean(x.tradeNumSell3s)
	x.outs[22] = statStd(x.tradeNumSell3s)
	x.outs[23] = decay(x.tradeNumSell3s)





	x.outs[24] = statStd(x.addQtyStdBuy3s)
	x.outs[25] = decay(x.addQtyStdBuy3s)
	x.outs[26] = statStd(x.tradeQtyStdBuy3s)
	x.outs[27] = decay(x.tradeQtyStdBuy3s)
	x.outs[28] = statStd(x.addQNavgBuy3s)
	x.outs[29] = decay(x.addQNavgBuy3s)
	x.outs[30] = statStd(x.tradeQNavgBuy3s)
	x.outs[31] = decay(x.tradeQNavgBuy3s)
	
	x.outs[32] = statMean(x.addQtyStdSell3s)
	x.outs[33] = statStd(x.addQtyStdSell3s)
	x.outs[34] = statMean(x.tradeQtyStdSell3s)
	x.outs[35] = statStd(x.tradeQtyStdSell3s)
	x.outs[36] = statMean(x.addQNavgSell3s)
	x.outs[37] = statStd(x.addQNavgSell3s)
	x.outs[38] = statMean(x.tradeQNavgSell3s)
	x.outs[39] = statStd(x.tradeQNavgSell3s)

	
	
	var filter_addQtySell3s, filter_addNumSell3s, filter_addQtyBuy3s, filter_addNumBuy3s, filter_addQtySell3s_2, filter_addNumSell3s_2, filter_addQtyBuy3s_2, filter_addNumBuy3s_2 []float64

	SortaddQtyStdSell3s := append([]float64{}, x.addQtyStdSell3s...)
	sort.Float64s(SortaddQtyStdSell3s)
	SortaddQtyStdBuy3s := append([]float64{}, x.addQtyStdBuy3s...)
	sort.Float64s(SortaddQtyStdBuy3s)
	SortaddQNavgSell3s := append([]float64{}, x.addQNavgSell3s...)
	sort.Float64s(SortaddQNavgSell3s)
	SortaddQNavgBuy3s := append([]float64{}, x.addQNavgBuy3s...)
	sort.Float64s(SortaddQNavgBuy3s)


	DelayCountBuy := len(SortaddQtyStdSell3s)
	if DelayCountBuy>=5 {
		p70addQtyStdSell3s := SortaddQtyStdSell3s[DelayCountBuy*65/100]
		p70addQtyStdBuy3s := SortaddQtyStdBuy3s[DelayCountBuy*65/100]
		p70addQNavgSell3s := SortaddQNavgSell3s[DelayCountBuy*65/100]
		p70addQNavgBuy3s := SortaddQNavgBuy3s[DelayCountBuy*65/100]


		for i := 0; i < DelayCountBuy; i++ {
			if x.addQtyStdSell3s[i] > p70addQtyStdSell3s{
				filter_addQtySell3s = append(filter_addQtySell3s, x.addQtySell3s[i])
				filter_addNumSell3s = append(filter_addNumSell3s, x.addNumSell3s[i])
			}
			if x.addQtyStdBuy3s[i] > p70addQtyStdBuy3s{
			    filter_addQtyBuy3s = append(filter_addQtyBuy3s, x.addQtyBuy3s[i])
				filter_addNumBuy3s = append(filter_addNumBuy3s, x.addNumBuy3s[i])
			}


			if x.addQNavgSell3s[i] > p70addQNavgSell3s{
				filter_addQtySell3s_2 = append(filter_addQtySell3s_2, x.addQtySell3s[i])
				filter_addNumSell3s_2 = append(filter_addNumSell3s_2, x.addNumSell3s[i])
			}
			if x.addQNavgBuy3s[i] > p70addQNavgBuy3s{
			    filter_addQtyBuy3s_2 = append(filter_addQtyBuy3s_2, x.addQtyBuy3s[i])
				filter_addNumBuy3s_2 = append(filter_addNumBuy3s_2, x.addNumBuy3s[i])
			}

		}
	}
	
	x.outs[40] = statMean(filter_addQtySell3s)
	x.outs[41] = statStd(filter_addQtySell3s)
	x.outs[42] = statMean(filter_addNumSell3s)
	x.outs[43] = statStd(filter_addNumSell3s)
	x.outs[44] = statMean(filter_addQtySell3s_2)
	x.outs[45] = statStd(filter_addQtySell3s_2)
	x.outs[46] = statMean(filter_addNumSell3s_2)
	x.outs[47] = statStd(filter_addNumSell3s_2)

	x.outs[48] = statMean(filter_addQtyBuy3s)
	x.outs[49] = statStd(filter_addQtyBuy3s)
	x.outs[50] = statMean(filter_addNumBuy3s)
	x.outs[51] = statStd(filter_addNumBuy3s)
	x.outs[52] = statMean(filter_addQtyBuy3s_2)
	x.outs[53] = statStd(filter_addQtyBuy3s_2)
	x.outs[54] = statMean(filter_addNumBuy3s_2)
	x.outs[55] = statStd(filter_addNumBuy3s_2)


	copy(out, x.outs)

	// 清空
	x.outs = make([]float64, 56)
	x.addQtyBuy3s = x.addQtyBuy3s[:0]
	x.tradeQtyBuy3s = x.tradeQtyBuy3s[:0]
	x.addNumBuy3s = x.addNumBuy3s[:0]
	x.tradeNumBuy3s = x.tradeNumBuy3s[:0]

	x.addQtySell3s = x.addQtySell3s[:0]
	x.tradeQtySell3s = x.tradeQtySell3s[:0]
	x.addNumSell3s = x.addNumSell3s[:0]
	x.tradeNumSell3s = x.tradeNumSell3s[:0]



	x.addQtyStdBuy3s = x.addQtyStdBuy3s[:0]
	x.addQNavgBuy3s = x.addQNavgBuy3s[:0]
	x.tradeQtyStdBuy3s = x.tradeQtyStdBuy3s[:0]
	x.tradeQNavgBuy3s = x.tradeQNavgBuy3s[:0]
	   
	x.addQtyStdSell3s = x.addQtyStdSell3s[:0]
	x.addQNavgSell3s = x.addQNavgSell3s[:0]
	x.tradeQtyStdSell3s = x.tradeQtyStdSell3s[:0]
	x.tradeQNavgSell3s = x.tradeQNavgSell3s[:0]

}


func statMean(arr []float64) float64 {  // sum
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	for _, v := range arr {
		sum += v
	}
	return sum 
}







func statStd(arr []float64) float64 {
	valid := make([]float64, 0, len(arr))
	for _, v := range arr {
		if !math.IsNaN(v) {
			valid = append(valid, v)
		}
	}
	n := len(valid)
	if n < 3 {
		return 0
	}
	mean := Mean(valid)
	var sum float64
	for _, v := range valid {
		sum += (v - mean) * (v - mean)
	}
	return math.Sqrt(sum / float64(n-1)) // 样本标准差
}


func Mean(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	for _, v := range arr {
		sum += v
	}
	return sum / float64(len(arr))
}



// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
