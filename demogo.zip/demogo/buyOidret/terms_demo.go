package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"



)

type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook
	// 成交滑窗记录
	MidPrice         []float64
	QtyTrade         []float64
	AskOidList       []int
	BidOidList       []int
	obfindShareAsk   []float64
	obfindShareBid   []float64

	// 统计ret60>0.005和<0.005时的买卖指标累积
	buyOidCountPos   []float64
	buyQtySumPos     []float64
	buyShareSumPos   []float64
	sellOidCountPos  []float64
	sellQtySumPos    []float64
	sellShareSumPos  []float64

	buyOidCountNeg   []float64
	buyQtySumNeg     []float64
	buyShareSumNeg   []float64
	sellOidCountNeg  []float64
	sellQtySumNeg    []float64
	sellShareSumNeg  []float64
}
func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names: []string{
			"buyOidCountPos", "buyQtySumPos", "buyShareSumPos",
			"sellOidCountPos", "sellQtySumPos", "sellShareSumPos",
			"buyOidCountNeg", "buyQtySumNeg", "buyShareSumNeg",
			"sellOidCountNeg", "sellQtySumNeg", "sellShareSumNeg",
		},
		outs:            make([]float64, 12),

	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}
//不变
func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}
//不变

// On Msg Update ###################################################################
func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	x.MidPrice = append(x.MidPrice, msg.GetMidPrice())
	
	n := len(x.MidPrice)
	if n>=19 {
		ret:= x.MidPrice[n-1] / x.MidPrice[n-19] - 1.0
		if ret > 0 {

			buyOids := make(map[int]struct{})
			for _, oid := range x.BidOidList {
				buyOids[oid] = struct{}{}
			}
			sellOids := make(map[int]struct{})
			for _, oid := range x.AskOidList {
				sellOids[oid] = struct{}{}
			}

			x.buyOidCountPos = append(x.buyOidCountPos, float64(len(buyOids)) / ret)
			x.buyQtySumPos = append(x.buyQtySumPos, sumFloat(x.QtyTrade)/ ret)
			x.buyShareSumPos = append(x.buyShareSumPos, sumFloat(x.obfindShareBid)/ ret)

			x.sellOidCountPos = append(x.sellOidCountPos, float64(len(sellOids))/ ret)
			x.sellQtySumPos = append(x.sellQtySumPos, sumFloat(x.QtyTrade)/ ret)
			x.sellShareSumPos = append(x.sellShareSumPos, sumFloat(x.obfindShareAsk)/ ret)
		} 
		if ret < 0 {
			retdiv := -ret
			// 收益下跌超 0.5%
			buyOids := make(map[int]struct{})
			for _, oid := range x.BidOidList {
				buyOids[oid] = struct{}{}
			}
			sellOids := make(map[int]struct{})
			for _, oid := range x.AskOidList {
				sellOids[oid] = struct{}{}
			}

			x.buyOidCountNeg = append(x.buyOidCountNeg, float64(len(buyOids)) / retdiv)
			x.buyQtySumNeg = append(x.buyQtySumNeg, sumFloat(x.QtyTrade)/ retdiv)
			x.buyShareSumNeg = append(x.buyShareSumNeg, sumFloat(x.obfindShareBid) / retdiv)

			x.sellOidCountNeg = append(x.sellOidCountNeg, float64(len(sellOids)) / retdiv)
			x.sellQtySumNeg = append(x.sellQtySumNeg, sumFloat(x.QtyTrade) / retdiv)
			x.sellShareSumNeg = append(x.sellShareSumNeg, sumFloat(x.obfindShareAsk) / retdiv)
		}
		x.QtyTrade = x.QtyTrade[:0]
		x.AskOidList = x.AskOidList[:0]
		x.BidOidList = x.BidOidList[:0]
		x.obfindShareAsk = x.obfindShareAsk[:0]
		x.obfindShareBid = x.obfindShareBid[:0]
		x.MidPrice      = x.MidPrice[:0]
	}
}

func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {


	x.QtyTrade = append(x.QtyTrade, msg.Qty)
	x.AskOidList = append(x.AskOidList, msg.AskOid)
	x.BidOidList = append(x.BidOidList, msg.BidOid)
	
	// 获取挂单量
	orderAsk := x.ob.FindOrder(msg.AskOid, bookmsg.SellSide)
	orderBid := x.ob.FindOrder(msg.BidOid, bookmsg.BuySide)
	var shareAsk, shareBid float64
	if orderAsk != nil {
		shareAsk = orderAsk.Shares()
	}
	if orderBid != nil {
		shareBid = orderBid.Shares()
	}
	x.obfindShareAsk = append(x.obfindShareAsk, shareAsk)
	x.obfindShareBid = append(x.obfindShareBid, shareBid)

}

func sumFloat(arr []float64) float64 {
	var s float64
	for _, v := range arr {
		s += v
	}
	return s
}

func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	if len(x.buyOidCountPos) > 0 {
		x.outs[0] = sumFloat(x.buyOidCountPos)
		x.outs[1] = sumFloat(x.buyQtySumPos)
		x.outs[2] = sumFloat(x.buyShareSumPos)
		x.outs[3] = sumFloat(x.sellOidCountPos)
		x.outs[4] = sumFloat(x.sellQtySumPos)
		x.outs[5] = sumFloat(x.sellShareSumPos)
	}
	if len(x.buyOidCountNeg) > 0 {
		x.outs[6] = sumFloat(x.buyOidCountNeg)
		x.outs[7] = sumFloat(x.buyQtySumNeg)
		x.outs[8] = sumFloat(x.buyShareSumNeg)
		x.outs[9] = sumFloat(x.sellOidCountNeg)
		x.outs[10] = sumFloat(x.sellQtySumNeg)
		x.outs[11] = sumFloat(x.sellShareSumNeg)
	}

	copy(out, x.outs)


	// 清空
	x.outs = make([]float64, 12)
	x.buyOidCountPos = x.buyOidCountPos[:0]
	x.buyQtySumPos = x.buyQtySumPos[:0]
	x.buyShareSumPos = x.buyShareSumPos[:0]
	x.sellOidCountPos = x.sellOidCountPos[:0]
	x.sellQtySumPos = x.sellQtySumPos[:0]
	x.sellShareSumPos = x.sellShareSumPos[:0]

	x.buyOidCountNeg = x.buyOidCountNeg[:0]
	x.buyQtySumNeg = x.buyQtySumNeg[:0]
	x.buyShareSumNeg = x.buyShareSumNeg[:0]
	x.sellOidCountNeg = x.sellOidCountNeg[:0]
	x.sellQtySumNeg = x.sellQtySumNeg[:0]
	x.sellShareSumNeg = x.sellShareSumNeg[:0]
}


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
