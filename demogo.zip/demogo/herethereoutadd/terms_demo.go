package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	_ "fmt"
	"math"
)

type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book

	// 中间变量
	Bid2to6Vols []float64
	Ask2to6Vols []float64
	BookEpochs  []float64

	// 每个挂单记录
	AddQtys        []float64
	AddPrcs        []float64
	AddIsBuy       []bool
	AddBid2to6Vols []float64
	AddAsk2to6Vols []float64
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:  base.New(cfg, sid),
		names: []string{"SellAggQtyTop30%", "SellAggAvgPrcTop30%", "BuyAggQtyTop30%", "BuyAggAvgPrcTop30%"},
		outs:  make([]float64, 13),

		Bid2to6Vols:     []float64{},
		Ask2to6Vols:     []float64{},
		BookEpochs:      []float64{},
		AddQtys:         []float64{},
		AddPrcs:         []float64{},
		AddIsBuy:        []bool{},
		AddBid2to6Vols:  []float64{},
		AddAsk2to6Vols:  []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################


func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {

}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}



func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	x.MidPrice = append(x.MidPrice, msg.SrcEpoch)	// 保持不变，为了填充市价单的价格
	x.BookEpochs = append(x.BookEpochs, msg.SrcEpoch)
	// 记录每个msg.CumVol , 增加到list:x.CumVOlall中
	// 如果列表长度大于20了 计算 成交价格的ret20, 计算并记录这20snap的成交量 x.volsum20 =append(x.volsum20,  x.CumVOlall[n-1] - x.CumVolall[n-20]），计算增加ret20/volsum20到list: x.retvolsnap中
}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	// 保持不变，为了填充市价单的价格
	n := len(x.MidPrice)
	if n == 0 {
		return
	}
	if (msg.OrdType != 0) && (msg.Prc <= 0) {
		if msg.Side == 1 {
			msg.Prc = x.MidPrice[n-1] * 1.05
		} else {
			msg.Prc = x.MidPrice[n-1] * 0.95
		}		
	}

	// 分别记录买/卖挂单量，挂单价格，并记录最近一个时刻的x.retvolsnap[n-1]

}

func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	// 任务1：筛选出x.volsum20在整个区间中低于30分位数的样本，统计这些样本的卖/买挂单量，买卖挂单金额， 买卖挂单平均价格， 筛选出x.volsum20在整个区间中高于70分位数的样本，统计这些样本的卖/买挂单量，买卖挂单金额， 买卖挂单平均价格
	// 任务2：筛选出x.retvolsnap , 在整个区间中低于30分位数且小于0的样本（记为无量下跌）， 统计这些样本的卖/买挂单量，买卖挂单金额， 买卖挂单平均价格
	// 任务3：筛选出ret25/volsum25, 在整个区间中高于70分位数且大于0的样本（记为无量上涨）， ，统计这些样本的卖/买挂单量，买卖挂单金额， 买卖挂单平均价格


	copy(out, x.outs)


	// 初始化
	x.outs = make([]float64, 10)
	x.Ask2to6Vols = x.Ask2to6Vols[:0]
	x.BookEpochs = x.BookEpochs[:0]
}


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
