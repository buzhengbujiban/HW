package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"time"
	"sort"
)

type TermDemo struct {
	*base.Base

	names     []string // names of the fields
	outs      []float64
	MidPrice  []float64
	strsecB   map[int]int
	strsecS   map[int]int
	strsecQtyB map[int]float64
	strsecQtyS map[int]float64
	strsecPrcB map[int][]float64
	strsecPrcS map[int][]float64

	QmodnumB  map[int]int
	QmodnumS  map[int]int
	QmodQtyB  map[int]float64
	QmodQtyS  map[int]float64
	QmodPrcB  map[int][]float64
	QmodPrcS  map[int][]float64

	priceStats map[string]float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names:     []string{"maxhist20Interval_B_Qty", "maxhist20Interval_S_Qty","maxhist20Interval_B_Prc","maxhist20Interval_S_Prc",
							"maxhistQtyMod_B_Qty", "maxhistQtyMod_S_Qty","maxhistQtyMod_B_Prc","maxhistQtyMod_S_Prc" , "allQrt"},
		outs:      make([]float64, 9),
		MidPrice: make([]float64, 10),
		strsecB:  make(map[int]int),
		strsecS:  make(map[int]int),
		QmodnumB: make(map[int]int),
		QmodnumS: make(map[int]int),

		// 初始化 int 到 float64 的 map
		strsecQtyB: make(map[int]float64),
		strsecQtyS: make(map[int]float64),
		QmodQtyB:   make(map[int]float64),
		QmodQtyS:   make(map[int]float64),

		// 初始化 int 到 []float64 的 map
		strsecPrcB: make(map[int][]float64),
		strsecPrcS: make(map[int][]float64),
		QmodPrcB:   make(map[int][]float64),
		QmodPrcS:   make(map[int][]float64),
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}


// On Msg Update ###################################################################
func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	x.MidPrice  = append(x.MidPrice, msg.GetMidPrice())
}

func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}

func topKInt(m map[int]int, kmax int) []int {
	type kv struct {
		Key   int
		Value int
	}
	var ss []kv
	for k, v := range m {
		ss = append(ss, kv{k, v})
	}
	sort.Slice(ss, func(i, j int) bool {
		return ss[i].Value > ss[j].Value
	})
	var result []int
	for i := 0; i < kmax && i < len(ss); i++ {
		result = append(result, ss[i].Key)
	}
	return result
}

// OnOBAddMsg 每当有挂单到来时触发
func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {

	// 采用 Unix 时间提取秒数
	n := len(x.MidPrice)
	if n == 0 {
		return
	}


	if (msg.OrdType != 0) && (msg.Prc <= 0) {
		if msg.Side == 1 {
			msg.Prc = x.MidPrice[n-1] * 1.05
		} else {
			msg.Prc = x.MidPrice[n-1] * 0.95
		}		
	}


	Mod := 3700
	sec := int(time.Unix(int64(msg.SrcEpoch), 0).Second())

	// 如果是买单
	if msg.Side == bookmsg.BuySide {
		x.strsecB[sec]++                      // 记录次数
		x.strsecQtyB[sec] += msg.Qty           // 累计数量
		x.strsecPrcB[sec] = append(x.strsecPrcB[sec], msg.Prc) // 保存价格

		// 取模统计：先将数量转换为整数再取模（根据实际情况数量可能需要转换）
		modAns := int(msg.Qty) % Mod
		x.QmodnumB[modAns]++                      // 次数
		x.QmodQtyB[modAns] += msg.Qty             // 数量累计
		x.QmodPrcB[modAns] = append(x.QmodPrcB[modAns], msg.Prc)
	} else if msg.Side == bookmsg.SellSide {
		x.strsecS[sec]++ // 记录卖单出现次数
		x.strsecQtyS[sec] += msg.Qty
		x.strsecPrcS[sec] = append(x.strsecPrcS[sec], msg.Prc)

		modAns := int(msg.Qty) % Mod
		x.QmodnumS[modAns]++
		x.QmodQtyS[modAns] += msg.Qty
		x.QmodPrcS[modAns] = append(x.QmodPrcS[modAns], msg.Prc) 
	}
	
	x.outs[8] += msg.Qty
	// // 保存所有订单，用于第三个任务的成交量统计（无论买卖）
	// x.orders = append(x.orders, *msg)
}






// On Snap ###################################################################
// 这个函数用于在每5min的开头，计算过去5min的值的聚合操作
func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	// ===== Part 1: 高频秒点分析（前20个秒）
	topSecs := topKInt(x.strsecB, 20)

	var totalQtyB float64
	var totalPrcB float64
	var countB int
	for _, sec := range topSecs {
		totalQtyB += x.strsecQtyB[sec]
		for _, p := range x.strsecPrcB[sec] {
			totalPrcB += p
			countB++
		}
	}
	avgPrcB := totalPrcB / float64(countB)

	topSecsS := topKInt(x.strsecS, 20)
	var totalQtyS float64
	var totalPrcS float64
	var countS int
	for _, sec := range topSecsS {
		totalQtyS += x.strsecQtyS[sec]
		for _, p := range x.strsecPrcS[sec] {
			totalPrcS += p
			countS++
		}
	}
	avgPrcS := totalPrcS / float64(countS)

	x.outs[0] = totalQtyB
	x.outs[1] = totalQtyS
	x.outs[2] = avgPrcB
	x.outs[3] = avgPrcS

	// ===== Part 2: 成交量 modans 分析，买入和卖出分别处理
	// 买入部分
	type modPair struct {
		mod int
		cnt int
	}
	var modPairsB []modPair
	for k, v := range x.QmodnumB {
		modPairsB = append(modPairsB, modPair{mod: k, cnt: v})
	}
	sort.Slice(modPairsB, func(i, j int) bool {
		return modPairsB[i].cnt > modPairsB[j].cnt
	})
	Nb := int(float64(len(modPairsB)) * 0.35)
	var sumQtyB float64
	var sumPrcB float64
	var prcCntB int
	for i := 0; i < Nb && i < len(modPairsB); i++ {
		mod := modPairsB[i].mod
		sumQtyB += x.QmodQtyB[mod]
		for _, prc := range x.QmodPrcB[mod] {
			sumPrcB += prc
			prcCntB++
		}
	}
	var avgPrcB2 float64
	if prcCntB > 0 {
		avgPrcB2 = sumPrcB / float64(prcCntB)
	}
	x.outs[4] = sumQtyB
	x.outs[6] = avgPrcB2

	// 卖出部分
	var modPairsS []modPair
	for k, v := range x.QmodnumS {
		modPairsS = append(modPairsS, modPair{mod: k, cnt: v})
	}
	sort.Slice(modPairsS, func(i, j int) bool {
		return modPairsS[i].cnt > modPairsS[j].cnt
	})
	Ns := int(float64(len(modPairsS)) * 0.3)
	var sumQtyS float64
	var sumPrcS float64
	var prcCntS int
	for i := 0; i < Ns && i < len(modPairsS); i++ {
		mod := modPairsS[i].mod
		sumQtyS += x.QmodQtyS[mod]
		for _, prc := range x.QmodPrcS[mod] {
			sumPrcS += prc
			prcCntS++
		}
	}
	var avgPrcS2 float64
	if prcCntS > 0 {
		avgPrcS2 = sumPrcS / float64(prcCntS)
	}
	x.outs[5] = sumQtyS
	x.outs[7] = avgPrcS2
	

	copy(out, x.outs)

	// fmt.Println("-------", x.outs)
	// reset for next round
	// 清空 Part 1 用到的字典
	x.outs = make([]float64, 9)
	x.strsecB = make(map[int]int)
	x.strsecS = make(map[int]int)
	x.strsecQtyB = make(map[int]float64)
	x.strsecQtyS = make(map[int]float64)
	x.strsecPrcB = make(map[int][]float64)
	x.strsecPrcS = make(map[int][]float64)

	// 清空 Part 2 用到的 mod 分布字典
	x.QmodnumB = make(map[int]int)
	x.QmodnumS = make(map[int]int)
	x.QmodQtyB = make(map[int]float64)
	x.QmodQtyS = make(map[int]float64)
	x.QmodPrcB = make(map[int][]float64)
	x.QmodPrcS = make(map[int][]float64)
}




// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
