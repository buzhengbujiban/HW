package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"fmt"
	"time"

	"math"
)

type TermDemo struct {
	*base.Base

	names     []string // names of the fields
	outs      []float64

	Ask1Price []float64
	Bid1Price []float64
	Timeepoch []float64
	Prcsum2S  []float64
	Prcsum2B  []float64
	PrcQsum2B []float64
	PrcQsum2S []float64
	MidPrice  []float64
	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names:     []string{"allQrt", "OutAggres_S_Qty", "MidAggres_S_Qty","OutAggres_B_Qty", "MidAggres_B_Qty", "OutAggres_S_Prc", "OutAggres_B_Prc", 
		"OutAggres_S_WavgPrc", "OutAggres_B_WavgPrc"},

		outs:      make([]float64, 10),
		// Timeepoch: []string{},
		// PrcsumS:   []float64{},
		// PrcsumB:   []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// FormatUnixTimestampTime 将 float64 类型的 Unix 时间戳转换为格式化的时间字符串（%H:%M:%S.%f）
func FormatUnixTimestampTime(timestamp float64) string {
    sec := int64(timestamp)
    nsec := int64((timestamp - float64(sec)) * 1e9)
    t := time.Unix(sec, nsec).Local()
    return fmt.Sprintf("%02d:%02d:%02d.%06d", t.Hour(), t.Minute(), t.Second(), t.Nanosecond()/1000)
}

func meanNanIgnore(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	count := 0
	for _, val := range arr {
		if !math.IsNaN(val) {
			sum += val
			count++
		}
	}
	if count == 0 {
		return 0 // or return math.NaN() if you prefer
	}
	return sum / float64(count)
}

// On Msg Update ###################################################################
func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	x.Timeepoch = append(x.Timeepoch, msg.SrcEpoch)
	x.Ask1Price = append(x.Ask1Price, msg.GetAsk(0))
	x.Bid1Price = append(x.Bid1Price, msg.GetBid(0))
	x.MidPrice  = append(x.MidPrice, msg.GetMidPrice())
}

func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	n := len(x.MidPrice)
	if n == 0 {
		return
	}

	if (msg.OrdType != 0) && (msg.Prc <= 0) {
		if msg.Side == 1 {
			msg.Prc = x.MidPrice[n-1] * 1.05
		} else {
			msg.Prc = x.MidPrice[n-1] * 0.95
		}		
	}


	x.outs[0] += msg.Qty



	if (msg.Side == -1) {
		if (msg.Prc<=x.Bid1Price[n-1]) {
			x.outs[1] += msg.Qty
			x.Prcsum2S = append(x.Prcsum2S, msg.Prc)
			x.PrcQsum2S = append(x.PrcQsum2S, msg.Prc * msg.Qty)
		}
		if (msg.Prc<x.Ask1Price[n-1]) && (msg.Prc>=x.Bid1Price[n-1]){
			x.outs[2] += msg.Qty
		}
	}
	if (msg.Side == 1) {
		if (msg.Prc>=x.Ask1Price[n-1]) {
			x.outs[3] += msg.Qty
			x.Prcsum2B = append(x.Prcsum2B, msg.Prc)
			x.PrcQsum2B = append(x.PrcQsum2B, msg.Prc * msg.Qty)
		}
		if (msg.Prc>x.Bid1Price[n-1]) && (msg.Prc<=x.Ask1Price[n-1]){
			x.outs[4] += msg.Qty
		}
	} 


}

// On Snap ###################################################################
func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	

	x.outs[5] = meanNanIgnore(x.Prcsum2S)
	x.outs[6] = meanNanIgnore(x.Prcsum2B)
	x.outs[7] = meanNanIgnore(x.PrcQsum2S) / x.outs[2]
	x.outs[8] = meanNanIgnore(x.PrcQsum2B) / x.outs[3]
	copy(out, x.outs)
	// fmt.Println("-------", x.outs)

	x.outs = make([]float64, 10)
	x.Prcsum2S = x.Prcsum2S[:0]
	x.Prcsum2B = x.Prcsum2B[:0]
	x.PrcQsum2B = x.PrcQsum2B[:0]
	x.PrcQsum2S = x.PrcQsum2S[:0]

}


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
