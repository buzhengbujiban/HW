package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"fmt"
	"base/orderbook/cneq"
	"time"
	"sort"
	"math"
)


// type OrderRecord struct {
// 	Sid      int
// 	OurEpoch float64
// 	SrcEpoch float64
// 	Oid     int
// 	Prc     float64
// 	Qty     float64
// 	OrdType OrdType
// 	Side    BookSide
// }



type TermDemo struct {
	*base.Base

	names []string // names of the fields
	outs  []float64

	Oidlist []float64
	passiveSellShare []float64
	passiveSellDelay []float64
	passiveSellRatio []float64


	passiveBuyShare []float64
	passiveBuyDelay []float64
	passiveBuyRatio []float64
	
	activeSellOid []int
	activeBuyOid []int

	actOidmapQty map[int]float64

	Oidmax int
	

	isSH bool
	isSZ bool


	ob ob.IOrderBook // 自建book
}


func init() {
	cneq.UNCORSSING_ON_ADD = false // 关闭 orderbook 在 SZ 主动 add 来到时，自动uncross的功能
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base: base.New(cfg, sid),
		actOidmapQty: make(map[int]float64),
	}

	// r.names = cfg.GetListOfStringX("names")
	// r.outs = make([]float64, len(r.names))
	ret.names = []string{   
		"Mean_passiveBuyDelay",
		"Mean_passiveSellDelay",
		"Mean_passiveBuyRatio",
		"Mean_passiveSellRatio",
		"Std_passiveBuyDelay",
		"Std_passiveSellDelay",
		"Std_passiveBuyRatio",
		"Std_passiveSellRatio",
		"float64_len_passiveBuyDelay",
		"float64_len_passiveSellDelay",
		"Sum_filteractSelldelayl_lastQ",
		"Sum_filterpasBuydelayl_lastQ",
		"Sum_filteractSellRatiosl_lastQ",
		"Sum_filterpasBuyRatiosl_lastQ",
		"Sum_filteractBuydelayl_lastQ",
		"Sum_filterpasSelldelayl_lastQ",
		"Sum_filteractBuyRatiosl_lastQ",
		"Sum_filterpasSellRatiosl_lastQ",
		"Sum_filteractSellRatios1_lastQ",
		"Sum_filteractBuyRatios1_lastQ",
		"float64_len_filteractSellRatios1_lastQ",
		"float64_len_filteractBuyRatios1_lastQ",
		"Std_filteractSelldelayl_lastQ",
		"Std_filterpasBuydelayl_lastQ",
		"Std_filteractSellRatiosl_lastQ",
		"Std_filterpasBuyRatiosl_lastQ",
		"Std_filteractBuydelayl_lastQ",
		"Std_filterpasSelldelayl_lastQ",
		"Std_filteractBuyRatiosl_lastQ",
		"Std_filterpasSellRatiosl_lastQ",
		"Std_filteractSellRatios1_lastQ",
		"Std_filteractBuyRatios1_lastQ",
		"Qtyall_addreal",
		"Qtyall_trd",
		"Numall_addreal",
		"Numall_trd",
		}
	ret.outs = make([]float64, len(ret.names))

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH

	ret.ob = security.Lookup(sid).OrderBook()
	ret.ob.AddMsgHook(ret)
	ret.Oidmax = 0

	return ret
}

func (x *TermDemo) DataType() string { return "f64" }
func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################
func (x *TermDemo) OnOBAddPre(msg *bookmsg.OBAddMsg, orderPrice float64) {}
func (x *TermDemo) OnOBCancelPre(msg *bookmsg.OBCancelMsg)               {}


func FormatUnixTimestampTime(timestamp float64) string {
    sec := int64(timestamp)
    nsec := int64((timestamp - float64(sec)) * 1e9)
    t := time.Unix(sec, nsec).Local()
    return fmt.Sprintf("%02d:%02d:%02d.%06d", t.Hour(), t.Minute(), t.Second(), t.Nanosecond()/1000)
}



func (x *TermDemo) OnOBTradePre(msg *bookmsg.OBTradeMsg)                 {

	if x.isSH {
		tstring := FormatUnixTimestampTime(msg.SrcEpoch)
		if ((tstring<="14:59:58") && (tstring>="09:30:00")){
			x.outs[32] += msg.Qty
			x.outs[34]++
		}
	}
	x.outs[33] += msg.Qty
	x.outs[35]++


	if msg.Dir == bookmsg.DirBuy {

		OrderSell := x.ob.FindOrder(msg.AskOid, bookmsg.SellSide)
		if OrderSell!=nil {
			share := OrderSell.Shares()
			
			x.passiveSellShare = append(x.passiveSellShare, share)
			x.passiveSellDelay = append(x.passiveSellDelay, msg.SrcEpoch - OrderSell.SrcEpoch()) 
			x.passiveSellRatio = append(x.passiveSellRatio, msg.Qty / share) 
			
		}

		actOrderBuy := x.ob.FindOrder(msg.BidOid, bookmsg.BuySide)
		x.activeBuyOid = append(x.activeBuyOid, msg.BidOid)
		if actOrderBuy!=nil {
			x.actOidmapQty[msg.BidOid] = actOrderBuy.Shares()
		} else {
			x.actOidmapQty[msg.BidOid] += msg.Qty
		}

		x.Oidmax = msg.BidOid

	} else if msg.Dir == bookmsg.DirSell {
		OrderBuy := x.ob.FindOrder(msg.BidOid, bookmsg.BuySide)
		if OrderBuy!=nil {
			share := OrderBuy.Shares()
			
			x.passiveBuyShare = append(x.passiveBuyShare, share)
			x.passiveBuyDelay = append(x.passiveBuyDelay, msg.SrcEpoch - OrderBuy.SrcEpoch()) 
			x.passiveBuyRatio = append(x.passiveBuyRatio, msg.Qty / share) 
			
		}
		
		actOrderSell := x.ob.FindOrder(msg.AskOid, bookmsg.SellSide)
		x.activeSellOid = append(x.activeSellOid, msg.AskOid)
		if actOrderSell!=nil {
			x.actOidmapQty[msg.AskOid] = actOrderSell.Shares()
		} else {
			x.actOidmapQty[msg.AskOid] += msg.Qty
		}

		x.Oidmax = msg.AskOid
		


	} else {
		return
	}

}
func (x *TermDemo) OnOBReplacePre(msg *bookmsg.OBReplaceMsg)             {}
func (x *TermDemo) OnOBRebuildPre(msg *bookmsg.OBRebuildMsg)             {}
func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
}

// func FormatUnixTimestampTime(timestamp float64) string {
//     sec := int64(timestamp)
//     nsec := int64((timestamp - float64(sec)) * 1e9)
//     t := time.Unix(sec, nsec).Local()
//     return fmt.Sprintf("%02d:%02d:%02d.%06d", t.Hour(), t.Minute(), t.Second(), t.Nanosecond()/1000)
// }


func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	
	// tstring := FormatUnixTimestampTime(msg.SrcEpoch)
	// if (x.isSH) && ((tstring<="14:59:58") && (tstring>="09:30:00")){
	// 	if (msg.AskOid > msg.BidOid)  {
	// 		msgadd = OrderRecord{
	// 			Sid:       msg.Sid,
	// 			OurEpoch:  msg.OurEpoch,
	// 			SrcEpoch:  msg.SrcEpoch,
	// 			Oid:       msg.AskOid,
	// 			Prc:       msg.Prc,
	// 			Qty:       msg.Qty,
	// 			OrdType:   OrdType.LimitOrder,
	// 			Side:      -1,
	// 		}
	// 	}
	// 	if (msg.AskOid < msg.BidOid) {
	// 		msgaddS = OrderRecord{
	// 			Sid:       msg.Sid,
	// 			OurEpoch:  msg.OurEpoch,
	// 			SrcEpoch:  msg.SrcEpoch,
	// 			Oid:       msg.BidOid,
	// 			Prc:       msg.Prc,
	// 			Qty:       msg.Qty,
	// 			OrdType:   OrdType.LimitOrder,
	// 			Side:      1,
	// 		}
	// 	}
	// 	// follow AddMsg +
	// }
}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {

	if x.isSH && (msg.Oid == x.Oidmax) {
		x.actOidmapQty[msg.Oid] += msg.Qty
	} 
	x.outs[32] += msg.Qty
	x.outs[34]++
}

// On Snap ###################################################################
func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {

	var p70delays, p70Ratios float64
	var filteractSelldelayl_lastQ, filterpasBuydelayl_lastQ, filteractSellRatiosl_lastQ, filterpasBuyRatiosl_lastQ, filteractSellRatios1_lastQ []float64
	var filteractBuydelayl_lastQ, filterpasSelldelayl_lastQ, filteractBuyRatiosl_lastQ, filterpasSellRatiosl_lastQ, filteractBuyRatios1_lastQ []float64



	x.outs[0] = Mean(x.passiveBuyDelay)
	x.outs[1] = Mean(x.passiveSellDelay)

	x.outs[2] = Mean(x.passiveBuyRatio)
	x.outs[3] = Mean(x.passiveSellRatio)

	x.outs[4] = Std(x.passiveBuyDelay)
	x.outs[5] = Std(x.passiveSellDelay)

	x.outs[6] = Std(x.passiveBuyRatio)
	x.outs[7] = Std(x.passiveSellRatio)


	x.outs[8] = float64(len(x.passiveBuyDelay))
	x.outs[9] = float64(len(x.passiveSellDelay))






	sortedDelayBuy := append([]float64{}, x.passiveBuyDelay...)
	sort.Float64s(sortedDelayBuy)
	sortedRatioBuy := append([]float64{}, x.passiveBuyRatio...)
	sort.Float64s(sortedRatioBuy)

	DelayCountBuy := len(sortedDelayBuy)
	if DelayCountBuy>=5 {
		p70delays = sortedDelayBuy[DelayCountBuy*65/100]
		p70Ratios = sortedRatioBuy[DelayCountBuy*60/100]
	
		for i := 0; i < DelayCountBuy; i++ {
			if x.passiveBuyDelay[i] > p70delays{
				filteractSelldelayl_lastQ = append(filteractSelldelayl_lastQ, x.actOidmapQty[x.activeSellOid[i]])
				filterpasBuydelayl_lastQ = append(filterpasBuydelayl_lastQ, x.passiveBuyShare[i])
			}

			if x.passiveBuyRatio[i] > p70Ratios{
				filteractSellRatiosl_lastQ = append(filteractSellRatiosl_lastQ, x.actOidmapQty[x.activeSellOid[i]])
				filterpasBuyRatiosl_lastQ = append(filterpasBuyRatiosl_lastQ, x.passiveBuyShare[i])
			}

			if x.passiveBuyRatio[i] >= 1.0{
				filteractSellRatios1_lastQ = append(filteractSellRatios1_lastQ, x.actOidmapQty[x.activeSellOid[i]])
			}

		}
	}




	sortedDelaySell := append([]float64{}, x.passiveSellDelay...)
	sort.Float64s(sortedDelaySell)
	sortedRatioSell := append([]float64{}, x.passiveSellRatio...)
	sort.Float64s(sortedRatioSell)

	DelayCountSell := len(sortedDelaySell)
	if DelayCountSell>=5 {
		p70delays = sortedDelaySell[DelayCountSell*65/100]
		p70Ratios = sortedRatioSell[DelayCountSell*60/100]
	
		for i := 0; i < DelayCountSell; i++ {
			if x.passiveSellDelay[i] > p70delays{
				filteractBuydelayl_lastQ = append(filteractBuydelayl_lastQ, x.actOidmapQty[x.activeBuyOid[i]])
				filterpasSelldelayl_lastQ = append(filterpasSelldelayl_lastQ, x.passiveSellShare[i])
			}

			if x.passiveSellRatio[i] > p70Ratios{
				filteractBuyRatiosl_lastQ = append(filteractBuyRatiosl_lastQ, x.actOidmapQty[x.activeBuyOid[i]])
				filterpasSellRatiosl_lastQ = append(filterpasSellRatiosl_lastQ, x.passiveSellShare[i])
			}

			if x.passiveSellRatio[i] >= 1.0{
				filteractBuyRatios1_lastQ = append(filteractBuyRatios1_lastQ, x.actOidmapQty[x.activeBuyOid[i]])
			}

		}
	}






	x.outs[10] = Sum(filteractSelldelayl_lastQ)
	x.outs[11] = Sum(filterpasBuydelayl_lastQ)

	x.outs[12] = Sum(filteractSellRatiosl_lastQ)
	x.outs[13] = Sum(filterpasBuyRatiosl_lastQ)
	
	x.outs[14] = Sum(filteractBuydelayl_lastQ)
	x.outs[15] = Sum(filterpasSelldelayl_lastQ)

	x.outs[16] = Sum(filteractBuyRatiosl_lastQ)
	x.outs[17] = Sum(filterpasSellRatiosl_lastQ)

	x.outs[18] = Sum(filteractSellRatios1_lastQ)
	x.outs[19] = Sum(filteractBuyRatios1_lastQ)


	x.outs[20] = float64(len(filteractSellRatios1_lastQ))
	x.outs[21] = float64(len(filteractBuyRatios1_lastQ))


	x.outs[22] = Std(filteractSelldelayl_lastQ)
	x.outs[23] = Std(filterpasBuydelayl_lastQ)

	x.outs[24] = Std(filteractSellRatiosl_lastQ)
	x.outs[25] = Std(filterpasBuyRatiosl_lastQ)
	
	x.outs[26] = Std(filteractBuydelayl_lastQ)
	x.outs[27] = Std(filterpasSelldelayl_lastQ)

	x.outs[28] = Std(filteractBuyRatiosl_lastQ)
	x.outs[29] = Std(filterpasSellRatiosl_lastQ)

	x.outs[30] = Std(filteractSellRatios1_lastQ)
	x.outs[31] = Std(filteractBuyRatios1_lastQ)




	copy(out, x.outs)
	x.outs = make([]float64, 36)
	// x.addBuyRecords = make(map[int]OrderRecord)
	// x.addSellRecords = make(map[int]OrderRecord)
	x.passiveSellShare = x.passiveSellShare[:0]
	x.passiveSellDelay = x.passiveSellDelay[:0]
	x.passiveSellRatio = x.passiveSellRatio[:0]

	x.passiveBuyShare = x.passiveBuyShare[:0]
	x.passiveBuyDelay = x.passiveBuyDelay[:0]
	x.passiveBuyRatio = x.passiveBuyRatio[:0]

	x.activeSellOid = x.activeSellOid[:0]
	x.activeBuyOid = x.activeBuyOid[:0]

	x.actOidmapQty = make(map[int]float64)

}








func Sum(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	for _, v := range arr {
		sum += v
	}
	return sum 
}



func Mean(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	for _, v := range arr {
		sum += v
	}
	return sum / float64(len(arr))
}


func Std(arr []float64) float64 {
	valid := make([]float64, 0, len(arr))
	for _, v := range arr {
		if !math.IsNaN(v) {
			valid = append(valid, v)
		}
	}
	n := len(valid)
	if n < 3 {
		return 0
	}
	mean := Mean(valid)
	var sum float64
	for _, v := range valid {
		sum += (v - mean) * (v - mean)
	}
	return math.Sqrt(sum / float64(n-1)) // 样本标准差
}




// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm { return New(cfg, sid) })
}
