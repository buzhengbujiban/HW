package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"



)

type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook
	// 成交滑窗记录
	PrcTrade         []float64
	QtyTrade         []float64
	AskOidList       []int
	BidOidList       []int
	obfindShareAsk   []float64
	obfindShareBid   []float64

	// 统计ret60>0.005和<0.005时的买卖指标累积
	buyOidCountPos   []float64
	buyQtySumPos     []float64
	buyShareSumPos   []float64
	sellOidCountPos  []float64
	sellQtySumPos    []float64
	sellShareSumPos  []float64

	buyOidCountNeg   []float64
	buyQtySumNeg     []float64
	buyShareSumNeg   []float64
	sellOidCountNeg  []float64
	sellQtySumNeg    []float64
	sellShareSumNeg  []float64
}
func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names: []string{
			"buyOidCountPos", "buyQtySumPos", "buyShareSumPos",
			"sellOidCountPos", "sellQtySumPos", "sellShareSumPos",
			"buyOidCountNeg", "buyQtySumNeg", "buyShareSumNeg",
			"sellOidCountNeg", "sellQtySumNeg", "sellShareSumNeg",
		},
		outs:            make([]float64, 12),

		PrcTrade:        make([]float64, 0, 201),
		QtyTrade:        make([]float64, 0, 201),
		AskOidList:      make([]int, 0, 201),
		BidOidList:      make([]int, 0, 201),
		obfindShareAsk:  make([]float64, 0, 201),
		obfindShareBid:  make([]float64, 0, 201),
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}
//不变
func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}
//不变

// On Msg Update ###################################################################
func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
}

func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	// 添加滑窗
	x.PrcTrade = append(x.PrcTrade, msg.Prc)
	x.QtyTrade = append(x.QtyTrade, msg.Qty)
	x.AskOidList = append(x.AskOidList, msg.AskOid)
	x.BidOidList = append(x.BidOidList, msg.BidOid)

	// 获取挂单量
	orderAsk := x.ob.FindOrder(msg.AskOid, bookmsg.SellSide)
	orderBid := x.ob.FindOrder(msg.BidOid, bookmsg.BuySide)
	var shareAsk, shareBid float64
	if orderAsk != nil {
		shareAsk = orderAsk.Shares()
	}
	if orderBid != nil {
		shareBid = orderBid.Shares()
	}
	x.obfindShareAsk = append(x.obfindShareAsk, shareAsk)
	x.obfindShareBid = append(x.obfindShareBid, shareBid)

	// 滑窗满 201 条，计算 ret60
	if len(x.PrcTrade) >= 201 {
		n := len(x.PrcTrade)
		ret60 := x.PrcTrade[n-1]/x.PrcTrade[n-201] - 1


		if ret60 > 0.002 {
			// print(ret60>0.005, "---------------")
			// 收益上涨超 0.5%
			buyOids := make(map[int]struct{})
			for _, oid := range x.BidOidList[n-201:] {
				buyOids[oid] = struct{}{}
			}
			sellOids := make(map[int]struct{})
			for _, oid := range x.AskOidList[n-201:] {
				sellOids[oid] = struct{}{}
			}

			x.buyOidCountPos = append(x.buyOidCountPos, float64(len(buyOids)))
			x.buyQtySumPos = append(x.buyQtySumPos, sumFloat(x.QtyTrade[n-201:]))
			x.buyShareSumPos = append(x.buyShareSumPos, sumFloat(x.obfindShareBid[n-201:]))

			x.sellOidCountPos = append(x.sellOidCountPos, float64(len(sellOids)))
			x.sellQtySumPos = append(x.sellQtySumPos, sumFloat(x.QtyTrade[n-201:]))
			x.sellShareSumPos = append(x.sellShareSumPos, sumFloat(x.obfindShareAsk[n-201:]))
		} else if ret60 < -0.002 {
			// 收益下跌超 0.5%
			buyOids := make(map[int]struct{})
			for _, oid := range x.BidOidList[n-201:] {
				buyOids[oid] = struct{}{}
			}
			sellOids := make(map[int]struct{})
			for _, oid := range x.AskOidList[n-201:] {
				sellOids[oid] = struct{}{}
			}

			x.buyOidCountNeg = append(x.buyOidCountNeg, float64(len(buyOids)))
			x.buyQtySumNeg = append(x.buyQtySumNeg, sumFloat(x.QtyTrade[n-201:]))
			x.buyShareSumNeg = append(x.buyShareSumNeg, sumFloat(x.obfindShareBid[n-201:]))

			x.sellOidCountNeg = append(x.sellOidCountNeg, float64(len(sellOids)))
			x.sellQtySumNeg = append(x.sellQtySumNeg, sumFloat(x.QtyTrade[n-201:]))
			x.sellShareSumNeg = append(x.sellShareSumNeg, sumFloat(x.obfindShareAsk[n-201:]))
		}

		// 控制滑窗长度为 201
		x.PrcTrade = x.PrcTrade[1:]
		x.QtyTrade = x.QtyTrade[1:]
		x.AskOidList = x.AskOidList[1:]
		x.BidOidList = x.BidOidList[1:]
		x.obfindShareAsk = x.obfindShareAsk[1:]
		x.obfindShareBid = x.obfindShareBid[1:]
	}
}

func sumFloat(arr []float64) float64 {
	var s float64
	for _, v := range arr {
		s += v
	}
	return s
}

func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	if len(x.buyOidCountPos) > 0 {
		x.outs[0] = mean(x.buyOidCountPos)
		x.outs[1] = mean(x.buyQtySumPos)
		x.outs[2] = mean(x.buyShareSumPos)
		x.outs[3] = mean(x.sellOidCountPos)
		x.outs[4] = mean(x.sellQtySumPos)
		x.outs[5] = mean(x.sellShareSumPos)
	}
	if len(x.buyOidCountNeg) > 0 {
		x.outs[6] = mean(x.buyOidCountNeg)
		x.outs[7] = mean(x.buyQtySumNeg)
		x.outs[8] = mean(x.buyShareSumNeg)
		x.outs[9] = mean(x.sellOidCountNeg)
		x.outs[10] = mean(x.sellQtySumNeg)
		x.outs[11] = mean(x.sellShareSumNeg)
	}

	copy(out, x.outs)


	// 清空
	x.outs = make([]float64, 12)
	x.buyOidCountPos = x.buyOidCountPos[:0]
	x.buyQtySumPos = x.buyQtySumPos[:0]
	x.buyShareSumPos = x.buyShareSumPos[:0]
	x.sellOidCountPos = x.sellOidCountPos[:0]
	x.sellQtySumPos = x.sellQtySumPos[:0]
	x.sellShareSumPos = x.sellShareSumPos[:0]

	x.buyOidCountNeg = x.buyOidCountNeg[:0]
	x.buyQtySumNeg = x.buyQtySumNeg[:0]
	x.buyShareSumNeg = x.buyShareSumNeg[:0]
	x.sellOidCountNeg = x.sellOidCountNeg[:0]
	x.sellQtySumNeg = x.sellQtySumNeg[:0]
	x.sellShareSumNeg = x.sellShareSumNeg[:0]
}

func mean(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	return sumFloat(arr) / float64(len(arr))
}
// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
