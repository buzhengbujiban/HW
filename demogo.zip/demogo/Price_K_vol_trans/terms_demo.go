package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	_ "fmt"
	"math"
)

type TermDemo struct {
	*base.Base

	names     []string // names of the fields
	outs      []float64
	// ========== 买方挂单相关 ==========
	TimeepochB      []float64 // 每个买单的时间戳
	DeltaTimeepochB []float64 // 相邻买单之间的时间间隔
	QtyB            []float64 // 对应每个买单的数量
	PrcB            []float64 // 对应每个买单的价格

	// ========== 卖方挂单相关 ==========
	TimeepochS      []float64 // 每个卖单的时间戳
	DeltaTimeepochS []float64 // 相邻卖单之间的时间间隔
	QtyS            []float64 // 对应每个卖单的数量
	PrcS            []float64 // 对应每个卖单的价格

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names:            []string{"dense_B_Qty", "dense_B_AvgPrc", "dense_S_Qty", "dense_S_AvgPrc", "All_B_Qty", "All_S_Qty"},
		outs:             make([]float64, 6),

		TimeepochB:      make([]float64, 0, 1000),
		DeltaTimeepochB: make([]float64, 0, 1000),
		QtyB:            make([]float64, 0, 1000),
		PrcB:            make([]float64, 0, 1000),

		TimeepochS:      make([]float64, 0, 1000),
		DeltaTimeepochS: make([]float64, 0, 1000),
		QtyS:            make([]float64, 0, 1000),
		PrcS:            make([]float64, 0, 1000),
		// MidPrice:  []float64{},
		// Timeepoch: []string{},
		// PrcsumS:   []float64{},
		// PrcsumB:   []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################
func Percentile(data []float64, percentile float64) float64 {
	if len(data) == 0 {
		return 0
	}
	sorted := make([]float64, len(data))
	copy(sorted, data)
	sort.Float64s(sorted)

	k := int(float64(len(sorted)-1) * percentile)
	return sorted[k]
}

// 记录必要的中间价格！和时间戳
func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {}

// 记录买卖订单的时间戳和订单量订单价格,以及距离这个单的时间戳最近的上一个MidPrice，最近的上一个msg.AskPrice(0) ()
func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	// 在这里记录逐笔成交的订单信息
}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {}




// On Snap ###################################################################
func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	// 定义当前区间的下影线价格区间，为当前1min 的min(open, close)~(low-0.02),   low=min(x.MidPrice), open=first(x.MidPrice), close=last(x.MidPrice), 请你帮我计算在这个下影线价格区间内, 成交笔数，成交量和成交均价
	// 定义当前区间的上影线价格区间，为当前1min 的(high+0.02)~max(open, close)，  high=max(x.MidPrice), open=first(x.MidPrice), close=last(x.MidPrice), 请你帮我计算在这个上影线价格区间内, 成交笔数，成交量和成交均价

	


	copy(out, x.outs)

	// 清空中间变量
	x.outs = make([]float64, 5)

	x.TimeepochB = x.TimeepochB[:0]
	x.DeltaTimeepochB = x.DeltaTimeepochB[:0]
	x.QtyB = x.QtyB[:0]
	x.PrcB = x.PrcB[:0]

	x.TimeepochS = x.TimeepochS[:0]
	x.DeltaTimeepochS = x.DeltaTimeepochS[:0]
	x.QtyS = x.QtyS[:0]
	x.PrcS = x.PrcS[:0]
}


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
