package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	_ "fmt"
	"math"
)

type TermDemo struct {
	*base.Base

	names     []string // names of the fields
	outs      []float64
	MidPrice  []float64
	Timeepoch []float64
	PrcsumS   []float64
	PrcsumB   []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names:     []string{"revtrend_add_S_Qty", "revtrend_add_B_Qty", "revtrend_add_S_Prcavg", "revtrend_add_B_Prcavg", "allQrt"},
		outs:      make([]float64, 5),
		// MidPrice:  []float64{},
		// Timeepoch: []string{},
		// PrcsumS:   []float64{},
		// PrcsumB:   []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################
func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	x.MidPrice = append(x.MidPrice, msg.GetMidPrice())
	x.Timeepoch = append(x.Timeepoch, msg.OurEpoch)
}

func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	n := len(x.MidPrice)
	// fmt.Println("---*--*--", x.MidPrice, n)
	if (n >= 21) {
		ret3s := x.MidPrice[n-1]/x.MidPrice[n-21] - 1.0
		if ret3s > 0 && msg.Side == -1 {
			x.outs[0] += float64(msg.Qty)
			x.PrcsumS = append(x.PrcsumS, msg.Prc)
		}

		if ret3s < 0 && msg.Side == 1 {
			x.outs[1] += float64(msg.Qty)
			x.PrcsumB = append(x.PrcsumB, msg.Prc)
		}
	}
	x.outs[4] += float64(msg.Qty)
}


func meanNanIgnore(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	count := 0
	for _, val := range arr {
		if !math.IsNaN(val) {
			sum += val
			count++
		}
	}
	if count == 0 {
		return 0 // or return math.NaN() if you prefer
	}
	return sum / float64(count)
}
// On Snap ###################################################################
func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	x.outs[2] = meanNanIgnore(x.PrcsumS)
	x.outs[3] = meanNanIgnore(x.PrcsumB)
	copy(out, x.outs)
	// fmt.Println("-------", x.outs)

	// reset for next round
	x.outs = make([]float64, 5)
	if ((len(x.PrcsumS)>40) && (len(x.PrcsumB)>=40)) {
		x.PrcsumS = x.PrcsumS[19:]
		x.PrcsumB = x.PrcsumB[19:]
	}
}


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
