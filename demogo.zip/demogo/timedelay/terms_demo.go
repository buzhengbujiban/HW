package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"math"
)



type OrderRecord struct {
	Qty      float64
	Prc      float64
	MidDist  float64
	Epoch    float64
	Timediff float64
}



type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook

	// 中间变量
	addBuyRecords  map[int]OrderRecord
	addSellRecords map[int]OrderRecord
	SellTime     []float64
	BuyTime      []float64

}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:  base.New(cfg, sid),
		names: []string{
			"adddisWQty_S_Qty", "addstddisWQty_S_Qty", "addstddis_S_dis", "addavgdis_S_dis", "add_Time20diff_S_avg",
			"adddisWQty_B_Qty", "addstddisWQty_B_Qty", "addstddis_B_dis", "addavgdis_B_dis", "add_Time20diff_B_avg",
			"add_Time20diff_BS_avg", "Qtyall_add", "QtyMean_S", "QtyStd_S", "QtyMean_B", "QtyStd_B", "SStdTimeDiff", "BStdTimeDiff",
		},
		outs:           make([]float64, 18),
		addBuyRecords:  make(map[int]OrderRecord),
		addSellRecords: make(map[int]OrderRecord),
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}



// 不同变这两个函数
func (x *TermDemo) DataType() string {
	return "f64"
}
func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################
func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {

}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}



func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {

}


func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	// 针对每一个挂单，首先记录该订单的挂单量，挂单价格
	// 计算 abs(挂单价格-最近一个时刻的MidPrice), 作为挂单"距离"
	// 针对每一个挂单事件，记录当前事件时间戳与20个事件之前的时间戳的差，记录在数组。
	Level0A := x.ob.Ask(0)
	Level0B := x.ob.Bid(0)
	if (Level0A == nil) || (Level0B == nil) {
		return
	}
	Midpricenow := (Level0A.Price() + Level0B.Price()) / 2
	if (msg.OrdType != 0) && ((msg.Prc <= 0) || (msg.Prc >= 9999))  {
		if msg.Side == 1 {
			msg.Prc = Midpricenow * 1.05
		} else {
			msg.Prc = Midpricenow * 0.95
		}		
	}




	var Timediff20, dist float64
	if msg.Side == bookmsg.BuySide {
		x.BuyTime = append(x.BuyTime, msg.SrcEpoch)
		nRecord := len(x.BuyTime)
		if nRecord >= 20 {
			Timediff20 = msg.SrcEpoch - x.BuyTime[nRecord-20]
			x.BuyTime = x.BuyTime[1:]
		} else {
			Timediff20 = 0.0
		}

		dist = Midpricenow - msg.Prc
		if dist<=0 {
			dist = 0
		}
		x.addBuyRecords[msg.Oid] = OrderRecord{
			Qty:      msg.Qty,
			Prc:      msg.Prc,
			MidDist:  dist,
			Epoch:    msg.SrcEpoch,
			Timediff: Timediff20,
		}
	} else if msg.Side == bookmsg.SellSide {
		x.SellTime = append(x.SellTime, msg.SrcEpoch)
		nRecord := len(x.SellTime)
		if nRecord >= 20 {
			Timediff20 = msg.SrcEpoch - x.SellTime[nRecord-20]
			x.SellTime = x.SellTime[1:]
		} else {
			Timediff20 = 0.0
		}
		dist = msg.Prc - Midpricenow
		if dist<=0 {
			dist = 0
		}
		x.addSellRecords[msg.Oid] = OrderRecord{
			Qty:      msg.Qty,
			Prc:      msg.Prc,
			MidDist:  dist,
			Epoch:    msg.SrcEpoch,
			Timediff: Timediff20,
		}
	}

	x.outs[11] += msg.Qty // QtyAdd_all
}








func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	var sellWeights, buyWeights []float64
	var sellInvDists, buyInvDists []float64
	var buyQty, sellQty []float64

    var SSumTimeDiff, BSumTimeDiff, BSSumTimeDiff []float64
    	

	for _, rec := range x.addSellRecords {
		sellWeights = append(sellWeights, rec.Qty /( rec.MidDist + 0.01))
		sellInvDists = append(sellInvDists, 1.0/(rec.MidDist + 0.01))
		sellQty     = append(sellQty, rec.Qty)
		if rec.Timediff<=0.0 {
			SSumTimeDiff = append(SSumTimeDiff, rec.Timediff)
		}
	}
	for _, rec := range x.addBuyRecords {
		buyWeights = append(buyWeights, rec.Qty / (rec.MidDist + 0.01))
		buyInvDists = append(buyInvDists, 1.0/(rec.MidDist+0.01))
		buyQty     = append(buyQty, rec.Qty)
		if rec.Timediff<=0.0 {
			BSumTimeDiff = append(BSumTimeDiff, rec.Timediff)
		}
		
	}



	x.outs[0] = Mean(sellWeights) / Mean(sellInvDists)
	x.outs[1] = Std(sellWeights)
	x.outs[2] = Std(sellInvDists)
	x.outs[3] = Mean(sellInvDists)
	x.outs[4] = Mean(SSumTimeDiff)

	x.outs[5] = Mean(buyWeights) / Mean(buyInvDists)
	x.outs[6] = Std(buyWeights)
	x.outs[7] = Std(buyInvDists)
	x.outs[8] = Mean(buyInvDists)
	x.outs[9] = Mean(BSumTimeDiff)

	BSSumTimeDiff = append(BSSumTimeDiff, BSumTimeDiff...)
	BSSumTimeDiff = append(BSSumTimeDiff, SSumTimeDiff...)

	x.outs[10] = Mean(BSSumTimeDiff)
	
	x.outs[12] = Mean(sellQty)
	x.outs[13] = Std(sellQty)
	
	x.outs[14] = Mean(buyQty)
	x.outs[15] = Std(buyQty)

	x.outs[16] = Std(SSumTimeDiff)
	x.outs[17] = Std(BSumTimeDiff)


	
	copy(out, x.outs)
	x.outs = make([]float64, 18)
	x.addBuyRecords = make(map[int]OrderRecord)
	x.addSellRecords = make(map[int]OrderRecord)
	// x.BuyTime    = x.BuyTime[:0]
	// x.SellTime   = x.SellTime[:0]
}


func Std(arr []float64) float64 {
	valid := make([]float64, 0, len(arr))
	for _, v := range arr {
		if !math.IsNaN(v) {
			valid = append(valid, v)
		}
	}
	n := len(valid)
	if n < 3 {
		return 0
	}
	mean := Mean(valid)
	var sum float64
	for _, v := range valid {
		sum += (v - mean) * (v - mean)
	}
	return math.Sqrt(sum / float64(n-1)) // 样本标准差
}


func Mean(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	for _, v := range arr {
		sum += v
	}
	return sum / float64(len(arr))
}




// percentile returns the threshold value for the given ratio (e.g. 0.7 means top 30%)


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
