package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	_ "fmt"
	"math"
)

type TermDemo struct {
	*base.Base

	names     []string // names of the fields
	outs      []float64
	Prcall  []float64
	Qtyall  []float64
	Dirall  []bookmsg.TradeDir

	Qty_B1  float64
	Prc_B1  []float64

	Qty_S1  float64
	Prc_S1  []float64

	Qty_S2  float64
	Prc_S2  []float64

	Qty_B2  float64
	Prc_B2  []float64

	Qty_BN  float64
	Prc_BN  []float64

	Qty_SN  float64
	Prc_SN  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:      base.New(cfg, sid),
		names:     []string{"ImpactPIN_B_Qty", "ImpactPIN_S_Qty", "invImpactPIN_B_Qty", "invImpactPIN_S_Qty", "inverstransP_B_Qty", "inverstransP_S_Qty", 
							"ImpactPIN_B_Prc", "ImpactPIN_S_Prc", "invImpactPIN_B_Prc", "invImpactPIN_S_Prc", "inverstransP_B_Prc", "inverstransP_S_Prc", 
							"allQty"},
		outs:      make([]float64, 13),
		// MidPrice:  []float64{},
		// Timeepoch: []string{},
		// PrcsumS:   []float64{},
		// PrcsumB:   []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################
func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
}

func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
	x.Prcall = append(x.Prcall, msg.Prc)
	x.Qtyall = append(x.Qtyall, msg.Qty)  
	x.outs[12] += msg.Qty
	x.Dirall = append(x.Dirall, msg.Dir)  
	
	n := len(x.Prcall)
	if n >= 25 {
		ret25 := x.Prcall[n-1]/x.Prcall[n-25] - 1.0

		if (ret25<0) && (x.Dirall[n-25] == 1) {
			x.Qty_B1 += (x.Qtyall[n-25])
			x.Prc_B1 = append(x.Prc_B1, x.Prcall[n-25])
		}
		if (ret25>0) && (x.Dirall[n-25] == -1) {
			x.Qty_S1 += (x.Qtyall[n-25])
			x.Prc_S1 = append(x.Prc_S1, x.Prcall[n-25])
		}
		if (ret25>0) && (x.Dirall[n-25] == 1) {
			x.Qty_B2 += (x.Qtyall[n-25])
			x.Prc_B2 = append(x.Prc_B2, x.Prcall[n-25])
		}
		if (ret25<0) && (x.Dirall[n-25] == -1) {
			x.Qty_S2 += (x.Qtyall[n-25])
			x.Prc_S2 = append(x.Prc_S2, x.Prcall[n-25])
		}
		if (ret25<0) && (x.Dirall[n-25] == -1) {
			x.Qty_BN += (msg.Qty)
			x.Prc_BN = append(x.Prc_BN, msg.Prc)
		}
		if (ret25>0) && (x.Dirall[n-25] == 1) {
			x.Qty_SN += (msg.Qty)
			x.Prc_SN = append(x.Prc_SN, msg.Prc)
		}
	}
}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
}


func meanNanIgnore(arr []float64) float64 {
	if len(arr) == 0 {
		return 0
	}
	sum := 0.0
	count := 0
	for _, val := range arr {
		if !math.IsNaN(val) {
			sum += val
			count++
		}
	}
	if count == 0 {
		return 0 // or return math.NaN() if you prefer
	}
	return sum / float64(count)
}
// On Snap ###################################################################
func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	x.outs[0] = x.Qty_B1
	x.outs[1] = x.Qty_S1
	x.outs[2] = x.Qty_B2 
	x.outs[3] = x.Qty_S2
	x.outs[4] = x.Qty_BN
	x.outs[5] = x.Qty_SN
	x.outs[6] = meanNanIgnore(x.Prc_B1)
	x.outs[7] = meanNanIgnore(x.Prc_S1)
	x.outs[8] = meanNanIgnore(x.Prc_B2)
	x.outs[9] = meanNanIgnore(x.Prc_S2)
	x.outs[10] = meanNanIgnore(x.Prc_BN)
	x.outs[11] = meanNanIgnore(x.Prc_SN)

	copy(out, x.outs)
	// fmt.Println("-------", x.outs)

	// reset for next round
	x.outs = make([]float64, 13)


	x.Qty_B1 = 0
	x.Prc_B1 = x.Prc_B1[:0]

	x.Qty_S1 = 0
	x.Prc_S1 = x.Prc_S1[:0]

	x.Qty_B2 = 0
	x.Prc_B2 = x.Prc_B2[:0]

	x.Qty_S2 = 0
	x.Prc_S2 = x.Prc_S2[:0]

	x.Qty_BN = 0
	x.Prc_BN = x.Prc_BN[:0]

	x.Qty_SN = 0
	x.Prc_SN = x.Prc_SN[:0]
}


// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
