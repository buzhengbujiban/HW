package termsdemo

import (
	"autosupply/bookmsg"
	"base/config"
	"base/enums"
	"base/events"
	"base/orderbook/ob"
	"base/security"
	"galpha/terms"
	"galpha/terms/base"
	"sort"
)

type TermDemo struct {
	*base.Base

	names []string
	outs  []float64

	isSH bool
	isSZ bool

	ob ob.IOrderBook // 自建book

	// 中间变量
	Bid2to6Vols []float64
	Ask2to6Vols []float64
	BookEpochs  []float64

	// 每个挂单记录
	MidPrice       []float64
	directions     []int8
	AddQtys        []float64
	AddPrcs        []float64
	AddIsBuy       []bool
	AddBid2to6Vols []float64
	AddAsk2to6Vols []float64
}

func New(cfg config.IConfig, sid int) *TermDemo {
	ret := &TermDemo{
		Base:  base.New(cfg, sid),
		names: []string{"oppsiteHuge_S_Qty", "oppsiteHuge_S_Prc", "oppsiteHuge_S_Count", "oppsiteHuge_B_Qty", "oppsiteHuge_B_Prc", "oppsiteHuge_B_Count","QtyAdd_all"},
		outs:  make([]float64, 7),
		// MidPrice: []float64[],
		// Bid2to6Vols:     []float64{},
		// Ask2to6Vols:     []float64{},
		// BookEpochs:      []float64{},
		// AddQtys:         []float64{},
		// AddPrcs:         []float64{},
		// AddIsBuy:        []bool{},
		// AddBid2to6Vols:  []float64{},
		// AddAsk2to6Vols:  []float64{},
	}

	ret.isSH = security.Lookup(sid).GetEx() == enums.ExSH
	ret.isSZ = !ret.isSH
	ret.ob = security.Lookup(sid).OrderBook()

	return ret
}

func (x *TermDemo) DataType() string {
	return "f64"
}

func (x *TermDemo) Headers() []string {
	return x.names
}

// On Msg Update ###################################################################


func (x *TermDemo) OnOBTradeMsg(msg *bookmsg.OBTradeMsg, events []events.IEvent) {
}

func (x *TermDemo) OnOBCancelMsg(msg *bookmsg.OBCancelMsg, events []events.IEvent) {}



func (x *TermDemo) OnFLBEndBatchMsg(msg *bookmsg.FLBEndBatchMsg, events []events.IEvent) {
	bidVol := 0.0
	askVol := 0.0
	for i := 1; i <= 5; i++ { // 买2-买6 和 卖2-卖6
		bidVol += msg.GetBsize(i)
		askVol += msg.GetAsize(i)
	}
	x.Bid2to6Vols = append(x.Bid2to6Vols, bidVol)
	x.Ask2to6Vols = append(x.Ask2to6Vols, askVol)
	// x.BookEpochs = append(x.BookEpochs, msg.SrcEpoch)
	x.MidPrice   = append(x.MidPrice, msg.GetMidPrice())
}

func (x *TermDemo) OnOBAddMsg(msg *bookmsg.OBAddMsg, events []events.IEvent) {
	n := len(x.MidPrice)
	if n <= 0 {
		return
	}
	x.outs[6] += msg.Qty

	if (msg.OrdType != 0) && (msg.Prc <= 0) {
		if msg.Side == 1 {
			msg.Prc = x.MidPrice[n-1] * 1.05
		} else {
			msg.Prc = x.MidPrice[n-1] * 0.95
		}		
	}

	x.AddQtys = append(x.AddQtys, msg.Qty)
	x.AddPrcs = append(x.AddPrcs, msg.Prc)
	x.directions = append(x.directions, int8(msg.Side))

	x.AddBid2to6Vols = append(x.AddBid2to6Vols, x.Bid2to6Vols[n-1])
	x.AddAsk2to6Vols = append(x.AddAsk2to6Vols, x.Ask2to6Vols[n-1])
}

func (x *TermDemo) Snap(snapId int, epoch float64, out []float64) {
	n := len(x.AddQtys)

	// 找出 Bid2-6 最大的前30%（用于筛选卖挂单）
	bidThreshold := percentile(x.AddBid2to6Vols, 0.7)
	var sellQtySum, sellAmtSum float64
	var sellCount int

	// 找出 Ask2-6 最大的前30%（用于筛选买挂单）
	askThreshold := percentile(x.AddAsk2to6Vols, 0.7)
	var buyQtySum, buyAmtSum float64
	var buyCount int

	for i := 0; i < n; i++ {
		if x.directions[i]==-1 && x.AddBid2to6Vols[i] >= bidThreshold {
			sellQtySum += x.AddQtys[i]
			sellAmtSum += x.AddQtys[i] * x.AddPrcs[i]
			sellCount++
		}
		if x.directions[i]==1 && x.AddAsk2to6Vols[i] >= askThreshold {
			buyQtySum += x.AddQtys[i]
			buyAmtSum += x.AddQtys[i] * x.AddPrcs[i]
			buyCount++
		}
	}

	var sellAvgPrc, buyAvgPrc float64
	if sellQtySum > 0 {
		sellAvgPrc = sellAmtSum / sellQtySum
	}
	if buyQtySum > 0 {
		buyAvgPrc = buyAmtSum / buyQtySum
	}



	x.outs[0] = sellQtySum   
	x.outs[1] = sellAvgPrc
	x.outs[2] = float64(sellCount)    // 绝对?,
	x.outs[3] = buyQtySum
	x.outs[4] = buyAvgPrc
	x.outs[5] = float64(buyCount)

	copy(out, x.outs)
	// // 清空
	x.outs = make([]float64, 7)
	x.AddQtys = x.AddQtys[:0]
	x.AddPrcs = x.AddPrcs[:0]
	x.directions = x.directions[:0]
	x.AddBid2to6Vols = x.AddBid2to6Vols[:0]
	x.AddAsk2to6Vols = x.AddAsk2to6Vols[:0]

	// x.Bid2to6Vols = x.Bid2to6Vols[:0]
	// x.Ask2to6Vols = x.Ask2to6Vols[:0]
	// x.MidPrice    = x.MidPrice[:0]

}

// percentile returns the threshold value for the given ratio (e.g. 0.7 means top 30%)
func percentile(data []float64, ratio float64) float64 {
	if len(data) == 0 {
		return 0
	}
	sorted := append([]float64(nil), data...) // 复制一份，避免破坏原数组
	sort.Float64s(sorted)
	idx := int(float64(len(sorted)) * ratio)
	if idx >= len(sorted) {
		idx = len(sorted) - 1
	}
	return sorted[idx]
}

// check if TermDemo implements ITerm
var _ terms.ITerm = (*TermDemo)(nil)

// register TermDemo
func init() {
	terms.Register("term_demo", func(cfg config.IConfig, sid int) terms.ITerm {
		return New(cfg, sid)
	})
}
