from pattern_helper import *

dates = find_dates_from_pattern("/data/beef2/data/CA/CNEQ/Panels/Y/Y_V5/YYYYMMDD.sdiv")
dates = [d for d in dates if 20180101 <= d <= 20221231]

def split_dates_into_4_rolls(dates):
    def split_list_indices(k, m):
        target_len = len(k) // m
        remainder = len(k) % m
        sub_list_indices = []
        start = 0
        for i in range(m):
            end = start + target_len + (1 if i < remainder else 0)
            sub_list_indices.append((start, end))
            start = end
        return sub_list_indices

    idxes = split_list_indices(dates, 4)
    rolls = []

    tr_start, tr_end = dates[idxes[0][0]], dates[idxes[1][1]-1]
    va_start, va_end = dates[idxes[3][0]], dates[idxes[3][1]-1]
    te_start, te_end = dates[idxes[2][0]], dates[idxes[2][1]-1]
    rolls += [((tr_start, tr_end),(va_start, va_end),(te_start, te_end))]

    tr_start, tr_end = dates[idxes[1][0]], dates[idxes[2][1]-1]
    va_start, va_end = dates[idxes[0][0]], dates[idxes[0][1]-1]
    te_start, te_end = dates[idxes[3][0]], dates[idxes[3][1]-1]
    rolls += [((tr_start, tr_end),(va_start, va_end),(te_start, te_end))]

    tr_start, tr_end = dates[idxes[1][0]], dates[idxes[2][1]-1]
    va_start, va_end = dates[idxes[3][0]], dates[idxes[3][1]-1]
    te_start, te_end = dates[idxes[0][0]], dates[idxes[0][1]-1]
    rolls += [((tr_start, tr_end),(va_start, va_end),(te_start, te_end))]

    tr_start, tr_end = dates[idxes[2][0]], dates[idxes[3][1]-1]
    va_start, va_end = dates[idxes[0][0]], dates[idxes[0][1]-1]
    te_start, te_end = dates[idxes[1][0]], dates[idxes[1][1]-1]
    rolls += [((tr_start, tr_end),(va_start, va_end),(te_start, te_end))]
    return rolls
print(split_dates_into_4_rolls(dates))