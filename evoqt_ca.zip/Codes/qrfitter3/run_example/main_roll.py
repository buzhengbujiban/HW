import os
import copy
import math
import SharedArray as sa
from exec import run_parallel
from nnfitter.utils import read_json, save_json, Roller
from nnfitter.torch_dataset import load_processed_data

current_folder = os.path.dirname(os.path.realpath(__file__))

def generate_cmd(json_path):
    py = os.path.join(current_folder, 'run_terminal.py')
    return f"python {py} {json_path}"


if __name__ == '__main__':

    json_path = os.path.join(current_folder, 'config.json')
    
    config = read_json(json_path)
    workspace_dir, expt_name = config["fitting"]['workspace_dir'], config["fitting"]['expt_name']
    workspace_dir = os.path.join(workspace_dir, expt_name)
    config["fitting"]['workspace_dir'] = workspace_dir
    config["fitting"]["delete_shm"] = False  # delete array in share memory after loading
    config["fitting"]["store_per_month"] = True
    jsons_folder = os.path.join(workspace_dir, 'jsons')
    os.makedirs(jsons_folder, exist_ok=True)

    # roller = Roller(
    #     start_date='20190101', end_date='20240331', valid_window=4, reverse_valid=True,
    #     test_start_month='202105', test_window=4, gen_next_month=False, max_train_months=18+4
    # )  # valid 4m + train 18m + test 4m
    roller = Roller(
        start_date='20190101', end_date='20240331', valid_window=1, reverse_valid=True,
        test_start_month='202401', test_window=1, gen_next_month=False, max_train_months=2+1
    )  # valid 1m + train 2m + test 1m  for quick testing
    n_rolls = sum(1 for _ in roller.iter())  # 总共多少个roll任务
    n_jobs = 9  # 每次的最大并行任务数
    n_times = math.ceil(n_rolls / n_jobs)  # 需要串行多少次

    for i in range(n_times):
        start, end = i*n_jobs, (i+1)*n_jobs
        save_json_paths = []
        ranges = []
        for fold_tuple in roller.iter(start=start, end=end):
            roll_config = copy.deepcopy(config)
            fold_id, fold_name, train_range, valid_range, test_range = fold_tuple
            print(fold_tuple)
        #     segments = {
        #         "train": train_range,
        #         "valid": valid_range,
        #         "test": test_range
        #     }
        #     ranges.extend(list(segments.values()))
        #     roll_config['segments'] = segments
        #     expt_name = f'roll_{fold_id}'
        #     roll_config['expt_name'] = expt_name
            
        #     save_json_path = os.path.join(jsons_folder, f'roll_{fold_id}.json')
        #     save_json(roll_config, save_json_path)
        #     save_json_paths.append(save_json_path)
        
        # date_start, date_end = min([r[0] for r in ranges]), max([r[1] for r in ranges])
        # dirname = config["processed_data_dir"]
        # filenames = config["filenames"]
        # _, shm_keys = load_processed_data(dirname, filenames, date_start, date_end, store_per_month=True)

        # cmds_fn = os.path.join(jsons_folder, f'tasks_{start}to{end}.txt')
        # with open(cmds_fn, "w") as f:
        #     cmds = [generate_cmd(json_path) for json_path in save_json_paths]
        #     f.writelines([c+"\n" for c in cmds])

        # threads_per_job = config["dataloader_workers"]
        # run_parallel(wdir=workspace_dir, cmds_fn=cmds_fn, job_spec=n_jobs, delay_each_job=3, omp_threads=threads_per_job, dryrun=False)
        
        # for shm_key in shm_keys:  # delete shared array afterwards
        #     sa.delete(shm_key)