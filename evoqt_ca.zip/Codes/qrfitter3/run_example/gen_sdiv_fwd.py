import argparse
from pattern_helper import *

if __name__ == "__main__":
    def str_to_int_list(s):
        return [int(i) for i in s.split(",")]
    
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern",      type=str,             required=True)
    parser.add_argument("--date",         type=int,             required=True)
    parser.add_argument("--fwd_horizons", type=str_to_int_list, required=True)
    args = parser.parse_args()

    dates = find_dates_from_pattern(args.pattern)
    cols = read_columns_from_pattern(args.pattern)
    print(dates)
    print(cols)
    