import os
import json
import subprocess
import inspect
from pathlib import Path

from jobs.rnodes.rnode import RNode
from canopus_py.rnodes.ca_node import CANode, clos2node
#import alpha_ca.closures as clos
from canopus_py.rnodes.stats_node import StatsNode
from canopus_py.ca_expr import *
from canopus_py.ca_stats import *
#import alpha_ca.closures as clos


if __name__ == "__main__":
    RNode.RNODE_ROOT = "/media/ps/disk1/Rroot/"
    RNode.RNODE_ROOT = "/data/beef2/mike/rroot"
    RNode.GLOBAL_TASKNAME = Path(__file__).stem

    # CANode.MUTE_RUN = True

    base_config = CANode.base_config()
    base_config["EVENTS.market"] = "CNEQ"
    base_config["EVENTS.busdate_pattern"] = "/data/beef2/zifan/label_v1/label.YYYYMMDD.sdiv"
    base_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"

    panels = [
        "/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/mpv/mpvd/terms.YYYYMMDD.sdiv",
        "/data/beef2/zifan/label_v1/label.YYYYMMDD.sdiv",
    ]

    term_node = CANode(base_config, label="mpvd", clean_dir_name=True)
    term_node.node_config["DATA.panels"] += ["P"]
    term_node.node_config["DATA.P.pattern"] = "/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/mpv/mpvd/terms.YYYYMMDD.sdiv"
    term_node.node_config["CA.terms"] = {
        col:ca.Na20(col) for col in read_columns_from_pattern(term_node.node_config["DATA.P.pattern"])
    }
    term_node.node_config["OUTPUT.terms"] = True
    term_node.node_config["OUTPUT.terms.output_ii"] = iih.down_sample_ii(6, offset=1)
    term_node.node_config["OUTPUT.dir"] = "/data/beef2/zifan/mpvd_30m_downsample/"
    term_node.set_run_dates()
    # term_node.run_date(20190513)
    term_node.run(pattern_dates_cache=True)

    term_node = CANode(base_config, label="label", clean_dir_name=True)
    term_node.node_config["DATA.panels"] += ["P"]
    term_node.node_config["DATA.P.pattern"] = "/data/beef2/zifan/label_v1/label.YYYYMMDD.sdiv"
    term_node.node_config["CA.terms"] = {
        col:ca.Na20(col) for col in read_columns_from_pattern(term_node.node_config["DATA.P.pattern"])
    }
    term_node.node_config["OUTPUT.terms"] = True
    term_node.node_config["OUTPUT.terms.output_ii"] = iih.down_sample_ii(6, offset=1)
    term_node.node_config["OUTPUT.dir"] = "/data/beef2/zifan/label_30m_downsample/"
    term_node.set_run_dates()
    # term_node.run_date(20190513)
    term_node.run(pattern_dates_cache=True)

    term_node = CANode(base_config, label="label", clean_dir_name=True)
    term_node.node_config["DATA.panels"] += ["P"]
    term_node.node_config["DATA.P.pattern"] = "/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/BB/5min-YYYYMMDD.sdiv"
    term_node.node_config["CA.terms"] = {
        "wgt":ca.Na20("is.active")
    }
    term_node.node_config["OUTPUT.terms"] = True
    term_node.node_config["OUTPUT.terms.output_ii"] = iih.down_sample_ii(6, offset=1)
    term_node.node_config["OUTPUT.dir"] = "/data/beef2/zifan/wgt_30m_downsample/"
    term_node.set_run_dates()
    # term_node.run_date(20190513)
    term_node.run(pattern_dates_cache=True)
    exit(0)
    term_node.node_config["OUTPUT.shm_label"] = "Y"
    w_node = CANode(base_config, label="W", clean_dir_name=True)
    w_node.node_config["DATA.panels"] += ["BB"]
    w_node.node_config["DATA.BB.pattern"] = "/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/BB/5min-YYYYMMDD.sdiv"
    w_node.node_config["CA.terms"] = {
        "wgt":ca.Na20("is.active")
    }
    w_node.node_config["OUTPUT.shm"] = True
    w_node.node_config["OUTPUT.terms"] = True
    w_node.node_config["OUTPUT.shm_label"] = "W"

    combine_node = CANode(base_config, label="combine", clean_dir_name=True)
    columns = []
    for i, panel in enumerate(panels):
        combine_node.node_config["DATA.panels"] += [f"p{i}"]
        combine_node.node_config[f"DATA.p{i}.pattern"] = panels[i]
        columns += read_columns_from_pattern(panels[i])
    combine_node.node_config["CA.terms"] = {
        col:ca.Na20(col) for col in columns
    }
    combine_node.node_config["OUTPUT.shm"] = True
    combine_node.node_config["OUTPUT.terms"] = True
    combine_node.node_config["OUTPUT.shm_label"] = "combine"

    for panel in panels:
        chapter_name = panel.split("/")[5]
        closure_name = panel.split("/")[6].split(".")[2]
        shm_label = chapter_name+"."+closure_name
        print(shm_label)
        term_node = CANode(base_config, label=shm_label, clean_dir_name=True)
        term_node.node_config["DATA.panels"] += ["terms"]
        term_node.node_config["DATA.terms.pattern"] = panel
        columns = read_columns_from_pattern(panel)
        term_node.node_config["CA.terms"] = {
            col:ca.Na20(col) for col in columns
        }
        term_node.node_config["OUTPUT.shm"] = True
        term_node.node_config["OUTPUT.terms"] = True
        term_node.node_config["OUTPUT.shm_label"] = shm_label

    for node in CANode.ALL_NODES[:3]:
        # node.run_date(20230201)
        node.set_run_dates()
        node.run_periods = node.run_periods[-20:]
        node.run()
        # if isinstance(node, StatsNode):
        #     # if int(str(node.term_node.stage_dir()).split("/")[-1][:3]) < 22:
        #     #     continue
        #     selected_terms = read_non_empty_lines(node.stage_dir()/"selected.txt")
        #     node.term_node.node_config["CA.terms"] = {k: v for k, v in node.term_node.node_config["CA.terms"].items() if k in selected_terms}
        #     print(len(node.term_node.node_config["CA.terms"]), node.term_node.stage_dir())
        #     node.term_node.node_config["OUTPUT.terms"] = True
        #     node.term_node.node_config["OUTPUT.stats"] = False
        #     node.term_node.set_run_dates()
        #     node.term_node.run()
        #     # periods = term_node.run_periods
        #     # term_node.run_periods = periods[:150]
        #     # node.term_node.run()
        #     # term_node.run_periods = periods[150:]
        #     # term_node.run()