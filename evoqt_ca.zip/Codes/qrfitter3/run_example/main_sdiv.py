import os
from nnfitter.utils import read_yaml
from nnfitter import learner as learner_module
import json

if __name__ == '__main__':
    current_folder = os.path.dirname(os.path.realpath(__file__))
    yaml_path = os.path.join(current_folder, 'config.yaml')

    config = read_yaml(yaml_path)
    
    # print(json.dumps(config, indent=2))
    # exit(0)

    learner = getattr(learner_module, config["learner_class"])(config)
    learner.run()