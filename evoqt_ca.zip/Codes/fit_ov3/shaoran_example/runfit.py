from random import sample
import sys
sys.path = ["/home/tgy/git/TP_tgy/apps/", "/home/tgy/git-test/qrfitter"] + sys.path
import modelflow as mf
import argparse
import subprocess
import pytbl
from typing import List, Union
import re

def minusMonth(ym, num):
    year = int(ym[:4])
    month = int(ym[4:6])
    st_month = month - num
    month_ans = (st_month - 1) % 12 + 1
    year_ans = year - ((month_ans - st_month) // 12)
    return f"{year_ans}{month_ans:02d}"


"""
sids: [sid_a, (sid_name: [sid_b, sid_c])]
"""

def isCC(channel):
    return "-cc" in channel or "-bu" in channel

def runFit(channel, fittag, sid: Union[str, List[str]], sid_name: str,
           roll=-1, selgids: List[int] = [], x_names="",
           reg_alpha=-1, reg_lambda=1, reg_l1_ratio = 0.2,
           run_test=False,
           model="lgb", window=4,
           wgt_hl="inf", ret="",
           extra="", test_start="",
           lr_mult=1., num_rounds=2000,
           date_version=1, sid_wgt_mult="",
           override_month_end="", fit_test=True,
           num_threads = 80,
           extra_pattern=".*[-.].*",
           root_name="features_tgy",
           override_min_child_sample = -1,
           max_mcs_ratio=-1,
           override_max_depth = 0, 
           no_feature_frac = False,
           autocorr_configs = {}, do_shap=True,
           override_suffix="",
           extra_vcat="",
           disk_wkdir="/data/nasData/chinaFuturesData",
           filter_column = "",
           filter_limit = 0,
           weight="",
           cat="",
           lgb_update_dict = {},
           extra_use_sid = ""
           ):
    if len(override_month_end) > 0 and fit_test:
        print("ERROR: month_end & fit test not implemented. to implement, you might need to put in test_month as well")
        sys.exit(1)
    mcs_ratio = 1.
    if len(selgids) == 0:
        selgids = None
    else:
        mcs_ratio = len(selgids) / 3.
        if mcs_ratio > 1.:
            mcs_ratio = 1.
    sample_date = "20230301"
    gap_days = 0
    if not run_test:
        date_start = "20160101"
        date_end = "20221114"
        test_start = "201901"
        print(channel)
        # removed a lot of checks
        if date_version == 19:
            # for 9804* starting from 20220722
            date_start = "20220722"
            date_end = "20240312"
            test_start = "202209"
            sample_date = "20221230" 
        
    else:

        date_start = "20191201"
        date_end = "20200201"
        test_start = "202001"

    fitname = f"fit_{sid_name}_{channel}_{fittag}"
    sample_dir = f"{disk_wkdir}/{root_name}/{channel}/sample"
    out_dir = f"{sample_dir}/{fitname}"
    out_cfg = f"{out_dir}/mf.whole.json"
    #!!!
    m = mf.Workspace(mode="cfggen")

    if "-pa-" in channel or "-pab-" in channel:
        n_estimators = num_rounds
        min_child_samples = 20000
        tu_group = "yes"
        tu_bound = "no"
        sample_suffix = "tbl"
        ret_pattern = "^(i\.)?ret.*"
        target_ret = "ret300s"
        raw_target_ret = None
        max_depth = 10
    else:
        raise "unkown channel"

    if len(override_suffix) > 0:
        sample_suffix = override_suffix

    if ret != "":
        target_ret = ret
        if target_ret.startswith("N"):
            raw_target_ret = target_ret[2:]
        else:
            raw_target_ret = None

    if override_min_child_sample > 0:
        min_child_samples = override_min_child_sample

    if override_max_depth > 0:
        max_depth = override_max_depth

    useWGTLS = "wgtls" in fittag
    wgt_name = "wgt"
    mcw = 0.001
    mcs = int(min_child_samples * mcs_ratio)
    if useWGTLS:
        wgt_name = "X.wgtls"
        if "wgtlsr" in fittag:
            if "wgtlsrm2" in fittag:
                mcw = int(min_child_samples * mcs_ratio * 2)
                mcs = 1
        else:
            mcw = int(min_child_samples * mcs_ratio)
            mcs = mcw
    if weight != "":
        wgt_name = weight
        print("using weight", wgt_name)

    if model == "lgb":
        if reg_alpha < 0:
            reg_alpha = 0.5
        lgb_param = {
            "task": "train",
            "device": "cpu",
            "num_threads": num_threads,
            "boosting_type": "gbdt",
            "objective": "regression",
            "metric": "custom",
            "learning_rate": 0.005 * lr_mult,
            "verbose": 2,
            "feature_fraction": 0.7,
            "max_depth": max_depth,
            "num_leaves": 64,
            "max_bin": 128,
            "n_estimators": n_estimators,
            "min_child_samples": mcs,
            "min_child_weight": mcw,
            "reg_alpha": reg_alpha,
            "reg_lambda": reg_lambda,
            # "early_stopping_rounds": 100,
            # "__warmup_rounds": 500
        }
        if "data_sample_strategy" not in lgb_update_dict or lgb_update_dict == "bagging":
            bagging_config = {
                "bagging_fraction": 0.9,
                "bagging_freq": 2,
            }
            lgb_param.update(bagging_config)
        lgb_param.update(lgb_update_dict)
        if len(cat) > 0:
            lgb_param["categorical_feature"] = cat
        if no_feature_frac:
            lgb_param['feature_fraction'] = 1.
        if "ac_rounds" in lgb_param:
            if isCC(channel):
                lgb_param["ac_roll_len"] = 60
            else:
                lgb_param["ac_roll_len"] = 1
        # let configs override
        lgb_param.update(autocorr_configs)
        if max_mcs_ratio > 0:
            lgb_param["max_mcs_ratio"] = max_mcs_ratio
        fitter_param = lgb_param
    elif model == "xgb_rf":
        xgb_param = {
            "base_score":            0.001,
            "colsample_bytree":      0.7,
            "max_depth":             max_depth,
            "num_parallel_tree":     25,
            "objective":             "reg:linear",
            "subsample":             0.3,
            "tree_method":           "hist",
            "num_boost_round":       n_estimators,
            "nthread":               80,
            "min_child_weight":     mcw,
# TODO learn rate
        }
        xgb_param.update(lgb_update_dict)
        fitter_param = xgb_param

    elif model == "ridge":
        if reg_alpha < 0:
            reg_alpha = 1.
        ridge_param = {
            "alpha": reg_alpha,
            "normalize": True
        }
        if isCC(channel):
            ridge_param['normalize'] = False
            ridge_param['fit_intercept'] = False
        fitter_param = ridge_param
    elif model == "en":
        if reg_alpha < 0:
            reg_alpha = 1.
        en_param = {
            "ridge_alpha": reg_alpha,
            "normalize": True,
            "l1_ratio": reg_l1_ratio,
        }
        if isCC(channel):
            en_param['normalize'] = False
            en_param['fit_intercept'] = False
        fitter_param = en_param
    else:
        raise Exception("unkown model")

    sid_wgt_mult_dict = {}
    for sw in sid_wgt_mult.split("/"):
        if len(sw) <= 0:
            continue
        [wsids, wwgt] = sw.split(":")
        for wsid in wsids.split(","):
            sid_wgt_mult_dict[wsid] = float(wwgt)
    #! estimator is here

    regs = mf.grid_estimators(model,
                              **fitter_param
                              )
    # data
    import template_utils
    # TODO: normed, group
    if type(x_names) is str:
        x_names = x_names.replace("%SID%", sid_name)

    def get_x_names(fn, x_names=x_names, check_xnames = True, dir=sample_dir):
        if check_xnames and len(x_names) > 0:
            if "%TRAIN_END%" in x_names:
                
                return x_names
            else:
                x_names_list = eval(open(x_names).read())
                return x_names_list
        else:
            return template_utils.get_features(
                f"{dir}/{sample_date}/{fn}",
                fittag,
                group=tu_group,
                bound=tu_bound
            )

    extra_prov_args = {}
    if isinstance(sid, str):
        filename = f"{sid}.{sample_suffix}"
        x_names_list = get_x_names(filename)
        dirnames = sample_dir
        sample_df = pytbl.tbl_read(f"{sample_dir}/{sample_date}/{filename}")
        provider_how = "single"
    else:
        filename = [f"{s}.{sample_suffix}" for s in sid]
        if len(x_names) > 0:
            x_names_list = get_x_names(filename[0])
        else:
            x_names_list = sorted(set.intersection(*map(set, [get_x_names(fn) for fn in filename])))
        dirnames = [sample_dir] * len(sid)
        sample_df = pytbl.tbl_read(f"{sample_dir}/{sample_date}/{filename[0]}")
        provider_how = "vcat"
    if extra != "" and extra_vcat != "":
        sys.exit("combining vcat and hcat not supported")
    if extra != "":
        if extra.startswith("CHA") or extra.startswith("CHL"):
            extra_file_name = extra[3:]
            if ":" in extra_file_name:
                extra_file_root, extra_file_channel = extra_file_name.split(":")
            else:
                extra_file_root, extra_file_channel = root_name, extra_file_name
            if "@" in extra_file_channel:
                extra_file_channel, extra_suffix = extra_file_channel.split("@")
            else:
                extra_suffix = sample_suffix
            extra_file = f"{extra_use_sid}.{extra_suffix}"
            if extra.startswith("CHA"):
                extra_dir = f"/data/nasData/chinaFuturesData/{extra_file_root}/{extra_file_channel}/sample"
            elif extra.startswith("CHL"):
                extra_dir = f"/data/local30/tgy/{extra_file_root}/{extra_file_channel}/sample"
        
        else:
            sys.exit("unknown extra")
        filename = [filename, extra_file]
        dirnames = [dirnames, extra_dir]
        print("before adding extra: ", extra_dir, len(x_names_list))
        extra_x_names = get_x_names(extra_file, check_xnames=False, dir= extra_dir)
        reg_extra_pattern = r"^(?!X\.wgtls|ret.*|N\.ret.*)" + extra_pattern + r"|rec_epoch|^gid"
        extra_x_names = [x for x in extra_x_names if re.match(reg_extra_pattern, x)]
        for name in extra_x_names:
            if name not in x_names_list and not (name.startswith("ret") or name.startswith("N.ret") or name.startswith("sm.ret") ):
                x_names_list.append(name)
        print("after adding", len(x_names_list))
        provider_how = "hcat"
        extra_prov_args = {
            "column_pattern": [r"-|\.|ret|rec_epoch|sid|date|wgt|gid",
                               reg_extra_pattern],
            "on": ["rec_epoch", "gid"],
        }
    if extra_vcat != "":
        if provider_how != "single":
            sys.exit("combining vcat and hcat not supported")
        extra_file = f"{sid}.{sample_suffix}"
        if ":" in extra_vcat:
            [extra_vcat_root, extra_dir]  = extra_vcat.split(":")
        else:
            extra_vcat_root = f"/data/nasData/chinaFuturesData/{root_name}"
            extra_dir = extra_vcat
        extra_sample_dir = f"{extra_vcat_root}/{extra_dir}/sample"
        filename = [filename, extra_file]
        dirnames = [dirnames, extra_sample_dir]
        
        provider_how = "vcat"

    provider_x_names = x_names_list
    if type(x_names_list) is str and "%TRAIN_END%" in x_names_list:
        provider_x_names = x_names_list.replace("%TRAIN_END%", "ALL")
    noroll = len(override_month_end) > 0
    if noroll:
        if roll < 0:
            month_start = date_start[:6]
        else:
            month_start = minusMonth(override_month_end, roll)
            date_start = month_start + "01"
        date_end = override_month_end + "31"
    if filter_column != "":
        extra_prov_args['filter_column'] = filter_column
        extra_prov_args['filter_limit'] = filter_limit
    rets = mf.cols_from_regex(sample_df, [ret_pattern])
    if target_ret not in rets:
        rets += [target_ret]
    provider = mf.ProviderBase(dirname=dirnames,
                               filename=filename,
                               x_names=provider_x_names,
                               y_names=rets,
                               w_name=wgt_name,
                               date_start=date_start,
                               date_end=date_end,
                               gids=selgids,
                               how=provider_how,
                               copy=False,
                               **extra_prov_args)
    print(provider, date_end)
    # dataset
    dss_args = {}
    task_args = {"do_shap": do_shap}
    if gap_days > 0:
        dss_args['gap_days'] = gap_days
        print("using gap days", gap_days)
    if type(x_names_list) is str and "%TRAIN_END%" in x_names_list:
        if noroll:
            dss_args["x_names"] =  x_names_list
    if noroll:
        print(f"using month_start = {month_start}")
        dss = [mf.Dataset.create(provider, "roll.0", month_start, override_month_end, None, None,
                                 gen_next_month=True, wgt_hl=wgt_hl, sid_wgt_mult=sid_wgt_mult_dict, **dss_args)]
        task_args["prefix"] = f"task_{sid_name}_{override_month_end}_"
    else:
        roll_ds = mf.RollDataset(date_start, date_end, test_start, window, False, roll)
        dss = roll_ds.create(provider, wgt_hl=wgt_hl, sid_wgt_mult=sid_wgt_mult_dict, **dss_args)
        task_args['raw_target_name'] = raw_target_ret
        # tasks: 2D-list, rolls x tasks
    tasks = [
        mf.Task.from_grid(
            out_dir, target_ret, ds, regs, yname2horizon="^ret(.*)$", do_test=fit_test, **task_args)
        for ds in dss]
    all_tasks = [t for sub in tasks for t in sub]
    # ensembles, 1 ensemble per roll
    ensembles = [
        # mf.Ensemble(f"ensemble_{i}", tss, cfg={'outdir': f"{out_dir}/ensemble_{i}"})
        # for i, tss in enumerate(tasks)
    ]
    # assemble
    m.assemble(
        provider=provider,
        datasets=dss,
        estimators=regs,
        tasks=all_tasks,
        ensembles=ensembles)
    return {"m": m,
            "out_cfg": out_cfg,
            "out_dir": out_dir,
            "fitname": fitname,
            "all_tasks": all_tasks,
            "sample_dir": sample_dir}
