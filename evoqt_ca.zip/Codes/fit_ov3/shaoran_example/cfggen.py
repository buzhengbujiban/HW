from random import sample
import sys
sys.path = ["/home/tgy/git/TP_tgy/apps/", "/home/tgy/git-test/qrfitter"] + sys.path
import modelflow as mf
import argparse
import subprocess
import pytbl
import runfit
import os
parser = argparse.ArgumentParser()
parser.add_argument("--channel", required=True)
parser.add_argument("--fittag", required=True)
parser.add_argument("--sid", required=True)
parser.add_argument("--sid_name", default="")
parser.add_argument("--roll", default=-1, type=int)
parser.add_argument("--selgids", default="")
parser.add_argument("--x_names", default="")
parser.add_argument("--reg_alpha", default=-1, type=float)
parser.add_argument("--reg_lambda", default=1., type=float)
parser.add_argument("--reg_l1_ratio", default = 0.2, type= float)
parser.add_argument("--run_test", action="store_true")
parser.add_argument("--report_only", action="store_true")
parser.add_argument("--model", default="lgb")
parser.add_argument("--window", default=4, type=int)
parser.add_argument("--wgt_hl", default="inf")
parser.add_argument("--ret", default="")
parser.add_argument("--extra", default="")
parser.add_argument("--extra_vcat", default="")
parser.add_argument("--test_start", default="")
parser.add_argument("--lr_mult", type=float, default=1.)
parser.add_argument("--num_rounds", type=int, default=2000)
parser.add_argument("--date_version", default=1, type=int)
parser.add_argument("--sid_wgt_mult", default="")
parser.add_argument("--memPerCpu", type=int, default =4100)
parser.add_argument("--extra_pattern", default = ".*[-.].*")
parser.add_argument("--root_name", default="features_tgy")
parser.add_argument("--threads", type=int, default=80)
parser.add_argument("--max_mcs_ratio", type=float, default=-1)
parser.add_argument("--mcs", type=int, default = -1)
parser.add_argument("--md", default = 0, type=int)
parser.add_argument("--ac_rounds", default = 0, type=int)
parser.add_argument("--ac_iter", default = 50, type=int)
parser.add_argument("--ac_alpha", default = .2, type=float)
parser.add_argument("--ac_roll_len", default =1, type=int)
parser.add_argument("--ac_roll_y", action="store_true")
parser.add_argument("--compare", type=str, default = "")
parser.add_argument("--no_report", action="store_true")
parser.add_argument("--no_feature_frac", action="store_true")
parser.add_argument("--suffix", default="")
parser.add_argument("--disk_wkdir", default ="/data/nasData/chinaFuturesData")
parser.add_argument("--filter_column", default = "")
parser.add_argument("--weight", default="")
parser.add_argument("--cat", default="")
parser.add_argument("--lgb_update_dict", default="")
parser.add_argument("--lgb4", action="store_true")
parser.add_argument("--no_slurm", action="store_true")
parser.add_argument("--extra_use_sid", default="")
args = parser.parse_args()
sid = args.sid
if "," in sid:
    sid = sid.split(",")
    sid_name = args.sid_name
    if len(sid_name) == 0:
        raise "please specify sid_name when you have multiple sid"
else:
    sid_name = sid
ac_configs = {}
if args.ac_rounds > 0:
    ac_configs = {
        "ac_rounds": args.ac_rounds,
        "ac_iter_per_round": args.ac_iter,
        "ac_alpha": args.ac_alpha,
        "ac_roll_len": args.ac_roll_len,
        "ac_roll_y": args.ac_roll_y
    }
extra_kwargs = {}
if args.filter_column != "":
    extra_kwargs["filter_column"] = args.filter_column
    extra_kwargs["filter_limit"] = -0.5
if args.lgb_update_dict != "":
    def toFloatIfIsFloat(x):
        try:
            fx = float(x)
            if int(fx) == fx:
                return int(fx)
            return fx
        except:
            return x
    items = args.lgb_update_dict.split(",")
    extra_kwargs["lgb_update_dict"] = {x.split(":")[0]: toFloatIfIsFloat(x.split(":")[1]) for x in items}
cfg = runfit.runFit(
    args.channel, args.fittag, sid, sid_name,
    roll=args.roll, selgids=[] if len(args.selgids) == 0 else [int(x) for x in args.selgids.split(",")],
    reg_alpha=args.reg_alpha, reg_lambda=args.reg_lambda, reg_l1_ratio= args.reg_l1_ratio,
    run_test=args.run_test,
    model=args.model, window=args.window,
    wgt_hl=args.wgt_hl, ret=args.ret,
    extra=args.extra, test_start=args.test_start,
    lr_mult=args.lr_mult, num_rounds=args.num_rounds,
    date_version=args.date_version, sid_wgt_mult=args.sid_wgt_mult,
    extra_pattern= args.extra_pattern, root_name=args.root_name,
    num_threads= args.threads,
    max_mcs_ratio=args.max_mcs_ratio,
    override_min_child_sample=args.mcs,
    x_names = args.x_names,
    override_max_depth = args.md,
    no_feature_frac=args.no_feature_frac,
    autocorr_configs = ac_configs,
    override_suffix = args.suffix,
    extra_vcat = args.extra_vcat,
    disk_wkdir = args.disk_wkdir,
    weight = args.weight,
    cat = args.cat,
    extra_use_sid = args.extra_use_sid,
    **extra_kwargs
)
m = cfg['m']
out_cfg = cfg['out_cfg']
all_tasks = cfg['all_tasks']
out_dir = cfg['out_dir']
fitname = cfg['fitname']
python_dir = ""
if args.lgb4:
    python_dir = "/data/nasData/apps/mambaforge/envs/lgb4/bin/"
if not args.report_only:
    mf.ws_write_cfg(m, out_cfg)
    slurm = not args.no_slurm
    extra_param = "--retries 1"
    if slurm:
        extra_param = f" -sq fqueue --memPerCpu {args.memPerCpu} -sjn fit-{fitname} --timeout 12:00:00 " + extra_param
    
    mf.ws_run_parallel(m, out_dir, '1',  # 22
                       order="backward", per_dataset=1, omp_threads=args.threads, delay_each_job=5, slurm=slurm, extra_param = extra_param , python_dir=python_dir)

rpt_dir = "/home/tgy/fitrpt/roll_ensemble/"

task_str = ','.join([x.task_id for x in all_tasks])

if not args.no_report:
    cmd = [
        f'/home/tgy/git/TP_tgy/modelflow/jlefit/report/run_roll_task_report_notebook.sh',
        out_cfg,
        task_str,
        f'{rpt_dir}/task_{fitname}'
    ]
    print(cmd)
    subprocess.check_call(cmd)
if len(args.compare) > 0:
    cmp_cfg = args.compare
    cmd = [os.path.join(mf.MF_PATH, "apps/notebook/run_roll_cmp_notebook.sh"),
           out_cfg,
           cmp_cfg,
            task_str,
            task_str,
            f'{rpt_dir}/cmp_{fitname}'
    ]
    print(cmd)
    subprocess.check_call(cmd)
