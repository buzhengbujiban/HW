import os, sys

sys.path = ['/home/junming/git/qrfitter'] + sys.path

import modelflow as mf
mf.pd_set_max_option()

use_5min_data = True

class Args():
    pass

args = Args()
if use_5min_data:
    args.sample_dir = "/data/nfs1/users/junming/ov3_sampled_5min"
else:
    args.sample_dir = "/data/nfs1/users/junming/ov3"
args.expt_result_dir = "/data/nasData/chinaEquityData/junming/temp_files/"
args.expt_name = "lgb_test"
args.target = "mret24.0h"
args.y_names = ["mret24.0h", "mret1d0m", "mret1d10m", "mret1d30m", "mret1e"]
args.do_shap = False
args.job_spec = '1'  # how many jobs run-parallel takes, e.g. for parallel for multiple dss and models
args.exec = False  # False means only print commands
args.slurm = False  # whether to use slurm or not
args.sq = 'fqueue'
args.n_threads = 75
args.memPerCpu = 2000 if use_5min_data else 2000*5
args.se = "ps6,ps7,ps8,ps9,ps10"  # 排除部分机器

out_dir = os.path.join(args.expt_result_dir, args.expt_name)
this_dir = mf.relative("__file__")


# ========================== Estimator ==========================
lgb_param = {
    "task": "train",
    "device": "cpu",
    "num_threads": args.n_threads,
    "boosting_type": "gbdt",
    "objective": "regression",  # L2 loss or mse
    "metric": "custom",  # metric(s) to be evaluated on the evaluation set, 在fit中定义了eval_metric=_customized_metric_cor
    "learning_rate": 0.001,
    "verbose": 2,  # < 0: Fatal, = 0: Error (Warning), = 1: Info, > 1: Debug
    "feature_fraction": 0.7,  # randomly select a subset of features on each iteration (tree)
    # "bagging_fraction": 0.9,
    # "bagging_freq": 2,  # 表示每k轮，会随机选择fraction部分数据来用作接下来的k轮的fitting data
    # "max_depth": 64, # default -1 means no limit
    "num_leaves": 128,  # max_leaf
    # "max_bin": 128,  # 直方图算法的分箱数
    "min_child_samples": 20000,  # minimal number of data in one leaf
    "min_child_weight": 0.001,  # minimal sum hessian in one leaf
    # "reg_alpha": 0.5,
    # "reg_lambda": 1,
    "num_boost_round": 20,  # n_estimators is same as num_boost_round
    # "early_stopping_rounds": 10,
    # "__warmup_rounds": 500
}
reg = mf.Estimator.create2(model_id="lgb_test", model_type="lgb", para_dict=lgb_param)


# ========================== Provider ==========================
# date_start='20190101', date_end='20221231'
date_start, date_end = '20210101', '20220430'
# date_start='20201101', date_end='20201231'

#test_start_month='202201', test_window=12, max_train_months=-1
test_start_month, test_window = '202201', 1
# test_start_month='202012', test_window=1,
max_train_months = -1

if use_5min_data:
    provider = mf.create_provider(
        args.sample_dir, x_names_reg=["-"], y_names_reg=["^mret"], w_name="wgt",
        date_start=date_start, date_end=date_end
    )
else:
    filenames = ['sampler.s1.tbl', 'sampler.s2.tbl', 'sampler.s3.tbl', 'sampler.s4.tbl']
    provider = mf.create_provider(
        args.sample_dir, x_names_reg=["-"], y_names_reg=["^mret"], w_name="wgt",
        filename=filenames[0], date_start=date_start, date_end=date_end
    )
    provider.dirname = [args.sample_dir] * len(filenames)
    provider.filename = filenames
    provider.how = "vcat"


# ========================== Dataset, Task, Workspace ==========================
roller = mf.create_roller(
    provider,
    test_start_month=test_start_month, test_window=test_window, max_train_months=max_train_months
)
dss = roller.create(provider)
tasks = [
    mf.create_task(task_id=f"task_{i}", estimator=reg, dataset=ds, outdir=f"{out_dir}/task_{i}", target_name=args.target, do_shap=args.do_shap)
    for i, ds in enumerate(dss)
]

ws = mf.Workspace(mode="cfggen")
ws.assemble(provider=provider, datasets=dss, estimators=[reg], tasks=tasks)


# ========================== Execution ==========================
extra_param = " --retries 1"
if args.slurm:
    extra_param = f"--memPerCpu {args.memPerCpu} -sjn {args.expt_name} --timeout 12:00:00 -sq {args.sq}" + extra_param
    if args.se is not None:
        extra_param += f" -se {args.se}"

mf.ws_run_parallel(
    ws, out_dir, args.job_spec,
    per_dataset=True, delay_each_job=5, omp_threads=args.n_threads, dryrun=not args.exec,
    slurm=args.slurm, extra_param=extra_param
    
)