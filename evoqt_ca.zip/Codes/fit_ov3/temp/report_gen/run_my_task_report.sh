#!/bin/bash
# example:
# $ CFG=/data/nasData/chinaEquityData/john/nott/mf.fitted.mi.p2/roll.2.x0_model_0/task_roll.2.x0_model_0.task_cfg.json
# $ TASK=task_roll.2.x0_model_0
# $ OUTPUT=test/rpt_task_roll_2_x0
# $ time ./run_task_report.sh $CFG $TASK $OUTPUT  
# [NbConvertApp] Converting notebook /data/qraZone/john/notebook/mf/prod/rpt_task.ipynb to notebook
# [NbConvertApp] Writing 470760 bytes to /data/qraZone/john/notebook/mf/prod/test/rpt_task_roll_2_x0.ipynb
# 
# real    1m26.103s
# user    29m15.481s
# sys     4m16.843s

set -eo pipefail


# use conda dev9 env
source activate /data/nas2Data/apps/anaconda3/envs/dev9

# parse input
if [[ $# -ne 3 ]]; then
    echo "$0 tast_mf_json task_id output"
    exit 1
fi

cfg=$1
task=$2
output=`realpath $3`

folder=$(dirname $output)
if [[ ! -e $folder ]]; then
    echo "creating $folder"
    mkdir -p $folder
fi

script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd -P)
echo "BASH_SOURCE $BASH_SOURCE"
cat <<- EOF > $output.sh
source activate /data/nas2Data/apps/anaconda3/envs/dev9
export JUPYTER_INPUT_PYTHON="{'cfg':'$cfg', 'task_id':'$task'}"
jupyter-nbconvert ${script_dir}/rpt_task_junming.ipynb --execute --to html --no-input --output $output
EOF

bash $output.sh  && rm $output.sh