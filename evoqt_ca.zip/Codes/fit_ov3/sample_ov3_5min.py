import os
import sys
from datetime import datetime
import time
import pandas as pd
import numpy as np
import json
from joblib import Parallel, delayed

import qr


def read_onedate_feature_df(dir_name, fns, date):
    date_folder = os.path.join(dir_name, date)
    if len(os.listdir(date_folder)) == 0:  # 2019年之前ov3都没数据
        return None
    dfs = []
    for fn in fns:
        df = qr.tbl_read(os.path.join(date_folder, fn))
        dfs.append(df)
    df = pd.concat(dfs, axis=0)
    return df


def load_times(json_file):
    with open(json_file, 'r') as f:
        time_strs = json.load(f)
    times = [datetime.strptime(time_str, '%H:%M').time() for time_str in time_strs]
    return times


def sample_df_on_times(df, times, epoch_column='rec_epoch'):
    df['time'] = pd.to_datetime(df[epoch_column].round(), unit='s')\
        .dt.tz_localize('UTC').dt.tz_convert('Asia/Shanghai').dt.tz_localize(None).dt.round('min').dt.time
    # 上面新增.dt.round('min')主要是为了处理20190103这种rec_epoch是01s的，其他都是00.xxxx s到
    df = df[df['time'].isin(times)].drop(columns=['time'])
    return df


def onedate_job(dir_name, fns, date, times, save_folder, tbl_name='sampler.tbl'):
    df = read_onedate_feature_df(dir_name, fns, date)
    if df is not None:
        df = sample_df_on_times(df, times)
        date_path = os.path.join(save_folder, date)
        os.makedirs(date_path, exist_ok=True)
        qr.tbl_write(df, os.path.join(date_path, tbl_name))


if __name__ == "__main__":
    start_time = time.time()

    times = load_times('/data/nfs1/users/junming/times_5min.json')  # 提前准备好的5min-interval时间点文件
    dir_name = '/data/nfs1/users/junming/ov3'
    fns = ['sampler.s1.tbl', 'sampler.s2.tbl', 'sampler.s3.tbl', 'sampler.s4.tbl']
    save_folder = '/data/nfs1/users/junming/ov3_sampled_5min'

    # date = '20230531'
    # onedate_job(dir_name, fns, date, times, save_folder)

    date_start, date_end = '20190103', '20190103'
    date_list = qr.bd.get_range(date_start, date_end)
    results = Parallel(n_jobs=32, verbose=1)(delayed(onedate_job)(dir_name, fns, date, times, save_folder) for date in date_list)

    print('time: %.2f hours (%.1f minutes)' % ((time.time() - start_time)/3600, (time.time() - start_time)/60), flush=True)