from jobs.rnodes.rnode import RNode
from canopus_py.rnodes.ca_node import CANode
from canopus_py.ca_expr import ca
from canopus_py.ca_stats import *
from fit_ca.canopus_scripts.dump_shm import get_run_periods
from pathlib import Path
from sim.zz1000sim import alpha_xy_node_from_patterns, run_report

inds_CNE5 = [
    'AEROSPCE', 'AIRLINES', 'APPAREL', 'AUTOCOMP',
    'BANKS', 'BEVTOB', 'BLDPROD', 'COMMSVCS', 'CHEMICAL', 'CONGTRD',
    'CNSTENG', 'CONMAT', 'CONSDUR', 'CONSRV', 'DIVFINAN', 'ELECEQP',
    'ENERGY', 'FOODPROD', 'FSTAPHPP', 'HDWRSE', 'HEALTH', 'MACHINRY',
    'MARINE', 'MEDIA', 'MTLMIN', 'OTHRCHEM', 'PACKGFP', 
    'REALEST', 'RETAIL',
    'RDRLTRAN', 'SOFTWARE', 'UTILITY',
]

stls_CNE5 = [
    'ANLYSTSN', 'BETA', 'BTOP', 'DIVYILD', 'EARNQLTY', 'EARNVAR',
    'EARNYILD', 'GROWTH', 'INDMOM', 'INVSQLTY', 'LEVERAGE', 'LIQUIDTY',
    'LTREVRSL', 'MIDCAP', 'MOMENTUM', 'PROFIT', 'RESVOL', 'SEASON',
    'STREVRSL', 'SIZE'
]
factors_ind = inds_CNE5
factors_stl = stls_CNE5


def rdcp1(terms_dict, include_original=True, lite=False, types=None):
    global inds_CNE5
    global stls_CNE5
    global factors_ind
    global factors_stl

    factors_s3 = [
        "SIZE", "RESVOL", "BETA"
    ]

    factors_CNE5D = factors_ind+factors_stl  # exclude "COUNTRY"

    factors_all = [ca.Na20(i) for i in factors_CNE5D]
    factors_ind = [ca.Na20(i) for i in factors_ind]
    factors_stl = [ca.Na20(i) for i in factors_stl]
    factors_s3 = [ca.Na20(i) for i in factors_s3]

    result = {}
    for k, v in terms_dict.items():
        if include_original:
            result[f"{k}.o"] = v
        # result[f"{k}.m"]   = ca.RegRes( ca.Na20(v), [ca.C(1)], bod_reg   =True)  # PBETA
        result[f"{k}.b"]   = ca.RegRes( ca.Na20(v), factors_all, bod_reg =True,pinv=True)
        result[f"{k}.bp"]  = ca.RegYHat(ca.Na20(v), factors_all, bod_reg=True,pinv=True)
        if not lite:
            result[f"{k}.m"]   = ca.RegRes( ca.Na20(v), ca("PBeta"), bod_reg   =True,pinv=True)  # PBETA
            result[f"{k}.i"]   = ca.RegRes( ca.Na20(v), factors_ind, bod_reg =True,pinv=True)
            result[f"{k}.ip"]  = ca.RegYHat(ca.Na20(v), factors_ind, bod_reg=True,pinv=True)
            result[f"{k}.s"]   = ca.RegRes( ca.Na20(v), factors_stl, bod_reg =True,pinv=True)
            result[f"{k}.sp"]  = ca.RegYHat(ca.Na20(v), factors_stl, bod_reg=True,pinv=True)
            result[f"{k}.s3"]  = ca.RegRes( ca.Na20(v), factors_s3, bod_reg  =True,pinv=True)
            result[f"{k}.s3p"] = ca.RegYHat(ca.Na20(v), factors_s3, bod_reg =True,pinv=True)
    if types is not None:
        result = {k:v for k,v in result.items() if k.split(".")[-1] in types}
    return result

def calc_rdcp(pattern_dict, start_date, end_date):
    node_config = CANode.base_config()
    node_config["EVENTS.busdate_pattern"] = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"
    node_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    node_config["OUTPUT.terms"] = True
    node_config["OUTPUT.stats"] = True

    panel_name = "BarraExp"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = "/data/nfs0/chinaEquityData/panel/barra/exp-YYYYMMDD.sdiv"
    node_config[f"DATA.{panel_name}.inclusive"] = False  # barra exp YYYYMMDD.sdiv要下一天bod才能用

    panel_name = "BarraStats"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = "/data/nfs0/chinaEquityData/panel/barra/stats-YYYYMMDD.sdiv"
    node_config[f"DATA.{panel_name}.inclusive"] = False  # barra exp YYYYMMDD.sdiv要下一天bod才能用

    node_config["DATA.panels"] += ["Y"]
    node_config["DATA.Y.pattern"] = "/data/beef3/data/CA.v24.1220.test_release/CNEQ/Panels/Y/Y_V5/terms.YYYYMMDD.sdiv"
    # base_config["DATA.Y.pattern"] = "/data/nasData/chinaEquityData/statarb/midfreq/Y_V5/YYYYMMDD.sdiv"
    node_config["STATS.y_terms"] = {
        "mret24h": "mret24h",
        "mret2e": "mret2e",
        "mret1h": "mret1h",
        "mret0e": "mret0e",
        "mret_t1":ca("mret1e")-ca("mret0e"),
        "mret_ovn":ca("mret1o")-ca("mret0e"),
        "mret_t1i":ca("mret1e")-ca("mret1o"),
        "mret5e": "mret5e",
    }
    node_config["DATA.panels"] += ["5min"]
    node_config["DATA.5min.pattern"] = "/data/bees3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/I/fq5m/BB/terms.YYYYMMDD.sdiv"
    node_config["DATA.5min.columns"] = ["backward.ret5m", "is.active", "high" ,"low", "open", "close", "dollarVolumeTotal", "tradesTotal", "buyNotl", "sellNotl"]

    reversed_all_patterns = {}
    terms_dict = {}
    for k,v in pattern_dict.items():
        pattern = v.split(":")[0]
        col = v.split(":")[1]
        # col_mask = k+"."+col
        alpha_name = k
        if pattern in reversed_all_patterns:
            pattern_key = reversed_all_patterns[pattern]
            node_config[f"DATA.{pattern_key}.columns"] += [col]
            node_config[f"DATA.{pattern_key}.column_masks"] += [alpha_name]
        else:
            reversed_all_patterns[pattern] = k
            node_config["DATA.panels"] += [k]
            node_config[f"DATA.{k}.pattern"] = pattern
            node_config[f"DATA.{k}.columns"] = [col]
            node_config[f"DATA.{k}.column_masks"] = [alpha_name]
        terms_dict[k] = k

    node_config["CA.terms"] = rdcp1(terms_dict)
    node = CANode(node_config)
    node.set_run_dates()
    run_periods = get_run_periods(pattern=node.node_config["EVENTS.busdate_pattern"], start_date=start_date, end_date=end_date)
    node.run_periods = run_periods
    node.run(para_spec=80)

def modify_ca_node(ca_node):
    panel_name = "BarraExp"
    ca_node.node_config["DATA.panels"] += [panel_name]
    ca_node.node_config[f"DATA.{panel_name}.pattern"] = "/data/nfs0/chinaEquityData/panel/barra/exp-YYYYMMDD.sdiv"
    ca_node.node_config[f"DATA.{panel_name}.inclusive"] = False  # barra exp YYYYMMDD.sdiv要下一天bod才能用

    panel_name = "BarraStats"
    ca_node.node_config["DATA.panels"] += [panel_name]
    ca_node.node_config[f"DATA.{panel_name}.pattern"] = "/data/nfs0/chinaEquityData/panel/barra/stats-YYYYMMDD.sdiv"
    ca_node.node_config[f"DATA.{panel_name}.inclusive"] = False  # barra exp YYYYMMDD.sdiv要下一天bod才能用

    ca_node.node_config["CA.terms"] = rdcp1({k: k for k in ca_node.node_config["CA.terms"].keys()})
    terms_g = {}
    for name, expr in ca_node.node_config["CA.terms"].items():
        terms_g[f"{name}.g10"] = ca.IfElse((ca.XsRank2(ca.IfElse(ca.Na20('is.active'), expr, ca.C("nan")))>=ca.C(0.8)), ca.C(1), ca.C(0))
    ca_node.node_config["CA.terms"].update(terms_g)

if __name__ == "__main__":
    RNode.RNODE_ROOT = f"/data/beef2/junming/rroot/{Path(__file__).stem}"
    RNode.GLOBAL_TASKNAME = 'zuze_alpha_new_g10'  # TODO 设置本次实验名
    pattern_dict = {
        # "zuze2458_m24h": "/data/bees1/unsafe/junming/equity_fitting/online202409/tree_model/zuze_Forhs2458_mret24h/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.0.alpha",
        "zuze_Alpha.145": "/data/bees1/unsafe/junming/equity_fitting/online202409/tree_model/zuze_Alpha.145.calbyCA_mret24h/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.0.alpha",
    }
    # calc_rdcp(pattern_dict, start_date=20230101, end_date=20241227)
    univ = "csi300"
    ca_node = alpha_xy_node_from_patterns(pattern_dict, label="ca", univ=univ)
    modify_ca_node(ca_node)

    ca_node.run()
    run_report(ca_node, univ=univ)