      
#!/usr/bin/env python

from jobs.rnodes.rnode import RNode
from canopus_py.rnodes.ca_node import CANode
from canopus_py.ca_expr import ca, CAExprHelper, CAExprHelperPro
from canopus_py.ca_stats import *
import copy
from pathlib import Path
import json
import qr_utils
import panel
import pandas as pd 
import numpy as np
from joblib import Parallel, delayed
import subprocess
import pickle
import pandas as pd
import numpy as np
from scipy import stats
from canopus_py.test.test_helper import *
from canopus_py.ca_utils import read_columns_from_pattern
from uni_report.rnodes.uni_report_node import UniReportNode
ca = CAExprHelper()


def get_stats_dict(daily_FR):

    stats_dict = {}
    for short_window, long_window in [(10, 120),  (20, 250)]:
        p_values = []
        mean_short = []
        mean_long = []
        # 确保序列长度足够
        for i in range(long_window, len(daily_FR)):
            # 提取过去20个点和过去250个点
            past_short = daily_FR[i-short_window:i]
            past_long = daily_FR[i-long_window:i]
        
            # 进行KS检验
            ks_statistic, p_value = stats.ks_2samp(past_short, past_long)
            p_values.append(p_value)
        
            # 计算均值
            mean_short.append(past_short.mean())
            mean_long.append(past_long.mean())
        
        # 将p值和均值转换为Series
        p_values_series = pd.Series(p_values, index=daily_FR.index[long_window:])
        mean_short_series = pd.Series(mean_short, index=daily_FR.index[long_window:])
        mean_long_series = pd.Series(mean_long, index=daily_FR.index[long_window:])

        stats_df = pd.concat([p_values_series, mean_short_series, mean_long_series], axis=1)
        stats_df.columns = ["p_value", "mean_short", "mean_long"]
        assert not stats_df.isna().any().any()
        stats_df = stats_df.shift(1).dropna()  # eod to bod
        stats_df.index = stats_df.index.strftime("%Y%m%d")
        if short_window == 10:
            sig_level = 0.05
            remove = stats_df[(stats_df["p_value"] < sig_level) & (stats_df["mean_short"] < stats_df["mean_long"])]
            print(remove.index.values)
        stats_dict[(short_window, long_window)] = stats_df
    return stats_dict

def get_CAF_trigger(panel_patterns, task_name, start_date=20230101):
    assert len(panel_patterns) == 1  # 目前只会有一个CAF
    alpha_name, alpha_pattern = list(panel_patterns.keys())[0], list(panel_patterns.values())[0]
    RNode.RNODE_ROOT = f"/data/beef2/junming/data/CAF_trigger"
    RNode.GLOBAL_TASKNAME = task_name  # TODO 设置本次实验名
    ca_node = alpha_xy_node_from_patterns(panel_patterns, label="ca")
    terms_g = {}
    for name, expr in ca_node.node_config["CA.terms"].items():
        terms_g[f"{name}.g10"] = ca.IfElse((ca.XsRank2(ca.IfElse(ca.Na20('is.active'), expr, ca.C("nan")))>=ca.C(0.8)), ca.C(1), ca.C(0))
    ca_node.node_config["CA.terms"].update(terms_g)
    ca_node.run()
    patterns = {}
    for col in read_columns_from_pattern(str(ca_node.stage_dir() / "terms.YYYYMMDD.sdiv")):
        patterns[col] = f"{ca_node.stage_dir()}/terms.YYYYMMDD.sdiv:{col}"
    report_node = UniReportNode(
        ca_node.stage_dir(),
        panel_patterns=patterns,
        refresh_data=True,
        rnode_root=ca_node.stage_dir(),
        chain_name="",
    )
    report_node.add_FR_chart(y="mret0e")

    file_path = os.path.join(report_node.stage_dir(), "sections/000.lines_chart.FR.pkl")
    with open(file_path, "rb") as file:
        lines_chart = pickle.load(file)
    # 计算日FR序列
    daily_FR = (lines_chart[f'{alpha_name}.g10|mret0e|w_csi300'] - lines_chart[f'{alpha_name}.g10|mret0e|w_csi300'].shift(1)).dropna()
    stats_dict = get_stats_dict(daily_FR)

    import warnings
    from tqdm import tqdm
    warnings.filterwarnings("ignore", category=FutureWarning)
    univ = "csi300"
    save_folder = os.path.join(RNode.RNODE_ROOT, RNode.GLOBAL_TASKNAME, "trigger")
    os.makedirs(save_folder, exist_ok=True)
    with open(os.path.join(save_folder, "panel_patterns.json"), 'w') as file:
        json.dump(panel_patterns, file, indent=4, sort_keys=True)

    index_pattern = "/data/nfs0/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"
    end_date = list(stats_dict.values())[0].index.astype(int).max()  # alpha值只到这一天，理论上已经有明天的开关，但对于sim来说没用
    dates = [date for date in find_dates_from_pattern(index_pattern) if date >= start_date and date <= end_date]
    for date in tqdm(dates):
        index = panel.read(index_pattern.replace("YYYYMMDD", str(date)))
        univ_df = panel.sdiv2df(index)[[univ]+["time", "date", "sid"]].dropna()
        for (short_window, long_window), stats_df in stats_dict.items():
            for p_value in [0.01, 0.05, 0.1]:
                name = f"long{long_window}_short{short_window}_p{p_value}"
                if str(date) in stats_df[(stats_df["p_value"] < p_value) & (stats_df["mean_short"] < stats_df["mean_long"])].index:
                    weight = 0
                else:
                    weight = 1
                univ_df[name] = weight
        univ_sdiv = panel.df2sdiv(univ_df, S='sid', D='date', I='time')
        panel.write(os.path.join(save_folder, f"bod.{date}.sdiv"), univ_sdiv)

def e2e_alpha_changeI(pattern):  # 现在alpha 158是用昨天数据算出来的，但是qrfitter3 map到的I是今日9:35,如果要在9:31-9:34得到值得话，需要改成00:00:00
    dates = find_dates_from_pattern(pattern)
    target_I = ["00:00:00"]
    def change_I(file_path):
        x = panel.read(file_path)
        x = x.assign_coords(I=target_I)
        panel.write(file_path, x)
    if (source_I:=read_columns_from_pattern(pattern, "I")) != target_I:
        print(f"{pattern=}, changing {source_I=} to {target_I=}")
        res = Parallel(n_jobs=32)(delayed(change_I)(pattern.replace("YYYYMMDD", str(date))) for date in dates)


UNIV = "csi300"  # sh250, csi300, csi500, zz1000_midx, topx_midx, topx_non50, G2458  # TODO:设置univ
START_DATE, END_DATE = 20230101, 20250214 # 20241226
FREQ = 1
assert FREQ in [1, 5]
use_ipopt = False

class ApsJsonNode(RNode):
    class_id = "aps"
    def __init__(self, node_config, *args, **kwargs):
        super().__init__(node_config, *args, **kwargs)
        self.conf_name = "config.json"

    def config_to_dump(self):
        # self.node_config = {}
        # extra_config["metainfo"] = {}
        self.node_config["metainfo"]["workdir"] = str(self.stage_dir())
        return self.node_config

    def dump_json(self):
        json.dump(self.config_to_dump(), open(self.config_json_path(), "w"), indent=4, default=str)

    def set_alpha_source(self, panel_patterns):
        self.node_config["metainfo"]["env"]["alpha_source"] = {}
        for k,v in panel_patterns.items():
            pattern = v.split(":")[0]
            col = v.split(":")[1]
            self.node_config["metainfo"]["env"]["alpha_source"][k] = {
                "path_pattern":pattern.replace("YYYYMMDD", "{date}"),
                "col_need":[col],
                "cap": 0.01
            }

    def config_json_path(self):
        return self.stage_dir() / self.conf_name

    def set_task(self, task="SA"):
        self.node_config["metainfo"]["tasks"][0] = task

    def set_alpha_weights(self, weights):
        self.node_config[self.node_config["metainfo"]["tasks"][0]]["alpha_weight"]["weight_list"] = weights
    
    def set_alpha_names(self, names):
        self.node_config[self.node_config["metainfo"]["tasks"][0]]["new_names"] = names
    
    def run_internal(self):
        self.dump_json()
        cmd = f"export HOME=/data/nfshome/junming && python ~/git/aps/simulator/apps/sim_jobflow.py {self.config_json_path()} --run **rerun"
        print(cmd)
        subprocess.run(cmd, shell=True, text=True)


def alpha_xy_node_from_patterns(patterns, label=None, univ=UNIV):
    base_config = CANode.base_config()
    if univ in ["sh50", "csi300", "csi500", "zz1000"]:
        base_config["CA.univ"] = f"/data/bees3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/D/bod/index/index-YYYYMMDD.sdiv:{univ}"
    elif univ in ["sh250", "zz1000_midx", "topx_midx", "topx_non50"]:
        base_config["CA.univ"] = f"/data/beef2/junming/data/univ_index_bod/terms.YYYYMMDD.sdiv:{univ}"
    elif univ == "G2458":
        base_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    else:
        raise NotImplementedError
    base_config["CA.freq_m"] = FREQ
    # base_config["EVENTS.gf_weeks"] = 1
    for k,v in patterns.items():
        base_config["EVENTS.busdate_pattern"] = v.split(":")[0]
        break
    reversed_all_patterns = {}
    for k,v in patterns.items():
        pattern = v.split(":")[0]
        col = v.split(":")[1]
        # col_mask = k+"."+col
        alpha_name = k
        if pattern in reversed_all_patterns:
            pattern_key = reversed_all_patterns[pattern]
            base_config[f"DATA.{pattern_key}.columns"] += [col]
            base_config[f"DATA.{pattern_key}.column_masks"] += [alpha_name]
        else:
            reversed_all_patterns[pattern] = k
            base_config["DATA.panels"] += [k]
            base_config[f"DATA.{k}.pattern"] = pattern
            base_config[f"DATA.{k}.columns"] = [col]
            base_config[f"DATA.{k}.column_masks"] = [alpha_name]
            if "e2e_nn_model" in pattern.split(os.sep):
                base_config[f"DATA.{k}.inclusive"] = True
            elif "eod.YYYYMMDD.sdiv" in pattern:
                base_config[f"DATA.{k}.inclusive"] = False
            elif pattern in ["/data/beef3/mike/pshared/fa_alpha/YYYYMMDD.sdiv"]:
                base_config[f"DATA.{k}.inclusive"] = False
        base_config[f"DATA.{k}.lb_days"] = 1
        base_config["CA.terms"][alpha_name] = ca.Na20(alpha_name, rpii=1)  # 纯粹是为了931-934的CAalpha能读到前一天的最后一个值
    base_config["DATA.panels"] += ["index"]
    base_config["DATA.index.pattern"] = "/data/bees3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/D/bod/index/index-YYYYMMDD.sdiv"
    base_config["DATA.panels"] += ["univ"]
    base_config["DATA.univ.pattern"] = "/data/bees3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/D/eod/univ/univ-YYYYMMDD.sdiv"
    base_config["DATA.panels"] += ["5min"]
    base_config["DATA.5min.pattern"] = "/data/bees3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/I/fq5m/BB/terms.YYYYMMDD.sdiv"
    base_config["DATA.5min.columns"] = ["is.active", "high" ,"low", "open", "close", "dollarVolumeTotal", "tradesTotal", "buyNotl", "sellNotl"]

    am = ca.IIndex() < ca.C(24)
    pm = ca.IIndex() >= ca.C(24)
    # 其实设置了univ之后，w设置成C(1)也一样
    if univ == "csi300":
        w = ca.Sign(ca.Na20("csi300"))
    elif univ == "sh250":
        w = ca.Sign(ca.Na20("csi300")) - ca.Sign(ca.Na20("sh50"))
    elif univ == "csi500":
        w = ca.Sign(ca.Na20("csi500"))
    elif univ == 'zz1000_midx':
        w = ca.Sign(ca.Na20("zz1000")+ca.Na20("midx"))
    elif univ == 'topx_midx':
        w = ca.Sign(ca.Na20("topx")+ca.Na20("midx"))
    elif univ == "topx_non50":
        w = ca.Sign(ca.Na20("topx")) - ca.Sign(ca.Na20("sh50"))
    elif univ == "G2458":
        w = ca.C(1)
    else:
        raise NotImplementedError(univ)
    base_config["STATS.w_terms"] = {f"w_{univ}": w, f"w_{univ}_am": w*am, f"w_{univ}_pm": w*pm}

    base_config["DATA.panels"] += ["Y"]
    base_config["DATA.Y.pattern"] = "/data/beef3/data/CA.v24.1220.test_release/CNEQ/Panels/Y/Y_V5/terms.YYYYMMDD.sdiv"  # 20250207的Y有问题，暂时被mike填成0了
    # base_config["DATA.Y.pattern"] = "/data/nasData/chinaEquityData/statarb/midfreq/Y_V5/YYYYMMDD.sdiv"
    base_config["STATS.y_terms"] = {
        "mret24h": "mret24h",
        "mret2e": "mret2e",
        "mret1h": "mret1h",
        "mret0e": "mret0e",
        "mret_t1":ca("mret1e")-ca("mret0e"),
        "mret_ovn":ca("mret1o")-ca("mret0e"),
        "mret_t1i":ca("mret1e")-ca("mret1o"),
        "mret_5e24h":ca("mret5e")-ca("mret24h"),
        "mret5e": "mret5e",
    }

    base_config["OUTPUT.stats"] = True
    base_config["OUTPUT.terms"] = True
    node = CANode(base_config, label=label)
    # node.parse_vdeps()
    node.set_run_dates()
    node.run_periods = [i for i in node.run_periods if START_DATE <= i <= END_DATE]
    return node

def run_report(ca_node, marginal_base=None, report_label=None, mds:list=None, univ=UNIV):
    w = f"w_{univ}"
    patterns = {}
    for col in read_columns_from_pattern(str(ca_node.stage_dir() / "terms.YYYYMMDD.sdiv")):
        patterns[col] = f"{ca_node.stage_dir()}/terms.YYYYMMDD.sdiv:{col}"
    report_node = UniReportNode(
        ca_node.stage_dir(),
        panel_patterns=patterns,
        refresh_data=True,
        rnode_root=ca_node.stage_dir(),
        chain_name="",
        report_label=report_label,
    )
    if mds is not None:
        for md in mds:
            report_node.add_md(md)
    report_node.add_FR_chart(y="mret24h")
    report_node.add_FR_chart(y="mret1h")
    report_node.add_FR_chart(y="mret0e")
    report_node.add_FR_chart(y="mret_t1")
    report_node.add_FR_chart(y="mret_ovn")
    report_node.add_FR_chart(y="mret_t1i")
    report_node.add_FR_chart(y="mret5e")
    report_node.add_FR_chart(y="mret_5e24h")
    if marginal_base is not None:
        report_node.add_marginal_FR_chart(y="mret24h", base_x=marginal_base)
        report_node.add_marginal_FR_chart(y="mret1h", base_x=marginal_base)
        report_node.add_marginal_FR_chart(y="mret5e", base_x=marginal_base)
    report_node.add_FR_corr_table(y="mret24h", w=w)
    report_node.add_size_chart(w=w)
    report_node.add_autocorr_chart()
    # report_node.add_fr_chart(y="mret24h", w=w)
    # report_node.add_fr_chart(y="mret1h", w=w)
    report_node.add_FR_size_ratio_chart(w=w, y="mret24h", rolling_window=20)
    report_node.run(report_folder=report_node.stage_dir())


if __name__ == "__main__":
    # panel_patterns = {"CAFN": "/data/beef2/junming/online_testing/alpha_1h/terms.YYYYMMDD.sdiv:New_FGTE_Tree"}
    # get_CAF_trigger(panel_patterns, task_name=f'upto{END_DATE}')
    # exit()

    RNode.RNODE_ROOT = f"/data/beef2/junming/rroot/{Path(__file__).stem}"
    RNode.GLOBAL_TASKNAME = 'hs300_add_e2e_LSfitw_freq1_931945_rpii1'  # TODO 设置本次实验名

    panel_patterns = {
        "MA": "/data/nasData/chinaEquityData/alphapanels/active/MA.new/YYYYMMDD.sdiv:MA",
        "OV": "/data/nasData/chinaEquityData/alphapanels/active/OV.new/YYYYMMDD.sdiv:alpha",
        # "CA":"/data/beef2/junming/temp_alpha/m24h_online_ensemble_long_dump/terms.YYYYMMDD.sdiv:tree_mlp_mbp",
        # "CAF": "/data/beef2/junming/temp_alpha/GRU_MLP_Tree_1m/yhat.YYYYMMDD.sdiv:All.ridge",
        
        # "CAS": "/data/beef2/junming/temp_alpha/m5e_latest_ensemble/terms.YYYYMMDD.sdiv:pv_alter_fit5e",
        # # "CASpv": "/data/beef2/junming/rroot/calc_stats/m5e_latest_ensemble/terms.YYYYMMDD.sdiv:pv",
        # "alter": "/data/beef2/junming/temp_alpha/m5e_latest_ensemble/terms.YYYYMMDD.sdiv:alter_cofit_mret24h",

        # "HE": "/data/nasData/chinaEquityData/alphapanels/active/HE30m/YYYYMMDD.sdiv:n6s",
        # "zuze": "/data/bees1/unsafe/junming/equity_fitting/online202409/tree_model/merge.addold.select/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.0.alpha",
        # "zuzeg10": "/data/bees1/unsafe/junming/equity_fitting/online202409/tree_model/zuze_Forhs2458_mret24h/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.0.alpha",
        # "zuzeg10bp": "/data/beef3/mike/rroot/hs300_factors_perf/017.ca/terms.YYYYMMDD.sdiv:zuzeg10.bp",
        # "zuzeg10bpN": "/data/beef3/mike/rroot/hs300_factors_perf/017.ca/terms.YYYYMMDD.sdiv:zuzeg10drop.bp",
        # zuze 上线alpha
        "zuzeg10bpN": "/data/beef2/junming/rroot/rdcp_alpha/zuze_alpha_new_g10/000.ca.ca/terms.YYYYMMDD.sdiv:zuze_Alpha.145.bp",
        # "zuzeg10N": "/data/beef2/junming/rroot/rdcp_alpha/zuze_alpha_new_g10/000.ca.ca/terms.YYYYMMDD.sdiv:zuze_Alpha.145.o",

        # "zuzeg10sp": "/data/beef3/mike/rroot/hs300_factors_perf/017.ca/terms.YYYYMMDD.sdiv:zuzeg10.sp",
        # "gp_daily": "/data/bees1/unsafe/junming/equity_fitting/online202409/tree_model/tree_guopeng_daily_fea_202501/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.0.alpha",
        # "SR1500_G2548": "/data/bees1/unsafe/junming/equity_fitting/online202409/tree_model/tree_m24h_csi300.g10_SR1500_fitinG2548/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.0.alpha",
        # "CAFre": "/data/beef2/junming/temp_alpha/addoldsel_ensemble_dump/terms.YYYYMMDD.sdiv:All.ridge",
        # "CAFaddoldsel": "/data/beef2/junming/temp_alpha/addoldsel_ensemble_dump/terms.YYYYMMDD.sdiv:addoldsel.en.old",

        # "CAN": "/data/beef2/junming/temp_alpha/m24h_latest_ensemble_long_dump/terms.YYYYMMDD.sdiv:tree_mlp_mbp",
        # "CAFN": "/data/beef2/junming/temp_alpha/m1h_network_ensemble/terms.YYYYMMDD.sdiv:New_FGTE_Tree",
        # "CAFN2": "/data/beef2/junming/temp_alpha/m1h_network_ensemble_ftI_mix/terms.YYYYMMDD.sdiv:New_FGTE_Tree",

        # infer up to 20241227
        # "CAN": "/data/beef3/data/CA.v24.1220.test_release/CNEQ/Panels/A/fq5m/final_alpha/terms.YYYYMMDD.sdiv:tree_mlp_mbp",
        # "CAFN": "/data/beef3/data/CA.v24.1220.test_release/CNEQ/Panels/A/fq1m/final_alpha/terms.YYYYMMDD.sdiv:New_FGTE_Tree",
        # "CAFN": "/data/beef2/junming/online_testing_topx_quick/fq1m/terms.YYYYMMDD.sdiv:New_FGTE_Tree",  # 这个是用online脚本跑出来的1h alpha版本
        # "CAFN": "/data/beef2/junming/online_testing/alpha_1h/terms.YYYYMMDD.sdiv:New_FGTE_Tree",  # 用一样的脚本在online_testing文件夹下重新跑了一遍
        "CAFN": "/data/beef2/junming/online_testing/alpha_1h_PLUS_931945/terms.YYYYMMDD.sdiv:New_FGTE_Tree",

        # "Tree_mret": "/data/beef3/data/CA.v24.1220.test_release/CNEQ/Panels/A/fq5m/final_alpha/terms.YYYYMMDD.sdiv:Tree_mret24h",
        # "MLP_mret": "/data/beef3/data/CA.v24.1220.test_release/CNEQ/Panels/A/fq5m/final_alpha/terms.YYYYMMDD.sdiv:MLP_KD_mret24h",
        # "Tree_bret": "/data/beef3/data/CA.v24.1220.test_release/CNEQ/Panels/A/fq5m/final_alpha/terms.YYYYMMDD.sdiv:Tree_bret24h",
        # "MLP_bret": "/data/beef3/data/CA.v24.1220.test_release/CNEQ/Panels/A/fq5m/final_alpha/terms.YYYYMMDD.sdiv:MLP_KD_bret24h",
        # "Tree_bpret": "/data/beef3/data/CA.v24.1220.test_release/CNEQ/Panels/A/fq5m/final_alpha/terms.YYYYMMDD.sdiv:Tree_bpret24h",
        # "MLP_bpret": "/data/beef3/data/CA.v24.1220.test_release/CNEQ/Panels/A/fq5m/final_alpha/terms.YYYYMMDD.sdiv:MLP_bpret24h_std1",

        # 'CA5e': '/data/bees1/unsafe/junming/equity_fitting/online202409/mlp_model/mlp_all_latest_KDstudent_batch1500droplast/canopus_inference_alpha_temp/terms.YYYYMMDD.sdiv:fit.38.alpha',
        # 'CA_ovnt': '/data/bees1/unsafe/junming/equity_fitting/online202409/mlp_model/mlp_addG_ovnt_1itrd/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.0.alpha',
        # "CAN": "/data/beef2/junming/online_testing/fq5m/terms.YYYYMMDD.sdiv:tree_mlp_mbp",  # 这个是用online脚本跑出来的用zz1000_midx select features的24h alpha版本
        "CAN": "/data/beef2/junming/online_testing/alpha_24h/terms.YYYYMMDD.sdiv:tree_mlp_mbp",  # 同上，重新用run_CAjson infer了一遍
        # "fitw_ret_le_0.5": '/data/bees1/unsafe/junming/equity_fitting/online202409/mlp_model/mlp_all_latest_m24h1500_fithightprc/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.0.alpha',
        # "fitw_ret_le_0.8": '/data/bees1/unsafe/junming/equity_fitting/online202409/mlp_model/mlp_all_latest_m24h1500_fithightprc/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.2.alpha',
        # "fitw_up_limited": '/data/bees1/unsafe/junming/equity_fitting/online202409/mlp_model/mlp_all_latest_m24h1500_fithightprc/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.4.alpha',
        # 'fa': "/data/beef3/mike/pshared/fa_alpha/YYYYMMDD.sdiv:x",

        # e2e alpha
        # "e2ecombo": "/data/beef3/guopeng/research/e2e_alpha/others/e2ecombo/eod.YYYYMMDD.sdiv:hsl.e2ecombo",
        # 'eoda158': '/data/bees1/unsafe/junming/equity_fitting/online202409/e2e_nn_model/eoda158_GRU.mad_hs_ks_hiddenlayer_from2008/expt_folder/fit.4/yhat/yhat.YYYYMMDD.sdiv:yhat',
        # 'alpha480': '/data/bees1/unsafe/junming/equity_fitting/online202409/e2e_nn_model/alpha480_GRU.mad_hs2_from2008_mret24hclip/expt_folder/fit.6/yhat/yhat.YYYYMMDD.sdiv:yhat',

        'fit_mret24h.clip_ks90': '/data/beer2/junming/equity_fitting/e2e_nn_model/eoda158.mad.tsrkconcat_GRU_10y24h_bs4096/qrfitter3_inference_alpha158_tushare_gfw1/fit.11/yhat/yhat.YYYYMMDD.sdiv:yhat',
        'fit_sret24h.clip_ks90': '/data/beer2/junming/equity_fitting/e2e_nn_model/eoda158.mad.tsrkconcat_GRU_10y24h_bs4096/qrfitter3_inference_alpha158_tushare_gfw1/fit.12/yhat/yhat.YYYYMMDD.sdiv:yhat',
        'fit_spret24h.clip_ks90': '/data/beer2/junming/equity_fitting/e2e_nn_model/eoda158.mad.tsrkconcat_GRU_10y24h_bs4096/qrfitter3_inference_alpha158_tushare_gfw1/fit.13/yhat/yhat.YYYYMMDD.sdiv:yhat',
        # '158_tsconcat_ks60_l2_h64': '/data/beer2/junming/equity_fitting/e2e_nn_model/eoda158.GRU.tsrank_concat/expt_folder/fit.3/yhat/yhat.YYYYMMDD.sdiv:yhat',
        # 'trading90topx': '/data/beer2/junming/equity_fitting/e2e_nn_model/eoda158.mad.tsrkconcat_GRU_sampling_univx/expt_folder/fit.6/yhat/yhat.YYYYMMDD.sdiv:yhat'
        # 'Smret24h_4_h32': '/data/beer2/junming/equity_fitting/e2e_nn_model/eoda158.mad.GRU_tsrkconcat_LSfitw_noreflect/expt_folder/fit.8/yhat/yhat.YYYYMMDD.sdiv:yhat',
        'Smret24h_1.5_h32': '/data/beer2/junming/equity_fitting/e2e_nn_model/eoda158.mad.GRU_tsrkconcat_reflection_LSfitw/qrfitter3_inference_alpha158_tushare_gfw1/fit.6/yhat/yhat.YYYYMMDD.sdiv:yhat',
        
        # LS weight alpha
        'mret24h__Smret24h_1.5': "/data/beer2/junming/equity_fitting/mlp_model/mlp_LSbalance_sel_LSfitw_multiy_online1500/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.3.alpha",
        'bret24h__Sbret24h_1.5': "/data/beer2/junming/equity_fitting/mlp_model/mlp_LSbalance_sel_LSfitw_multiy_online1500/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.8.alpha",
        'bpret24h__Sbpret24h_1.5': "/data/beer2/junming/equity_fitting/mlp_model/mlp_LSbalance_sel_LSfitw_multiy_online1500/canopus_inference_alpha/terms.YYYYMMDD.sdiv:fit.13.alpha",
    }
    
    for alpha_name, pattern_col in panel_patterns.items():
        pattern, col = pattern_col.split(":")
        if 'e2e_nn_model' in pattern.split(os.sep):
            e2e_alpha_changeI(pattern)

    mds = []
    mds.append(f"### Alpha Source:")  # TODO 设置alpha路径和变换
    mds.extend([f"{k}: {v}<br>" for k, v in panel_patterns.items()])

    ca_node = alpha_xy_node_from_patterns(panel_patterns, label="ca")
    ca_node.node_config["CA.terms"]["MA"] = ca.Na20("MA") if FREQ == 5 else ca.IfElse(ca.IIndex() == ca.C(1), ca.C(0), ca.Na20("MA"))  # MA在9:31未必能算出来
    ca_node.node_config["CA.terms"]["MAOV"] = ca_node.node_config["CA.terms"]["MA"]+ca_node.node_config["CA.terms"]["OV"]
    # ca_node.node_config["CA.terms"]["MAOVe30"] = ca.Ema(ca.Na20("MA")+ca.Na20("OV"), 6, rpii=0)
    # ca_node.node_config["CA.terms"]["CAe30"] = ca.Ema("CA", 6, rpii=0)
    # ca_node.node_config["CA.terms"]["CAFe30"] = ca.Ema("CAF", 6, rpii=0)
    # ca_node.node_config["CA.terms"]["CANe30"] = ca.Na20(ca.Ema("CAN", 6, rpii=0))
    # ca_node.node_config["CA.terms"]["CAFNe30"] = ca.Na20(ca.Ema("CAFN", 6, rpii=0))
    ca_node.node_config["CA.terms"]["CANzs"] = ca.XsZScore(ca_node.node_config["CA.terms"]["CAN"], cutoff=100) * ca.C(0.001)
    for alpha in ['mret24h__Smret24h_1.5', 'bret24h__Sbret24h_1.5', 'bpret24h__Sbpret24h_1.5']:
        ca_node.node_config["CA.terms"][alpha] = ca.XsZScore(ca_node.node_config["CA.terms"][alpha], cutoff=100) * ca.C(0.001)
    ca_node.node_config["CA.terms"]["Smret24h_1.5_h32"] = ca.XsZScore(ca_node.node_config["CA.terms"]["Smret24h_1.5_h32"], cutoff=100) * ca.C(0.001)

    ensemble_weights = {
        # 'en_sel2': {'158_tsconcat_ks60_l2_h64__yhat': 0.2, 'trading90topx__yhat': 1},
        # 'en_mssp': {'fit_mret24h.clip_ks90__yhat': 1, 'fit_sret24h.clip_ks90__yhat': 1, 'fit_spret24h.clip_ks90__yhat': 1},
        'en_mssp_S2': {'fit_mret24h.clip_ks90__yhat': 1, 'fit_sret24h.clip_ks90__yhat': 1, 'fit_spret24h.clip_ks90__yhat': 1, "Smret24h_1.5_h32__yhat": 2},
        "en111CAN": {"mret24h__Smret24h_1.5": 1, 'bret24h__Sbret24h_1.5': 1, "bpret24h__Sbpret24h_1.5": 1, "CANzs": 1},
    }
    for en_name, en_dict in ensemble_weights.items():
        en = ca.C(0)
        for yhat_name, weight in en_dict.items():
            en += ca_node.node_config["CA.terms"][yhat_name.removesuffix("__yhat")] * ca.C(weight)
        en *= ca.C(1/sum(en_dict.values()))
        ca_node.node_config["CA.terms"][en_name] = en
    # ca_node.node_config["CA.terms"]["CANm"] = ca.C(0.5) * ca.Na20("Tree_mret") + ca.C(0.5) * ca.Na20("MLP_mret")
    # ca_node.node_config["CA.terms"]["CANme30"] = ca.Ema(ca.C(0.5) * ca("Tree_mret") + ca.C(0.5) * ca("MLP_mret"), 6, rpii=0)
    # ca_node.node_config["CA.terms"]["CANbe30"] = ca.Ema(ca.C(0.5) * ca("Tree_bret") + ca.C(0.5) * ca("MLP_bret"), 6, rpii=0)
    # ca_node.node_config["CA.terms"]["CANbpe30"] = ca.Ema(ca.C(0.5) * ca("Tree_bpret") + ca.C(0.5) * ca("MLP_bpret"), 6, rpii=0)
    # ca_node.node_config["CA.terms"]["CAFN2e30"] = ca.Ema("CAFN2", 6, rpii=0)
    # ca_node.node_config["CA.terms"]["HEe30"] = ca.Na20(ca.Ema("HE", 6, rpii=0))
    # ca_node.node_config["CA.terms"]["CAFree30"] = ca.Ema("CAFre", 6, rpii=0)
    # ca_node.node_config["CA.terms"]["CAFaddoldsele30"] = ca.Ema("CAFaddoldsel", 6, rpii=0)
    # ovnt_alpha = ca.Na20("MA")+ca.Na20("OV")+ca.Na20(ca.Ema("CAN", 6, rpii=0))+ca.Na20("zuzeg10")+ca.Na20("SR1500_G2548")
    # itrd_alpha = ca.Na20("CAFN")
    # ca_node.node_config["CA.terms"]["combined0"] = ca.C(0.3) * ovnt_alpha + ca.C(0.8) * itrd_alpha
    # ca_node.node_config["CA.terms"]["combined1"] = ca.IfElse(ca.IIndex() < ca.C(24), ca.C(0.8) * itrd_alpha, ca.C(0.3) * ovnt_alpha)
    # ca_node.node_config["CA.terms"]["combined2"] = ca.IfElse(ca.IIndex() < ca.C(24), ca.C(1.2) * itrd_alpha, ca.C(0.3) * ovnt_alpha)
    # ca_node.node_config["CA.terms"]["combined3"] = ca.IfElse(ca.IIndex() < ca.C(24), ca.C(1.5) * itrd_alpha, ca.C(0.3) * ovnt_alpha)
    # ca_node.node_config["CA.terms"]["combined4"] = ca.IfElse(ca.IIndex() < ca.C(24), ca.C(0.8) * itrd_alpha, ca.C(0.5) * ovnt_alpha)
    # ca_node.node_config["CA.terms"]["combined5"] = ca.IfElse(ca.IIndex() < ca.C(24), ca.C(1.2) * itrd_alpha, ca.C(0.5) * ovnt_alpha)
    # ca_node.node_config["CA.terms"]["combined6"] = ca.IfElse(ca.IIndex() < ca.C(24), ca.C(1.5) * itrd_alpha, ca.C(0.5) * ovnt_alpha)
    # ca_node.node_config["CA.terms"]["combined0"] = ca.C(0.2) * (ca.Na20("MA")+ca.Na20("OV")+ca.Ema("CA", 6, rpii=0)) + ca.C(1) * ca.Ema("CAF", 6, rpii=0)
    # ca_node.node_config["CA.terms"]["combined1"] = ca.IfElse(
    #     ca.IIndex() <= ca.C(6),
    #     ca.C(0.2) * (ca.Na20("MA")+ca.Na20("OV")+ca.Ema("CA", 6, rpii=0)) + ca.C(1) * ca.Ema("CAF", 6, rpii=0),
    #     ca.C(0.3) * (ca.Na20("MA")+ca.Na20("OV")+ca.Ema("CA", 6, rpii=0)) + ca.C(0.5) * ca.Ema("CAF", 6, rpii=0),
    # )
    # ca_node.node_config["CA.terms"]["combined2"] = ca.IfElse(
    #     ca.IIndex() <= ca.C(6),
    #     ca.C(0.2) * (ca.Na20("MA")+ca.Na20("OV")+ca.Ema("CA", 6, rpii=0)) + ca.C(1) * ca.Ema("CAF", 6, rpii=0),
    #     ca.C(0.4) * (ca.Na20("MA")+ca.Na20("OV")+ca.Ema("CA", 6, rpii=0)),
    # )
    # combine0 = ca.C(0.35) * (ca.Na20("MA")+ca.Na20("OV")+ca.Na20(ca.Ema("CAN", 6, rpii=0))) + ca.C(1.6) * ca.Na20(ca.Ema("CAFN", 6, rpii=0))
    # combine0 = ca.C(0.5) * ca.Na20("HE") + ca.C(0.5) * ca.Na20("CAFN")
    # ca_node.node_config["CA.terms"]["baseline"] = combine0
    # ca_node.node_config["CA.terms"]["pm_0"] = ca.IfElse(ca.IIndex() < ca.C(24), combine0, ca.C(0))  # 24是13：00：00
    # ca_node.node_config["CA.terms"]["last30m_0"] = ca.IfElse(ca.IIndex() < ca.C(36), combine0, ca.C(0))  # 24是14：00：00
    # ca_node.node_config["CA.terms"]["pm_1.5ovnt"] = ca.IfElse(ca.IIndex() < ca.C(24), combine0, ca.C(1.5) * ca.Na20("CA_ovnt"))  # 24是13：00：00
    # ca_node.node_config["CA.terms"]["last30m_1.5ovnt"] = ca.IfElse(ca.IIndex() < ca.C(36), combine0, ca.C(1.5) * ca.Na20("CA_ovnt"))  # 36是14：00：00
    # ca_node.node_config["CA.terms"]["pm_2ovnt"] = ca.IfElse(ca.IIndex() < ca.C(24), combine0, ca.C(2) * ca.Na20("CA_ovnt"))  # 24是13：00：00
    # ca_node.node_config["CA.terms"]["last30m_2ovnt"] = ca.IfElse(ca.IIndex() < ca.C(36), combine0, ca.C(2) * ca.Na20("CA_ovnt"))  # 36是14：00：00
    # ca_node.node_config["CA.terms"]["pm_3ovnt"] = ca.IfElse(ca.IIndex() < ca.C(24), combine0, ca.C(3) * ca.Na20("CA_ovnt"))  # 24是13：00：00
    # ca_node.node_config["CA.terms"]["last30m_3ovnt"] = ca.IfElse(ca.IIndex() < ca.C(36), combine0, ca.C(3) * ca.Na20("CA_ovnt"))  # 36是14：00：00
    
    # raw_size = {
    #     "MA": 16.30, "OV":14.60, "zuzeg10": 15.80, "zuzeg10bp": 9.00, "zuzeg10sp": 7.60, "CAN": 11.70,
    #     "CAFN": 7.60, "MAOV": 26.80, "CANe30": 10.90, "CAFNe30": 5.90	
    # }
    # update_dict = {}
    # for name, expr in ca_node.node_config["CA.terms"].items():
    #     update_dict[name] = ca.XsZScore(expr, cutoff=100, tail_ratio=0.01) * ca.C(raw_size[name] / 11000)
    # ca_node.node_config["CA.terms"].update(update_dict)

    # panel_name = "smb_ratio"
    # ca_node.node_config["DATA.panels"] += [panel_name]
    # ca_node.node_config[f"DATA.{panel_name}.pattern"] = "/data/beef3/guopeng/research/modify_csi300/smb_ratio/eod.YYYYMMDD.sdiv"
    # ca_node.node_config[f"DATA.{panel_name}.inclusive"] = False
    # ca_node.node_config[f"DATA.{panel_name}.columns"] = ["big_ratio"]
    # ca_node.node_config["CA.terms"]["CAFNadj"] = ca_node.node_config["CA.terms"]["CAFN"] * ca.C(5) * ca.XsMean("big_ratio")

    # TODO:csi300设置CAF adj
    p_value_weights = ['long120_short10_p0.01', 'long120_short10_p0.05', 'long120_short10_p0.1', 'long250_short20_p0.01', 'long250_short20_p0.05', 'long250_short20_p0.1']
    panel_name = "p_value_weights"
    ca_node.node_config["DATA.panels"] += [panel_name]
    ca_node.node_config[f"DATA.{panel_name}.pattern"] = "/data/beef2/junming/data/CAF_trigger/upto20250214/trigger/bod.YYYYMMDD.sdiv"# f"/data/beef2/junming/data/p_value_{UNIV}/bod.YYYYMMDD.sdiv" # "/data/beef2/junming/data/p_value2/bod.YYYYMMDD.sdiv"
    ca_node.node_config[f"DATA.{panel_name}.inclusive"] = True
    ca_node.node_config[f"DATA.{panel_name}.columns"] = p_value_weights
    # for weight in p_value_weights:
    #     ca_node.node_config["CA.terms"][f"CAFN_{weight}"] = ca_node.node_config["CA.terms"]["CAFN"] * ca(weight)
    ca_node.node_config["CA.terms"]["CAFNadj"] = ca_node.node_config["CA.terms"]["CAFN"] * ca('long120_short10_p0.05')

    # panel_name = "approaching_limit_weight"
    # triggers = ['ret_le_0.5', 'ret_le_0.8', 'up_limited']
    # ca_node.node_config["DATA.panels"] += [panel_name]
    # ca_node.node_config[f"DATA.{panel_name}.pattern"] = "/data/beef2/junming/data/approaching_limit_weight/terms.YYYYMMDD.sdiv"
    # combo = ca.C(0.35) * ca_node.node_config["CA.terms"]["MAOV"] + ca.C(0.25) * ca_node.node_config["CA.terms"]["CANe30"] + ca.C(1.2) * ca_node.node_config["CA.terms"]["CAFNe30"]
    # ca_node.node_config["CA.terms"]["combo"] = combo
    # for trigger in triggers:
    #     # ca_node.node_config["CA.terms"][trigger] = ca.IfElse(trigger, ca.XsMean(combo)+ca.C(3)*ca.XsStd(combo), combo)
    #     ca_node.node_config["CA.terms"][trigger] = ca.IfElse(trigger, ca_node.node_config["CA.terms"][f"fitw_{trigger}"], combo)
    #     if trigger == 'ret_le_0.8':
    #         ca_node.node_config["CA.terms"][f"{trigger}_mul0p3"] = ca.IfElse(trigger, ca.C(0.3) * ca_node.node_config["CA.terms"][f"fitw_{trigger}"], combo)
    #         ca_node.node_config["CA.terms"][f"{trigger}_mul0p1"] = ca.IfElse(trigger, ca.C(0.1) * ca_node.node_config["CA.terms"][f"fitw_{trigger}"], combo)
    # mds.extend([f"{k}: {str(v)}<br>" for k, v in ca_node.node_config["CA.terms"].items()])  #  if k not in panel_patterns

    # alphas = ["combo"] + triggers + ["ret_le_0.8_mul0p3", "ret_le_0.8_mul0p1"]
    # alpha_weights = np.eye(len(alphas)).tolist()

    # TODO 设置alpha combo名字
    # g2458
    # alphas = ["MAOV", "CAN", "CAFN"]
    # alpha_weights = [
    #     [0.35, 0.35, 0.6],
    # ]

    # -------------zz1000_midx没细调
    # alphas = ["MAOV", "CAN", "CAFN"]
    # alpha_weights = [
    #     [0.35, 0.25, 0.6],
    # ]
    # alphas = ["MAOV", "CAN", "CAFN", 'fa']
    # alpha_weights = [
    #     [0.35, 0.25, 0.6, 0],
    #     [0.35, 0.25, 0.6, 0.8],
    #     [0, 0, 0, 1],
    #     [0, 0, 0, 2],
    #     [0, 0, 0, 3],
    #     [0, 0, 0, 4],
    #     [0, 0, 0, 5],
    # ]

    # -------------topx-sh50 zz500
    # alphas = ["MAOV", "CAN", "CAFN"]
    # alpha_weights = [
    #     [0.15, 0.15, 0.6],
    # ]

    # -------------csi300
    # alphas = ["MAOV", "CAN", "zuzeg10bpN"]
    # alpha_weights = [
    #     [0.25, 0.1, 0.75],
    # ]
    # alphas = ["MAOV", "zuzeg10bpN", "CAN", 'fa']
    # alpha_weights = [
    #     [0.25, 0.8, 0.1, 0],
    #     [0.25, 0.8, 0.1, 0.2],
    #     [0.25, 0.8, 0.1, 0.4],
    #     [0.25, 0.8, 0.1, 0.6],
    #     [0.25, 0.8, 0.1, 0.8],
    # ]

    # alphas = ["MAOV", "zuzeg10bpN", "CAN", 'Smret24h_1.5_h32', 'en_mssp_S2']
    # alpha_weights = [
    #     [0.25, 0.75, 0.1, 0, 0],
    #     # [0.25, 0.75, 0.1, 0.1, 0],
    #     # [0.25, 0.75, 0.1, 0.2, 0],
    #     # [0.25, 0.75, 0.1, 0.3, 0],
    #     # [0.25, 0.75, 0.1, 0, 0.1],
    #     [0.25, 0.75, 0.1, 0, 0.2],
    #     # [0.25, 0.75, 0.1, 0, 0.3],
    # ]
    # alphas = ["MAOV", "zuzeg10bpN", "CAN", "en111CAN"]
    # alpha_weights = [
    #     [0.25, 0.75, 0.1, 0],
    #     [0.25, 0.75, 0, 0.1],
    #     [0.25, 0.6, 0, 0.2],
    #     [0.25, 0.5, 0, 0.2],
    #     [0.25, 0.6, 0, 0.25],
    #     [0.25, 0.5, 0, 0.25],
    # ]
    alphas = ["MAOV", "zuzeg10bpN", "CAN", "en111CAN", 'en_mssp_S2']
    alpha_weights = [
        [0.25, 0.75, 0.1, 0, 0],
        [0.25, 0.6, 0, 0.2, 0],
        [0.25, 0.75, 0.1, 0, 0.2],
        [0.25, 0.6, 0, 0.2, 0.2],
        # [0.25, 0.6, 0, 0.2, 0.15],
        # [0.25, 0.6, 0, 0.2, 0.25],
    ]
    # alphas.append("CAFN")
    alphas.append("CAFNadj")
    for weights in alpha_weights:
        weights.append(0.6)

    # alphas += [f"CAFN_{weight}" for weight in p_value_weights]
    # n = len(p_value_weights)
    # assert len(alpha_weights) == 1, alpha_weights
    # alpha_weights = np.hstack([np.tile(np.array(alpha_weights[0]), (n, 1)), np.eye(n) * 0.6]).tolist()
    # for wi, weights in enumerate(alpha_weights):
    #     alpha = ca.C(0)
    #     for i, w in enumerate(weights):
    #         alpha += ca.C(w) * ca_node.node_config["CA.terms"][alphas[i]]
    #     ca_node.node_config["CA.terms"][f"alpha{wi}"] = ca.IfElse(
    #         (ca.IIndex() < ca.C(36)) & (ca('long120_short10_p0.05') == ca.C(1)),
    #         ca_node.node_config["CA.terms"]["CAFN"],
    #         alpha
    #     )  # 36是14：00：00
    # alphas = [f"alpha{wi}" for wi in range(len(alpha_weights))]
    # alpha_weights = np.eye(len(alpha_weights)).tolist()
    
    # alphas = ["MAOV", "CANN", "zuzeg10bp", "CAFN"]  # CAFNadj
    # alpha_weights = [
    #     # [0.25, 0.15, 0.6, 0.6], # 1st
    #     [0.25, 0.1, 0.8, 0.6], # 2nd
    #     # [0.25, 0.15, 0.6, 0], # 1st
    #     # [0.25, 0.1, 0.8, 0], # 2nd
    # ]

    # alphas = ["MAOV", "CANN", "zuzeg10bp", "CAFNadj", "CAFNNadj"]  # CAFNadj
    # alpha_weights = [
    #     [0.25, 0.15, 0.6, 0.6, 0], # 1st
    #     [0.25, 0.1, 0.8, 0.6, 0], # 2nd
    #     [0.25, 0.15, 0.6, 0, 0.6], # 1st
    #     [0.25, 0.1, 0.8, 0, 0.6], # 2nd
    # ]

    missing_alphas = np.setdiff1d(alphas, list(ca_node.node_config["CA.terms"].keys())).tolist()
    assert len(missing_alphas) == 0, f"missing alphas: {missing_alphas}"
    combo_names = []
    for wi, weights in enumerate(alpha_weights, start=1):
        combo = ca.C(0)
        combo_name = f"combo{wi}"
        for i, weight in enumerate(weights):
            combo += ca_node.node_config["CA.terms"][alphas[i]] * ca.C(weight)
        ca_node.node_config["CA.terms"][combo_name] = combo
        combo_names.append(combo_name)
        terms = [f"{w} \\cdot {alpha}" for w, alpha in zip(weights, alphas) if w != 0]
        line = f"\\text combo_{wi} = " + " + ".join(terms)
        mds.append(f"$$ {line} $$")
    mds.append("  ")
    mds.append("### Tables:")
    mds.append("  ")
    terms_g = {}
    for name, expr in ca_node.node_config["CA.terms"].items():
        terms_g[f"{name}.g10"] = ca.IfElse((ca.XsRank2(ca.IfElse(ca.Na20('is.active'), expr, ca.C("nan")))>=ca.C(0.8)), ca.C(1), ca.C(0))
    ca_node.node_config["CA.terms"].update(terms_g)
    ca_node.run()
    run_report(ca_node, mds=mds)

    base_SAwHF_sim_config = json.load(open("/data/nfshome/junming/git/junming/Codes/sim/benchmark.SAwHF_zz1000_CA.json"))
    for task in ["SA", "SAwHF"]:  # , "SAwHF"
        aps_node = ApsJsonNode(base_SAwHF_sim_config, label=task)
        aps_node.set_task(task)
        alpha_source = {alpha: f"{ca_node.stage_dir()}/terms.YYYYMMDD.sdiv:{alpha}" for alpha in alphas}
        aps_node.set_alpha_source(alpha_source)
        aps_node.set_alpha_weights([alphas] + alpha_weights)
        aps_node.set_alpha_names(combo_names)
        # TODO 设置临时超参改变
        # aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_theta"] = [0.003, 0.005, 0.007]
        # aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_riskratio"] = 1
        # aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_lambda"] = [10, 20, 30]
        if UNIV in ["csi300", "sh250"]:
            # hs300
            # aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_theta"] = [0.002, 0.003, 0.004]
            # aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_tau"] = [1, 2, 3]
            # aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_lambda"] = [5, 10, 20, 30, 50]
            # aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_riskratio"] = [1, 5]
            aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_theta"] = 0.003 # 0.003
            aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_tau"] = 2
            aps_node.node_config["metainfo"]["env"]["sim_params"]["account"]["tot_cap"] = 500000000.0
        elif UNIV == 'zz1000_midx':
            aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_theta"] = 0.005
            aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_tau"] = 3
            aps_node.node_config["metainfo"]["env"]["sim_params"]["account"]["tot_cap"] = 500000000.0
        elif UNIV == "csi500":
            aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_theta"] = 0.003 # 0.003
            aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_tau"] = 2
            aps_node.node_config["metainfo"]["env"]["sim_params"]["account"]["tot_cap"] = 500000000.0
        elif UNIV in ['topx_midx', "topx_non50"]:
            aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_theta"] = 0.005
            aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["p_tau"] = 3
            aps_node.node_config["metainfo"]["env"]["sim_params"]["account"]["tot_cap"] = 500000000.0
        else:
            raise NotImplementedError(UNIV)
        
        # after_I_params_list = [{"after_I": "14:00:00", "alpha_multiplier": mul, "p_lambda": p_lambda, "p_theta": 0.001, "p_tau": 1} for mul in [0.5, 0] for p_lambda in [50, 100, 200]]
        # aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["after_I_params"] = after_I_params_list
        # between_D_params_list = [
        #     {"start_date": 20240701, "end_date": 20240923},
        #     {"start_date": 20240701, "end_date": 20240923, "alpha_multiplier": 1.2},
        #     {"start_date": 20240701, "end_date": 20240923, "alpha_multiplier": 1.5},
        #     {"start_date": 20240701, "end_date": 20240923, "p_lambda": 5, "p_theta": 0.003, "p_tau": 2},
        #     {"start_date": 20240701, "end_date": 20240923, "p_lambda": 2, "p_theta": 0.001, "p_tau": 1},
        # ]
        # aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"]["param"]["between_D_params"] = between_D_params_list
        # aps_node.node_config["metainfo"]["env"]["nsim_month"] = -1
        # aps_node.node_config["metainfo"]["env"]["START_DATE"] = "20240801"
        aps_node.node_config["metainfo"]["env"]["END_DATE"] = str(END_DATE)  # e2ecombo: up to "20241223"
        if FREQ == 1:
            aps_node.node_config["metainfo"]["env"]["trade_time"] = "09:31:00,09:32:00,09:33:00,09:34:00,09:35:00,09:36:00,09:37:00,09:38:00,09:39:00,09:40:00,09:41:00,09:42:00,09:43:00,09:44:00,09:45:00,09:50:00,09:55:00,10:00:00,10:05:00,10:10:00,10:15:00,10:20:00,10:25:00,10:30:00,10:35:00,10:40:00,10:45:00,10:50:00,10:55:00,11:00:00,11:05:00,11:10:00,11:15:00,11:20:00,11:25:00,13:05:00,13:10:00,13:15:00,13:20:00,13:25:00,13:30:00,13:35:00,13:40:00,13:45:00,13:50:00,13:55:00,14:00:00,14:05:00,14:10:00,14:15:00,14:20:00,14:25:00,14:30:00,14:35:00,14:40:00,14:45:00,14:50:00,14:55:00"
        if use_ipopt:
            aps_node.node_config["metainfo"]["env"]["sim_params"]["optimizers"].update({"useIPOPT": 1, "ipoptOPT": "/data/nfshome/junming/git/aps/mvo/ipopt.opt"})
        
        if UNIV == "csi300":
            univ_params = {"univ": ["hs300"], "short": ["hs300"],}
        elif UNIV == "sh250":
            univ_params = {"univ": ["sh250"], "short": ["sh250"],}
        elif UNIV == "csi500":
            univ_params = {"univ": ["zz500"], "short": ["zz500"],}
        elif UNIV == 'zz1000_midx':
            univ_params = {"univ": ["zz1000", "midx"], "short": ["zz1000"],}
        elif UNIV == "topx_midx":
            univ_params = {"univ": ["topx", "midx"], "short": ["zz500"],}
        elif UNIV == "topx_non50":
            univ_params = {"univ": ["topx_non50"], "short": ["zz500"],}
        else:
            raise NotImplementedError(UNIV)
        aps_node.node_config["metainfo"]["env"]["sim_params"]["account"].update(univ_params)
        aps_node.run()
