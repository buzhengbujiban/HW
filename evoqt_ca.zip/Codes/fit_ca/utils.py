import matplotlib.pyplot as plt
from tqdm import tqdm
import xarray as xr
from joblib import Parallel, delayed
import pandas as pd
import numpy as np
import os, shutil
import time
from typing import List,Tuple,Dict
import panel
import re
from functools import reduce
import pickle

import qr
from qrfitter3.utils import save_df_as_sdiv_daily, read_json, save_json
from qrfitter3.reports.utils import rounds_df_plot
from fit_ca.canopus_scripts.dump_shm import get_run_periods

from jobs.rnodes.rnode import RNode
from canopus_py.rnodes.ca_node import CANode, dump_term_sizes, dump_term_quantile
from canopus_py.rnodes.stats_node import StatsNode
from canopus_py.ca_expr import *
from canopus_py.nb_utils import *
from canopus_py.ca_stats import *
from pattern_helper import *
from online202409 import terms
from qrfitter3.evaluator import fr

TEMP_FOLDER = '/data/beef2/junming/temp_alpha'
univ_active_exst = "/data/beef2/junming/data/univ_active_exst/terms.YYYYMMDD.sdiv"
SDI = ['time', 'date', 'sid']

def extract_para(d, para=None):
    if para is None:
        para = {}
    for k, v in d.items():
        if isinstance(v, dict):
            extract_para(v, para)
        else:
            para[k] = v
    return pd.Series(para)

def get_paras(expt_folder, exclude=[]):
    fit_ids = [folder for folder in os.listdir(expt_folder) if re.match(r"^fit\.\d+$", folder) and folder not in exclude]
    fit_ids = sorted(fit_ids, key=lambda s: int(s.split('.')[1]))
    scenarios = read_json(os.path.join(expt_folder, "scenarios.json"))
    paras = [extract_para(scenarios[fit_id]) for fit_id in fit_ids]
    paras = dict(zip(fit_ids, paras))
    paras = pd.DataFrame(paras).T
    return paras

def get_feature_names(fit_folder):
    if "roll_tasks.csv" in os.listdir(fit_folder):
        feature_names = read_json(os.path.join(fit_folder, "roll.0", "feature_names.json"))
    else:
        feature_names = read_json(os.path.join(fit_folder, "feature_names.json"))
    return feature_names

def get_concat_data(pattern, start_date=None, end_date=None, columns:List[str]=None, return_type="df"):
    dates = get_run_periods(pattern, start_date, end_date)
    files = [pattern.replace("YYYYMMDD", str(date)) for date in dates]
    if columns is None:
        xarrs = [panel.read(file) for file in files]
    else:
        xarrs = [panel.read(file).sel(V=columns) for file in files]
    xarr = xr.concat(xarrs, dim="D")
    if return_type == "xr":
        return xarr
    df = panel.sdiv2df(xarr, order='C')
    return df

def merge_dfs(dfs: list):
    merge_df = dfs[0]
    for df in dfs[1:]:
        merge_df = merge_df.merge(df, on=['time', 'date', 'sid'])
    return merge_df

def get_yhat_df(fit_folder, start_date=None, end_date=None, set_name="test", roll_id:str=None):
    yhat_pattern = "yhat.YYYYMMDD.sdiv"
    files = []
    t0 = time.time()
    if "roll_tasks.csv" in os.listdir(fit_folder):
        if roll_id is None:
            roll_ids = [folder for folder in os.listdir(fit_folder) if folder.startswith("roll.")]
            for roll_id in roll_ids:
                pattern = os.path.join(fit_folder, roll_id, f"y_hat_{set_name}", yhat_pattern)
                dates = get_run_periods(pattern, start_date, end_date)
                files.extend([pattern.replace("YYYYMMDD", str(date)) for date in dates])
        else:  # 比如指定roll_id=roll.0的valid
            pattern = os.path.join(fit_folder, roll_id, f"y_hat_{set_name}", yhat_pattern)
            dates = get_run_periods(pattern, start_date, end_date)
            files.extend([pattern.replace("YYYYMMDD", str(date)) for date in dates])
    else:
        pattern = os.path.join(fit_folder, f"y_hat_{set_name}", yhat_pattern)
        dates = get_run_periods(pattern, start_date, end_date)
        files.extend([pattern.replace("YYYYMMDD", str(date)) for date in dates])
    #yhats = Parallel(n_jobs=16, backend="loky")(delayed(panel.read)(file) for file in files)
    yhats = [panel.read(file) for file in files]
    t1 = time.time()
    yhat_xr = xr.concat(yhats, dim="D")
    t2 = time.time()
    yhat_df = panel.sdiv2df(yhat_xr, order='C')
    t3 = time.time()
    # print(f"read yhat{t1-t0:.1f}s, xr concat{t2-t1:.1f}s, sdiv2df{t3-t2:.1f}s")
    return yhat_df

from qrfitter3.evaluator import rcor, cor, pcor, fr, FR, PFR
def FR_long(x, y, w):
    return 1e4 * np.sum(np.maximum(x, 0)*y*w) / np.sqrt(np.sum(x*x*w)) / np.sqrt(np.sum(w))
def FR_short(x, y, w):
    return 1e4 * np.sum(np.minimum(x, 0)*y*w) / np.sqrt(np.sum(x*x*w)) / np.sqrt(np.sum(w))
    
def evaluate(yhat_df: pd.DataFrame, name='yhat', yname="y", D="date", include_ls=False) -> pd.Series:
    x = yhat_df[name].values
    y = yhat_df[yname].values
    w = yhat_df['weight'].values
    res = {}
    digit = 1
    res["cor"] = round(cor(x, y, w), digit)
    res["pcor"] = round(pcor(x, y, w), digit)
    res["rcor"] = round(rcor(x, y, w), digit)
    res["fr"] = round(fr(x, y, w), digit)
    res["FR"] = round(FR(x, y, w), digit)
    xy_series = yhat_df.groupby(D).apply(lambda x: (x[name]*x[yname]*x['weight']).mean(), include_groups=False)
    res["SR"] = round(xy_series.mean() / xy_series.std() * np.sqrt(252), digit)
    if include_ls:
        res['FR_long'] = round(FR_long(x, y, w), digit)
        res['FR_short'] = round(FR_short(x, y, w), digit)
    res = pd.Series(res)
    return res

def calc_res(fit_folder, start_date=None, end_date=None):
    try:
        if "y_hat_test.tbl" in os.listdir(fit_folder):
            yhat_df = qr.tbl_read(os.path.join(fit_folder, "y_hat_test.tbl"))
        else:   
            yhat_df = get_yhat_df(fit_folder, start_date=start_date, end_date=end_date)
    except Exception as e:
        res = None
    else:
        res = evaluate(yhat_df)
    return res

def compare_fit(expt_folder, start_date=None, end_date=None, include_para=True, exclude=[]):
    fit_ids = [folder.replace("main", "-1") for folder in os.listdir(expt_folder) if folder.startswith("fit.") and folder not in exclude]
    fit_ids = sorted(fit_ids, key=lambda s: int(s.split('.')[1]))
    results = Parallel(n_jobs=min(len(fit_ids), 64), verbose=0)(delayed(calc_res)(
        os.path.join(expt_folder, fit_id), start_date=start_date, end_date=end_date
    ) for fit_id in fit_ids)
    results = dict(zip(fit_ids, results))
    results = {fit_id: res for fit_id, res in results.items() if res is not None}
    results = pd.DataFrame(results).T

    paras = get_paras(expt_folder, exclude=exclude)
    results = pd.concat([results, paras], axis=1)
    results.index = [int(x[4:]) for x in results.index]
    return results

def calc_res_MT(fit_folder, start_date=None, end_date=None):
    yhat_df = get_yhat_df(fit_folder, start_date=start_date, end_date=end_date)
    y_names = [col[5:] for col in yhat_df.columns if col.startswith("yhat_")]
    results = {}
    for y_name in y_names:
        results[y_name] = evaluate(yhat_df, name="yhat_"+y_name, yname="y_"+y_name)
    results = pd.DataFrame(results).T
    return results

def compare_fit_MT(expt_folder, start_date=None, end_date=None, include_para=True, exclude=[]):
    paras = get_paras(expt_folder, exclude=exclude)
    print("==========================paras==========================")
    print(paras)
    fit_ids = [folder for folder in os.listdir(expt_folder) if folder.startswith("fit.") and folder not in exclude]
    fit_ids = sorted(fit_ids, key=lambda s: int(s.split('.')[1]))
    results = Parallel(n_jobs=min(len(fit_ids), 64), verbose=1)(delayed(calc_res_MT)(
        os.path.join(expt_folder, fit_id), start_date=start_date, end_date=end_date
    ) for fit_id in fit_ids)
    results = pd.concat(results, axis=0, keys=fit_ids)
    return results

def combine_yhat(yhats, target_y_in:str=None):
    if target_y_in is None:
        target_y_in = list(yhats.keys())[0]
    combined = yhats[target_y_in][['time', 'date', 'sid', 'y', 'weight', 'yhat']].copy()
    combined.rename(columns={'yhat': target_y_in}, inplace=True)
    for name, yhat_df in yhats.items():
        if name != target_y_in:
            combined = combined.merge(yhat_df[['time', 'date', 'sid', 'yhat']].rename(columns={"yhat": name}), on=['time', 'date', 'sid'])
    return combined

def combine_yhat_new(yhats, wy:list=None, yhat_names=['alpha', 'yhat', "x"]):
    first_name = list(yhats.keys())[0]
    combined = yhats[first_name]
    combined = combined.rename(columns={yhat_name: first_name for yhat_name in yhat_names})
    for name, yhat_df in yhats.items():
        if name != first_name:
            combined = combined.merge(yhat_df.rename(columns={yhat_name: name for yhat_name in yhat_names}), on=['time', 'date', 'sid'])
    combined = combined[['time', 'date', 'sid']+list(yhats.keys())]
    if wy:
        for df in wy:
            combined = combined.merge(df, on=['time', 'date', 'sid'], how='left')  # w里有一些sid缺失
    return combined

def get_yhats(fit_dict, set_name="test", target_y_in=None, combine=True):
    yhats = Parallel(n_jobs=len(fit_dict))(delayed(get_yhat_df)(fit_folder, set_name=set_name) for fit_folder in fit_dict.values())
    yhats = dict(zip(fit_dict.keys(), yhats))
    if combine:
        combined = combine_yhat(yhats, target_y_in=target_y_in)
        print("----------------------describe----------------------")
        print(combined[list(fit_dict.keys())].describe())
        print("----------------------corr----------------------")
        plot_corr(combined[list(fit_dict.keys())].corr().round(2))
        #print(combined[list(fit_dict.keys())].corr().round(2))
    else:
        combined = None
    return yhats, combined

def evaluate_combined_yhat(combined: pd.DataFrame, names:list=None, exclude_days:List[str]=None, yname="y", include_ls=False):
    if names is None:
        names = [x for x in combined.columns if x not in ['time', 'date', 'sid', yname, 'weight']]
    if exclude_days:
        combined = combined[~combined['date'].isin(exclude_days)].copy()
    results = Parallel(n_jobs=len(names))(delayed(evaluate)(combined[['time', 'date', 'sid', yname, 'weight', name]], name=name, yname=yname, include_ls=include_ls) for name in names)
    results = dict(zip(names, results))
    # results = {}
    # for name in names:
    #     results[name] = evaluate(combined[['time', 'date', 'sid', 'y', 'weight', name]], name=name)
    return pd.DataFrame(results).T

def plot_corr(corr: pd.DataFrame, h_max=10):
    import seaborn as sns
    import matplotlib.pyplot as plt
    h = min(len(corr), h_max)
    w = int(h*2/3)
    plt.figure(figsize=(h, w))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap='coolwarm', square=True, cbar_kws={"shrink": .5})
    plt.title('Correlation Matrix Heatmap')
    plt.show()

def ridge_ensemble(combined_valid, combined_test, features, weight="weight", target='y', alpha=0.1, ensemble_name='', ols=False):
    from sklearn.linear_model import Ridge, LinearRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline
    w1_combined_valid = combined_valid[combined_valid[weight] == 1].copy()  # TODO:之后兼容float的w
    X_train, y_train = w1_combined_valid[features], w1_combined_valid[target]
    X_test = combined_test[features]
    if ols:
        model = LinearRegression(fit_intercept=False).fit(X_train, y_train)
        coefficients = model.coef_
        coefficients = np.where(coefficients < 0, 0, coefficients)
        ensembled = np.dot(X_test, coefficients)
    else:
        X_scaler = StandardScaler(with_mean=False)
        X_train = X_scaler.fit_transform(X_train)
        y_scaler = StandardScaler(with_mean=False)
        y_train = y_scaler.fit_transform(y_train.to_frame()).squeeze()
        model = Ridge(alpha=alpha, fit_intercept=False).fit(X_train, y_train)
        coefficients = model.coef_ / X_scaler.scale_ * y_scaler.scale_
        coefficients = np.where(coefficients < 0, 0, coefficients)
        ensembled = np.dot(X_test, coefficients)
    coefficients = pd.Series(coefficients, index=features)
    print(f"---------{ensemble_name}:coefficients---------")
    print(coefficients)
    
    return ensembled

def get_ridge_coefficients(combined_valid, features, weight="weight", target='y', alpha=0.1, ensemble_name='', ols=False, nonnegative=True):
    from sklearn.linear_model import Ridge, LinearRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline
    w1_combined_valid = combined_valid[combined_valid[weight] == 1].copy()
    X_train, y_train = w1_combined_valid[features], w1_combined_valid[target]
    if ols:
        model = LinearRegression(fit_intercept=False).fit(X_train, y_train)
        coefficients = model.coef_
    else:
        X_scaler = StandardScaler(with_mean=False)
        X_train = X_scaler.fit_transform(X_train)
        y_scaler = StandardScaler(with_mean=False)
        y_train = y_scaler.fit_transform(y_train.to_frame()).squeeze()
        model = Ridge(alpha=alpha, fit_intercept=False).fit(X_train, y_train)
        coefficients = model.coef_ / X_scaler.scale_ * y_scaler.scale_
    if nonnegative:
        coefficients = np.where(coefficients < 0, 0, coefficients)
    coefficients = pd.Series(coefficients, index=features)
    print(f"---------{ensemble_name}:coefficients---------")
    print(coefficients)
    
    return coefficients

def get_ridge_ensemble(combined_test, coefficients:pd.Series):
    return combined_test[coefficients.index] @ coefficients

def save_temp_alpha(panel_name, df):
    """df中具有多列alpha，可能还会有y和weight"""
    folder = os.path.join(TEMP_FOLDER, panel_name)
    save_df_as_sdiv_daily(df, folder, S='sid', D='date', I='time')

def calc_stats(
    node_name, pattern_dict:dict|list, start_date=20230101, end_date=20240731, exclude_days:List[int]=[20240201,20240202,20240205,20240206,20240207,20240208],
    rename_col=True, labels=["mret24h"], alpha_columns:List[str]=None, rename_map={},
    univ=None, wgt:dict={"w_c1": None}, num_groups=0, raw_only=False, extra_transform=[], output_ii=None, require_terms=False,
    external_label_dict:Dict[str,str]={}, vd_start=None, os_start=None,
    use_senti_weight=False, refresh_data=False, wyweighted_pow=None, wy="mret24h", condition_separate=False, ensemble_weights:Dict[str,dict]={},
    slurm_cfg=None, para_spec=120,
    rnode_root="/data/beef2/junming/rroot", chain_name="calc_stats"
):

    CANode.DEFAULT_CA_BINARY = "/data/beef2/bin/unstable/canopus"
    node_dir = os.path.join(rnode_root, chain_name, node_name)
    if os.path.exists(node_dir):
        shutil.rmtree(node_dir)
    base_config = CANode.base_config()
    ca_node = CANode(base_config, rnode_root=rnode_root, chain_name=chain_name, label=node_name, clean_dir_name=True)
    # 加载univ:注意univ能影响后续的zs或者group
    if univ is None:
        ca_node.node_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    elif univ in ["sh50", "csi300", "csi500", "zz1000"]:
        ca_node.node_config["CA.univ"] = f"/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv:{univ}"
    elif univ in ["topx", "midx", "smlx", "botx"]:
        ca_node.node_config["CA.univ"] = f"/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv:{univ}"
    elif univ in ["sz", "sh"]:
        ca_node.node_config["CA.univ"] = f"/data/beef2/junming/universe/{univ}.csv"
    else:
        raise NotImplementedError(f"Unknown Univ: {univ}")
    # 加载wgt:注意wgt不能影响后续的zs或者group
    # panel_name = "index"
    # ca_node.node_config["DATA.panels"] += [panel_name]
    # ca_node.node_config[f"DATA.{panel_name}.pattern"] = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"  # 这东西每天更新，适合做business pattern
    # ca_node.node_config[f"DATA.{panel_name}.inclusive"] = False
    # ca_node.node_config[f"DATA.{panel_name}.columns"] = ["sh50", "csi300", "csi500", "zz1000"]  # , "zz2000" 24年1月之后没有
    
    panel_name = "st_panel"
    ca_node.node_config["DATA.panels"] += [panel_name]
    ca_node.node_config[f"DATA.{panel_name}.pattern"] = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/D/eod/sid_st/st_YYYYMMDD.sdiv"  # 往前能到2007年
    ca_node.node_config[f"DATA.{panel_name}.inclusive"] = False
    ca_node.node_config[f"DATA.{panel_name}.columns"] = ["st"]

    # panel_name = "univ_x"
    # x_columns = ["topx", "midx"]  # (注意：smlx从20180101之后才开始生成, 且在20180102, 20200203没有)  # , "smlx", "botx"
    # ca_node.node_config["DATA.panels"] += [panel_name]
    # ca_node.node_config[f"DATA.{panel_name}.pattern"] = "/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv"  # 往前能到2007年
    # ca_node.node_config[f"DATA.{panel_name}.inclusive"] = False
    # ca_node.node_config[f"DATA.{panel_name}.columns"] = x_columns

    if use_senti_weight:
        senti_pattern = "/data/beef3/guopeng/alter_data/news_senti/senti-YYYYMMDD.sdiv"    
        ca_node.node_config["DATA.panels"] += ["senti"]
        ca_node.node_config["DATA.senti.pattern"] = senti_pattern
        ca_node.node_config["DATA.senti.lb_days"] = 10
        wgt = (ca.C(1)-ca("st"))*ca.Na20(ca.FFill(ca.IfElse(ca("senti")==ca.C(0), ca.C("nan"), ca.C(1)), 96, rpii=2))
        w_terms = {'w_c1': wgt}
    else:
        w_terms = {}
        for name, w in wgt.items():
            w = ca.C(1) if w is None else ca.Sign(ca.Na20(w))  # 暂时只支持上面的index和univ_x
            w *= (~ca.Na20("st"))
            if wyweighted_pow:
                w *=ca.Na20(ca.NumPow(ca.Abs(wy), wyweighted_pow))
            w_terms[name] = w
    if output_ii is not None:  # e.g. list(range(1,49,2))
        ii_wgt = ca.C(0)
        for ii in output_ii:
            ii_wgt = ii_wgt | (ca.IIndex() == ca.C(ii))
        for name, w in w_terms.items():
            w = w & ii_wgt
    ca_node.node_config["STATS.w_terms"] = w_terms  # wt.csv Canopus背后还会自动乘上is.active

    # 加载backward label
    # panel_name = "Y.backward"
    # backwardret_pattern = "/data/nas2Data/chinaEquityData/statarb/midfreq/Y_V5/YYYYMMDD.sdiv"
    # ca_node.node_config["DATA.panels"] += [panel_name]
    # ca_node.node_config[f"DATA.{panel_name}.pattern"] = backwardret_pattern
    # backwardret_columns = [f for f in read_columns_from_pattern(backwardret_pattern) if f.endswith("b")]
    # ca_node.node_config[f"DATA.{panel_name}.columns"] = backwardret_columns

    # 加载label
    CAv24Path = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels"
    y_pattern = os.path.join(CAv24Path, "Y/Y_V5/terms.YYYYMMDD.sdiv")
    w_pattern = os.path.join(CAv24Path, "I/fq5m/BB/terms.YYYYMMDD.sdiv")
    ca_node.node_config["EVENTS.busdate_pattern"] = y_pattern  # "/data/beef2/data/CA.v24.1001/CNEQ/Panels/Y/Y_V5/terms.YYYYMMDD.sdiv"  # Y 没啥问题 跟原来对的上
    ca_node.node_config["DATA.panels"] += ["5min"]
    ca_node.node_config["DATA.5min.pattern"] = w_pattern
    ca_node.node_config["DATA.5min.columns"] = ["is.active"]
    ca_node.node_config["DATA.panels"] += ["Y"]
    ca_node.node_config["DATA.Y.pattern"] = y_pattern
    y_columns = read_columns_from_pattern(y_pattern)
    ca_node.node_config["DATA.Y.columns"] = y_columns
    y_terms = {y: y for y in y_columns}
    y_terms['bpret24h'] = ca("mret24h") - ca("bret24h")
    y_terms['mret_ovnt'] = ca("mret1o") - ca("mret0e")
    y_terms['mret24h1h'] = ca("mret24h") - ca("mret1h")
    y_terms['bpret1h'] = ca("mret1h") - ca("bret1h")
    thresholds = [0.07]
    for threshold in thresholds:
        term = "mret24h"
        y_terms[f"{term}.clip{threshold:.2f}"] = ca.Na20(ca.IfElse(ca(term) > ca.C(threshold), ca.C(threshold), ca.IfElse(ca(term) < ca.C(-threshold), ca.C(-threshold), ca(term))))
    for panel_name, pattern in external_label_dict.items():
        ca_node.node_config["DATA.panels"] += [panel_name]
        ca_node.node_config[f"DATA.{panel_name}.pattern"] = pattern
        columns = read_columns_from_pattern(pattern)
        assert len(np.intersect1d(columns, list(y_terms.keys()))) == 0, f"duplicated y columns: {columns}"
        y_terms.update({y: ca(y) for y in columns})
    ca_node.node_config["STATS.y_terms"] = {k: v for k, v in y_terms.items() if k in labels}
    ca_node.node_config["OUTPUT.terms"] = require_terms
    ca_node.node_config["OUTPUT.stats"] = True

    # 加载yhat/alpha
    yhats = []
    if isinstance(pattern_dict, list):
        pattern_dict = {panel_name: os.path.join(TEMP_FOLDER, panel_name, "yhat.YYYYMMDD.sdiv") for panel_name in pattern_dict}  # 默认以panel_name命名的alpha文件夹都放在TEMP_FOLDER下
    sizes_dict_all = {}
    quantiles_median_list = []
    for panel_name, pattern in pattern_dict.items():
        if ":" in pattern:
            pattern, columns = pattern.split(":")
            columns = columns.split(",")
        else:
            columns = [col for col in read_columns_from_pattern(pattern) if col not in ['y', 'weight']]
        if "mad" in extra_transform:
            assert not rename_col, "conflict: mad and rename_col"
            try:
                sizes_dict = dump_term_sizes(pattern, dates=None, refresh_data=refresh_data, mad=True)
            except FileNotFoundError:
                try:
                    sizes_dict = dump_term_sizes(pattern, dates=None, refresh_data=True, mad=True)
                except PermissionError:
                    sizes_dict = dump_term_sizes(pattern, dates=None, refresh_data=True, dump_files=False, mad=True)
            sizes_dict_all |= sizes_dict  # 如果是这样的话就不允许rename_col了注意！！feature不能有重名的
        if "normal" in extra_transform:
            assert not rename_col, "conflict: normal and rename_col"
            try:
                quantiles_median, nuniques_series = dump_term_quantile(pattern, dates=None, refresh_data=refresh_data, dump_files=True, bins=100)
            except FileNotFoundError:
                try:
                    quantiles_median, nuniques_series = dump_term_quantile(pattern, dates=None, refresh_data=True, dump_files=True, bins=100)
                except PermissionError:
                    quantiles_median, nuniques_series = dump_term_quantile(pattern, dates=None, refresh_data=True, dump_files=False, bins=100)
            quantiles_median_list.append(quantiles_median)
        
        if alpha_columns is not None:
            columns = [col for col in columns if col in alpha_columns]
        ca_node.node_config["DATA.panels"] += [panel_name]
        ca_node.node_config[f"DATA.{panel_name}.pattern"] = pattern
        ca_node.node_config[f"DATA.{panel_name}.columns"] = columns
        I = panel.get_coords(find_files_from_pattern(pattern)[-1], "I")
        if len(I) == 1:
            inclusive = False if I[0] == "00:00:00" else True
            ca_node.node_config[f"DATA.{panel_name}.inclusive"] = inclusive
        if rename_col:  # 主要是有多个panel的时候可能会重名
            renamed_columns = [f"{panel_name}__{col}" for col in columns]
            ca_node.node_config[f"DATA.{panel_name}.column_masks"] = renamed_columns
            yhats.extend(renamed_columns)
        else:
            yhats.extend(columns)
    if quantiles_median_list:
        quantiles_median = pd.concat(quantiles_median_list, axis=0)
    
    yhats = {rename_map.get(yhat, yhat): yhat for yhat in yhats}  # list to dict to fit in yhat_ensemble

    for rename, ensemble_weight in ensemble_weights.items():
        yhat_ensemble = ca.C(0)
        for yhat, weight in ensemble_weight.items():
            yhat_ensemble += ca.C(weight) * ca.Na20(yhat)
        yhats[rename] = yhat_ensemble

    # 对alpha进行处理
    wgt = (~ca.Na20("st"))  # 下面zs和group要用
    for yhat_name, yhat in yhats.items():  # string yhat names
        if raw_only:
            ca_node.node_config["CA.terms"][yhat_name] = ca.Na20(yhat)
        elif condition_separate: # 可以多写一些condition_separate方法
            ca_node.node_config["CA.terms"][yhat_name] = ca.Na20(yhat)
            ca_node.node_config["CA.terms"][f"{yhat_name}.pos"] = ca.Na20(ca.IfElse(ca(yhat) > ca.C(0), ca(yhat), ca.C(0)))
            ca_node.node_config["CA.terms"][f"{yhat_name}.neg"] = ca.Na20(ca.IfElse(ca(yhat) < ca.C(0), ca(yhat), ca.C(0)))
        else:
            ca_node.node_config["CA.terms"][f"{yhat_name}.raw"] = ca.Na20(yhat)
            ca_node.node_config["CA.terms"][f"{yhat_name}.zs"] = ca.Na20(ca.XsZScore(ca.IfElse(ca("is.active") & wgt, yhat, ca.C("nan"))))
            if "mad" in extra_transform:
                ca_node.node_config["CA.terms"][f"{yhat_name}.mad"] = ca.Na20(ca.Clip(ca(yhat) / ca.C(sizes_dict_all[yhat]), 5))
            if "normal" in extra_transform:
                bin_edges = quantiles_median.loc[yhat]
                if bin_edges.isna().all():  # nunique个数不够算不出bin
                    pass # term = ca.Na20(yhat)
                else:
                    ca_node.node_config["CA.terms"][f"{yhat_name}.normal"] = ca.Na20(ca.NormalDist(ca(yhat), bin_edges.tolist()))
                    
        # ca_node.node_config["CA.terms"][f"{yhat}.dm"] = ca.Na20(ca(yhat) - ca.XsMean(ca.IfElse(ca("is.active") & wgt, yhat, ca.C("nan"))))
    ## 多空分组
    if num_groups:
        for yhat_name, yhat in yhats.items():
            for g in range(1, num_groups+1):
                start = ca.C(-1 + 2*(g-1)/num_groups)
                end = ca.C(-1 + 2*g/num_groups)
                fea1 = ca(yhat) * ca.IfElse(ca("is.active") & wgt, ca.C(1), ca.C("nan"))
                ca_node.node_config["CA.terms"][f"{yhat_name}.g{g}"] = ca.IfElse((ca.XsRank2(fea1)>start)&(ca.XsRank2(fea1)<=end), ca.C(1), ca.C(0))

    # run CANode & StatsNode
    ca_node.set_run_dates()
    start_date = 0 if start_date is None else int(start_date)
    end_date = 30000000 if end_date is None else int(end_date)
    ca_node.run_periods = [i for i in ca_node.run_periods if i >= start_date and i <= end_date and i not in exclude_days]
    if ca.use_nugg_cache:
        ca_node.node_config["CA.nuggs"] = ca.get_nugg_cache()
    ca_node.run(para_spec=para_spec, slurm_cfg=slurm_cfg)
    StatsNode({
        "wgts":list(ca_node.node_config["STATS.w_terms"].keys()),
        "vd_start":vd_start,
        "os_start":os_start,
    }, xy_pattern=ca_node).run(print_df=True, refresh_data=True, corr_threshold=0.7).run()


def show_stats(
    node_name, select:str|list="raw",
    diffs:List[Tuple[str, str]]=[], labels=["mret24h"], alpha_columns:List[str]=None, show_g=[1, 10],
    return_dfss=False, stats_dir='/data/beef2/junming/rroot/calc_stats/'
):
    find_dates_from_pattern.cache_clear()
    panel_stats_dir = os.path.join(stats_dir, node_name)
    newest_stats = max([f for f in os.listdir(panel_stats_dir) if re.match(r'\d{3}\.stats', f)])
    df, ss, _ = StatsNode.read_stats(os.path.join(panel_stats_dir, newest_stats))
    if return_dfss:
        return df, ss
    
    alpha_index = df.index.get_level_values(2).unique()
    if select is None:
        if alpha_columns is not None:
            alpha_index = np.array([f for f in alpha_columns if f in alpha_index])
        df = df[df.index.get_level_values(2).isin(alpha_index)]
        df = df[df.index.get_level_values(0) == "w_c1"]
        for label in labels:
            label_df = df[df.index.get_level_values(1) == label]
            if alpha_columns is None:
                cpdf(label_df.sort_values(("is", "FR"), ascending=False, key=abs), 200)
            else:
                cpdf(label_df.loc[(slice(None), slice(None), alpha_index)], 200)
            ss_all = sel_all_series(ss, x=alpha_index.tolist(), w=["w_c1"], y=[label], p="all")
            plot_stats(ss_all)
            
    else:  # 有raw或者zs等后缀
        if alpha_columns is not None:
            alpha_index = alpha_index[np.array([a[:a.rfind(".")] in alpha_columns for a in alpha_index])]
        
        alpha_g = alpha_index[np.array([bool(re.match(r"g\d", x[-1])) for x in alpha_index.str.split(".")])].tolist()
        alpha_processed = {}
        other_processed_methods = set([x.split(".")[-1] for x in np.setdiff1d(alpha_index, alpha_g)])  # {'raw', 'zs'}
        for method in other_processed_methods:
            alpha_processed[method] = alpha_index[alpha_index.str.endswith(f'.{method}')].tolist()
        
        num_groups = len(alpha_g) / len(alpha_processed["raw"])  # 注意这里默认每个alpha都在calc的时候分了一样的组数
        if show_g is not None:
            alpha_g = [a for a in alpha_g if int(a.split(".")[-1][1:]) in show_g]
        alpha_processed["g"] = alpha_g
        if isinstance(select, str):
            select = [select]
        alpha_select = []
        for sel in select:
            alpha_select.extend(alpha_processed[sel])
        
        df.loc[df.index.get_level_values(2).isin(alpha_g),  ('is', 'FR')] *= np.sqrt(num_groups)
        
        df = df[df.index.get_level_values(2).isin(alpha_select)]
        df = df[df.index.get_level_values(0) == "w_c1"]
            
        for label in labels:
            cpdf(df[df.index.get_level_values(1) == label], 200)
            series_diffs = []
            for (alpha1, alpha2) in diffs:
                for sel in select:
                    alpha1_s_name, alpha2_s_name = f"{alpha1}.{sel}", f"{alpha2}.{sel}"
                    s_diff = series_diff(ss, alpha1_s_name, alpha2_s_name, "all", "w_c1", label)
                    series_diffs.append(s_diff)
                    print(f"Diff({alpha1_s_name}, {alpha2_s_name}) Sharpe: {SR(s_diff): .2f}")
            ss_all = sel_all_series(ss, x=alpha_select, w=["w_c1"], y=[label], p="all")
            ss_g = [s * np.sqrt(num_groups) for s in ss_all if s.name.split("|")[0] in alpha_g]
            ss_other = [s for s in ss_all if s.name.split("|")[0] not in alpha_g]
            plot_stats(ss_g+ss_other + series_diffs)


def SR(df_FR_series):
    return (df_FR_series.mean() / df_FR_series.std() * np.sqrt(252))

def plot_rounds(expt_folder, fit_id):
    df = qr.tbl_read(os.path.join(expt_folder, fit_id, "lgb_rounds.tbl"))
    rounds_df_plot(df, cor_cols=['train_cor', 'valid_cor'])


# =============================below codes are related to alpha combine, both mlp and tree=============================
def alpha_combine(expt_folder, panel_name=None):
    map_dict = {
        0: "base",
        1: "add",
        2: "cofit",
    }
    fit_dict = {}
    for id, name in map_dict.items():
        fit_id = f"fit.{id}"
        fit_dict[name] = os.path.join(expt_folder, fit_id)
    
    yhats = Parallel(n_jobs=len(fit_dict))(delayed(get_yhat_df)(fit_folder, set_name="test") for fit_folder in fit_dict.values())
    yhats = dict(zip(fit_dict.keys(), yhats))
    combined = combine_yhat(yhats, target_y_in="base")
    yhats_valid = Parallel(n_jobs=len(fit_dict))(delayed(get_yhat_df)(fit_folder, set_name="valid") for fit_folder in fit_dict.values())
    yhats_valid = dict(zip(fit_dict.keys(), yhats_valid))
    combined_valid = combine_yhat(yhats_valid, target_y_in="base")
    
    to_ensemble = ["base", "add"]
    # combined['eqw_ensemble'] = combined[to_ensemble].mean(axis=1)
    combined['ridge_ensemble'] = ridge_ensemble(combined_valid, combined, features=to_ensemble)

    if panel_name:
        save_temp_alpha(panel_name, df=combined)

def alpha_combine_univ(expt_folder, panel_name=None, univ="topx"):
    map_dict = {
        0: "base",
        1: "add",
        2: "cofit",
        3: f"base_{univ}",
        4: f"add_{univ}",
        5: f"cofit_{univ}",
    }
    fit_dict = {}
    for id, name in map_dict.items():
        fit_id = f"fit.{id}"
        fit_dict[name] = os.path.join(expt_folder, fit_id)
    
    yhats = Parallel(n_jobs=len(fit_dict))(delayed(get_yhat_df)(fit_folder, set_name="test") for fit_folder in fit_dict.values())
    yhats = dict(zip(fit_dict.keys(), yhats))
    yhats_valid = Parallel(n_jobs=len(fit_dict))(delayed(get_yhat_df)(fit_folder, set_name="valid") for fit_folder in fit_dict.values())
    yhats_valid = dict(zip(fit_dict.keys(), yhats_valid))
    
    combined = combine_yhat({name: yhat for name, yhat in yhats.items() if not name.endswith(f"_{univ}")}, target_y_in="base")
    combined_valid = combine_yhat({name: yhat for name, yhat in yhats_valid.items() if not name.endswith(f"_{univ}")}, target_y_in="base")
    to_ensemble = ["base", "add"]
    combined['ridge_ensemble']= ridge_ensemble(combined_valid, combined, features=to_ensemble)
    if panel_name:
        save_temp_alpha(panel_name, df=combined)

    combined_univ = combine_yhat({name: yhat for name, yhat in yhats.items() if name.endswith(f"_{univ}")}, target_y_in=f"base_{univ}")
    combined_valid_univ = combine_yhat({name: yhat for name, yhat in yhats_valid.items() if name.endswith(f"_{univ}")}, target_y_in=f"base_{univ}")
    to_ensemble = [f"base_{univ}", f"add_{univ}"]
    combined_univ[f'ridge_ensemble_{univ}'] = ridge_ensemble(combined_valid_univ, combined_univ, features=to_ensemble)
    if panel_name:
        save_temp_alpha(f"{panel_name}_{univ}", df=combined_univ)

def alpha_combine_bothsel(expt_folder, panel_name=None):
    map_dict = {
        0: "base",
        1: "sel1",
        2: "cofit_sel1",
        3: "sel2",
        4: "cofit_sel2",
    }
    fit_dict = {}
    for id, name in map_dict.items():
        fit_id = f"fit.{id}"
        fit_dict[name] = os.path.join(expt_folder, fit_id)
    
    yhats = Parallel(n_jobs=len(fit_dict))(delayed(get_yhat_df)(fit_folder, set_name="test") for fit_folder in fit_dict.values())
    yhats = dict(zip(fit_dict.keys(), yhats))
    combined = combine_yhat(yhats, target_y_in="base")
    yhats_valid = Parallel(n_jobs=len(fit_dict))(delayed(get_yhat_df)(fit_folder, set_name="valid") for fit_folder in fit_dict.values())
    yhats_valid = dict(zip(fit_dict.keys(), yhats_valid))
    combined_valid = combine_yhat(yhats_valid, target_y_in="base")

    to_ensemble_dict = {
        "ridge_sel1": ["base", "sel1"],
        "ridge_sel2": ["base", "sel2"],
    }
    to_ensemble = ["base", "add"]
    for name, to_ensemble in to_ensemble_dict.items():
        combined[name] = ridge_ensemble(combined_valid, combined, features=to_ensemble)
    eval_res = evaluate_combined_yhat(combined)
    print(eval_res)

    if panel_name:
        save_temp_alpha(panel_name, df=combined)

def tree_alpha_combine(expts=None, panel_name=None):
    alpha_combine_folder = "/data/bees1/safe/junming/equity_fitting/expt_res_tree_exclude202002/alpha_combine"
    if expts is None:
        expts = [x for x in os.listdir(alpha_combine_folder) if x not in ["ca1999"]]
    fit_dict = {}
    fit_dict["ca1999"] = os.path.join(alpha_combine_folder, "ca1999", "fit.0")
    fit_map = dict(zip([f'fit.{i}' for i in range(2)], ['add', 'cofit']))
    for expt in expts:
        expt_folder = os.path.join(alpha_combine_folder, expt)
        fit_ids = sorted([folder for folder in os.listdir(expt_folder) if folder.startswith("fit.")])
        for fit_id in fit_ids:
            fit_dict[f"{expt}.{fit_map[fit_id]}"] = os.path.join(expt_folder, fit_id)

    yhats = Parallel(n_jobs=len(fit_dict))(delayed(get_yhat_df)(fit_folder, set_name="test") for fit_folder in fit_dict.values())
    yhats = dict(zip(fit_dict.keys(), yhats))
    combined = combine_yhat(yhats, target_y_in="ca1999")
    
    yhats_valid = Parallel(n_jobs=len(fit_dict))(delayed(get_yhat_df)(fit_folder, set_name="valid") for fit_folder in fit_dict.values())
    yhats_valid = dict(zip(fit_dict.keys(), yhats_valid))
    combined_valid = combine_yhat(yhats_valid, target_y_in="ca1999")

    to_ensemble_dict = {}
    for expt in expts:
        to_ensemble_dict[f"{expt}.ridge"] = ["ca1999", f"{expt}.add"]
    for name, to_ensemble in to_ensemble_dict.items():
        combined[name] = ridge_ensemble(combined_valid, combined, features=to_ensemble)
    eval_res = evaluate_combined_yhat(combined)
    print(eval_res)

    if panel_name:
        save_temp_alpha(panel_name, df=combined)


import numba
numba.set_num_threads(min(numba.get_num_threads(), 120))
@numba.jit(nopython=True, parallel=True)
def pearson_corr_numba(X):
    n, k = X.shape
    corr_matrix = np.empty((k, k))
    for i in numba.prange(k):
        for j in range(i, k):
            xi = X[:, i]
            xj = X[:, j]
            # 创建掩码，过滤掉 NaN 值
            mask = ~np.isnan(xi) & ~np.isnan(xj)
            # 检查是否有有效数据点
            if np.sum(mask) == 0:
                corr_matrix[i, j] = np.nan
                corr_matrix[j, i] = np.nan
                continue
            xi_filtered = xi[mask]
            xj_filtered = xj[mask]
            # 计算相关系数
            xi_mean = np.mean(xi_filtered)
            xj_mean = np.mean(xj_filtered)
            numerator = np.sum((xi_filtered - xi_mean) * (xj_filtered - xj_mean))
            denominator = np.sqrt(np.sum((xi_filtered - xi_mean)**2) * np.sum((xj_filtered - xj_mean)**2))
            # 如果分母为 0，相关系数为 NaN
            if denominator == 0:
                corr = np.nan
            else:
                corr = numerator / denominator
            corr_matrix[i, j] = corr
            corr_matrix[j, i] = corr  # 对称性
    return corr_matrix.astype(np.float32)

def get_FR_corr_matrix(ss, x=None, w='w_c1', y="mret24h", p="is"):
    FR_series = pd.concat(sel_all_series(ss, x=x, w=[w], y=[y], p=p), axis=1)
    term_names = [l[0] for l in FR_series.columns.str.split("|")]
    FR_series.columns = term_names
    FR_series = np.sign(FR_series.sum()) * FR_series
    corr_matrix = pearson_corr_numba(FR_series.values)
    corr_matrix = pd.DataFrame(corr_matrix, index=FR_series.columns, columns=FR_series.columns)
    return corr_matrix

def select_features(sorted_features, corr_matrix, corrmax_threhold=0.7, print_interval:int=None, corrsum_threshold:float=None):
    # sorted_features = df_y.abs().sort_values(sort_method, ascending=False).index.tolist()
    # sorted_features = (0.5*filtered["is_FR"].abs().rank()+0.5*filtered["is_SR"].abs().rank()).sort_values(ascending=False).index.tolist()
    selected = []
    neglected = [False] * len(sorted_features)
    for i, feature1 in tqdm(enumerate(sorted_features)):
        if print_interval is not None and i % print_interval == 0:
            print(f"Selected {len(selected)}/{i}")
        if neglected[i]:
            continue
        if corrsum_threshold is not None and (corr_matrix.loc[feature1, selected] > corrsum_threshold).sum() > 5:
            neglected[j] = True
            continue
        selected.append(feature1)
        for j in range(i+1, len(sorted_features)):
            if neglected[j]:
                continue
            feature2 = sorted_features[j]
            corr = corr_matrix.loc[feature1, feature2]
            if corr > corrmax_threhold:
                neglected[j] = True
    print(f"Selected {len(selected)}/{i}")
    return selected