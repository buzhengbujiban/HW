import os
import copy
import subprocess
from pathlib import Path
from typing import Dict, List, Tuple
import re
from functools import reduce
import pandas as pd
import numpy as np
import copy

from jobs.rnodes.rnode import RNode
from pattern_helper import *
from qrfitter3.utils import read_json, save_json
from qrfitter3.generator import gen_fitting_tasks


def pattern_to_5min(file_pattern):
    pattern_ori = r"^/dev/shm/YYYYMMDD\.([\w\.]+)\.sdiv$"
    match = re.match(pattern_ori, file_pattern)
    if match:
        captured_content = match.group(1)
        if captured_content.endswith(".5min"):
            file_pattern_5min = file_pattern
        else:
            file_pattern_5min = f"/dev/shm/YYYYMMDD.{captured_content}.5min.sdiv"
    else:
        raise NotImplementedError(f'unknown file pattern: {file_pattern}')
    return file_pattern_5min

def pattern_to_5min_d_concat(file_pattern, inference_file_pattern):
    pattern_ori = "^/dev/shm/(\d{8}_\d{8})\.([\w\.]+)_d_concat\.sdiv$"
    match_for_file_name = re.match(pattern_ori, file_pattern)
    if match_for_file_name:
        captured_file_name = match_for_file_name.group(2)
    else:
        raise NotImplementedError(f'unknown file pattern: {file_pattern}')
    match_for_start_end = re.match(pattern_ori, inference_file_pattern)
    if match_for_start_end:
        captured_start_end = match_for_start_end.group(1)
    else:
        raise NotImplementedError(f'unknown inference file pattern: {inference_file_pattern}')
    file_pattern_5min = f"/dev/shm/{captured_start_end}.{captured_file_name}.5min_d_concat.sdiv"
    return file_pattern_5min 

def configurate_inference_dataset(inference_dataset_config, out_dir, to_5min_files=[]):
    # 如果inference_dataset还有什么配置是需要从dataset_config里infer出来的，就往这里继续加
    fit_task_cfg = read_json(os.path.join(out_dir, "fit_task_cfg.json"))
    dataset_config = fit_task_cfg["dataset"]
    if isinstance(dataset_config["x_files"], str) and "d_concat" in dataset_config["x_files"]:  # 代表这是tree的dataset
        for file in to_5min_files:
            assert file in inference_dataset_config, f"{file} missing in inference_dataset_config"  # 需要start_end在x_file里
            file_pattern = dataset_config[file]
            inference_file_pattern = inference_dataset_config[file]
            file_5min = pattern_to_5min_d_concat(file_pattern, inference_file_pattern)
            inference_dataset_config[file] = file_5min
    else:
        for files in to_5min_files:
            file_patterns = dataset_config[files]
            if isinstance(file_patterns, str): # y_file, w_file
                files_5min = pattern_to_5min(file_patterns)
            else:  # x_files
                files_5min = [pattern_to_5min(pattern) for pattern in file_patterns]
            inference_dataset_config[files] = files_5min
    successors = ["use_x_names", "group_name", "fit_y"]  # 自行添加要从dataset config中继承的东西
    for successor in successors:
            if successor in dataset_config:
                inference_dataset_config[successor] = dataset_config[successor]

class QRFitter3Node(RNode):
    class_id = "qf3"

    def __init__(self, node_config, *args, **kwargs):
        super().__init__(node_config, *args, **kwargs)
        self.pid = os.getpid()
        print(f"pid: {self.pid}")

    def update_config(self, node_config):
        super().__init__(node_config)

    @staticmethod
    def base_dataset_config(is5min=False, Xname="X", Yname="Y", Wname="W", exclude202002=True):
        is5min_suffix = ".5min" if is5min else ""
        x_files = [f"/dev/shm/YYYYMMDD.{Xname}{is5min_suffix}.sdiv"]
        y_file = f"/dev/shm/YYYYMMDD.{Yname}{is5min_suffix}.sdiv"
        w_file = f"/dev/shm/YYYYMMDD.{Wname}{is5min_suffix}.sdiv"

        dataset_config = {
            "class"                : "MLPDataset",
            "x_files"              : x_files,
            "y_file"               : y_file,
            "w_file"               : w_file,
            "fit_y"                : "mret24h",
            "fit_w"                : "is.active",
            "dataset_type"         : "tabular"
        }
        if exclude202002:
            dataset_config["exclude_dates"] = [{"start_date": "20200201", "end_date": "20200231"}]
        return copy.deepcopy(dataset_config)

    @staticmethod
    def base_tsdataset_config(is5min=False, Xname="X", Yname="Y", Wname="W", ks=25, exclude202002=False):
        if is5min:
            x_files = [f"/dev/shm/YYYYMMDD.{Xname}.5min.sdiv"]
            y_file = f"/dev/shm/YYYYMMDD.{Yname}.5min.sdiv"
            w_file = f"/dev/shm/YYYYMMDD.{Wname}.5min.sdiv"
            dilation = 2
        else:  # downsampled
            x_files = [f"/dev/shm/YYYYMMDD.{Xname}.sdiv"]
            y_file = f"/dev/shm/YYYYMMDD.{Yname}.sdiv"
            w_file = f"/dev/shm/YYYYMMDD.{Wname}.sdiv"
            dilation = 1

        dataset_config = {
            "class"                : "TSDataset",
            "x_files"              : x_files,
            "y_file"               : y_file,
            "w_file"               : w_file,
            "fit_y"                : "mret24h",
            "fit_w"                : "is.active",
            "dataset_type"         : "ts",
            "kernel_size"          : ks,
            "dilation"             : dilation,
        }
        if exclude202002:
            dataset_config["exclude_dates"] = [{"start_date": "20200201", "end_date": "20200231"}]
        return copy.deepcopy(dataset_config)

    @staticmethod
    def base_concat_dataset_config(start_end, is5min=False, Xname="X", Yname="Y", Wname="W"):
        is5min_suffix = ".5min" if is5min else ""
        dataset_config = {
            "x_files": f"/dev/shm/{start_end}.{Xname}{is5min_suffix}_d_concat.sdiv",
            "y_file": f"/dev/shm/{start_end}.{Yname}{is5min_suffix}_d_concat.sdiv",
            "w_file": f"/dev/shm/{start_end}.{Wname}{is5min_suffix}_d_concat.sdiv",
            "fit_y": "mret24h",
            "fit_w": "is.active"
        }
        return copy.deepcopy(dataset_config)

    @staticmethod
    def base_roller_config(croll=False, croll_pro=False):
        if croll:
            config = {
                "roll_type":         "croll",
                "start_date":        "20180101",
                "end_date":          "20240729",
                "test_start_month":  "202301"
            }
            if croll_pro:
                config.update({
                    "roll_type": "croll_pro",
                    'croll_folds': 5,
                    'valid_window': 6,
                })
            return copy.deepcopy(config)
        else:
            config = {
                "roll_type":         "vanilla",
                "start_date":        "20180101",
                "end_date":          "20240729",
                "test_start_month":  "202301",
                "test_window":       4,
                "valid_window":      6,
                'reverse_valid':     False,
                "gen_next_month":    False,
                "max_train_months":  60
            }
            return copy.deepcopy(config)
    
    @staticmethod
    def base_task_config(testing=False, oos=20232024):
        if testing:
            config = {
                "train": {"start_date": "20220301", "end_date": "20220715"},
                "valid": {"start_date": "20220716", "end_date": "20220722"},
                "test": {"start_date": "20230101", "end_date": "20230120"}
            }
        elif oos == 20232024:
            config = {
                "train": {"start_date": "20180101", "end_date": "20220631"},
                "valid": {"start_date": "20220701", "end_date": "20221231"},
                "test": {"start_date": "20230101", "end_date": "20240729"},
            }
        else:
            raise NotImplementedError
        return copy.deepcopy(config)
    
    @staticmethod
    def base_fitter_config(model="mlp3", enable_RR=True, eval_fraction=1):
        config = {
            "class": "MLPLearner",
            "device_id": "0",

            "model_config": {
                "class": "MLPNetwork",
                "kwargs": {
                    "hidden_size": [256, 64, 16],
                    "dropout_rate": 0.3,
                    "act_fn": "ELU",
                    "bn": False
                }
            },
            "batch_size": 16384,
            "max_epoch": 100,
            "loss_fn": ["wmse", {}],
            "optimizer": ["AdamW", {}],
            "learning_rate": 0.0001,
            "lr_scheduler": ["CosineAnnealingLR", {"T_max": 20}],
            "l2_decay": 0,
            "eval_start_epoch": 0,
            "eval_fraction": eval_fraction,
            "earlystop_config": {
                "enable": True,
                "monitor_key": "valid/cor",
                "mode": "max",
                "patience": 3*eval_fraction,
                "delta": 0.1
            },
            "evaltrain": False,
            "evaltest": False,
            "interpret": False,
            "inference_last_hidden": False,

            "enable_tensorboard": True,
            "dataloader_workers": 3
        }
        
        if enable_RR:
            config["randomrestart_config"] = {
                "enable": True,
                "restart_num": 2,
                "earlystop_config": config.pop("earlystop_config")
            }
            # config["randomrestart_config"]["earlystop_config"]["patience"] = 4
        if model == "mlp_base":
            pass    
        elif model == "mlp3":
            config.update({
                "model_config": {
                    "class": "MLP3",
                    "kwargs": {
                        "hidden_size": [256, 64, 16],
                        "dropout_rate": 0.3,
                        "act_fn": "ELU",
                        "norm_type": "BatchNorm1d",
                        "lastlayer_reg": False
                    }
                },
                "l2_decay": 1,
                "learning_rate": 0.00005,
                "lr_scheduler": [None, {}],
            })
        elif model == "resnet":
            config.update({
                "model_config": {
                    "class": "ResiConnectionMLP",
                    "kwargs": {
                        "act_fn": "ELU",
                        "norm_type": "BatchNorm1d",
                        "dropout_rate": 0.3,
                        "hidden_size": 128,
                        "num_hidden": 5,
                        "lastlayer_reg": False
                    }
                },
                "l2_decay": 1,
                "learning_rate": 0.00005,
                "lr_scheduler": [None, {}],
            })
        elif model == "mlp_seq":
            config.update({
                "model_config": {
                    "class": "MLPSequential",
                    "kwargs": {
                        "hidden_size": [256, 64, 16],
                        "dropout_rate": 0.3,
                        "act_fn": "ELU",
                        "bn": True
                    }
                },
                "l2_decay": 1,
                "learning_rate": 0.00005,
                "lr_scheduler": [None, {}],
            })
        elif model == "mlp_split_input":
            config.update({
                "model_config": {
                    "class": "MLPSplitInput",
                    "kwargs": {
                        "hidden_size": [256, 64, 16],
                        "dropout_rate": 0.3,
                        "act_fn": "ELU",
                        "norm_type": "BatchNorm1d",
                        "lastlayer_reg": False
                    }
                },
                "l2_decay": 1,
                "learning_rate": 0.00005,
                "lr_scheduler": [None, {}],
            })
        elif model == "TE":
            config.update({
                "model_config": {
                    "class": "TransformerEncoder",
                    "kwargs": {
                        "d_model": 64,
                        "dropout_rate": 0.3,
                        "nhead": 4,
                    }
                },
                "batch_size": 16384,
            })
        elif model == "GRU":
            config.update({
                "model_config": {
                    "class": "RNNNetwork",
                    "kwargs": {
                        "hidden_size": 32,
                        "dropout_rate": 0.5,
                        "num_layers": 1,
                        "type": "GRU",
                    }
                },
                "batch_size": 8192,
                "l2_decay": 3,
                "learning_rate": 5e-05,
                "dataloader_workers": 5
            })
            config["randomrestart_config"]["restart_num"] = 2
            config["randomrestart_config"]["earlystop_config"]["patience"] = 2
        elif model == "TSMLP":
            config.update({
                "model_config": {
                    "class": "TSMLP",
                    "kwargs": {
                        "d_hidden": 64,
                        "d_time_pattern": 16,
                        "dropout_rate": 0.3,
                        "act_fn": "GELU",
                    }
                },
                "batch_size": 16384,
            })
        elif model.startswith("lgb"):
            config = {
                "class": "lgbRegressor",
                "para_dict": {
                    'task': 'train',
                    'device': 'cpu',
                    'num_threads': 180,
                    'boosting_type': 'gbdt',
                    'objective': 'regression',
                    'metric': 'custom',
                    'learning_rate': 0.05,
                    'verbose': -1,
                    'feature_fraction': 0.7,  # if you set it to 0.8, LightGBM will select 80% of features before training each tree
                    'bagging_fraction': 0.9,
                    'bagging_freq': 2,  # 0 means disable bagging; k means perform bagging at every k iteration. Every k-th iteration, LightGBM will randomly select bagging_fraction * 100 % of the data to use for the next k iterations
                    'max_depth': 6,
                    'num_leaves': 64,
                    'num_iterations': 3000,
                    'min_child_samples': 20,  # minimal number of data in one leaf， an approximation based on the Hessian
                    'min_child_weight': 0.001,  # minimal sum hessian in one leaf.
                    'reg_alpha': 0.5,  # L1
                    'reg_lambda': 1  # L2
                },
                "useExistModel": False,
                "do_evaluate": False,
            }
            if model == 'lgbnew':
                config["para_dict"].update({
                    "learning_rate": 0.01,
                    "bagging_fraction": 0.5,
                    "feature_fraction": 0.5,
                    "bin_construct_sample_cnt": 3000000,
                    "min_data_in_bin": 50000,
                    "min_child_samples": 2000,
                })
        else:
            raise ValueError(f"unknown model: {model}")
        return copy.deepcopy(config)
    
    @staticmethod
    def base_inference_fitter_config(model="mlp"):
        if model == "mlp":
            config = {
                "class": "MLPLearner",
                "device_id": "0",
                "batch_size": 16384,
                "dataloader_workers": 3,
                "loss_fn": ["wmse", {}],
            }
        elif model == "lgb":
            config = {
                "class": "lgbRegressor",
                'para_dict': {},
                "useExistModel": True
            }
        else:
            raise NotImplementedError(f"Unknown model type: {model}")
        return copy.deepcopy(config)
    
    @staticmethod
    def base_inference_task_config(task, set_name='test', testing=False):
        if testing:
            config = {
                "task": task,
                "period": {"start_date": "20220101", "end_date": "20220131"},
                "set_name": set_name
            }
        else:
            period = {"start_date": "20230101", "end_date": "20240729"}
            config =  {
                "task": task,
                "period": period,
                "set_name": set_name
            }
        return copy.deepcopy(config)

    def gen_tasks(self, **kwargs):
        cfg_path = os.path.join(self.stage_dir(), 'fitting_cfg.json')
        save_json(self.node_config, cfg_path)
        os.chmod(cfg_path, 0o700)
        gen_fitting_tasks(self.node_config, workspace_dir=self.stage_dir(), **kwargs)

    def cmd_file_path(self):
        return self.stage_dir() / 'all_fit_jobs.sh'

    def run_internal(self, para_spec="2", dryrun=False):
        commands_log_file = self.stage_dir() / "logs"
        os.makedirs(commands_log_file, exist_ok=True)
        os.chmod(commands_log_file, 0o700)
        cmd = f"cat {self.cmd_file_path()} | run-parallel -j {para_spec} -w {commands_log_file} -k"
        if dryrun:
            print(cmd)
            return cmd
        subprocess.run(cmd, shell=True, text=True)

    def run_inference(self, para_spec="2", gpus:list[str]=None, dryrun=False):
        expt_folder = self.stage_dir()
        #fit_batch_map = self.get_fit_batch_map(expt_folder)
        fitroll_idx_config = self.node_config.get("fitroll_idx", {})
        fit_idx = fitroll_idx_config.get("fit", None)
        roll_idx = fitroll_idx_config.get("roll", None)

        inference_tasks_jsons = []
        fit_ids = [folder for folder in os.listdir(expt_folder) if folder.startswith("fit.")]
        if fit_idx is not None:
            fit_ids = [fit_id for fit_id in fit_ids if fit_id in fit_idx]
        for fit_id in fit_ids:
            fit_folder = os.path.join(expt_folder, fit_id)
            if "roll_tasks.csv" in os.listdir(fit_folder):
                roll_ids = [folder for folder in os.listdir(fit_folder) if folder.startswith("roll.")]
                if roll_idx is not None:
                    roll_ids = [roll_id for roll_id in roll_ids if roll_id in roll_idx]
                for roll_id in roll_ids:
                    outdir = os.path.join(fit_folder, roll_id)
                    inference_task = copy.deepcopy(self.node_config)
                    inference_task["task"]["outdir"] = outdir
                    if gpus is not None:  # gpus to use are specified
                        task_idx = len(inference_tasks_jsons)
                        gpu_idx = task_idx % len(gpus)
                        device_id = gpus[gpu_idx]
                        inference_task["fitter"]["device_id"] = device_id
                    configurate_inference_dataset(inference_task["inference_dataset"], outdir)
                    out_inference_job_file = os.path.join(outdir, 'inference_task_cfg.json')
                    save_json(inference_task, out_inference_job_file)
                    inference_tasks_jsons.append(out_inference_job_file)
            else:
                outdir = fit_folder
                inference_task = copy.deepcopy(self.node_config)
                inference_task["task"]["outdir"] = outdir
                if gpus is not None:  # gpus to use are specified
                    task_idx = len(inference_tasks_jsons)
                    gpu_idx = task_idx % len(gpus)
                    device_id = gpus[gpu_idx]
                    inference_task["fitter"]["device_id"] = device_id
                configurate_inference_dataset(inference_task["inference_dataset"], outdir)
                out_inference_job_file = os.path.join(outdir, 'inference_task_cfg.json')
                save_json(inference_task, out_inference_job_file)
                os.chmod(out_inference_job_file, 0o700)
                inference_tasks_jsons.append(out_inference_job_file)
        
        inference_jobs_file = os.path.join(expt_folder, 'all_inference_jobs.sh')
        with open(inference_jobs_file, 'w') as out_file:
            for task_json in inference_tasks_jsons:
                cmd_line = 'python /data/nfshome/junming/git/qrfitter3/qrfitter3/apps/run_inference_task.py %s' % (task_json)
                out_file.write(cmd_line)
                out_file.write('\n')
        print('inference jobs file written to: %s' % inference_jobs_file)

        commands_log_file = self.stage_dir() / "inference_logs"
        os.makedirs(commands_log_file, exist_ok=True)
        os.chmod(commands_log_file, 0o700)
        cmd = f"cat {inference_jobs_file} | run-parallel -j {para_spec} -w {commands_log_file} -k"
        if dryrun:
            print(cmd)
            return cmd
        subprocess.run(cmd, shell=True, text=True)
        

if __name__ == "__main__":
    RNode.GLOBAL_TASKNAME = Path(__file__).stem
    qf_config = read_json(os.path.expanduser('~/git/qrfitter3/run_example/fitting_cfg.json'))
    del qf_config["fitting_name"]
    del qf_config["fitting_root_dir"]
    qf3 = QRFitter3Node(qf_config)
    qf3.gen_tasks()
    qf3.run()
    print(qf3)
