from qrfitter3.rnodes.qrfitter3_node import *

def get_extra_tasks():
    rets = ["mret"]  # "mret", "bret", "bpret"
    parts = ["0itrd", "1o"]  # "0itrd", "ovnt", "1o", "1itrd", "itrd", "ovnt_res", "itrd_res", "1e1o"
    
    y_file_name = "Y"
    extra_file_name = "X.BarraExp"
    external_input_size = 53
    extra_tasks = [
        {
            "dataset": {
                # "fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv",
                "x_files": ["/dev/shm/YYYYMMDD.X.sdiv", f"/dev/shm/YYYYMMDD.{extra_file_name}.sdiv"],
                "dataset_type": "xs"
            },
            "inference_dataset": {
                # "fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv",
                "x_files": ["/dev/shm/YYYYMMDD.X.5min.sdiv", f"/dev/shm/YYYYMMDD.{extra_file_name}.5min.sdiv"],
                "dataset_type": "xs"
            },  # 需要更改inference dataset(如有)的fit_y，否则y_hat_test里的y都是mret24h；如没有inference dataset则要把这一行注释掉
            "fitter":{
                "model_config":{
                    "class": "ExternalAttention",
                    "kwargs": {
                        "external_input_size": external_input_size,
                        "d_model": d,
                        "nhead": nhead,
                        "dim_feedforward": [d],
                        "num_layers": num_layers,
                        "dropout_rate": 0.3,
                        "norm_type": "LayerNorm",
                    }
                },
                "batch_size": 1,  # 一个截面一个样本
                "l2_decay": 5,
                "optimizer": ["AdamW", {}]
            }
        }
        for num_layers in [1, 2, 3] \
            for d in [128, 256] \
                for nhead in [1, 2, 4]
    ]
    return extra_tasks


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002"
RNode.GLOBAL_TASKNAME = "xs_attn"

dataset_config = QRFitter3Node.base_dataset_config(exclude202002=True)
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config()
task_config = QRFitter3Node.base_task_config(oos=2023)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
extra_tasks_config = get_extra_tasks()

# fitter_config["max_epoch"] = 1

fitting_name = "hs2_regularized"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    "extra_tasks": extra_tasks_config,

}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)

qf3.gen_tasks(gpus=[str(i) for i in range(1,5)])  # [str(i) for i in range(4,8)]
print(f"pid: {os.getpid()}")
qf3.run(para_spec="18")