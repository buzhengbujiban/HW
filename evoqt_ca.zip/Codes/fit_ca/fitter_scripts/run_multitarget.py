from fit_ca.qrfitter3_node import *

def get_MLPMT_config():
    return {
        "class": "MLPMT",
        "kwargs": {
            "hidden_size": [256, 64, 16],
            "dropout_rate": 0.3,
            "act_fn": "ELU",
            "norm_type": "BatchNorm1d",
            "lastlayer_reg": False
        }
    }

def get_MMOE_config():
    return {
        "class": "MMoE",
        "kwargs": {
            "n_expert": 4,
            "expert_hidden": [256, 64],
            "tower_hidden": [16],
            "use_gate": True,
            "dropout_rate": 0.3,
            "act_fn": "ELU",
            "norm_type": "BatchNorm1d",
        }
    }

def get_grid_hs_MMOE():
    return {
        "fitter":{
            "model_config": {
                "kwargs": {
                    "n_expert": [2, 3, 4],
                    "expert_hidden": [[256, 64], [128, 32]],
                    "tower_hidden": [[16], []],
                    "use_gate": [True, False],
                }
            }
        }
    }

def get_grid_tasks():
    grid_tasks = {
        "fitter":{
            "equal_Yw": [True, False]
        },
    }
    return grid_tasks


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
RNode.GLOBAL_TASKNAME = "multitarget"

dataset_config = QRFitter3Node.base_dataset_config()
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp3")
task_config = QRFitter3Node.base_task_config(oos=2023)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
grid_tasks_config = get_grid_hs_MMOE()

dataset_config["fit_y"] = ["mret24h", "bpret24h", "bret24h"]
inference_dataset_config["fit_y"] = ["mret24h", "bpret24h", "bret24h"]
fitter_config["class"] = "MultiTargetLearner"
fitter_config.update({
    "model_config": get_MMOE_config(),
})
fitter_config["loss_fn"] = ["wmse_mt", {}]
fitter_config["earlystop_config"] = {
    "enable": True,
    "monitor_key": "valid/loss",
    "mode": "min",
    "patience": 5,
}
fitter_config["randomrestart_config"] = {
    "enable": True,
    "restart_num": 3,
    "earlystop_config": fitter_config.pop("earlystop_config")
}
# fitter_config["equal_Yw"] = True
# fitter_config["max_epoch"] = 1

fitting_name = "MMoE_barra3_RR_hs"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    # "roller": roller_confg,
    "grid_tasks": grid_tasks_config,
    # "extra_tasks": extra_tasks_config
    
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks(gpus=[str(i) for i in range(2)])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="24")