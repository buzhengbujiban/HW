# from qrfitter3.rnodes.qrfitter3_node import *
from fit_ca.qrfitter3_node import *
from fit_ca.canopus_scripts.dump_shm import prepare_shm


def get_extra_tasks(x_file_list:List[str|List[str]], grid_label="mret24h"):
    if grid_label == "mret24h":
        y_file_name = "Y"
        labels = ["mret24h"]
    elif grid_label == "barra":
        y_file_name = "Y"
        labels = ["mret24h", "bret24h", "bpret24h"]
    elif grid_label == "ori.barra":
        y_file_name = "Y.ori"
        labels = ["mret24h", "bret24h", "bpret24h"]
    elif grid_label == "OI":
        y_file_name = "Y"
        rets = ["mret", "bret", "bpret"]
        parts = ["24h", "_1o"]
        labels = [f"{ret}{part}" for ret in rets for part in parts]
    elif grid_label == "tradeimb":
        y_file_name = "Y.tradeimb"
        labels = ["sign_vol_24h.1d", "sign_vol_24h.zs.1d", "sign_vol_24h_v2.1d", "sign_vol_24h_v2.zs.1d"]
    elif grid_label == "Y.clip":
        y_file_name = "Y.clip"
        labels = ["mret24h", "mret24h.clip"]
    else:
        raise NotImplementedError

    extra_tasks = []
    for y in labels:
        for x_file_names in x_file_list:
            if isinstance(x_file_names, str):
                x_file_names = [x_file_names]
            x_files = [f"/dev/shm/YYYYMMDD.{x_file_name}.sdiv" for x_file_name in x_file_names] 
            x_files_inference = [f"/dev/shm/YYYYMMDD.{x_file_name}.5min.sdiv" for x_file_name in x_file_names] 
            y_file = f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv"
            y_file_inference = f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv"
            extra_tasks.append({
                "dataset": {"fit_y": y, "x_files": x_files, "y_file": y_file},
                "inference_dataset": {"fit_y": y, "x_files": x_files_inference, "y_file": y_file_inference}
            })
    return extra_tasks

def get_extra_tasks_sampling_weight(batch_fit=False):
    rets = ["mret", "bret", "bpret"]  # "mret", "bret", "bpret"
    parts = ["0itrd", "ovnt", "1o", "1itrd", "itrd"]  # "0itrd", "ovnt", "1o", "1itrd", "itrd", "ovnt_res", "itrd_res"
    sampling_weights = ["w_op1", "w_mh1", "w_ed1", "w_op2", "w_mh2", "w_ed2"]  # "w_op1", "w_mh1", "w_ed1", "w_op2", "w_mh2", "w_ed2"
    
    extra_tasks = [
        {
            "dataset": {"fit_y": y, "sampling_w": w},
            "inference_dataset": {"fit_y": y,  "sampling_w": w}  # 需要更改inference dataset(如有)的fit_y，否则y_hat_test里的y都是mret24h；如没有inference dataset则要把这一行注释掉
        }
        for y in [f"{ret}_{part}" for ret in rets for part in parts] for w in sampling_weights
    ]
    return extra_tasks

def get_extra_tasks_embeddingMLP():
    rets = ["mret"]  # "mret", "bret", "bpret"
    parts = ["0itrd", "1o"]  # "0itrd", "ovnt", "1o", "1itrd", "itrd", "ovnt_res", "itrd_res", "1e1o"
    
    y_file_name = "Y.OI"
    w_file_name = "W.period8"
    w_n = 8
    extra_tasks = [
        {
            "dataset": {
                "fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv",
                "x_files": ["/dev/shm/YYYYMMDD.X.sdiv", f"/dev/shm/YYYYMMDD.{w_file_name}.sdiv"]
            },
            "inference_dataset": {
                "fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv",
                "x_files": ["/dev/shm/YYYYMMDD.X.5min.sdiv", f"/dev/shm/YYYYMMDD.{w_file_name}.5min.sdiv"]
            },  # 需要更改inference dataset(如有)的fit_y，否则y_hat_test里的y都是mret24h；如没有inference dataset则要把这一行注释掉
            "fitter":{
                "model_config":{
                    "class": "EmbeddingMLP",
                    "kwargs": {
                        "embedding_input_size": w_n,
                        "hidden_size": [256, 64, 16],
                        "embedding_loc": embedding_loc,
                        "embedding_method": embedding_method,
                        "embedding_size": [256, 64, 16][embedding_loc]  # 只对concat方法起作用
                    }
                }
            }
        }
        for y in [f"{ret}_{part}" for ret in rets for part in parts] \
            for embedding_method in ["add", "multiply", "concat"] \
                for embedding_loc in [0, 1, 2]
    ]
    extra_tasks.extend([
        {
            "dataset": {"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv"},
            "inference_dataset": {"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv"}  # 需要更改inference dataset(如有)的fit_y，否则y_hat_test里的y都是mret24h；如没有inference dataset则要把这一行注释掉
        }
        for y in [f"{ret}_{part}" for ret in rets for part in parts]  # ["mret1h", "mret24h", "bret24h", "bpret24h", "bret5e"]
    ])
    return extra_tasks

def get_extra_tasks_FiLMMLP():
    rets = ["mret"]  # "mret", "bret", "bpret"
    parts = ["0itrd"]  # "0itrd", "ovnt", "1o", "1itrd", "itrd", "ovnt_res", "itrd_res", "1e1o"
    
    y_file_name = "Y.OI"
    w_file_name = "W.period2"
    w_n = 3
    extra_tasks = [
        {
            "dataset": {
                "fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv",
                "x_files": ["/dev/shm/YYYYMMDD.X.sdiv", f"/dev/shm/YYYYMMDD.{w_file_name}.sdiv"]
            },
            "inference_dataset": {
                "fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv",
                "x_files": ["/dev/shm/YYYYMMDD.X.5min.sdiv", f"/dev/shm/YYYYMMDD.{w_file_name}.5min.sdiv"]
            },  # 需要更改inference dataset(如有)的fit_y，否则y_hat_test里的y都是mret24h；如没有inference dataset则要把这一行注释掉
            "fitter":{
                "model_config":{
                    "class": "FiLMMLP",
                    "kwargs": {
                        "embedding_input_size": w_n,
                        "hidden_size": [256, 64, 16],
                        "embedding_loc": embedding_loc,
                        "film_num_hidden": film_num_hidden
                    }
                }
            }
        }
        for y in [f"{ret}_{part}" for ret in rets for part in parts] \
            for film_num_hidden in [0, 1, 2, 3] \
                for embedding_loc in [0, 1, 2]
    ]
    extra_tasks.extend([  # 加个base mlp
        {
            "dataset": {"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv"},
            "inference_dataset": {"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv"}  # 需要更改inference dataset(如有)的fit_y，否则y_hat_test里的y都是mret24h；如没有inference dataset则要把这一行注释掉
        }
        for y in [f"{ret}_{part}" for ret in rets for part in parts]  # ["mret1h", "mret24h", "bret24h", "bpret24h", "bret5e"]
    ])
    return extra_tasks

def get_extra_tasks_DRM():
    
    extra_tasks = [
        {
            "dataset": {"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv",},
            "inference_dataset": {"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv"}  # 需要更改inference dataset(如有)的fit_y，否则y_hat_test里的y都是mret24h；如没有inference dataset则要把这一行注释掉
        }
        # for y in ["forward.bret24h.b", "forward.bret24h.bp", "forward.mret24h.b", "forward.mret24h.bp"] \
        for y in ["forward.bpret24h.b", "forward.bpret24h.bp"] \
        for y_file_name in ["Y.DRM.AE", "Y.DRM.CA"]
    ]
    return extra_tasks

def get_ResiConnectionMLP_model_config():
    return {
        "class": "ResiConnectionMLP",
        "kwargs": {
            "act_fn": "ELU",
            "norm_type": "BatchNorm1d",
            "dropout_rate": 0.3,
            "hidden_size": 128,
            "num_hidden": 5,
            "lastlayer_reg": False
        }
    }

RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002"
RNode.GLOBAL_TASKNAME = "multilabel"

dataset_config = QRFitter3Node.base_dataset_config(exclude202002=True)
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp3", enable_RR=True)
task_config = QRFitter3Node.base_task_config(oos=20232024)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
extra_tasks_config = get_extra_tasks(x_file_list=["X.bk"], grid_label="OI")

# fitter_config["seed"] = 0  # tod_hs_w2和w8用的这个种子，baseline会好些
# fitter_config["max_epoch"] = 1
# fitter_config["model_config"] = get_ResiConnectionMLP_model_config()

fitting_name = "mlp3_X.bk_mbp_24h1o_RR"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    "extra_tasks": extra_tasks_config,

}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)

qf3.gen_tasks(gpus=[str(i) for i in range(1)])  # [str(i) for i in range(4,8)]
print(f"pid: {os.getpid()}")
qf3.run(para_spec="36")

exit()
# ======================================= task2 =======================================
for bottleneck in ["bottleneck100", "bottleneck200", "bottleneck400"]:
    clear_patterns = ["X.ae_bottleneck", "X.ae_residual"]
    data = {
        f"X.ae_bottleneck": f"/data/bees1/safe/junming/equity_fitting/data/ae_croll_exclude202002/{bottleneck}/bottleneck/terms.YYYYMMDD.sdiv",
        f"X.ae_residual": f"/data/bees1/safe/junming/equity_fitting/data/ae_croll_exclude202002/{bottleneck}/residual/terms.YYYYMMDD.sdiv",
    }
    prepare_shm(wait_pids=[], clear_patterns=clear_patterns, data=data)


    extra_tasks_config = get_extra_tasks_x_file_names(x_file_names=["X.ae_bottleneck", "X.ae_residual"], ys=["mret24h", "bret24h", "bpret24h"])
    fitting_name = f"ae_ex02_{bottleneck}_barra"
    qf_config = {
        "fitting_name": fitting_name,
        "dataset": dataset_config,
        "inference_dataset": inference_dataset_config,
        "fitter": fitter_config,
        "task": task_config,
        #"roller": roller_confg,
        "extra_tasks": extra_tasks_config,

    }
    qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)

    qf3.gen_tasks(gpus=[str(i) for i in range(1,2)])  # [str(i) for i in range(4,8)]
    print(f"pid: {os.getpid()}")
    qf3.run(para_spec="40")