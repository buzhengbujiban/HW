# from qrfitter3.rnodes.qrfitter3_node import *
from fit_ca.qrfitter3_node import *
from fit_ca.canopus_scripts.dump_shm import *


def get_extra_tasks_FiLMMLP():

    y_file_name = "Y"
    extra_file_name = "X.BarraExp"
    external_input_size = 53
    extra_tasks = [
        {
            "dataset": {
                "fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv",
                "x_files": ["/dev/shm/YYYYMMDD.X.sdiv", f"/dev/shm/YYYYMMDD.{extra_file_name}.sdiv"]
            },
            "inference_dataset": {
                "fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv",
                "x_files": ["/dev/shm/YYYYMMDD.X.5min.sdiv", f"/dev/shm/YYYYMMDD.{extra_file_name}.5min.sdiv"]
            },  # 需要更改inference dataset(如有)的fit_y，否则y_hat_test里的y都是mret24h；如没有inference dataset则要把这一行注释掉
            "fitter":{
                "model_config":{
                    "class": "FiLMMLP",
                    "kwargs": {
                        "embedding_input_size": external_input_size,
                        "hidden_size": [256, 64, 16],
                        "embedding_loc": embedding_loc,
                        "film_num_hidden": film_num_hidden
                    }
                }
            }
        }
        for y in ["mret24h"] \
            for film_num_hidden in [0, 1, 2] \
                for embedding_loc in [0, 1, 2]
    ]
    return extra_tasks


def get_extra_tasks_FiLMResnet(input_file_name="X", extra_file_names=["X.DRMRisk"]):
    y_file_name = "Y"
    y = "mret24h"
    
    extra_tasks = []
    for extra_file_name in extra_file_names:
        external_input_size = len(read_columns_from_pattern_shm(f"/dev/shm/YYYYMMDD.{extra_file_name}.sdiv"))
        extra_tasks.extend([
            {
                "dataset": {
                    "fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv",
                    "x_files": [f"/dev/shm/YYYYMMDD.{input_file_name}.sdiv", f"/dev/shm/YYYYMMDD.{extra_file_name}.sdiv"]
                },
                "inference_dataset": {
                    "fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv",
                    "x_files": [f"/dev/shm/YYYYMMDD.{input_file_name}.5min.sdiv", f"/dev/shm/YYYYMMDD.{extra_file_name}.5min.sdiv"]
                },  # 需要更改inference dataset(如有)的fit_y，否则y_hat_test里的y都是mret24h；如没有inference dataset则要把这一行注释掉
                "fitter":{
                    "model_config":{
                        "class": "FiLMResnet",
                        "kwargs": {
                            "embedding_input_size": external_input_size,
                            "hidden_size": 128,
                            "embedding_loc": 0,
                            "film_num_hidden": 0,
                            "norm_type": "BatchNorm1d",
                            "num_hidden": num_hidden,
                            "lastlayer_reg": False,
                            "gamma": gamma,
                            "beta": False,
                            "tanh": False,
                            
                        }
                    }
                }
            }
            for num_hidden in [3, 5] \
                for gamma in [True, False] \
                #     for beta in  [True, False] \
                #         for tanh in  [True, False]
            # for y in ["mret24h"] \
                # for film_num_hidden in [0, 1] \
                    # for embedding_loc in [-1, 0, 1, 2, 3, 4]
        ])
    return extra_tasks


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002"
RNode.GLOBAL_TASKNAME = "conditional"

dataset_config = QRFitter3Node.base_dataset_config(exclude202002=True)
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config(model="resnet")
task_config = QRFitter3Node.base_task_config(oos=2023)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
# extra_tasks_config = get_extra_tasks_x_file_names(x_file_names=["X.b"], ys=["bpret24h"])
extra_tasks_config = get_extra_tasks_FiLMResnet(input_file_name="X.subalpha1", extra_file_names=[
    "X.subalpha2", "X.DRMRisk", "X.BarraExp", "W.period2", "X.mpv", "X.subalpha2.rkp1"])

# fitter_config["max_epoch"] = 1
fitter_config["earlystop_config"]["patience"] = 4
fitter_config["randomrestart_config"] = {
    "enable": True,
    "restart_num": 3,
    "earlystop_config": fitter_config.pop("earlystop_config")
}

fitting_name = "cond_subalpha_hscond_notanh_RR"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    "extra_tasks": extra_tasks_config,

}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)

qf3.gen_tasks(gpus=[str(i) for i in range(2)])  # [str(i) for i in range(4,8)]
print(f"pid: {os.getpid()}")
qf3.run(para_spec="24")
