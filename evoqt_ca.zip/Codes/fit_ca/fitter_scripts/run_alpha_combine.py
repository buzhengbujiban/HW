from fit_ca.qrfitter3_node import *
from fit_ca.canopus_scripts.dump_shm import prepare_shm, xszscore
from collections import defaultdict

def get_extra_tasks(addXnames_list:List[str|List[str]], base_name:str="X", wgts=["is.active"]):
    # 对于addXnames_list中的每个元素，都是要add的terms；如果元素是一个list，则全当作一批add
    extra_tasks = []
    for wgt in wgts:
        extra_tasks.append({  # e.g. mike1999
            "dataset": {"x_files": [f"/dev/shm/YYYYMMDD.{base_name}.sdiv"], "fit_w": wgt},
            "inference_dataset": {"x_files": [f"/dev/shm/YYYYMMDD.{base_name}.5min.sdiv"], "fit_w": wgt}
        })
        
        for addXnames in addXnames_list:
            if isinstance(addXnames, str):
                addXnames = [addXnames]
            extra_tasks.extend([
                {  # 只有{addXname}
                    "dataset": {"x_files": [f"/dev/shm/YYYYMMDD.{addXname}.sdiv" for addXname in addXnames], "fit_w": wgt},
                    "inference_dataset": {"x_files": [f"/dev/shm/YYYYMMDD.{addXname}.5min.sdiv" for addXname in addXnames], "fit_w": wgt}
                },
                {  # mike1999+{addXname}
                    "dataset": {"x_files": [f"/dev/shm/YYYYMMDD.{base_name}.sdiv"]+[f"/dev/shm/YYYYMMDD.{addXname}.sdiv" for addXname in addXnames], "fit_w": wgt},
                    "inference_dataset": {"x_files": [f"/dev/shm/YYYYMMDD.{base_name}.5min.sdiv"]+[f"/dev/shm/YYYYMMDD.{addXname}.5min.sdiv" for addXname in addXnames], "fit_w": wgt}
                },
            ])
    return extra_tasks


data = defaultdict(list)
# for i in [1, 4, 5, 6, 8, 10, 11, 14, 18]: # [1, 3, 4, 5, 6, 8, 10, 11, 14, 18]
#     data["X.chunxiao.select1"].append(f"/data/beef2/guopeng/zp_alpha_ex/chunxiao{i}/000.ca.chunxiao{i}/selected1.YYYYMMDD.sdiv")  # 3没有
#     data["X.chunxiao.select2"].append(f"/data/beef2/guopeng/zp_alpha_ex/chunxiao{i}/000.ca.chunxiao{i}/selected2.YYYYMMDD.sdiv")

# folder = "/data/beef2/guopeng/tsreg"
# batch_names = os.listdir(folder)
# for batch in batch_names:
#     data["X.tsreg.select1"].append(os.path.join(folder, batch, f"000.ca.{batch}", "selected1.YYYYMMDD.sdiv"))
#     data["X.tsreg.select2"].append(os.path.join(folder, batch, f"000.ca.{batch}", "selected2.YYYYMMDD.sdiv"))

# folders = [
#     "/data/beef2/guopeng/l2_project/remain_LOB/000.ca.remain_LOB",
#     "/data/beef2/guopeng/l2_project/imb_tsreg3/000.ca.imb_tsreg3",
#     "/data/beef2/guopeng/l2_project/imb_tsreg2/000.ca.imb_tsreg2",
#     "/data/beef2/guopeng/l2_project/imb_tsreg2_m/000.ca.imb_tsreg2_m",
#     "/data/beef2/guopeng/l2_project/imb_tsreg3_m/000.ca.imb_tsreg3_m",
#     "/data/beef2/guopeng/l2_project/remain_LOB_m/000.ca.remain_LOB_m",
# ]
# for folder in folders:
#     data["X.l2_noLOB_resi.select1"].append(os.path.join(folder, "selected1.YYYYMMDD.sdiv"))
#     data["X.l2_noLOB_resi.select2"].append(os.path.join(folder, "selected2.YYYYMMDD.sdiv"))

# imb_tsreg = [
#     "/data/beef2/guopeng/l2_project/atc_tsreg2_m1/000.ca.atc_tsreg2_m1",
#     "/data/beef2/guopeng/l2_project/atc_tsreg3_m1/000.ca.atc_tsreg3_m1",
#     "/data/beef2/guopeng/l2_project/imb_tsreg2_m1/000.ca.imb_tsreg2_m1",
#     "/data/beef2/guopeng/l2_project/imb_tsreg3_m1/000.ca.imb_tsreg3_m1",
#     "/data/beef2/guopeng/l2_project/imb_xsreg2_m1/000.ca.imb_xsreg2_m1",
#     "/data/beef2/guopeng/l2_project/imb_xsreg3_m1/000.ca.imb_xsreg3_m1",
# ]

# l2_report = [
#     "/data/beef2/guopeng/l2_project/l2retApen/000.ca.l2retApen/",
#     "/data/beef2/guopeng/l2_project/l2ar/000.ca.l2ar",
#     "/data/beef2/guopeng/l2_project/vsareg/000.ca.vsareg",
#     "/data/beef2/guopeng/l2_project/l2smart/000.ca.l2smart",
#     "/data/beef2/guopeng/l2_project/l2str/000.ca.l2str",
# ]


l2_report2 = [
    "/data/beef2/guopeng/l2_project/rsareg/000.ca.rsareg",
    "/data/beef2/guopeng/l2_project/l2apb/000.ca.l2apb",
    "/data/beef2/guopeng/l2_project/spoof/000.ca.spoof",
    "/data/beef2/guopeng/l2_project/l2apm/000.ca.l2apm",
    "/data/beef2/guopeng/l2_project/vwret_tsreg2/000.ca.vwret_tsreg2",
    "/data/beef2/guopeng/l2_project/vwret_tsreg3/000.ca.vwret_tsreg3",
    "/data/beef2/guopeng/l2_project/l2ii/000.ca.l2ii",
]

l2_batch3 = [
    "/data/beef2/guopeng/l2_project/vwret_tsreg2/000.ca.vwret_tsreg2/",
    "/data/beef2/guopeng/l2_project/vwret_tsreg3/000.ca.vwret_tsreg3/",
    "/data/beef2/guopeng/l2_project/bs_xsreg_imb1/000.ca.bs_xsreg_imb1/",
    "/data/beef2/guopeng/l2_project/bs_xsreg_imb2/000.ca.bs_xsreg_imb2/",
    "/data/beef2/guopeng/l2_project/didsmb_stats/000.ca.didsmb_stats/",
    "/data/beef2/guopeng/l2_project/l2herd/000.ca.l2herd/",
]

bk2_folder = "/data/beef2/mike/shared/bk2_terms"
bk2 = [os.path.join(bk2_folder, batch) for batch in os.listdir(bk2_folder)]

con_proj2 = [
    "/data/beef2/guopeng/concept_project/rroot/con_proj4/000.ca.con_proj4",
    "/data/beef2/guopeng/concept_project/rroot/con_proj3/000.ca.con_proj3",
    "/data/beef2/guopeng/concept_project/rroot/con_proj2/000.ca.con_proj2",
    "/data/beef2/guopeng/concept_project/rroot/con_proj/000.ca.con_proj",
    "/data/beef2/guopeng/concept_project/rroot/emb_proj1/000.ca.emb_proj1",
    "/data/beef2/guopeng/concept_project/rroot/emb_proj2/000.ca.emb_proj2",
    "/data/beef2/guopeng/concept_project/rroot/emb_proj4/000.ca.emb_proj4",
]


# tss_folder = "/data/beef2/mike/CA_terms_tssovn/tss_terms"
# ovn_folder = "/data/beef2/mike/CA_terms_tssovn/ovn_terms"
# tss = [os.path.join(tss_folder, batch) for batch in os.listdir(tss_folder)]
# ovn = [os.path.join(ovn_folder, batch) for batch in os.listdir(ovn_folder)]
# tssovn = tss + ovn
# name = "tss"
# data = {f"X.{name}": [os.path.join(batch_folder, "terms.YYYYMMDD.sdiv") for batch_folder in eval(name)]}

# data = {f"X.{name}": ["/data/beef2/guopeng/concept_project/rroot/test_con/000.ca.test_con/terms.YYYYMMDD.sdiv"]}

pq_cxl_folder = "/data/beef2/mike/shared/pq_cxl"
pq_cxl = [os.path.join(pq_cxl_folder, batch) for batch in os.listdir(pq_cxl_folder)]

qiml_fixppq = [
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0101/000.ca.qiml0101',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0307/000.ca.qiml0307',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0728/000.ca.qiml0728',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0309/000.ca.qiml0309',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0811/000.ca.qiml0811',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0312/000.ca.qiml0312',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0618/000.ca.qiml0618',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0613/000.ca.qiml0613',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0718/000.ca.qiml0718',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml1023/000.ca.qiml1023',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml1125/000.ca.qiml1125',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0526/000.ca.qiml0526',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0303/000.ca.qiml0303',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml1107/000.ca.qiml1107',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0130/000.ca.qiml0130',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0306/000.ca.qiml0306',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0119/000.ca.qiml0119',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0102/000.ca.qiml0102',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0406/000.ca.qiml0406',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0325/000.ca.qiml0325',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0815/000.ca.qiml0815',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0221/000.ca.qiml0221',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0516/000.ca.qiml0516',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml1109/000.ca.qiml1109',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0205/000.ca.qiml0205',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0724/000.ca.qiml0724',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0131/000.ca.qiml0131',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0612/000.ca.qiml0612',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0105/000.ca.qiml0105',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0124/000.ca.qiml0124',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0430/000.ca.qiml0430',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0525/000.ca.qiml0525',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0208/000.ca.qiml0208',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0920/000.ca.qiml0920',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml1012/000.ca.qiml1012',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0409/000.ca.qiml0409',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0411/000.ca.qiml0411',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0116/000.ca.qiml0116',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0225/000.ca.qiml0225',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0228/000.ca.qiml0228',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0903/000.ca.qiml0903',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0624/000.ca.qiml0624',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0520/000.ca.qiml0520',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0719/000.ca.qiml0719',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0120/000.ca.qiml0120',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0629/000.ca.qiml0629',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0202/000.ca.qiml0202',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0214/000.ca.qiml0214',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml1214/000.ca.qiml1214',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0611/000.ca.qiml0611',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0315/000.ca.qiml0315',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml1014/000.ca.qiml1014',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0701/000.ca.qiml0701',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0908/000.ca.qiml0908',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0704/000.ca.qiml0704',
    '/data/beef2/guopeng/qiml2024_topx_fix/qiml0419/000.ca.qiml0419'
]

con_proj_plusemb = [
    "/data/beef2/guopeng/concept_project/rroot/con_proj/000.ca.con_proj/",
    "/data/beef2/guopeng/concept_project/rroot/con_proj2/000.ca.con_proj2/",
    "/data/beef2/guopeng/concept_project/rroot/con_proj3/000.ca.con_proj3/",
    "/data/beef2/guopeng/concept_project/rroot/con_proj4/000.ca.con_proj4/",
    "/data/beef2/guopeng/concept_project/rroot/emb_proj1/000.ca.emb_proj1/",
    "/data/beef2/guopeng/concept_project/rroot/emb_proj2/000.ca.emb_proj2/",
    "/data/beef2/guopeng/concept_project/rroot/emb_proj3/000.ca.emb_proj3/",
    "/data/beef2/guopeng/concept_project/rroot/emb_proj4/000.ca.emb_proj4/",
]


# name = "qiml_fixppq"
# patterns = [os.path.join(batch_folder, "selected1.YYYYMMDD.sdiv") for batch_folder in eval(name)]


ppq_imb_fixppq = [
    "/data/beef2/guopeng/l2_project_fix/l2retApen/000.ca.l2retApen/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/l2vwapret/000.ca.l2vwapret/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/atc_tsreg2_m1/000.ca.atc_tsreg2_m1/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/l2apm/000.ca.l2apm/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/vwret_tsreg3/000.ca.vwret_tsreg3/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/didsmb_apen/000.ca.didsmb_apen/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/didsmb_stats/000.ca.didsmb_stats/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/xsret2vwret_stats/000.ca.xsret2vwret_stats/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/imb_tsreg3_m1/000.ca.imb_tsreg3_m1/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/spoof/000.ca.spoof/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/l2sa/000.ca.l2sa/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/l2herd/000.ca.l2herd/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/imb_xsreg2_m1/000.ca.imb_xsreg2_m1/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/vsareg/000.ca.vsareg/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/rsareg/000.ca.rsareg/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/imb_xsreg3_m1/000.ca.imb_xsreg3_m1/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/basic/000.ca.basic/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/l2str/000.ca.l2str/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/xsvwret32_stats/000.ca.xsvwret32_stats/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/vwret_tsreg2/000.ca.vwret_tsreg2/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/l2smart/000.ca.l2smart/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/l2apb/000.ca.l2apb/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/imb_tsreg2_m1/000.ca.imb_tsreg2_m1/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/didsmb/000.ca.didsmb/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/l2ar/000.ca.l2ar/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/imb_corrsum2_m1/000.ca.imb_corrsum2_m1/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/atc_tsreg3_m1/000.ca.atc_tsreg3_m1/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/bs_xsreg_imb2/000.ca.bs_xsreg_imb2/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/l2ii/000.ca.l2ii/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/l2_project_fix/bs_xsreg_imb1/000.ca.bs_xsreg_imb1/selected1.YYYYMMDD.sdiv",
]

auction = [
    "/data/beef2/guopeng/auction/full_timer/auc1/000.ca.auc1/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/auction/full_timer/auc2/000.ca.auc2/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/auction/full_timer/auc3/000.ca.auc3/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/auction/full_timer/auc4/000.ca.auc4/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/auction/full_timer/auc5/000.ca.auc5/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/auction/full_timer/auc6/000.ca.auc6/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/auction/full_timer/auc7/000.ca.auc7/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/auction/full_timer/auc8/000.ca.auc8/selected1.YYYYMMDD.sdiv",
    "/data/beef2/guopeng/auction/full_timer/auc9/000.ca.auc9/selected1.YYYYMMDD.sdiv",
]

if __name__ == "__main__":
    name = "auction"
    patterns = eval(name)
    valid_patterns = []
    for pattern in patterns:
        try:
            read_columns_from_pattern(pattern)
        except Exception:
            pass
        else:
            valid_patterns.append(pattern)
    print(f"patterns: {len(patterns)}; valid_patterns: {len(valid_patterns)}")
    error_patterns = [p for p in patterns if p not in valid_patterns]
    print("error_patterns")
    print(error_patterns)
    data = {
        f"X.{name}.select1": valid_patterns,
        # f"X.{name}.select2": [os.path.join(batch_folder, "selected2.YYYYMMDD.sdiv") for batch_folder in eval(name)],
    }

    configs = [
        {"output_ii": list(range(1,49,2)), "start_date": "20180101", "end_date": "20221231"},  # online setting 
        {"output_ii": None, "start_date": "20230101", "end_date": "20240729"}  # 不downsample, oos
    ]
    prepare_shm(data=data, configs=configs)

    RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
    RNode.GLOBAL_TASKNAME = "alpha_combine"

    dataset_config = QRFitter3Node.base_dataset_config(exclude202002=True)
    inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
    fitter_config = QRFitter3Node.base_fitter_config(model="mlp3", enable_RR=True)
    task_config = QRFitter3Node.base_task_config(oos=20232024)
    roller_confg = QRFitter3Node.base_roller_config(croll=True)
    # extra_tasks_config = get_extra_tasks(addXnames_list=list(data.keys()), wgts=["is.active", "is.active_topx"])  # alpha_combine_univ
    extra_tasks_config = get_extra_tasks(addXnames_list=list(data.keys()))  # alpha_combine
    dataset_config["exclude_dates"].append({"start_date": "20180102", "end_date": "20180102"})


    fitting_name = f"mike1999_X.{name}_mlp3_RR"
    qf_config = {
        "fitting_name": fitting_name,
        "dataset": dataset_config,
        "inference_dataset": inference_dataset_config,
        "fitter": fitter_config,
        "task": task_config,
        #"roller": roller_confg,
        # "grid_tasks": grid_tasks_config,
        "extra_tasks": extra_tasks_config
    }
    qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)

    qf3.gen_tasks(gpus=["1"])  # [str(i) for i in range(4,8)]
    qf3.run(para_spec="6")
    prepare_shm(clear_patterns=list(data.keys()))