import os
import shutil
from fit_ca.helper_scripts.copy_files import copy_fit, get_paras
from fit_ca.canopus_scripts.dump_shm import *
from fit_ca.utils import get_paras


def copy_del_fit_expt(expt_folder, y_hat_folder="y_hat_test", delete=False):
    "将expt中的每个人fit folder：将所有roll的y_hat_folder的文件集中在一起"
    fit_ids = [folder.replace("main", "-1") for folder in os.listdir(expt_folder) if folder.startswith("fit.")]
    for fit_id in fit_ids:
        fit_folder = os.path.join(expt_folder, fit_id)
        dest_dir = os.path.join(fit_folder, f"croll_{y_hat_folder}")
        if delete:  # 事后即get_subalpha_panel后删除croll_y_hat_test
            if os.path.exists(dest_dir):
                shutil.rmtree(dest_dir)
        else:
            copy_fit(fit_folder, dest_dir, sub_folder=y_hat_folder)


def get_combined_subalphas(expt_folder, y_hat_folder="croll_y_hat_test", start_date:str=None, end_date:str=None, output_ii=None, fit_rename_fields:List[str]=None):
    base_config = CANode.base_config()
    base_config["EVENTS.market"] = "CNEQ"
    base_config["EVENTS.busdate_pattern"] = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"
    base_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    base_config["OUTPUT.terms"] = True

    paras = get_paras(expt_folder)
    fit_ids = [folder.replace("main", "-1") for folder in os.listdir(expt_folder) if folder.startswith("fit.")]
    file_pattern = "yhat.YYYYMMDD.sdiv"
    yhat_name = "yhat"
    all_terms = []
    for fit_id in fit_ids:
        pattern = os.path.join(expt_folder, fit_id, y_hat_folder, file_pattern)
        if fit_rename_fields is None:
            fit_rename = fit_id
        else:
            fit_rename = ".".join([paras.loc[fit_id, fit_rename_field] for fit_rename_field in fit_rename_fields])
        panel_name = fit_id
        base_config[f"DATA.panels"] += [panel_name]
        base_config[f"DATA.{panel_name}.pattern"] = pattern
        base_config[f"DATA.{panel_name}.columns"] = [yhat_name]
        yhat_rename = f"{fit_rename}.{yhat_name}"
        base_config[f"DATA.{panel_name}.column_masks"] = [yhat_rename]
        all_terms.append(yhat_rename)

    assert len(all_terms) == len(set(all_terms)), "duplicated term names"
    print(f"Number of terms: {len(all_terms)}")

    node = CANode(base_config, label="", clean_dir_name=True, rnode_root=expt_folder, chain_name="subalpha_panel")
    for term in all_terms:
        node.node_config["CA.terms"][term] = ca.Na20(ca(term))
    if output_ii is not None:
        node.node_config["OUTPUT.terms.output_ii"] = output_ii  # downsample

    node.set_run_dates()
    run_periods = get_run_periods(pattern=node.node_config["EVENTS.busdate_pattern"], start_date=start_date, end_date=end_date)
    node.run_periods = run_periods
    node.run(para_spec=80)


def get_subalpha_panel(expt_folder, fit_rename_fields:List[str]=None):
    configs = [
        {"output_ii": list(range(1,49,2)), "start_date": "20180101", "end_date": "20221231"},  # 每十分钟采样, is  
        {"output_ii": None, "start_date": "20230101", "end_date": "20240729"}  # 不downsample, oos
    ]
    for config in configs:
        get_combined_subalphas(expt_folder, **config, fit_rename_fields=fit_rename_fields)

if __name__ == "__main__":
    expt_folder = "/data/bees1/safe/junming/equity_fitting/online202409/primary_model/mlp_ca1999_mlpfs_3batch300_7y"
    # copy_del_fit_expt(expt_folder)
    # get_subalpha_panel(expt_folder, y_hat_folder="y_hat_test")
    get_combined_subalphas(expt_folder, y_hat_folder="y_hat_test")
    # copy_del_fit_expt(expt_folder, delete=True)