from fit_ca.qrfitter3_node import *
from fit_ca.canopus_scripts.dump_shm import *
from fit_ca.fitter_scripts.run_sequential.gen_run import get_feature_groups_FRSR


def get_extra_tasks(x_file_names:List[str]=["X"], groups: Dict[str, List]=None, grid_label="barra"):
    if grid_label == "mret24h":
        y_file_name = "Y"
        labels = ["mret24h"]
    elif grid_label == "barra":
        y_file_name = "Y"
        labels = ["mret24h", "bret24h", "bpret24h"]
    elif grid_label == "OI":
        y_file_name = "Y.OI"
        rets = ["mret", "bret", "bpret"]  # "mret", "bret", "bpret"
        parts = ["24h", "_0itrd", "_ovnt", "_1o", "_1itrd"]  # "_0itrd", "_ovnt", "_1o", "_1itrd", "_itrd", "_ovnt_res", "_itrd_res", "_1e1o"
        labels = [f"{ret}{part}" for ret in rets for part in parts]
    elif grid_label == "magic":
        y_file_name = "Y.magic"
        labels = read_columns_from_pattern("/data/beef2/junming/shared/magic_label_45/terms.YYYYMMDD.sdiv")
    
    if groups is None:  # x依靠x_files指定
        extra_tasks = [
            {
                "dataset": {"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv", "x_files": [f"/dev/shm/YYYYMMDD.{x_file_name}.sdiv"]},
                # "inference_dataset": {"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv"}  # 需要更改inference dataset(如有)的fit_y，否则y_hat_test里的y都是mret24h；如没有inference dataset则要把这一行注释掉
            }
            for y in labels for x_file_name in x_file_names
        ]
    else:  # x依靠{group_name: [features]} 指定
        extra_tasks = [
            {
                "dataset": {"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv", "use_x_names": group, "x_group_name": name},
                # "inference_dataset": {"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv", "use_x_names": group, "x_group_name": name}  # 需要更改inference dataset(如有)的fit_y，否则y_hat_test里的y都是mret24h；如没有inference dataset则要把这一行注释掉
            }
            for y in labels for name, group in groups.items()
        ]

    return extra_tasks

def get_fitroll_idx_config():
    "以下fit和roll会被inference, 一般inference2023的话指定roll.3"
    return {
        # "fit": ["fit.main"],
        "roll": ["roll.3"]
    }

def get_inference_config(x_file_name="X"):  # 2023年的inference
    inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)  # 如果2023的数据已经dump到shm里了on_shm=True
    inference_fitter_config = QRFitter3Node.base_inference_fitter_config()
    inference_task_config = QRFitter3Node.base_inference_task_config(task=["inference"], oos=20232024)  # , "inference_hidden" 可选2023要不要inference_hidden
    fitroll_idx_config = get_fitroll_idx_config()
    # 注意inference的dataset config中没有额外指定fit_y，给出来的sdiv中的y都是默认的mret24h
    inference_fitter_config["device_id"] = "0"
    inference_dataset_config["x_files"] = [f"/dev/shm/YYYYMMDD.{x_file_name}.5min.sdiv"]

    qf_config = {
        "inference_dataset": inference_dataset_config,
        "fitter": inference_fitter_config,
        "task": inference_task_config,
        "fitroll_idx": fitroll_idx_config

    }
    return qf_config


data = {
    "tsfresh_reproduce":
        ["/data/beef2/guopeng/tsfresh_fea/reproduce/ApEn4/000.ca.ApEn4/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/tsfresh_fea/reproduce/minret1/000.ca.minret1/selected1.YYYYMMDD.sdiv"],
    "tsreg": 
        ["/data/beef2/guopeng/tsreg/idea1_0/000.ca.idea1_0/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/tsreg/idea2/000.ca.idea2/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/tsreg/idea3/000.ca.idea3/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/tsreg/idea4/000.ca.idea4/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/tsreg/idea5_1/000.ca.idea5_1/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/tsreg/idea6/000.ca.idea6/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/tsreg/idea7/000.ca.idea7/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/tsreg/idea8_9/000.ca.idea8_9/selected1.YYYYMMDD.sdiv"],
    "l2imb": 
        ["/data/beef2/guopeng/l2_project/atc_tsreg2_m1/000.ca.atc_tsreg2_m1/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/l2_project/atc_tsreg3_m1/000.ca.atc_tsreg3_m1/selected1.YYYYMMDD.sdiv", 
        # "/data/beef2/guopeng/l2_project/imb_corrsum2_m1/000.ca.imb_corrsum2_m1/selected1.YYYYMMDD.sdiv", 20231013有问题
        "/data/beef2/guopeng/l2_project/imb_tsreg2_m1/000.ca.imb_tsreg2_m1/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/l2_project/imb_tsreg3_m1/000.ca.imb_tsreg3_m1/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/l2_project/imb_xsreg2_m1/000.ca.imb_xsreg2_m1/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/l2_project/imb_xsreg3_m1/000.ca.imb_xsreg3_m1/selected1.YYYYMMDD.sdiv"],
    "l2report": 
        ["/data/beef2/guopeng/l2_project/l2ar/000.ca.l2ar/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/l2_project/l2retApen/000.ca.l2retApen/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/l2_project/l2smart/000.ca.l2smart/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/l2_project/l2str/000.ca.l2str/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/l2_project/vsareg/000.ca.vsareg/selected1.YYYYMMDD.sdiv"],
    "chunxiao": 
        ["/data/beef2/guopeng/zp_alpha_ex/chunxiao1/000.ca.chunxiao1/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/zp_alpha_ex/chunxiao4/000.ca.chunxiao4/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/zp_alpha_ex/chunxiao5/000.ca.chunxiao5/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/zp_alpha_ex/chunxiao6/000.ca.chunxiao6/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/zp_alpha_ex/chunxiao8/000.ca.chunxiao8/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/zp_alpha_ex/chunxiao10/000.ca.chunxiao10/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/zp_alpha_ex/chunxiao11/000.ca.chunxiao11/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/zp_alpha_ex/chunxiao14/000.ca.chunxiao14/selected1.YYYYMMDD.sdiv", 
        "/data/beef2/guopeng/zp_alpha_ex/chunxiao18/000.ca.chunxiao18/selected1.YYYYMMDD.sdiv"]
}

file_pattern = "terms.YYYYMMDD.sdiv"
all_terms = []
root_folder = "/data/beef2/mike/CA_terms_v24.0408/"
for term_group in os.listdir(root_folder):
    pattern_list = []
    for term_batch in os.listdir(os.path.join(root_folder, term_group)):
        if term_group == "mpv_terms" and term_batch in ["000.ca.mpvd", "001.ca.mpvd"]:
            continue  # 重复了
        if term_group == "mms_terms" and term_batch in ["001.ca.mms_basic_reg_sv0.fix"]:
            continue  # 是001的fix
        pattern = os.path.join(root_folder, term_group, term_batch, file_pattern)
        pattern_list.append(pattern)
    data[term_group] = pattern_list

# data["Y"] = "/data/beef2/junming/data/clipped_label/terms.YYYYMMDD.sdiv"
# data["W"] = "/data/beef2/junming/data/is_active/terms.YYYYMMDD.sdiv"

configs = [
    {"output_ii": list(range(1,49,2)), "start_date": "20180501", "end_date": "20221231"},  # croll需要从20180501开始
    {"output_ii": None, "start_date": "20230101", "end_date": "20231013"},  # 不downsample, oos
]

# prepare_shm(data={k: v for k, v in data.items() if k == "tsfresh_reproduce"}, configs=configs)  # {k: v for k, v in data.items() if k == "mms_terms"}
# exit()

RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
RNode.GLOBAL_TASKNAME = "croll"

dataset_config = QRFitter3Node.base_dataset_config(exclude202002=True)
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True, on_shm=False)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp3")
roller_confg = QRFitter3Node.base_roller_config(croll=True)
# grid_tasks_config = get_grid_tasks_multilabel()
# extra_tasks_config = get_extra_tasks(x_file_names=list(data.keys()), grid_label="mret24h")  # "X.ae_bottleneck", "X.ae_residual"

# FR2groups = get_feature_groups_FRSR(method="FR", period="vd", ret="mret24h", ngroup=2)
# SR2groups = get_feature_groups_FRSR(method="SR", period="vd", ret="mret24h", ngroup=2)
# # extra_tasks_config = get_extra_task(groups=FR2groups+SR2groups)
# groups={"FR1": FR2groups[0], "SR1": SR2groups[0]}
# extra_tasks_config = get_extra_tasks(groups=groups, grid_label="mret24h")

name_groups = read_json("/data/beef2/junming/data/lasso_sel_features/v24_new.active/nfnzo.json")
name_groups = {name: group for name, group in name_groups.items() if name == "381"}
extra_tasks_config = get_extra_tasks(groups=name_groups, grid_label="mret24h")

# fitter_config["inference_last_hidden"] = True  # croll需不需要inference_last_hidden
# dataset_config["exclude_dates"] = [
#     {"start_date": "20200201", "end_date": "20200231"},
#     {"start_date": "20221208", "end_date": "20221209"},
#     {"start_date": "20200908", "end_date": "20200909"},
# ]

fitting_name = "lasso_381"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    # "inference_dataset": inference_dataset_config,  # 如果croll阶段2018-2022只需要10min采样的数据(alpha/hidden)，那可以把这一行给注释掉；若5min则需打开(内存占用很大)
    "fitter": fitter_config,
    "roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    "extra_tasks": extra_tasks_config,
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)

# inference_config = get_inference_config(x_file_name="X")

# qf3.gen_tasks(gpus=[str(i) for i in range(4)])  # [str(i) for i in range(4,8)] # final control on gpu devices of fitting
# qf3.run(para_spec="32")

# qf3.node_config = inference_config
# qf3.run_inference(para_spec="12")

# 生成subalpha panel
# from fit_ca.fitter_scripts.croll_subalpha_fit.gen_subalpha_panel import *
# expt_folder = qf3.stage_dir()
# copy_del_fit_expt(expt_folder)
# get_subalpha_panel(expt_folder)
# copy_del_fit_expt(expt_folder, delete=True)