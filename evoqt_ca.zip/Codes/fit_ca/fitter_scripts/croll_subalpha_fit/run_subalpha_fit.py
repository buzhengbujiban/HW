from fit_ca.qrfitter3_node import *


def get_extra_tasks_x_file_names(x_file_names:List[str|List[str]], ys=["mret24h", "bret24h", "bpret24h"]):
    extra_tasks = []
    for y in ys:
        for x_file_name in x_file_names:
            if isinstance(x_file_name, str):
                x_file_name = [x_file_name]
            x_files = [f"/dev/shm/YYYYMMDD.{x}.sdiv" for x in x_file_name]  # 支持multi xfile
            x_files_inference = [f"/dev/shm/YYYYMMDD.{x}.5min.sdiv" for x in x_file_name]
            extra_tasks.append({
                "dataset": {"fit_y": y, "x_files": x_files},
                "inference_dataset": {"fit_y": y, "x_files": x_files_inference}
            })
    return extra_tasks


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
RNode.GLOBAL_TASKNAME = "subalpha"

dataset_config = QRFitter3Node.base_dataset_config()
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config(model="resnet")
task_config = QRFitter3Node.base_task_config(oos=2023)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
# grid_tasks_config = get_grid_tasks()
extra_tasks_config = get_extra_tasks_x_file_names(x_file_names=["X.subalpha12.mul", "X.subalpha12.mul.rk", ["X.subalpha1", "X.subalpha12.mul"], ["X.subalpha1", "X.subalpha12.mul.rk"], ["X.subalpha1", "X.subalpha12.mul", "X.subalpha12.mul.rk"]], ys=["mret24h"])


fitter_config["earlystop_config"]["patience"] = 4
fitter_config["randomrestart_config"] = {
    "enable": True,
    "restart_num": 3,
    "earlystop_config": fitter_config.pop("earlystop_config")
}

fitting_name = "subalpha1_mul_compare_RR"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    "extra_tasks": extra_tasks_config
    
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks(gpus=["0"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="12")