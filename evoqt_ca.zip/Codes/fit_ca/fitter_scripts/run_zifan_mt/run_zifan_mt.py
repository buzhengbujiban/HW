from fit_ca.qrfitter3_node import *


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
RNode.GLOBAL_TASKNAME = "multitarget"

Xname, Yname, Wname = "X.ae_bottleneck200", "Y", "W"
dataset_config = QRFitter3Node.base_dataset_config(Xname=Xname, Yname=Yname, Wname=Wname)
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True, Xname=Xname, Yname=Yname, Wname=Wname)
task_config = QRFitter3Node.base_task_config(oos=2023)

dataset_config["fit_y"] = ["mret24h", "bret5e"]
inference_dataset_config["fit_y"] = ["mret24h", "bret5e"]
fitter_config = {
    "_share_model_path": "/data/beef2/zifan/multi_output/uncw/share_model.pt",
    "share_model_require_grad": True,
    "_load_model_path": "/data/beef2/zifan/multi_output/diff_mean_cor/model.pt",
    "class": "MultiTargetLearner",
    "device_id": "0",
    "save_share_model": True,
    "w_field": [1,1],
    "model_config": {
        "class": "MultiTargetNetwork",
        "kwargs": {
            "hidden_size": [256,128,64],
            "dropout_rate": 0.3,
            "act_fn": "ELU",
            "bn": True,
            "head_hidden_size": [64,16]
        }
    },
    "batch_size": 8000,
    "max_epoch": 20,
    "loss_fn": ["wmse_mt",{}],
    "learning_rate": 0.0005,
    "lr_scheduler": ["CosineAnnealingLR",{"T_max": 20,"eta_min": 0}],
    "l2_decay": 0,
    "eval_start_epoch": 0,
    "earlystop_config": {
        "enable": True,
        "monitor_key": [{"valid/cor_mret24h": {"delta": 0, "mode": "max"}}],
        "mode": "max",
        "patience": 10
    },
    "evaltrain": False,
    "evaltest": False,
    "enable_tensorboard": False,
    "dataloader_workers": 8
}

fitting_name = "zifan_m24b5e_ae200_escor"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    # "roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    # "extra_tasks": extra_tasks_config
    
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks(gpus=["0", "1"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="24")