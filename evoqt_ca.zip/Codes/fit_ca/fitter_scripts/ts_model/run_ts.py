from fit_ca.qrfitter3_node import *
from online202409.utils import get_features_from_extra_tasks, load_train_test_data_shm
from online202409 import terms
from fit_ca.utils import show_stats
import qr

def get_grid_tasks_hs(model="TE"):
    if model == "TE":
        grid_tasks = {
            "fitter":{
                "model_config": {
                    "kwargs": {
                        "d_model": [64, 128],
                        # "dropout_rate": [0.3, 0.5],
                        # "nhead": [1, 4],
                    }
                },
                # "batch_size": [4096, 16384],
                "l2_decay": [0, 1, 5],
                "learning_rate": [0.0001, 0.00005],
            },
        }
    elif model == "GRU":
        grid_tasks = {
            "fitter":{
                "model_config": {
                    "kwargs": {
                        "hidden_size": [32, 64],
                        # "dropout_rate": [0.3, 0.5],
                        "num_layers": [1, 2],
                    }
                },
                # "batch_size": [4096, 16384],
                "l2_decay": [1, 2, 3],
                "learning_rate": [0.00005],
            },
        }
    elif model == "TSMLP":
        grid_tasks = {
            "fitter":{
                "model_config": {
                    "kwargs": {
                        "seq_len": [25],
                        "d_hidden": [32, 64],
                        "d_time_pattern": [8, 16],
                        "dropout_rate": [0.3, 0.5],
                    }
                },
                # "batch_size": [4096, 16384],
                # "l2_decay": [0, 1],
                # "learning_rate": [0.0001, 0.00005],
            },
        }
    return grid_tasks


def get_extra_tasks_ks():
    extra_tasks = [
        {
            "dataset": {"kernel_size": ks},
            "inference_dataset": {"kernel_size": ks},
        }
        for ks in [3, 6, 12, 25]  # [3, 6, 12, 25, 49, 73]
    ]
    return extra_tasks

def get_extra_tasks_ks_caae():
    extra_tasks = [
        {
            "dataset": {"kernel_size": ks, "dilation": dilation},
            "inference_dataset": {"kernel_size": ks, "dilation": dilation*2},
        }
        for ks, dilation in [(24, 3), (40, 3), (12, 6), (24, 6), (6, 12), (10, 12), (3, 24), (5, 24)]
    ]
    return extra_tasks

def get_extra_tasks_label():
    labels = terms.labels_7y
    extra_tasks = []
    for y in labels:
        extra_tasks.append({
            "dataset": {"fit_y": y},
            "inference_dataset": {"fit_y": y}
        })
    return extra_tasks

def get_extra_tasks_wgt():
    wgts = ["is.active_topx", "is.active"]  # , "is.active_csi300"
    extra_tasks = []
    for wgt in wgts:
        extra_tasks.append({
            "dataset": {"fit_w": wgt},
            "inference_dataset": {"fit_w": wgt}
        })
    return extra_tasks

def get_extra_tasts_feature_group():
    extra_tasks = []

    n_feature = 500
    feature_coef = qr.tbl_read("/data/beef2/junming/online202409/bk_pq_snap_2norm/torchlasso_fs/mret24h/feature_coef.tbl").set_index("feature")
    col = feature_coef.columns[-1]
    columns = feature_coef[col].abs().sort_values(ascending=False).index[:n_feature].tolist()
    extra_tasks.append({
        "dataset": {"use_x_names": columns, "group_name": "torchlasso_fs"},
        "inference_dataset": {"use_x_names": columns, "group_name": "torchlasso_fs"},
    })
    
    df, ss = show_stats(node_name="bk_pq_snap_2norm_terms", return_dfss=True)
    for method in ["FR", "SR"]:
        columns = df.xs("w_c1").xs("mret24h").xs("is", axis=1).abs().sort_values(method, ascending=False).index[:n_feature].tolist()
        extra_tasks.append({
            "dataset": {"use_x_names": columns, "group_name": f"{method}_fs"},
            "inference_dataset": {"use_x_names": columns, "group_name": f"{method}_fs"},
        })

    return extra_tasks

def get_extra_tasks_SR():
    extra_tasks = []
    df, ss = show_stats(node_name="gru_all_terms", return_dfss=True)
    y = "mret24h"
    df_y = df.xs("w_c1").xs(y).xs("is", axis=1).abs()
    for batch_num in [100, 300, 500, len(df_y)]:
        features = df_y.sort_values("SR", ascending=False).index[:batch_num].tolist()
        extra_tasks.append({
            "dataset": {"fit_y": y, "use_x_names": features, "group_name": f"{y}_{len(features)}"},
            "inference_dataset": {"fit_y": y, "use_x_names": features, "group_name": f"{y}_{len(features)}"},
        })
    return extra_tasks

RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res/"
RNode.GLOBAL_TASKNAME = "ts_model"

fitting_name = "GRU_fs_hs"
Xname, Yname, Wname = "X.gru_all", "Y", "W"
X_pattern = {Xname: {"pattern": terms.gru_all}}

# fitting_name = "bk_pq_snap_2norm_fs_compare"
# Xname, Yname, Wname = "X.bk_pq_snap_2norm", "Y", "W"
# extra_tasks_config = get_extra_tasts_feature_group()
# all_features = get_features_from_extra_tasks(extra_tasks_config)
# X_pattern = {Xname: {"pattern": terms.bk+terms.pq_snap+terms.bk_norm+terms.pq_snap_norm, "columns": all_features}}

# Xname, Yname, Wname = "X.bk_pqsnap.norm", "Y", "W"
# X_pattern = {Xname: {"pattern": [
#     "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/T/merged_snap.mad_norm/selected1.YYYYMMDD.sdiv",
#     "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/T/merged_bk.mad_norm/selected1.YYYYMMDD.sdiv",
# ]}}
# fitting_name = f"bk_pqsnap.norm_config2"

# load_train_test_data_shm(X_pattern=X_pattern, include_YW=True, Yname=Yname, Wname=Wname, rolling=True)  # 注意include_YW是否需要重新dump
dataset_config = QRFitter3Node.base_tsdataset_config(Xname=Xname, Yname=Yname, Wname=Wname)
inference_dataset_config = QRFitter3Node.base_tsdataset_config(is5min=True, Xname=Xname, Yname=Yname, Wname=Wname)
fitter_config = QRFitter3Node.base_fitter_config(model="GRU", enable_RR=True, eval_fraction=1)
task_config = QRFitter3Node.base_task_config(testing=False, oos=20232024)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
# grid_tasks_config = get_grid_tasks_hs(model="GRU")
extra_tasks_config = get_extra_tasks_SR()
# extra_tasks_config = get_extra_tasks_wgt()

fitter_config["randomrestart_config"]["restart_num"] = 2
fitter_config["randomrestart_config"]["earlystop_config"]["patience"] = 2
fitter_config.update({
    "model_config": {
        "class": "RNNNetwork",
        "kwargs": {
            "dropout_rate": 0.5,
            "hidden_size": 32,
            "num_layers": 1,
            "type": "GRU"
        }
    },
    "l2_decay": 3,
    "learning_rate": 5e-05,
})
# y = "mret1h"
# dataset_config.update({"fit_y": y}),
# inference_dataset_config.update({"fit_y": y})

qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    "extra_tasks": extra_tasks_config
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks(gpus=[str(i) for i in range(4,8)])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="12")
# load_train_test_data_shm(X_pattern=X_pattern, include_YW=False, Yname=Yname, Wname=Wname, clear=True)