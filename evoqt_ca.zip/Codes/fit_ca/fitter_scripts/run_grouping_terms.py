from qrfitter3.rnodes.qrfitter3_node import *
import pandas as pd


def get_extra_tasks():
    rets = ["mret"]  # "mret", "bret", "bpret"
    parts = ["0itrd", "ovnt", "1o"]  # "0itrd", "ovnt", "1o", "1itrd", "itrd", "ovnt_res", "itrd_res", "1e1o"
    y_file_name = "Y"

    grouping_df = pd.read_parquet("/data/beef2/junming/data/ca1999_grouping_random.parquet")
    group_methods = ['random0_group', 'random1_group', 'random2_group']  #  'SR_group', 'FR_group', 'SRFR_group'
    extra_tasks = []
    for method in group_methods:
        groups = grouping_df[method].unique()
        for g in groups:
            feature_names = grouping_df[grouping_df[method] == g].index.tolist()
            extra_tasks.extend([
                {
                    "dataset": {
                        "use_x_names": feature_names,
                        #"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv"
                    },
                    "inference_dataset": {
                        "use_x_names": feature_names,
                        #"fit_y": y, "y_file": f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv"
                    }
                }
                #for y in [f"{ret}_{part}" for ret in rets for part in parts]
                # for y in ["mret24h", "bret24h", "bpret24h"]
            ])
    return extra_tasks


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002"
RNode.GLOBAL_TASKNAME = "terms_grouping"

dataset_config = QRFitter3Node.base_dataset_config()
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp2")
task_config = QRFitter3Node.base_task_config(oos=2023)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
extra_tasks_config = get_extra_tasks()

# fitter_config["max_epoch"] = 1

fitting_name = "random_4group_mlp2"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    "extra_tasks": extra_tasks_config
    

}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)

qf3.gen_tasks(gpus=["4"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="4")