# from qrfitter3.rnodes.qrfitter3_node import *
from fit_ca.qrfitter3_node import *
from fit_ca.canopus_scripts.dump_shm import *
from online202409.utils import get_features_from_extra_tasks, load_train_test_data_shm
from online202409 import terms
from fit_ca.utils import show_stats
import qr

def get_extra_tasks(x_file_list:List[str|List[str]], grid_label="mret24h"):
    if grid_label == "mret24h":
        y_file_name = "Y"
        labels = ["mret24h"]
    elif grid_label == "barra":
        y_file_name = "Y"
        labels = ["mret24h", "bret24h", "bpret24h"]
    elif grid_label == "OI":
        y_file_name = "Y.OI"
        rets = ["mret"]  # "mret", "bret", "bpret"
        parts = ["0itrd", "ovnt", "1o"]  # "0itrd", "ovnt", "1o", "1itrd", "itrd", "ovnt_res", "itrd_res", "1e1o"
        labels = [f"{ret}_{part}" for ret in rets for part in parts]
    
    extra_tasks = []
    for y in labels:
        for x_file_names in x_file_list:
            if isinstance(x_file_names, str):
                x_file_names = [x_file_names]
            x_files = [f"/dev/shm/YYYYMMDD.{x_file_name}.sdiv" for x_file_name in x_file_names] 
            x_files_inference = [f"/dev/shm/YYYYMMDD.{x_file_name}.5min.sdiv" for x_file_name in x_file_names] 
            y_file = f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv"
            y_file_inference = f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv"
            extra_tasks.append({
                "dataset": {"fit_y": y, "x_files": x_files, "y_file": y_file},
                "inference_dataset": {"fit_y": y, "x_files": x_files_inference, "y_file": y_file_inference}
            })
    return extra_tasks


def get_GroupInputMLP_model_config():
    return {
        "class": "GroupInputMLP",
        "kwargs": {
            "act_fn": "ELU",
            "bn": False,
            "dropout_rate": 0.3,
            "hidden_size": [126, 32],
            "reduce_factor": 4,
            "x_pattern": "/data/beef2/junming/data/combine1999/terms.YYYYMMDD.sdiv"
        }
    }

def get_ResiConnectionMLP_model_config():
    return {
        "class": "ResiConnectionMLP",
        "kwargs": {
            "act_fn": "ELU",
            "norm_type": "BatchNorm1d",
            "dropout_rate": 0.3,
            "hidden_size": 256,
            "num_hidden": 3,
            "lastlayer_reg": False
        }
    }


def get_extra_task_features(x_file_names=["X"]):
    # 根据一个lasso_coef_df，跑不同正则化强度选出来的feature子集
    x_files = [f"/dev/shm/YYYYMMDD.{x_file_name}.sdiv" for x_file_name in x_file_names] 
    x_files_inference = [f"/dev/shm/YYYYMMDD.{x_file_name}.5min.sdiv" for x_file_name in x_file_names] 
    import qr
    lasso_coef_df = qr.tbl_read("/data/beef2/junming/online202409/pq_ema/mlp_fs/mret24h/feature_coef.tbl").set_index("feature")
    extra_tasks = []
    for m in lasso_coef_df.columns:
        nzo = lasso_coef_df.loc[lasso_coef_df[m] != 0, m]
        group = nzo.index.tolist()
        name = f"{len(group)}"
        extra_tasks.append({
            "dataset": {"use_x_names": group, "group_name": name, "x_files": x_files},
            "inference_dataset": {"use_x_names": group, "group_name": name, "x_files": x_files_inference}
        })

    # 自动逐轮lasso得到的子集,fix batch num / not fix
    # extra_tasks = []
    # method_folder = "/data/beef2/junming/data/lasso_sel_features/v24_new.active_topx_2122_auto_seq_fix200"
    # round_features = read_json(os.path.join(method_folder, "round_features.json"))
    # for name, group in round_features.items():
    #     name += f"_{len(group)}"
    #     extra_tasks.append({
    #         "dataset": {"use_x_names": group, "group_name": name},
    #         "inference_dataset": {"use_x_names": group, "group_name": name}
    #     })
    
    # lasso差分得到的fix batch num features子集， 支持多X files e.g. X + X.bk
    # x_files = [f"/dev/shm/YYYYMMDD.{x_file_name}.sdiv" for x_file_name in x_file_names] 
    # x_files_inference = [f"/dev/shm/YYYYMMDD.{x_file_name}.5min.sdiv" for x_file_name in x_file_names] 
    # extra_tasks = []
    # method_folder = "/data/beef2/junming/online202409/ca1999_bk/mlp_fs/mret24h"
    # round_features = read_json(os.path.join(method_folder, "round_features_fix300.json"))
    # for name, group in round_features.items():
    #     name += f"_{len(group)}"
    #     extra_tasks.append({
    #         "dataset": {"use_x_names": group, "group_name": name, "x_files": x_files},
    #         "inference_dataset": {"use_x_names": group, "group_name": name, "x_files": x_files_inference}
    #     })

    # lasso差分得到的fix batch num features子集，只跑前三round
    # round_features = read_json("/data/beef2/junming/online202409/ca1999/mlp_fs/mret24h/round_features_fix300.json")
    # extra_tasks = []
    # for name, group in round_features.items():
    #     if name in ["round0", "round1", "round2"]:
    #         name += f"_{len(group)}"
    #         extra_tasks.append({
    #             "dataset": {"use_x_names": group, "group_name": name},
    #             "inference_dataset": {"use_x_names": group, "group_name": name}
    #         })
    # round012 = round_features["round0"] + round_features["round1"] + round_features["round2"]
    # group = round012
    # name = f"round012_{len(group)}"
    # extra_tasks.append({
    #     "dataset": {"use_x_names": group, "group_name": name},
    #     "inference_dataset": {"use_x_names": group, "group_name": name}
    # })

    # import lightgbm as lgb
    # model_file = "/data/bees1/safe/junming/equity_fitting/expt_res_tree/lgb_fit_barra_valid/fit.0/lgb.model"
    # model = lgb.Booster(model_file=model_file)
    # importance = model.feature_importance(importance_type='gain')
    # feature_names = model.feature_name()
    # importance_dict = dict(zip(feature_names, importance))
    # importance = pd.Series(importance_dict)
    # importance /= importance.sum()
    # cumsum = importance.sort_values(ascending=False).cumsum()
    # thresholds = [0.5, 0.70, 0.80, 0.90, 0.95, 0.97, 0.98, 0.99, 0.999, 0.9999]
    # name_groups = {}
    # for t in thresholds:
    #     group = cumsum[cumsum<t].index.tolist()
    #     name_groups[str(len(group))] = group
    # extra_tasks = []
    # for name, group in name_groups.items():
    #     extra_tasks.append({
    #         "dataset": {"use_x_names": group, "group_name": name},
    #         "inference_dataset": {"use_x_names": group, "group_name": name}
    #     })
    return extra_tasks

def get_extra_tasks_univfile(univs):
    extra_tasks = []
    for univ in univs:
        x_files = [f"/dev/shm/YYYYMMDD.X.{univ}.sdiv"]
        y_file = f"/dev/shm/YYYYMMDD.Y.{univ}.sdiv"
        w_file = f"/dev/shm/YYYYMMDD.W.{univ}.sdiv"
        x_files_inference = [f"/dev/shm/YYYYMMDD.X.5min.{univ}.sdiv"]
        y_file_inference = f"/dev/shm/YYYYMMDD.Y.5min.{univ}.sdiv"
        w_file_inference = f"/dev/shm/YYYYMMDD.W.5min.{univ}.sdiv"
        extra_tasks.append({
            "dataset": {"x_files": x_files, "y_file": y_file, "w_file": w_file},
            "inference_dataset": {"x_files": x_files_inference, "y_file": y_file_inference, "w_file": w_file_inference},
            "fitter": {"max_epoch": 200, "evaltrain": True, "evaltest": True, "randomrestart_config": {"earlystop_config": {"patience": 20}}}
        })
    return extra_tasks

def get_extra_tasks_l1():
    extra_tasks = [
        {"fitter": {"input_l1_alpha": l1, "earlystop_config":{"patience":20}, "max_epoch": 20}}
        for l1 in [1e-4, 1e-5, 1e-6, 1e-7, 1e-8]
    ]
    return extra_tasks

def get_extra_task_Xfiles(x_file_names=["X"]):
    extra_tasks = []
    for x_file_name in x_file_names:
        x_files = [f"/dev/shm/YYYYMMDD.{x_file_name}.sdiv"] 
        x_files_inference = [f"/dev/shm/YYYYMMDD.{x_file_name}.5min.sdiv"] 
        extra_tasks.append({
            "dataset": {"x_files": x_files},
            "inference_dataset": {"x_files": x_files_inference}
        })
    return extra_tasks

def get_extra_tasks_wgt():
    wgts = ["is.active_topx", "is.active"]  # , "is.active_csi300"
    extra_tasks = []
    for wgt in wgts:
        extra_tasks.append({
            "dataset": {"fit_w": wgt},
            "inference_dataset": {"fit_w": wgt}
        })
    return extra_tasks

def get_extra_tasts_feature_group():
    extra_tasks = []

    n_features = [300, 500, 1000, 1500]  # 1000
    for n_feature in n_features:
        df, ss = show_stats(node_name="mlp_all_u_terms_vsmret1500resi_g2458", return_dfss=True)
        for method in ["SR"]:
            columns = df.xs("w_c1").xs('mret24h.res').xs("is", axis=1).abs().sort_values(method, ascending=False).index[:n_feature].tolist()
            extra_tasks.append({
                "dataset": {"use_x_names": columns, "group_name": f"{method}_fs_{n_feature}"},
                "inference_dataset": {"use_x_names": columns, "group_name": f"{method}_fs_{n_feature}"},
            })

    return extra_tasks

def get_extra_tasks_bpret():
    extra_tasks = []
    for y in ["bpret24h", "bpret24h.zs"]:
        for l2_decay in [1, 2, 4, 8]:
            for dr in [0.3, 0.5]:
                extra_tasks.append({
                    "dataset": {"fit_y": y},
                    "inference_dataset": {"fit_y": y},
                    "fitter": {
                        "model_config": {"kwargs": {"dropout_rate": dr}},
                        "l2_decay": l2_decay
                    }
                })
    return extra_tasks


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
RNode.GLOBAL_TASKNAME = "hypersearch"

extra_tasks_config = get_extra_tasts_feature_group()
Xname, Yname, Wname = f"X.resi", "Y.resi", "W"
features = get_features_from_extra_tasks(extra_tasks_config)
X_pattern = {Xname: {"pattern": terms.mlp_all_u, "columns": features}}
fitting_name = f"fit_mret1500_resi_SR_fs"

load_train_test_data_shm(X_pattern=X_pattern, include_YW=True)  # 注意include_YW是否需要重新dump
dataset_config = QRFitter3Node.base_dataset_config(Xname=Xname, Yname=Yname, Wname=Wname)
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True, Xname=Xname, Yname=Yname, Wname=Wname)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp3", enable_RR=True)
task_config = QRFitter3Node.base_task_config(oos=20232024)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
# dataset_config["fit_w"] = "is.active_topx"
# inference_dataset_config["fit_w"] = "is.active_topx"
dataset_config["fit_y"] = "mret24h.res"
inference_dataset_config["fit_y"] = "mret24h.res"
# fitter_config["randomrestart_config"]["restart_num"] = 0  # qucik

qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    "extra_tasks": extra_tasks_config
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks(gpus=["0", "1", "2"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="24")
load_train_test_data_shm(X_pattern=X_pattern, include_YW=False, clear=True)