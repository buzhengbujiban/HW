from fit_ca.qrfitter3_node import *
from fit_ca.canopus_scripts.dump_shm import *
from online202409.utils import get_features_from_extra_tasks, canopus_inference_allinone_helper, load_train_test_data_shm_new
from online202409 import terms
from fit_ca.utils import show_stats
import qr
import pickle
from qrfitter3.reports.utils import lgb_importance_df

start_end = "20180102_20221230"
# start_end = "20180102_20240729"
start_end_5min = "20230103_20240729"

def get_extra_tasks(x_file_names:List[str], grid_label="mret24h"):
    
    if grid_label == "mret24h":
        y_file_name = "Y"
        labels = ["mret24h"]
    elif grid_label == "barra":
        y_file_name = "Y"
        labels = ["mret24h", "bret24h", "bpret24h"]
    elif grid_label == "OI":
        y_file_name = "Y.OI"
        rets = ["mret"]  # "mret", "bret", "bpret"
        parts = ["0itrd", "ovnt", "1o"]  # "0itrd", "ovnt", "1o", "1itrd", "itrd", "ovnt_res", "itrd_res", "1e1o"
        labels = [f"{ret}_{part}" for ret in rets for part in parts]
    
    extra_tasks = []
    for y in labels:
        for x_file_name in x_file_names:
            x_files = f"/dev/shm/{start_end}.{x_file_name}_d_concat.sdiv"
            x_files_inference = f"/dev/shm/{start_end_5min}.{x_file_name}.5min_d_concat.sdiv"
            y_file = f"/dev/shm/{start_end}.{y_file_name}_d_concat.sdiv"
            y_file_inference = f"/dev/shm/{start_end_5min}.{y_file_name}.5min_d_concat.sdiv"
            extra_tasks.append({
                "dataset": {"fit_y": y, "x_files": x_files, "y_file": y_file},
                "inference_dataset": {"fit_y": y, "x_files": x_files_inference, "y_file": y_file_inference}
            })
    return extra_tasks

def get_grid_tasks():
    grid_tasks = {
        "fitter":{
            "para_dict": {
                'learning_rate': [0.05, 0.02, 0.01,],
                # 'num_leaves': [32, 64],
                # 'min_child_samples': [20, 200],  # minimal number of data in one leaf， an approximation based on the Hessian
                # 'reg_alpha': [0.1, 0.5, 1],  # L1
                # 'reg_lambda': [0.5, 1, 2],  # L2
                # 'feature_fraction': [0.7, 0.5, 0.3],
                # 'bagging_fraction': [0.9, 0.6, 0.3],
                'num_iterations': [3000, 6000],
            }
        }
    }
    return grid_tasks

def get_extra_tasks_hs():
    extra_tasks = []
    for lr in [0.1, 0.05, 0.02, 0.01]:
        extra_tasks.append({
            "fitter": {"para_dict": {'learning_rate': lr}},
        })
    extra_tasks.append({
        "fitter": {"para_dict": {'learning_rate': 0.01, 'num_iterations': 10000}},
    })
    return extra_tasks


def get_extra_task_wgt():
    wgts = ["is.active_topx", "is.active"]
    extra_tasks = [
        {"dataset": {"fit_w": wgt}, "inference_dataset": {"fit_w": wgt}}
        for wgt in wgts
    ]
    return extra_tasks

def get_extra_tasks_xxyy():
    extra_tasks = []
    xs = ["X", "X.v24"]
    ys = ["Y", "Y.v24"]
    for x_file_name in xs:
        for y_file_name in ys:
            x_files = f"/dev/shm/{start_end}.{x_file_name}_d_concat.sdiv"
            x_files_inference = f"/dev/shm/{start_end_5min}.{x_file_name}.5min_d_concat.sdiv"
            y_file = f"/dev/shm/{start_end}.{y_file_name}_d_concat.sdiv"
            y_file_inference = f"/dev/shm/{start_end_5min}.{y_file_name}.5min_d_concat.sdiv"
            extra_tasks.append({
                "dataset": {"x_files": x_files, "y_file": y_file},
                "inference_dataset": {"x_files": x_files_inference, "y_file": y_file_inference}
            })
    return extra_tasks

def get_extra_tasks_feature():
    round_features = read_json("/data/beef2/junming/online202409/ca1999/mlp_fs/mret24h/round_features_fix300.json")
    extra_tasks = []
    for name, group in round_features.items():
        if name in ["round0", "round1", "round2"]:
            name += f"_{len(group)}"
            extra_tasks.append({
                "dataset": {"use_x_names": group, "group_name": name},
                "inference_dataset": {"use_x_names": group, "group_name": name}
            })
    round012 = round_features["round0"] + round_features["round1"] + round_features["round2"]
    group = round012
    name = f"round012_{len(group)}"
    extra_tasks.append({
        "dataset": {"use_x_names": group, "group_name": name},
        "inference_dataset": {"use_x_names": group, "group_name": name}
    })
    # round01 = round_features["round0"] + round_features["round1"]
    # round23 = round_features["round2"] + round_features["round3"]
    # round0123 =  round01 + round23
    # for name in ["round01", "round23", "round0123"]:
    #     group = eval(name)
    #     name += f"_{len(group)}"
    #     extra_tasks.append({
    #         "dataset": {"use_x_names": group, "group_name": name},
    #         "inference_dataset": {"use_x_names": group, "group_name": name}
    #     })
    return extra_tasks

def get_extra_tasks_train_start():
    extra_tasks = []
    for start_date in ["20140101", "20150101", "20160101", "20170101", "20180101"]:
        extra_tasks.append({
            "task": {"train": {"start_date": start_date}},
        })
    return extra_tasks

def main(fitting_name, X_pattern, Yname="Y", Wname="W", include_YW=True,
         fit_y="mret24h", fit_w="is.active", univ="G2548", sampling_w=None,
         rolling=False, canopus_inference=False, is_output_ii=list(range(1,49,2))):

    RNode.RNODE_ROOT = "/data/bees1/unsafe/junming/equity_fitting/online202409"
    RNode.GLOBAL_TASKNAME = "tree_model"

    Xname = list(X_pattern.keys())[0]  # tree can only have one X file.
    univ_suffix = "" if univ == "G2548" else f".{univ}"
    Xname, Yname, Wname = f"{Xname}{univ_suffix}", f"{Yname}{univ_suffix}", f"{Wname}{univ_suffix}"
    do_dump, para_spec = True, 80
    if canopus_inference:
        train_start_end = load_train_test_data_shm_new(X_pattern=X_pattern, is_output_ii=is_output_ii, include_YW=True, d_concat=True, do_dump=do_dump, univ=univ, para_spec=para_spec, require=["is"])
                                                   # is_output_ii=[1], os_output_ii=[1], train_start="20170213", train_end="20240729")  # TODO: daily fitting
    else:
        train_start_end, test_start_end = load_train_test_data_shm_new(X_pattern=X_pattern, include_YW=True, d_concat=True, do_dump=do_dump, univ=univ, para_spec=para_spec, require=["is", "os"])                                                           
        inference_dataset_config = QRFitter3Node.base_concat_dataset_config(start_end=test_start_end, is5min=True, Xname=Xname, Yname=Yname, Wname=Wname)
        inference_dataset_config["fit_w"] = fit_w
        inference_dataset_config["fit_y"] = fit_y                                   
    dataset_config = QRFitter3Node.base_concat_dataset_config(start_end=train_start_end, Xname=Xname, Yname=Yname, Wname=Wname)
    dataset_config["fit_w"] = fit_w
    dataset_config["fit_y"] = fit_y
    fitter_config = QRFitter3Node.base_fitter_config(model="lgbnew")  # TODO
    task_config = QRFitter3Node.base_task_config(oos=20232024)
    roller_confg = QRFitter3Node.base_roller_config(croll=False)
    extra_tasks_config = get_extra_tasks_hs()
    grid_tasks_config = get_grid_tasks()

    fitter_config["para_dict"]['num_threads'] = 120
    if sampling_w is not None:
        dataset_config["sampling_w"] = sampling_w

    # TODO: daily fitting
    # task_config["train"]["start_date"] = "20180101"#  "20170213"
    # multiplier = 1/24
    # for para in ["min_data_in_bin", "min_child_samples"]:
    #     fitter_config["para_dict"][para] = int(fitter_config["para_dict"][para] * multiplier)
    fitter_config["para_dict"]['learning_rate'] = 0.02

    qf_config = {
        "canopus_inference": canopus_inference,
        "fitting_name": fitting_name,
        "dataset": dataset_config,
        "fitter": fitter_config,
        #"grid_tasks": grid_tasks_config,  # TODO
        # "extra_tasks": extra_tasks_config,
    }
    if canopus_inference:
        if "extra_tasks" in qf_config:
            for task in qf_config["extra_tasks"]:
                if "inference_dataset" in task:
                    del task["inference_dataset"]
    else:
        qf_config["inference_dataset"] = inference_dataset_config
    if rolling:
        qf_config["roller"] = roller_confg
    else:
        qf_config["task"] = task_config
    qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
    pkl_path = os.path.join(qf3.stage_dir(), "X_pattern.pkl")
    with open(pkl_path, "wb") as f:
        pickle.dump(X_pattern, f)
    os.chmod(pkl_path, 0o700)
    qf3.gen_tasks()
    qf3.run(para_spec="1")
    load_train_test_data_shm_new(X_pattern=X_pattern, include_YW=True, clear=True, d_concat=True)

    if canopus_inference:
        canopus_inference_allinone_helper(expt_folder=str(qf3.stage_dir()), univ=univ, slurm_cfg={"smem": 10000, "retries": 2, "timeout": "01:00:00"})

if __name__ == "__main__":
    # expt_folder = "/data/bees1/unsafe/junming/equity_fitting/online202409/tree_model/tree_CAPQ_1m_lrnit_hs"
    # canopus_inference_allinone_helper(expt_folder=expt_folder, slurm_cfg={"smem": 10000, "retries": 2, "timeout": "00:30:00"})
    # exit()

    # fitting_name = "pzz_ds10min_mad"
    # Xname = f"X.{fitting_name}"
    # pattern = "/data/beef3/zuze/AlphaSave/Alpha.pzz.to2024/YYYYMMDD.sdiv"
    # X_pattern = {Xname: {"pattern": pattern, "calc_f": partial(mad, pattern_list=pattern)}}
    # main(fitting_name, X_pattern, include_YW=True, fit_y="mret1h", univ='csi300', canopus_inference=True)
    # exit()

    # senti weight作为sample_w
    # Xname, Yname, Wname = "X.tree", "Y", "W.senti"
    # pattern = [
    #     "/data/beef3/guopeng/alter_data/senti_stats_dm_sparse1/000.ca.senti_stats_dm_sparse1/selected1.YYYYMMDD.sdiv",
    # ]
    # X_pattern = {Xname: {"pattern": pattern}}
    # fitting_name = f"tree_senti_fit_withweight"
    # main(fitting_name=fitting_name, X_pattern=X_pattern, Yname=Yname, Wname=Wname, fit_w="is.active_senti", sampling_w="is.active_senti")
    

    # cofit conditionals
    # fit_y = "mret24h"
    # batch_num = 1500
    # model_file = f"/data/bees1/unsafe/junming/equity_fitting/online202409/tree_imp_fs_u/{fit_y}_fs/fit.0/lgb.model"
    # features = lgb_importance_df(model_file)[0].sort_values("score_by_gain", ascending=False)["term"].tolist()[:batch_num]
    # fitting_name = f"tree_m24h_imp{len(features)}_cofitBarraW1"
    # Xname = f"X.{fitting_name}"
    # X_pattern = {Xname: [
    #     {"pattern": terms.tree_all_u,  "columns": features},
    #     {"pattern": "/data/nfs0/chinaEquityData/panel/barra/exp-YYYYMMDD.sdiv", "inclusive": False},
    #     # {"pattern": terms.mpvI, "calc_f": partial(mad, pattern_list=terms.mpvI, add_suffix=".mad")},
    #     {"pattern": terms.Y, "columns":[], "calc_f": partial(get_conditionals, conditionals=['W.period1'])},
    # ]}
    # main(fitting_name, X_pattern, canopus_inference=True)

    # batch_num = 1500
    # model_file = f"/data/bees1/unsafe/junming/equity_fitting/expt_res_tree_exclude202002/2024/tree_CAPQ_1m_forimp/fit.0/lgb.model"
    # features = lgb_importance_df(model_file)[0].sort_values("score_by_gain", ascending=False)["term"].tolist()# [:batch_num]
    fitting_name = "tree_CAPQ_1m_ds20min"
    Xname = f"X.{fitting_name}"
    X_pattern = {Xname: {"pattern": "/data/beef2/junming/data/CAPQ_1m_241001_5min/terms.YYYYMMDD.sdiv"}}
    main(fitting_name=fitting_name, X_pattern=X_pattern, fit_y="mret1h", canopus_inference=True, is_output_ii=list(range(1,49,4)))
    fitting_name = "tree_CAPQ_1m_ds30min"
    Xname = f"X.{fitting_name}"
    X_pattern = {Xname: {"pattern": "/data/beef2/junming/data/CAPQ_1m_241001_5min/terms.YYYYMMDD.sdiv"}}
    main(fitting_name=fitting_name, X_pattern=X_pattern, fit_y="mret1h", canopus_inference=True, is_output_ii=list(range(1,49,6)))

    # fitting_name = "tree_CAPQ_1m_imp1500_cofitBarraW1"
    # Xname = f"X.{fitting_name}"
    # X_pattern = {Xname: [
    #     {"pattern": "/data/beef2/junming/data/CAPQ_1m_241001_5min/terms.YYYYMMDD.sdiv", "columns": features},
    #     {"pattern": "/data/nfs0/chinaEquityData/panel/barra/exp-YYYYMMDD.sdiv", "inclusive": False},
    #     # {"pattern": terms.mpvh, "calc_f": partial(mad, pattern_list=terms.mpvh, add_suffix=".mad")},
    #     {"pattern": terms.Y, "columns":[], "calc_f": partial(get_conditionals, conditionals=['W.period1'])},
    # ]}
    # main(fitting_name=fitting_name, X_pattern=X_pattern, fit_y="mret1h", canopus_inference=True)


    # re feature selection
    # fit_y = "mret24h"
    # for batch_num in [3000, 4000, 5500]:
    #     model_file = f"/data/bees1/unsafe/junming/equity_fitting/online202409/tree_imp_fs_u/{fit_y}_fs/fit.0/lgb.model"
    #     features = lgb_importance_df(model_file)[0].sort_values("score_by_gain", ascending=False)["term"].tolist()[:batch_num]
    #     fitting_name = f"tree_m24h_imp{len(features)}"
    #     Xname = f"X.{fitting_name}"
    #     X_pattern = {Xname: {"pattern": terms.tree_all_u,  "columns": features}}
    #     main(fitting_name, X_pattern, canopus_inference=True)
    # fit_y = "mret24h"
    # node_name = "tree_all_u_terms_allU_isvd"
    # df, ss = show_stats(node_name=node_name, return_dfss=True)
    # method = 'SR'
    # label_df = df.xs("w_c1").xs(fit_y)
    # ratio = (label_df[("vd", method)] / label_df[("is", method)])
    # sorted_features = (label_df[("is", method)].abs() * (ratio.clip(lower=0, upper=1) ** 0.5)).dropna().sort_values(ascending=False).index.tolist()  # 用根号ratio来加权is的FR
    # for batch_num in [500, 1000, 1500, 2000]:  # , 3000, 4000
    #     features = sorted_features[:batch_num]
    #     fitting_name = f"tree_m24h_SRcorrect{len(features)}"
    #     Xname = f"X.{fitting_name}"
    #     X_pattern = {Xname: {"pattern": terms.tree_all_u,  "columns": features}}
    #     main(fitting_name, X_pattern, canopus_inference=True)
    # exit()

    m24h1500_features = read_json("/data/bees1/unsafe/junming/equity_fitting/online202409/tree_model/tree_u_mret24h_overallimp1500/fit.0/feature_names.json")
    other_patterns = terms.tsrdcp_CA
    other_features = reduce(list.__add__, [read_columns_from_pattern(pattern) for pattern in other_patterns])

    # fitting_name = "tree_m24h1500_lgbnew_rerun"
    # Xname = f"X.{fitting_name}"
    # X_pattern = {Xname: {"pattern": terms.tree_all_u,  "columns": m24h1500_features}}
    # main(fitting_name, X_pattern, canopus_inference=True)

    fitting_name = "tree_tsrdcp_CA"
    Xname = f"X.{fitting_name}"
    X_pattern = {Xname: {"pattern": other_patterns}}
    main(fitting_name, X_pattern, canopus_inference=True)

    fitting_name = "tree_m24h1500_cofit_tsrdcp_CA"
    Xname = f"X.{fitting_name}"
    X_pattern = {Xname: [
        {"pattern": terms.tree_all_u, "columns": m24h1500_features, "rename": "tree_all_u"},
        {"pattern": other_patterns, "rename": "tsrdcp_CA"},
    ]}
    main(fitting_name, X_pattern, canopus_inference=True)
    exit()

    # pattern = [
    #     "/data/beef3/guopeng/alter_data/repo_senti_stats/000.ca.repo_senti_stats/selected1.YYYYMMDD.sdiv",
    #     "/data/beef3/guopeng/alter_data/news_cls_senti_stats/000.ca.news_cls_senti_stats/selected1.YYYYMMDD.sdiv",
    #     "/data/beef3/guopeng/alter_data/anns_senti_stats_o1/000.ca.anns_senti_stats_o1/selected1.YYYYMMDD.sdiv",
    #     "/data/beef3/guopeng/alter_data/anns_senti_stats_ind/000.ca.anns_senti_stats_ind/selected1.YYYYMMDD.sdiv",
    # ]
    # fitting_name = "tree_senti_final"
    # Xname = f"X.{fitting_name}"
    # X_pattern = {Xname: pattern}
    # main(fitting_name=fitting_name, X_pattern=X_pattern)

    # all_features = read_json("/data/bees1/unsafe/junming/equity_fitting/online202409/tree_model/tree_u_mret24h_overallimp1500/fit.0/feature_names.json")
    # for univ in ["G2548", "sz", "sh"]:
    #     fitting_name = f"mret1500_lgbnew_{univ}"
    #     Xname = f"X.{fitting_name}"
    #     X_pattern = {Xname: {"pattern": terms.tree_all_u, "columns": all_features}}
    #     main(fitting_name, X_pattern, canopus_inference=True, univ=univ)

    # fitting_name = "tree_CAPQ_1m_forimp"
    # Xname = f"X.{fitting_name}"
    # X_pattern = {Xname: {"pattern": "/data/beef2/junming/data/CAPQ_1m_241001_5min/terms.YYYYMMDD.sdiv"}}
    # main(fitting_name=fitting_name, X_pattern=X_pattern, fit_y="mret1h", canopus_inference=True)

    all_features = read_json("/data/bees1/unsafe/junming/equity_fitting/online202409/tree_model/tree_u_mret24h_overallimp1500/fit.0/feature_names.json")
    fitting_name = f"mret1500_normalY_lgbnew"
    Xname = f"X.{fitting_name}"
    X_pattern = {Xname: {"pattern": terms.tree_all_u, "columns": all_features}}
    main(fitting_name, X_pattern, Yname='Y.normal', canopus_inference=True)
    exit()

    # fitting_name = f"mpvI_lgbnew"
    # Xname = f"X.{fitting_name}"
    # X_pattern = {Xname: {"pattern": terms.mpvI}}
    # main(fitting_name, X_pattern, canopus_inference=True)

    # BOD fitting 每天一个样本点 / 都有样本点
    # Xname, Yname, Wname = "X", "Y", "W"
    # pattern = [
    #     "/data/beef3/guopeng/research/daily_fea/fea_stats/000.ca.fea_stats/terms.YYYYMMDD.sdiv",
    # ]
    # X_pattern = {Xname: {"pattern": pattern, "inclusive": True}}
    # fitting_name = f"daily_fea_fit_mret24h_bod_lgbnew_multiplier_2018"
    # main(fitting_name=fitting_name, fit_y="mret24h", X_pattern=X_pattern, Yname=Yname, Wname=Wname, include_YW=True, canopus_inference=True)

    daily_fea_pattern = "/data/beef2/junming/data/daily_fea/terms.YYYYMMDD.sdiv"
    # fitting_name = f"daily_fea_allI_fit_bret5e"
    # Xname = f"X.{fitting_name}"
    # X_pattern = {Xname: {"pattern": "/data/beef2/junming/data/daily_fea/terms.YYYYMMDD.sdiv"}}
    # main(fitting_name, X_pattern, fit_y="bret5e", canopus_inference=True)

    df, ss = show_stats(node_name="tree_all_u_terms", return_dfss=True)
    y = "bret5e"
    df_y = df.xs("w_c1").xs(y).xs("is", axis=1).abs()
    method = "FR" if y == 'mret1h' else "SR"
    batch_num = 1500 if y == 'mret24h' else 1000
    features = df_y.sort_values(method, ascending=False).index[:batch_num].tolist()
    
    fitting_name = f"tree_{y}_{method}{batch_num}"
    Xname = f"X.{fitting_name}"
    X_pattern = {Xname: {"pattern": terms.tree_all_u, "columns": features}}
    main(fitting_name, X_pattern, fit_y=y, canopus_inference=True)

    fitting_name = f"tree_{y}_{method}{batch_num}_cofit"
    Xname = f"X.{fitting_name}"
    X_pattern = {Xname: {"pattern": terms.tree_all_u+[daily_fea_pattern], "columns": features+read_columns_from_pattern(daily_fea_pattern)}}
    main(fitting_name, X_pattern, fit_y=y, canopus_inference=True)