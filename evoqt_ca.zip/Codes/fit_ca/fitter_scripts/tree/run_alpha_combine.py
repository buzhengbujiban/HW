# from fit_ca.qrfitter3_node import *
from qrfitter3.rnodes.qrfitter3_node import *
from fit_ca.canopus_scripts.dump_shm import prepare_shm
import copy


def get_extra_tasks(x_file_names:List[str], grid_label="mret24h"):
    issample = "20200102_20221230"
    outsample = "20230103_20231013"
    if grid_label == "mret24h":
        y_file_name = "Y"
        labels = ["mret24h"]
    elif grid_label == "barra":
        y_file_name = "Y"
        labels = ["mret24h", "bret24h", "bpret24h"]
    elif grid_label == "OI":
        y_file_name = "Y.OI"
        rets = ["mret"]  # "mret", "bret", "bpret"
        parts = ["0itrd", "ovnt", "1o"]  # "0itrd", "ovnt", "1o", "1itrd", "itrd", "ovnt_res", "itrd_res", "1e1o"
        labels = [f"{ret}_{part}" for ret in rets for part in parts]
    
    extra_tasks = []
    for y in labels:
        for x_file_name in x_file_names:
            x_files = f"/dev/shm/{issample}.{x_file_name}_d_concat.sdiv"
            x_files_inference = f"/dev/shm/{outsample}.{x_file_name}.5min_d_concat.sdiv"
            y_file = f"/dev/shm/{issample}.{y_file_name}_d_concat.sdiv"
            y_file_inference = f"/dev/shm/{outsample}.{y_file_name}.5min_d_concat.sdiv"
            extra_tasks.append({
                "dataset": {"fit_y": y, "x_files": x_files, "y_file": y_file},
                "inference_dataset": {"fit_y": y, "x_files": x_files_inference, "y_file": y_file_inference}
            })
    return extra_tasks


X = "X"  # X.ae_bottleneck
dataset_config = {
    "x_files": f"/dev/shm/20200102_20221230.{X}_d_concat.sdiv",
    "y_file": "/dev/shm/20200102_20221230.Y_d_concat.sdiv",
    "w_file": "/dev/shm/20200102_20221230.W_d_concat.sdiv",
    "fit_y": "mret24h",
    "fit_w": "wgt"
}
inference_dataset_config = {
    "x_files": f"/dev/shm/20230103_20231013.{X}.5min_d_concat.sdiv",
    "y_file": "/dev/shm/20230103_20231013.Y.5min_d_concat.sdiv",
    "w_file": "/dev/shm/20230103_20231013.W.5min_d_concat.sdiv",
    "fit_y": "mret24h",
    "fit_w": "wgt"
}

fitter_config = {
    "class": "lgbRegressor",
    "para_dict": {
        'task': 'train',
        'device': 'cpu',
        'num_threads': 100,
        'boosting_type': 'gbdt',
        'objective': 'regression',
        'metric': 'custom',
        'learning_rate': 0.05,
        'verbose': -1,
        'feature_fraction': 0.7,  # if you set it to 0.8, LightGBM will select 80% of features before training each tree
        'bagging_fraction': 0.9,
        'bagging_freq': 2,  # 0 means disable bagging; k means perform bagging at every k iteration. Every k-th iteration, LightGBM will randomly select bagging_fraction * 100 % of the data to use for the next k iterations
        'max_depth': 6,
        'num_leaves': 64,
        'num_iterations': 3000,
        'min_child_samples': 20,  # minimal number of data in one leaf， an approximation based on the Hessian
        'min_child_weight': 0.001,  # minimal sum hessian in one leaf.
        'reg_alpha': 0.5,  # L1
        'reg_lambda': 1  # L2
    },
    "useExistModel": False
}
task_config = {
    "train": {"start_date": "20200101", "end_date": "20220631"},
    "valid": {"start_date": "20220701", "end_date": "20221231"},
    "test": {"start_date": "20230101", "end_date": "20231031"},
}
roller_confg = {
    "start_date":        "20230101",
    "end_date":          "20230731",
    "test_start_month":  "202304",
    "test_window":       2,
    "valid_window":      1,
    "gen_next_month":    True,
    "max_train_months":  2
}

qf_config_base = {
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
}

RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_tree_exclude202002"  # change to your own directory
RNode.GLOBAL_TASKNAME = "alpha_combine"

base_x = "/data/beef2/junming/data/combine1999/terms.YYYYMMDD.sdiv"
data_base = {
    "Y": "/data/beef2/junming/data/clipped_label/terms.YYYYMMDD.sdiv",
    "W": "/data/beef2/junming/data/is_active/terms.YYYYMMDD.sdiv",
}


fit_base_x = False
if fit_base_x:
    data = copy.deepcopy(data_base)
    data['X'] = base_x
    prepare_shm(data=data, d_concat=True)
    qf_config = copy.deepcopy(qf_config_base)
    fitting_name = "ca1999"
    qf_config.update({
        "fitting_name": fitting_name,
        "extra_tasks": get_extra_tasks(x_file_names=["X"], grid_label="mret24h"),
    })
    qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
    qf3.gen_tasks()
    qf3.run(para_spec="1")
    prepare_shm(clear_patterns=list(data.keys()), d_concat=True)


PQ_path = "/data/beef2/mike/PQ_terms_v24.0614"
PQprocessed_path = "/data/beef2/zifan/mike_data"
l2_noLOB = [
    "/data/beef2/guopeng/l2_project/imb_tsreg3/000.ca.imb_tsreg3",
    "/data/beef2/guopeng/l2_project/imb_tsreg2/000.ca.imb_tsreg2",
]
l2_noLOB_resi = [   
    "/data/beef2/guopeng/l2_project/imb_tsreg2_m/000.ca.imb_tsreg2_m",
    "/data/beef2/guopeng/l2_project/imb_tsreg3_m/000.ca.imb_tsreg3_m",
]
chunxiao_batch = [1, 4, 5, 6, 8, 10, 11, 14, 18]
imb_tsreg = [
    "/data/beef2/guopeng/l2_project/atc_tsreg2_m1/000.ca.atc_tsreg2_m1",
    "/data/beef2/guopeng/l2_project/atc_tsreg3_m1/000.ca.atc_tsreg3_m1",
    "/data/beef2/guopeng/l2_project/imb_tsreg2_m1/000.ca.imb_tsreg2_m1",
    "/data/beef2/guopeng/l2_project/imb_tsreg3_m1/000.ca.imb_tsreg3_m1",
    "/data/beef2/guopeng/l2_project/imb_xsreg2_m1/000.ca.imb_xsreg2_m1",
    "/data/beef2/guopeng/l2_project/imb_xsreg3_m1/000.ca.imb_xsreg3_m1",
]
l2_report = [
    "/data/beef2/guopeng/l2_project/l2retApen/000.ca.l2retApen/",
    "/data/beef2/guopeng/l2_project/l2ar/000.ca.l2ar",
    "/data/beef2/guopeng/l2_project/vsareg/000.ca.vsareg",
    "/data/beef2/guopeng/l2_project/l2smart/000.ca.l2smart",
    "/data/beef2/guopeng/l2_project/l2str/000.ca.l2str",
]
l2_batch3 = [
    "/data/beef2/guopeng/l2_project/vwret_tsreg2/000.ca.vwret_tsreg2/",
    "/data/beef2/guopeng/l2_project/vwret_tsreg3/000.ca.vwret_tsreg3/",
    "/data/beef2/guopeng/l2_project/bs_xsreg_imb1/000.ca.bs_xsreg_imb1/",
    "/data/beef2/guopeng/l2_project/bs_xsreg_imb2/000.ca.bs_xsreg_imb2/",
    "/data/beef2/guopeng/l2_project/didsmb_stats/000.ca.didsmb_stats/",
    "/data/beef2/guopeng/l2_project/l2herd/000.ca.l2herd/",
]
bk2_folder = "/data/beef2/mike/shared/bk2_terms"
bk2 = [os.path.join(bk2_folder, batch) for batch in os.listdir(bk2_folder)]

con_proj2 = [
    "/data/beef2/guopeng/concept_project/rroot/con_proj4/000.ca.con_proj4",
    "/data/beef2/guopeng/concept_project/rroot/con_proj3/000.ca.con_proj3",
    "/data/beef2/guopeng/concept_project/rroot/con_proj2/000.ca.con_proj2",
    "/data/beef2/guopeng/concept_project/rroot/con_proj/000.ca.con_proj",
    "/data/beef2/guopeng/concept_project/rroot/emb_proj1/000.ca.emb_proj1",
    "/data/beef2/guopeng/concept_project/rroot/emb_proj2/000.ca.emb_proj2",
    "/data/beef2/guopeng/concept_project/rroot/emb_proj4/000.ca.emb_proj4",
]

pq_cxl_folder = "/data/beef2/mike/shared/pq_cxl"
pq_cxl = [os.path.join(pq_cxl_folder, batch) for batch in os.listdir(pq_cxl_folder)]

qiml01 = [
    "/data/beef2/guopeng/qiml2024/qiml0101/000.ca.qiml0101/",
    "/data/beef2/guopeng/qiml2024/qiml0102/000.ca.qiml0102/",
    "/data/beef2/guopeng/qiml2024/qiml0105/000.ca.qiml0105/",
    "/data/beef2/guopeng/qiml2024/qiml0116/000.ca.qiml0116/",
    "/data/beef2/guopeng/qiml2024/qiml0119/000.ca.qiml0119/",
    "/data/beef2/guopeng/qiml2024/qiml0120/000.ca.qiml0120/",
    "/data/beef2/guopeng/qiml2024/qiml0124/000.ca.qiml0124/",
    "/data/beef2/guopeng/qiml2024/qiml0130/000.ca.qiml0130/",
    "/data/beef2/guopeng/qiml2024/qiml0131/000.ca.qiml0131/",
]

qiml02 = [
    "/data/beef2/guopeng/qiml2024/qiml0202/000.ca.qiml0202",
    "/data/beef2/guopeng/qiml2024/qiml0205/000.ca.qiml0205",
    "/data/beef2/guopeng/qiml2024/qiml0208/000.ca.qiml0208",
    "/data/beef2/guopeng/qiml2024/qiml0214/000.ca.qiml0214",
    "/data/beef2/guopeng/qiml2024/qiml0221/000.ca.qiml0221",
    "/data/beef2/guopeng/qiml2024/qiml0224/000.ca.qiml0224",
    "/data/beef2/guopeng/qiml2024/qiml0225/000.ca.qiml0225",
    "/data/beef2/guopeng/qiml2024/qiml0228/000.ca.qiml0228",
]

tss_folder = "/data/beef2/mike/CA_terms_tssovn/tss_terms"
ovn_folder = "/data/beef2/mike/CA_terms_tssovn/ovn_terms"
tss = [os.path.join(tss_folder, batch) for batch in os.listdir(tss_folder)]
ovn = [os.path.join(ovn_folder, batch) for batch in os.listdir(ovn_folder)]
tssovn = tss + ovn

name = "qiml02"
extras = {
    # "X.PQ": [os.path.join(PQ_path, batch, "terms.YYYYMMDD.sdiv") for batch in os.listdir(PQ_path)],
    # "X.PQprocessed_peak": [os.path.join(PQprocessed_path, batch, "terms.YYYYMMDD.sdiv") for batch in os.listdir(PQprocessed_path) if batch.endswith("peak")],
    # "X.l2_noLOB.select1": [os.path.join(folder, "selected1.YYYYMMDD.sdiv") for folder in l2_noLOB],
    # "X.l2_noLOB_resi.select1": [os.path.join(folder, "selected1.YYYYMMDD.sdiv") for folder in l2_noLOB_resi],
    # "X.chunxiao.select1": [f"/data/beef2/guopeng/zp_alpha_ex/chunxiao{i}/000.ca.chunxiao{i}/selected1.YYYYMMDD.sdiv" for i in chunxiao_batch],
    # "X.chunxiao.select2": [f"/data/beef2/guopeng/zp_alpha_ex/chunxiao{i}/000.ca.chunxiao{i}/selected2.YYYYMMDD.sdiv" for i in chunxiao_batch],
    # "X.imb_tsreg.select1": [os.path.join(batch_folder, "selected1.YYYYMMDD.sdiv") for batch_folder in imb_tsreg],
    # "X.imb_tsreg.select2": [os.path.join(batch_folder, "selected2.YYYYMMDD.sdiv") for batch_folder in imb_tsreg],
    # "X.imb_corrsum2.select2": ["/data/beef2/guopeng/l2_project/imb_corrsum2_m1/000.ca.imb_corrsum2_m1/selected2.YYYYMMDD.sdiv"],
    # "X.l2retApen.selected1": ["/data/beef2/guopeng/l2_project/l2retApen/000.ca.l2retApen/selected1.YYYYMMDD.sdiv"],
    # "X.ruud_mc": ["/data/bees1/unsafe/ruud/mc/v1_univ_G2548_220731/post/YYYYMMDD.sdiv"],
    # "X.thsalpha": ["/data/beef2/guopeng/thsidx/test_thsalpha/000.ca.test_thsalpha/terms.YYYYMMDD.sdiv"],
    # f"X.{name}.select1": [os.path.join(batch_folder, "selected1.YYYYMMDD.sdiv") for batch_folder in eval(name)],  # 有select12用这个
    # f"X.{name}.select2": [os.path.join(batch_folder, "selected2.YYYYMMDD.sdiv") for batch_folder in eval(name)],
    # f"X.test_con": ["/data/beef2/guopeng/concept_project/rroot/test_con/000.ca.test_con/terms.YYYYMMDD.sdiv"],
    # f"X.{name}": [os.path.join(batch_folder, "terms.YYYYMMDD.sdiv") for batch_folder in eval(name)],  # 只有一批，没有select12用这个
    "X.tss": [os.path.join(batch_folder, "terms.YYYYMMDD.sdiv") for batch_folder in tss],
    "X.ovn": [os.path.join(batch_folder, "terms.YYYYMMDD.sdiv") for batch_folder in ovn],
}

configs = [
    {"output_ii": list(range(1,49,2)), "start_date": "20200101", "end_date": "20221231"},  # 每十分钟采样, is  
    {"output_ii": None, "start_date": "20230101", "end_date": "20231013"}  # 不downsample, oos
]
for name, extra_x in extras.items():
    data = copy.deepcopy(data_base)
    data[f'{name}.only'] = extra_x
    data[f'{name}.cofit'] = [base_x] + extra_x

    prepare_shm(data=data, d_concat=True, configs=configs)
    qf_config = copy.deepcopy(qf_config_base)
    fitting_name = name
    qf_config.update({
        "fitting_name": fitting_name,
        "extra_tasks": get_extra_tasks(x_file_names=[f'{name}.only', f'{name}.cofit'], grid_label="mret24h"),
    })
    qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
    qf3.gen_tasks()
    qf3.run(para_spec="1")
    prepare_shm(clear_patterns=list(data.keys()), d_concat=True)