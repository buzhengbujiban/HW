from fit_ca.qrfitter3_node import *
from fit_ca.canopus_scripts.dump_shm import *
from online202409.utils import get_features_from_extra_tasks, load_train_test_data_shm


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_tree_exclude202002/"  # change to your own directory
RNode.GLOBAL_TASKNAME = "2024"

X, Y, W = "X.subalpha42_addcond", "Y", "W"
X_pattern = {
    X: {
        "pattern": [
            "/data/bees1/safe/junming/equity_fitting/online202409/croll/ca1999_mlpfs_3batch300_7y/subalpha_panel/terms.YYYYMMDD.sdiv", 
            "/data/bees1/safe/junming/equity_fitting/online202409/croll/tree_ca1999_mlpfs_3batch300_7y/subalpha_panel/terms.YYYYMMDD.sdiv"
        ],
        "calc_f": get_conditionals
    }
}
train_start_end, test_start_end = load_train_test_data_shm(X_pattern=X_pattern, d_concat=True)
dataset_config                  = QRFitter3Node.base_concat_dataset_config(start_end=train_start_end, Xname=X, Yname=Y, Wname=W)
inference_dataset_config        = QRFitter3Node.base_concat_dataset_config(start_end=test_start_end, is5min=True, Xname=X, Yname=Y, Wname=W)
fitter_config                   = QRFitter3Node.base_fitter_config(model="lgb")
task_config                     = QRFitter3Node.base_task_config(oos=20232024)
roller_confg                    = QRFitter3Node.base_roller_config(croll=False)
# fitter_config["para_dict"]['num_threads'] = 120

fitting_name = "subalpha42_addcond"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    # "roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    # "extra_tasks": extra_tasks_config,
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks()
qf3.run(para_spec="1")
load_train_test_data_shm(X_pattern=X_pattern, clear=True, d_concat=True)