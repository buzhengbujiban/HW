# from fit_ca.qrfitter3_node import *
from qrfitter3.rnodes.qrfitter3_node import *
from fit_ca.canopus_scripts.dump_shm import prepare_shm
import copy


def get_extra_tasks(x_file_names:List[str], grid_label="mret24h"):
    issample = "20200102_20221230"
    outsample = "20230103_20231013"
    if grid_label == "mret24h":
        y_file_name = "Y"
        labels = ["mret24h"]
    elif grid_label == "barra":
        y_file_name = "Y"
        labels = ["mret24h", "bret24h", "bpret24h"]
    elif grid_label == "OI":
        y_file_name = "Y.OI"
        rets = ["mret"]  # "mret", "bret", "bpret"
        parts = ["0itrd", "ovnt", "1o"]  # "0itrd", "ovnt", "1o", "1itrd", "itrd", "ovnt_res", "itrd_res", "1e1o"
        labels = [f"{ret}_{part}" for ret in rets for part in parts]
    
    extra_tasks = []
    for y in labels:
        for x_file_name in x_file_names:
            x_files = f"/dev/shm/{issample}.{x_file_name}_d_concat.sdiv"
            x_files_inference = f"/dev/shm/{outsample}.{x_file_name}.5min_d_concat.sdiv"
            y_file = f"/dev/shm/{issample}.{y_file_name}_d_concat.sdiv"
            y_file_inference = f"/dev/shm/{outsample}.{y_file_name}.5min_d_concat.sdiv"
            extra_tasks.append({
                "dataset": {"fit_y": y, "x_files": x_files, "y_file": y_file},
                "inference_dataset": {"fit_y": y, "x_files": x_files_inference, "y_file": y_file_inference}
            })
    return extra_tasks


X = "X"  # X.ae_bottleneck
dataset_config = {
    "x_files": f"/dev/shm/20200102_20221230.{X}_d_concat.sdiv",
    "y_file": "/dev/shm/20200102_20221230.Y_d_concat.sdiv",
    "w_file": "/dev/shm/20200102_20221230.W_d_concat.sdiv",
    "fit_y": "mret24h",
    "fit_w": "wgt"
}
inference_dataset_config = {
    "x_files": f"/dev/shm/20230103_20231013.{X}.5min_d_concat.sdiv",
    "y_file": "/dev/shm/20230103_20231013.Y.5min_d_concat.sdiv",
    "w_file": "/dev/shm/20230103_20231013.W.5min_d_concat.sdiv",
    "fit_y": "mret24h",
    "fit_w": "wgt"
}

fitter_config = {
    "class": "lgbRegressor",
    "para_dict": {
        'task': 'train',
        'device': 'cpu',
        'num_threads': 100,
        'boosting_type': 'gbdt',
        'objective': 'regression',
        'metric': 'custom',
        'learning_rate': 0.05,
        'verbose': -1,
        'feature_fraction': 0.7,  # if you set it to 0.8, LightGBM will select 80% of features before training each tree
        'bagging_fraction': 0.9,
        'bagging_freq': 2,  # 0 means disable bagging; k means perform bagging at every k iteration. Every k-th iteration, LightGBM will randomly select bagging_fraction * 100 % of the data to use for the next k iterations
        'max_depth': 6,
        'num_leaves': 64,
        'num_iterations': 3000,
        'min_child_samples': 20,  # minimal number of data in one leaf， an approximation based on the Hessian
        'min_child_weight': 0.001,  # minimal sum hessian in one leaf.
        'reg_alpha': 0.5,  # L1
        'reg_lambda': 1  # L2
    },
    "useExistModel": False
}
task_config = {
    "train": {"start_date": "20200101", "end_date": "20220631"},
    "valid": {"start_date": "20220701", "end_date": "20221231"},
    "test": {"start_date": "20230101", "end_date": "20231031"},
}
roller_confg = {
    "start_date":        "20230101",
    "end_date":          "20230731",
    "test_start_month":  "202304",
    "test_window":       2,
    "valid_window":      1,
    "gen_next_month":    True,
    "max_train_months":  2
}

qf_config_base = {
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
}

RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_tree_exclude202002"  # change to your own directory
RNode.GLOBAL_TASKNAME = "feature_selection"

base_x = "/data/beef2/junming/data/combine1999/terms.YYYYMMDD.sdiv"
data_base = {
    "Y": "/data/beef2/junming/data/clipped_label/terms.YYYYMMDD.sdiv",
    "W": "/data/beef2/junming/data/is_active/terms.YYYYMMDD.sdiv",
}

name_groups = read_json("/data/beef2/junming/data/lasso_sel_features/nfnzo.json")  # 不同lasso强度选出来的features子集

configs = [
    {"output_ii": list(range(1,49,2)), "start_date": "20200101", "end_date": "20221231"},  # 每十分钟采样, is  
    {"output_ii": None, "start_date": "20230101", "end_date": "20231013"}  # 不downsample, oos
]
for name, group in name_groups.items():
    data = copy.deepcopy(data_base)
    data[name] = {"pattern": base_x, "columns": group}

    prepare_shm(data=data, d_concat=True, configs=configs)
    qf_config = copy.deepcopy(qf_config_base)
    fitting_name = name
    qf_config.update({
        "fitting_name": fitting_name,
        "extra_tasks": get_extra_tasks(x_file_names=[name], grid_label="mret24h"),
    })
    qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
    qf3.gen_tasks()
    qf3.run(para_spec="1")
    prepare_shm(clear_patterns=list(data.keys()), d_concat=True)