import os
import re
from tqdm import tqdm
import time
from typing import List, Dict
from pathlib import Path
# jobs这个库在qrlite，如果没有请注意看qrlite是否在自己的Python路径下
from jobs.rnodes.rnode import RNode, SlurmCfg
from canopus_py.rnodes.ca_node import CANode
# StatsNode是特征测试时使用
# from canopus_py.rnodes.stats_node import StatsNode
# ca对象在这里导入
from canopus_py.ca_expr import *
from canopus_py.ca_stats import *

from pattern_helper import *
from qrfitter3.utils import save_json, read_json
from qrfitter3.utils import wait_for_processes

CANode.DEFAULT_CA_BINARY = "/data/beef2/bin/unstable/canopus"

UNIV = {
    "G2548": "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv",
    "G200": "/data/beef2/data/CA/CNEQ/Univs/gpfast_new/gpf_G200.csv",
    "G500": "/data/beef2/data/CA/CNEQ/Univs/gpfast_new/gpf_G500.csv",
    "G1000": "/data/beef2/data/CA/CNEQ/Univs/gpfast_new/gpf_G1000.csv",
    "Gunion": "/data/beef2/junming/universe/Gunion.csv",
    "Gother": "/data/beef2/junming/universe/Gother.csv",
}

inds_CNE5 = [
    'AEROSPCE', 'AIRLINES', 'APPAREL', 'AUTOCOMP',
    'BANKS', 'BEVTOB', 'BLDPROD', 'COMMSVCS', 'CHEMICAL', 'CONGTRD',
    'CNSTENG', 'CONMAT', 'CONSDUR', 'CONSRV', 'DIVFINAN', 'ELECEQP',
    'ENERGY', 'FOODPROD', 'FSTAPHPP', 'HDWRSE', 'HEALTH', 'MACHINRY',
    'MARINE', 'MEDIA', 'MTLMIN', 'OTHRCHEM', 'PACKGFP', 'REALEST', 'RETAIL',
    'RDRLTRAN', 'SOFTWARE', 'UTILITY',
]
stls_CNE5 = [
    'ANLYSTSN', 'BETA', 'BTOP', 'DIVYILD', 'EARNQLTY', 'EARNVAR',
    'EARNYILD', 'GROWTH', 'INDMOM', 'INVSQLTY', 'LEVERAGE', 'LIQUIDTY',
    'LTREVRSL', 'MIDCAP', 'MOMENTUM', 'PROFIT', 'RESVOL', 'SEASON',
    'STREVRSL', 'SIZE'
]
factors_CNE5D = inds_CNE5+stls_CNE5


def create_fake_files(dates, folder_path=f"/tmp/{os.environ['USER']}/fake_pattern_{os.getpid()}"):
    file_pattern = "fake.YYYYMMDD.sdiv"
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    for date in dates:
        file_name = file_pattern.replace("YYYYMMDD", str(date))
        file_path = os.path.join(folder_path, file_name)
        with open(file_path, 'w') as file:
            pass  # 创建一个空文件
    return os.path.join(folder_path, file_pattern)

def get_common_date_pattern(*patterns):
    common_dates = set(find_dates_from_pattern(patterns[0]))
    for pattern in patterns[1:]:
        common_dates = common_dates.intersection(find_dates_from_pattern(pattern))
    common_dates = sorted(list(common_dates))
    date_pattern = create_fake_files(common_dates)
    return date_pattern

def get_run_periods(pattern, start_date:str=None, end_date:str=None):
    run_periods = find_dates_from_pattern(pattern)
    start_date = 0 if start_date is None else int(start_date)
    end_date = 30000000 if end_date is None else int(end_date)
    run_periods = [d for d in run_periods if d >= start_date and d <= end_date]
    return run_periods


def dump_shm(
    label, *, pattern: str|List[str], date_pattern=None, inclusive: bool=None, regress: str|List[str]='o',
    start_date:str=None, end_date:str=None, columns: str|List[str] = None, d_concat=False,
    output_ii=None, univ="G2548", para_spec=80
):
    """把pattern文件(如多个则combine后)dump到shm里，shm里名字叫label"""
    sample_suffix = '.5min' if output_ii is None else ''
    univ_suffix = "" if univ == "G2548" else f".{univ}"
    label = f"{label}{sample_suffix}{univ_suffix}"

    node_config = CANode.base_config()
    node_config["CA.univ"] = UNIV[univ]
    # 加入Barraexp数据
    panel_name = "BarraExp"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = "/data/beef2/guopeng/risk_model/DRMRisk/DRMRisk.v5/DRMRisk-YYYYMMDD.sdiv"
    node_config[f"DATA.{panel_name}.inclusive"] = False  # barra exp YYYYMMDD.sdiv要下一天bod才能用
    factors_all = [ca.Na20(i) for i in factors_CNE5D]

    if isinstance(pattern, str):  # 只有一个文件
        if date_pattern is None:
            date_pattern = pattern
        node_config["DATA.panels"] += ["terms"]
        node_config["DATA.terms.pattern"] = pattern
        if inclusive is not None:  # 代表pattern是daily panel
            node_config["DATA.terms.inclusive"] = inclusive  # true的话代表当天能用，false的话代表第二天才能用
        terms = read_columns_from_pattern(pattern)
    elif isinstance(pattern, list):  # 多个文件combine
        if date_pattern is None:
            date_pattern = pattern[0]
        terms = []
        for i, patt in enumerate(pattern):
            panel_name = f"batch{i}"
            node_config["DATA.panels"] += [panel_name]
            node_config[f"DATA.{panel_name}.pattern"] = patt
            batch_terms = read_columns_from_pattern(patt)
            node_config[f"DATA.{panel_name}.columns"] = batch_terms
            renamed_terms = [f"{panel_name}.{term}" for term in batch_terms]
            node_config[f"DATA.{panel_name}.column_masks"] = renamed_terms
            if inclusive is not None:  # 代表pattern是daily panel
                node_config[f"DATA.{panel_name}.inclusive"] = inclusive  # true的话代表当天能用，false的话代表第二天才能用
            terms.extend(renamed_terms)
    node_config["EVENTS.busdate_pattern"] = date_pattern

    if columns is None:  # 指定了只读那些fields
        columns = terms
    elif isinstance(columns, str):
        columns = [columns]

    if isinstance(regress, str):
        regress = [regress]
    for term in columns:  # 对terms的处理可以放在这里
        v = ca.Na20(ca(term))
        if 'o' in regress:
            node_config["CA.terms"][term] = v
        if 'b' in regress:
            node_config["CA.terms"][f"{term}.b"] = ca.RegRes(v, factors_all, bod_reg=True)
        if 'bp' in regress:
            node_config["CA.terms"][f"{term}.bp"] = ca.RegYHat(v, factors_all, bod_reg=True)
        # if univ == "G2548" or label.startswith("W"):  # XY本身在G2548内是均衡的，另外W不需要做demean
            # if label.startswith("Y.magic"):
            #     node.node_config["CA.terms"][term] = ca.XsRank(ca.Na20(ca(term)))
            # node_config["CA.terms"][term] = ca.Na20(ca(term))
        # else:
            # node_config["CA.terms"][term] = ca.Na20(term) - ca.XsMean(ca.Na20(term))
        # if label.startswith("X") and term.endswith('.rk'):  # TODO: temp hack
        #     node_config["CA.terms"][term] = node_config["CA.terms"][term] * ca.C(2.5)
    
    if d_concat:
        run_periods = get_run_periods(date_pattern, start_date, end_date)
        node_config["OUTPUT.shm"] = False
        node_config["OUTPUT.d_concat_shm"] = True
        node_config["OUTPUT.shm.dim_seq"] = "SDIV" # "DISV"
        node_config["OUTPUT.all_dates"] = run_periods
        node_config["OUTPUT.shm_label"] = f"{label}_d_concat"
    else:
        node_config["OUTPUT.shm"] = True
        node_config["OUTPUT.shm_label"] = label
    node_config["OUTPUT.terms"] = False
    if output_ii is not None:
        node_config["OUTPUT.terms.output_ii"] = output_ii  # downsample

    node = CANode(node_config, label=label, clean_dir_name=True, rnode_root=f"/tmp/{os.environ['USER']}", chain_name="dump_shm")
    run_periods = get_run_periods(date_pattern, start_date, end_date)
    node.run_periods = run_periods
    node.run(para_spec=para_spec)


def clear_shm(patterns: List[str]=None):
    """如何patterns是None代表清楚所有shm, 如果是空list代表不清"""
    print(f"cleaning shm for patterns: {patterns}")
    shm_dir = "/dev/shm"
    delete_count = 0
    delete_size = 0
    for file in tqdm(os.listdir(shm_dir)):
        if patterns is not None:
            remove = False
            for pattern in patterns:
                if re.search(pattern, file):
                    remove = True
                    break
            if not remove:
                continue
        file_path = os.path.join(shm_dir, file)
        if os.path.isfile(file_path):
            try:
                size = os.path.getsize(file_path)
                os.unlink(file_path)
            except PermissionError:
                pass
            else:
                delete_count += 1
                delete_size += size

    print(f"delete_count: {delete_count}; delete_size: {delete_size // 1024**3:.1f} GB")


def dump():
    univ = "G2548"
    d_concat = True
    configs = [
        {"output_ii": list(range(1,49,2)), "start_date": "20200101", "end_date": "20221231"},  # 每十分钟采样, is, oos=2023时够用了，只有croll才需要从20180501开始
        {"output_ii": None, "start_date": "20230101", "end_date": "20231013"},  # 不downsample, oos
    ]

    for config in configs:
        output_ii, start_date, end_date = config["output_ii"], config["start_date"], config["end_date"]
        
        data = {
            "X": "/data/beef2/junming/data/combine1999/terms.YYYYMMDD.sdiv",
            "Y": "/data/beef2/junming/data/clipped_label/terms.YYYYMMDD.sdiv",
            "W": "/data/beef2/junming/data/is_active/terms.YYYYMMDD.sdiv",
        }
        if d_concat:
            date_pattern = get_common_date_pattern(*data.values())  # 几个patern对应的文件必须同时写到data里从而生成inner date
            # date_pattern = "/tmp/junming/fake_pattern_1110607/fake.YYYYMMDD.sdiv"  # combine1999的日期，减去202002月
        else:
            date_pattern = None

        for label, pattern in data.items():
            if isinstance(pattern, (str, list)):
                dump_shm(label=label, pattern=pattern, date_pattern=date_pattern, start_date=start_date, end_date=end_date, d_concat=d_concat, output_ii=output_ii, univ=univ)
            elif isinstance(pattern, dict):
                dump_shm(label=label, **pattern, date_pattern=date_pattern, start_date=start_date, end_date=end_date, d_concat=d_concat, output_ii=output_ii, univ=univ)



from qrfitter3.rnodes.qrfitter3_node import *


def get_extra_tasks(x_file_names:List[str], grid_label="mret24h"):
    issample = "20200102_20221230"
    outsample = "20230103_20231013"
    if grid_label == "mret24h":
        y_file_name = "Y"
        labels = ["mret24h"]
    elif grid_label == "barra":
        y_file_name = "Y"
        labels = ["mret24h", "bret24h", "bpret24h"]
    elif grid_label == "OI":
        y_file_name = "Y.OI"
        rets = ["mret"]  # "mret", "bret", "bpret"
        parts = ["0itrd", "ovnt", "1o"]  # "0itrd", "ovnt", "1o", "1itrd", "itrd", "ovnt_res", "itrd_res", "1e1o"
        labels = [f"{ret}_{part}" for ret in rets for part in parts]
    
    extra_tasks = []
    for y in labels:
        for x_file_name in x_file_names:
            x_files = f"/dev/shm/{issample}.{x_file_name}_d_concat.sdiv"
            x_files_inference = f"/dev/shm/{outsample}.{x_file_name}.5min_d_concat.sdiv"
            y_file = f"/dev/shm/{issample}.{y_file_name}_d_concat.sdiv"
            y_file_inference = f"/dev/shm/{outsample}.{y_file_name}.5min_d_concat.sdiv"
            extra_tasks.append({
                "dataset": {"fit_y": y, "x_files": x_files, "y_file": y_file},
                "inference_dataset": {"fit_y": y, "x_files": x_files_inference, "y_file": y_file_inference}
            })
    return extra_tasks


X = "X"  # X.ae_bottleneck
dataset_config = {
    "x_files": f"/dev/shm/20200102_20221230.{X}_d_concat.sdiv",
    "y_file": "/dev/shm/20200102_20221230.Y_d_concat.sdiv",
    "w_file": "/dev/shm/20200102_20221230.W_d_concat.sdiv",
    "fit_y": "mret24h",
    "fit_w": "wgt"
}
inference_dataset_config = {
    "x_files": f"/dev/shm/20230103_20231013.{X}.5min_d_concat.sdiv",
    "y_file": "/dev/shm/20230103_20231013.Y.5min_d_concat.sdiv",
    "w_file": "/dev/shm/20230103_20231013.W.5min_d_concat.sdiv",
    "fit_y": "mret24h",
    "fit_w": "wgt"
}

fitter_config = {
    "class": "lgbRegressor",
    "para_dict": {
        'task': 'train',
        'device': 'cpu',
        'num_threads': 120,
        'boosting_type': 'gbdt',
        'objective': 'regression',
        'metric': 'custom',
        'learning_rate': 0.05,
        'verbose': -1,
        'feature_fraction': 0.7,  # if you set it to 0.8, LightGBM will select 80% of features before training each tree
        'bagging_fraction': 0.9,
        'bagging_freq': 2,  # 0 means disable bagging; k means perform bagging at every k iteration. Every k-th iteration, LightGBM will randomly select bagging_fraction * 100 % of the data to use for the next k iterations
        'max_depth': 6,
        'num_leaves': 64,
        'num_iterations': 3000,
        'min_child_samples': 20,  # minimal number of data in one leaf， an approximation based on the Hessian
        'min_child_weight': 0.001,  # minimal sum hessian in one leaf.
        'reg_alpha': 0.5,  # L1
        'reg_lambda': 1  # L2
    },
    "useExistModel": False
}
task_config = {
    "train": {"start_date": "20200101", "end_date": "20220631"},
    "valid": {"start_date": "20220701", "end_date": "20221231"},
    "test": {"start_date": "20230101", "end_date": "20231031"},
}

RNode.RNODE_ROOT = f"/data/bees1/safe/{os.environ['USER']}/equity_fitting/"
RNode.GLOBAL_TASKNAME = "expt_res_tree"


def run_fitting():
    extra_tasks_config = get_extra_tasks(x_file_names=["X"], grid_label="barra")
    fitting_name = "lgb_fit_barra_testpg1"
    qf_config = {
        "fitting_name": fitting_name,
        "dataset": dataset_config,
        "inference_dataset": inference_dataset_config,
        "fitter": fitter_config,
        "task": task_config,
        "extra_tasks": extra_tasks_config,
    }
    qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
    qf3.gen_tasks()
    qf3.run(para_spec="1")



if __name__ == "__main__":
    # clear_shm()
    # exit()
    dump()
    for i in range(2):
        run_fitting()
    clear_shm()
    