from fit_ca.qrfitter3_node import *


def get_extra_task_wgt():
    univ_wgts = ["is.active_csi300", "is.active_csi500", "is.active_csi800", "is.active_topx", "is.active_midx", "is.active_smlx", "is.active_botx"]
    wgts = ["is.active"]
    wgts.extend(univ_wgts)
    # for i in [2, 4, 8]:
    #     wgts.extend([f"{wgt}.{i}_other.1" for wgt in univ_wgts])
    extra_tasks = [
        {"dataset": {"fit_w": wgt}, "inference_dataset": {"fit_w": wgt}}
        for wgt in wgts
    ]
    return extra_tasks

def get_inference_config():  # valid集上的inference，因为y_hat_valid中只有子univ的yhat
    inference_dataset_config = QRFitter3Node.base_dataset_config()
    inference_fitter_config = QRFitter3Node.base_inference_fitter_config()
    inference_task_config = QRFitter3Node.base_inference_task_config(task=["inference"], set_name="valid_allU")  # , "inference_hidden" 可选2023要不要inference_hidden
    # 注意inference的dataset config中没有额外指定fit_y，给出来的sdiv中的y都是默认的mret24h
    inference_fitter_config["device_id"] = "0"

    qf_config = {
        "inference_dataset": inference_dataset_config,
        "fitter": inference_fitter_config,
        "task": inference_task_config,
    }
    return qf_config


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002"
RNode.GLOBAL_TASKNAME = "universe"

dataset_config = QRFitter3Node.base_dataset_config()
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp3", enable_RR=True)
task_config = QRFitter3Node.base_task_config(oos=20232024)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
extra_tasks_config = get_extra_task_wgt()

#fitter_config["max_epoch"] = 1

fitting_name = "wgt_x_hs_RR"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    "extra_tasks": extra_tasks_config,

}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)

qf3.gen_tasks(gpus=["6", "7"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="32")

# inference_config = get_inference_config()
# qf3.node_config = inference_config
# qf3.run_inference(para_spec="6")