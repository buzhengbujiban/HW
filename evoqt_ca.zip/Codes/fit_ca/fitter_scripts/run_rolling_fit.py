from fit_ca.qrfitter3_node import *


def get_extra_tasks(x_file_list:List[str|List[str]]=["X"]):
    rets = ["mret", "bret", "bpret"]
    parts = ["24h", "5e", "_1o", "_0itrd"]
    labels = [f"{ret}{part}" for ret in rets for part in parts]

    extra_tasks = []
    for y in labels:
        for x_file_names in x_file_list:
            if isinstance(x_file_names, str):
                x_file_names = [x_file_names]
            x_files = [f"/dev/shm/YYYYMMDD.{x_file_name}.sdiv" for x_file_name in x_file_names] 
            x_files_inference = [f"/dev/shm/YYYYMMDD.{x_file_name}.5min.sdiv" for x_file_name in x_file_names] 
            extra_tasks.append({
                "dataset": {"fit_y": y, "x_files": x_files},
                "inference_dataset": {"fit_y": y, "x_files": x_files_inference}
            })
    return extra_tasks


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
RNode.GLOBAL_TASKNAME = "rolling_fit"

dataset_config = QRFitter3Node.base_dataset_config()
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp3", enable_RR=True)
task_config = QRFitter3Node.base_task_config(oos=20232024)
roller_confg = QRFitter3Node.base_roller_config(croll=False)
# extra_tasks_config = get_extra_tasks_X(names=["X.ae_residual"])  # "X", "X.ae_bottleneck", "X.ae_residual"
extra_tasks_config = get_extra_tasks()


fitting_name = "mlp3_v24_rolling5m_nomaxtrain_gridlabel"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    #"task": task_config,
    "roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    "extra_tasks": extra_tasks_config
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)

qf3.gen_tasks(gpus=["0", "1", "4"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="13")