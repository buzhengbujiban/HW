from fit_ca.qrfitter3_node import *
from fit_ca.utils import show_stats
import pandas as pd
import math
from online202409 import terms
from online202409.utils import get_features_from_extra_tasks, load_train_test_data_shm


if __name__ == "__main__":

    RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/sequential_label"

    labels = ['mret_ovnt', "mret1h"]
    chain_name = "ovnt_1h_lowlr_quick_both"
    df, ss = show_stats(node_name="mlp_all_terms", return_dfss=True)
    
    df1 = df.xs("w_c1").xs(labels[0]).xs("is", axis=1).abs()
    df2 = df.xs("w_c1").xs(labels[1]).xs("is", axis=1).abs()
    feature1 = df1.sort_values("SR", ascending=False).head(500).index.tolist()   # 长周期的按SR
    feature2 = df2.sort_values("FR", ascending=False).head(500).index.tolist()   # 短周期的按FR
    both = (df2["FR"].rank(ascending=False) + df1["SR"].rank(ascending=False)).sort_values().index[:1000].tolist()

    Xname, Yname, Wname = "X.mlp_all_ovnt_1h", "Y", "W"
    X_pattern = {Xname: {"pattern": terms.mlp_all, "columns": both}}
    load_train_test_data_shm(X_pattern=X_pattern, include_YW=False, Yname=Yname, Wname=Wname)  # 注意include_YW是否需要重新dump
    exit()

    dataset_config = QRFitter3Node.base_dataset_config(Xname=Xname, Yname=Yname, Wname=Wname)
    inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True, Xname=Xname, Yname=Yname, Wname=Wname)
    fitter_config = QRFitter3Node.base_fitter_config(model="mlp3", enable_RR=True)
    task_config = QRFitter3Node.base_task_config(oos=20232024)
    # grid_tasks_config = get_grid_tasks()
    # extra_tasks_config = get_extra_tasks(x_file_list=["X"], grid_label="barra")
    fitting_name = f"pretrain"
    dataset_config["fit_y"] = labels[0]
    inference_dataset_config["fit_y"] = labels[0]
    fitter_config["max_epoch"] = 1  # only pretrain 1 epoch
    fitter_config["learning_rate"] = 1e-5  # low lr
    qf_config = {
        "fitting_name": fitting_name,
        "dataset": dataset_config,
        "inference_dataset": inference_dataset_config,
        "fitter": fitter_config,
        "task": task_config,
    }
    qf3 = QRFitter3Node(qf_config, chain_name=chain_name, label=fitting_name, clean_dir_name=True)
    qf3.gen_tasks(gpus=["0"])  # [str(i) for i in range(4,8)]
    qf3.run(para_spec="20")
    last_output_dir = qf3.stage_dir()


    dataset_config = QRFitter3Node.base_dataset_config(Xname=Xname, Yname=Yname, Wname=Wname)
    inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True, Xname=Xname, Yname=Yname, Wname=Wname)
    fitter_config = QRFitter3Node.base_fitter_config(model="mlp3", enable_RR=True)
    task_config = QRFitter3Node.base_task_config(oos=20232024)
    fitting_name = f"finetune"
    dataset_config["fit_y"] = labels[1]
    inference_dataset_config["fit_y"] = labels[1]
    fitter_config["share_model_path"] = {
        "layers": {"path": os.path.join(last_output_dir, "fit.0", 'model.pt'), "name": "layers"},
        "output_layer": {"path": os.path.join(last_output_dir, "fit.0", 'model.pt'), "name": "output_layer"},
    }
    fitter_config["evalvalid_onstart"] = True
    fitter_config["randomrestart_config"]["restart_num"] = 0  # qucik
    qf_config = {
        "fitting_name": fitting_name,
        "dataset": dataset_config,
        "inference_dataset": inference_dataset_config,
        "fitter": fitter_config,
        "task": task_config,
    }
    qf3 = QRFitter3Node(qf_config, chain_name=chain_name, label=fitting_name, clean_dir_name=True)
    qf3.gen_tasks(gpus=["0"])  # [str(i) for i in range(4,8)]
    qf3.run(para_spec="20")
    last_output_dir = qf3.stage_dir()