from fit_ca.qrfitter3_node import *
import argparse


def main(root_config):

    dataset_config = QRFitter3Node.base_dataset_config()
    inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
    fitter_config = QRFitter3Node.base_fitter_config(model="mlp_seq")
    task_config = QRFitter3Node.base_task_config(oos=2023)
    roller_confg = QRFitter3Node.base_roller_config(croll=True)
    # grid_tasks_config = get_grid_tasks()
    # extra_tasks_config = get_extra_tasks(x_file_list=["X"], grid_label="barra")

    fitter_config["earlystop_config"]["patience"] = 4
    fitter_config["randomrestart_config"] = {
        "enable": True,
        "restart_num": 3,
        "earlystop_config": fitter_config.pop("earlystop_config")
    }
    fitter_config["save_share_model"] = True
    fitter_config["evalvalid_onstart"] = True
    # fitter_config["model_config"]["kwargs"]["freeze_former_linears"] = True
    # fitter_config["max_epoch"] = 1

    rnode_root = root_config["rnode_root"]
    fitting_name = root_config["fitting_name"]
    groups = root_config["groups"]

    x_file_names = root_config.get("x_file_names", ["X"])
    dataset_config["x_files"] = [f"/dev/shm/YYYYMMDD.{x_file_name}.sdiv" for x_file_name in x_file_names]
    inference_dataset_config["x_files"] = [f"/dev/shm/YYYYMMDD.{x_file_name}.5min.sdiv" for x_file_name in x_file_names]
    fit_y = root_config.get("fit_y", "mret24h")
    dataset_config["fit_y"] = fit_y
    inference_dataset_config["fit_y"] = fit_y

    features_sofar = []
    last_output_dir = None
    for i, group in enumerate(groups):
        features_sofar.extend(group)
        dataset_config["use_x_names"] = features_sofar
        inference_dataset_config["use_x_names"] = features_sofar
        if last_output_dir is not None:
            fitter_config["share_model_path"] = os.path.join(last_output_dir, "fit.0", 'share_model.pt')
        # if i == 0:
        #     fitter_config["max_epoch"] = 1
        # else:
        #     fitter_config["max_epoch"] = 100
        qf_config = {
            "fitting_name": f"{fitting_name}.{i}",
            "dataset": dataset_config,
            "inference_dataset": inference_dataset_config,
            "fitter": fitter_config,
            "task": task_config,
            #"roller": roller_confg,
            # "grid_tasks": grid_tasks_config,
            # "extra_tasks": extra_tasks_config
        }
        qf3 = QRFitter3Node(qf_config, chain_name=fitting_name, rnode_root=rnode_root)
        qf3.gen_tasks(gpus=[root_config.get("gpu", "0")])  # [str(i) for i in range(4,8)]
        qf3.run(para_spec="20")
        last_output_dir = qf3.stage_dir()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("config_path")
    args = parser.parse_args()
    config = read_json(args.config_path)
    main(config)