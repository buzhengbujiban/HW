from fit_ca.qrfitter3_node import *


def get_extra_task_wgt():
    lrs = [0.00005, 0.00001, 0.000005]
    wgts = ["is.active_csi300", "is.active_csi800"]  # "is.active", 
    # for i in [2, 4, 8, 16]:
    #     wgts.extend([f"is.active_csi300.{i}_other.1", f"is.active_csi800.{i}_other.1"])
    extra_tasks = [
        {"dataset": {"fit_w": wgt}, "inference_dataset": {"fit_w": wgt}, "fitter": {"learning_rate": lr}}
        for lr in lrs for wgt in wgts
    ]
    return extra_tasks


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002"
RNode.GLOBAL_TASKNAME = "universe"

dataset_config = QRFitter3Node.base_dataset_config()
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp3", enable_RR=True)
task_config = QRFitter3Node.base_task_config(oos=2023, long_is=False)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
extra_tasks_config = get_extra_task_wgt()

init_model_path = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/universe/wgt300500_hs_RR/fit.0/model.pt"
share_model_path = {  # MLP3就这两个submodule，TODO: 在optimizer中分别为不同的层设置不同的学习率
    "layers": {"path": init_model_path, "name": "layers"},
    "output_layer": {"path": init_model_path, "name": "output_layer"},
}
fitter_config["share_model_path"] = share_model_path
fitter_config["evalvalid_onstart"] = True

fitting_name = "FT_in300800_lr_hs"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    "extra_tasks": extra_tasks_config,

}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)

qf3.gen_tasks(gpus=["2"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="16")