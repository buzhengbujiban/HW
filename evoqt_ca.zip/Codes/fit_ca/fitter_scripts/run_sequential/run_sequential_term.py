from fit_ca.qrfitter3_node import *
import pandas as pd
import math
from gen_run import *

# def read_stats_df(stage_dir="/data/beef2/junming/rroot/calc_stats/calc_terms_stats/000.stats"):
#     df = pd.read_csv(f"{stage_dir}/df.csv", index_col=[0,1,2], header=[0,1]).xs('w_c1')
#     df = df.abs()
#     return df

def read_stats_df(stage_dir="/data/beef2/junming/rroot/calc_stats/calc_terms_stats_isos_mbret/000.stats"):
    df = pd.read_csv(f"{stage_dir}/df.csv", index_col=[0,1,2], header=[0,1]).xs('w_c1')
    df = df.abs()
    return df

def get_feature_groups_FRSR(method="FR", period="is", ret="mret24h", ngroup=2):
    df = read_stats_df()
    df = df.xs(ret).xs(period, axis=1)
    feature_list = df.sort_values(method, ascending=False).index.tolist()  # 按照FR从高到低排序
    groups = []
    n_per_group = math.ceil(len(feature_list) / ngroup)
    for i in range(ngroup):
        groups.append(feature_list[i*n_per_group: (i+1)*n_per_group])
    return groups


if __name__ == "__main__":

    RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/sequential_term"

    dataset_config = QRFitter3Node.base_dataset_config()
    inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
    fitter_config = QRFitter3Node.base_fitter_config(model="mlp_seq")
    task_config = QRFitter3Node.base_task_config(oos=2023)
    roller_confg = QRFitter3Node.base_roller_config(croll=True)
    # grid_tasks_config = get_grid_tasks()
    # extra_tasks_config = get_extra_tasks(x_file_list=["X"], grid_label="barra")

    fitter_config["earlystop_config"]["patience"] = 4
    fitter_config["randomrestart_config"] = {
        "enable": True,
        "restart_num": 3,
        "earlystop_config": fitter_config.pop("earlystop_config")
    }
    dataset_config["fit_y"] = 'bret24h'
    inference_dataset_config["fit_y"] = 'bret24h'
    fitter_config["save_share_model"] = True
    # fitter_config["max_epoch"] = 1

    fitting_name = "FR_aggcluster"

    # fitter_config["model_config"]["kwargs"]["lastlayer_reg"] = True
    # groups = get_feature_groups_FRSR(method="FR", period="is", ret="bret24h", ngroup=6)
    groups = get_featue_groups_cluster_FRSR(method="FR")
    features_sofar = []
    last_output_dir = None
    for i, group in enumerate(groups):
        features_sofar.extend(group)
        dataset_config["use_x_names"] = features_sofar
        inference_dataset_config["use_x_names"] = features_sofar
        if last_output_dir is not None:
            fitter_config["share_model_path"] = os.path.join(last_output_dir, "fit.0", 'share_model.pt')
        qf_config = {
            "fitting_name": f"{fitting_name}.{i}",
            "dataset": dataset_config,
            "inference_dataset": inference_dataset_config,
            "fitter": fitter_config,
            "task": task_config,
            #"roller": roller_confg,
            # "grid_tasks": grid_tasks_config,
            # "extra_tasks": extra_tasks_config
            
        }
        qf3 = QRFitter3Node(qf_config, chain_name=fitting_name)
        qf3.gen_tasks(gpus=["0"])  # [str(i) for i in range(4,8)]
        qf3.run(para_spec="20")
        last_output_dir = qf3.stage_dir()