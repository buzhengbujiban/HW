from fit_ca.qrfitter3_node import *
from fit_ca.canopus_scripts.dump_shm import prepare_shm, read_columns_from_pattern_shm
from collections import defaultdict, OrderedDict
import pandas as pd
import math
import qr

def config_gpus(root_configs, gpus:list[str]=None):
    if gpus is not None:
        for task_idx, root_config in enumerate(root_configs):
            gpu_idx = task_idx % len(gpus)
            device_id = gpus[gpu_idx]
            root_config["gpu"] = device_id


data = defaultdict(list)
folders = [
    "/data/beef2/guopeng/shared/tsfresh_reproduce/apen1",
    "/data/beef2/guopeng/shared/tsfresh_reproduce/minret1",
]
for folder in folders:
    data["X.minret_apen.select1"].append(os.path.join(folder, "selected1", "selected1.YYYYMMDD.sdiv"))
    data["X.minret_apen.select2"].append(os.path.join(folder, "selected2", "selected2.YYYYMMDD.sdiv"))

for i in [1, 4, 5, 6, 8, 10, 11, 14, 18]: # [1, 3, 4, 5, 6, 8, 10, 11, 14, 18]
    data["X.chunxiao.select1"].append(f"/data/beef2/guopeng/zp_alpha_ex/chunxiao{i}/000.ca.chunxiao{i}/selected1.YYYYMMDD.sdiv")  # 3没有
    data["X.chunxiao.select2"].append(f"/data/beef2/guopeng/zp_alpha_ex/chunxiao{i}/000.ca.chunxiao{i}/selected2.YYYYMMDD.sdiv")

folders = [
    # "/data/beef2/guopeng/l2_project/remain_LOB/000.ca.remain_LOB",
    # "/data/beef2/guopeng/l2_project/imb_tsreg3/000.ca.imb_tsreg3",
    # "/data/beef2/guopeng/l2_project/imb_tsreg2/000.ca.imb_tsreg2",
    "/data/beef2/guopeng/l2_project/imb_tsreg2_m/000.ca.imb_tsreg2_m",
    "/data/beef2/guopeng/l2_project/imb_tsreg3_m/000.ca.imb_tsreg3_m",
    # "/data/beef2/guopeng/l2_project/remain_LOB_m/000.ca.remain_LOB_m",
]
for folder in folders:
    data["X.l2_noLOB_resi.select1"].append(os.path.join(folder, "selected1.YYYYMMDD.sdiv"))
    data["X.l2_noLOB_resi.select2"].append(os.path.join(folder, "selected2.YYYYMMDD.sdiv"))

PQ_path = "/data/beef2/mike/PQ_terms_v24.0614"
PQprocessed_path = "/data/beef2/zifan/mike_data"
data["X.PQ"] = [os.path.join(PQ_path, batch, "terms.YYYYMMDD.sdiv") for batch in os.listdir(PQ_path)]
# data["X.PQprocessed_peak"] = [os.path.join(PQprocessed_path, batch, "terms.YYYYMMDD.sdiv") for batch in os.listdir(PQprocessed_path) if batch.endswith("peak")]

data["X.ae_bottleneck200"] = "/data/bees1/safe/junming/equity_fitting/data/ae_croll_exclude202002/bottleneck200/bottleneck/terms.YYYYMMDD.sdiv"

# prepare_shm(data={k: v for k, v in data.items() if k == "X.PQ"})
# exit()


def read_stats_df(stage_dir):
    df = pd.read_csv(f"{stage_dir}/df.csv", index_col=[0,1,2], header=[0,1]).xs('w_c1')
    df = df.abs()
    return df

def get_feature_groups_FRSR(method="FR", period="is", ret="mret24h", ngroup=2):
    if period in ["is", "os"]:
        stage_dir="/data/beef2/junming/rroot/calc_stats/calc_terms_stats_isos_mbret/000.stats"
    elif period == "vd":
        stage_dir="/data/beef2/junming/rroot/calc_stats/calc_terms_stats_vd_mbret/000.stats"
    df = read_stats_df(stage_dir)
    df = df.xs(ret).xs(period, axis=1)
    feature_list = df.sort_values(method, ascending=False).index.tolist()  # 按照FR从高到低排序
    groups = []
    n_per_group = math.ceil(len(feature_list) / ngroup)
    for i in range(ngroup):
        groups.append(feature_list[i*n_per_group: (i+1)*n_per_group])
    return groups

def get_feature_names_shm(name):
    pattern = f"/dev/shm/YYYYMMDD.{name}.sdiv"
    return read_columns_from_pattern_shm(pattern)

def get_featue_groups_cluster_FRSR(method="FR", ret="mret24h"):
    if ret == "mret24h":
        cluster_folder = "/data/beef2/junming/data/aggcluster10group"
    elif ret == "bret24h":
        cluster_folder = "/data/beef2/junming/data/aggcluster10group_bret"
    features_ori_cluster = qr.tbl_read(os.path.join(cluster_folder, "features_ori_cluster.tbl"))
    features = qr.tbl_read(os.path.join(cluster_folder, "features.tbl"))
    frsr = qr.tbl_read(os.path.join(cluster_folder, "cluster_frsr.tbl"))
    groups = OrderedDict()
    for cluster_id in frsr.sort_values(method, ascending=False)['index']:  # 其实不sort也无所谓，就是为了固定FR高的组在groups最前面方便看
        cluster_features = features.loc[features["cluster"] == cluster_id, "name"].tolist()
        groups[cluster_id] = cluster_features
    return groups

def get_features_groups_FRSR_ratio(method="FR", ret="mret24h", ngroup=2):
    stage_dir = "/data/beef2/junming/rroot/calc_stats/calc_terms_stats_isvdos_mbret/000.stats"
    df = read_stats_df(stage_dir)
    vd_df = df.xs(ret).xs("vd", axis=1)
    is_df = df.xs(ret).xs("is", axis=1)
    feature_sortby_method = vd_df.sort_values(method, ascending=False).index.tolist()
    ratio = (vd_df[method] / is_df[method])
    if ngroup == 2:
        potential_good_features = feature_sortby_method[:int(len(feature_sortby_method) * (2/3))]  # 先选值高的
        potential_good_features_sortby_ratio = ratio.loc[potential_good_features].sort_values(ascending=False).index.tolist()
        good_features = potential_good_features_sortby_ratio[:len(feature_sortby_method) // 2]  # 再选ratio高的
        bad_features = [f for f in feature_sortby_method if f not in good_features]
        groups = [good_features, bad_features]
    elif ngroup == 4:
        good_features = feature_sortby_method[:len(feature_sortby_method) // 2]  # 先按值排
        bad_features = feature_sortby_method[len(feature_sortby_method) // 2:]
        good_features_sortby_ratio = ratio.loc[good_features].sort_values(ascending=False).index.tolist()
        bad_features_sortby_ratio = ratio.loc[bad_features].sort_values(ascending=False).index.tolist()
        good1 = good_features_sortby_ratio[: len(good_features_sortby_ratio) // 2]  # 再按ratio排
        good2 = good_features_sortby_ratio[len(good_features_sortby_ratio) // 2: ]
        bad1 = bad_features_sortby_ratio[: len(bad_features_sortby_ratio) // 2]
        bad2 = bad_features_sortby_ratio[len(bad_features_sortby_ratio) // 2: ]
        groups = [good1, good2, bad1, bad2]
    return groups


ROOT_CONFIG_BASE = {
    "rnode_root": "",
    "fitting_name": "",
    "groups": [],
}

def get_root_configs_X_plus_newbatch():
    base_name = "X"
    base_features = get_feature_names_shm(base_name)
    root_configs = []
    for batch_name in data.keys():
        root_config = copy.deepcopy(ROOT_CONFIG_BASE)
        batch_features = get_feature_names_shm(batch_name)
        fitting_name = f"plus_{batch_name}"
        root_config["fitting_name"] = fitting_name
        root_config["groups"] = [base_features, batch_features]
        root_config["x_file_names"] = [base_name, batch_name]
        root_config["fit_y"] = "mret24h"
        root_configs.append(root_config)
    return root_configs

def get_root_configs_FRSR_groups(period):
    root_configs = []
    for ret in ["mret24h", "bret24h"]:
        for method in ["FR", "SR"]:
            for ngroup in [2, 4]:
                root_config = copy.deepcopy(ROOT_CONFIG_BASE)
                fitting_name = f"{method}_{ngroup}group_{ret}"
                groups = get_feature_groups_FRSR(method=method, period=period, ret=ret, ngroup=ngroup)
                root_config["fitting_name"] = fitting_name
                root_config["groups"] = groups
                root_config["fit_y"] = ret
                root_configs.append(root_config)
    return root_configs

def get_root_configs_FRSR_ratio_groups():
    root_configs = []
    for ret in ["mret24h", "bret24h"]:
        for method in ["FR", "SR"]:
            for ngroup in [2]:
                root_config = copy.deepcopy(ROOT_CONFIG_BASE)
                fitting_name = f"{method}_{ngroup}group_{ret}"
                groups = get_features_groups_FRSR_ratio(method=method, ret=ret, ngroup=ngroup)
                root_config["fitting_name"] = fitting_name
                root_config["groups"] = groups
                root_config["fit_y"] = ret
                root_configs.append(root_config)
    return root_configs


def generate_job_files(root_configs):
    rnode_root = root_configs[0]["rnode_root"]
    root_config_folder = os.path.join(rnode_root, "root_configs")
    os.makedirs(root_config_folder, exist_ok=True)

    root_config_files = []
    for root_config in root_configs:
        fitting_name = root_config["fitting_name"]
        root_config_file = os.path.join(root_config_folder, f"{fitting_name}.json")
        save_json(root_config, root_config_file)
        root_config_files.append(root_config_file)
        print(f"fitting_name={fitting_name} config.json write to {root_config_file}")
    
    root_jobs_file = os.path.join(rnode_root, 'all_root_jobs.sh')
    with open(root_jobs_file, 'w') as out_file:
        for root_config_file in root_config_files:
            cmd_line = f"python /data/nfshome/junming/git/junming/Codes/fit_ca/fitter_scripts/run_sequential/run_fit_root.py {root_config_file}"
            out_file.write(cmd_line)
            out_file.write('\n')
    print(f'root_jobs_file written to: {root_jobs_file}')

def run_root_tasks(rnode_root, para_spec=4):
    root_jobs_file = os.path.join(rnode_root, 'all_root_jobs.sh')
    commands_log_file = os.path.join(rnode_root, 'logs')
    cmd = f"cat {root_jobs_file} | run-parallel -j {para_spec} -w {commands_log_file} -k"
    subprocess.run(cmd, shell=True, text=True)


# -----------主函数在这-------------
def gen_run_root_tasks(gpus:list[str]=None, para_spec=4):
    seq_folder = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/sequential_term"
    expt_name = "FRSR_ratio_2group_mbret"
    rnode_root = os.path.join(seq_folder, expt_name)
    ROOT_CONFIG_BASE["rnode_root"] = rnode_root
    
    # 1. 选择所需要的函数生成root_configs
    root_configs = get_root_configs_FRSR_ratio_groups()
    # 2. 指定每个root使用的gpu
    config_gpus(root_configs, gpus=gpus)
    # 3. 按照configs生成jsons以及sh脚本
    generate_job_files(root_configs)
    run_root_tasks(rnode_root, para_spec=para_spec)


if __name__ == '__main__':
    gen_run_root_tasks(gpus=["0", "1"], para_spec=16)