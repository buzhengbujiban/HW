from fit_ca.qrfitter3_node import *
from gen_run import get_feature_groups_FRSR


def get_extra_tasks():
    extra_tasks = []
    for method in ["FR", "SR"]:
        groups = get_feature_groups_FRSR(method=method, period="vd", ret="mret24h", ngroup=2)
        x_names = reduce(list.__add__, [features for features in groups])
        group_nums = [(f"{method}{i+1}", len(group)) for i, group in enumerate(groups)]  # FR1和FR2
        for weight_decay in [0, 1, 3]:
            extra_tasks.append({
                "dataset": {"use_x_names": x_names, "method": method},
                "inference_dataset": {"use_x_names": x_names, "method": method},
                "fitter": {
                    "model_config": {
                        "kwargs": {
                            "group_nums": group_nums
                        }
                    },
                    "params_optimizer_config": {f"{method}2": {"weight_decay": weight_decay}},
                    "l2_decay": 0
                }
            })
    return extra_tasks


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
RNode.GLOBAL_TASKNAME = "sequential_term"


dataset_config = QRFitter3Node.base_dataset_config()
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp_split_input", enable_RR=True)
task_config = QRFitter3Node.base_task_config(oos=2023)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
# grid_tasks_config = get_grid_tasks()
extra_tasks_config = get_extra_tasks()


fitting_name = "mlp_split_input_l2_0vs013_hs"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    "extra_tasks": extra_tasks_config
    
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks(gpus=["0", "1"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="24")


