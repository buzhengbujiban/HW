from fit_ca.qrfitter3_node import *
import pandas as pd
from functools import reduce
from gen_run import get_featue_groups_cluster_FRSR


def get_GroupHeadMLP_model_config(cluster_nums, hidden_mode=1):
    return {
        "class": "GroupHeadMLP",
        "kwargs": {
            "cluster_nums": cluster_nums,
            "hidden_mode": hidden_mode,
            "num_hidden": 3,
            "normal_group_hidden": 5,
            "unique_group_multiplier": 4,
            "act_fn": "ELU",
            "norm_type": "BatchNorm1d",
            "dropout_rate": 0.3,
        }
    }

def get_SingleGroupMLP_model_config(cluster_num=(0, 0), hidden_mode=2):
    return {
        "class": "SingleGroupMLP",
        "kwargs": {
            "cluster_num": cluster_num,
            "hidden_mode": hidden_mode,
            "num_hidden": 3,
            "normal_group_hidden": 5,
            "unique_group_multiplier": 4,
            "act_fn": "ELU",
            "norm_type": "BatchNorm1d",
            "dropout_rate": 0.3,
        }
    }


def get_extra_tasks_hs():
    # extra_tasks = [
    #     {"fitter": {"model_config": {"kwargs": {"adaptive_last_hidden": True}}}}
    # ]
    # extra_tasks.extend([
    #     {"fitter": {"model_config": {"kwargs": {"adaptive_last_hidden": False, "normal_group_hidden": h, "unique_group_multiplier": p}}}}
    #     for h in [3, 5, 10] for p in [1, 4, 8]
    # ])
    # extra_tasks = [
    #     {"fitter": {"model_config": {"kwargs": {"hidden_mode": mode}}}}
    #     for mode in [0, 1, 2, 3]
    # ]
    extra_tasks = [
        {"fitter": {"model_config": {"kwargs": {"init_adjust_var": adjust}}}}
        for adjust in [True, False]
    ]

    return extra_tasks


def get_extra_tasks_singlegroup_fit(ret):
    groups = get_featue_groups_cluster_FRSR(ret=ret)
    extra_tasks = []
    for cluster_id, cluster_features in groups.items():
        extra_tasks.append({
            "dataset": {"use_x_names": cluster_features, "cluster_id": cluster_id},
            "inference_dataset": {"use_x_names": cluster_features, "cluster_id": cluster_id},
            "fitter": {
                "model_config": {
                    "kwargs": {
                        "cluster_num": (int(cluster_id), len(cluster_features))
                    }
                }
            }
        })
    return extra_tasks


def get_cluster_head_model_map(expt_folder, include_output_layer=False):
    scenarios = read_json(os.path.join(expt_folder, "scenarios.json"))
    cluster_head_model_map = {}
    for fit_id, scenario in scenarios.items():
        cluster_id = scenario["fitter"]["model_config"]["kwargs"]["cluster_num"][0]
        cluster_head_model_map[f"head_{cluster_id}"] = {"path": os.path.join(expt_folder, fit_id, "model.pt"), "name": "head"}
        if include_output_layer:
            cluster_head_model_map[f"output_layer_{cluster_id}"] = {"path": os.path.join(expt_folder, fit_id, "model.pt"), "name": "output_layer"}
    return cluster_head_model_map

def get_extra_tasks_grouphead_init_type(single_model_expt_folder):
    extra_tasks = [{}]  # 空字典代表不init，就这么单训一个GroupHeadMLP模型
    extra_tasks.extend([
        {
            "fitter": {
                "share_model_path": get_cluster_head_model_map(single_model_expt_folder),
                "model_config": {
                    "kwargs": {
                        "freeze_head": freeze_head
                    }
                }
            }
        }
        for freeze_head in [True, False]
    ])  # 这俩是只init head，分别是freeze住head的参数和不freeze

    extra_tasks.extend([
        {
            "fitter": {
                "share_model_path": get_cluster_head_model_map(single_model_expt_folder, include_output_layer=True),
                "model_config": {
                    "kwargs": {
                        "freeze_head": freeze_head,
                        "init_adjust_var": init_adjust_var
                    }
                }
            }
        }
        for freeze_head in [True, False] for init_adjust_var in [True, False]
    ])  # 这是init head和output_layer
    return extra_tasks



RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
RNode.GLOBAL_TASKNAME = "sequential_term"

dataset_config = QRFitter3Node.base_dataset_config()
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp3")
task_config = QRFitter3Node.base_task_config(oos=2023)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
# grid_tasks_config = get_grid_tasks_resnet()
# extra_tasks_config = get_extra_tasks_hs()
# extra_tasks_config = get_extra_tasks_singlegroup_fit(ret="mret24h")


fitter_config["earlystop_config"]["patience"] = 4
fitter_config["randomrestart_config"] = {
    "enable": True,
    "restart_num": 3,
    "earlystop_config": fitter_config.pop("earlystop_config")
}
# fit bret的话要制定以下两行，注意submodel也要是fit bret的，也是要指定以下两行
# dataset_config.update({"fit_y": "bret24h"})
# inference_dataset_config.update({"fit_y": "bret24h"})

# 以下对应SingleGroupMLP_model, 需要在extra_tasks指定各子model的cluster_num
# fitter_config["model_config"] = get_SingleGroupMLP_model_config(hidden_mode=2)

# 以下对应GroupHeadMLP_model
groups = get_featue_groups_cluster_FRSR(ret="mret24h")  # 要和上面singlegroup的extra_tasks_config = get_extra_tasks_singlegroup_fit(ret="mret24h")对应
cluster_nums = [(int(cluster_id), len(cluster_features)) for cluster_id, cluster_features in groups.items()]
x_names = reduce(list.__add__, [cluster_features for cluster_features in groups.values()])
dataset_config["use_x_names"] = x_names
inference_dataset_config["use_x_names"] = x_names
fitter_config["model_config"] = get_GroupHeadMLP_model_config(cluster_nums, hidden_mode=2)
# 以下几行是加上用多个子模型init GroupHeadMLP_model的底层
single_model_expt_folder = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/sequential_term/ca1999_aggcluster_singlegroupsubmodel_hidden_mode2"
extra_tasks_config = get_extra_tasks_grouphead_init_type(single_model_expt_folder)  # 利用上面single_model_expt_folder的子模型进行多种init
fitter_config["evalvalid_onstart"] = True

# fitter_config["max_epoch"] = 1


fitting_name = "aggcluster_grouphead_mret_hs_ps12"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    "extra_tasks": extra_tasks_config
    
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks(gpus=["0", "1"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="24")