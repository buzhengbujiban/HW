from fit_ca.qrfitter3_node import *
from online202409.utils import get_features_from_extra_tasks, load_train_test_data_shm
from online202409 import terms
from fit_ca.utils import show_stats
import qr
from fit_ca.canopus_scripts.dump_shm import *

def get_extra_tasks_w_field():
    w_fields = [[1,1], [1,4], [1,8], [1,16], [1,32], [1,64]]  # , "is.active_csi300"
    extra_tasks = []
    for wgt in w_fields:
        extra_tasks.append({
            "fitter": {"w_field": wgt},
        })
    return extra_tasks


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
RNode.GLOBAL_TASKNAME = "sequential_label"
Xname, Yname, Wname = "X.mlp_all_ovnt_1h", "Y", "W"
# X_pattern = {Xname: {"pattern": terms.ca1999_norm, "calc_f": xsdemean_within_index}}
fitting_name = f"multiloss_w_field_hs"


dataset_config = QRFitter3Node.base_dataset_config(Xname=Xname, Yname=Yname, Wname=Wname)
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True, Xname=Xname, Yname=Yname, Wname=Wname)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp3", enable_RR=True)
task_config = QRFitter3Node.base_task_config(oos=20232024)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
extra_tasks_config = get_extra_tasks_w_field()
# extra_tasks_config = get_extra_tasks_wgt()
# dataset_config["fit_w"] = "is.active_topx"
# inference_dataset_config["fit_w"] = "is.active_topx"

dataset_config["fit_y"] = ["mret_ovnt", "mret1h"]
inference_dataset_config["fit_y"] = ["mret_ovnt", "mret1h"]
fitter_config["randomrestart_config"]["earlystop_config"]["monitor_key"] = [{'valid/cor_mret1h': {"delta": 0.1, "mode": "max"}}]
fitter_config["randomrestart_config"]["restart_num"] = 0  # qucik
fitter_config.update({
    # "max_epoch": 1,
    "w_field": [1,1],
    "loss_fn": ["wmse_ml",{}],
})

qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    #"roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    "extra_tasks": extra_tasks_config
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks(gpus=["0", "1"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="24")