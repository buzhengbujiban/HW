from fit_ca.qrfitter3_node import *
from gen_run import get_feature_groups_FRSR


def get_extra_task(groups):
    extra_task = [
        {
            "dataset": {"use_x_names": group},
            "inference_dataset": {"use_x_names": group}
        }
        for group in groups
    ]
    return extra_task

def get_extra_task_fitresi():
    FR2groups = get_feature_groups_FRSR(method="FR", period="vd", ret="mret24h", ngroup=2)
    SR2groups = get_feature_groups_FRSR(method="SR", period="vd", ret="mret24h", ngroup=2)
    y_file_name = "Y.resi"
    y_file = f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv"
    y_file_inference = f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv"
    extra_task = []
    extra_task.append({
        "dataset": {"use_x_names": FR2groups[1], "x_group_name": "FR2", "fit_y": "fit.0.yhat_mret24h.resi", "y_file": y_file},
        "inference_dataset": {"use_x_names": FR2groups[1], "x_group_name": "FR2", "fit_y": "fit.0.yhat_mret24h.resi", "y_file": y_file_inference}
    })
    extra_task.append({
        "dataset": {"use_x_names": SR2groups[1], "x_group_name": "SR2", "fit_y": "fit.1.yhat_mret24h.resi", "y_file": y_file},
        "inference_dataset": {"use_x_names": SR2groups[1], "x_group_name": "SR2", "fit_y": "fit.1.yhat_mret24h.resi", "y_file": y_file_inference}
    })
    return extra_task


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
RNode.GLOBAL_TASKNAME = "sequential_term"

dataset_config = QRFitter3Node.base_dataset_config()
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp3", enable_RR=True)
task_config = QRFitter3Node.base_task_config(oos=2023)
roller_confg = QRFitter3Node.base_roller_config(croll=True)

FR2groups = get_feature_groups_FRSR(method="FR", period="vd", ret="mret24h", ngroup=2)
SR2groups = get_feature_groups_FRSR(method="SR", period="vd", ret="mret24h", ngroup=2)
# extra_tasks_config = get_extra_task(groups=FR2groups+SR2groups)
# extra_tasks_config = get_extra_task(groups=[FR2groups[0], SR2groups[0]])
extra_tasks_config = get_extra_task_fitresi()

fitting_name = "vdSRFR_2group_2nd_fitresi"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    # "roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    "extra_tasks": extra_tasks_config
    
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks(gpus=["1"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="24")