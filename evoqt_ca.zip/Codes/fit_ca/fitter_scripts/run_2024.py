from fit_ca.qrfitter3_node import *

def get_extra_tasks(x_file_list:List[str|List[str]], grid_label="mret24h"):
    if grid_label == "mret24h":
        y_file_name = "Y"
        labels = ["mret24h"]
    elif grid_label == "barra":
        y_file_name = "Y"
        labels = ["mret24h", "bret24h", "bpret24h"]
    elif grid_label == "OI":
        y_file_name = "Y.OI"
        rets = ["mret"]  # "mret", "bret", "bpret"
        parts = ["0itrd", "ovnt", "1o"]  # "0itrd", "ovnt", "1o", "1itrd", "itrd", "ovnt_res", "itrd_res", "1e1o"
        labels = [f"{ret}_{part}" for ret in rets for part in parts]
    
    extra_tasks = []
    for y in labels:
        for x_file_names in x_file_list:
            if isinstance(x_file_names, str):
                x_file_names = [x_file_names]
            x_files = [f"/dev/shm/YYYYMMDD.{x_file_name}.sdiv" for x_file_name in x_file_names] 
            x_files_inference = [f"/dev/shm/YYYYMMDD.{x_file_name}.5min.sdiv" for x_file_name in x_file_names] 
            y_file = f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv"
            y_file_inference = f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv"
            extra_tasks.append({
                "dataset": {"fit_y": y, "x_files": x_files, "y_file": y_file},
                "inference_dataset": {"fit_y": y, "x_files": x_files_inference, "y_file": y_file_inference}
            })
    return extra_tasks

def get_extra_tasks_xxyy():
    extra_tasks = []
    xs = ["X", "X.v24"]
    ys = ["Y", "Y.v24"]
    for x_file_name in xs:
        for y_file_name in ys:
            x_files = [f"/dev/shm/YYYYMMDD.{x_file_name}.sdiv"] 
            x_files_inference = [f"/dev/shm/YYYYMMDD.{x_file_name}.5min.sdiv"] 
            y_file = f"/dev/shm/YYYYMMDD.{y_file_name}.sdiv"
            y_file_inference = f"/dev/shm/YYYYMMDD.{y_file_name}.5min.sdiv"
            extra_tasks.append({
                "dataset": {"x_files": x_files, "y_file": y_file},
                "inference_dataset": {"x_files": x_files_inference, "y_file": y_file_inference}
            })
    return extra_tasks

def get_extra_tasks_train_period():
    train_start = ["20140101", "20150101", "20160101", "20170101", "20180101", "20190101", "20200101"]
    # train_start = ["20180601", "20190101", "20200101"]
    # train_start = ["20170101", "20180101", "20190101", "20200101"]
    extra_tasks = [
        {"task": {"train": {"start_date": start}}}
        for start in train_start
    ]
    return extra_tasks

RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/"
RNode.GLOBAL_TASKNAME = "2024"

Xname, Yname, Wname = "X", "Y", "W"
# Xname, Yname, Wname = "X.v24", "Y.v24", "W.v24"
dataset_config = QRFitter3Node.base_dataset_config(Xname=Xname, Yname=Yname, Wname=Wname)
inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True, Xname=Xname, Yname=Yname, Wname=Wname)
fitter_config = QRFitter3Node.base_fitter_config(model="mlp3", enable_RR=True, eval_fraction=1)
task_config = QRFitter3Node.base_task_config(oos=20232024)  # 20232024
roller_confg = QRFitter3Node.base_roller_config(croll=False)
# grid_tasks_config = get_grid_tasks_mlp_base_ablation()
# extra_tasks_config = get_extra_tasks(x_file_list=["X"], grid_label="barra")
# extra_tasks_config = get_extra_tasks_xxyy()
extra_tasks_config = get_extra_tasks_train_period()

roller_confg["end_date"] = "20240731"
#fitter_config["max_epoch"] = 1

fitting_name = "mlp3_v24_newactive_train_period_hs_RR_2014"
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "inference_dataset": inference_dataset_config,
    "fitter": fitter_config,
    "task": task_config,
    # "roller": roller_confg,
    # "grid_tasks": grid_tasks_config,
    "extra_tasks": extra_tasks_config
}
qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks(gpus=["2", "3"])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="24")