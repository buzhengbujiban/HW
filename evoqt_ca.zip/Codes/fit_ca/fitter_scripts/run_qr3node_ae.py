from fit_ca.qrfitter3_node import *
from fit_ca.fitter_scripts.run_sequential.gen_run import *


def get_ae_inference_fitter_config():
    return {
        "class": "AELearner",
        "device_id": "0",
        "batch_size": 16384,
        "dataloader_workers": 4,
        "loss_fn": ["wmse_mt", {}],
        "inference_residual": True
    }

def get_inference_config():  # 2023年的inference
    inference_dataset_config = QRFitter3Node.base_dataset_config(is5min=True)  # 如果2023的数据已经dump到shm里了on_shm=True
    inference_fitter_config = get_ae_inference_fitter_config()
    inference_task_config = QRFitter3Node.base_inference_task_config(task=["inference"])
    fitroll_idx_config = {"roll": ["roll.3"]}
    inference_fitter_config["device_id"] = "0"

    qf_config = {
        "inference_dataset": inference_dataset_config,
        "fitter": inference_fitter_config,
        "task": inference_task_config,
        "fitroll_idx": fitroll_idx_config  # 一般inference样本外的话指定roll.3
    }
    return qf_config


def get_ae_fitter_config():
    fitter_config = {
        "class": "AELearner",
        "device_id": "0",

        "model_config": {
            "class": "Autoencoder",
            "kwargs": {
                "hidden_size": [1000, 500],
                "bottleneck_dim": 200,
                "dropout_rate": 0.,
                "act_fn": "ELU",
                "norm_type": None
            }
        },
        "batch_size": 16384,
        "max_epoch": 10,
        "loss_fn": ["wmse_mt", {}],
        "learning_rate": 0.0005,
        "l2_decay": 0,
        "eval_start_epoch": 0, 
        "earlystop_config": {
            "enable": True,
            "monitor_key": "valid/loss",
            "mode": "min",
            "patience": 10
        },
        "evaltrain": False,
        "evaltest": False,
        "interpret": False,
        "inference_residual": True,

        "enable_tensorboard": True,
        "dataloader_workers": 3
    }
    return fitter_config


def get_extra_tasks_hs():
    tasks1 = [
        {
            "fitter": {
                "model_config": {
                    "kwargs": {
                        "hidden_size": [2*d],
                        "bottleneck_dim": d
                    }
                }
            }
        }
        for d in [100, 400, 600]
    ]
    tasks2 = [
        {
            "fitter": {
                "model_config": {
                    "kwargs": {
                        "hidden_size": [200*(i+1) for i in range(num_hidden, 0, -1)],
                        "bottleneck_dim": 200
                    }
                }
            }
        }
        for num_hidden in [2,3,4]
    ]
    tasks3 = [
        {
            "fitter": {
                "learning_rate": 0.1 ** i
            }
        }
        for i in [1,2,3]
    ]

    extra_tasks = tasks1 + tasks2 + tasks3
    return extra_tasks


def get_extra_tasks():
    extra_tasks = [
        {
            "fitter": {
                "model_config": {
                    "kwargs": {
                        "hidden_size": hidden_size,
                        "bottleneck_dim": d
                    }
                }
            }
        }
        for d, hidden_size in [(100, [800, 400]), (200, [1000, 500]), (400, [1200, 800])]
    ]
    
    return extra_tasks


def get_extra_tasks_group_fit():
    from run_sequential.gen_run import get_featue_groups_cluster_FRSR
    groups = get_featue_groups_cluster_FRSR()
    extra_tasks = []
    for cluster_id, group in groups.items():
        group_size = len(group)
        if int(cluster_id) == -1:
            d = math.ceil(group_size * 0.4)
        else:
            d = math.ceil(group_size * 0.2)
        hidden_size = [d*4, d*2]
        extra_tasks.append({
            "dataset": {"use_x_names": group, "cluster_id": cluster_id},
            "fitter": {
                "model_config": {
                    "kwargs": {
                        "hidden_size": hidden_size,
                        "bottleneck_dim": d
                    }
                }
            }
        })
    return extra_tasks


def get_extra_tasks_wfield():
    extra_tasks = []

    for method in ["FR", "SR"]:
        groups = get_feature_groups_FRSR(method=method, period="vd", ret="mret24h", ngroup=2)
        w_field = {feature_name: 2 for feature_name in groups[0]}
        w_field.update({feature_name: 1 for feature_name in groups[1]})
        extra_tasks.append({"fitter": {"w_field": w_field, "w_field_name": f"{method}2_21"}})

    for method in ["FR", "SR"]:
        groups = get_features_groups_FRSR_ratio(method=method, ret="mret24h", ngroup=4)
        w_field = {feature_name: 4 for feature_name in groups[0]}
        w_field.update({feature_name: 3 for feature_name in groups[1]})
        w_field.update({feature_name: 2 for feature_name in groups[2]})
        w_field.update({feature_name: 1 for feature_name in groups[3]})
        extra_tasks.append({"fitter": {"w_field": w_field, "w_field_name": f"{method}ratio4_4321"}})
    return extra_tasks


RNode.RNODE_ROOT = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002"
RNode.GLOBAL_TASKNAME = "autoencoder"

dataset_config = QRFitter3Node.base_dataset_config(exclude202002=True)
fitter_config = get_ae_fitter_config() # QRFitter3Node.base_fitter_config()
task_config = QRFitter3Node.base_task_config(testing=True, oos=2022)
roller_confg = QRFitter3Node.base_roller_config(croll=True)
extra_tasks_config = get_extra_tasks()

from online202409.croll_mlp import get_extra_tasks as get_extra_tasks_round012
from online202409.utils import get_features_from_extra_tasks, load_train_test_data_shm
# extra_tasks_round012 = get_extra_tasks_round012()
extra_tasks_round0 = get_extra_tasks_round012(use_rounds=1)
all_features = get_features_from_extra_tasks(extra_tasks_round0)
# load_train_test_data_shm(features=all_features)
name = "lasso_1roundfeatures"
dataset_config.update({"use_x_names": all_features, "group_name": name})

fitting_name = "CAv24_lasso_1roundfeatures_ae200"  # inference bottleneck+residual
qf_config = {
    "fitting_name": fitting_name,
    "dataset": dataset_config,
    "fitter": fitter_config,
    #"task": task_config,
    "roller": roller_confg,
    #"grid_tasks": grid_tasks_config,
    # "extra_tasks": extra_tasks_config,
}

qf3 = QRFitter3Node(qf_config, label=fitting_name, clean_dir_name=True)
qf3.gen_tasks(gpus=[str(i) for i in range(3, 5)])  # [str(i) for i in range(4,8)]
qf3.run(para_spec="24")

inference_config = get_inference_config()
qf3.node_config = inference_config
qf3.run_inference(para_spec="10")

# 生成subalpha panel
from fit_ca.fitter_scripts.croll_subalpha_fit.gen_subalpha_panel import *
expt_folder = qf3.stage_dir()
copy_del_fit_expt(expt_folder, y_hat_folder="encoded_test")
copy_del_fit_expt(expt_folder, y_hat_folder="residual_test")