from __future__ import annotations
import os
import re
from tqdm import tqdm
import copy
from typing import List, Dict, Callable
from functools import partial, reduce
import pickle
# jobs这个库在qrlite，如果没有请注意看qrlite是否在自己的Python路径下
from canopus_py.rnodes.ca_node import CANode
from canopus_py.ca_expr import *
from canopus_py.ca_stats import *
from canopus_py.rnodes.ca_node import CANode, dump_term_sizes, dump_term_quantile

from pattern_helper import *
from qrfitter3.utils import save_json, read_json, wait_for_processes
import online202409

CANode.DEFAULT_CA_BINARY = "/data/beef2/bin/unstable/canopus"

UNIV = {
    "G2548": "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv",
    "G200": "/data/beef2/data/CA/CNEQ/Univs/gpfast_new/gpf_G200.csv",
    "G500": "/data/beef2/data/CA/CNEQ/Univs/gpfast_new/gpf_G500.csv",
    "G1000": "/data/beef2/data/CA/CNEQ/Univs/gpfast_new/gpf_G1000.csv",
    "Gunion": "/data/beef2/junming/universe/Gunion.csv",
    "Gother": "/data/beef2/junming/universe/Gother.csv",
    "sz": "/data/beef2/junming/universe/sz.csv",
    "sh": "/data/beef2/junming/universe/sh.csv",
}

UNIV_K5 = {f"G{i}": os.path.join("/data/beef2/junming/universe/K=5", f"small_univ_{i}.csv") for i in range(5)}


inds_CNE5 = [
    'AEROSPCE', 'AIRLINES', 'APPAREL', 'AUTOCOMP',
    'BANKS', 'BEVTOB', 'BLDPROD', 'COMMSVCS', 'CHEMICAL', 'CONGTRD',
    'CNSTENG', 'CONMAT', 'CONSDUR', 'CONSRV', 'DIVFINAN', 'ELECEQP',
    'ENERGY', 'FOODPROD', 'FSTAPHPP', 'HDWRSE', 'HEALTH', 'MACHINRY',
    'MARINE', 'MEDIA', 'MTLMIN', 'OTHRCHEM', 'PACKGFP', 'REALEST', 'RETAIL',
    'RDRLTRAN', 'SOFTWARE', 'UTILITY',
]
stls_CNE5 = [
    'ANLYSTSN', 'BETA', 'BTOP', 'DIVYILD', 'EARNQLTY', 'EARNVAR',
    'EARNYILD', 'GROWTH', 'INDMOM', 'INVSQLTY', 'LEVERAGE', 'LIQUIDTY',
    'LTREVRSL', 'MIDCAP', 'MOMENTUM', 'PROFIT', 'RESVOL', 'SEASON',
    'STREVRSL', 'SIZE'
]
factors_CNE5D = inds_CNE5+stls_CNE5
imp_stls = ['SIZE', 'BETA', 'MOMENTUM', 'RESVOL']

CAv24Path = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels"


def create_fake_files(dates, folder_path):
    file_pattern = "fake.YYYYMMDD.sdiv"
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
    for date in dates:
        file_name = file_pattern.replace("YYYYMMDD", str(date))
        file_path = os.path.join(folder_path, file_name)
        with open(file_path, 'w') as file:
            pass  # 创建一个空文件
    return os.path.join(folder_path, file_pattern)

def get_common_date_pattern(*patterns, folder_path=f"/tmp/{os.environ['USER']}/fake_pattern_{os.getpid()}"):

    common_dates = set(find_dates_from_pattern(patterns[0]))
    for pattern in patterns[1:]:
        common_dates = common_dates.intersection(find_dates_from_pattern(pattern))
    common_dates = sorted(list(common_dates))
    date_pattern = create_fake_files(common_dates, folder_path=folder_path)
    return date_pattern

def get_run_periods(pattern, start_date:str|int=None, end_date:str|int=None, drop_last=0):
    run_periods = find_dates_from_pattern(pattern)
    start_date = 0 if start_date is None else int(start_date)
    end_date = 30000000 if end_date is None else int(end_date)
    run_periods = [d for d in run_periods if d >= start_date and d <= end_date]
    if drop_last > 0:
        run_periods = run_periods[:-drop_last]
    return run_periods

def dump_weights(label="W.period", start_date:str=None, end_date:str=None, output_ii=None, univ="G2548"):
    sample_suffix = '.5min' if output_ii is None else ''
    univ_suffix = "" if univ == "G2548" else f".{univ}"
    label = f"{label}{sample_suffix}{univ_suffix}"

    node_config = CANode.base_config()
    node_config["CA.univ"] = UNIV[univ]
    file_pattern = "/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/BB/5min-YYYYMMDD.sdiv"
    node_config["EVENTS.busdate_pattern"] = file_pattern

    node_config["OUTPUT.terms"] = False
    node_config["OUTPUT.shm"] = True
    node_config["OUTPUT.shm_label"] = label
    if output_ii is not None:
        node_config["OUTPUT.terms.output_ii"] = output_ii  # downsample

    node_config["DATA.panels"] += ["5min"]
    node_config["DATA.5min.pattern"] = file_pattern
    # node_config["CA.terms"]["wgt"] = ca.Na20(ca('is.active'))
    if label.startswith('W.period1'):
        node_config["CA.terms"].update({
            "w_op1": ca.IIndex() <= ca.C(6),
            "w_mh1": (ca.IIndex() > ca.C(6)) & (ca.IIndex() <= ca.C(42)),
            "w_ed1": (ca.IIndex() > ca.C(42)),
        })
    if label.startswith('W.period2'):
        node_config["CA.terms"].update({
            "w_op2": ca.IIndex() <= ca.C(12),
            "w_mh2": (ca.IIndex() > ca.C(12)) & (ca.IIndex() <= ca.C(36)),
            "w_ed2": (ca.IIndex() > ca.C(36)),
        })
    if label.startswith('W.period8'):  # 8个半小时
        node_config["CA.terms"].update({
            f"w_p{i}": (ca.IIndex() > ca.C(i*6)) & (ca.IIndex() <= ca.C((i+1)*6))
            for i in range(8)
        })
    if label.startswith('W.period48'):  # 48个时间点
        node_config["CA.terms"].update({
            f"w_p{i}": ca.IIndex() == ca.C(i) for i in range(1, 49)
        })

    node = CANode(node_config, label=label, clean_dir_name=True)
    run_periods = get_run_periods(file_pattern, start_date, end_date)
    node.run_periods = run_periods
    node.run(para_spec=40)


def barra_decompose(node_config, columns, regress: str|List[str]='o'):  # 可作为calc_f传入
    panel_name = "weight_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.W
    node_config[f"DATA.{panel_name}.columns"] = ['is.active']
    panel_name = "st_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.ST
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = ["st"]
    w = ca.Na20('is.active') * (~ca.Na20("st"))

    # 加入Barraexp数据
    panel_name = "BarraExp"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = "/data/nfs0/chinaEquityData/panel/barra/exp-YYYYMMDD.sdiv"
    node_config[f"DATA.{panel_name}.inclusive"] = False  # barra exp YYYYMMDD.sdiv要下一天bod才能用

    factors_all = [ca.Na20(i) for i in factors_CNE5D]
    if isinstance(regress, str):
        regress = [regress]
    for term in columns:
        v = ca.Na20(ca(term))
        if 'o' in regress:
            node_config["CA.terms"][term] = v
        if 'b' in regress:
            node_config["CA.terms"][f"{term}.b"] = ca.Na20(ca.RegRes(v, factors_all, w=w))  # bod_reg=True的意思是(X^TX)^(-1)X这个东西在bod就算好了，整天都沿用。但这样没法在回归中考虑wgt
        if 'bp' in regress:
            node_config["CA.terms"][f"{term}.bp"] = ca.Na20(ca.RegYHat(v, factors_all, w=w))  # w有些截面全为0，因此此时这些beta是nan，比如20190122 13:05:00

def random_barra_fret(node_config, columns, random_panel_pattern):
    panel_name = "weight_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.W
    node_config[f"DATA.{panel_name}.columns"] = ['is.active']
    panel_name = "st_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.ST
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = ["st"]
    w = ca.Na20('is.active') * (~ca.Na20("st"))

    panel_name = "BarraExp"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = "/data/nfs0/chinaEquityData/panel/barra/exp-YYYYMMDD.sdiv"
    node_config[f"DATA.{panel_name}.inclusive"] = False  # barra exp YYYYMMDD.sdiv要下一天bod才能用

    panel_name = "random_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = random_panel_pattern

    all_term_fret = ca.RegBetaGroup([ca.Na20(term) for term in columns], [ca.Na20(term) for term in factors_CNE5D], w=w)  # w有些截面全为0，因此此时这些beta是nan，比如20190122 13:05:00
    for i, term in enumerate(columns):
        res = ca.Na20(ca.RegRes(ca.Na20(term), [ca.Na20(term) for term in factors_CNE5D], w=w))
        for j, factor in enumerate(factors_CNE5D):
            multiplier = ca.Na20(f"{factor}.random")
            res += multiplier * ca.Na20(all_term_fret[[i, j]]) * ca.Na20(factor)
        node_config["CA.terms"][term] = res

def dump_barra_fret_exp(node_config, columns):
    panel_name = "weight_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.W
    node_config[f"DATA.{panel_name}.columns"] = ['is.active']
    panel_name = "st_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.ST
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = ["st"]
    w = ca.Na20('is.active') * (~ca.Na20("st"))

    panel_name = "BarraExp"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = "/data/nfs0/chinaEquityData/panel/barra/exp-YYYYMMDD.sdiv"
    node_config[f"DATA.{panel_name}.inclusive"] = False  # barra exp YYYYMMDD.sdiv要下一天bod才能用

    reg_factors = imp_stls+inds_CNE5
    all_term_fret = ca.RegBetaGroup([ca.Na20(term) for term in columns], [ca.Na20(term) for term in reg_factors], bod_reg=True)
    for i, term in enumerate(columns):
        res = ca.Na20(ca.RegRes(ca.Na20(ca(term)), [ca.Na20(term) for term in reg_factors], w=w, bod_reg=True))
        node_config["CA.terms"][f"{term}__res"] = res
        ind_component = ca.C(0)
        for j, factor in enumerate(reg_factors):
            if factor in inds_CNE5:
                ind_component += ca.Na20(all_term_fret[[i, j]]) * ca.Na20(factor)
            else:
                node_config["CA.terms"][f"{term}__{factor}"] = ca.Na20(all_term_fret[[i, j]]) * ca.Na20(factor)
            node_config["CA.terms"][f"{term}__INDUSTRY"] = ind_component

def multiply_magic(node_config, columns, process=None):
    subalphas = read_columns_from_pattern("/data/beef2/junming/croll_alpha/subalpha20240710/terms.YYYYMMDD.sdiv")
    magics = read_columns_from_pattern("/data/beef2/junming/croll_alpha/subalpha20240715/terms.YYYYMMDD.sdiv")
    prefix = "m3_magic.magic"
    for subalpha in subalphas:
        magic = [x for x in magics if x.startswith(f"{prefix}.{subalpha}.")]
        assert len(magic) == 1, f"subalpha {subalpha} matches wrong magic: {magic}"
        magic = magic[0]
        if process is None:
            node_config["CA.terms"][f"{subalpha}.mul"] = ca.Na20(ca(subalpha) * ca(magic))
        elif process == "xsrank":
            node_config["CA.terms"][f"{subalpha}.mul"] = ca.Na20(ca(subalpha) * (ca.C(1) + ca.XsRank(ca(magic))))
        else:
            raise NotImplementedError

def xsrankp1(node_config, columns):
    for term in columns:
        node_config["CA.terms"][term] = ca.Na20((ca.C(1) + ca.XsRank(ca(term))))  # XsRank2是忽略nan的rank，XsRank会把nan都排在前面或者后面

def nonactive2nan(node_config, columns, univ="G2548"):
    panel_name = "5min"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = os.path.join(CAv24Path, "I/fq5m/BB/terms.YYYYMMDD.sdiv")
    node_config[f"DATA.{panel_name}.columns"] = ['is.active']
    
    panel_name = "index"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"  # 这东西每天更新，适合做business pattern
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = ["sh50", "csi300", "csi500", "zz1000"]  # , "zz2000" 24年1月之后没有

    panel_name = "univ_x"
    x_columns = ["topx"]  # (注意：smlx从20180101之后才开始生成, 且在20180102, 20200203没有)  # , "midx", "smlx", "botx"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = "/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv"  # 往前能到2007年
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = x_columns

    panel_name = "st_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = os.path.join(CAv24Path, "D/eod/sid_st/st_YYYYMMDD.sdiv")  # 往前能到2007年
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = ["st"]

    valid_indicator = ca.Na20('is.active')
    if univ != "G2548":
        valid_indicator = valid_indicator * ca.Sign(ca.Na20(univ))
    valid_indicator = valid_indicator * (~ca.Na20("st"))
    for term in columns:
        node_config["CA.terms"][term] = ca.IfElse(valid_indicator == ca.C(1), ca.Na20(ca(term)), ca.C("nan"))

def xszscore(node_config, columns):
    for term in columns:
        node_config["CA.terms"][term] = ca.Na20(ca.XsZScore(ca(term)))

def normalization(node_config, columns, pattern_list:str|list, bins=100, add_suffix: bool|str=False):
    if isinstance(pattern_list, str):
        pattern_list = [pattern_list]
    all_terms = reduce(list.__add__, [read_columns_from_pattern(pattern) for pattern in pattern_list])
    if len(all_terms) > len(set(all_terms)):
        counts = pd.Series(all_terms).values_counts()
        print(counts[counts>1])
        raise ValueError("Name conflict")
    quantiles_median_list = []
    for pattern in pattern_list:
        try:
            quantiles_median, _ = dump_term_quantile(pattern, dates=None, refresh_data=False, bins=bins)
        except FileNotFoundError:
            try:
                quantiles_median, _ = dump_term_quantile(pattern, dates=None, refresh_data=True, dump_files=True, bins=bins)
            except PermissionError:
                quantiles_median, _ = dump_term_quantile(pattern, dates=None, refresh_data=True, dump_files=False, bins=bins)
        quantiles_median_list.append(quantiles_median)
    quantiles_median = pd.concat(quantiles_median_list, axis=0)
    for term in columns:
        bin_edges = quantiles_median.loc[term]
        if bin_edges.isna().all():  # nunique个数不够算不出bin
            pass # term = ca.Na20(yhat)
        else:
            name = term + add_suffix if add_suffix else term
            node_config["CA.terms"][name] = ca.Na20(ca.NormalDist(ca(term), bin_edges.tolist()))

def mad(node_config, columns, pattern_list:str|list, add_suffix: bool|str=False):
    if isinstance(pattern_list, str):
        pattern_list = [pattern_list]
    all_terms = reduce(list.__add__, [read_columns_from_pattern(pattern) for pattern in pattern_list])
    if len(all_terms) > len(set(all_terms)):
        counts = pd.Series(all_terms).values_counts()
        print(counts[counts>1])
        raise ValueError("Name conflict")
    sizes_dict_all = {}
    for pattern in pattern_list:
        try:
            sizes_dict = dump_term_sizes(pattern, dates=None, refresh_data=False, mad=True)
        except FileNotFoundError:
            try:
                sizes_dict = dump_term_sizes(pattern, dates=None, refresh_data=True, mad=True)
            except PermissionError:
                sizes_dict = dump_term_sizes(pattern, dates=None, refresh_data=True, dump_files=False, mad=True)
        sizes_dict_all |= sizes_dict
    for term in columns:
        name = term + add_suffix if add_suffix else term
        node_config["CA.terms"][name] = ca.Na20(ca.Clip(ca(term) / ca.C(sizes_dict_all[term]), 5))

def xsdemean(node_config, columns):
    for term in columns:
        node_config["CA.terms"][term] = ca.Na20(ca(term) - ca.XsMean(term))

def xswinsorize(node_config, columns):
    for term in columns:
        node_config["CA.terms"][term] = ca.Na20(ca.Winsorize(ca(term)))

def posneg_separation(node_config, columns):
    for term in columns:
        node_config["CA.terms"][term] = ca.Na20(term)
        node_config["CA.terms"][f"{term}.pos"] = ca.Na20(ca.IfElse(ca(term) > ca.C(0), ca(term), ca.C(0)))
        node_config["CA.terms"][f"{term}.neg"] = ca.Na20(ca.IfElse(ca(term) < ca.C(0), ca(term), ca.C(0)))

def xsproject(node_config, columns, xsproject_panel_pattern, xs_wgt_name="xs_wgt", include_res=False):
    if include_res:
        panel_name = "weight_panel"
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.W
        node_config[f"DATA.{panel_name}.columns"] = ['is.active']
        panel_name = "st_panel"
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.ST
        node_config[f"DATA.{panel_name}.inclusive"] = False
        node_config[f"DATA.{panel_name}.columns"] = ["st"]
        w = ca.Na20('is.active') * (~ca.Na20("st"))

    panel_name = "xsproject_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = xsproject_panel_pattern
    node_config[f"DATA.{panel_name}.inclusive"] = True

    xsproj = ca.XsProj([ca.Na20(c) for c in columns], xs_wgt_name, d_mode_load=False)
    for i, c in enumerate(columns):
        node_config["CA.terms"][c] = ca.Na20(c)
        node_config["CA.terms"][f"{c}.proj"] = ca.Na20(ca.XsZScore(xsproj[f"v_{i}"]))
        if include_res:
            node_config["CA.terms"][f"{c}.res"] = ca.Na20(ca.XsZScore(ca.RegRes(xsproj[f"v_{i}"], c, w=w)))

def xsdemean_within_index(node_config, columns):
    panel_name = "index"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"  # 这东西每天更新，适合做business pattern
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = ["sh50", "csi300", "csi500", "zz1000"]  # , "zz2000" 24年1月之后没有
    csi300, csi500 = ca.Sign(ca.Na20("csi300")), ca.Sign(ca.Na20("csi500"))
    other = ~(csi300|csi500)
    for term in columns:
        mean_csi300 = ca.XsMean(ca.IfElse(csi300, ca(term), ca.C("nan")))
        mean_csi500 = ca.XsMean(ca.IfElse(csi500, ca(term), ca.C("nan")))
        mean_other = ca.XsMean(ca.IfElse(other, ca(term), ca.C("nan")))
        group_mean = csi300 * mean_csi300 + csi500 * mean_csi500 + other * mean_other
        node_config["CA.terms"][term] = ca.Na20(ca(term) - group_mean)

def wgt_mul_index(node_config, columns, exclude_st=True, mul_index=False, index_multiplier=[], mul_y=[], y_multiplier=[1,2,3], dindex_decay=False):
    panel_name = "st_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = os.path.join(CAv24Path, "D/eod/sid_st/st_YYYYMMDD.sdiv")  # 往前能到2007年
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = ["st"]

    if mul_index:
        panel_name = "index"
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"  # 这东西每天更新，适合做business pattern
        node_config[f"DATA.{panel_name}.inclusive"] = False
        node_config[f"DATA.{panel_name}.columns"] = ["sh50", "csi300", "csi500", "zz1000"]  # , "zz2000" 24年1月之后没有

        panel_name = "univ_x"
        x_columns = ["topx", "midx"]  # (注意：smlx从20180101之后才开始生成, 且在20180102, 20200203没有)  # , "smlx", "botx"
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = "/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv"  # 往前能到2007年
        node_config[f"DATA.{panel_name}.inclusive"] = False
        node_config[f"DATA.{panel_name}.columns"] = x_columns

    if mul_y:  # 用forward或backward做加权
        y_pattern = os.path.join(CAv24Path, "Y/Y_V5/terms.YYYYMMDD.sdiv")
        node_config["DATA.panels"] += ["Y"]
        node_config["DATA.Y.pattern"] = y_pattern

        panel_name = "Y.backward"
        backwardret_pattern = "/data/nas2Data/chinaEquityData/statarb/midfreq/Y_V5/YYYYMMDD.sdiv"
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = backwardret_pattern
        backwardret_columns = [f for f in read_columns_from_pattern(backwardret_pattern) if f.endswith("b")]
        node_config[f"DATA.{panel_name}.columns"] = backwardret_columns

    if dindex_decay:
        panel_name = "dindex_decay"
        decay_weight_pattern = "/data/beef2/junming/data/decay_weights/terms.YYYYMMDD.sdiv"
        decay_weight_columns = read_columns_from_pattern(decay_weight_pattern)
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = decay_weight_pattern  # 往前能到2007年
        node_config[f"DATA.{panel_name}.inclusive"] = True
        node_config[f"DATA.{panel_name}.columns"] = decay_weight_columns
        
    csi300, csi500 = ca.Sign(ca.Na20("csi300")), ca.Sign(ca.Na20("csi500"))
    csi800 = (csi300 | csi500)
    zz1000_midx =(ca.Sign(ca.Na20("zz1000")) | ca.Sign(ca.Na20("midx")))
    index_weight = {
        # "csi300": csi300,
        # "csi500": csi500,
        # "csi800": csi800,
        # "zz1000_midx": zz1000_midx,
    }
    # for col in x_columns:
    #     index_weight[col] = ca.Sign(ca.Na20(col))

    for i in index_multiplier:  # [2,4,8,16]
        index_weight.update({
            # f"csi300.{i}_other.1": ca.IfElse(csi300, ca.C(i), ca.C(1)),
            # f"csi500.{i}_other.1": ca.IfElse(csi500, ca.C(i), ca.C(1)),
            # f"csi800.{i}_other.1": ca.IfElse(csi800, ca.C(i), ca.C(1)),
            # f"zz1000_midx.{i}_other.1": ca.IfElse(zz1000_midx, ca.C(i), ca.C(1)),
        })
        # for col in x_columns:
        #     index_weight[f"{col}.{i}_other.1"] =  ca.IfElse(ca.Sign(ca.Na20(col)), ca.C(i), ca.C(1))

    for term in columns:
        ca_term = ca.Na20(ca(term))
        if exclude_st:
            ca_term = ca_term * (~ca.Na20("st"))
        node_config["CA.terms"][term] = ca.Na20(ca_term)
        if mul_index:  # 要不要乘以index或者topx
            for name, weight in index_weight.items():
                node_config["CA.terms"][f"{term}_{name}"] = ca.Na20(ca_term * weight)
        for y in mul_y:
            abs_y = ca.Abs(y)
            for i in y_multiplier:  # 多少倍放大y的weight
                node_config["CA.terms"][f"{term}_{y}_pow{i}"] = ca.Na20(ca_term * ca.NumPow(abs_y, i))
        if dindex_decay:
            for decay in decay_weight_columns:
                node_config["CA.terms"][f"{term}_{decay}"] = ca_term * ca(decay)

def cluster_weight(node_config, columns, clusters=[0,1,2,3]):
    panel_name = "st_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = os.path.join(CAv24Path, "D/eod/sid_st/st_YYYYMMDD.sdiv")  # 往前能到2007年
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = ["st"]

    panel_name = "5min"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.W
    node_config[f"DATA.{panel_name}.columns"] = ["is.active"]

    panel_name = "cluster_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = "/data/beef2/junming/data/mpvh.normal_Kmeans4/Cluster.YYYYMMDD.sdiv"
    node_config[f"DATA.{panel_name}.columns"] = ["Cluster"]

    wgt = (ca.C(1)-ca.Na20("st")) * ca.Na20("is.active")
    assert columns == ["Cluster"], columns
    node_config["CA.terms"]["is.active"] = wgt
    for cluster in clusters:
        node_config["CA.terms"][f"cluster{cluster}"] = wgt * ca.Na20(ca.IfElse(ca.Na20("Cluster") == ca.C(cluster), ca.C(1), ca.C(0)))
        for multiplier in [2, 4]:
            node_config["CA.terms"][f"cluster{cluster}_mul{multiplier}"] = wgt * ca.Na20(ca.IfElse(ca.Na20("Cluster") == ca.C(cluster), ca.C(multiplier), ca.C(1)))


def externel_weight(node_config, columns):
    panel_name = "5min"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = W = os.path.join(CAv24Path, "I/fq5m/BB/terms.YYYYMMDD.sdiv")
    node_config[f"DATA.{panel_name}.columns"] = ['is.active']

    panel_name = "st_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = os.path.join(CAv24Path, "D/eod/sid_st/st_YYYYMMDD.sdiv")  # 往前能到2007年
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = ["st"]

    senti_pattern = "/data/beef3/guopeng/alter_data/news_senti/senti-YYYYMMDD.sdiv"    
    node_config["DATA.panels"] += ["senti"]
    node_config["DATA.senti.pattern"] = senti_pattern
    node_config["DATA.senti.lb_days"] = 10
    senti = ca.Na20(ca.FFill(ca.IfElse(ca("senti")==ca.C(0), ca.C("nan"), ca.C(1)), 96, rpii=2))
    node_config["CA.terms"]["is.active_senti"] = ca.Na20('is.active') * (~ca.Na20("st")) * senti

def y_resi(node_config, columns, yhat_pattern):

    node_config["DATA.panels"] += ["Y"]
    node_config["DATA.Y.pattern"] = os.path.join(CAv24Path, "Y/Y_V5/terms.YYYYMMDD.sdiv")
    node_config["DATA.Y.columns"] = ["mret1h", "mret24h", "bret1h", "bret24h", "bret5e", "bpret24h"]

    node_config["DATA.panels"] += ["5min"]
    node_config["DATA.5min.pattern"] = os.path.join(CAv24Path, "I/fq5m/BB/terms.YYYYMMDD.sdiv")
    node_config["DATA.5min.columns"] = ["is.active"]

    panel_name = "st_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = os.path.join(CAv24Path, "D/eod/sid_st/st_YYYYMMDD.sdiv")  # 往前能到2007年
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = ["st"]

    panel_name = "yhat"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = yhat_pattern
    yhats = read_columns_from_pattern(yhat_pattern)
    for yhat in yhats:
        node_config["CA.terms"][f"{yhat}_mret24h.RegRes"] = ca.RegRes(ca.Na20("mret24h"), ca.Na20(yhat), w=ca.Na20("is.active") * (~ca.Na20("st")))
        node_config["CA.terms"][f"{yhat}_mret24h.MinusRes"] = ca.Na20("mret24h") - ca.Na20(yhat)

def y_clip(node_config, columns, thresholds=[0.05, 0.07, 0.08, 0.1, 0.15]):
    for term in columns:
        node_config["CA.terms"][term] = ca.Na20(term)
        for threshold in thresholds:
            node_config["CA.terms"][f"{term}.clip{threshold:.2f}"] = ca.Na20(ca.IfElse(ca(term) > ca.C(threshold), ca.C(threshold), ca.IfElse(ca(term) < ca.C(-threshold), ca.C(-threshold), ca(term))))

def get_overnight_intraday_ret(node_config, columns, teacher_panel:str=None, clip=False):
    # 原始24h
    mret24h, bret24h = ca.Na20(ca("mret24h")), ca.Na20(ca("bret24h"))
    bpret24h = mret24h - bret24h
    node_config["CA.terms"]["mret24h"] = mret24h
    node_config["CA.terms"]["bret24h"] = bret24h
    node_config["CA.terms"]["bpret24h"] = bpret24h
    node_config["CA.terms"]["bpret24h.zs"] = ca.Na20(ca.XsZScore(ca("mret24h") - ca("bret24h")))
    node_config["CA.terms"]["bpret24h.rk"] = ca.Na20(ca.XsRank2(ca("mret24h") - ca("bret24h")))
    # 1h
    node_config["CA.terms"]["mret1h"] = ca.Na20(ca("mret1h"))
    node_config["CA.terms"]["bret1h"] = ca.Na20(ca("bret1h"))
    node_config["CA.terms"]["bpret1h"] = ca.Na20(ca("mret1h") - ca("bret1h"))
    # 当日日内 0itrd
    mret0e = ca.Na20(ca("mret0e"))
    bret0e = ca.Na20(ca("bret0e"))
    bpret0e = mret0e - bret0e
    node_config["CA.terms"]["mret0e"] = mret0e
    node_config["CA.terms"]["bret0e"] = bret0e
    node_config["CA.terms"]["bpret0e"] = bpret0e
    # 至次日开盘 1o
    mret1o = ca.Na20(ca("mret1o"))
    bret1o = ca.Na20(ca("bret1o"))
    bpret1o = mret1o - bret1o
    node_config["CA.terms"]["mret1o"] = mret1o
    node_config["CA.terms"]["bret1o"] = bret1o
    node_config["CA.terms"]["bpret1o"] = bpret1o
    # 当日隔夜 ovnt
    mret_ovnt = mret1o - mret0e
    bret_ovnt = bret1o - bret0e
    bpret_ovnt = mret_ovnt - bret_ovnt
    node_config["CA.terms"]["mret_ovnt"] = mret_ovnt
    node_config["CA.terms"]["bret_ovnt"] = bret_ovnt
    node_config["CA.terms"]["bpret_ovnt"] = bpret_ovnt
    # 次日日内 1itrd
    mret_1itrd = mret24h - mret1o
    bret_1itrd = bret24h - bret1o
    bpret_1itrd = mret_1itrd - bret_1itrd
    node_config["CA.terms"]["mret_1itrd"] = mret_1itrd
    node_config["CA.terms"]["bret_1itrd"] = bret_1itrd
    node_config["CA.terms"]["bpret_1itrd"] = bpret_1itrd
    # 5e
    node_config["CA.terms"]["mret5e"] = ca.Na20(ca("mret5e"))
    node_config["CA.terms"]["bret5e"] = ca.Na20(ca("bret5e"))
    node_config["CA.terms"]["bpret5e"] = ca.Na20(ca("bpret5e"))

    if clip:
        for ret, expr in node_config["CA.terms"].items():
            if ret.endswith("1h") or ret.endswith("0e") or ret.endswith("1itrd"):
                threshold = 0.05
                node_config["CA.terms"][ret] = ca.Na20(ca.IfElse(expr > ca.C(threshold), ca.C(threshold), ca.IfElse(expr < ca.C(-threshold), ca.C(-threshold), expr)))
            elif ret.endswith("24h") or ret.endswith("ovnt") or ret.endswith("1o"):
                threshold = 0.12
                node_config["CA.terms"][ret] = ca.Na20(ca.IfElse(expr > ca.C(threshold), ca.C(threshold), ca.IfElse(expr < ca.C(-threshold), ca.C(-threshold), expr)))
            elif ret.endswith("5e"):
                threshold = 0.25
                node_config["CA.terms"][ret] = ca.Na20(ca.IfElse(expr > ca.C(threshold), ca.C(threshold), ca.IfElse(expr < ca.C(-threshold), ca.C(-threshold), expr)))

    if teacher_panel is not None:
        # panel_name = "teacher"
        # node_config["DATA.panels"] += [panel_name]
        # node_config[f"DATA.{panel_name}.pattern"] = '/data/beef2/junming/temp_alpha/m24h_1keach_addG_en/yhat.YYYYMMDD.sdiv'
        # node_config["CA.terms"]["teacher.eqw"] = ca.Na20(ca("eqw"))
        # node_config["CA.terms"]["teacher.ridge"] = ca.Na20(ca("ridge"))

        # panel_name = "teacher"
        # node_config["DATA.panels"] += [panel_name]
        # node_config[f"DATA.{panel_name}.pattern"] = '/data/beef2/junming/alpha/online202409/static_ensemble/terms.YYYYMMDD.sdiv'
        # node_config["CA.terms"]["teacher.static"] = ca.Na20(ca("final_alpha"))

        panel_name = "teacher"
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = teacher_panel
        for col in read_columns_from_pattern(teacher_panel):
            node_config["CA.terms"][col] = ca.Na20(ca(col))


def get_conditionals(node_config, columns, conditionals=['W.period1']):

    if 'W.period1' in conditionals:
        node_config["CA.terms"].update({
            "w_op1": ca.IIndex() <= ca.C(6),
            "w_mh1": (ca.IIndex() > ca.C(6)) & (ca.IIndex() <= ca.C(42)),
            "w_ed1": (ca.IIndex() > ca.C(42)),
        })
    if 'W.period2' in conditionals:
        node_config["CA.terms"].update({
            "w_op2": ca.IIndex() <= ca.C(12),
            "w_mh2": (ca.IIndex() > ca.C(12)) & (ca.IIndex() <= ca.C(36)),
            "w_ed2": (ca.IIndex() > ca.C(36)),
        })
    if 'W.period8' in conditionals:  # 8个半小时
        node_config["CA.terms"].update({
            f"w_p{i}": (ca.IIndex() > ca.C(i*6)) & (ca.IIndex() <= ca.C((i+1)*6))
            for i in range(8)
        })

def get_ae_resi_from_decoded(node_config, columns, fit_folder):
    panel_name = "weight_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.W
    node_config[f"DATA.{panel_name}.columns"] = ['is.active']
    panel_name = "st_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.ST
    node_config[f"DATA.{panel_name}.inclusive"] = False
    node_config[f"DATA.{panel_name}.columns"] = ["st"]
    panel_name = "y_panel"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = online202409.terms.Y
    w = ca.Na20('is.active') * (~ca.Na20("st"))

    panel_name = f"decoded"
    node_config["DATA.panels"] += [panel_name]
    node_config[f"DATA.{panel_name}.pattern"] = os.path.join(fit_folder, "canopus_inference_decoded/terms.YYYYMMDD.sdiv")

    expt_folder = os.path.dirname(fit_folder)
    with open(os.path.join(expt_folder, "X_pattern.pkl"), 'rb') as f:
        X_pattern = pickle.load(f)
    for Xname, pattern_dicts in X_pattern.items():  # 支持多个Xname,一个Xname对应shm中的一个label，即一个文件
        configurate_node(node_config=node_config, label=Xname, pattern_dicts=pattern_dicts)
    feature_expr_map = node_config.pop("CA.terms")
    node_config["CA.terms"] = {}
    feature_names = read_json(os.path.join(fit_folder, "feature_names.json"))
    for i, term in enumerate(feature_names):
        node_config["CA.terms"][f"resi_{i}"] = ca.Na20(ca.RegRes(feature_expr_map[term], ca(f"decoded_{i}"), w=w))
        # node_config["CA.terms"][f"diff_{i}"] = feature_expr_map[term] - ca(f"decoded_{i}")

def configurate_node(node_config, label:str, pattern_dicts:dict|List[dict]):
    if isinstance(pattern_dicts, dict):
        pattern_dicts = [pattern_dicts]
    for i, pattern_dict in enumerate(pattern_dicts):  # 一个Xname(i.e. label)支持多个pattern_dict,方便对不同的panel采取不一样的calc_f以及inclusive等
        patterns = pattern_dict["pattern"]
        if isinstance(patterns, str):
            patterns = [patterns]
        for j, pattern in enumerate(patterns):  # 一个pattern_dict中含有多个panel pattern
            panel_name = f"{label}.pattern_dict{i}.panel{j}"
            node_config["DATA.panels"] += [panel_name]
            node_config[f"DATA.{panel_name}.pattern"] = pattern
            if "inclusive" in pattern_dict:  # 优先使用外部指定了inclusive,像"/data/nfs0/chinaEquityData/panel/barra/exp-YYYYMMDD.sdiv"这个路径中没有eod就必须手动设置False
                inclusive = pattern_dict["inclusive"]
            else:
                inclusive = True  # 多I的panel设置这个也不会有影响
                nI = read_columns_from_pattern(pattern, dim="I")
                if len(nI) == 1:  # pattern是daily panel
                    if nI[0] == "00:00:00" and "eod" in pattern.split("/"):  # 跟国鹏确认过以这个判断eod的逻辑为准
                        inclusive = False
            node_config[f"DATA.{panel_name}.inclusive"] = inclusive
            panel_features = read_columns_from_pattern(pattern)
            if 'columns' in pattern_dict:
                columns = pattern_dict['columns']
                panel_features = [f for f in columns if f in panel_features] # 未必该panel所有terms都要, 按columns保一下序，单panel应该好使
            if "rename" in pattern_dict:  # 需要重命名，因为该patterns跟别的patterns有terms重名
                node_config[f"DATA.{panel_name}.columns"] = panel_features
                rename = pattern_dict["rename"]
                if isinstance(rename, str):  # 统一加前缀来重命名
                    panel_features = [f"{rename}.{term}" for term in panel_features]
                else:
                    assert isinstance(rename, list) and len(rename) == len(panel_features), f"{type(rename)}, length {len(rename)} != {len(panel_features)} panel_features"
                    panel_features = rename
                node_config[f"DATA.{panel_name}.column_masks"] = panel_features
            if 'calc_f' in pattern_dict:
                calc_f = pattern_dict['calc_f']
                calc_f(node_config, panel_features)
            else:  # 普通的feature transformation
                node_config["CA.terms"] |= {term: ca.Na20(term) for term in panel_features}

def dump_shm(
    label, pattern_dicts:dict|List[dict], *, 
    univ="G2548", run_periods:List[str]=None, start_date:int=None, end_date:int=None, freq_m:int=5, output_ii=list(range(1,49,1)),
    d_concat=False, date_pattern=None, para_spec=80,
    shm=True, dump_config_only=False, rnode_root=f"/tmp/{os.environ['USER']}", chain_name="dump_shm"
):
    """
    把pattern文件(如多个则combine后)dump到shm里，shm里名字叫label。
    pattern_dicts里面每个dict形如{"pattern": list of patterns, "columns": list of features, "inclusive": bool, "calc_f": Callable}
    """
    if date_pattern is None:
        date_pattern = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"
    node_config = CANode.base_config()
    node_config["CA.freq_m"] = freq_m
    node_config["EVENTS.busdate_pattern"] = date_pattern
    if univ in UNIV:
        node_config["CA.univ"] = UNIV[univ]
    elif univ in ["sh50", "csi300", "csi500", "zz1000", "sci50"] :
        node_config["CA.univ"] = f"/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv:{univ}"
    elif univ in ["topx", "midx", "smlx", "botx"]:
        node_config["CA.univ"] = f"/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv:{univ}"
    elif univ in ["csi800", "zz1000_midx", "ooi"]:
        node_config["CA.univ"] = f"/data/beef2/junming/data/univ_active/terms.YYYYMMDD.sdiv:{univ}"
    else:
        raise NotImplementedError(f"Unknown {univ}")

    if isinstance(pattern_dicts, dict):
        pattern_dicts = [pattern_dicts]
    # 检查有无重名
    all_terms = []
    for pattern_dict in pattern_dicts:
        patterns = pattern_dict["pattern"]
        if isinstance(patterns, str):
            patterns = [patterns]
        for i, pattern in enumerate(patterns):
            panel_features = read_columns_from_pattern(pattern)
            if "rename" in pattern_dict:  # 需要重命名，因为该patterns跟别的patterns有terms重名
                rename = pattern_dict["rename"]
                panel_features = [f"{rename}.{term}" for term in panel_features]
            all_terms.extend(panel_features)
    name_conflict = (len(all_terms) > len(set(all_terms)))
    if name_conflict:
        counts = pd.Series(all_terms).value_counts()
        print(counts[counts>1])
        raise ValueError(f"NAME CONFLICT")

    configurate_node(node_config=node_config, label=label, pattern_dicts=pattern_dicts)
    
    if run_periods is None:  # 优先使用指定的run_periods
        run_periods = get_run_periods(date_pattern, start_date, end_date)
    if d_concat:
        assert shm
        node_config["OUTPUT.shm"] = False
        node_config["OUTPUT.d_concat_shm"] = True
        node_config["OUTPUT.shm.dim_seq"] = "DISV"  # D-continuous，so that slicing along D dim returns continuous memory for lgb training
        node_config["OUTPUT.all_dates"] = run_periods
        node_config["OUTPUT.shm_label"] = f"{label}_d_concat"
    else:
        node_config["OUTPUT.shm"] = shm
        node_config["OUTPUT.shm_label"] = label
    node_config["OUTPUT.terms"] = not shm
    node_config["OUTPUT.terms.output_ii"] = output_ii

    if node_config.get("EVENTS.gf_weeks", 0) != 0:  # 需要从run_periods中找到每个周一来跑
        run_periods = [i for i in run_periods if datetime.datetime.strptime(str(i), "%Y%m%d").weekday() == 0]
    node = CANode(node_config, label=label, clean_dir_name=True, rnode_root=rnode_root, chain_name=chain_name)
    if ca.use_nugg_cache:
        node.node_config["CA.nuggs"] = ca.get_nugg_cache()
    node.run_periods = run_periods
    if dump_config_only:# often we don't need to re-dump shm, but we'd like to save config for future reference
        node.dump_config_json()
    else:  
        node.run(para_spec=para_spec, delayEachJob=1 if label.startswith("X") else 0)

def clear_shm(patterns: List[str]=None):
    """如何patterns是None代表清楚所有shm, 如果是空list代表不清"""
    print(f"cleaning shm for patterns: {patterns}")
    shm_dir = "/dev/shm"
    delete_count = 0
    for file in tqdm(os.listdir(shm_dir)):
        if patterns is not None:
            remove = False
            for pattern in patterns:
                if re.search(pattern, file):
                    remove = True
                    break
            if not remove:
                continue
        file_path = os.path.join(shm_dir, file)
        if os.path.isfile(file_path):
            try:
                os.unlink(file_path)
            except PermissionError:
                pass
            else:
                delete_count += 1
    print(f"delete_count: {delete_count}")


def prepare_shm(
    data={}, configs=[], clear_data=False, d_concat=False, dump_config_only_list=[], para_spec=80,
    rnode_root='', chain_name='',
    wait_pids=[], clear_labels=[],
):
    """data: Dict[label, pattern_dicts:dict|List[dict]]"""
    wait_for_processes(wait_pids)
    sdiv = "_d_concat.sdiv" if d_concat else ".sdiv"
    clear_patterns = [f"{label}{sdiv}" for label in clear_labels]  # label要符合这样的pattern
    if clear_data:
        clear_patterns.extend(list(data.keys()))
    clear_shm(patterns=clear_patterns)
    if data:
        if d_concat: # 对于tree模型所需要的d_concat array，必须得到所有panel的dates交集
            patterns = []
            for pattern_dicts in data.values():
                if isinstance(pattern_dicts, dict):
                    pattern_dicts = [pattern_dicts]
                for pattern_dict in pattern_dicts:
                    pattern = pattern_dict["pattern"]
                    if isinstance(pattern, list):
                        patterns.extend(pattern)
                    else:
                        patterns.append(pattern)
            date_pattern = get_common_date_pattern(*patterns)
        else:
            date_pattern = None

        start_ends = []  # 是一个长度等于config长度的list，e.g. 长度=2 when config是train-test(目前train=is+vd)
        for config in configs:
            univ, mask_univ = config.get("univ", "G2548"), config.get("mask_univ", None)
            output_ii, freq_m = config.get("output_ii", list(range(1,49,1))), config.get("freq_m", 5)
            run_periods, start_date, end_date = config.get("run_periods", None), config.get("start_date", None), config.get("end_date", None)
            exclude_periods, exclude_start_date, exclude_end_date = config.get("exclude_periods", None), config.get("exclude_start_date", None), config.get("exclude_end_date", None)
            if d_concat:
                # 对于tree使用的d_concat shm来说，如果要exclude_dates那就在创建的时候就exclude掉，mlp暂时还是放在fitter的dataset里exclude
                if run_periods is None:
                    run_periods = get_run_periods(date_pattern, start_date, end_date)
                if exclude_periods is None:
                    if exclude_start_date is not None and exclude_end_date is not None:
                        exclude_periods = get_run_periods(date_pattern, exclude_start_date, exclude_end_date)
                    else:
                        exclude_periods = []
                run_periods = sorted([d for d in run_periods if d not in exclude_periods])
                start_end = f"{run_periods[0]}_{run_periods[-1]}"  # e.g "20180102_20221230"
                start_ends.append(start_end)  # tree所用d_concat模式需要记录下start_ends方便之后从shm中寻找对应的文件
                # mask_univ=None是为了跟之前之前的实验结果保持一致即全U就不mask, nonactive2nan主要是为了不让那些非active或者非univ样本影响到lgb对x的分箱，但实验下来发现用不用也没显著区别
                if mask_univ is not None:  
                    data_nonactive2nan = {}
                    for label, pattern_dicts in data.items():
                        if label.startswith("X"):  # 对X做这个操作即可，注意label是要按照X Y W开头这种模式写的
                            if isinstance(pattern_dicts, dict):
                                pattern_dicts = [pattern_dicts]
                            for pattern_dict in pattern_dicts:
                                pattern_dict["calc_f"] = partial(nonactive2nan, univ=mask_univ)  # FIXME: 如果这个pattern_dict本身就已经有了calc_f，这样是错的，TODO：得做出calc_f的嵌套
                            data_nonactive2nan[label] = pattern_dict
                    data.update(data_nonactive2nan)
                    print(data)

            for label, pattern_dicts in data.items():
                dump_shm(label=label, pattern_dicts=pattern_dicts, univ=univ, run_periods=run_periods, start_date=start_date, end_date=end_date, freq_m=freq_m, output_ii=output_ii, d_concat=d_concat, date_pattern=date_pattern,
                                para_spec=para_spec, dump_config_only=label in dump_config_only_list, rnode_root=rnode_root, chain_name=chain_name)
        return start_ends