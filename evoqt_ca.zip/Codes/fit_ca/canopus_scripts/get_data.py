import os
import copy
from pathlib import Path
# jobs这个库在qrlite，如果没有请注意看qrlite是否在自己的Python路径下
from jobs.rnodes.rnode import RNode, SlurmCfg
from canopus_py.rnodes.ca_node import CANode
# StatsNode是特征测试时使用
# from canopus_py.rnodes.stats_node import StatsNode
# ca对象在这里导入
from canopus_py.ca_expr import *
from canopus_py.ca_stats import *

from pattern_helper import *
from fit_ca.canopus_scripts.dump_shm import get_run_periods, UNIV

RNode.RNODE_ROOT = "/data/beef2/junming/"
RNode.GLOBAL_TASKNAME = "data"
CANode.DEFAULT_CA_BINARY = "/data/beef2/bin/unstable/canopus"

def get_base_config():
    base_config = CANode.base_config()
    base_config["EVENTS.market"] = "CNEQ"
    base_config["EVENTS.busdate_pattern"] = "/data/beef2/data/CA/CNEQ/Panels/Y/Y_240527/terms.YYYYMMDD.sdiv"
    base_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    base_config["OUTPUT.terms"] = True
    # base_config["OUTPUT.terms.output_ii"] = list(range(1,49,2))  # 每十分钟采样
    
    return copy.deepcopy(base_config)


def get_combined_terms(label, start_date:str=None, end_date:str=None):
    base_config = get_base_config()

    root_folder = "/data/beef2/mike/CA_terms_v24.0408/"
    file_pattern = "terms.YYYYMMDD.sdiv"
    all_terms = []
    for term_group in os.listdir(root_folder):
        term_name = term_group[:3]  # xxx_terms
        for term_batch in os.listdir(os.path.join(root_folder, term_group)):
            if term_group == "mpv_terms" and term_batch in ["000.ca.mpvd", "001.ca.mpvd"]:
                continue
            if term_group == "mms_terms" and term_batch in ["001.ca.mms_basic_reg_sv0.fix"]:
                continue  # 是001的fix
            batch_name = term_batch[:3]  # 001
            panel_name = f"{term_name}.{batch_name}"
            base_config[f"DATA.panels"] += [panel_name]
            pattern = os.path.join(root_folder, term_group, term_batch, file_pattern)
            base_config[f"DATA.{panel_name}.pattern"] = pattern
            terms = read_columns_from_pattern(pattern)
            base_config[f"DATA.{panel_name}.columns"] = terms
            renamed_terms = [f"{panel_name}.{term}" for term in terms]
            base_config[f"DATA.{panel_name}.column_masks"] = renamed_terms
            all_terms.extend(renamed_terms)

    assert len(all_terms) == len(set(all_terms)), "duplicated term names"
    print(f"Number of terms: {len(all_terms)}")

    node = CANode(base_config, label=label, clean_dir_name=True)
    # test_node.node_config["OUTPUT.terms.output_ii"] = list(range(1,49,2))  # 每十分钟采样
    for term in all_terms:
        node.node_config["CA.terms"][term] = ca.Na20(ca(term))

    node.set_run_dates()
    start_date = 0 if start_date is None else int(start_date)
    end_date = 30000000 if end_date is None else int(end_date)
    node.run_periods = [d for d in node.run_periods if d >= start_date and d <= end_date]
    node.run(para_spec=80)


def get_weight(start_date:str=None, end_date:str=None):
    base_config = get_base_config()

    file_pattern = "/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/BB/5min-YYYYMMDD.sdiv"
    base_config["EVENTS.busdate_pattern"] = file_pattern
    base_config["DATA.panels"] += ["5min"]
    base_config["DATA.5min.pattern"] = file_pattern

    weight_name = 'is.active'
    node = CANode(base_config, label=weight_name, clean_dir_name=True)
    # test_node.node_config["OUTPUT.terms.output_ii"] = list(range(1,49,2))  # 每十分钟采样
    node.node_config["CA.terms"]["wgt"] = ca.Na20(ca(weight_name))
    node.set_run_dates()
    start_date = 0 if start_date is None else int(start_date)
    end_date = 30000000 if end_date is None else int(end_date)
    node.run_periods = [d for d in node.run_periods if d >= start_date and d <= end_date]
    node.run(para_spec=80)

def get_univ_active(label='univ_active', start_date:str=None, end_date:str=None, active=True):
    base_config = get_base_config()

    CAv24Path = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels"
    file_pattern = os.path.join(CAv24Path, "I/fq5m/BB/terms.YYYYMMDD.sdiv")
    base_config["EVENTS.busdate_pattern"] = file_pattern
    base_config["DATA.panels"] += ["5min"]
    base_config["DATA.5min.pattern"] = file_pattern
    base_config["DATA.5min.columns"] = ['is.active']

    panel_name = "index"
    index_columns = ["sh50", "csi300", "csi500", "zz1000", "sci50"]
    base_config["DATA.panels"] += [panel_name]
    base_config[f"DATA.{panel_name}.pattern"] = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"
    base_config[f"DATA.{panel_name}.inclusive"] = False
    base_config[f"DATA.{panel_name}.columns"] = index_columns

    panel_name = "univ_x"
    x_columns = ["topx", "midx", "smlx", "botx"]
    base_config["DATA.panels"] += [panel_name]
    base_config[f"DATA.{panel_name}.pattern"] = "/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv"
    base_config[f"DATA.{panel_name}.inclusive"] = False
    base_config[f"DATA.{panel_name}.columns"] = x_columns

    univ_indicator = {}
    for univ in index_columns+x_columns:
        univ_indicator[univ] = ca.Sign(ca.Na20(univ))
    univ_indicator["csi800"] = ca.Sign(ca.Na20("csi300")) | ca.Sign(ca.Na20("csi500"))

    node = CANode(base_config, label=label, clean_dir_name=True)
    for univ, indicator in univ_indicator.items():
        if active:
            node.node_config["CA.terms"][univ] = ca.Na20(ca('is.active') * indicator)
        else:
            node.node_config["CA.terms"][univ] = indicator
    node.node_config["CA.terms"]['is.active'] = ca.Na20(ca('is.active'))

    node.set_run_dates()
    start_date = 0 if start_date is None else int(start_date)
    end_date = 30000000 if end_date is None else int(end_date)
    node.run_periods = [d for d in node.run_periods if d >= start_date and d <= end_date]
    node.run(para_spec=80)


def get_labels(label="label", start_date:str=None, end_date:str=None):
    # same as origin Y file except Na20
    base_config = get_base_config()

    file_pattern = "/data/beef2/data/CA/CNEQ/Panels/Y/Y_240527/terms.YYYYMMDD.sdiv"
    base_config["OUTPUT.terms"] = True
    base_config["DATA.panels"] += ["Y"]
    base_config["DATA.Y.pattern"] = file_pattern

    node = CANode(base_config, label=label, clean_dir_name=True)
    terms = read_columns_from_pattern(file_pattern)
    for term in terms:
        node.node_config["CA.terms"][term] = ca.Na20(ca(term))
    node.set_run_dates()
    start_date = 0 if start_date is None else int(start_date)
    end_date = 30000000 if end_date is None else int(end_date)
    node.run_periods = [d for d in node.run_periods if d >= start_date and d <= end_date]
    node.run(para_spec=80)


def get_combined_alphas(label, start_date:str=None, end_date:str=None):
    base_config = get_base_config()

    root_folder = "/data/beef2/junming/data/temp/batch_fit_croll"
    file_pattern = "yhat.YYYYMMDD.sdiv"
    all_terms = []
    for term_group in os.listdir(root_folder):
        
        panel_name = term_group
        base_config[f"DATA.panels"] += [panel_name]
        pattern = os.path.join(root_folder, term_group, file_pattern)
        base_config[f"DATA.{panel_name}.pattern"] = pattern

        terms = read_columns_from_pattern(pattern)
        base_config[f"DATA.{panel_name}.columns"] = terms
        renamed_terms = [f"{panel_name}.{term}" for term in terms]
        base_config[f"DATA.{panel_name}.column_masks"] = renamed_terms
        all_terms.append(f"{panel_name}.yhat")

    assert len(all_terms) == len(set(all_terms)), "duplicated term names"
    print(f"Number of terms: {len(all_terms)}")

    node = CANode(base_config, label=label, clean_dir_name=True)
    # test_node.node_config["OUTPUT.terms.output_ii"] = list(range(1,49,2))  # 每十分钟采样
    for term in all_terms:
        node.node_config["CA.terms"][term] = ca.Na20(ca(term))

    run_periods = get_run_periods(pattern=base_config["EVENTS.busdate_pattern"], start_date=start_date, end_date=end_date)
    node.run_periods = run_periods
    node.run(para_spec=80)


def feature_engineering(label="guopeng_pv", start_date:str=None, end_date:str=None):
    # same as origin Y file except Na20
    base_config = get_base_config()

    file_pattern = "/data/beef2/guopeng/pv_rroot/selected/terms.YYYYMMDD.sdiv"
    base_config["OUTPUT.terms"] = True
    base_config["DATA.panels"] += ["terms"]
    base_config["DATA.terms.pattern"] = file_pattern

    node = CANode(base_config, label=label, clean_dir_name=True)
    terms = read_columns_from_pattern(file_pattern)
    for term in terms:
        node.node_config["CA.terms"][term] = ca.XsZScore(ca.Na20(term))

    run_periods = get_run_periods(pattern=file_pattern, start_date=start_date, end_date=end_date)
    node.run_periods = run_periods
    node.run(para_spec=80)

def get_overnight_intraday_ret(label="oi_ret", start_date:str=None, end_date:str=None):
    base_config = get_base_config()

    file_pattern = "/data/beef2/data/CA/CNEQ/Panels/Y/Y_V5/YYYYMMDD.sdiv"
    base_config["OUTPUT.terms"] = True
    base_config["DATA.panels"] += ["Y"]
    base_config["DATA.Y.pattern"] = file_pattern

    node = CANode(base_config, label=label, clean_dir_name=True)
    # 原始24h
    mret24h, bret24h = ca.Na20(ca("mret24h")), ca.Na20(ca("bret24h"))
    bpret24h = mret24h - bret24h
    node.node_config["CA.terms"]["mret24h"] = mret24h
    node.node_config["CA.terms"]["bret24h"] = bret24h
    node.node_config["CA.terms"]["bpret24h"] = bpret24h
    # 当日日内
    mret_0itrd = ca.Na20(ca("mret0e"))
    bret_0itrd = ca.Na20(ca("bret0e"))
    bpret_0itrd = mret_0itrd - bret_0itrd
    node.node_config["CA.terms"]["mret_0itrd"] = mret_0itrd
    node.node_config["CA.terms"]["bret_0itrd"] = bret_0itrd
    node.node_config["CA.terms"]["bpret_0itrd"] = bpret_0itrd
    # 至次日开盘
    mret_1o = ca.Na20(ca("mret1o"))
    bret_1o = ca.Na20(ca("bret1o"))
    bpret_1o = mret_1o - bret_1o
    node.node_config["CA.terms"]["mret_1o"] = mret_1o
    node.node_config["CA.terms"]["bret_1o"] = bret_1o
    node.node_config["CA.terms"]["bpret_1o"] = bpret_1o
    # 当日隔夜
    mret_ovnt = mret_1o - mret_0itrd
    bret_ovnt = bret_1o - bret_0itrd
    bpret_ovnt = mret_ovnt - bret_ovnt
    node.node_config["CA.terms"]["mret_ovnt"] = mret_ovnt
    node.node_config["CA.terms"]["bret_ovnt"] = bret_ovnt
    node.node_config["CA.terms"]["bpret_ovnt"] = bpret_ovnt
    # 次日日内
    mret_1itrd = mret24h - mret_1o
    bret_1itrd = bret24h - bret_1o
    bpret_1itrd = mret_1itrd - bret_1itrd
    node.node_config["CA.terms"]["mret_1itrd"] = mret_1itrd
    node.node_config["CA.terms"]["bret_1itrd"] = bret_1itrd
    node.node_config["CA.terms"]["bpret_1itrd"] = bpret_1itrd
    # 日内相加
    node.node_config["CA.terms"]["mret_itrd"] = mret_0itrd + mret_1itrd
    node.node_config["CA.terms"]["bret_itrd"] = bret_0itrd + bret_1itrd
    node.node_config["CA.terms"]["bpret_itrd"] = bpret_0itrd + bpret_1itrd
    # 24h回归隔夜取残差
    node.node_config["CA.terms"]["mret_ovnt_res"] = ca.RegRes(mret24h, mret_ovnt)
    node.node_config["CA.terms"]["bret_ovnt_res"] = ca.RegRes(bret24h, bret_ovnt)
    node.node_config["CA.terms"]["bpret_ovnt_res"] = ca.RegRes(bpret24h, bpret_ovnt)
    # 24h回归日内取残差
    node.node_config["CA.terms"]["mret_itrd_res"] = ca.RegRes(mret24h, mret_0itrd + mret_1itrd)
    node.node_config["CA.terms"]["bret_itrd_res"] = ca.RegRes(bret24h, bret_0itrd + bret_1itrd)
    node.node_config["CA.terms"]["bpret_itrd_res"] = ca.RegRes(bpret24h, bpret_0itrd + bpret_1itrd)
    # 1e-1o, 方差恒定
    mret_1e = ca.Na20(ca("mret1e"))
    bret_1e = ca.Na20(ca("bret1e"))
    bpret_1e = mret_1e - bret_1e
    node.node_config["CA.terms"]["mret_1e1o"] = mret_1e - mret_1o
    node.node_config["CA.terms"]["bret_1e1o"] = bret_1e - bret_1o
    node.node_config["CA.terms"]["bpret_1e1o"] = bpret_1e - bpret_1o

    node.set_run_dates()
    run_periods = get_run_periods(pattern=file_pattern, start_date=start_date, end_date=end_date)
    node.run_periods = run_periods
    node.run(para_spec=40)

def get_tradevol_imbalance(label, start_date:str=None, end_date:str=None):
    rnode_root = "/data/beef2/junming/"
    chain_name = "data"

    base_config = CANode.base_config()
    ca_node = CANode(base_config, label=label, clean_dir_name=True, rnode_root=rnode_root, chain_name=chain_name)
    ca_node.node_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    # ca_node.node_config["CA.univ"] = "1"
    file_pattern = "/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/BB/5min-YYYYMMDD.sdiv"
    ca_node.node_config["EVENTS.busdate_pattern"] = file_pattern
    ca_node.node_config["DATA.panels"] += ["5min"]
    ca_node.node_config["DATA.5min.pattern"] = "/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/BB/5min-YYYYMMDD.sdiv"
    # ca_node.node_config["DATA.5min.columns"] = ["backward.ret5m", "is.active"]
    ca_node.node_config["DATA.5min.lb_days"] = 1
    ca_node.node_config["DATA.panels"] += ["D1RS"]
    ca_node.node_config["DATA.D1RS.pattern"] = "/data/beef2/data/CA/CNEQ/Panels/D/eod/D1RS/daily-rollstats-YYYYMMDD.sdiv"
    ca_node.node_config["DATA.D1RS.lb_days"] = 1
    ca_node.node_config["OUTPUT.terms"] = True
    vb = ca.Na20("buyNotl")
    vs = ca.Na20("sellNotl")
    itrd_ret24h = ca.TsSum(ca.Na20("backward.ret5m")*(~ca.IsFirstII()), 48, rpii=1)
    vb24h = ca.TsSum(vb, 48, rpii=1)
    vs24h = ca.TsSum(vs, 48, rpii=1)
    tvr = ca.Na20("turnover.rw22")
    # ca_node.node_config["CA.terms"]["turnover.rw22"] = tvr
    # ca_node.node_config["CA.terms"]["sign_vol"] = vb-vs
    # ca_node.node_config["CA.terms"]["itrd_ret24h"] = itrd_ret24h
    sign_vol_24h = (ca.Log(vb24h+ca.C(1))-ca.Log(vs24h+ca.C(1)))*(ca.Log((vb24h+vs24h)/tvr+ca.C(1)))
    ca_node.node_config["CA.terms"]["sign_vol_24h"] = sign_vol_24h
    ca_node.node_config["CA.terms"]["sign_vol_24h.zs"] = ca.XsZScore(sign_vol_24h)
    sign_vol_24h_v2 = ca.Log(vb24h+ca.C(1))-ca.Log(vs24h+ca.C(1))
    ca_node.node_config["CA.terms"]["sign_vol_24h_v2"] = sign_vol_24h_v2
    ca_node.node_config["CA.terms"]["sign_vol_24h_v2.zs"] = ca.XsZScore(sign_vol_24h_v2)

    ca_node.set_run_dates()
    run_periods = get_run_periods(pattern=file_pattern, start_date=start_date, end_date=end_date)
    ca_node.run_periods = run_periods
    ca_node.run(para_spec=40)

def get_combined_subalphas(label, subalpha_panels_folder, start_date:str=None, end_date:str=None, output_ii=None):
    base_config = get_base_config()

    subalpha_panels_folder = os.path.join("/data/beef2/junming/croll_alpha", subalpha_panels_folder)
    file_pattern = "yhat.YYYYMMDD.sdiv"
    yhat_name = "yhat"
    all_terms = []
    for subalpha_panel in os.listdir(subalpha_panels_folder):  # e.g. m3_oi，里面有多个fit folder，每一个对应一个alpha，比如fit不同y
        for alpha_name in os.listdir(os.path.join(subalpha_panels_folder, subalpha_panel)):
            panel_name = f"{subalpha_panel}.{alpha_name}"
            base_config[f"DATA.panels"] += [panel_name]
            pattern = os.path.join(subalpha_panels_folder, subalpha_panel, alpha_name, file_pattern)
            base_config[f"DATA.{panel_name}.pattern"] = pattern
            base_config[f"DATA.{panel_name}.columns"] = [yhat_name]
            yhat_rename = f"{subalpha_panel}.{alpha_name}"
            base_config[f"DATA.{panel_name}.column_masks"] = [yhat_rename]
            all_terms.extend([yhat_rename])

    assert len(all_terms) == len(set(all_terms)), "duplicated term names"
    print(f"Number of terms: {len(all_terms)}")

    rnode_root = "/data/beef2/junming/"
    chain_name = "croll_alpha"

    node = CANode(base_config, label=label, clean_dir_name=True, rnode_root=rnode_root, chain_name=chain_name)
    # test_node.node_config["OUTPUT.terms.output_ii"] = list(range(1,49,2))  # 每十分钟采样
    for term in all_terms:
        node.node_config["CA.terms"][term] = ca.Na20(ca(term))
    if output_ii is not None:
        node.node_config["OUTPUT.terms.output_ii"] = output_ii  # downsample

    node.set_run_dates()
    run_periods = get_run_periods(pattern=node.node_config["EVENTS.busdate_pattern"], start_date=start_date, end_date=end_date)
    node.run_periods = run_periods
    node.run(para_spec=80)

def downsample_1min_to_5min(save_folder, start_date:str='20180101', end_date:str='20240729'):
    node_config = CANode.base_config()
    node_config["EVENTS.busdate_pattern"] = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"
    node_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    node_config["OUTPUT.terms"] = True
    
    folder = "/data/bees3/mike/shared/CAPQ_1m_241001"
    batches = os.listdir(folder)
    pattern = [os.path.join(folder, batch, "terms.YYYYMMDD.sdiv") for batch in batches]
    # from online202409 import terms
    # from qrfitter3.utils import save_df_as_sdiv_daily, read_json, save_json
    # all_features = read_json("/data/bees1/unsafe/junming/equity_fitting/online202409/tree_model/tree_u_mret24h_overallimp1500/fit.0/feature_names.json")
    # pattern = terms.tree_all_u

    all_terms = []
    for i, patt in enumerate(pattern):
        all_terms.extend(read_columns_from_pattern(patt))
    name_conflict = (len(all_terms) > len(set(all_terms)))
    if name_conflict:
        raise ValueError("NAME CONFLICT")
    
    for i, patt in enumerate(pattern):
        panel_name = f"batch{i}"
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = patt

    for term in all_terms:
        node_config["CA.terms"][term] = ca(term)
    # for term in all_features:
    #     node_config["CA.terms"][term] = ca.Na20(ca.XsZScore(ca(term)))

    folder_split = save_folder.rstrip("/").split('/')
    node = CANode(node_config, rnode_root='/'.join(folder_split[:-2]), chain_name=folder_split[-2], label=folder_split[-1], clean_dir_name=True)
    node.set_run_dates()
    run_periods = get_run_periods(pattern=node.node_config["EVENTS.busdate_pattern"], start_date=start_date, end_date=end_date)
    node.run_periods = run_periods
    node.run(para_spec=80)


def upsample_bod_to_5min(save_folder, start_date:str='20180101', end_date:str='20240729'):
    node_config = CANode.base_config()
    node_config["EVENTS.busdate_pattern"] = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"
    node_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    node_config["OUTPUT.terms"] = True
    
    pattern = ["/data/beef3/guopeng/research/daily_fea/fea_stats/000.ca.fea_stats/terms.YYYYMMDD.sdiv"]

    all_terms = []
    for i, patt in enumerate(pattern):
        all_terms.extend(read_columns_from_pattern(patt))
    name_conflict = (len(all_terms) > len(set(all_terms)))
    if name_conflict:
        raise ValueError("NAME CONFLICT")
    
    for i, patt in enumerate(pattern):
        panel_name = f"batch{i}"
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = patt
        node_config[f"DATA.{panel_name}.inclusive"] = True  # 今天可用

    for term in all_terms:
        node_config["CA.terms"][term] = ca(term)

    folder_split = save_folder.rstrip("/").split('/')
    node = CANode(node_config, rnode_root='/'.join(folder_split[:-2]), chain_name=folder_split[-2], label=folder_split[-1], clean_dir_name=True)
    node.set_run_dates()
    run_periods = get_run_periods(pattern=node.node_config["EVENTS.busdate_pattern"], start_date=start_date, end_date=end_date)
    node.run_periods = run_periods
    node.run(para_spec=80)

if __name__ == "__main__":
    #get_combined_terms(label='combine1999')  # it is normal to see some failed jobs, which is due to miss dates in some terms
    #get_combined_alphas(label="combine82batch")
    # feature_engineering()
    # get_overnight_intraday_ret(start_date="20180101", end_date="20231231")

    # configs = [
    #     {"output_ii": list(range(1,49,2)), "start_date": "20180501", "end_date": "20221231"},  # 每十分钟采样, is  
    #     {"output_ii": None, "start_date": "20230101", "end_date": "20231013"}  # 不downsample, oos
    # ]
    # for config in configs:
    #     get_combined_subalphas(label='subalpha20240715', subalpha_panels_folder="subalpha20240715_panels", **config)

    # get_tradevol_imbalance(label='tradevol_imbalance')
    # get_index_active(label='index_component', start_date="20180101", end_date="20240731", active=False)
    # get_univ_active(label='univ_active', start_date="20180101", end_date="20240731", active=True)
    downsample_1min_to_5min(save_folder="/data/beef2/junming/data/CAPQ_1m_241001_5min", start_date="20231212", end_date='20231212')
    # upsample_bod_to_5min(save_folder="/data/beef2/junming/data/daily_fea", start_date='20170101', end_date='20240729')