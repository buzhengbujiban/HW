import os
import shutil
from concurrent.futures import ThreadPoolExecutor
from tqdm import tqdm
import time
import re
from qrfitter3.utils import read_json, save_json
import sys
from fit_ca.utils import *


def copy_directory(src_dir, dest_dir, max_workers=16):
    "将scr_dir文件夹中的每个文件copy到dest_dir文件夹"
    os.makedirs(dest_dir, exist_ok=True)

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        for item in os.listdir(src_dir):
            src_path = os.path.join(src_dir, item)
            dest_path = os.path.join(dest_dir, item)
            if os.path.isfile(src_path):
                executor.submit(shutil.copy2, src_path, dest_path)
            else:
                raise ValueError(f"{src_path} should be a file")


def copy_fit(fit_folder, dest_dir, sub_folder="y_hat_test"):
    log = {
        "fit_folder": fit_folder,
        "sub_folder": sub_folder,
    }
    "将一个fit folder中的(各个roll的)y_hat_test中的YYYYMMDD.sdiv复制到dest_dir文件夹"
    if "roll_tasks.csv" in os.listdir(fit_folder):
        roll_ids = [folder for folder in os.listdir(fit_folder) if folder.startswith("roll.")]
        for roll_id in roll_ids:
            src_dir = os.path.join(fit_folder, roll_id, sub_folder)
            copy_directory(src_dir, dest_dir)
    else:
        src_dir = os.path.join(fit_folder, sub_folder)
        copy_directory(src_dir, dest_dir)
    save_json(log, os.path.join(dest_dir, "log.json"))
    
    # fit_folder = "/data/bees1/safe/junming/equity_fitting/expt_res/mlp_baseline_croll_inference/fit.main"
    # dest_dir = '/data/beef2/junming/alpha/baseline_croll_inference'
    # copy_fit(fit_folder, dest_dir)
    # fit_folder = "/data/bees1/safe/junming/equity_fitting/expt_res/mlp_croll_inference2023hidden/fit.main"
    # dest_dir = '/data/beef2/junming/data/mlp_croll_inference2023hidden/hidden'
    # copy_fit(fit_folder, dest_dir, sub_folder="y_hat_inference_hidden")


def copy_batch_fit_croll(expt_folder, dest_dir):
    "copy croll也就是2018-2022的croll test"
    scenarios = read_json(os.path.join(expt_folder, "scenarios.json"))
    for i, (fit_id, scenario) in tqdm(enumerate(scenarios.items())):
        x_file = scenario["dataset"]["x_files"][0]
        pattern = r'/dev/shm/YYYYMMDD\.(.*)\.sdiv'
        batch_name = re.search(pattern, x_file).group(1)
        fit_folder = os.path.join(expt_folder, fit_id)
        dest_dir_fit = os.path.join(dest_dir, batch_name)
        copy_fit(fit_folder, dest_dir_fit)
        
    # expt_folder = "/data/bees1/safe/junming/equity_fitting/expt_res/batch_fit/mlp_croll_82"
    # dest_dir = "/data/beef2/junming/data/temp/batch_fit_croll"
    # copy_batch_fit_croll(expt_folder, dest_dir)


def copy_batch_fit_2023_yhat(expt_folder, dest_dir, roll_id='roll.3'):
    scenarios = read_json(os.path.join(expt_folder, "scenarios.json"))
    for i, (fit_id, scenario) in tqdm(enumerate(scenarios.items())):
        x_file = scenario["dataset"]["x_files"][0]
        pattern = r'/dev/shm/YYYYMMDD\.(.*)\.sdiv'
        batch_name = re.search(pattern, x_file).group(1)
        src_dir = os.path.join(expt_folder, fit_id, roll_id, "y_hat_inference")
        dest_dir_fit = os.path.join(dest_dir, batch_name)
        copy_directory(src_dir, dest_dir_fit)

    # expt_folder = "/data/bees1/safe/junming/equity_fitting/expt_res/batch_fit/mlp_croll_40"
    # dest_dir = "/data/beef2/junming/data/temp/batch_fit_2023_single_yhat"
    # copy_batch_fit_2023_yhat(expt_folder, dest_dir)

def copy_supp_date_terms(supp_dir, origin_dir):
    for group in os.listdir(supp_dir):
        for batch in os.listdir(os.path.join(supp_dir, group)):
            src_dir = os.path.join(supp_dir, group, batch)
            dest_dir = os.path.join(origin_dir, group, batch)
            copy_directory(src_dir, dest_dir)

    # supp_dir = "/data/beef2/mike/CA_terms_v24.0408.supp"
    # origin_dir = "/data/beef2/mike/CA_terms_v24.0408"
    # copy_supp_date_terms(supp_dir, origin_dir)

def combine():
    supp_dir = "/data/beef2/junming/data/temp/batch_fit_2023_single_yhat"
    origin_dir = "/data/beef2/junming/data/temp/batch_fit_croll"
    for group_batch in os.listdir(supp_dir):
        src_dir = os.path.join(supp_dir, group_batch)
        dest_dir = os.path.join(origin_dir, group_batch)
        copy_directory(src_dir, dest_dir)

if __name__ == "__main__":
    # fit_map = dict(zip([f"fit.{i}" for i in range(3)], ["mret", "bret", "bpret"]))
    fit_map = dict(zip([f"fit.{i}" for i in range(3)], ["base", "add", "cofit"]))
    expt_folder = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/alpha_combine/mike1999_chunxiaoex_select2_mlp3_RR"
    out_folder = "/data/beef2/junming/alpha/chunxiao_ex2"
    fit_ids = [folder.replace("main", "-1") for folder in os.listdir(expt_folder) if folder.startswith("fit.")]
    for fit_id in fit_ids:
        fit_folder = os.path.join(expt_folder, fit_id)
        dest_dir = os.path.join(out_folder, fit_map[fit_id])
        for set_name in ["train", "valid", "test"]:
            copy_fit(fit_folder, dest_dir, sub_folder=f"y_hat_{set_name}")


    # 以下代码用于拷贝多个subalpha croll fit yhats
    # t0 = time.time()
    # subalpha_folder = "/data/beef2/junming/croll_alpha/subalpha20240715_panels"
    # croll_folder = "/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/croll"
    # expt_names = {
    #     "m3_magic": "mlp3_fit_magic",
    # }
    # for rename, expt_name in expt_names.items():
    #     expt_folder = os.path.join(croll_folder, expt_name)
    #     paras = get_paras(expt_folder)
    #     fit_ids = [folder.replace("main", "-1") for folder in os.listdir(expt_folder) if folder.startswith("fit.")]
    #     for fit_id in fit_ids:
    #         alpha_name = paras.loc[fit_id, 'fit_y']  # TODO：注意不一定所有alpha_name都是这样
    #         fit_folder = os.path.join(expt_folder, fit_id)
    #         dest_dir = os.path.join(subalpha_folder, rename, alpha_name)
    #         copy_fit(fit_folder, dest_dir, sub_folder="y_hat_test")
    # t1 = time.time()
    # print(f"consumed: {t1-t0:.0f} sec")


    # 以下代码是用于拷贝autoencoder的croll
    # map_dict = {
    #     "fit.0": "bottleneck100",
    #     "fit.1": "bottleneck200",
    #     "fit.2": "bottleneck400",
    # }
    # d = {
    #     "residual_test": "residual",
    #     "encoded_test": "bottleneck"
    # }
    # for fit_id, bottleneck in map_dict.items():
    #     fit_folder = f"/data/bees1/safe/junming/equity_fitting/expt_res_exclude202002/autoencoder/croll_inference_100_200_400/{fit_id}"
    #     for src, dest in d.items():
    #         dest_dir = f'/data/bees1/safe/junming/equity_fitting/data/ae_croll_exclude202002/{bottleneck}/{dest}/'
    #         copy_fit(fit_folder, dest_dir, sub_folder=src)