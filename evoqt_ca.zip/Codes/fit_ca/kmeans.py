from riskmodels.small_univ import *
@lru_cache(maxsize=256)
def get_trade_date(start_date=None, end_date=None):
    """
    获取交易日。
    - start_date: str, datetime64[ns], 开始日期
    - end_date: str, datetime64[ns], 结束日期
    - return: pd.DatetimeIndex
    """
    if start_date is None and end_date is None:
        return all_trade_date
    else:
        if start_date is None:
            return all_trade_date[all_trade_date<=pd.to_datetime(end_date)]
        if end_date is None:
            return all_trade_date[pd.to_datetime(start_date)<=all_trade_date]
        return all_trade_date[(pd.to_datetime(start_date)<=all_trade_date)&(all_trade_date<=pd.to_datetime(end_date))]
def get_panel_data(
        panel_name, sub_name=None, 
        start_date=None, end_date=None, 
        to_dataframe=False, fields=None, 
        n_jobs=64, to_datetime=True, panel_path=panel_path, split='-'):
    """
    获取panel数据。
    - table_name: str, 所取表格名称
    - sub_name: str or None, 子表格的名称
    - start_date: str, datetime64[ns], 开始日期
    - end_date: str, datetime64[ns], 结束日期
    - to_dataframe: bool, 是否转化为pd.DataFrame
    - fields: str, list[str], None, 需要提取的字段
    - n_jobs: int, 并行数量
    - return: DataArray or pd.DataFrame
    """
    if sub_name is None:
        sub_name1 = panel_name
    else:
        sub_name1 = sub_name
    trade_date = get_trade_date(start_date=start_date, end_date=end_date)
    data = Parallel(n_jobs)(
            delayed(get_one_date_data)(
                panel_name, td, sub_name, fields=fields, panel_path=panel_path, split=split) 
            for td in tqdm.tqdm(trade_date, desc=f'fetching {panel_name}/{sub_name1}-*.sidv'))
    if to_dataframe:
        data =pd.concat([panel.sdiv2df(_data) for _data in tqdm.tqdm(data, desc='sdiv2df')])
        if to_datetime:
            data['datetime'] = pd.to_datetime(data['date'] + ' ' + data['time'])
            data = data.drop(columns=['date', 'time'])
        return data
    else:
        return panel.concat(data, 'D')
def get_barra_exp(start_date=None, end_date=None, to_dataframe=False, fields=None, to_datetime=True):
    """
    获取barra因子暴露数据
    - start_date: str, datetime64[ns], 开始日期
    - end_date: str, datetime64[ns], 结束日期
    - to_dataframe: bool, 是否转化为pd.DataFrame
    - fields: str, list[str], None, 需要提取的字段
    - return: DataArray or pd.DataFrame
    """
    return get_panel_data(
        'barra', 'exp', start_date=start_date, end_date=end_date, 
        to_dataframe=to_dataframe, fields=fields, 
        to_datetime=to_datetime, 
        )
def get_barra_mean(start_date, end_date, univ=universe):
    all_exp = get_barra_exp(start_date, end_date)
    all_exp = all_exp.loc[list(set(all_exp.coords['S'].data)&set(univ)), :, :, :]
    exp = all_exp.mean(dim='D').squeeze().to_pandas()
    return exp
exp = get_barra_mean('2018-01-01', '2022-12-31', )
kmeans = KMeans(5)
pred0 = pd.Series(kmeans.fit_predict(exp), index=exp.index, name='cls').reset_index()
for c, sid in pred0.groupby('cls'):
    with open(f'/home/guopeng/git/guopeng/small_univ/K=5/small_univ_{c}.txt', 'w', encoding='u8') as f:
        sid = sid['S'].astype(int).sort_values().astype(str)
        # sid = sid.sort_values(by='S')
        f.write('sid\n')
        [f.write(s+'\n') for s in sid]