import os
import json
import itertools
import copy

from qrfitter3.roller import Roller
from qrfitter3.utils import make_dir, write_lines, read_json, save_json

def extract_lists(d, path=None):
    if path is None:
        path = []

    items = []
    for k, v in d.items():
        new_path = path + [k]
        if isinstance(v, dict):
            items.extend(extract_lists(v, new_path))
        elif isinstance(v, list):
            items.append((new_path, v))
        else:
            raise TypeError(f"Expect dict or list, got {type(v)}")
    return items

def set_value(d, keys, value):
    for key in keys[:-1]:
        d = d[key]
    d[keys[-1]] = value

def generate_combinations_fromgrid(grid_tasks):
    all_lists = extract_lists(grid_tasks)
    all_keys = [item[0] for item in all_lists]
    all_paras = [item[1] for item in all_lists]
    all_combinations = list(itertools.product(*all_paras))
    
    resulting_dicts = []
    for combination in all_combinations:
        task_copy = copy.deepcopy(grid_tasks)
        for keys, value in zip(all_keys, combination):
            set_value(task_copy, keys, value)
        resulting_dicts.append(task_copy)

    return resulting_dicts

def update_dict(origin: dict, update: dict):
    for key, value in update.items():
        if isinstance(value, dict) and key in origin:
            update_dict(origin[key], value)
        else:
            origin[key] = value

def generate_combinations(cfg):
    grid_tasks = cfg.pop("grid_tasks", [])
    extra_tasks = cfg.pop("extra_tasks", [])
    
    combinations = []
    if grid_tasks:
        combinations_fromgrid = generate_combinations_fromgrid(grid_tasks)
        combinations.extend(combinations_fromgrid)
    combinations.extend(extra_tasks)
    
    all_cfgs = []
    for combination in combinations:
        new_cfg = copy.deepcopy(cfg)
        update_dict(origin=new_cfg, update=combination)
        all_cfgs.append(new_cfg)
    
    scenarios = [f"fit.{i}" for i in range(len(combinations))]
    if not grid_tasks and not extra_tasks:  # 如果这俩都没有才跑原cfg
        all_cfgs.insert(0, cfg)
        scenarios.insert(0, "fit.0")
        combinations.insert(0, {})
    scenarios = dict(zip(scenarios, combinations))

    return all_cfgs, scenarios


def gen_fitting_tasks(
    fitting_cfg,
    gpus:list[str]=None,
    task_option="", workspace_dir=None
):
    # setup outdir and files
    if workspace_dir is None:
        fitting_name = fitting_cfg['fitting_name']
        out_root = os.path.join(fitting_cfg['fitting_root_dir'], fitting_name)
    else:
        out_root = str(workspace_dir)
        
    fit_jobs_file = os.path.join(out_root, 'all_fit_jobs.sh')

    all_fitting_paras, scenarios = generate_combinations(fitting_cfg)
    scenario_file = os.path.join(out_root, 'scenarios.json')
    save_json(scenarios, scenario_file)
    os.chmod(scenario_file, 0o700)
    print(f'fitting scenario file written to: {scenario_file}')

    # generate task json cfg one by one
    fit_tasks_jsons = []
    # FOREACH parameter
    for fit_id, fitting_para in zip(scenarios.keys(), all_fitting_paras):
        this_fit_folder = os.path.join(out_root, fit_id)
        make_dir(this_fit_folder)
        
        if "roller" in fitting_para:
            roll_tasks_file = os.path.join(this_fit_folder, 'roll_tasks.csv')
            roll_tasks_lines = ['task,train_start,train_end,valid_start,valid_end,test_start,test_end']
            roller_cfg = fitting_para.pop('roller')
            roller = Roller(roller_cfg)
            # FOREACH train-valid-test split
            for fold_tuple in roller.iter():
                fold_id, fold_name, train_range, valid_range, test_range = fold_tuple
                this_fold_folder = os.path.join(this_fit_folder, "roll.{}".format(fold_id))
                make_dir(this_fold_folder)
                if isinstance(train_range, tuple):
                    train_period = {"start_date": train_range[0], "end_date": train_range[1]}
                else:
                    train_period = train_range  # should be a list of dates
                task = {
                    'outdir': this_fold_folder,
                    'train': train_period,
                    'valid': {"start_date": valid_range[0], "end_date": valid_range[1]},
                    'test': {"start_date": test_range[0], "end_date": test_range[1]},               
                }
                fitting_para_task = copy.deepcopy(fitting_para)
                fitting_para_task['task'] = task
                if "fitting_name" not in fitting_para_task:
                    fitting_para_task["fitting_name"] = f"fit.{fit_id}"
                if gpus is not None:  # gpus to use are specified
                    task_idx = len(fit_tasks_jsons)
                    gpu_idx = task_idx % len(gpus)
                    device_id = gpus[gpu_idx]
                    fitting_para_task["fitter"]["device_id"] = device_id

                out_fit_job_file = os.path.join(this_fold_folder, 'fit_task_cfg.json')
                save_json(fitting_para_task, out_fit_job_file)
                os.chmod(out_fit_job_file, 0o700)
                print(f'generated fit task file: {out_fit_job_file}')
                fit_tasks_jsons.append(out_fit_job_file)
                roll_tasks_lines.append('%d,%s,%s,%s,%s,%s,%s' % (fold_id,
                                                        train_range[0] if isinstance(train_range, tuple) else "na",
                                                        train_range[1] if isinstance(train_range, tuple) else "na",
                                                        valid_range[0] if valid_range is not None else 'NA',
                                                        valid_range[1] if valid_range is not None else 'NA',
                                                        test_range[0] if test_range is not None else 'NA',
                                                        test_range[1] if test_range is not None else 'NA'
                                                        ))
            write_lines(roll_tasks_file, roll_tasks_lines)
            print(f'fit_id={fit_id} tasks written to: {roll_tasks_file}')
        else:  # task is specified directly
            fitting_para['task']['outdir'] = this_fit_folder
            if gpus is not None:  # gpus to use are specified
                task_idx = len(fit_tasks_jsons)
                gpu_idx = task_idx % len(gpus)
                device_id = gpus[gpu_idx]
                fitting_para["fitter"]["device_id"] = device_id
            out_fit_job_file = os.path.join(this_fit_folder, 'fit_task_cfg.json')
            save_json(fitting_para, out_fit_job_file)
            os.chmod(out_fit_job_file, 0o700)
            print(f'generated fit task file: {out_fit_job_file}')
            fit_tasks_jsons.append(out_fit_job_file)

    with open(fit_jobs_file, 'w') as out_file:
        for task_json in fit_tasks_jsons:
            cmd_line = f"python /data/nfshome/{os.environ['USER']}/git/qrfitter3/qrfitter3/apps/run_fit_task.py {task_json} {task_option}"
            out_file.write(cmd_line)
            out_file.write('\n')
    print ('fitting jobs file written to: %s' % fit_jobs_file)
    os.chmod(fit_jobs_file, 0o700)

    print ('DONE with gen_fitting_tasks.')
    return out_root, fit_jobs_file, len(fit_tasks_jsons)