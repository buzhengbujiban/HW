import os, json, sys
import logging
import numpy as np
import pandas as pd
from typing import Dict, List
import gc
from joblib import Parallel, delayed

import qr
import qr_utils
from modelflow.block import dates_from
from ds_utils import load_dataset, calc_stats, pad_df_oneday, save_processed_data_oneday # type: ignore
from rolling_norm_ds import norm_oneday # type: ignore


def calc_train_stats(dirname, filename, date_start, date_end, x_names:List[str], x_q=0.9999):
    df_train = load_dataset(dirname, filename, date_start=date_start, date_end=date_end, threads=8)
    print(qr.cpu_mem_usage("finish loading df_train"))
    x_array = df_train[x_names].values
    print(qr.cpu_mem_usage("finish getting x_array"))
    del df_train
    gc.collect()
    print(qr.cpu_mem_usage("finish deleting df_train"))
    stats = calc_stats(x_array, x_names, q=x_q)
    print(qr.cpu_mem_usage("finish calc stats"))
    return stats


def process_data_oneday(dirname, filename, date, x_names, label_name, stats, y_thre, pad_num, y_names, save_folder):
    df, y_names_added = norm_oneday(dirname, filename, date, x_names, label_name, stats, y_thre)
    y_names = y_names + y_names_added
    if pad_num > 0:
        df = pad_df_oneday(df, pad_num)
    save_processed_data_oneday(df, x_names, y_names, save_folder)


def process_data(
    dirname: str, filename: str, date_start: str, date_end: str,
    x_names: List[str], label_name: str, stats: pd.DataFrame, y_thre: float,
    pad_num: int, y_names: List[str], save_folder: str, threads=16, filepattern=None
):
    print(qr.cpu_mem_usage("Processing data......"))
    if filepattern is None:
        filepattern = '{dirname}/{date}/{filename}'
    filepattern = filepattern.format(dirname=dirname,filename=filename,date='{date}')
    date_list = dates_from(filepattern, date_start=date_start, date_end=date_end)
    print(f"data from {dirname}\nto {save_folder}\n from {date_start} to {date_end}")
    if threads == 1:
        results = [process_data_oneday(
            dirname, filename, date, x_names, label_name, stats, y_thre, pad_num, y_names, save_folder
        ) for date in date_list]
    else:
        results = Parallel(n_jobs=min(threads, len(date_list)), verbose=1)(delayed(process_data_oneday)(
            dirname, filename, date, x_names, label_name, stats, y_thre, pad_num, y_names, save_folder
        ) for date in date_list)
    print(qr.cpu_mem_usage("Finish processing......"))


if __name__ == '__main__':
    dateset_dir = '/data/bees1/safe/junming/padl/dataset'
    processeddata_dir = '/data/bees1/safe/junming/padl/processed_data/'
    n_jobs = 16

    with open(os.path.join('/data/bees1/safe/junming/padl', 'column_group.json'), 'r') as f:
        column_group = json.load(f)
    feature = "feature_all"
    x_names = column_group[feature]
    y_names = column_group['fret']
    misc = ['gid', 'date', 'rec_epoch', 'X.wgtls']
    columns_need = misc + x_names + y_names
    label_name = 'ret300.1s'

    # 1. load dataset
    dataset_name = 'feature_all_20190801-20240409_7.5s'
    dirname = os.path.join(dateset_dir, dataset_name)
    filename = 'dataset.tbl'
    task = ['20200301', '20211231', '20220101', '20220430']
    processed_name = f'{feature}_traintestnorm_{task[0]}-{task[1]}_{task[2]}-{task[3]}_7.5s'
    save_folder = os.path.join(processeddata_dir, processed_name)
    os.makedirs(save_folder, exist_ok=True)
    
    x_q = 0.9999
    y_thre = 0.03
    pad_num = 100
    stats = calc_train_stats(dirname=dirname, filename=filename, date_start=task[0], date_end=task[1], x_names=x_names, x_q=x_q)
    stats.to_parquet(os.path.join(save_folder, 'stats.parquet'))
    process_data(
        dirname=dirname, filename=filename, date_start=task[0], date_end=task[-1],
        x_names=x_names, label_name=label_name, stats=stats, y_thre=y_thre,
        pad_num=pad_num, y_names=y_names, save_folder=save_folder, threads=16, filepattern=None
    )