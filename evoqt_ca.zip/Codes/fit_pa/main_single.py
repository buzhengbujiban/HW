import os
from nnfitter.utils import read_json
from nnfitter import learner as learner_module
import qr
qr.sdiv2_read
if __name__ == '__main__':
    current_folder = os.path.dirname(os.path.realpath(__file__))
    config_path = os.path.join(current_folder, 'config.json')

    config = read_json(config_path)
    learner = getattr(learner_module, config["learner_class"])(config)
    learner.run()