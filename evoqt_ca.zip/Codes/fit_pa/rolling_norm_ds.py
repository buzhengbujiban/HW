import os, json
import re
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple
import gc
from joblib import Parallel, delayed

import qr
import qr_utils
from file_utils.provider import dates_from
from ds_utils import load_dataset, calc_stats, pad_df_oneday, save_processed_data_oneday # type: ignore


def get_rolling_stats(dirname, filename, date, window, x_names, x_q):
    date_start = qr.bd.prev_date(date, nday=window)
    date_end = qr.bd.prev_date(date, nday=1)
    df_fit = load_dataset(dirname, filename, date_start, date_end, min_dates=window, threads=1)
    if df_fit.empty:  # 往前回看的window没有数据
        return pd.DataFrame()
    x_array = df_fit[x_names].values
    stats = calc_stats(x_array, x_names, q=x_q)
    return stats

def norm_oneday(dirname, filename, date, x_names, label_name, stats, y_thre):
    df_transform = load_dataset(dirname, filename, date, date, threads=1)
    m, s, l, u = stats['mean'], stats['std'], stats['lower'], stats['upper']
    # preprocess x
    df_transform[x_names] = df_transform[x_names].clip(lower=l, upper=u, axis=1)
    df_transform[x_names] = (df_transform[x_names] - m) / s
    df_transform[x_names] = df_transform[x_names].replace([np.nan], 0)
    # preprocess y
    fit_y = df_transform[label_name].clip(lower=-y_thre, upper=y_thre).replace([np.inf, -np.inf, np.nan], 0)  # 加个train后缀以区分训练y和原始y
    fit_y = fit_y.astype(df_transform[label_name].dtype).to_frame(f'{label_name}_fit')
    df_transform = pd.concat([df_transform, fit_y], axis=1)
    y_names_added = [f'{label_name}_fit']
    # just to avoid warning PerformanceWarning: DataFrame is highly fragmented
    # at df_transform[f'{label_name}_fit'] = df_transform[label_name].clip(lower=-y_thre, upper=y_thre).replace([np.inf, -np.inf, np.nan], 0)
    return df_transform, y_names_added

def rolling_norm_oneday(dirname, filename, date, window, x_names, label_name, x_q, y_thre) -> Tuple[pd.DataFrame, List[str]]:
    stats = get_rolling_stats(dirname, filename, date, window, x_names, x_q)  # 获取前window天的stats
    if stats.empty:
        return pd.DataFrame(), []
    df_transform, y_names_added = norm_oneday(dirname, filename, date, x_names, label_name, stats, y_thre)  # 将stats作用在今天
    return df_transform, y_names_added


def process_data_oneday(dirname, filename, date, window, x_names, label_name, x_q, y_thre, pad_num, y_names, save_folder):
    df, y_names_added = rolling_norm_oneday(dirname, filename, date, window, x_names, label_name, x_q, y_thre)
    if not df.empty:
        y_names = y_names + y_names_added
        if pad_num > 0:
            df = pad_df_oneday(df, pad_num)
        save_processed_data_oneday(df, x_names, y_names, save_folder)


def process_data(
    dirname: str, filename: str, date_start: str, date_end: str,
    window: int, x_names: List[str], label_name: str, x_q: float, y_thre: float,
    pad_num: int, y_names: List[str], save_folder: str, threads=32, filepattern=None
):
    print(qr.cpu_mem_usage("Processing data......"))
    if filepattern is None:
        filepattern = '{dirname}/{date}/{filename}'
    filepattern = filepattern.format(dirname=dirname,filename=filename,date='{date}')
    date_list = dates_from(filepattern, date_start=date_start, date_end=date_end)
    print(f"data from {dirname}\nto {save_folder}\n from {date_start} to {date_end}")
    if threads == 1:
        results = [process_data_oneday(
            dirname, filename, date, window, x_names, label_name, x_q, y_thre, pad_num, y_names, save_folder
        ) for date in date_list]
    else:
        results = Parallel(n_jobs=min(threads, len(date_list)), verbose=1)(delayed(process_data_oneday)(
            dirname, filename, date, window, x_names, label_name, x_q, y_thre, pad_num, y_names, save_folder
        ) for date in date_list)
    print(qr.cpu_mem_usage("Finish processing......"))


if __name__ == '__main__':
    dateset_dir = '/data/bees1/safe/junming/padl/dataset'
    processeddata_dir = '/data/bees1/safe/junming/padl/processed_data/'

    with open(os.path.join('/data/bees1/safe/junming/padl', 'column_group.json'), 'r') as f:
        column_group = json.load(f)
    feature = "feature_all"
    x_names = column_group[feature]
    y_names = column_group['fret']
    misc = ['gid', 'date', 'rec_epoch', 'X.wgtls']
    label_name = 'ret300.1s'

    date_start, date_end = '20190801', '20240409'
    dataset_name = f'{feature}_{date_start}-{date_end}_7.5s'
    dirname = os.path.join(dateset_dir, dataset_name)
    filename = 'dataset.tbl'
    
    # load & process & save
    window = 10  # rolling 10个交易日用于计算stats
    x_q = 0.9999
    y_thre = 0.03
    pad_num = 100
    
    processed_name = f'{feature}_rolling{window}norm_pad{pad_num}_{date_start}-{date_end}_7.5s'
    save_folder = os.path.join(processeddata_dir, processed_name)
    process_data(
        dirname, filename, date_start, date_end,
        window, x_names, label_name, x_q, y_thre,
        pad_num, y_names, save_folder, threads=32,
    )