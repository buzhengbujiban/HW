import os, json
import re
import numpy as np
import pandas as pd
from typing import Dict, List
import gc
from joblib import Parallel, delayed

import qr
import qr_utils
from file_utils.provider import dates_from


def make_dataset_oneday(
    filepattern: str, date: str, y_names, columns_need: List[str]=None, 
    save_dir: str=None, save_name: str='dataset.tbl'
):
    """在这里filter data以及一些基础的处理"""
    df = qr.tbl_read(filepattern.format(date=date))
    if columns_need:
        df = df[columns_need]

    df[y_names] = df[y_names].astype(np.float32)
    df.rename(columns={'gid': 'S', 'date': 'D'}, inplace=True) # 期货用gid 股票sid
    df['S'] = df['S'].astype(int)
    df['D'] = df['D'].astype(int)
    df['I'] = df['rec_epoch'].apply(lambda t: qr_utils.epoch_to_HMS(t, show_ms=False))  # 原2.5s/7.5s采样被rounding到s
    df['I'] = df['I'].str.replace(':', '').astype(int)  # e.g. 90000 for '09：00：00'
    # df.drop_duplicates(subset=['S', 'I'], inplace=True)  # 确保各合约每一分钟的数据都是unique; 后来发现rec_epoch有间隔很近的时间点但src_epoch，这样会丢失样本
    df.sort_values(by=['S', 'D', 'I'], inplace=True)  # 按照code, time排好序

    if save_dir:
        os.makedirs(os.path.join(save_dir, date), exist_ok=True)
        qr.tbl_write(df, os.path.join(save_dir, date, save_name))
    else:
        return df
    

def make_dataset(
    dirname: str, filename: str, date_start: str, date_end: str, y_names: str,
    save_dir: str=None, save_name: str='dataset.tbl',
    columns_need: List[str]=None, threads=32, filepattern: str=None,
):
    print(qr.cpu_mem_usage("Making Dataset......"))
    if filepattern is None:
        filepattern = '{dirname}/{date}/{filename}'
    filepattern = filepattern.format(dirname=dirname,filename=filename,date='{date}')
    date_list = dates_from(filepattern, date_start=date_start, date_end=date_end)
    print(f"data from {dirname}\nto {save_dir}\n from {date_start} to {date_end}")
    dfs = Parallel(n_jobs=threads, verbose=1)(delayed(make_dataset_oneday)(
        filepattern, date, y_names, columns_need, save_dir, save_name
    ) for date in date_list)
    print(qr.cpu_mem_usage("finish parallel make dfs"))
    if save_dir is None:
        df_all = pd.concat(dfs, axis=0)
        del dfs
        print(qr.cpu_mem_usage("finish concat dfs"))
        return df_all


if __name__ == '__main__':

    filename = 'All2.tbl'
    dateset_dir = '/data/bees1/safe/junming/padl/dataset'
    n_jobs = 8

    with open(os.path.join('/data/bees1/safe/junming/padl', 'column_group.json'), 'r') as f:
        column_group = json.load(f)
    feature = 'feature_all'
    x_names = column_group[feature]
    y_names = column_group['fret']
    misc = ['gid', 'date', 'rec_epoch', 'X.wgtls']
    columns_need = misc + x_names + y_names
    label_name = 'ret300.1s'

    # 1. make dataset
    # dirname = '/data/nasData/chinaFuturesData/features_tgy/go2-pab-l2/sample'  # 2.5s sample的数据
    # date_start, date_end = '20190801', '20240321'
    # dataset_name = f'{feature}_{date_start}-{date_end}'

    dirname = '/data/bees1/unsafe/features_tgy/go2-pab2-l2/sample'  # 7.5s sample的数据
    date_start, date_end = '20190801', '20240409'
    dataset_name = f'{feature}_{date_start}-{date_end}_7.5s'

    save_dir = os.path.join(dateset_dir, dataset_name)  # save_dir for this particular dataset
    make_dataset(
        dirname, filename, date_start, date_end,
        y_names=y_names, save_dir=save_dir, columns_need=columns_need, threads=n_jobs
    )
    print(qr.cpu_mem_usage("finish making dataset"))