import os, json
import re
import logging
import bisect
import numpy as np
import pandas as pd
from typing import Dict, List
import gc
from joblib import Parallel, delayed

import qr
from file_utils import SingleFile, dates_from, load_block


def load_dataset(
    dirname: str, filename: str, date_start: str, date_end: str, min_dates: int=0,
    threads=4, filepattern: str=None,
):
    """
    if min_dates > 0, then need to gather min_dates days' data no later than date_end.
    """
    if filepattern is None:
        filepattern = '{dirname}/{date}/{filename}'
    filepattern = filepattern.format(dirname=dirname,filename=filename,date='{date}')
    if min_dates == 0:
        date_list = dates_from(filepattern, date_start=date_start, date_end=date_end)
        if len(date_list) == 0:
            print(f"no data for {date_end}.")
            return pd.DataFrame()  # no data for this date
    else:
        available_dates = dates_from(filepattern)
        ### below lines are to deal with missing dates' data
        end_idx = bisect.bisect_right(available_dates, date_end) - 1  # end_idx is the largest i s.t. available_dates[i] <= date_end
        if end_idx < 0:
            print(f"end idx<0 for {date_end}")
            return pd.DataFrame()  # for 1st date
        start_idx = end_idx - min_dates + 1
        if start_idx < 0:
            print(f"not enough dates' data for {date_end}")
            return pd.DataFrame()  # not enough dates' data
        actual_start_date = available_dates[start_idx]
        actual_end_date = available_dates[end_idx]
        if actual_start_date < date_start or actual_end_date < date_end:
            print(f'Warning: due to file missing, actual_start_date: {actual_start_date} vs. date_start: {date_start}, actual_end_date: {actual_end_date} vs. date_end: {date_end}')
        date_list = dates_from(filepattern, date_start=actual_start_date, date_end=actual_end_date)
        assert len(date_list) == min_dates, f"len(date_list) != min_dates, date_end: {date_end}"
        ###
    if len(date_list) == 1:
        df_all = qr.tbl_read(filepattern.format(date=date_list[0]))
    else:
        if threads > 1:
            dfs = Parallel(n_jobs=threads, verbose=1)(delayed(lambda date: qr.tbl_read(filepattern.format(date=date)))(date) for date in date_list)
        else:
            dfs = [qr.tbl_read(filepattern.format(date=date)) for date in date_list]
        df_all = pd.concat(dfs, axis=0)
        print(qr.cpu_mem_usage("finish concating dfs"))
        del dfs
        gc.collect()
        print(qr.cpu_mem_usage("finish deleting dfs"))
    return df_all


def load_dataset_shm(
    dirname: str, filename: str, date_start: str, date_end: str, min_dates: int=1,
    threads=4, filepattern: str=None
):  
    if filepattern is None:
        filepattern = '{dirname}/{date}/{filename}'
    filepattern = filepattern.format(dirname=dirname,filename=filename,date='{date}')
    date_list = dates_from(filepattern, date_start=date_start, date_end=date_end)
    ds = [SingleFile(date, dirname, filename) for date in date_list]
    data_array, feature_names, shm_key = load_block(ds, threads)
    return data_array, feature_names


def calc_stats(array, names, q=0.9999):
    array[np.isinf(array)] = np.nan  # mslu会被inf影响，而会自动忽略nan
    mean = np.nanmean(array, axis=0)
    std = np.nanstd(array, axis=0)
    qs = np.nanquantile(array, q=(1-q, q), axis=0)
    lower, upper = qs[0], qs[1]
    stats = pd.DataFrame({'mean': mean, 'std': std, 'lower': lower, f'upper': upper}, index=names).astype(np.float32)
    return stats


def pad_df_oneday(df, pad_num:int):
    """给这一天的df的所有gid在时间上的最前面padding上pad_num个0"""
    df = df.copy()
    df[['S', 'D', 'I']] = df[['S', 'D', 'I']].astype(int)
    df['real'] = 1  # 标注真实样本，而非padding出来的虚假样本
    date = df['D'].values[0]
    time_start = np.nanmin(df['I'].values)
    time_list = sorted([time_start-i-1 for i in range(pad_num)])  # 生成每天开盘前的虚假时间点
    sids = pd.unique(df['S'].values)
    df3 = pd.DataFrame(np.zeros((len(sids)*len(time_list), df.shape[1]), dtype=np.float32), columns=df.columns.values.tolist())
    df3['S'] = np.repeat(sids, len(time_list))
    df3['I'] = np.tile(time_list, len(sids))
    df3['D'] = date 
    df3['real'] = 0
    df = pd.concat([df, df3], ignore_index=True, sort=False)  # 注意，df3['real']连同其他field都是0
    df.sort_values(by=['S', 'D', 'I'], inplace=True)
    return df


def save_processed_data_oneday(df, x_names, y_names, save_folder):
    df = df.copy()
    df[['S', 'D', 'I']] = df[['S', 'D', 'I']].astype(int)
    date = df['D'].values[0]
    attr_names = [col for col in df.columns if col not in x_names+y_names]
    df_x = df[x_names]
    df_y = df[y_names]
    df_attr = df[attr_names]
    del df
    os.makedirs(os.path.join(save_folder, str(date)), exist_ok=True)
    qr.tbl_write(df_x, os.path.join(save_folder, str(date), 'x.tbl'))
    qr.tbl_write(df_y, os.path.join(save_folder, str(date), 'y.tbl'))
    qr.tbl_write(df_attr, os.path.join(save_folder, str(date), 'attr.tbl'))