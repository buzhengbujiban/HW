import argparse
from nnfitter.utils import read_json
from nnfitter import learner as learner_module


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("config_path")
    args = parser.parse_args()
    config = read_json(args.config_path)

    learner = getattr(learner_module, config["learner_class"])(config)
    learner.run()