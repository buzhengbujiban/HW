import os
import sys
from multiprocessing import Pool
from tqdm import tqdm
import numpy as np

# 获取当前脚本文件的目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取上一级目录
parent_dir = os.path.dirname(current_dir)
# 将上一级目录添加到sys.path
sys.path.append(parent_dir)

from pattern_helper import find_dates_from_pattern 
from array_shm import write_xr_to_shm
import panel

def process_file(date, read_pattern, write_pattern):
    read_file = read_pattern.replace("YYYYMMDD", str(date))
    write_file = write_pattern.replace("YYYYMMDD", str(date))

    try:
        # 读取文件
        data = panel.read(read_file)
        # 写入文件
        write_xr_to_shm(data, write_file, dtype=np.float32)
        # print(f"Processed {read_file} -> {write_file}")
    except Exception as e:
        print(f"Failed to process {read_file}: {e}")

def process_files(read_pattern, write_pattern, num_proceses):
    # 获取所有日期
    dates = find_dates_from_pattern(read_pattern)

    # 创建一个进程池
    with Pool(processes=num_proceses) as pool:
        results = []
        for date in tqdm(dates):
            result = pool.apply_async(process_file, (date, read_pattern, write_pattern))
            results.append(result)
        
        # 等待所有进程完成
        for result in results:
            result.get()

if __name__ == "__main__":
    read_pattern = "/data/beef2/zifan/shared/label_10m_downsample/is_active/terms.YYYYMMDD.sdiv"
    write_pattern = "/dev/shm/zifan.YYYYMMDD.W.sdiv"

    process_files(read_pattern, write_pattern, num_proceses=64)
