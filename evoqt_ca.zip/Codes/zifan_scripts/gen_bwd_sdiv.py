import os
import re
import argparse
import numpy as np
import xarray as xr
import panel
import glob
from tqdm import tqdm
import hdf5plugin
from multiprocessing import Pool

def get_previous_n_trading_file(dates, current_date, n):
    current_index = dates.index(current_date)
    if current_index - n >= 0:
        return dates[current_index - n]
    else:
        return dates[0]

def get_previous_n_trading_files(dates, current_date, n):
    current_index = dates.index(current_date)
    if current_index - n >= 0:
        return dates[current_index - n:current_index]
    else:
        return dates[:current_index]

def calculate_backward_rolling(sdiv_data, time_interval, intervals, interval_length):
    unit = time_interval[-1]
    t = int(time_interval[:-1])

    if unit == 'm':
        n_intervals = t // interval_length
    elif unit == 'h':
        n_intervals = t * 60 // interval_length
    else:
        raise ValueError(f"Unknown time unit: {unit}")

    shifted = sdiv_data.shift(I=n_intervals, fill_value=np.nan)
    
    first_index = intervals.index('09:30:00')
    first_values = sdiv_data.sel(I=intervals[first_index])

    indices_to_fill = intervals[:n_intervals]
    shifted.loc[{'I': indices_to_fill}] = first_values

    return shifted

def calculate_backward_sum_label(dates, input_pattern, date, horizon, features_to_calculate):
    unit = horizon[-1]
    t = int(horizon[:-1])

    if unit != 'd':
        raise ValueError("Sum label calculation is only applicable for daily horizons.")

    previous_dates = get_previous_n_trading_files(dates, date, t)
    sum_data = None
    for previous_date in previous_dates:
        previous_file = input_pattern.replace('YYYYMMDD', str(previous_date))
        previous_sdiv_data = panel.read_v1(previous_file)
        if sum_data is None:
            sum_data = previous_sdiv_data.sel(V=features_to_calculate).values
        else:
            sum_data += previous_sdiv_data.sel(V=features_to_calculate).values
    return sum_data

def create_backward_label_sdiv_file(input_pattern, date, horizon_list, output_file, freq_m, features_list, label_types, full_print=False):
    dates = find_dates_from_pattern(input_pattern)
    
    input_file = input_pattern.replace('YYYYMMDD', str(date))
    sdiv_data = panel.read_v1(input_file)
    S, D, I, V = sdiv_data.coords['S'], sdiv_data.coords['D'], sdiv_data.coords['I'], sdiv_data.coords['V']
    
    if features_list:
        features_to_calculate = features_list
    else:
        features_to_calculate = V.values

    cols = V.values

    if full_print:
        print(dates)
        print(cols)
    original_labels = []
    diff_labels = []
    sum_labels = []
    intervals = list(I.values)

    sdiv_data = sdiv_data.sel(V=features_to_calculate)
    for horizon in horizon_list:
        unit = horizon[-1]
        t = int(horizon[:-1])
        
        if unit == 'd':
            previous_date = get_previous_n_trading_file(dates, date, t)
            previous_file = input_pattern.replace('YYYYMMDD', str(previous_date))
            previous_sdiv_data = panel.read_v1(previous_file)
            if 'orig' in label_types:
                original_labels.append(previous_sdiv_data.sel(V=features_to_calculate).values)
            if 'diff' in label_types:
                diff_labels.append(sdiv_data.sel(V=features_to_calculate).values - previous_sdiv_data.sel(V=features_to_calculate).values)
            if 'sum' in label_types:
                sum_labels.append(calculate_backward_sum_label(dates, input_pattern, date, horizon, features_to_calculate))
        elif unit in ['m', 'h']:
            previous_sdiv_data = calculate_backward_rolling(sdiv_data, horizon, intervals, freq_m)
            if 'orig' in label_types:
                original_labels.append(previous_sdiv_data.values)
            if 'diff' in label_types:
                diff_labels.append(-previous_sdiv_data.values + sdiv_data.values)
        else:
            raise ValueError(f"Unknown time unit: {unit}")

    combined_values = []
    new_V_combined = []

    if 'orig' in label_types:
        combined_values.append(np.concatenate(original_labels, axis=-1))
        new_V_combined += [f"bwd.orig.{v.split('.')[-1]}.{time}" for time in horizon_list for v in features_to_calculate]

    if 'diff' in label_types:
        combined_values.append(np.concatenate(diff_labels, axis=-1))
        new_V_combined += [f"bwd.diff.{v.split('.')[-1]}.{time}" for time in horizon_list for v in features_to_calculate]

    if 'sum' in label_types:
        combined_values.append(np.concatenate(sum_labels, axis=-1))
        new_V_combined += [f"bwd.sum.{v.split('.')[-1]}.{time}" for time in horizon_list if time[-1] == 'd' for v in features_to_calculate]

    combined_values = np.concatenate(combined_values, axis=-1)

    label_sdiv_data = xr.DataArray(combined_values, coords=[S, D, I, new_V_combined], dims=['S', 'D', 'I', 'V'])
    panel.write_v1(output_file, label_sdiv_data)

def find_dates_from_pattern(pattern, warmup=0):
    files = glob.glob(pattern.replace("YYYYMMDD", "*"))
    result = []
    for f in files:
        result += re.findall(pattern.replace("YYYYMMDD", "(\d{8})"), f)
    return sorted([int(i) for i in result])[warmup:]

def process_date(args, date, full_print):
    output_file = args.output_pattern.replace('YYYYMMDD', str(date))
    create_backward_label_sdiv_file(
        input_pattern=args.pattern,
        date=date,
        horizon_list=args.fwd_horizons,
        output_file=output_file,
        freq_m=args.freq_m,
        features_list=args.features,
        label_types=args.label_types,
        full_print=full_print,
    )

def initializer(args, full_print):
    global global_args
    global global_full_print
    global_args = args
    global_full_print = full_print

def process_date_wrapper(date):
    return process_date(global_args, date, global_full_print)

if __name__ == "__main__":
    def str_to_list(s):
        return s.split(',')

    parser = argparse.ArgumentParser()

    parser.add_argument("--pattern", type=str, required=True, help="输入文件的模式，其中 'YYYYMMDD' 将被实际日期替换。")
    parser.add_argument("--date", type=int, required=False, help="要处理的特定日期。如果未提供，将处理与模式匹配的所有日期。")
    parser.add_argument("--fwd_horizons", type=str_to_list, required=True, help="逗号分隔的前向预测时间范围列表（例如 '1d,5d,1h'）")
    parser.add_argument("--output_pattern", type=str, required=True, help="输出文件的模式，其中 'YYYYMMDD' 将被实际日期替换。")
    parser.add_argument("--freq_m", type=int, required=False, default=5, help="数据处理间隔的分钟频率。如果处理日频数据则不需要写这个")
    parser.add_argument("--features", type=str_to_list, required=False, default=None, help="逗号分隔的要计算的特征列表。如果未提供，将使用所有特征。")
    parser.add_argument("--label_types", type=str_to_list, required=False, default="orig,diff", help="逗号分隔的要计算的标签类型列表（例如 'orig,diff,sum'）。")
    parser.add_argument("--num_workers", type=int, required=False, default=32, help="用于数据处理的子进程数量。默认为32。")
    args = parser.parse_args()
    
    if args.date:
        dates = [args.date]
        full_print = True
    else:
        dates = find_dates_from_pattern(args.pattern)
        full_print = False
        print(len(dates))

    print(os.path.dirname(args.output_pattern))
    os.makedirs(os.path.dirname(args.output_pattern), exist_ok=True)

    num_cpus = args.num_workers

    with Pool(processes=num_cpus, initializer=initializer, initargs=(args, full_print)) as pool:
        for _ in tqdm(pool.imap_unordered(process_date_wrapper, dates), total=len(dates)):
            pass
