import os
import sys

# 获取当前脚本文件的目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取上一级目录
parent_dir = os.path.dirname(current_dir)
# 将上一级目录添加到sys.path
sys.path.append(parent_dir)
import numpy as np
from tqdm import tqdm
import json
import panel
import xarray as xr
from utils import find_dates_from_pattern
import re
import multiprocessing



class FeaturePreprocessor:
    def __init__(self, feature_stats, index_y):
        self.log_features = {entry["index"]: (entry["mean_value"], entry["std_dev"], entry["1_percentile"], entry["99_percentile"])
                             for entry in feature_stats["Highly skewed and kurtotic"]}
        self.normal_features = {entry["index"]: (entry["mean_value"], entry["std_dev"], entry["1_percentile"], entry["99_percentile"])
                                for entry in feature_stats["Moderately skewed and kurtotic"]}
        self.normal_features.update({entry["index"]: (entry["mean_value"], entry["std_dev"], entry["1_percentile"], entry["99_percentile"])
                                     for entry in feature_stats["Near-normal distribution"]})
        self.index_y = index_y
        self.y_stats = self.log_features.get(index_y, self.normal_features.get(index_y))

    def log_transform(self, x, mean, std, min_val):
        shift = 1e-6 - min_val if min_val<=0 else 1e-6  # 确保没有负值
        return (np.log(x + shift) - mean) / std

    def normalize(self, x, mean, std):
        return (x - mean) / std

    def clip(self, x, min_val, max_val):
        return np.clip(x, min_val, max_val)

    def preprocess_features(self, xs):
        for idx, (mean, std, min_val, max_val) in self.log_features.items():
            xs[:, idx] = self.clip(xs[:, idx], min_val, max_val)
            xs[:, idx] = self.log_transform(xs[:, idx], mean, std, min_val)
        for idx, (mean, std, min_val, max_val) in self.normal_features.items():
            xs[:, idx] = self.clip(xs[:, idx], min_val, max_val)
            xs[:, idx] = self.normalize(xs[:, idx], mean, std)
        return xs

def preprocess_file(preprocessor, input_file, output_file):
    # Load input data
    data = panel.read(input_file)
    data = data.fillna(0)
    dim_V = data.sizes['V']
    dim_S = data.sizes['S']
    dim_D = data.sizes['D']
    dim_I = data.sizes['I']
    xs = data.values.reshape((-1, dim_V))  # Reshape for preprocessing

    # Preprocess features
    xs = preprocessor.preprocess_features(xs)
    
    # Reshape data back to original dimensions
    xs = xs.reshape((dim_S, dim_D, dim_I, dim_V))
    
    # Create xarray DataArray for outputs
    result = xr.DataArray(xs, coords=[data.coords['S'], data.coords['D'], data.coords['I'], data.coords['V']], dims=['S', 'D', 'I', 'V'])
    
    # Save the results to file
    panel.write(output_file, result)
    print(f"Processed data saved to {output_file}")

def preprocess_wrapper(args):
    preprocessor, input_file, output_file = args
    preprocess_file(preprocessor, input_file, output_file)

def process_all_files(feature_stats, dates, input_dir, output_dir):
    # Create a pool of workers
    num_workers = 64
    pool = multiprocessing.Pool(num_workers)
    
    preprocessor = FeaturePreprocessor(feature_stats, index_y=None)
    
    tasks = []
    for date in dates:
        input_file = os.path.join(input_dir, f'terms.{date}.sdiv')
        output_file = os.path.join(output_dir, f'terms.{date}.sdiv')
        tasks.append((preprocessor, input_file, output_file))
    
    for _ in tqdm(pool.imap_unordered(preprocess_wrapper, tasks), total=len(tasks)):
        pass
    
    pool.close()
    pool.join()

if __name__ == "__main__":
    multiprocessing.set_start_method("spawn")
    input_dir = '/data/beef2/zifan/diff_infer_data/mpvd'
    output_dir = '/data/beef2/zifan/shared/test/processed_diff_mpvd'

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    with open('/home/zifan/dev/conditional/statistics/diff_feature_statistics.json', 'r') as f:
        feature_stats = json.load(f)


    # multiprocessing.set_start_method("spawn")
    # input_dir = '/data/beef2/junming/data/tradevol_imbalance'
    # output_dir = '/data/beef2/zifan/mix_data/tradevol_imbalance'

    # if not os.path.exists(output_dir):
    #     os.makedirs(output_dir)
    
    # with open('/home/zifan/dev/conditional/statistics/pq_mean.json', 'r') as f:
    #     feature_stats = json.load(f)

    dates = find_dates_from_pattern(input_dir + '/terms.YYYYMMDD.sdiv')
    process_all_files(feature_stats, dates, input_dir, output_dir)
