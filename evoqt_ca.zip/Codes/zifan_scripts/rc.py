import os
import sys
import xarray as xr
from tqdm import tqdm
from multiprocessing import Pool, cpu_count

# 获取当前脚本文件的目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取上一级目录
parent_dir = os.path.dirname(current_dir)
# 将上一级目录添加到sys.path
sys.path.append(parent_dir)

import panel
from pattern_helper import find_dates_from_pattern

def filter_concat_and_write(args):
    features_to_keep, feature2remove, date, input_dir1, input_dirs2, output_dir, previous_shape = args
    try:
        # 读取第一个输入目录中的数据并进行特征过滤
        input_file1 = os.path.join(input_dir1, f'terms.{date}.sdiv')
        data1 = panel.read(input_file1)
        
        if features_to_keep:
            vars_to_keep = [v for v in data1['V'].values if any(f == v for f in features_to_keep)]
            selector = dict(V=vars_to_keep)
        else:
            vars_to_remove = [v for v in data1['V'].values if any(f == v for f in feature2remove)]
            selector = dict(V=[var for var in data1['V'].values if var not in vars_to_remove])
        
        data1 = data1.sel(selector)
        
        # 读取第二个输入目录中的数据
        xarrays = [data1]
        for input_dir2 in input_dirs2:
            input_file2 = os.path.join(input_dir2, f'terms.{date}.sdiv')
            if os.path.exists(input_file2):
                data2 = panel.read(input_file2).fillna(0)
                xarrays.append(data2)
            else:
                raise ValueError(f"File not found: {input_file2}")

        # 合并数据集
        combined_data = xr.concat(xarrays, dim='V')
        
        if previous_shape is None:
            previous_shape = combined_data.shape
        elif combined_data.shape != previous_shape:
            raise ValueError(f"Shape mismatch: {combined_data.shape} does not match {previous_shape} for date {date}")

        # 保存合并后的数据
        output_file = os.path.join(output_dir, f'terms.{date}.sdiv')
        panel.write(output_file, combined_data)
        print(f'Saved combined data for date {date} to {output_file}')

        return previous_shape
    
    except ValueError as e:
        print(f"Skipping date {date} due to error: {e}")
        return None

if __name__ == "__main__":
    # 设置输入输出路径和参数
    input_dir1 = '/data/beef2/zifan/shared/label_10m_downsample/oi_ret'
    input_dirs2 = ['/data/beef2/zifan/shared/label_10m_downsample/Y_vol_daily_ovnt_expanded']
    output_dir = '/data/beef2/zifan/shared/label_10m_downsample/Y_itrd_vol_daily_ovnt'
    
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    dates = find_dates_from_pattern(input_dir1 + '/terms.YYYYMMDD.sdiv')
    feature2remove = ["vrpo", "vtpo", "vrpb", "vtpb"]
    features_to_keep = None
    features_to_keep = ['bret_1itrd', 'mret_1itrd', 'mret_itrd', 'bret_itrd']
    
    previous_shape = None
    args_filter_concat = [(features_to_keep, feature2remove, date, input_dir1, input_dirs2, output_dir, previous_shape) for date in dates]
    
    with Pool(128) as pool:
        list(tqdm(pool.imap(filter_concat_and_write, args_filter_concat), total=len(dates)))
