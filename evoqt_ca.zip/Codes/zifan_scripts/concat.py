import os
import sys
import xarray as xr
from tqdm import tqdm
from multiprocessing import Pool, cpu_count

# 获取当前脚本文件的目录
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取上一级目录
parent_dir = os.path.dirname(current_dir)
# 将上一级目录添加到sys.path
sys.path.append(parent_dir)

import panel
import pattern_helper as ph

def process_date(date, input_dir, output_pattern, previous_shape, subfolder_list):
    if subfolder_list is None:
        subfolders = [f.path for f in os.scandir(input_dir) if f.is_dir()]
    else:
        subfolders = [os.path.join(input_dir, subfolder) for subfolder in subfolder_list]

    xarrays = []

    try:
        for subfolder in subfolders:
            # 构建文件路径
            file_path = os.path.join(subfolder, f'terms.{date}.sdiv')
            # file_path = os.path.join(subfolder, f'selected1.{date}.sdiv')
            if os.path.exists(file_path):
                # 读取xarray文件
                data = panel.read(file_path)

                # 将NaN值设置为0
                data = data.fillna(0)

                # 将处理过的data添加到列表
                xarrays.append(data)
            else:
                raise ValueError(f"File not found: {file_path}")

        if xarrays:
            # 将所有xarray沿V轴进行合并
            combined_data = xr.concat(xarrays, dim='V')

            if previous_shape is None:
                previous_shape = combined_data.shape
            elif combined_data.shape != previous_shape:
                raise ValueError(f"Shape mismatch: {combined_data.shape} does not match {previous_shape} for date {date}")

            # 保存合并后的数据
            output_file = output_pattern.replace('YYYYMMDD', str(date))
            panel.write(output_file, combined_data)
            print(f'Saved combined data for date {date} to {output_file}')

        else:
            raise ValueError(f"No files found for date {date}")

        return previous_shape
    
    except ValueError as e:
        print(f"Skipping date {date} due to error: {e}")
        return None

def read_concat(input_dir, output_pattern, cpu_num, subfolder_list=None):
    # 使用pattern_helper找到所有日期
    dates = ph.find_dates_from_pattern("/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/mpv/mpvd/terms.YYYYMMDD.sdiv")
    
    previous_shape = None

    with Pool(processes=cpu_num) as pool:
        results = []
        for date in tqdm(dates):
            result = pool.apply_async(process_date, (date, input_dir, output_pattern, previous_shape, subfolder_list))
            results.append(result)

        for result in results:
            new_shape = result.get()
            if new_shape is not None:
                previous_shape = new_shape

if __name__ == "__main__":
    # 输入文件夹和输出文件夹路径
    input_dir = "/data/beef2/zifan/shared/label_10m_downsample"
    output_pattern = "/data/beef2/zifan/shared/label_10m_downsample/bk_diff_AE/terms.YYYYMMDD.sdiv"

    # input_dir = "/data/beef2/mike/CA_terms_v24.0408/std_terms"
    # output_pattern = "/data/beef2/zifan/std_test/terms.YYYYMMDD.sdiv"

    output_dir = os.path.dirname(output_pattern)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # 设置cpu_num为最大可用CPU数量
    cpu_num = 64
    
    # 指定要处理的子文件夹列表，或者设置为None以处理所有子文件夹
    subfolder_list = None  # 或者 ['subfolder1', 'subfolder2', ...]
    subfolder_list = ["bk2_terms", "diff_infer_processed_AE"]

    # input_dir = '/data/beef2/mike/PQ_terms_v24.0614'
    # output_pattern = "/data/beef2/zifan/mike_data/concat_processed/terms.YYYYMMDD.sdiv"

    # output_dir = os.path.dirname(output_pattern)
    # if not os.path.exists(output_dir):
    #     os.makedirs(output_dir)
    # subfolder_list = ["act_000", "act_001", "act_002"]
    read_concat(input_dir, output_pattern, cpu_num, subfolder_list)
