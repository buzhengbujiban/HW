import os
import re
import argparse
import numpy as np
import xarray as xr
import panel
import glob
from tqdm import tqdm
import hdf5plugin
from multiprocessing import Pool

def get_next_n_trading_file(dates, current_date, n):
    current_index = dates.index(current_date)
    if current_index + n < len(dates):
        return dates[current_index + n]
    else:
        return dates[-1]

def get_next_n_trading_files(dates, current_date, n):
    current_index = dates.index(current_date)
    if current_index + n < len(dates):
        return dates[current_index + 1:current_index + n + 1]
    else:
        return dates[current_index + 1:]

def calculate_rolling(sdiv_data, time_interval, intervals, interval_length, use_next_day, 
                      next_sdiv_data=None):
    unit = time_interval[-1]
    t = int(time_interval[:-1])

    if unit == 'm':
        n_intervals = t // interval_length
    elif unit == 'h':
        n_intervals = (t * 60) // interval_length
    else:
        raise ValueError(f"Unknown time unit: {unit}")

    total_intervals = len(intervals)
    
    # Step 1: Apply rolling shift
    rolling_data = sdiv_data.shift(I=-n_intervals, fill_value=np.nan)

    # Step 2: Get the last valid value from current day's data
    last_index = intervals.index('15:00:00')
    last_values = sdiv_data.sel(I=intervals[last_index]).values

    # Step 3: Handle use_next_day logic
    if use_next_day and next_sdiv_data is not None:
        remaining_intervals = n_intervals - (total_intervals - last_index - 1)
        if remaining_intervals > 0:
            next_intervals = next_sdiv_data.coords['I'].values[:remaining_intervals]
            next_values = next_sdiv_data.sel(I=next_intervals).values
            
            # Combine current day's data with next day's data
            rolling_data[:, :, -remaining_intervals:, :] = next_values
    else:
        # Fill remaining intervals with the last available value
        rolling_data[:, :, -n_intervals:, :] = last_values[:, :, np.newaxis, :]

    return rolling_data

def calculate_sum_label(dates, input_pattern, date, horizon, features_to_calculate):
    unit = horizon[-1]
    t = int(horizon[:-1])

    if unit != 'd':
        raise ValueError("Sum label calculation is only applicable for daily horizons.")

    next_dates = get_next_n_trading_files(dates, date, t)
    sum_data = None
    for next_date in next_dates:
        next_file = input_pattern.replace('YYYYMMDD', str(next_date))
        next_sdiv_data = panel.read_v1(next_file)
        if sum_data is None:
            sum_data = next_sdiv_data.sel(V=features_to_calculate).values
        else:
            # print(sum_data, next_sdiv_data)
            sum_data += next_sdiv_data.sel(V=features_to_calculate).values
    return sum_data

def calculate_sum_label_intraday(sdiv_data, time_interval, intervals, freq_m, use_next_day, next_sdiv_data=None):
    unit = time_interval[-1]
    t = int(time_interval[:-1])

    if unit == 'm':
        n_intervals = t // freq_m
    elif unit == 'h':
        n_intervals = (t * 60) // freq_m
    else:
        raise ValueError(f"Unknown time unit: {unit}")

    sum_data = np.full_like(sdiv_data.values, np.nan)

    for i in range(len(intervals)):
        end_idx = i + n_intervals
        if end_idx <= len(intervals):
            sum_data[:, :, i, :] = np.nansum(sdiv_data.values[:, :, i:end_idx, :], axis=2)
        else:
            sum_data[:, :, i, :] = np.nansum(sdiv_data.values[:, :, i:, :], axis=2)
            if use_next_day and next_sdiv_data is not None:
                extra_intervals = end_idx - len(intervals)
                next_intervals = next_sdiv_data.coords['I'].values[:extra_intervals]
                next_values = next_sdiv_data.sel(I=next_intervals).values
                sum_data[:, :, i, :] += np.nansum(next_values, axis=2)

    return sum_data

def create_label_sdiv_file(input_pattern, date, horizon_list, output_file, freq_m, features_list, label_types, use_next_day, full_print=False):
    dates = find_dates_from_pattern(input_pattern)
    
    input_file = input_pattern.replace('YYYYMMDD', str(date))
    sdiv_data = panel.read_v1(input_file)
    S, D, I, V = sdiv_data.coords['S'], sdiv_data.coords['D'], sdiv_data.coords['I'], sdiv_data.coords['V']


    
    if features_list:
        features_to_calculate = features_list
    else:
        features_to_calculate = V.values

    if use_next_day:
        next_date = get_next_n_trading_file(dates, date, 1)
        next_file = input_pattern.replace('YYYYMMDD', str(next_date))
        next_sdiv_data = panel.read_v1(next_file)
        next_sdiv_data = next_sdiv_data.sel(V=features_to_calculate)
    else:
        next_sdiv_data = None
        
    cols = V.values

    if full_print:
        print(dates)
        print(cols)
    original_labels = []
    diff_labels = []
    sum_labels = []
    intervals = list(I.values)

    sdiv_data = sdiv_data.sel(V=features_to_calculate)
    for horizon in horizon_list:
        unit = horizon[-1]
        t = int(horizon[:-1])
        
        if unit == 'd':
            next_date = get_next_n_trading_file(dates, date, t)
            next_file = input_pattern.replace('YYYYMMDD', str(next_date))
            next_sdiv_data = panel.read_v1(next_file)
            next
            if 'orig' in label_types:
                original_labels.append(next_sdiv_data.sel(V=features_to_calculate).values)
            if 'diff' in label_types:
                diff_labels.append(next_sdiv_data.sel(V=features_to_calculate).values - sdiv_data.sel(V=features_to_calculate).values)
            if 'sum' in label_types:
                sum_labels.append(calculate_sum_label(dates, input_pattern, date, horizon, features_to_calculate))
        elif unit in ['m', 'h']:
            next_sdiv_data = calculate_rolling(sdiv_data, horizon, intervals, freq_m, use_next_day, next_sdiv_data)
            if 'orig' in label_types:
                original_labels.append(next_sdiv_data.values)
            if 'diff' in label_types:
                diff_labels.append(next_sdiv_data.values - sdiv_data.values)
            if 'sum' in label_types:
                sum_labels.append(calculate_sum_label_intraday(sdiv_data, horizon, intervals, freq_m, use_next_day, next_sdiv_data))
        else:
            raise ValueError(f"Unknown time unit: {unit}")

    combined_values = []
    new_V_combined = []

    if 'orig' in label_types:
        combined_values.append(np.concatenate(original_labels, axis=-1))
        # new_V_combined += [f"{v.split('.')[-1]}.{time}" for time in horizon_list for v in features_to_calculate]
        new_V_combined += [f"{v}.{time}" for time in horizon_list for v in features_to_calculate]

    if 'diff' in label_types:
        combined_values.append(np.concatenate(diff_labels, axis=-1))
        new_V_combined += [f"fwd.diff.{v.split('.')[-1]}.{time}" for time in horizon_list for v in features_to_calculate]

    if 'sum' in label_types:
        combined_values.append(np.concatenate(sum_labels, axis=-1))
        new_V_combined += [f"fwd.sum.{v.split('.')[-1]}.{time}" for time in horizon_list for v in features_to_calculate]

    combined_values = np.concatenate(combined_values, axis=-1)
    # print(new_V_combined)
    # print(combined_values)
    label_sdiv_data = xr.DataArray(combined_values, coords=[S, D, I, new_V_combined], dims=['S', 'D', 'I', 'V'])
    label_sdiv_data = label_sdiv_data.fillna(0)
    panel.write_v1(output_file, label_sdiv_data)

def find_dates_from_pattern(pattern, warmup=0):
    files = glob.glob(pattern.replace("YYYYMMDD", "*"))
    result = []
    for f in files:
        result += re.findall(pattern.replace("YYYYMMDD", "(\d{8})"), f)
    return sorted([int(i) for i in result])[warmup:]

def process_date(args, date, full_print):
    output_file = args.output_pattern.replace('YYYYMMDD', str(date))
    create_label_sdiv_file(
        input_pattern=args.pattern,
        date=date,
        horizon_list=args.fwd_horizons,
        output_file=output_file,
        freq_m=args.freq_m,
        features_list=args.features,
        label_types=args.label_types,
        full_print=full_print,
        use_next_day=args.use_next_day
    )

def initializer(args, full_print):
    global global_args
    global global_full_print
    global_args = args
    global_full_print = full_print

def process_date_wrapper(date):
    return process_date(global_args, date, global_full_print)


if __name__ == "__main__":
    def str_to_list(s):
        return s.split(',')

    parser = argparse.ArgumentParser()

    '''
    python gen_sdiv_fwd.py --pattern "/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/mpv/mpvd/terms.YYYYMMDD.sdiv" --date 20220817 --fwd_horizons "30m,1h,2d,5d" --output_pattern "./label1.YYYYMMDD.sdiv" --freq_m 5 --features "mpvd.spr,mpvd.rskm" --label_types "orig,diff,sum"
    '''

    # 输入文件的模式，必需参数
    parser.add_argument("--pattern", type=str, required=True, help="输入文件的模式，其中 'YYYYMMDD' 将被实际日期替换。")

    # 要处理的特定日期，可选参数
    parser.add_argument("--date", type=int, required=False, help="要处理的特定日期。如果未提供，将处理与模式匹配的所有日期。")

    # 前向预测的时间范围列表，必需参数
    parser.add_argument("--fwd_horizons", type=str_to_list, required=True, help="逗号分隔的前向预测时间范围列表（例如 '1d,5d,1h'）")

    # 输出文件的模式，必需参数
    parser.add_argument("--output_pattern", type=str, required=True, help="输出文件的模式，其中 'YYYYMMDD' 将被实际日期替换。")

    # 数据处理的分钟频率，可选参数
    parser.add_argument("--freq_m", type=int, required=False, default=5, help="数据处理间隔的分钟频率。如果处理日频数据则不需要写这个")

    # 要计算的特征列表，可选参数
    parser.add_argument("--features", type=str_to_list, required=False, default=None, help="逗号分隔的要计算的特征列表。如果未提供，将使用所有特征。")

    # 要计算的标签类型列表，可选参数，默认值为 'orig,diff'
    parser.add_argument("--label_types", type=str_to_list, required=False, default="orig,diff", help="逗号分隔的要计算的标签类型列表（例如 'orig,diff,sum'）。")

    # 是否使用第二天的数据，默认为 False
    parser.add_argument("--use_next_day", type=bool, required=False, default=False, help="如果第一天不够，将使用第二天的数据。")

    # 增加解析进程数参数
    parser.add_argument("--num_workers", type=int, required=False, default=64, help="用于数据处理的子进程数量。默认为32。")
    args = parser.parse_args()
    
    if args.date:
        dates = [args.date]
        full_print = True
    else:
        dates = find_dates_from_pattern(args.pattern)
        full_print = False
        print(len(dates))

    print(os.path.dirname(args.output_pattern))
    os.makedirs(os.path.dirname(args.output_pattern), exist_ok=True)
    # for date in tqdm(dates):
    #     print("process: ", date, "\n")
    #     output_file = args.output_pattern.replace('YYYYMMDD', str(date))
    #     create_label_sdiv_file(
    #         input_pattern=args.pattern,
    #         date=date,
    #         horizon_list=args.fwd_horizons,
    #         output_file=output_file,
    #         freq_m=args.freq_m,
    #         features_list=args.features,
    #         label_types=args.label_types,
    #         full_print=full_print,
    #     )


    num_cpus = args.num_workers

    with Pool(processes=num_cpus, initializer=initializer, initargs=(args, full_print)) as pool:
        for _ in tqdm(pool.imap_unordered(process_date_wrapper, dates), total=len(dates)):
            pass
