
### 需要在脚本里面修改参数的

1. concat.py: concat多个panel，这几个panel需要在同一个大文件夹下面的几个subfolder中，历史遗留问题，改起来也不难。
2. downsample： 对panel做downsample
3. rc.py: 对特征进行选择或者移除，再和其他panel做拼接，其中input_dir1是需要对特征做选择的panel，input_dirs2是需要拼接的panel列表，如果指定了features2remove就需要把feature_to_keep设置为None，指定了feature_to_keep就不会考虑remove的。会从指定的panel移除/选择一些特征，然后和input_dirs2列表中的panel做拼接。
4. transform.py： 对conditional panel或者其他panel做zscore的，会有一个文件记录了每个特征的mean和std这些，要把这个统计文件和需要zscore的panel作为输入。这个统计文件的位置我写在脚本里面了。
5. write_shm.py: 把文件写到shm


### 需要再命令行里修改参数的

1. gen_sdiv_fwd.py: 得到label用的，注释很详细
2. gen_sum_sdiv.py：gen_sdiv_fwd.py的阉割版，只保留了sum后几天的label功能。需要注意的是这个sum会包括自己，而gen_sdiv_fwd的sum不会包括自己。所以适用于对本来就是fwd label的ret做sum。
3. gen_bwd_sdiv.py: 得到backward特征用的，一般是做diff 差分

### 得到X的流程
1. `python gen_bwd_sdiv.py --pattern "/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/mpv/mpvd/terms.YYYYMMDD.sdiv" --fwd_horizons "1d" --output_pattern "/data/beef2/zifan/diff_data/mpvd/terms.YYYYMMDD.sdiv" --freq_m 5 --label_types "diff" ` 得到一个含有20个差分conditional特征的panel，也就是这一天减去前一天的差分。这个output pattern自行修改
2. 用concat.py 把原来的mpvd panel和新的到的diff panel拼接成40个特征的panel，注意，原来的mpvd需要再列表的第一项，diff panel要在列表的后一项。
3. 用transform.py把conditional panel做zscore，注意需要修改一下output和input pattern 
4. 用新的panel做10min downsample，可以用我写的downsample函数，也可以用ca
5. 用downsample后的conditional panel和AE拼接，我是conditional在前，AE在后，最终会得到一个240个feature的10min的panel，可以和我给出的X "/data/beef2/zifan/shared/label_10m_downsample/diff_infer_processed_AE"做对比。
6. 需要注意的是，即使直接用AE做训练结论基本保持一致，我之所以一直用这个panel做X是因为好比较。

### 得到Y的流程
1. `python gen_sum_sdiv.py --pattern "/data/beef2/zifan/shared/label_10m_downsample/Y_daily_ovnt_expanded/terms.YYYYMMDD.sdiv" --fwd_horizons "3d,5d,7d" --output_pattern "/data/beef2/zifan/shared/label_10m_downsample/Y_ovnt_357d/terms.YYYYMMDD.sdiv" --features "mret_ovnt,bret_ovnt"` 这是一个得到overnight72h,120h,168h的示例，如果是想得到，mret120h或者bret120h用类似的代码就行。
2. 注意所有文件都使用了10min downsample