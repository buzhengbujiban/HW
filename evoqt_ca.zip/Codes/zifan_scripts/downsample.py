import xarray as xr
import numpy as np
import glob
import re
import os
from tqdm import tqdm
from multiprocessing import Pool, Manager
import panel

def find_dates_from_pattern(pattern, warmup=0):
    files = glob.glob(pattern.replace("YYYYMMDD", "*"))
    result = []
    for f in files:
        result += re.findall(pattern.replace("YYYYMMDD", "(\d{8})"), f)
    return sorted([int(i) for i in result])[warmup:]

def downsample(x, n, dim):
    dim_len = x.shape[dim]
    
    if dim_len % n != 0:
        raise ValueError(f"Dimension length {dim_len} is not divisible by {n}.")

    sampled_indices = np.arange(0, dim_len, n)
    sampled_x = x.isel({x.dims[dim]: sampled_indices})

    # 将 inf 和 -inf 替换为 NaN，然后将 NaN 替换为 0
    sampled_x = sampled_x.where(np.isfinite(sampled_x), 0)
    sampled_x = sampled_x.fillna(0)
    
    return sampled_x

def process_date(args):
    date, x_pattern, x_output, n, dim, stats_list = args
    
    x_file = x_pattern.replace("YYYYMMDD", str(date))
    
    if not os.path.exists(x_file):
        print(f"Skipping date {date}: Missing file - X: {x_file}")
        return
    
    x = panel.read(x_file)
    
    sampled_x = downsample(x, n, dim)

    # 计算统计量
    max_val = sampled_x.max().item()
    min_val = sampled_x.min().item()
    mean_val = sampled_x.mean().item()

    # 将统计量添加到共享列表中
    stats_list.append((max_val, min_val, mean_val))
    
    panel.write(x_output.replace("YYYYMMDD", str(date)), sampled_x)

def main():
    x_pattern = "/data/beef2/zifan/shared/bk2_terms/terms.YYYYMMDD.sdiv"
    x_output = "/data/beef2/zifan/shared/label_10m_downsample/bk2_terms/terms.YYYYMMDD.sdiv"

    os.makedirs(os.path.dirname(x_output), exist_ok=True)
    
    dates = find_dates_from_pattern(x_pattern)
    n = 2  # 配置降采样的步长，比如3-1降采样
    dim = 2

    manager = Manager()
    stats_list = manager.list()  # 用于存储各个进程计算的统计量

    pool = Pool(processes=64)

    tasks = [(date, x_pattern, x_output, n, dim, stats_list) for date in dates]
    
    for _ in tqdm(pool.imap_unordered(process_date, tasks), total=len(dates)):
        pass
    
    pool.close()
    pool.join()

    # 计算全局最大值、最小值和均值
    all_max_vals, all_min_vals, all_mean_vals = zip(*stats_list)
    
    global_max = max(all_max_vals)
    global_min = min(all_min_vals)
    global_mean = sum(all_mean_vals) / len(all_mean_vals)

    print(f"Global Max: {global_max}")
    print(f"Global Min: {global_min}")
    print(f"Global Mean: {global_mean}")

if __name__ == "__main__":
    main()
