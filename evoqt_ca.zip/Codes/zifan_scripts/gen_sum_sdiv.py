import os
import re
import argparse
import numpy as np
import xarray as xr
import panel
import glob
from tqdm import tqdm
import hdf5plugin
from multiprocessing import Pool

def get_next_n_trading_files(dates, current_date, n):
    current_index = dates.index(current_date)
    if current_index + n < len(dates):
        return dates[current_index:current_index + n]  # Include current date
    else:
        return dates[current_index:]

def calculate_sum_label(dates, input_pattern, date, horizon, features_to_calculate):
    unit = horizon[-1]
    t = int(horizon[:-1])

    if unit != 'd':
        raise ValueError("Sum label calculation is only applicable for daily horizons.")

    next_dates = get_next_n_trading_files(dates, date, t)
    sum_data = None
    for next_date in next_dates:
        next_file = input_pattern.replace('YYYYMMDD', str(next_date))
        next_sdiv_data = panel.read_v1(next_file)
        if sum_data is None:
            sum_data = next_sdiv_data.sel(V=features_to_calculate).values
        else:
            sum_data += next_sdiv_data.sel(V=features_to_calculate).values
    return sum_data

def generate_new_feature_name(feature, horizon):
    time_unit = horizon[-1]
    time_value = int(horizon[:-1])
    
    if time_unit == 'd':
        hours = time_value * 24
    elif time_unit == 'h':
        hours = time_value
    else:
        raise ValueError("Unknown time unit for feature naming.")
    
    # 尝试替换特征名中的模式
    new_feature_name = re.sub(r'\d+h', f'{hours}h', feature)
    
    # 如果没有匹配到模式，则在末尾添加'{hours}h'
    if new_feature_name == feature:
        new_feature_name = f'{feature}{hours}h'
    
    return new_feature_name

def create_label_sdiv_file(input_pattern, date, horizon_list, output_file, features_list, full_print=False):
    dates = find_dates_from_pattern(input_pattern)
    
    input_file = input_pattern.replace('YYYYMMDD', str(date))
    sdiv_data = panel.read_v1(input_file)
    S, D, I, V = sdiv_data.coords['S'], sdiv_data.coords['D'], sdiv_data.coords['I'], sdiv_data.coords['V']
    
    if features_list:
        features_to_calculate = features_list
    else:
        features_to_calculate = V.values

    if full_print:
        print(dates)
        print(V.values)
    
    sum_labels = []
    for horizon in horizon_list:
        unit = horizon[-1]
        if unit == 'd':
            sum_labels.append(calculate_sum_label(dates, input_pattern, date, horizon, features_to_calculate))
        else:
            raise ValueError(f"Unknown time unit: {unit}")

    combined_values = np.concatenate(sum_labels, axis=-1)
    new_V_combined = [generate_new_feature_name(v, time) for time in horizon_list if time[-1] == 'd' for v in features_to_calculate]

    label_sdiv_data = xr.DataArray(combined_values, coords=[S, D, I, new_V_combined], dims=['S', 'D', 'I', 'V'])
    label_sdiv_data = label_sdiv_data.fillna(0)
    panel.write_v1(output_file, label_sdiv_data)

def find_dates_from_pattern(pattern, warmup=0):
    files = glob.glob(pattern.replace("YYYYMMDD", "*"))
    result = []
    for f in files:
        result += re.findall(pattern.replace("YYYYMMDD", "(\d{8})"), f)
    return sorted([int(i) for i in result])[warmup:]

def process_date(args, date, full_print):
    output_file = args.output_pattern.replace('YYYYMMDD', str(date))
    create_label_sdiv_file(
        input_pattern=args.pattern,
        date=date,
        horizon_list=args.fwd_horizons,
        output_file=output_file,
        features_list=args.features,
        full_print=full_print,
    )

def initializer(args, full_print):
    global global_args
    global global_full_print
    global_args = args
    global_full_print = full_print

def process_date_wrapper(date):
    return process_date(global_args, date, global_full_print)


if __name__ == "__main__":
    def str_to_list(s):
        return s.split(',')

    parser = argparse.ArgumentParser()

    parser.add_argument("--pattern", type=str, required=True, help="输入文件的模式，其中 'YYYYMMDD' 将被实际日期替换。")
    parser.add_argument("--date", type=int, required=False, help="要处理的特定日期。如果未提供，将处理与模式匹配的所有日期。")
    parser.add_argument("--fwd_horizons", type=str_to_list, required=True, help="逗号分隔的前向预测时间范围列表（例如 '1d,5d,1h'）")
    parser.add_argument("--output_pattern", type=str, required=True, help="输出文件的模式，其中 'YYYYMMDD' 将被实际日期替换。")
    parser.add_argument("--features", type=str_to_list, required=False, default=None, help="逗号分隔的要计算的特征列表。如果未提供，将使用所有特征。")
    parser.add_argument("--num_workers", type=int, required=False, default=64, help="用于数据处理的子进程数量。默认为64。")
    args = parser.parse_args()
    
    if args.date:
        dates = [args.date]
        full_print = True
    else:
        dates = find_dates_from_pattern(args.pattern)
        full_print = False
        print(len(dates))

    os.makedirs(os.path.dirname(args.output_pattern), exist_ok=True)

    num_cpus = args.num_workers

    with Pool(processes=num_cpus, initializer=initializer, initargs=(args, full_print)) as pool:
        for _ in tqdm(pool.imap_unordered(process_date_wrapper, dates), total=len(dates)):
            pass
