#include <iostream>
#include <vector>
#include <unordered_map>
#include <map>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <iterator>
#include <string>
#include <iomanip>
using namespace std;

// 订单结构体定义
struct Order {
    int orderId;
    char side;       // 'b' = buy, 's' = sell
    int size;
    double price;
};

// 消息结构体定义（保留核心字段，补充TRD相关）
struct Msg {
    string DATE;
    double TIME;
    string RIC;
    string MSG;      // 事件类型（Cxl/TRD/ADD/DEL等）
    char SIDE;       // 订单方向
    double PRICE;    // 订单价格
    int SIZE;        // 订单数量（TRD时为成交数量，Cxl时为撤单订单原数量）
    int ORDER_ID;    // 订单ID（TRD时为被成交订单ID，Cxl时为被撤单订单ID）
    // 其他无关字段可根据实际场景补充
};

// 订单簿类（保持之前扩展的接口）
class OrderBook {
private:
    unordered_map<int, Order> orderMap;
    map<double, vector<int>, greater<double>> bids;  // 买盘：价格降序
    map<double, vector<int>, less<double>> asks;     // 卖盘：价格升序

    // 辅助函数：计算指定价格之前所有档位的总size（内部使用）
    int calculatePrevLevelsTotalSize(char side, double targetPrice) {
        int total = 0;
        if (side == 'b') {
            // 买盘：前序档位 = 价格 > targetPrice 的所有档位
            for (const auto& [price, orderIds] : bids) {
                if (price <= targetPrice) break;  // 降序排列，遇到<=目标价则停止
                for (int id : orderIds) {
                    auto it = orderMap.find(id);
                    if (it != orderMap.end()) total += it->second.size();
                }
            }
        } else if (side == 's') {
            // 卖盘：前序档位 = 价格 < targetPrice 的所有档位
            for (const auto& [price, orderIds] : asks) {
                if (price >= targetPrice) break;  // 升序排列，遇到>=目标价则停止
                for (int id : orderIds) {
                    auto it = orderMap.find(id);
                    if (it != orderMap.end()) total += it->second.size();
                }
            }
        }
        return total;
    }

public:
    // 新增订单
    void newOrder(int orderId, char side, int size, double price) {
        Order o{orderId, side, size, price};
        orderMap[orderId] = o;
        if (side == 'b') bids[price].push_back(orderId);
        else asks[price].push_back(orderId);
    }

    // 减少订单数量（TRD成交时会触发此操作，减少对应订单size）
    void reduceOrder(int orderId, int newSize) {
        if (!orderMap.count(orderId)) return;
        orderMap[orderId].size = newSize;
        if (newSize == 0) deleteOrder(orderId);
    }

    // 修改订单（删旧挂新）
    void modifyOrder(int oldOrderId, int orderId, char side, int size, double price) {
        deleteOrder(oldOrderId);
        newOrder(orderId, side, size, price);
    }

    // 删除订单
    void deleteOrder(int orderId) {
        if (!orderMap.count(orderId)) return;
        Order o = orderMap[orderId];
        auto& targetBook = (o.side == 'b') ? bids : asks;
        auto priceIt = targetBook.find(o.price);
        if (priceIt == targetBook.end()) return;

        auto& orderList = priceIt->second;
        orderList.erase(remove(orderList.begin(), orderList.end(), orderId), orderList.end());
        if (orderList.empty()) targetBook.erase(priceIt);
        orderMap.erase(orderId);
    }

    // 获取档位数量
    int getNumLevels(char side) {
        return (side == 'b') ? bids.size() : asks.size();
    }

    // 获取指定档位价格
    double getLevelPrice(char side, int level) {
        if (level < 0) return NAN;
        auto& targetBook = (side == 'b') ? bids : asks;
        if (level >= (int)targetBook.size()) return NAN;
        auto it = targetBook.begin();
        advance(it, level);
        return it->first;
    }

    // 获取指定档位总数量
    int getLevelSize(char side, int level) {
        if (level < 0) return 0;
        auto& targetBook = (side == 'b') ? bids : asks;
        if (level >= (int)targetBook.size()) return 0;
        auto it = targetBook.begin();
        advance(it, level);
        int total = 0;
        for (int id : it->second) total += orderMap[id].size;
        return total;
    }

    // 获取指定档位订单笔数
    int getLevelOrderCount(char side, int level) {
        if (level < 0) return 0;
        auto& targetBook = (side == 'b') ? bids : asks;
        if (level >= (int)targetBook.size()) return 0;
        auto it = targetBook.begin();
        advance(it, level);
        return it->second.size();
    }

    // 获取指定价格档位的订单列表（供外部查询）
    vector<int>* getLevelOrders(char side, double price) {
        auto& targetBook = (side == 'b') ? bids : asks;
        auto priceIt = targetBook.find(price);
        return (priceIt != targetBook.end()) ? &(priceIt->second) : nullptr;
    }

    // 获取订单映射（供外部查询订单详情）
    const unordered_map<int, Order>& getOrderMap() const {
        return orderMap;
    }

    // 计算指定订单所在档位之前的所有档位总size
    int getPrevLevelsTotalSize(char side, double targetPrice) {
        return calculatePrevLevelsTotalSize(side, targetPrice);
    }

    // 获取指定价格档位的总size
    int getLevelTotalSize(char side, double price) {
        auto& targetBook = (side == 'b') ? bids : asks;
        auto priceIt = targetBook.find(price);
        if (priceIt == targetBook.end()) return 0;

        int total = 0;
        for (int id : priceIt->second) {
            auto it = orderMap.find(id);
            if (it != orderMap.end()) total += it->second.size();
        }
        return total;
    }
};

// -------------------------- 全局统计变量 --------------------------
// 1. Cxl_priority_glob相关（原有因子）
vector<double> g_buy_cxl_priority;
vector<double> g_sell_cxl_priority;

// 2. Cxl_trd因子相关（新增）
// 跟踪订单的成交记录：orderId -> (成交次数, 累计成交size)
unordered_map<int, pair<int, int>> g_order_trade_records;
// 1分钟内Cxl_trd统计：买卖双方分别的（频率、总成交次数、总成交size）
struct CxlTrdStats {
    int freq = 0;         // 频率（Cxl_trd订单数量）
    int total_trade_cnt = 0;  // 累计成交次数
    int total_trade_size = 0; // 累计成交size
};
CxlTrdStats g_buy_cxl_trd;
CxlTrdStats g_sell_cxl_trd;

// -------------------------- 辅助函数（新增） --------------------------
// 计算BS系列衍生指标
void calculateBSIndices(double b_val, double s_val, double& bsdiff, double& bsimb, double& bslog) {
    bsdiff = b_val - s_val;
    // BSimb：分母为0时设为0
    double sum = b_val + s_val;
    bsimb = (sum == 0) ? 0.0 : (bsdiff / sum);
    // BSlog：避免log(0)，加1偏移
    bslog = log((1.0 + b_val) / (1.0 + s_val));
}

// -------------------------- 原有因子逻辑（保持不变） --------------------------
void OnMsgChange_CxlPriority(const Msg& msg, const OrderBook& ob) {
    if (msg.MSG != "Cxl") return;

    int cxlOrderId = msg.ORDER_ID;
    const auto& orderMap = ob.getOrderMap();
    auto orderIt = orderMap.find(cxlOrderId);
    if (orderIt == orderMap.end()) return;
    const Order& cxlOrder = orderIt->second;
    char side = cxlOrder.side;
    double targetPrice = cxlOrder.price;

    // 计算前序档位总size
    int prevLevelsTotal = ob.getPrevLevelsTotalSize(side, targetPrice);
    // 获取当前档位信息
    vector<int>* levelOrders = ob.getLevelOrders(side, targetPrice);
    if (!levelOrders) return;
    int currentLevelTotal = ob.getLevelTotalSize(side, targetPrice);
    // 计算本档位当前订单前的size
    auto orderPos = find(levelOrders->begin(), levelOrders->end(), cxlOrderId);
    if (orderPos == levelOrders->end()) return;
    int idx = distance(levelOrders->begin(), orderPos);
    int currentLevelPrevSum = 0;
    for (int i = 0; i < idx; ++i) {
        auto it = orderMap.find((*levelOrders)[i]);
        if (it != orderMap.end()) currentLevelPrevSum += it->second.size();
    }

    // 计算Cxl_priority_glob
    double cxlPriority = 0.0;
    int denominator = prevLevelsTotal + currentLevelTotal;
    if (denominator != 0) {
        int numerator = prevLevelsTotal + currentLevelPrevSum;
        cxlPriority = static_cast<double>(numerator) / denominator;
    }

    // 按方向存储
    if (side == 'b') g_buy_cxl_priority.push_back(cxlPriority);
    else if (side == 's') g_sell_cxl_priority.push_back(cxlPriority);
}

// -------------------------- 新增Cxl_trd因子逻辑 --------------------------
void OnMsgChange_CxlTrd(const Msg& msg, const OrderBook& ob) {
    // 第一步：处理TRD事件，记录订单成交记录
    if (msg.MSG == "TRD") {
        int tradedOrderId = msg.ORDER_ID;
        const auto& orderMap = ob.getOrderMap();
        // 确认订单存在（避免无效TRD事件）
        if (orderMap.count(tradedOrderId) == 0) return;

        // 更新成交记录：成交次数+1，累计size+本次成交size
        auto& [trade_cnt, trade_size] = g_order_trade_records[tradedOrderId];
        trade_cnt++;
        trade_size += msg.SIZE;
        return;
    }

    // 第二步：处理Cxl事件，识别Cxl_trd订单并统计
    if (msg.MSG != "Cxl") return;

    int cxlOrderId = msg.ORDER_ID;
    const auto& orderMap = ob.getOrderMap();
    // 条件1：订单存在
    auto orderIt = orderMap.find(cxlOrderId);
    if (orderIt == orderMap.end()) return;
    const Order& cxlOrder = orderIt->second;
    char side = cxlOrder.side;

    // 条件2：订单有过成交记录（存在于g_order_trade_records且成交次数>0）
    if (g_order_trade_records.count(cxlOrderId) == 0) return;
    auto [trade_cnt, trade_size] = g_order_trade_records[cxlOrderId];
    if (trade_cnt == 0) return;

    // 符合Cxl_trd定义，更新对应方向统计
    CxlTrdStats& stats = (side == 'b') ? g_buy_cxl_trd : g_sell_cxl_trd;
    stats.freq++;                  // 频率+1
    stats.total_trade_cnt += trade_cnt;  // 累计成交次数叠加
    stats.total_trade_size += trade_size; // 累计成交size叠加

    // （可选）移除已撤单的订单成交记录，避免重复统计（若订单不会被重复挂单）
    g_order_trade_records.erase(cxlOrderId);
}

// -------------------------- 统一事件处理入口 --------------------------
void OnMsgChange(const Msg& msg, const OrderBook& ob, const string& event) {
    // 同时处理两个因子
    OnMsgChange_CxlPriority(msg, ob);
    OnMsgChange_CxlTrd(msg, ob);
}

// -------------------------- 快照统计函数（新增Cxl_trd指标输出） --------------------------
void OnSnapshot() {
    cout << "===================== 1min Snapshot Statistics =====================" << endl;
    cout << fixed << setprecision(6);  // 统一精度输出

    // -------------------------- 原有Cxl_priority_glob指标 --------------------------
    cout << "\n[1] Cxl_priority_glob指标：" << endl;
    double avgBuyPriority = g_buy_cxl_priority.empty() ? 0.0 : 
        accumulate(g_buy_cxl_priority.begin(), g_buy_cxl_priority.end(), 0.0) / g_buy_cxl_priority.size();
    double avgSellPriority = g_sell_cxl_priority.empty() ? 0.0 : 
        accumulate(g_sell_cxl_priority.begin(), g_sell_cxl_priority.end(), 0.0) / g_sell_cxl_priority.size();
    double priority_bsdiff = avgBuyPriority - avgSellPriority;
    double priority_bslog = log((1.0 + avgBuyPriority) / (1.0 + avgSellPriority));
    cout << "  买盘平均值：" << avgBuyPriority << endl;
    cout << "  卖盘平均值：" << avgSellPriority << endl;
    cout << "  B-S差值：" << priority_bsdiff << endl;
    cout << "  log((1+B)/(1+S))：" << priority_bslog << endl;

    // -------------------------- 新增Cxl_trd因子指标 --------------------------
    cout << "\n[2] Cxl_trd因子指标：" << endl;

    // 2.1 频率相关
    cout << "  2.1 频率统计（单位：次/分钟）：" << endl;
    double b_freq = g_buy_cxl_trd.freq;
    double s_freq = g_sell_cxl_trd.freq;
    double freq_bsdiff, freq_bsimb, freq_bslog;
    calculateBSIndices(b_freq, s_freq, freq_bsdiff, freq_bsimb, freq_bslog);
    cout << "    买盘频率：" << b_freq << " | 卖盘频率：" << s_freq << endl;
    cout << "    BSdiff：" << freq_bsdiff << " | BSimb：" << freq_bsimb << " | BSlog：" << freq_bslog << endl;

    // 2.2 成交次数相关
    cout << "  2.2 累计成交次数统计：" << endl;
    double b_trade_cnt = g_buy_cxl_trd.total_trade_cnt;
    double s_trade_cnt = g_sell_cxl_trd.total_trade_cnt;
    double cnt_bsdiff, cnt_bsimb, cnt_bslog;
    calculateBSIndices(b_trade_cnt, s_trade_cnt, cnt_bsdiff, cnt_bsimb, cnt_bslog);
    cout << "    买盘累计成交次数：" << b_trade_cnt << " | 卖盘累计成交次数：" << s_trade_cnt << endl;
    cout << "    BSdiff：" << cnt_bsdiff << " | BSimb：" << cnt_bsimb << " | BSlog：" << cnt_bslog << endl;

    // 2.3 成交size相关
    cout << "  2.3 累计成交size统计：" << endl;
    double b_trade_size = g_buy_cxl_trd.total_trade_size;
    double s_trade_size = g_sell_cxl_trd.total_trade_size;
    double size_bsdiff, size_bsimb, size_bslog;
    calculateBSIndices(b_trade_size, s_trade_size, size_bsdiff, size_bsimb, size_bslog);
    cout << "    买盘累计成交size：" << b_trade_size << " | 卖盘累计成交size：" << s_trade_size << endl;
    cout << "    BSdiff：" << size_bsdiff << " | BSimb：" << size_bsimb << " | BSlog：" << size_bslog << endl;

    cout << "====================================================================\n" << endl;

    // -------------------------- 重置统计变量 --------------------------
    // 原有因子
    g_buy_cxl_priority.clear();
    g_sell_cxl_priority.clear();
    // 新增Cxl_trd因子
    g_order_trade_records.clear();
    g_buy_cxl_trd = CxlTrdStats{};
    g_sell_cxl_trd = CxlTrdStats{};
}

// -------------------------- 测试用例 --------------------------
int main() {
    OrderBook ob;
    // 模拟场景：订单先成交（TRD），后撤单（Cxl）
    // 1. 买盘订单：先挂单→成交2次→撤单
    ob.newOrder(10001, 'b', 500, 265.4);  // 挂买盘订单
    Msg trd1 = {"2022-08-02", 34200.05, "713.hk", "TRD", 'b', 265.4, 200, 10001};  // 第一次成交200
    Msg trd2 = {"2022-08-02", 34201.05, "714.hk", "TRD", 'b', 265.4, 150, 10001};  // 第二次成交150
    Msg cxlBuy = {"2022-08-02", 34202.05, "715.hk", "Cxl", 'b', 265.4, 150, 10001};// 撤单（剩余150未成交）

    // 2. 卖盘订单：先挂单→成交1次→撤单
    ob.newOrder(20001, 's', 400, 265.6);  // 挂卖盘订单
    Msg trd3 = {"2022-08-02", 34203.05, "716.hk", "TRD", 's', 265.6, 100, 20001};  // 成交100
    Msg cxlSell = {"2022-08-02", 34204.05, "717.hk", "Cxl", 's', 265.6, 300, 20001};// 撤单（剩余300未成交）

    // 3. 普通撤单（无成交记录，不统计为Cxl_trd）
    ob.newOrder(30001, 'b', 200, 265.2);
    Msg cxlNormal = {"2022-08-02", 34205.05, "718.hk", "Cxl", 'b', 265.2, 200, 30001};

    // 触发事件
    OnMsgChange(trd1, ob, "TRD");
    OnMsgChange(trd2, ob, "TRD");
    OnMsgChange(cxlBuy, ob, "Cxl");
    OnMsgChange(trd3, ob, "TRD");
    OnMsgChange(cxlSell, ob, "Cxl");
    OnMsgChange(cxlNormal, ob, "Cxl");

    // 触发快照统计
    OnSnapshot();

    return 0;
}


#############
DATE TIME RIC MSG SIDE PRICE SIZE ORDER_ID NOID SOLD BOID BROK 12_CHANGE ORDER_LIFET NUM LEVEL MID bid1 bid2 bid3 bid4 ask1 ask2 ask3 ask4 bp01 bp02 bp03 bp04 ap01 ap02 ap03 1248681 8/2/2022 34200.05 0700.hk BROKER_FCB B 254.2 100 100714 0 0 0 0 74863 0 74863 2 295.3 100 5200 100 1900 4100 700 165300 256.2 256 256.4 256.6 256.4 256.6 256.8 256 1248681 8/2/2022 34200.05 701.hk DEL S 254.2 100 28416 0 0 0 0 74860 6 295.1 100 5200 100 1900 4100 700 165300 256.2 256 256.4 256.6 256.4 256.6 256.8 256 1248681 8/2/2022 34200.05 702.hk BROKER_FCB B 254.2 100 28416 0 0 0 0 74860 6 295.1 100 5200 100 1900 4100 700 165300 256.2 256 256.4 256.6 256.4 256.6 256.8 256 1248681 8/2/2022 34200.05 703.hk BROKER_FCB B 254.2 100 28417 0 0 0 0 74860 6 295.1 100 5200 100 1900 4100 700 165300 256.2 256 256.4 256.6 256.4 256.6 256.8 256 1248681 8/2/2022 34200.05 704.hk BROKER_FCB B 254.2 100 28419 0 0 0 0 74860 6 295.1 100 5200 100 1900 4100 700 165300 256.2 256 256.4 256.6 256.4 256.6 256.8 256 1248681 8/2/2022 34200.05 705.hk BROKER_FCB B 254.2 100 28420 0 0 0 0 74860 6 295.1 100 5200 100 1900 4100 700 165300 256.2 256 256.4 256.6 256.4 256.6 256.8 256 1248688 8/2/2022 34200.05 706.hk ADDMOD S 260.6 400 100137 0 0 0 4981 74869 6 296.3 100 5200 100 1900 4100 700 160300 256.2 256 256.4 256.6 256.4 256.6 256.8 256 1248689 8/2/2022 34200.05 707.hk BROKER_FCB B 262 100 100137 0 0 0 0 67883 1 296.2 4000 100 1900 9000 4100 700 165300 258 258.4 258.6 258.4 258.6 258.8 258 1248689 8/2/2022 34200.05 708.hk DEL S 262 100 190137 190137 190500 0 0 67883 1 296.2 4000 100 1900 9000 4100 700 165300 258 258.4 258.6 258.4 258.6 258.8 258 1248689 8/2/2022 34200.05 709.hk REPLACE B 262 4200 100138 100508 100137 100508 0 67888 1 296.2 4000 100 1900 9000 4100 700 165300 258 258.4 258.6 258.4 258.6 258.8 258 1248694 8/2/2022 34200.05 710.hk ADDMOD B 265 100 190170 0 0 0 0 67887 1 296.2 4000 100 1900 9000 4100 700 165300 258 258.4 258.6 258.4 258.6 258.8 258 1248696 8/2/2022 34200.05 711.hk DEL S 265.4 100 190171 0 0 0 0 67911 32 296.2 4000 100 1900 9000 4100 700 164500 258 258.4 258.6 258.4 258.6 258.8 258 1248696 8/2/2022 34200.05 712.hk BROKER_FCB B 265.4 100 190171 0 0 0 0 67912 1 296.2 4000 100 1900 9000 4100 700 164500 258 258.4 258.6 258.4 258.6 258.8 258 1248698 8/2/2022 34200.05 713.hk TRD B 265.4 200 104298 104298 104298 0 0 67932 1 296.2 4000 100 1900 9000 4000 700 164500 258 258.4 258.6 258.4 258.6 258.8 258 1248698 8/2/2022 34200.05 714.hk REPLACE B 265.4 1300 104297 104298 104297 104298 0 67949 1 296.2 4000 100 1900 9000 4000 700 164500 258 258.4 258.6 258.4 258.6 258.8 258 1248700 8/2/2022 34200.05 715.hk ADDMOD S 265.6 200 104231 0 0 0 0 67961 2 296.2 4000 100 1900 9000 4000 700 164500 258 258.4 258.6 258.4 258.6 258.8 258 1248700 8/2/2022 34200.05 716.hk DEL S 265.6 200 104231 0 0 0 0 67961 2 296.2 4000 100 1900 9000 4000 700 164500 258 258.4 258.6 258.4 258.6 258.8 258 1248702 8/2/2022 34200.05 717.hk ADDMOD B 265.8 200 104298 104298 104298 0 0 67977 1 296.2 4000 100 1900 9000 4000 700 164500 258 258.4 258.6 258.4 258.6 258.8 258 1248702 8/2/2022 34200.05 718.hk DEL S 265.8 200 190260 190260 190260 0 0 67979 1 296.2 4000 100 1900 9000 4000 700 164500 258 258.4 258.6 258.4 258.6 258.8 258 1248703 8/2/2022 34200.05 719.hk TRD B 266 100 104298 0 0 0 0 67987 12 296.2 4000 100 1900 9000 2000 900 164500 258 258.4 258.6 258.4 258.6 258.8 258
我现在有L3data数据如上，存在table_df_ 

请你帮我编写python代码实现以下内容：请你给出:

过去1min内的trade个数，在ap1 trd的个数、size， 在ap2 trd的个数、size。 
过去1min内在买、卖方对面。ADDMOD的个数，size