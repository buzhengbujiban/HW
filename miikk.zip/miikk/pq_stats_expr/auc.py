# from tick_chart import tick_chart
import pqsum_py.msg_info as mi
from alpha_pq.pq_stats_expr.common import *
from pqsum_py.runner import PQSumNode
from jobs.rnodes.rnode import RNode
from pqsum_py.utils import *

# und = mi.auc

filters = {}

add_AM_filters = {}
for type_k, type_v in {
    "add": mi.auc.IsValid & mi.auc.IsAdd,
}.items():
    for side_k, side_v in {
        "B": mi.auc.IsB,
        "S": mi.auc.IsS,
    }.items():
        for size_k, size_v in {
            "AM1_Big0": mi.auc.IsValid &mi.auc.IsAM1 & is_big0(mi.auc),
            "AM1_Med0": mi.auc.IsValid &mi.auc.IsAM1 & is_med0(mi.auc),
            "AM1_Sml0": mi.auc.IsValid &mi.auc.IsAM1 & is_sml0(mi.auc),
            "AM2_Big0": mi.auc.IsValid &mi.auc.IsAM2 & is_big0(mi.auc),
            "AM2_Med0": mi.auc.IsValid &mi.auc.IsAM2 & is_med0(mi.auc),
            "AM2_Sml0": mi.auc.IsValid &mi.auc.IsAM2 & is_sml0(mi.auc),
            # "PM": mi.auc.IsValid &mi.auc.IsPM,
        }.items():
            add_AM_filters[f"auc.{side_k}.{type_k}_{size_k}"] = type_v & side_v & size_v

cxl_AM_filters = {}
for type_k, type_v in {
    "cxl": mi.auc.IsValid & mi.auc.IsCxl,
}.items():
    for side_k, side_v in {
        "B": mi.auc.IsB,
        "S": mi.auc.IsS,
    }.items():
        for size_k, size_v in {
            "AM1_Big0": mi.auc.IsValid &mi.auc.IsAM1 & is_big0(mi.auc),
            "AM1_Med0": mi.auc.IsValid &mi.auc.IsAM1 & is_med0(mi.auc),
            "AM1_Sml0": mi.auc.IsValid &mi.auc.IsAM1 & is_sml0(mi.auc),
        }.items():
            cxl_AM_filters[f"auc.{side_k}.{type_k}_{size_k}"] = type_v & side_v & size_v

trd_AM_filters = {}
for type_k, type_v in {
    "trd": mi.auc.IsValid & mi.auc.IsTrd,
}.items():
    for side_k, side_v in {
        "B": mi.auc.IsB,
        "S": mi.auc.IsS,
    }.items():
        for size_k, size_v in {
            "AM2_Big0": mi.auc.IsValid &mi.auc.IsAM2 & is_big0(mi.auc),
            "AM2_Med0": mi.auc.IsValid &mi.auc.IsAM2 & is_med0(mi.auc),
            "AM2_Sml0": mi.auc.IsValid &mi.auc.IsAM2 & is_sml0(mi.auc),
            # "PM_Big0": mi.auc.IsValid &mi.auc.IsPM& is_big0(mi.auc),
            # "PM_Med0": mi.auc.IsValid &mi.auc.IsPM& is_med0(mi.auc),
            # "PM_Sml0": mi.auc.IsValid &mi.auc.IsPM& is_sml0(mi.auc),
        }.items():
            trd_AM_filters[f"auc.{side_k}.{type_k}_{size_k}"] = type_v & side_v & size_v

add_PM_filters = {}
for type_k, type_v in {
    "add": mi.auc.IsValid & mi.auc.IsAdd,
}.items():
    for side_k, side_v in {
        "B": mi.auc.IsB,
        "S": mi.auc.IsS,
    }.items():
        for size_k, size_v in {
            # "AM1": mi.auc.IsValid &mi.auc.IsAM1,
            # "AM2": mi.auc.IsValid &mi.auc.IsAM2,
            "PM_Big0": mi.auc.IsValid &mi.auc.IsPM & is_big0(mi.auc),
            "PM_Med0": mi.auc.IsValid &mi.auc.IsPM & is_med0(mi.auc),
            "PM_Sml0": mi.auc.IsValid &mi.auc.IsPM & is_sml0(mi.auc),
        }.items():
            add_PM_filters[f"auc.{side_k}.{type_k}_{size_k}"] = type_v & side_v & size_v

trd_PM_filters = {}
for type_k, type_v in {
    "trd": mi.auc.IsValid & mi.auc.IsTrd,
}.items():
    for side_k, side_v in {
        "B": mi.auc.IsB,
        "S": mi.auc.IsS,
    }.items():
        for size_k, size_v in {
            # "AM2_Big0": mi.auc.IsValid &mi.auc.IsAM2 & is_big0(mi.auc),
            # "AM2_Med0": mi.auc.IsValid &mi.auc.IsAM2 & is_med0(mi.auc),
            # "AM2_Sml0": mi.auc.IsValid &mi.auc.IsAM2 & is_sml0(mi.auc),
            "PM_Big0": mi.auc.IsValid &mi.auc.IsPM& is_big0(mi.auc),
            "PM_Med0": mi.auc.IsValid &mi.auc.IsPM& is_med0(mi.auc),
            "PM_Sml0": mi.auc.IsValid &mi.auc.IsPM& is_sml0(mi.auc),
        }.items():
            trd_PM_filters[f"auc.{side_k}.{type_k}_{size_k}"] = type_v & side_v & size_v

pq_snaps_AM = {
    "iep_AM1" : mi.auc.IepAM1,
    "qty_AM1" : mi.auc.MatchQtyAM1,
    "iep_AM2" : mi.auc.IepAM2,
    "qty_AM2" : mi.auc.MatchQtyAM2,
    "iep_max_AM1": mi.auc.IepMaxAM1,
    "iep_max_AM2": mi.auc.IepMaxAM2,
    "iep_min_AM1": mi.auc.IepMinAM1,
    "iep_min_AM2": mi.auc.IepMinAM2,
}

pq_snaps_PM = {
    "iep_PM" : mi.auc.IepPM,
    "qty_PM" : mi.auc.MatchQtyPM,
    "iep_max_PM": mi.auc.IepMaxPM,
    "iep_min_PM": mi.auc.IepMinPM,
}

pq_stats_cq_p1 = {
    "c" :mi.ut.C(1),
    "q":mi.auc.Q,
}

pq_stats_cqpq_p1 = {
    "c" :mi.ut.C(1),
    "q":mi.auc.Q,
    "pq":mi.auc.P*mi.auc.Q,
}

# trdpre_AM_filters = {
#     "auc.B.trd_orig": mi.auc.IsValid & mi.auc.IsTrd & mi.auc.IsAM,
# }

# pq_stats_origpq_p1 = {
#     "B.trd_orig.pq":mi.auc.TrdOrigBP*mi.auc.Q,
#     "S.trd_orig.pq":mi.auc.TrdOrigAP*mi.auc.Q,
# }

terms_trdpre_AM = [
    gen_pqsum_config(
        {"auc.B.trd_orig_AM2": mi.auc.IsValid & mi.auc.IsTrd & mi.auc.IsAM2,},
        {"pq":mi.auc.TrdOrigBP*mi.auc.Q,}
    ),
    gen_pqsum_config(
        {"auc.S.trd_orig_AM2": mi.auc.IsValid & mi.auc.IsTrd & mi.auc.IsAM2,},
        {"pq":mi.auc.TrdOrigAP*mi.auc.Q,}
    )
]

terms_trdpre_PM = [
    gen_pqsum_config(
        {"auc.B.trd_orig_PM": mi.auc.IsValid & mi.auc.IsTrd & mi.auc.IsPM,},
        {"pq":mi.auc.TrdOrigBP*mi.auc.Q,}
    ),
    gen_pqsum_config(
        {"auc.S.trd_orig_PM": mi.auc.IsValid & mi.auc.IsTrd & mi.auc.IsPM,},
        {"pq":mi.auc.TrdOrigAP*mi.auc.Q,}
    )
]

terms_trdpre_eod_AM = [
    gen_pqsum_config(
        {"auc_eod.B.trd_orig_AM2": mi.auc.IsValid & mi.auc.IsTrd & mi.auc.IsAM2,},
        {"pq":mi.auc.TrdOrigBP*mi.auc.Q,}
    ),
    gen_pqsum_config(
        {"auc_eod.S.trd_orig_AM2": mi.auc.IsValid & mi.auc.IsTrd & mi.auc.IsAM2,},
        {"pq":mi.auc.TrdOrigAP*mi.auc.Q,}
    )
]

terms_trdpre_eod_PM = [
    gen_pqsum_config(
        {"auc_eod.B.trd_orig_PM": mi.auc.IsValid & mi.auc.IsTrd & mi.auc.IsPM,},
        {"pq":mi.auc.TrdOrigBP*mi.auc.Q,}
    ),
    gen_pqsum_config(
        {"auc_eod.S.trd_orig_PM": mi.auc.IsValid & mi.auc.IsTrd & mi.auc.IsPM,},
        {"pq":mi.auc.TrdOrigAP*mi.auc.Q,}
    )
]

pqsum_configs = [
    gen_pqsum_config(add_AM_filters, pq_stats_cqpq_p1),
    gen_pqsum_config(cxl_AM_filters, pq_stats_cqpq_p1),
    *terms_trdpre_AM,
    # gen_pqsum_config(trdpre_AM_filters, pq_stats_cq_p1),
    gen_pqsum_config(trd_AM_filters, pq_stats_cq_p1),
    # gen_pqsum_config(add_PM_filters, pq_stats_p1),
    # gen_pqsum_config(trd_PM_filters, pq_stats_p1),
] + [
    gen_pqsum_config_snap({"auc.BS.all": mi.auc.IsValid,}, pq_snaps_AM),
]
eod_pqsum_configs = [
    gen_pqsum_config({k.replace("auc", "auc_eod"):v for k,v in add_AM_filters.items()}, pq_stats_cqpq_p1),
    gen_pqsum_config({k.replace("auc", "auc_eod"):v for k,v in cxl_AM_filters.items()}, pq_stats_cqpq_p1),
    # gen_pqsum_config({k.replace("auc", "auc_eod"):v for k,v in trdpre_AM_filters.items()}, pq_stats_cqpq_p1),
    *terms_trdpre_eod_AM,
    gen_pqsum_config({k.replace("auc", "auc_eod"):v for k,v in trd_AM_filters.items()}, pq_stats_cq_p1),
    gen_pqsum_config({k.replace("auc", "auc_eod"):v for k,v in add_PM_filters.items()}, pq_stats_cqpq_p1),
    # gen_pqsum_config({k.replace("auc", "auc_eod"):v for k,v in trdpre_PM_filters.items()}, pq_stats_cqpq_p1),
    *terms_trdpre_eod_PM,
    gen_pqsum_config({k.replace("auc", "auc_eod"):v for k,v in trd_PM_filters.items()}, pq_stats_cq_p1),
] + [
    gen_pqsum_config_snap({"auc_eod.BS.all": mi.auc.IsValid,}, pq_snaps_AM),
    gen_pqsum_config_snap({"auc_eod.BS.all": mi.auc.IsValid,}, pq_snaps_PM),
]
