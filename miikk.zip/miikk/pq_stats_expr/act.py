from tick_chart import tick_chart
import pqsum_py.msg_info as mi
from alpha_pq.pq_stats_expr.common import *
from pqsum_py.runner import PQSumNode
from jobs.rnodes.rnode import RNode
from pqsum_py.utils import *

und = mi.act

# P  float64 // price
# Q  float64 // qty
# TS float64 // timestamp
# D  float64 // distance to bbo
# D2 float64 // distance to opposite bbo
# ID int

# N  int     // number of passive trade triggered
# LV int     // sweep level
# CL bool    // is clean sweep
# SP float64 // spread when trade happen
# LQ float64 // opposite side liquidity


# is bms
# is e10
# is tmt
# is mom/flat/rev
# is aggressive/not aggressive

# is ext
# is clean
# is spread wide
# is liquidity

def is_clsw(info):
    return info.CL

def is_spread_wide(info):
    # TODO: better to have an avg spread
    return

def is_liquid(info):
    # TODO: better to have an avg liquidity
    return

def is_limit_order(info):
    return (info.P < mi.ut.C(999999)) & (info.P > mi.ut.C(0.01))

filters = {
    "act.B.all": is_B(und),
    "act.S.all": is_S(und),
    "act.B.bbo": is_B(und) & is_bbo(und),
    "act.S.bbo": is_S(und) & is_bbo(und),
    "act.B.nbbo": is_B(und) & ~is_bbo(und),
    "act.S.nbbo": is_S(und) & ~is_bbo(und),
    "act.B.e10": is_B(und) & is_e10(und),
    "act.S.e10": is_S(und) & is_e10(und),
    "act.B.mom": is_B(und) & is_mom(und),
    "act.S.mom": is_S(und) & is_mom(und),
    "act.B.rev": is_B(und) & is_rev(und),
    "act.S.rev": is_S(und) & is_rev(und),
    "act.B.flat": is_B(und) & is_flat(und),
    "act.S.flat": is_S(und) & is_flat(und),
    "act.B.sml0": is_B(und) & is_sml0(und),
    "act.S.sml0": is_S(und) & is_sml0(und),
    "act.B.med0": is_B(und) & is_med0(und),
    "act.S.med0": is_S(und) & is_med0(und),
    "act.B.big0": is_B(und) & is_big0(und),
    "act.S.big0": is_S(und) & is_big0(und),
    "act.B.aftf": is_B(und) & is_aft_tf(und),
    "act.S.aftf": is_S(und) & is_aft_tf(und),
    "act.B.aft": is_B(und) & is_aft_trd(und),
    "act.S.aft": is_S(und) & is_aft_trd(und),
    "act.B.lead": is_B(und) & is_leading_trd(und),
    "act.S.lead": is_S(und) & is_leading_trd(und),
    "act.B.in5s": is_B(und) & is_min_op(5),
    "act.S.in5s": is_S(und) & is_min_op(5),
    "act.B.clsw": is_B(und) & is_clsw(und),
    "act.S.clsw": is_S(und) & is_clsw(und),
    "act.B.ext": is_B(und) & is_clsw(und) & is_aft_trd(und, 0.01),
    "act.S.ext": is_S(und) & is_clsw(und) & is_aft_trd(und, 0.01),
}

filters_limit = {
    "actl.B.all": is_limit_order(und) & is_B(und),
    "actl.S.all": is_limit_order(und) & is_S(und),
    "actl.B.bbo": is_limit_order(und) & is_B(und) & is_bbo(und),
    "actl.S.bbo": is_limit_order(und) & is_S(und) & is_bbo(und),
    "actl.B.nbbo": is_limit_order(und) & is_B(und) & ~is_bbo(und),
    "actl.S.nbbo": is_limit_order(und) & is_S(und) & ~is_bbo(und),
    "actl.B.e10": is_limit_order(und) & is_B(und) & is_e10(und),
    "actl.S.e10": is_limit_order(und) & is_S(und) & is_e10(und),
    "actl.B.mom": is_limit_order(und) & is_B(und) & is_mom(und),
    "actl.S.mom": is_limit_order(und) & is_S(und) & is_mom(und),
    "actl.B.rev": is_limit_order(und) & is_B(und) & is_rev(und),
    "actl.S.rev": is_limit_order(und) & is_S(und) & is_rev(und),
    "actl.B.flat": is_limit_order(und) & is_B(und) & is_flat(und),
    "actl.S.flat": is_limit_order(und) & is_S(und) & is_flat(und),
    "actl.B.sml0": is_limit_order(und) & is_B(und) & is_sml0(und),
    "actl.S.sml0": is_limit_order(und) & is_S(und) & is_sml0(und),
    "actl.B.med0": is_limit_order(und) & is_B(und) & is_med0(und),
    "actl.S.med0": is_limit_order(und) & is_S(und) & is_med0(und),
    "actl.B.big0": is_limit_order(und) & is_B(und) & is_big0(und),
    "actl.S.big0": is_limit_order(und) & is_S(und) & is_big0(und),
    "actl.B.aftf": is_limit_order(und) & is_B(und) & is_aft_tf(und),
    "actl.S.aftf": is_limit_order(und) & is_S(und) & is_aft_tf(und),
    "actl.B.aft": is_limit_order(und) & is_B(und) & is_aft_trd(und),
    "actl.S.aft": is_limit_order(und) & is_S(und) & is_aft_trd(und),
    "actl.B.lead": is_limit_order(und) & is_B(und) & is_leading_trd(und),
    "actl.S.lead": is_limit_order(und) & is_S(und) & is_leading_trd(und),
    "actl.B.in5s": is_limit_order(und) & is_B(und) & is_min_op(5),
    "actl.S.in5s": is_limit_order(und) & is_S(und) & is_min_op(5),
    "actl.B.clsw": is_limit_order(und) & is_B(und) & is_clsw(und),
    "actl.S.clsw": is_limit_order(und) & is_S(und) & is_clsw(und),
    "actl.B.ext": is_limit_order(und) & is_B(und) & is_clsw(und) & is_aft_trd(und, 0.01),
    "actl.S.ext": is_limit_order(und) & is_S(und) & is_clsw(und) & is_aft_trd(und, 0.01),
}

filters_market = {
    "actm.B.all": (~is_limit_order(und)) & is_B(und),
    "actm.S.all": (~is_limit_order(und)) & is_S(und),
    "actm.B.e10": (~is_limit_order(und)) & is_B(und) & is_e10(und),
    "actm.S.e10": (~is_limit_order(und)) & is_S(und) & is_e10(und),
    "actm.B.mom": (~is_limit_order(und)) & is_B(und) & is_mom(und),
    "actm.S.mom": (~is_limit_order(und)) & is_S(und) & is_mom(und),
    "actm.B.rev": (~is_limit_order(und)) & is_B(und) & is_rev(und),
    "actm.S.rev": (~is_limit_order(und)) & is_S(und) & is_rev(und),
    "actm.B.flat": (~is_limit_order(und)) & is_B(und) & is_flat(und),
    "actm.S.flat": (~is_limit_order(und)) & is_S(und) & is_flat(und),
    "actm.B.sml0": (~is_limit_order(und)) & is_B(und) & is_sml0(und),
    "actm.S.sml0": (~is_limit_order(und)) & is_S(und) & is_sml0(und),
    "actm.B.med0": (~is_limit_order(und)) & is_B(und) & is_med0(und),
    "actm.S.med0": (~is_limit_order(und)) & is_S(und) & is_med0(und),
    "actm.B.big0": (~is_limit_order(und)) & is_B(und) & is_big0(und),
    "actm.S.big0": (~is_limit_order(und)) & is_S(und) & is_big0(und),
}

# ((mi.act.TSO - mi.act.LastT) < mi.ut.C(thres)) & ((mi.act.TSO - mi.act.LastT) > mi.ut.C(0.001))

def is_act_aft_tf_fix(info, thres=1):
    return ((mi.act.TSO - mi.bk.TFTS) < mi.ut.C(thres)) & ((mi.act.TSO - mi.bk.TFTS) > mi.ut.C(0.001))

def is_act_aft_trd_fix(info, long_thres, short_thres):
    return ((mi.act.TSO - mi.act.LastT) < mi.ut.C(long_thres)) & ((mi.act.TSO - mi.act.LastT) > mi.ut.C(short_thres))

def is_act_leading_trd_fix(info, thres=10):
    return (mi.act.TSO - mi.act.LastT) > mi.ut.C(thres)


filters_trigger_fix = {
    "actl.B.all": is_limit_order(und) & is_B(und),
    "actl.S.all": is_limit_order(und) & is_S(und),
    "actl.B.aftf2": is_limit_order(und) & is_B(und) & is_act_aft_tf_fix(und),
    "actl.S.aftf2": is_limit_order(und) & is_S(und) & is_act_aft_tf_fix(und),
    "actl.B.aft2s": is_limit_order(und) & is_B(und) & is_act_aft_trd_fix(und, 0.1, 0.001),
    "actl.S.aft2s": is_limit_order(und) & is_S(und) & is_act_aft_trd_fix(und, 0.1, 0.001),
    "actl.B.aft2l": is_limit_order(und) & is_B(und) & is_act_aft_trd_fix(und, 1, 0.1),
    "actl.S.aft2l": is_limit_order(und) & is_S(und) & is_act_aft_trd_fix(und, 1, 0.1),
    "actl.B.lead2": is_limit_order(und) & is_B(und) & is_act_leading_trd_fix(und),
    "actl.S.lead2": is_limit_order(und) & is_S(und) & is_act_leading_trd_fix(und),
    "actl.B.ext2": is_limit_order(und) & is_B(und) & is_clsw(und) & is_act_aft_trd_fix(und, 0.1, 0.001),
    "actl.S.ext2": is_limit_order(und) & is_S(und) & is_clsw(und) & is_act_aft_trd_fix(und, 0.1, 0.001),
}

pq_stats_p1 = {
    "c":mi.ut.C(1),
    # "pq":und.P*und.Q,
}

pq_stats_p2 = {
    "d2": und.D2,
    "n":und.N,
    "sp":und.SP,
    "lq":und.LQ,
    "bp":((mi.bk.AQ0/mi.bk.TCH)-0.5)*mi.ut.DirSign(mi.add.IsS),
    "pq":und.P*und.Q,
    "im":mi.ut.Sqrt(und.P*und.Q),
}

pq_stats_p2_market = {
    "n":und.N,
    "q":und.Q,
    "sp":und.SP,
    "lq":und.LQ,
    "bp":((mi.bk.AQ0/mi.bk.TCH)-0.5)*mi.ut.DirSign(mi.add.IsS),
}

pq_stats_p3 = {
    # "pq":und.P*und.Q,
    # "im":mi.ut.Sqrt(und.P*und.Q),
}

pqsum_config = gen_pqsum_config(filters, pq_stats_p1, pq_stats_p2, pq_stats_p3)
pqsum_config_limit = gen_pqsum_config(filters_limit, pq_stats_p1, pq_stats_p2, pq_stats_p3)
# print(pqsum_config_limit)
pqsum_config_market = gen_pqsum_config(filters_market, pq_stats_p1, pq_stats_p2_market, pq_stats_p3)
pqsum_config_trigger_fix = gen_pqsum_config(filters_trigger_fix, pq_stats_p1, pq_stats_p2_market, pq_stats_p3)
