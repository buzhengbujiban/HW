# from tick_chart import tick_chart
import pqsum_py.msg_info as mi
from alpha_pq.pq_stats_expr.common import *
from pqsum_py.runner import PQSumNode
from jobs.rnodes.rnode import RNode
from pqsum_py.utils import *

und = mi.cxl

# P   float64 // price
# Q   float64 // qty
# TSS float64 // src
# TSO float64 // our
# D   float64 // distance to bbo
# D2  float64 // distance to opposite bbo
# T   float64 // lifetime
# L   float64 // level
# ID  int

# NB float64 // TODO: order num before the canceled order
# NA float64 // TODO: order num after  the canceled order
# QB float64 // TODO: shares before the canceled order
# QA float64 // TODO: shares after  the canceled order
# // TTQ  float64 // TODO: total qty before the canceled order until bbo
# // TTN  float64 // TODO: total num before the canceled order until bbo

# IsSoleOrder bool

def is_sole_order(und):
    return und.IsSoleOrder

def is_high_priority(und):
    return und.QB<und.Q+und.QA

def is_top_priority(und):
    return und.QB == 0

def is_closer(und):
    return und.D < und.Orig_D()

def is_further(und):
    return und.D > und.Orig_D()

filters = {
    "cxl.B.all": is_B(und),
    "cxl.S.all": is_S(und),
    "cxl.B.bbo": is_B(und) & is_bbo(und),
    "cxl.S.bbo": is_S(und) & is_bbo(und),
    "cxl.B.nbbo": is_B(und) & ~is_bbo(und),
    "cxl.S.nbbo": is_S(und) & ~is_bbo(und),
    "cxl.B.e10": is_B(und) & is_e10(und),
    "cxl.S.e10": is_S(und) & is_e10(und),
    "cxl.B.mom": is_B(und) & is_mom(und),
    "cxl.S.mom": is_S(und) & is_mom(und),
    "cxl.B.rev": is_B(und) & is_rev(und),
    "cxl.S.rev": is_S(und) & is_rev(und),
    "cxl.B.flat": is_B(und) & is_flat(und),
    "cxl.S.flat": is_S(und) & is_flat(und),
    "cxl.B.sml0": is_B(und) & is_sml0(und),
    "cxl.S.sml0": is_S(und) & is_sml0(und),
    "cxl.B.med0": is_B(und) & is_med0(und),
    "cxl.S.med0": is_S(und) & is_med0(und),
    "cxl.B.big0": is_B(und) & is_big0(und),
    "cxl.S.big0": is_S(und) & is_big0(und),
    "cxl.B.aftf": is_B(und) & is_aft_tf(und),
    "cxl.S.aftf": is_S(und) & is_aft_tf(und),
    "cxl.B.aft": is_B(und) & is_aft_trd(und),
    "cxl.S.aft": is_S(und) & is_aft_trd(und),
    "cxl.B.fls": is_B(und) & is_time_s(und, 10),
    "cxl.S.fls": is_S(und) & is_time_s(und, 10),
    "cxl.B.nfls": is_B(und) & is_time_l(und, 10),
    "cxl.S.nfls": is_S(und) & is_time_l(und, 10),
    "cxl.B.sol": is_B(und) & is_sole_order(und),
    "cxl.S.sol": is_S(und) & is_sole_order(und),

    "cxl.B.hp": is_B(und) & is_high_priority(und),
    "cxl.S.hp": is_S(und) & is_high_priority(und),
    "cxl.B.lp": is_B(und) & (~is_high_priority(und)),
    "cxl.S.lp": is_S(und) & (~is_high_priority(und)),
    "cxl.B.tp": is_B(und) & is_top_priority(und),
    "cxl.S.tp": is_S(und) & is_top_priority(und),
    "cxl.B.cl": is_B(und) & is_closer(und),
    "cxl.S.cl": is_S(und) & is_closer(und),
    "cxl.B.ft": is_B(und) & is_further(und),
    "cxl.S.ft": is_S(und) & is_further(und),
}

pq_stats_p1 = {
    "c":mi.ut.C(1),
}

pq_stats_p2 = {
    "qb":mi.add.QB,
    "nb":mi.add.NB,
    "sp":mi.bk.SP,
    # "bp":((mi.bk.AQ0/mi.bk.TCH)-0.5)*mi.ut.DirSign(mi.add.IsS),

    "pqrnb":mi.add.P*mi.add.Q/(mi.add.NB+1),

    # # "q":mi.add.Q,
    "dr":mi.add.D/mi.bk.MP,
    # # "pqd":mi.add.P*mi.add.Q*mi.add.D,
    "imd":mi.ut.Sqrt(mi.add.P*mi.add.Q)*mi.add.D,

    "l":mi.cxl.L,
    # "pql":mi.add.P*mi.add.Q*(mi.add.L+2),
    # # "iml":mi.ut.Sqrt(mi.add.P*mi.add.Q)*(mi.add.L+2),
    "pqrl":mi.add.P*mi.add.Q/(mi.add.L+2),
    # "imrl":mi.ut.Sqrt(mi.add.P*mi.add.Q)/(mi.add.L+2),
    "pq":mi.add.P*mi.add.Q,
    "im":mi.ut.Sqrt(mi.add.P*mi.add.Q),
}

pq_stats_p3 = {
    # "pq":mi.add.P*mi.add.Q,
    # "im":mi.ut.Sqrt(mi.add.P*mi.add.Q),
}

pqsum_config = gen_pqsum_config(filters, pq_stats_p1, pq_stats_p2, pq_stats_p3)
