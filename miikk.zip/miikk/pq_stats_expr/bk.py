from tick_chart import tick_chart
import pqsum_py.msg_info as mi
from pqsum_py.runner import PQSumNode
from pqsum_py.utils import *
from jobs.rnodes.rnode import RNode
from alpha_pq.pq_stats_expr.common import *
from pattern_helper import *

from pathlib import Path
import argparse

node_config = []

filters = {
    "all": mi.bk2.IsValid,
}

pq_stats_p1 = {}

lv_stats = [
	"P", "Q", "N", "T",
	# "TMed", 
    "TStd", "TSkew",
	"QAvg", "QStd", "QSkew",
	"MaxQ", 
    # "MaxT",
	"QBig0", "QMed0", "QSml0",
	"QL", "QS",
    # "NL", "NS", "QAvgL", "QAvgS",
    # "QStdL", "QStdS", 
    # "QSkewL", 
    # "QSkewS",
]

for side_key, side_func in [("B", mi.bk2.BVal), ("A", mi.bk2.AVal)]:
    for i in range(20):
        for stat_i, stat in enumerate(lv_stats):
            pq_stats_p1[f"bk2.{side_key}_{stat}_lv{i}"] = side_func(stat_i, i)


bk2_pqsum_config = gen_pqsum_config_snap(filters, pq_stats_p1)

# node_config = []

filters = {
    "all": mi.bk3.IsValid,
}

pq_stats_p1 = {}

lv_stats = [
			"Q", "N", "T",
			"QAvg",
			"QBig0", "QMed0", "QSml0",
			"QL", "QS",
        ]

for side_key, side_func in [("B", mi.bk3.BVal), ("A", mi.bk3.AVal)]:
    for i in range(10):
        for stat_i, stat in enumerate(lv_stats):
            pq_stats_p1[f"bk3.{side_key}_{stat}_lv{i}"] = side_func(stat_i,i)
# pq_stats_p1 = {"c":mi.ut.C(99), "MAX_LEVEL":mi.bk3.MAX_LEVEL, "AQ1":mi.bk3.AVal(0,1)}

bk3_pqsum_config = gen_pqsum_config_snap(filters, pq_stats_p1)