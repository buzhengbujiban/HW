from tick_chart import tick_chart
import pqsum_py.msg_info as mi
from pqsum_py.runner import PQSumNode
from jobs.rnodes.rnode import RNode

from alpha_pq.pq_stats_expr.common import *
from pqsum_py.utils import *

und = mi.add

# is_B = mi.add.IsValid & mi.add.IsB
# is_S = mi.add.IsValid & mi.add.IsS

# is_bbo = (mi.ut.PEQ(mi.add.P, mi.bk.AP0)|mi.ut.PEQ(mi.add.P, mi.bk.BP0))
# is_cbbo = (mi.add.D/mi.bk.MP) < 0.01
# is_e10 = mi.ut.IsE10(mi.add.Q)
# is_sml0 = mi.add.P*mi.add.Q < 40000
# is_med0 = 40000 <= mi.add.P*mi.add.Q < 200000
# is_big0 = 200000 <= mi.add.P*mi.add.Q
# is_mom = mi.ut.DirSign(mi.add.IsS) * mi.tf.TFS > 3
# is_rev = mi.ut.DirSign(mi.add.IsS) * mi.tf.TFS < -3
# is_flat = -3 <= mi.ut.DirSign(mi.add.IsS) * mi.tf.TFS <= 3
# is_aft_tf = (mi.add.TS - mi.bk.TFTS) < 0.1
# is_aft_trd = (mi.add.TS - mi.bk.TTS) < 0.1
# is_in5s = mi.bk.TSEC < 5



filters = {
    "add.B.all": is_B(und),
    "add.S.all": is_S(und),
    "add.B.bbo": is_B(und) & is_bbo(und),
    "add.S.bbo": is_S(und) & is_bbo(und),
    "add.B.nbbo": is_B(und) & ~is_bbo(und),
    "add.S.nbbo": is_S(und) & ~is_bbo(und),
    "add.B.cbbo": is_B(und) & is_cbbo(und),
    "add.S.cbbo": is_S(und) & is_cbbo(und),
    "add.B.ncbbo": is_B(und) & ~is_cbbo(und),
    "add.S.ncbbo": is_S(und) & ~is_cbbo(und),
    "add.B.e10": is_B(und) & is_e10(und),
    "add.S.e10": is_S(und) & is_e10(und),
    "add.B.mom": is_B(und) & is_mom(und),
    "add.S.mom": is_S(und) & is_mom(und),
    "add.B.rev": is_B(und) & is_rev(und),
    "add.S.rev": is_S(und) & is_rev(und),
    "add.B.flat": is_B(und) & is_flat(und),
    "add.S.flat": is_S(und) & is_flat(und),
    "add.B.sml0": is_B(und) & is_sml0(und),
    "add.S.sml0": is_S(und) & is_sml0(und),
    "add.B.med0": is_B(und) & is_med0(und),
    "add.S.med0": is_S(und) & is_med0(und),
    "add.B.big0": is_B(und) & is_big0(und),
    "add.S.big0": is_S(und) & is_big0(und),
    "add.B.aftf": is_B(und) & is_aft_tf(und),
    "add.S.aftf": is_S(und) & is_aft_tf(und),
    "add.B.aft": is_B(und) & is_aft_trd(und),
    "add.S.aft": is_S(und) & is_aft_trd(und),
    "add.B.in5s": is_B(und) & is_min_op(5),
    "add.S.in5s": is_S(und) & is_min_op(5),
}

pq_stats_p1 = {
    "c":mi.ut.C(1),
}

pq_stats_p2 = {
    "qb":mi.add.QB,
    "nb":mi.add.NB,
    "sp":mi.bk.SP,
    "bp":((mi.bk.AQ0/mi.bk.TCH)-0.5)*mi.ut.DirSign(mi.add.IsS),

    "pqrnb":mi.add.P*mi.add.Q/(mi.add.NB+1),

    # "q":mi.add.Q,
    "dr":mi.add.D/mi.bk.MP,
    # "pqd":mi.add.P*mi.add.Q*mi.add.D,
    "imd":mi.ut.Sqrt(mi.add.P*mi.add.Q)*mi.add.D,

    "l":mi.add.L,
    "pql":mi.add.P*mi.add.Q*(mi.add.L+2),
    # "iml":mi.ut.Sqrt(mi.add.P*mi.add.Q)*(mi.add.L+2),
    "pqrl":mi.add.P*mi.add.Q/(mi.add.L+2),
    # "imrl":mi.ut.Sqrt(mi.add.P*mi.add.Q)/(mi.add.L+2),

    "pq":mi.add.P*mi.add.Q,
    "im":mi.ut.Sqrt(mi.add.P*mi.add.Q),
}

pq_stats_p3 = {
    # "pq":mi.add.P*mi.add.Q,
    # "im":mi.ut.Sqrt(mi.add.P*mi.add.Q),
}

pqsum_config = gen_pqsum_config(filters, pq_stats_p1, pq_stats_p2, pq_stats_p3)