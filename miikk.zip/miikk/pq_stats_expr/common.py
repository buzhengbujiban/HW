import pqsum_py.msg_info as mi


def is_B(info):
    return info.IsValid & info.IsB

def is_S(info):
    return info.IsValid & info.IsS

def is_bbo(info):
    return (mi.ut.PEQ(info.P, mi.bk.AP0)|mi.ut.PEQ(info.P, mi.bk.BP0))

def is_cbbo(info, thres=0.01):
    return (info.D/mi.bk.MP) < mi.ut.C(thres)

def is_e10(info):
    return mi.ut.IsE10(info.Q)

def is_sml0(info, thres=40000):
    return info.P*info.Q < mi.ut.C(thres)

def is_med0(info, thres_l=40000, thres_h=200000):
    return (mi.ut.C(thres_l) <= info.P*info.Q) & (info.P*info.Q < mi.ut.C(thres_h))

def is_big0(info, thres=200000):
    return mi.ut.C(thres) <= info.P*info.Q

def is_time_l(info, thres=60):
    return info.T > mi.ut.C(thres)

def is_time_s(info, thres=60):
    return info.T >= mi.ut.C(thres)

# TODO: TFS is 12 ticks
def is_mom(info):
    return mi.ut.DirSign(info.IsS) * mi.tf.TFS > mi.ut.C(3)

def is_rev(info):
    return mi.ut.DirSign(info.IsS) * mi.tf.TFS < mi.ut.C(-3)

def is_flat(info):
    return mi.ut.C(-3) <= mi.ut.DirSign(info.IsS) * mi.tf.TFS <= mi.ut.C(3)

def is_aft_tf(info, thres=0.1):
    return (info.TSO - mi.bk.TFTS) < mi.ut.C(thres)

def is_aft_trd(info, thres=0.1):
    return (info.TSO - mi.bk.TTS) < mi.ut.C(thres)

def is_leading_trd(info, thres=10):
    return (info.TSO - mi.bk.TTS) > mi.ut.C(thres)

def is_min_op(thres=5):
    return mi.bk.TSEC < mi.ut.C(thres)

