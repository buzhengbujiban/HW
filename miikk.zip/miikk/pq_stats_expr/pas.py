from tick_chart import tick_chart
import pqsum_py.msg_info as mi
from alpha_pq.pq_stats_expr.common import *
from pqsum_py.runner import PQSumNode
from jobs.rnodes.rnode import RNode
from pqsum_py.utils import *

und = mi.pas
und_AL = mi.pas.AL
und_PL = mi.pas.PL

def is_sml0_qo(info, thres=40000):
    return info.P*info.QO < mi.ut.C(thres)

def is_med0_qo(info, thres_l=40000, thres_h=200000):
    return (mi.ut.C(thres_l) <= info.P*info.QO) & (info.P*info.QO < mi.ut.C(thres_h))

def is_big0_qo(info, thres=200000):
    return mi.ut.C(thres) <= info.P*info.QO

filters = {
    "pas.B.all": is_B(und),
    "pas.S.all": is_S(und),
    "pas.B.BB": is_B(und) & is_big0(und_AL) & is_big0(und_PL),
    "pas.S.BB": is_S(und) & is_big0(und_AL) & is_big0(und_PL),
    "pas.B.BM": is_B(und) & is_big0(und_AL) & is_med0(und_PL),
    "pas.S.BM": is_S(und) & is_big0(und_AL) & is_med0(und_PL),
    "pas.B.BS": is_B(und) & is_big0(und_AL) & is_sml0(und_PL),
    "pas.S.BS": is_S(und) & is_big0(und_AL) & is_sml0(und_PL),
    "pas.B.MB": is_B(und) & is_med0(und_AL) & is_big0(und_PL),
    "pas.S.MB": is_S(und) & is_med0(und_AL) & is_big0(und_PL),
    "pas.B.MM": is_B(und) & is_med0(und_AL) & is_med0(und_PL),
    "pas.S.MM": is_S(und) & is_med0(und_AL) & is_med0(und_PL),
    "pas.B.MS": is_B(und) & is_med0(und_AL) & is_sml0(und_PL),
    "pas.S.MS": is_S(und) & is_med0(und_AL) & is_sml0(und_PL),
    "pas.B.SB": is_B(und) & is_sml0(und_AL) & is_big0(und_PL),
    "pas.S.SB": is_S(und) & is_sml0(und_AL) & is_big0(und_PL),
    "pas.B.SM": is_B(und) & is_sml0(und_AL) & is_med0(und_PL),
    "pas.S.SM": is_S(und) & is_sml0(und_AL) & is_med0(und_PL),
    "pas.B.SS": is_B(und) & is_sml0(und_AL) & is_sml0(und_PL),
    "pas.S.SS": is_S(und) & is_sml0(und_AL) & is_sml0(und_PL),
    "pas.B.BTL": is_B(und) & is_big0(und_AL) & is_time_l(und_PL),
    "pas.S.BTL": is_S(und) & is_big0(und_AL) & is_time_l(und_PL),
    "pas.B.BTS": is_B(und) & is_big0(und_AL) & is_time_s(und_PL),
    "pas.S.BTS": is_S(und) & is_big0(und_AL) & is_time_s(und_PL),
    "pas.B.MTL": is_B(und) & is_med0(und_AL) & is_time_l(und_PL),
    "pas.S.MTL": is_S(und) & is_med0(und_AL) & is_time_l(und_PL),
    "pas.B.MTS": is_B(und) & is_med0(und_AL) & is_time_s(und_PL),
    "pas.S.MTS": is_S(und) & is_med0(und_AL) & is_time_s(und_PL),
    "pas.B.STL": is_B(und) & is_sml0(und_AL) & is_time_l(und_PL),
    "pas.S.STL": is_S(und) & is_sml0(und_AL) & is_time_l(und_PL),
    "pas.B.STS": is_B(und) & is_sml0(und_AL) & is_time_s(und_PL),
    "pas.S.STS": is_S(und) & is_sml0(und_AL) & is_time_s(und_PL),
}

filters_qo = {
    "pas_qo.B.all": is_B(und),
    "pas_qo.S.all": is_S(und),
    "pas_qo.B.BB": is_B(und) & is_big0(und_AL) & is_big0_qo(und_PL),
    "pas_qo.S.BB": is_S(und) & is_big0(und_AL) & is_big0_qo(und_PL),
    "pas_qo.B.BM": is_B(und) & is_big0(und_AL) & is_med0_qo(und_PL),
    "pas_qo.S.BM": is_S(und) & is_big0(und_AL) & is_med0_qo(und_PL),
    "pas_qo.B.BS": is_B(und) & is_big0(und_AL) & is_sml0_qo(und_PL),
    "pas_qo.S.BS": is_S(und) & is_big0(und_AL) & is_sml0_qo(und_PL),
    "pas_qo.B.MB": is_B(und) & is_med0(und_AL) & is_big0_qo(und_PL),
    "pas_qo.S.MB": is_S(und) & is_med0(und_AL) & is_big0_qo(und_PL),
    "pas_qo.B.MM": is_B(und) & is_med0(und_AL) & is_med0_qo(und_PL),
    "pas_qo.S.MM": is_S(und) & is_med0(und_AL) & is_med0_qo(und_PL),
    "pas_qo.B.MS": is_B(und) & is_med0(und_AL) & is_sml0_qo(und_PL),
    "pas_qo.S.MS": is_S(und) & is_med0(und_AL) & is_sml0_qo(und_PL),
    "pas_qo.B.SB": is_B(und) & is_sml0(und_AL) & is_big0_qo(und_PL),
    "pas_qo.S.SB": is_S(und) & is_sml0(und_AL) & is_big0_qo(und_PL),
    "pas_qo.B.SM": is_B(und) & is_sml0(und_AL) & is_med0_qo(und_PL),
    "pas_qo.S.SM": is_S(und) & is_sml0(und_AL) & is_med0_qo(und_PL),
    "pas_qo.B.SS": is_B(und) & is_sml0(und_AL) & is_sml0_qo(und_PL),
    "pas_qo.S.SS": is_S(und) & is_sml0(und_AL) & is_sml0_qo(und_PL),
}

pq_stats_p1 = {
    "c":mi.ut.C(1),
    "pq":und.P*und.Q,
}

pq_stats_p2 = {
    # "qb":mi.add.QB,
    # "nb":mi.add.NB,
    # "sp":mi.bk.SP,
    # "bp":((mi.bk.AQ0/mi.bk.TCH)-0.5)*mi.ut.DirSign(mi.add.IsS),

    # "pqrnb":mi.add.P*mi.add.Q/(mi.add.NB+1),

    # # "q":mi.add.Q,
    # "dr":mi.add.D/mi.bk.MP,
    # # "pqd":mi.add.P*mi.add.Q*mi.add.D,
    # "imd":mi.ut.Sqrt(mi.add.P*mi.add.Q)*mi.add.D,

    # "l":mi.cxl.L,
    # "pql":mi.add.P*mi.add.Q*(mi.add.L+2),
    # # "iml":mi.ut.Sqrt(mi.add.P*mi.add.Q)*(mi.add.L+2),
    # "pqrl":mi.add.P*mi.add.Q/(mi.add.L+2),
    # "imrl":mi.ut.Sqrt(mi.add.P*mi.add.Q)/(mi.add.L+2),
}

pq_stats_p3 = {
    # "pq":mi.add.P*mi.add.Q,
    # "im":mi.ut.Sqrt(mi.add.P*mi.add.Q),
}

pqsum_config = gen_pqsum_config(filters, pq_stats_p1, pq_stats_p2, pq_stats_p3)
pqsum_config_qo = gen_pqsum_config(filters_qo, pq_stats_p1, pq_stats_p2, pq_stats_p3)
