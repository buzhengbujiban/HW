from canopus_py.ca_expr import *
import alpha_ca.closures

# 1. bid/ask spread
# 2. impact: ret ~ sign(v)*sqrt(v) + residual, beta is resilience
# 3. amihud illiquidity = abs(ret)/v
# 4. volume/floating shares

class NUGGS:
    pass
class TERMS:
    @staticmethod
    def basic():
        spread = (ca("askPrice")-ca("bidPrice"))/(ca("askPrice")+ca("bidPrice"))

        abs_ret_o_id = ca.Abs(ca("ret.o"))*(~ca.IsFirstII())
        sqrt_v = ca.Na20(ca.NumPow(ca.Diff("dollarVolumeTotal"), 0.5))

        abs_ret = ca.TsSum(abs_ret_o_id, iih.day(1))
        sqrt_v_sum = ca.TsSum(sqrt_v, iih.day(1))
        impact_resilience = ca.Sel(ca.TsReg([abs_ret,sqrt_v_sum], iih.day(1)), "beta_0")
        impact_resiliencew5 = ca.Sel(ca.TsReg([abs_ret,sqrt_v_sum], iih.day(5)), "beta_0")
        impact_resilience1 = abs_ret/sqrt_v_sum
        impact_resilience0 = ca.Sel(ca.TsReg([abs_ret_o_id,sqrt_v], iih.day(1)), "beta_0")
        ret_sum = ca.TsSum(ca.Na20(ca("ret.o")), iih.day(1))
        v_sum = ca.TsSum(ca.Na20(ca.Diff("dollarVolumeTotal")), iih.day(1))
        amihud = ca.Abs(ret_sum)/(v_sum+ca.C(1))
        amihud1 = ca.Abs(ret_sum)/((v_sum+ca.C(1))/ca("turnover.rw22"))
        amihud2 = ca.Abs(ret_sum)/((v_sum+ca.C(1))/ca("free.mv"))

        turnover_ratio = v_sum / ca("free.mv")
        result = {
            "liq.spread":spread,
            "liq.impres":impact_resilience,
            "liq.impresw5":impact_resiliencew5,
            "liq.impres1":impact_resilience1,
            "liq.impres0":impact_resilience0,
            "liq.amihud":amihud,
            "liq.amihud1":amihud1,
            "liq.amihud2":amihud2,
            "liq.tvrate":turnover_ratio,
        }
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def amihud_iliq():
        result = {}
        v_rdcp = alpha_ca.closures.bop.rdcp({"v":ca.Diff("dollarVolumeTotal")})
        sv_rdcp = alpha_ca.closures.bop.rdcp({"sv":ca("buyNotl")-ca("sellNotl")})
        for w in [iih.day(1), iih.day(5)]:
            for t in alpha_ca.closures.bop.rdcp_types:
                ret_sum = ca.Abs(ca.TsSum(ca.Na20(ca(f"ret.{t}")), w))
                v_sum = ca.TsSum(ca.Na20(v_rdcp[f"v.{t}"]), w)
                abs_sv_sum = ca.TsSum(ca.Abs(ca.Na20(sv_rdcp[f"sv.{t}"])), w)

                result[f"ami.v.{t}.w{w}"] = ret_sum/(v_sum+ca.C(1))
                result[f"ami2.v.{t}.w{w}"] = ret_sum/((v_sum+ca.C(1))/ca("free.mv"))
                result[f"ami.sv.{t}.w{w}"] = ret_sum/(abs_sv_sum+ca.C(1))
                result[f"ami2.sv.{t}.w{w}"] = ret_sum/((abs_sv_sum+ca.C(1))/ca("free.mv"))
            for t1, t2 in alpha_ca.closures.bop.rdcp_pairs:
                ret_sum = ca.Abs(ca.TsSum(ca.Na20(ca(f"ret.{t1}")), w))
                v_sum = ca.TsSum(ca.Na20(v_rdcp[f"v.{t2}"]), w)
                abs_sv_sum = ca.TsSum(ca.Abs(ca.Na20(sv_rdcp[f"sv.{t2}"])), w)

                result[f"ami.v.x.{t1}.{t2}.w{w}"] = ret_sum/(v_sum+ca.C(1))
                result[f"ami2.v.x.{t1}.{t2}.w{w}"] = ret_sum/((v_sum+ca.C(1))/ca("free.mv"))
                result[f"ami.sv.x.{t1}.{t2}.w{w}"] = ret_sum/(abs_sv_sum+ca.C(1))
                result[f"ami2.sv.x.{t1}.{t2}.w{w}"] = ret_sum/((abs_sv_sum+ca.C(1))/ca("free.mv"))
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def impact_resilience_d():
        result = {}
        v_rdcp = alpha_ca.closures.bop.rdcp({"v":ca.TsSum(ca.Diff("dollarVolumeTotal"), iih.day(1))})
        v_rdcp = {k:ca.Abs(ca.NumPow(v_rdcp[k], 0.5)) for k in v_rdcp}
        sv_rdcp = alpha_ca.closures.bop.rdcp({"sv":ca.TsSum(ca("buyNotl")-ca("sellNotl"), iih.day(1))})
        sv_rdcp = {k:ca.Abs(ca.NumPow(sv_rdcp[k], 0.5)) for k in sv_rdcp}
        for w in [iih.day(1), iih.day(5)]:
            for t in alpha_ca.closures.bop.rdcp_types:
                abs_ret = ca.TsSum(ca.Abs(ca(f"ret.{t}"))*(~ca.IsFirstII()), iih.day(1))
                result[f"impres.d.v.{t}.w{w}"] = ca.Sel(ca.TsReg([abs_ret, v_rdcp[f"v.{t}"]], w), "beta_0")
                result[f"impres.d.sv.{t}.w{w}"] = ca.Sel(ca.TsReg([abs_ret, sv_rdcp[f"sv.{t}"]], w), "beta_0")
            for t1, t2 in alpha_ca.closures.bop.rdcp_pairs:
                abs_ret = ca.TsSum(ca.Abs(ca(f"ret.{t1}"))*(~ca.IsFirstII()), iih.day(1))
                result[f"impres.d.v.x.{t1}.{t2}.w{w}"] = ca.Sel(ca.TsReg([abs_ret, v_rdcp[f"v.{t2}"]], w), "beta_0")
                result[f"impres.d.sv.x.{t1}.{t2}.w{w}"] = ca.Sel(ca.TsReg([abs_ret, sv_rdcp[f"sv.{t2}"]], w), "beta_0")
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def impact_resilience():
        result = {}
        v_rdcp = alpha_ca.closures.bop.rdcp({"v":ca.Diff("dollarVolumeTotal")})
        v_rdcp = {k:ca.Abs(ca.NumPow(v_rdcp[k], 0.5)) for k in v_rdcp}
        sv_rdcp = alpha_ca.closures.bop.rdcp({"sv":ca("buyNotl")-ca("sellNotl")})
        sv_rdcp = {k:ca.Abs(ca.NumPow(sv_rdcp[k], 0.5)) for k in sv_rdcp}
        for w in [iih.day(1), iih.day(5)]:
            for t in alpha_ca.closures.bop.rdcp_types:
                abs_ret = ca.Abs(ca(f"ret.{t}"))*(~ca.IsFirstII())
                result[f"impres.v.{t}.w{w}"] = ca.Sel(ca.TsReg([abs_ret, v_rdcp[f"v.{t}"]], w), "beta_0")
                result[f"impres.sv.{t}.w{w}"] = ca.Sel(ca.TsReg([abs_ret, sv_rdcp[f"sv.{t}"]], w), "beta_0")
            for t1, t2 in alpha_ca.closures.bop.rdcp_pairs:
                abs_ret = ca.Abs(ca(f"ret.{t1}"))*(~ca.IsFirstII())
                result[f"impres.v.x.{t1}.{t2}.w{w}"] = ca.Sel(ca.TsReg([abs_ret, v_rdcp[f"v.{t2}"]], w), "beta_0")
                result[f"impres.sv.x.{t1}.{t2}.w{w}"] = ca.Sel(ca.TsReg([abs_ret, sv_rdcp[f"sv.{t2}"]], w), "beta_0")
        # return alpha_ca.closures.bop.rkzs(result)
        return result