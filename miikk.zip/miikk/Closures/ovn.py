from canopus_py.ca_expr import *
import alpha_ca.closures

def mild_select(v):
    abs_v = ca.Abs(ca.Na20(v))
    v_abs_std = ca.TsStd(abs_v, iih.day(1))
    v_abs_mean = ca.TsMean(abs_v, iih.day(1))
    return ca.Na20(v) * (abs_v < v_abs_mean + v_abs_std) * ~ca.IsFirstII()

def extreme_select(v):
    abs_v = ca.Abs(ca.Na20(v))
    v_abs_std = ca.TsStd(abs_v, iih.day(1))
    v_abs_mean = ca.TsMean(abs_v, iih.day(1))
    return ca.Na20(v) * (abs_v > v_abs_mean + v_abs_std) * ~ca.IsFirstII()

class NUGGS:
    pass
class TERMS:
    @staticmethod
    def mild_extreme_ret():
        result = {}
        for t in alpha_ca.closures.bop.rdcp_types:
            result["mild.ret."+t] = ca.TsSum(mild_select("ret."+t), iih.day(1))
            result["xtrm.ret."+t] = ca.TsSum(extreme_select("ret."+t), iih.day(1))
            result["mx.xr.ret."+t] = ca.RegRes(result["mild.ret."+t], result["xtrm.ret."+t])
            result["xm.xr.ret."+t] = ca.RegRes(result["xtrm.ret."+t], result["mild.ret."+t])
            result["mx.df.ret."+t] = result["mild.ret."+t] - result["xtrm.ret."+t]
            result["mx.rkdf.ret."+t] = ca.XsRank(result["mild.ret."+t]) - ca.XsRank(result["xtrm.ret."+t])
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mild_extreme_sv0():
        result = {}
        for t in alpha_ca.closures.bop.rdcp_types:
            result["mild.sv0."+t] = ca.TsSum(mild_select("sv0."+t), iih.day(1))
            result["xtrm.sv0."+t] = ca.TsSum(extreme_select("sv0."+t), iih.day(1))
            result["mx.xr.sv0."+t] = ca.RegRes(result["mild.sv0."+t], result["xtrm.sv0."+t])
            result["xm.xr.sv0."+t] = ca.RegRes(result["xtrm.sv0."+t], result["mild.sv0."+t])
            result["mx.df.sv0."+t] = result["mild.sv0."+t] - result["xtrm.sv0."+t]
            result["mx.rkdf.sv0."+t] = ca.XsRank(result["mild.sv0."+t]) - ca.XsRank(result["xtrm.sv0."+t])
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mild_extreme_sv1():
        result = {}
        for t in alpha_ca.closures.bop.rdcp_types:
            result["mild.sv1."+t] = ca.TsSum(mild_select("sv1."+t), iih.day(1))
            result["xtrm.sv1."+t] = ca.TsSum(extreme_select("sv1."+t), iih.day(1))
            result["mx.xr.sv1."+t] = ca.RegRes(result["mild.sv1."+t], result["xtrm.sv1."+t])
            result["xm.xr.sv1."+t] = ca.RegRes(result["xtrm.sv1."+t], result["mild.sv1."+t])
            result["mx.df.sv1."+t] = result["mild.sv1."+t] - result["xtrm.sv1."+t]
            result["mx.rkdf.sv1."+t] = ca.XsRank(result["mild.sv1."+t]) - ca.XsRank(result["xtrm.sv1."+t])
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def ovn_jvc():
        result = {}
        for t in alpha_ca.closures.bop.rdcp_types:
            ovn_jump = ca.TsSum(ca.Na20(f"ret.{t}")*ca.IsFirstII(), iih.day(1))
            ita_v    = ca.TsSum(ca.Diff("dollarVolumeTotal"), iih.day(1))

            # result[f"ovn.{t}.jvc"] = ca.TsCorr([ca.Abs(ovn_jump), ca.TsLag(ita_v, 1, d_mode=True)], 10, d_mode=True)
            result[f"ovn.{t}.jvc.r"] = ca.RegRes(ca.TsCorr([ca.Abs(ovn_jump), ca.TsLag(ita_v, 1, d_mode=True)], 10, d_mode=True), ca.TsSum(ca.Abs(ovn_jump), 10, d_mode=True))
            result[f"ovn.{t}.jvc.rr"] = ca.RegRes(result[f"ovn.{t}.jvc.r"], ca.TsSum(ita_v, 10, d_mode=True))

        for t in alpha_ca.closures.bop.rdcp_types:
            ovn_jump = ca.TsSum(ca.Na20(f"ret.{t}")*ca.IsFirstII(), iih.day(1))
            ita_v    = ca.TsSum(ca.Diff("dollarVolumeTotal"), iih.day(1))
            ita_v    = (ita_v - ca.TsLag(ita_v, 1, d_mode=True))

            # result[f"ovn.{t}.jvc"] = ca.TsCorr([ca.Abs(ovn_jump), ca.TsLag(ita_v, 1, d_mode=True)], 10, d_mode=True)
            result[f"ovn.{t}.jdvc.r"] = ca.RegRes(ca.TsCorr([ca.Abs(ovn_jump), ca.TsLag(ita_v, 1, d_mode=True)], 10, d_mode=True), ca.TsSum(ca.Abs(ovn_jump), 10, d_mode=True))
            result[f"ovn.{t}.jdvc.rr"] = ca.RegRes(result[f"ovn.{t}.jdvc.r"], ca.TsSum(ita_v, 10, d_mode=True))

        ita_v    = ca.TsSum(ca.Diff("dollarVolumeTotal"), iih.day(1))
        ita_v_dict = {"ita_v":ita_v}
        rdcp_ita_v = alpha_ca.closures.bop.rdcp(ita_v_dict)
        for t in alpha_ca.closures.bop.rdcp_types:
            ovn_jump = ca.TsSum(ca.Na20(f"ret.{t}")*ca.IsFirstII(), iih.day(1))
            ita_v    = rdcp_ita_v[f"ita_v.{t}"]

            # result[f"ovn.{t}.jvc"] = ca.TsCorr([ca.Abs(ovn_jump), ca.TsLag(ita_v, 1, d_mode=True)], 10, d_mode=True)
            result[f"ovn.{t}.rjvc.r"] = ca.RegRes(ca.TsCorr([ca.Abs(ovn_jump), ca.TsLag(ita_v, 1, d_mode=True)], 10, d_mode=True), ca.TsSum(ca.Abs(ovn_jump), 10, d_mode=True))
            result[f"ovn.{t}.rjvc.rr"] = ca.RegRes(result[f"ovn.{t}.rjvc.r"], ca.TsSum(ita_v, 10, d_mode=True))*ita_v

        for t1,t2 in alpha_ca.closures.bop.rdcp_pairs:
            ovn_jump = ca.TsSum(ca.Na20(f"ret.{t1}")*ca.IsFirstII(), iih.day(1))
            ita_v    = rdcp_ita_v[f"ita_v.{t2}"]

            # result[f"ovn.{t}.jvc"] = ca.TsCorr([ca.Abs(ovn_jump), ca.TsLag(ita_v, 1, d_mode=True)], 10, d_mode=True)
            result[f"ovn.{t1}.{t2}.rpjvc.r"] = ca.RegRes(ca.TsCorr([ca.Abs(ovn_jump), ca.TsLag(ita_v, 1, d_mode=True)], 10, d_mode=True), ca.TsSum(ca.Abs(ovn_jump), 10, d_mode=True))
            result[f"ovn.{t1}.{t2}.rpjvc.rr"] = ca.RegRes(result[f"ovn.{t1}.{t2}.rpjvc.r"], ca.TsSum(ita_v, 10, d_mode=True))*ita_v

        # return alpha_ca.closures.bop.rkzs(result)
        return result