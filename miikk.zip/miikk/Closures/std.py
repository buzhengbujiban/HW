from canopus_py.ca_expr import *
import alpha_ca.closures

def ret_std(terms_dict):
    result = {}
    for k, v in terms_dict.items():
        for w in [iih.min(30), iih.min(120), iih.day(1)]:  # 30min, 120min
            result[f"{k}.sd.w{w}"] = ca.TsStd(v, w, demean=False, rpii=1)
        for w in [iih.day(2)]:
            result[f"{k}.sd.w{w}"] = ca.TsStd(v, w, demean=False, rpii=2)
        for w in [iih.day(5)]:
            result[f"{k}.sd.w{w}"] = ca.TsStd(v, w, demean=False, rpii=5)
    # return alpha_ca.closures.bop.rkzs(result)
    return result

def ret_p_hl(terms_dict):
    result = {}
    for k, v in terms_dict.items():
        def ret_p_hl_term(w, rpii):
            p = ca.TsSum(v, w, rpii=rpii)+ca.C(1)
            p_h = ca.TsMax(p, w, rpii=rpii)+ca.C(1)
            p_l = ca.TsMin(p, w, rpii=rpii)+ca.C(1)
            return (p_h-p_l)/p_l
        for w in [iih.min(30), iih.min(120), iih.day(1)]:  # 30min, 120min
            result[f"{k}.phl.w{w}"] = ret_p_hl_term(w, 1)
        for w in [iih.day(2)]:
            result[f"{k}.phl.w{w}"] = ret_p_hl_term(w, 2)
        for w in [iih.day(5)]:
            result[f"{k}.phl.w{w}"] = ret_p_hl_term(w, 5)
    # return alpha_ca.closures.bop.rkzs(result)
    return result

def ret_air(terms_dict):
    result = {}
    for k, v in terms_dict.items():
        for w in [iih.min(30), iih.min(120), iih.day(1)]:  # 30min, 120min
            result[f"{k}.air.w{w}"] = ca.TsMean(ca.Abs(v), w, rpii=1)/ca.TsStd(ca.Abs(v), w, demean=False, rpii=1)
        for w in [iih.day(2)]:
            result[f"{k}.air.w{w}"] = ca.TsMean(ca.Abs(v), w, rpii=2)/ca.TsStd(ca.Abs(v), w, demean=False, rpii=2)
        for w in [iih.day(5)]:
            result[f"{k}.air.w{w}"] = ca.TsMean(ca.Abs(v), w, rpii=5)/ca.TsStd(ca.Abs(v), w, demean=False, rpii=5)
    # return alpha_ca.closures.bop.rkzs(result)
    return result

class NUGGS:
    @staticmethod
    def I_std_hld():
        hld = {
            "hld":(ca("high")-ca("low"))/ca("low"),
        }
        return alpha_ca.closures.bop.rdcp(hld)

class TERMS:
    @staticmethod
    def spec_std():
        result = {}

        for d in [1, 5]:
            w = iih.day(d)
            
            for res_type in alpha_ca.closures.bop.rdcp_res_types:
                for prj_type in alpha_ca.closures.bop.rdcp_prj_types:
                    if str(res_type) == str(prj_type):
                        continue
                    res = ca.TsStd(f"ret.{res_type}", w, demean=False, rpii=d)
                    prj = ca.TsStd(f"ret.{prj_type}", w, demean=False, rpii=d)
                    result[f"spsd.{res_type}.{prj_type}.w{w}"] = res/prj
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def spec_std_hld():
        result = {}

        for d in [1, 5]:
            w = iih.day(d)
            
            for res_type in alpha_ca.closures.bop.rdcp_res_types:
                for prj_type in alpha_ca.closures.bop.rdcp_prj_types:
                    if str(res_type) == str(prj_type):
                        continue
                    res = ca.TsStd(f"hld.{res_type}", w, demean=False, rpii=d)
                    prj = ca.TsStd(f"hld.{prj_type}", w, demean=False, rpii=d)
                    result[f"spsd.hld.{res_type}.{prj_type}.w{w}"] = res/prj
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def spec_hl():
        result = {}

        for d in [1, 5]:
            w = iih.day(d)
            
            for res_type in alpha_ca.closures.bop.rdcp_res_types:
                for prj_type in alpha_ca.closures.bop.rdcp_prj_types:
                    if str(res_type) == str(prj_type):
                        continue
                    res_p = ca.TsSum(f"ret.{res_type}", w, rpii=d)+ca.C(1)
                    res_h = ca.TsMax(res_p, w, rpii=d)+ca.C(1)
                    res_l = ca.TsMin(res_p, w, rpii=d)+ca.C(1)
                    res_hld = (res_h-res_l)/res_l

                    prj_p = ca.TsSum(f"ret.{prj_type}", w, rpii=d)+ca.C(1)
                    prj_h = ca.TsMax(prj_p, w, rpii=d)+ca.C(1)
                    prj_l = ca.TsMin(prj_p, w, rpii=d)+ca.C(1)
                    prj_hld = (prj_h-prj_l)/prj_l

                    result[f"sphl.{res_type}.{prj_type}.w{w}"] = res_hld/prj_hld
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def ret_std_ls():
        result = {}
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            std_30 = ca.TsStd("ret."+ret_type, iih.min(30), demean=False)
            std_1d = ca.TsStd("ret."+ret_type, iih.day(1), demean=False)
            std_5d = ca.TsStd("ret."+ret_type, iih.day(5), demean=False)
            result[f"sdls.sm.{ret_type}"] = ca.RegRes(std_30/std_1d, std_30)
            result[f"sdls.ml.{ret_type}"] = ca.RegRes(std_1d/std_5d, std_1d)
            result[f"sdls.sl.{ret_type}"] = ca.RegRes(std_30/std_5d, std_30)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def ret_std_dcp_hl():
        seeds = {
            **{"ret."+i:"ret."+i for i in alpha_ca.closures.bop.rdcp_types},
            **{"hld."+i:"hld."+i for i in alpha_ca.closures.bop.rdcp_types},
        }
        return ret_std(seeds)
        
    @staticmethod
    def ret_air_dcp_hl():
        seeds = {
            **{"ret."+i:"ret."+i for i in alpha_ca.closures.bop.rdcp_types},
            **{"hld."+i:"hld."+i for i in alpha_ca.closures.bop.rdcp_types},
        }
        return ret_air(seeds)
        
        
    @staticmethod
    def ret_p_hl_dcp_hl():
        seeds = {
            **{"ret."+i:"ret."+i for i in alpha_ca.closures.bop.rdcp_types},
            **{"hld."+i:"hld."+i for i in alpha_ca.closures.bop.rdcp_types},
        }
        return ret_p_hl(seeds)
    
    @staticmethod
    def ochl_std_ratio():
        result = {}
        for w in [6, 12, 48, 96]:
            hld = ca.Na20((ca("high")-ca("low"))/ca("low")-ca.C(1))
            hlwd = ca.Na20((ca.TsMax("high", w, rpii=2)-ca.TsMin("low", w, rpii=2))/ca.TsMin("low", w, rpii=2)-ca.C(1))
            oc_ret = ca.Na20((ca("open")-ca("close"))/ca("close")-ca.C(1))
            std_ratio = ca.Na20(ca.TsStd(hld, w,demean=True,rpii=2)/ca.TsStd(oc_ret, w,demean=True,rpii=2))
            std_ratio2 = ca.Na20(hlwd/ca.TsStd(oc_ret, w,demean=True,rpii=2))
            result.update({f"ochl.sd.w{w}":std_ratio})
            result.update({f"ochl.sd2.w{w}":std_ratio2})
        return result
    
    @staticmethod
    def vstd():
        result = {}
        v = ca.Diff("dollarVolumeTotal")
        v_log = ca.Log(v)
        v_ret = (v-ca.TsLag(v, 1, rpii=5))/ca.TsLag(v, 1, rpii=5)
        v_lret = (v_log-ca.TsLag(v_log, 1, rpii=5))/ca.TsLag(v_log, 1, rpii=5)
        t = ca.Diff("tradesTotal")
        t_log = ca.Log(t)
        t_ret = (t-ca.TsLag(t, 1, rpii=5))/ca.TsLag(t, 1, rpii=5)
        t_lret = (t-ca.TsLag(t, 1, rpii=5))/ca.TsLag(t, 1, rpii=5)
        
        for k,v in {
            "v":v,
            "v_ret":v_ret,
            "v_log":v_log,
            "t":t,
            "t_ret":t_ret,
            "t_log":t_log,
            "vt_res":ca.RegRes(ca.Na20(v),ca.Na20(t)),
            "tv_res":ca.RegRes(ca.Na20(t),ca.Na20(v)),
            "vt_r_res":ca.RegRes(ca.Na20(v_ret),ca.Na20(t_ret)),
            "tv_r_res":ca.RegRes(ca.Na20(t_ret),ca.Na20(v_ret)),
            "vt_l_res":ca.RegRes(ca.Na20(v_log),ca.Na20(t_log)),
            "tv_l_res":ca.RegRes(ca.Na20(t_log),ca.Na20(v_log)),
            "v_lr": v_lret,
            "t_lr": t_lret,
            "vt_lr_res":ca.RegRes(ca.Na20(v_lret),ca.Na20(t_lret)),
            "tv_lr_res":ca.RegRes(ca.Na20(t_lret),ca.Na20(v_lret)),
        }.items():
            for w in [48, 120]:
                result["vstd."+k+f".w{w}.t"] = ca.TsStd(v, w, demean=True, rpii=5)
                result["vstd."+k+f".w{w}.f"] = ca.TsStd(v, w, demean=False, rpii=5)
                result["vstd."+k+f".w{w}.ir"] = ca.TsMean(v, w, rpii=5)/ca.TsStd(v, w, demean=False, rpii=5)
                result["vstd."+k+f".w{w}.air"] = ca.TsMean(ca.Abs(v), w, rpii=5)/ca.TsStd(v, w, demean=False, rpii=5)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def spec_std_res():
        result = {}

        for d in [1, 5]:
            w = iih.day(d)
            
            for res_type in alpha_ca.closures.bop.rdcp_res_types:
                for prj_type in alpha_ca.closures.bop.rdcp_prj_types:
                    if str(res_type) == str(prj_type):
                        continue
                    res = ca.TsStd(f"ret.{res_type}", w, demean=False, rpii=d)
                    prj = ca.TsStd(f"ret.{prj_type}", w, demean=False, rpii=d)
                    result[f"spsd.res.{res_type}.{prj_type}.w{w}"] = ca.RegRes(res, prj)
                    result[f"spsd.res.{prj_type}.{res_type}.w{w}"] = ca.RegRes(prj, res)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def spec_std_hld_res():
        result = {}

        for d in [1, 5]:
            w = iih.day(d)
            
            for res_type in alpha_ca.closures.bop.rdcp_res_types:
                for prj_type in alpha_ca.closures.bop.rdcp_prj_types:
                    if str(res_type) == str(prj_type):
                        continue
                    res = ca.TsStd(f"hld.{res_type}", w, demean=False, rpii=d)
                    prj = ca.TsStd(f"hld.{prj_type}", w, demean=False, rpii=d)
                    result[f"spsd.hld.res.{res_type}.{prj_type}.w{w}"] = ca.RegRes(res, prj)
                    result[f"spsd.hld.res.{prj_type}.{res_type}.w{w}"] = ca.RegRes(prj, res)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def spec_hl_res():
        result = {}

        for d in [1, 5]:
            w = iih.day(d)
            
            for res_type in alpha_ca.closures.bop.rdcp_res_types:
                for prj_type in alpha_ca.closures.bop.rdcp_prj_types:
                    if str(res_type) == str(prj_type):
                        continue
                    res_p = ca.TsSum(f"ret.{res_type}", w, rpii=d)+ca.C(1)
                    res_h = ca.TsMax(res_p, w, rpii=d)+ca.C(1)
                    res_l = ca.TsMin(res_p, w, rpii=d)+ca.C(1)
                    res_hld = (res_h-res_l)/res_l

                    prj_p = ca.TsSum(f"ret.{prj_type}", w, rpii=d)+ca.C(1)
                    prj_h = ca.TsMax(prj_p, w, rpii=d)+ca.C(1)
                    prj_l = ca.TsMin(prj_p, w, rpii=d)+ca.C(1)
                    prj_hld = (prj_h-prj_l)/prj_l

                    result[f"sphl.res.{res_type}.{prj_type}.w{w}"] = ca.RegRes(res_hld, prj_hld)
                    result[f"sphl.res.{prj_type}.{res_type}.w{w}"] = ca.RegRes(prj_hld, res_hld)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def _ovn_itd_std():
        result = {}
        for d in [1, 5]:
            w = iih.day(d)
            for ret_type in alpha_ca.closures.bop.rdcp_types:
                full_std = ca.TsStd(f"ret.{ret_type}", w, demean=False, rpii=d)
                intraday_ret = ca.IfElse(
                    ca.IIndex() <= ca.C(1),
                    ca.C(0),
                    f"ret.{ret_type}"
                )
                ita_std  = ca.TsStd(intraday_ret, w, demean=False, rpii=d)
                result[f"itd.sdrres.{ret_type}.w{w}"] = ca.RegRes(ita_std, full_std)
                result[f"itd.sdres.{ret_type}.w{w}"] = ca.RegRes(full_std, ita_std)
                result[f"itd.ovsd.{ret_type}.w{w}"] = ca.NumPow(ca.NumPow(full_std, 2) - ca.NumPow(ita_std, 2), 0.5) / full_std
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def tod_std_v0():
        result = {}
        for d in [1, 5]:
            w = iih.day(d)
            for ret_type in alpha_ca.closures.bop.rdcp_types:
                op_ret = ca.IfElse(
                    ca.IIndex() <= ca.C(iih.min(30)),
                    ca.C(0),
                    f"ret.{ret_type}"
                )
                mh_ret = ca.IfElse(
                    (ca.IIndex() > ca.C(iih.min(30)))&(ca.IIndex() <= ca.C(iih.day(1)) -ca.C(iih.min(30))),
                    ca.C(0),
                    f"ret.{ret_type}"
                )
                ed_ret = ca.IfElse(
                    ca.IIndex() > ca.C(iih.day(1)) -ca.C(iih.min(30)),
                    ca.C(0),
                    f"ret.{ret_type}"
                )
                stds = {
                    "op": ca.TsStd(op_ret, w, demean=False, rpii=d),
                    "mh": ca.TsStd(mh_ret, w, demean=False, rpii=d),
                    "ed": ca.TsStd(ed_ret, w, demean=False, rpii=d),
                }
                for k1,v1 in stds.items():
                    for k2,v2 in stds.items():
                        if k1 == k2:
                            continue
                        result[f"tod.sd.{ret_type}.w{w}.{k1}{k2}"] = v1/v2
                        result[f"tod.sdres.{ret_type}.w{w}.{k1}{k2}"] = ca.RegRes(v1, v2)
        # return alpha_ca.closures.bop.rkzs(result)
        return result