from canopus_py.ca_expr import *
import alpha_ca.closures

short_windows = [iih.min(60)]
short_rpii = 1

def mms_basic_reg(terms_dict, windows=[iih.min(120), iih.day(1), iih.day(2), iih.day(5)], rpii=5):
    result = {}
    for k, v in terms_dict.items(): 
        for w in windows:
            mn = ca.TsMean(ca.Na20(v), w, rpii=rpii)
            sd = ca.TsStd(ca.Na20(v), w, rpii=rpii)
            sk = ca.TsSkew(ca.Na20(v), w, rpii=rpii)
            result[f"{k}.sk.w{w}"] = sk
            kt = ca.TsKurt(ca.Na20(v), w, rpii=rpii)
            result[f"{k}.kt.w{w}"] = kt

            moments = {
                "1": mn,
                "2": sd,
                "3": sk,
                "4": kt,
            }
            for i in "1234":
                for j in "1234":
                    if i!=j:
                        result[f"{k}.mms.r{i}{j}.w{w}"] = ca.RegRes(moments[i], moments[j])
    return result


def mms_risk_pair(base_type, windows=[iih.min(120), iih.day(1), iih.day(2), iih.day(5)], rpii=5):
    result = {}
    pv_type_seq = [
        ("m", "o"),("m", "b"),("b", "bp") ,("i", "ip"), ("s", "sp"), ("s3", "s3p"),
        ("o", "m"),("b", "m"),("bp", "b") ,("ip", "i"), ("sp", "s"), ("s3p", "s3"),
    ]

    for w in windows:
        for dcp_type_1, dcp_type_2 in pv_type_seq:
            v1 = ca.Na20(f"{base_type}.{dcp_type_1}")
            v2 = ca.Na20(f"{base_type}.{dcp_type_2}")

            mn1 = ca.TsMean(ca.Na20(v1), w, rpii=rpii)
            sd1 = ca.TsStd(ca.Na20(v1), w, rpii=rpii)
            sk1 = ca.TsSkew(ca.Na20(v1), w, rpii=rpii)
            result[f"{base_type}.sk.w{w}"] = sk1
            kt1 = ca.TsKurt(ca.Na20(v1), w, rpii=rpii)
            result[f"{base_type}.kt.w{w}"] = kt1

            moments1 = {
                "1": mn1,
                "2": sd1,
                "3": sk1,
                "4": kt1,
            }
            mn2 = ca.TsMean(ca.Na20(v2), w, rpii=rpii)
            sd2 = ca.TsStd(ca.Na20(v2), w, rpii=rpii)
            sk2 = ca.TsSkew(ca.Na20(v2), w, rpii=rpii)
            result[f"{base_type}.sk.w{w}"] = sk2
            kt2 = ca.TsKurt(ca.Na20(v2), w, rpii=rpii)
            result[f"{base_type}.kt.w{w}"] = kt2

            moments2 = {
                "1": mn2,
                "2": sd2,
                "3": sk2,
                "4": kt2,
            }
            for mms in "1234":
                for i,j in pv_type_seq:
                    result[f"{base_type}.mms{mms}.x.{dcp_type_1}.{dcp_type_2}.w{w}"] = moments1[mms]*moments2[mms]
                    if i != j:
                        result[f"{base_type}.mms{mms}.r.{dcp_type_1}.{dcp_type_2}.w{w}"] = ca.RegRes(moments1[mms],moments2[mms])
    return result


class NUGGS:
    pass
class TERMS:
    # TODO: fix name to be unique !!!
    @staticmethod
    def mms_basic_reg_ret():
        rets = {t:"ret."+t for t in alpha_ca.closures.bop.rdcp_types}
        # return alpha_ca.closures.bop.rkzs(mms_basic_reg(rets))
        return mms_basic_reg(rets)
    @staticmethod
    def mms_basic_reg_sv0():
        sv0s = {t:"sv0."+t for t in alpha_ca.closures.bop.rdcp_types}
        # return alpha_ca.closures.bop.rkzs(mms_basic_reg(sv0s))
        return mms_basic_reg(sv0s)
    @staticmethod
    def mms_basic_reg_sv1():
        sv1s = {t:"sv1."+t for t in alpha_ca.closures.bop.rdcp_types}
        # return alpha_ca.closures.bop.rkzs(mms_basic_reg(sv1s))
        return mms_basic_reg(sv1s)
    @staticmethod
    def mms_basic_reg_v():
        sv1s = {
            "v":ca.Na20(ca.Diff("dollarVolumeTotal")/ca("turnover.rw22")),
            "dv":ca.Na20(ca.Diff(ca.Diff("dollarVolumeTotal"))/ca("turnover.rw22")),
            "sv":ca.Na20((ca("buyNotl")-ca("sellNotl"))/ca("turnover.rw22")),
            "dsv":ca.Na20(ca.Diff(ca("buyNotl")-ca("sellNotl"))/ca("turnover.rw22")),
        }
        # return alpha_ca.closures.bop.rkzs(mms_basic_reg(sv1s))
        return mms_basic_reg(sv1s)
    @staticmethod
    def mms_risk_pair_ret():
        # return alpha_ca.closures.bop.rkzs(mms_risk_pair("ret"))
        return mms_risk_pair("ret")
    @staticmethod
    def mms_risk_pair_sv0():
        # return alpha_ca.closures.bop.rkzs(mms_risk_pair("sv0"))
        return mms_risk_pair("sv0")
    @staticmethod
    def mms_risk_pair_sv1():
        # return alpha_ca.closures.bop.rkzs(mms_risk_pair("sv1"))
        return mms_risk_pair("sv1")
    
class TERMS_SHORT:
    # TODO: fix name to be unique !!!
    @staticmethod
    def mms_basic_reg_ret():
        rets = {t:"ret."+t for t in alpha_ca.closures.bop.rdcp_types}
        return mms_basic_reg(rets, short_windows, short_rpii)
    @staticmethod
    def mms_basic_reg_sv0():
        sv0s = {t:"sv0."+t for t in alpha_ca.closures.bop.rdcp_types}
        return mms_basic_reg(sv0s, short_windows, short_rpii)
    @staticmethod
    def mms_basic_reg_sv1():
        sv1s = {t:"sv1."+t for t in alpha_ca.closures.bop.rdcp_types}
        return mms_basic_reg(sv1s, short_windows, short_rpii)
    @staticmethod
    def mms_basic_reg_v():
        sv1s = {
            "v":ca.Na20(ca.Diff("dollarVolumeTotal")/ca("turnover.rw22")),
            "dv":ca.Na20(ca.Diff(ca.Diff("dollarVolumeTotal"))/ca("turnover.rw22")),
            "sv":ca.Na20((ca("buyNotl")-ca("sellNotl"))/ca("turnover.rw22")),
            "dsv":ca.Na20(ca.Diff(ca("buyNotl")-ca("sellNotl"))/ca("turnover.rw22")),
        }
        return mms_basic_reg(sv1s, short_windows, short_rpii)
    @staticmethod
    def mms_risk_pair_ret():
        return mms_risk_pair("ret", short_windows, short_rpii)
    @staticmethod
    def mms_risk_pair_sv0():
        return mms_risk_pair("sv0", short_windows, short_rpii)
    @staticmethod
    def mms_risk_pair_sv1():
        return mms_risk_pair("sv1", short_windows, short_rpii)