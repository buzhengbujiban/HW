from canopus_py.ca_expr import *
import alpha_ca.closures


def xs_select(terms_dict, conds_dict):
    result = {}
    for kt,vt in terms_dict.items():
        for kc,vc in conds_dict.items():
            result[f"{kt}.{kc}.sz"] = ca.XsZScore(vc)*vt
            result[f"{kt}.{kc}.sk"] = ca.XsRank(vc)*vt
    return result

class NUGGS:
    pass
class TERMS:
    @staticmethod
    def xs_sel_ret_mpvd():
        w = iih.day(1)
        result = {}
        vals = {"ret."+t:"ret."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"ret."+t:ca.TsSum(ca.Na20("ret."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, alpha_ca.closures.mpv.mpvds)
        xss_sum = xs_select(vals_accum, alpha_ca.closures.mpv.mpvds)
        for k,v in xss.items():
            result[k+".d.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".d.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def xs_sel_ret_mpvh():
        w = iih.min(60)
        result = {}
        vals = {"ret."+t:"ret."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"ret."+t:(~ca.IsFirstII())*ca.TsSum(ca.Na20("ret."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, alpha_ca.closures.mpv.mpvhs)
        xss_sum = xs_select(vals_accum, alpha_ca.closures.mpv.mpvhs)
        for k,v in xss.items():
            result[k+".h.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".h.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def xs_sel_sv0_mpvd():
        w = iih.day(1)
        result = {}
        vals = {"sv0."+t:"sv0."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"sv0."+t:ca.TsSum(ca.Na20("sv0."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, alpha_ca.closures.mpv.mpvds)
        xss_sum = xs_select(vals_accum, alpha_ca.closures.mpv.mpvds)
        for k,v in xss.items():
            result[k+".d.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".d.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def xs_sel_sv0_mpvh():
        w = iih.min(60)
        result = {}
        vals = {"sv0."+t:"sv0."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"sv0."+t:ca.TsSum(ca.Na20("sv0."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, alpha_ca.closures.mpv.mpvhs)
        xss_sum = xs_select(vals_accum, alpha_ca.closures.mpv.mpvhs)
        for k,v in xss.items():
            result[k+".h.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".h.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def xs_sel_sv1_mpvd():
        w = iih.day(1)
        result = {}
        vals = {"sv1."+t:"sv1."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"sv1."+t:ca.TsSum(ca.Na20("sv1."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, alpha_ca.closures.mpv.mpvds)
        xss_sum = xs_select(vals_accum, alpha_ca.closures.mpv.mpvds)
        for k,v in xss.items():
            result[k+".d.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".d.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def xs_sel_sv1_mpvh():
        w = iih.min(60)
        result = {}
        vals = {"sv1."+t:"sv1."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"sv1."+t:ca.TsSum(ca.Na20("sv1."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, alpha_ca.closures.mpv.mpvhs)
        xss_sum = xs_select(vals_accum, alpha_ca.closures.mpv.mpvhs)
        for k,v in xss.items():
            result[k+".h.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".h.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def xs_sel_ret_mpvd_diff():
        w = iih.day(1)
        result = {}
        vals = {"ret."+t:"ret."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"ret."+t:ca.TsSum(ca.Na20("ret."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvds.items()})
        xss_sum = xs_select(vals_accum, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvds.items()})
        for k,v in xss.items():
            result[k+".d.df.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".d.df.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def xs_sel_ret_mpvh_diff():
        w = iih.min(60)
        result = {}
        vals = {"ret."+t:"ret."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"ret."+t:ca.TsSum((~ca.IsFirstII())*ca.Na20("ret."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvhs.items()})
        xss_sum = xs_select(vals_accum, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvhs.items()})
        for k,v in xss.items():
            result[k+".h.df.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".h.df.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def xs_sel_sv0_mpvd_diff():
        w = iih.day(1)
        result = {}
        vals = {"sv0."+t:"sv0."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"sv0."+t:ca.TsSum(ca.Na20("sv0."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvds.items()})
        xss_sum = xs_select(vals_accum, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvds.items()})
        for k,v in xss.items():
            result[k+".d.df.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".d.df.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def xs_sel_sv0_mpvh_diff():
        w = iih.min(60)
        result = {}
        vals = {"sv0."+t:"sv0."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"sv0."+t:ca.TsSum(ca.Na20("sv0."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvhs.items()})
        xss_sum = xs_select(vals_accum, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvhs.items()})
        for k,v in xss.items():
            result[k+".h.df.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".h.df.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def xs_sel_sv1_mpvd_diff():
        w = iih.day(1)
        result = {}
        vals = {"sv1."+t:"sv1."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"sv1."+t:ca.TsSum(ca.Na20("sv1."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvds.items()})
        xss_sum = xs_select(vals_accum, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvds.items()})
        for k,v in xss.items():
            result[k+".d.df.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".d.df.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def xs_sel_sv1_mpvh_diff():
        w = iih.min(60)
        result = {}
        vals = {"sv1."+t:"sv1."+t for t in alpha_ca.closures.bop.rdcp_types}
        vals_accum = {"sv1."+t:ca.TsSum(ca.Na20("sv1."+t), w) for t in alpha_ca.closures.bop.rdcp_types}
        xss = xs_select(vals, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvhs.items()})
        xss_sum = xs_select(vals_accum, {k+".df":ca(v)-ca.TsLag(v, w, rpii=1) for k,v in alpha_ca.closures.mpv.mpvhs.items()})
        for k,v in xss.items():
            result[k+".h.df.sa"] = ca.TsSum(ca.Na20(v), w)
        for k,v in xss_sum.items():
            result[k+".h.df.as"] = ca.TsSum(ca.Na20(v), w)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
        

class TERMS_SHORT:
    @staticmethod
    def xs_sel_ret_mpvh():
        return TERMS.xs_sel_ret_mpvh()
    @staticmethod
    def xs_sel_sv0_mpvh():
        return TERMS.xs_sel_sv0_mpvh()
    @staticmethod
    def xs_sel_sv1_mpvh():
        return TERMS.xs_sel_sv1_mpvh()
    @staticmethod
    def xs_sel_ret_mpvh_diff():
        return TERMS.xs_sel_ret_mpvh_diff()
    @staticmethod
    def xs_sel_sv0_mpvh_diff():
        return TERMS.xs_sel_sv0_mpvh_diff()
    @staticmethod
    def xs_sel_sv1_mpvh_diff():
        return TERMS.xs_sel_sv1_mpvh_diff()