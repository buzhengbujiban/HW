from canopus_py.ca_expr import *
import alpha_ca.closures


def pv_corr_clos(sv_type, corr_type, short_terms=False):
    result = {}
    pv_type_seq = [(i,i) for i in alpha_ca.closures.bop.rdcp_types]+[
        ("m", "o"),("b", "bp") ,("i", "ip"), ("s", "sp"), ("s3", "s3p"),
        ("o", "m"),("bp", "b") ,("ip", "i"), ("sp", "s"), ("s3p", "s3"),
    ]

    corr_type_dict = {
        "t":True,
        "f":False,
    }

    corr_type_bool = corr_type_dict[corr_type]

    rpii = 5
    if short_terms:
        rpii = 1

    for p_type in ["r", "p", "lr", "lp"]:
        for v_type in ["sv", "cv", "lsv", "lcv"]:
            for p_dcp_type, v_dcp_type in pv_type_seq:

                r = ca.Na20(f"ret.{p_dcp_type}")
                sv = ca.Na20(f"{sv_type}.{v_dcp_type}")

                pv_dict = {
                    "r":r,
                    "sv":sv,
                    "p": ca.TsSum(r, iih.day(1), rpii=rpii),
                    "cv": ca.TsSum(sv, iih.day(1), rpii=rpii),
                    "lr":ca.TsLag(r, 1),
                    "lsv":ca.TsLag(sv, 1),
                    "lp":ca.TsLag(ca.TsSum(r, iih.day(1), rpii=rpii), 1),
                    "lcv":ca.TsLag(ca.TsSum(sv, iih.day(1), rpii=rpii), 1),
                }

                p = pv_dict[p_type]
                v = pv_dict[v_type]

                corr_h1 = ca.TsCorr([p, v], iih.min(60), demean=corr_type_bool, rpii=1)
                result[f"pvc.{sv_type[-1]}.{p_type}.{v_type}.{p_dcp_type}.{v_dcp_type}.h1.{corr_type}"] = corr_h1
                if not short_terms:
                    corr_d1 = ca.TsCorr([p, v], iih.day(1), demean=corr_type_bool, rpii=1)
                    corr_d5 = ca.TsCorr([p, v], iih.day(5), demean=corr_type_bool, rpii=5)
                    result[f"pvc.{sv_type[-1]}.{p_type}.{v_type}.{p_dcp_type}.{v_dcp_type}.d1.{corr_type}"] = corr_d1
                    result[f"pvc.{sv_type[-1]}.{p_type}.{v_type}.{p_dcp_type}.{v_dcp_type}.d5.{corr_type}"] = corr_d5
    return result


def p_rawv_corr_clos(corr_type, short_terms=False):
    result = {}

    corr_type_dict = {
        "t":True,
        "f":False,
    }

    corr_type_bool = corr_type_dict[corr_type]

    rpii = 5
    if short_terms:
        rpii = 1


    for p_type in ["r", "p", "lr", "lp"]:
        for v_type in ["v", "lv", "dv", "dvr"]:
            for p_dcp_type in alpha_ca.closures.bop.rdcp_types:

                r = ca.Na20(f"ret.{p_dcp_type}")
                v = ca.Na20("sellNotl")+ca.Na20("buyNotl")

                p_dict = {
                    "r":r,
                    "v":v,
                    "p": ca.TsSum(r, iih.day(1), rpii=rpii),
                    "lv": ca.TsLag(v, 1),
                    "lr":ca.TsLag(r, 1),
                    "dv": v-ca.TsLag(v, 1),
                    "lp":ca.TsLag(ca.TsSum(r, iih.day(1), rpii=rpii), 1),
                    "dvr":ca.Na20((v-ca.TsLag(v, 1))/ca.TsLag(v, 1)),
                }

                p = p_dict[p_type]

                corr_h1 = ca.TsCorr([p, v], iih.min(60), demean=corr_type_bool, rpii=1)
                result[f"prvc.{p_type}.{v_type}.{p_dcp_type}.h1.{corr_type}"] = corr_h1
                if not short_terms:
                    corr_d1 = ca.TsCorr([p, v], iih.day(1), demean=corr_type_bool, rpii=1)
                    corr_d5 = ca.TsCorr([p, v], iih.day(5), demean=corr_type_bool, rpii=5)
                    result[f"prvc.{p_type}.{v_type}.{p_dcp_type}.d1.{corr_type}"] = corr_d1
                    result[f"prvc.{p_type}.{v_type}.{p_dcp_type}.d5.{corr_type}"] = corr_d5

    return result


class NUGGS:
    pass
class TERMS:
    @staticmethod
    def p_rawv_corr_t():
        return p_rawv_corr_clos("t")
    @staticmethod
    def p_rawv_corr_f():
        return p_rawv_corr_clos("f")
    @staticmethod
    def pv_corr_sv0_t():
        return pv_corr_clos("sv0", "t")
    @staticmethod
    def pv_corr_sv0_f():
        return pv_corr_clos("sv0", "f")
    @staticmethod
    def pv_corr_sv1_t():
        return pv_corr_clos("sv1", "t")
    @staticmethod
    def pv_corr_sv1_f():
        return pv_corr_clos("sv1", "f")
class TERMS_SHORT:
    @staticmethod
    def p_rawv_corr_t():
        return p_rawv_corr_clos("t", True)
    @staticmethod
    def p_rawv_corr_f():
        return p_rawv_corr_clos("f", True)
    @staticmethod
    def pv_corr_sv0_t():
        return pv_corr_clos("sv0", "t", True)
    @staticmethod
    def pv_corr_sv0_f():
        return pv_corr_clos("sv0", "f", True)
    @staticmethod
    def pv_corr_sv1_t():
        return pv_corr_clos("sv1", "t", True)
    @staticmethod
    def pv_corr_sv1_f():
        return pv_corr_clos("sv1", "f", True)