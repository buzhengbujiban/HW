from canopus_py.ca_expr import *

def rkzs(terms_dict):
    result = {}
    for k, v in terms_dict.items():
        result[f"{k}.rk"] = ca.XsRank(v)
        result[f"{k}.zs"] = ca.XsZScore(v)
    return result

def tsmn(terms_dict):
    result = {}
    for k, v in terms_dict.items():
        for w in [iih.min(30), iih.min(120), iih.day(1)]:  # 30min, 120min
            result[f"{k}.mn.w{w}"] = ca.TsMean(v, w, rpii=1)
        for w in [iih.day(2)]:
            result[f"{k}.mn.w{w}"] = ca.TsMean(v, w, rpii=2)
        for w in [iih.day(5)]:
            result[f"{k}.mn.w{w}"] = ca.TsMean(v, w, rpii=5)
    return rkzs(result)

def tsir(terms_dict):
    result = {}
    for k, v in terms_dict.items():
        for w in [iih.min(30), iih.min(120), iih.day(1)]:  # 30min, 120min
            result[f"{k}.ir.w{w}"] = ca.TsMean(v, w, rpii=1)/ca.TsStd(v, w, rpii=1)
        for w in [iih.day(2)]:
            result[f"{k}.ir.w{w}"] = ca.TsMean(v, w, rpii=2)/ca.TsStd(v, w, rpii=2)
        for w in [iih.day(5)]:
            result[f"{k}.ir.w{w}"] = ca.TsMean(v, w, rpii=5)/ca.TsStd(v, w, rpii=5)
    return rkzs(result)

def tsrk(terms_dict):
    result = {}
    for k, v in terms_dict.items():
        result[f"{k}.tk.h1"] = ca.TsRank(ca.Na20(v), 12, rpii=1)
    return result

def iirk(terms_dict, w, with_ma=False, with_lag_ma=False):
    result = {}
    for k, v in terms_dict.items():
        result[f"{k}.iirk.w{w}"] = ca.IITsRank(ca.Na20(v), w)
    keys = list(result.keys())
    if with_ma:
        for k in keys:
            result[k+".ma"] = ca.TsMean(result[k], iih.min(30), rpii=1)
    if with_lag_ma:
        for k in keys:
            result[k+".d1fma"] = ca.TsLag(ca.TsMean(result[k], iih.min(30), rpii=1), iih.day(1)-iih.min(30), rpii=1)
    return result

def iiir(terms_dict, w, with_ma=False, with_lag_ma=False):
    result = {}
    for k, v in terms_dict.items():
        result[f"{k}.iiir.w{w}"] = ca.IITsMean(ca.Na20(v), w) / ca.IITsStd(ca.Na20(v), w)
    keys = list(result.keys())
    if with_ma:
        for k in keys:
            result[k+".ma"] = ca.TsMean(result[k], iih.min(30), rpii=1)
    if with_lag_ma:
        for k in keys:
            result[k+".d1fma"] = ca.TsLag(ca.TsMean(result[k], iih.min(30), rpii=1), iih.day(1)-iih.min(30), rpii=1)
        
    return result

def iizs(terms_dict, w, with_ma=False, with_lag_ma=False):
    result = {}
    for k, v in terms_dict.items():
        result[f"{k}.iizs.w{w}"] = (ca.Na20(v) - ca.IITsMean(ca.Na20(v), w)) / ca.IITsStd(ca.Na20(v), w)
    keys = list(result.keys())
    if with_ma:
        for k in keys:
            result[k+".ma"] = ca.TsMean(result[k], iih.min(30), rpii=1)
    if with_lag_ma:
        for k in keys:
            result[k+".d1fma"] = ca.TsLag(ca.TsMean(result[k], iih.min(30), rpii=1), iih.day(1)-iih.min(30), rpii=1)
        
    return result

def tszs(terms_dict):
    result = {}
    for k, v in terms_dict.items():
        for w in [iih.min(30), iih.min(120), iih.day(1)]:
            result[f"{k}.tszs.w{w}"] = (ca.Na20(v)-ca.TsMean(v, w, rpii=1))/ca.TsStd(v, w, rpii=1)
    return rkzs(result)

rdcp_types = ["o","m","b","bp","m","i","ip","s","sp","s3","s3p",]
rdcp_res_types = ["m","b" ,"i", "s", "s3",]
rdcp_prj_types = ["o","bp","ip","sp","s3p",]
rdcp_pairs = [
    ("m", "o"),("m", "b"),("b", "bp") ,("i", "ip"), ("s", "sp"), ("s3", "s3p"),
    ("o", "m"),("b", "m"),("bp", "b") ,("ip", "i"), ("sp", "s"), ("s3p", "s3"),
]
inds_CNE5 = [
    'AEROSPCE', 'AIRLINES', 'APPAREL', 'AUTOCOMP',
    'BANKS', 'BEVTOB', 'BLDPROD', 'COMMSVCS', 'CHEMICAL', 'CONGTRD',
    'CNSTENG', 'CONMAT', 'CONSDUR', 'CONSRV', 'DIVFINAN', 'ELECEQP',
    'ENERGY', 'FOODPROD', 'FSTAPHPP', 'HDWRSE', 'HEALTH', 'MACHINRY',
    'MARINE', 'MEDIA', 'MTLMIN', 'OTHRCHEM', 'PACKGFP', 'REALEST', 'RETAIL',
    'RDRLTRAN', 'SOFTWARE', 'UTILITY',
]
stls_CNE5 = [
    'ANLYSTSN', 'BETA', 'BTOP', 'DIVYILD', 'EARNQLTY', 'EARNVAR',
    'EARNYILD', 'GROWTH', 'INDMOM', 'INVSQLTY', 'LEVERAGE', 'LIQUIDTY',
    'LTREVRSL', 'MIDCAP', 'MOMENTUM', 'PROFIT', 'RESVOL', 'SEASON',
    'STREVRSL', 'SIZE'
]

def rdcp(terms_dict, include_original=True, lite=False, types=None, reg_wgt="C(1)"):
    factors_ind = inds_CNE5
    factors_stl = stls_CNE5

    factors_s3 = [
        "SIZE", "RESVOL", "BETA"
    ]

    factors_CNE5D = factors_ind+factors_stl  # exclude "COUNTRY"

    factors_all = [ca.Na20(i) for i in factors_CNE5D]
    factors_ind = [ca.Na20(i) for i in factors_ind]
    factors_stl = [ca.Na20(i) for i in factors_stl]
    factors_s3 = [ca.Na20(i) for i in factors_s3]

    result = {}
    for k, v in terms_dict.items():
        if include_original:
            result[f"{k}.o"] = v
        # result[f"{k}.m"]   = ca.RegRes( ca.Na20(v), [ca.C(1)], bod_reg   =True)  # PBETA
        result[f"{k}.b"]   = ca.RegRes( ca.Na20(v), factors_all, bod_reg =True, w=reg_wgt)
        result[f"{k}.bp"]  = ca.RegYHat(ca.Na20(v), factors_all, bod_reg=True, w=reg_wgt)
        if not lite:
            result[f"{k}.m"]   = ca.RegRes( ca.Na20(v), ca("PBeta"), bod_reg   =True, w=reg_wgt)  # PBETA
            result[f"{k}.i"]   = ca.RegRes( ca.Na20(v), factors_ind, bod_reg =True, w=reg_wgt)
            result[f"{k}.ip"]  = ca.RegYHat(ca.Na20(v), factors_ind, bod_reg=True, w=reg_wgt)
            result[f"{k}.s"]   = ca.RegRes( ca.Na20(v), factors_stl, bod_reg =True, w=reg_wgt)
            result[f"{k}.sp"]  = ca.RegYHat(ca.Na20(v), factors_stl, bod_reg=True, w=reg_wgt)
            result[f"{k}.s3"]  = ca.RegRes( ca.Na20(v), factors_s3, bod_reg  =True, w=reg_wgt)
            result[f"{k}.s3p"] = ca.RegYHat(ca.Na20(v), factors_s3, bod_reg =True, w=reg_wgt)
    if types is not None:
        result = {k:v for k,v in result.items() if k.split(".")[-1] in types}
    return result

class NUGGS:
    pass
class TERMS:
    pass