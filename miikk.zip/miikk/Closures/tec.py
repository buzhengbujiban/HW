from canopus_py.ca_expr import *
import alpha_ca.closures

def kdj(terms_dict, d, window=None):
    if window is None:
        window = iih.day(d)
    result = {}
    for k,v in terms_dict.items():
        px = ca.C(1)+ca.TsSum(ca.Na20(v), window, rpii=d)
        result[f"kdj.{k}.{d}"] = ca.KDJ(px, window, rpii=d)
        # result[f"kdjpx.{k}.{d}"] = px
    return result


def macd(terms_dict, ws, wl):
    # window = iih.day(d)
    ii_day = iih.ii_rp_day(wl)
    result = {}
    for k,v in terms_dict.items():
        px = ca.C(1)+ca.TsSum(ca.Na20(v), wl, rpii=ii_day)
        result[f"macd.{k}.{ws}.{wl}"] = ca.TsMean(px, ws, rpii=ii_day) - ca.TsMean(px, wl, rpii=ii_day)
        # result[f"kdjpx.{k}.{d}"] = px
    return result

class NUGGS:
    pass
class TERMS:
    @staticmethod
    def kdj_rdcp():
        result = {}
        for d in [1, 5]:
            for ret_type in alpha_ca.closures.bop.rdcp_types:
                result.update(kdj({"ret."+ret_type:"ret."+ret_type}, d))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def kdj_rdcp_sv0():
        result = {}
        for d in [1, 5]:
            for ret_type in alpha_ca.closures.bop.rdcp_types:
                result.update(kdj({"sv0."+ret_type:"sv0."+ret_type}, d))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def kdj_rdcp_sv1():
        result = {}
        for d in [1, 5]:
            for ret_type in alpha_ca.closures.bop.rdcp_types:
                result.update(kdj({"sv1."+ret_type:"sv1."+ret_type}, d))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def macd_rdcp():
        result = {}
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            result.update(macd({"ret."+ret_type:"ret."+ret_type}, iih.min(30), iih.day(1)))
            result.update(macd({"ret."+ret_type:"ret."+ret_type}, iih.day(1), iih.day(5)))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def macd_rdcp_sv0():
        result = {}
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            result.update(macd({"sv0."+ret_type:"sv0."+ret_type}, iih.min(30), iih.day(1)))
            result.update(macd({"sv0."+ret_type:"sv0."+ret_type}, iih.day(1), iih.day(5)))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def macd_rdcp_sv1():
        result = {}
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            result.update(macd({"sv1."+ret_type:"sv1."+ret_type}, iih.min(30), iih.day(1)))
            result.update(macd({"sv1."+ret_type:"sv1."+ret_type}, iih.day(1), iih.day(5)))
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def rdcp_ret_iirk():
        result = alpha_ca.closures.bop.iirk({"ret."+t:"ret."+t for t in alpha_ca.closures.bop.rdcp_types}, 10, True)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def rdcp_sv0_iirk():
        result = alpha_ca.closures.bop.iirk({"sv0."+t:"sv0."+t for t in alpha_ca.closures.bop.rdcp_types}, 10, True)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def rdcp_sv1_iirk():
        result = alpha_ca.closures.bop.iirk({"sv1."+t:"sv1."+t for t in alpha_ca.closures.bop.rdcp_types}, 10, True)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def rdcp_ret_iiir():
        result = alpha_ca.closures.bop.iiir({"ret."+t:"ret."+t for t in alpha_ca.closures.bop.rdcp_types}, 10, True)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def rdcp_sv0_iiir():
        result = alpha_ca.closures.bop.iiir({"sv0."+t:"sv0."+t for t in alpha_ca.closures.bop.rdcp_types}, 10, True)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def rdcp_sv1_iiir():
        result = alpha_ca.closures.bop.iiir({"sv1."+t:"sv1."+t for t in alpha_ca.closures.bop.rdcp_types}, 10, True)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def rdcp_ret_iizs():
        result = alpha_ca.closures.bop.iizs({"ret."+t:"ret."+t for t in alpha_ca.closures.bop.rdcp_types}, 10, True)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def rdcp_sv0_iizs():
        result = alpha_ca.closures.bop.iizs({"sv0."+t:"sv0."+t for t in alpha_ca.closures.bop.rdcp_types}, 10, True)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def rdcp_sv1_iizs():
        result = alpha_ca.closures.bop.iizs({"sv1."+t:"sv1."+t for t in alpha_ca.closures.bop.rdcp_types}, 10, True)
        # return alpha_ca.closures.bop.rkzs(result)
        return result

class TERMS_SHORT:
    @staticmethod
    def kdj_rdcp():
        result = {}
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            result.update(kdj({"ret."+ret_type:"ret."+ret_type}, 1, iih.min(60)))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def kdj_rdcp_sv0():
        result = {}
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            result.update(kdj({"sv0."+ret_type:"sv0."+ret_type}, 1, iih.min(60)))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def kdj_rdcp_sv1():
        result = {}
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            result.update(kdj({"sv1."+ret_type:"sv1."+ret_type}, 1, iih.min(60)))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def macd_rdcp():
        result = {}
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            result.update(macd({"ret."+ret_type:"ret."+ret_type}, iih.min(30), iih.day(1)))
            # result.update(macd({"ret."+ret_type:"ret."+ret_type}, iih.day(1), iih.day(5)))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def macd_rdcp_sv0():
        result = {}
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            result.update(macd({"sv0."+ret_type:"sv0."+ret_type}, iih.min(30), iih.day(1)))
            # result.update(macd({"sv0."+ret_type:"sv0."+ret_type}, iih.day(1), iih.day(5)))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    
    @staticmethod
    def macd_rdcp_sv1():
        result = {}
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            result.update(macd({"sv1."+ret_type:"sv1."+ret_type}, iih.min(30), iih.day(1)))
            # result.update(macd({"sv1."+ret_type:"sv1."+ret_type}, iih.day(1), iih.day(5)))
        # return alpha_ca.closures.bop.rkzs(result)
        return result