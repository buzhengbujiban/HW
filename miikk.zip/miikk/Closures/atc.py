from canopus_py.ca_expr import *
import alpha_ca.closures

# def autocorr(terms_dict, shift, window):
#     result = {}
#     for k,v in terms_dict.items():
#         result[f"autocorr.{k}.{shift}.{window}"] = ca.TsCorr(v, ca.TsLag(v, shift), window, rpii=1)
#     return result

def atc_clos(pv_type):
    result = {}
    for shift in [1, iih.min(30)]:
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            r = ca.Na20(f"{pv_type}."+ret_type)
            v = ca.TsSum(r, iih.day(1), rpii=1)
            r_ac = ca.TsCorr([r, ca.TsLag(r, shift)], iih.day(1), rpii=1)
            v_ac = ca.TsCorr([v, ca.TsLag(v, shift)], iih.day(1), rpii=1)
            r_ac_f = ca.TsCorr([r, ca.TsLag(r, shift)], iih.day(1), demean=False, rpii=1)
            v_ac_f = ca.TsCorr([v, ca.TsLag(v, shift)], iih.day(1), demean=False, rpii=1)
            result[f"{pv_type}.{ret_type}.ac.s{shift}"] = r_ac
            result[f"{pv_type}.{ret_type}.acr.s{shift}"] = r_ac*r
            result[f"{pv_type}.{ret_type}.acrs.s{shift}"] = ca.TsSum(r_ac*r, iih.min(30))
            result[f"{pv_type}.{ret_type}.acrd.s{shift}"] = ca.TsSum(r_ac*r, iih.day(1))
            result[f"{pv_type}.{ret_type}.acvr.s{shift}"] = v_ac*r
            result[f"{pv_type}.{ret_type}.acvrs.s{shift}"] = ca.TsSum(v_ac*r, iih.min(30))
            result[f"{pv_type}.{ret_type}.acvrd.s{shift}"] = ca.TsSum(v_ac*r, iih.day(1))

            result[f"{pv_type}.{ret_type}.ac.f.s{shift}"] = r_ac_f
            result[f"{pv_type}.{ret_type}.ac.f.r.s{shift}"] = r_ac_f*r
            result[f"{pv_type}.{ret_type}.ac.f.rs.s{shift}"] = ca.TsSum(r_ac_f*r, iih.min(30))
            result[f"{pv_type}.{ret_type}.ac.f.rd.s{shift}"] = ca.TsSum(r_ac_f*r, iih.day(1))
            result[f"{pv_type}.{ret_type}.ac.f.vr.s{shift}"] = v_ac_f*r
            result[f"{pv_type}.{ret_type}.ac.f.vrs.s{shift}"] = ca.TsSum(v_ac_f*r, iih.min(30))
            result[f"{pv_type}.{ret_type}.ac.f.vrd.s{shift}"] = ca.TsSum(v_ac_f*r, iih.day(1))
    # return alpha_ca.closures.bop.rkzs(result)
    return result

def atc_clos_short(pv_type):
    result = {}
    for shift in [iih.min(5)]:
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            r = ca.Na20(f"{pv_type}."+ret_type)
            v = ca.TsSum(r, iih.day(1), rpii=1)
            r_ac = ca.TsCorr([r, ca.TsLag(r, shift)], iih.min(60), rpii=1)
            v_ac = ca.TsCorr([v, ca.TsLag(v, shift)], iih.min(60), rpii=1)
            r_ac_f = ca.TsCorr([r, ca.TsLag(r, shift)], iih.min(60), demean=False, rpii=1)
            v_ac_f = ca.TsCorr([v, ca.TsLag(v, shift)], iih.min(60), demean=False, rpii=1)
            result[f"{pv_type}.{ret_type}.ac.s{shift}"] = r_ac
            result[f"{pv_type}.{ret_type}.acr.s{shift}"] = r_ac*r
            result[f"{pv_type}.{ret_type}.acrs.s{shift}"] = ca.TsSum(r_ac*r, iih.min(30))
            result[f"{pv_type}.{ret_type}.acvr.s{shift}"] = v_ac*r
            result[f"{pv_type}.{ret_type}.acvrs.s{shift}"] = ca.TsSum(v_ac*r, iih.min(30))

            result[f"{pv_type}.{ret_type}.ac.f.s{shift}"] = r_ac_f
            result[f"{pv_type}.{ret_type}.ac.f.r.s{shift}"] = r_ac_f*r
            result[f"{pv_type}.{ret_type}.ac.f.rs.s{shift}"] = ca.TsSum(r_ac_f*r, iih.min(30))
            result[f"{pv_type}.{ret_type}.ac.f.vr.s{shift}"] = v_ac_f*r
            result[f"{pv_type}.{ret_type}.ac.f.vrs.s{shift}"] = ca.TsSum(v_ac_f*r, iih.min(30))
    # return alpha_ca.closures.bop.rkzs(result)
    return result

def atc_clos_cross(pv_type):
    result = {}
    for shift in [1, iih.min(30)]:
        for ret_type_ac, ret_type_r in [
            ("m", "o"),("b", "bp") ,("i", "ip"), ("s", "sp"), ("s3", "s3p"),
            ("o", "m"),("bp", "b") ,("ip", "i"), ("sp", "s"), ("s3p", "s3"),
        ]:
            acr = ca.Na20(f"{pv_type}."+ret_type_ac)
            r = ca.Na20(f"{pv_type}."+ret_type_r)
            acv = ca.TsSum(acr, iih.day(1), rpii=1)
            r_ac = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.day(1), rpii=1)
            v_ac = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.day(1), rpii=1)
            r_ac_f = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.day(1), demean=False, rpii=1)
            v_ac_f = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.day(1), demean=False, rpii=1)
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.acr.s{shift}"] = r_ac*r
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.acrs.s{shift}"] = ca.TsSum(r_ac*r, iih.min(30))
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.acrd.s{shift}"] = ca.TsSum(r_ac*r, iih.day(1))
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.acvr.s{shift}"] = v_ac*r
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.acvrs.s{shift}"] = ca.TsSum(v_ac*r, iih.min(30))
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.acvrd.s{shift}"] = ca.TsSum(v_ac*r, iih.day(1))

            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.ac.f.r.s{shift}"] = r_ac_f*r
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.ac.f.rs.s{shift}"] = ca.TsSum(r_ac_f*r, iih.min(30))
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.ac.f.rd.s{shift}"] = ca.TsSum(r_ac_f*r, iih.day(1))
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.ac.f.vr.s{shift}"] = v_ac_f*r
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.ac.f.vrs.s{shift}"] = ca.TsSum(v_ac_f*r, iih.min(30))
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.ac.f.vrd.s{shift}"] = ca.TsSum(v_ac_f*r, iih.day(1))
    # return alpha_ca.closures.bop.rkzs(result)
    return result

def atc_clos_cross_short(pv_type):
    result = {}
    for shift in [iih.min(5)]:
        for ret_type_ac, ret_type_r in [
            ("m", "o"),("b", "bp") ,("i", "ip"), ("s", "sp"), ("s3", "s3p"),
            ("o", "m"),("bp", "b") ,("ip", "i"), ("sp", "s"), ("s3p", "s3"),
        ]:
            acr = ca.Na20(f"{pv_type}."+ret_type_ac)
            r = ca.Na20(f"{pv_type}."+ret_type_r)
            acv = ca.TsSum(acr, iih.day(1), rpii=1)
            r_ac = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.min(60), rpii=1)
            v_ac = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.min(60), rpii=1)
            r_ac_f = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.min(60), demean=False, rpii=1)
            v_ac_f = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.min(60), demean=False, rpii=1)
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.acr.s{shift}"] = r_ac*r
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.acrs.s{shift}"] = ca.TsSum(r_ac*r, iih.min(30))
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.acvr.s{shift}"] = v_ac*r
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.acvrs.s{shift}"] = ca.TsSum(v_ac*r, iih.min(30))

            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.ac.f.r.s{shift}"] = r_ac_f*r
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.ac.f.rs.s{shift}"] = ca.TsSum(r_ac_f*r, iih.min(30))
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.ac.f.vr.s{shift}"] = v_ac_f*r
            result[f"{pv_type}.x.{ret_type_ac}.{ret_type_r}.ac.f.vrs.s{shift}"] = ca.TsSum(v_ac_f*r, iih.min(30))
    # return alpha_ca.closures.bop.rkzs(result)
    return result

def atc_clos_pv(v_type):
    result = {}
    for shift in [1, iih.min(30)]:
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            acr = ca.Na20(f"ret."+ret_type)
            r = ca.Na20(f"{v_type}."+ret_type)
            acv = ca.TsSum(acr, iih.day(1), rpii=1)
            r_ac = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.day(1), rpii=1)
            v_ac = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.day(1), rpii=1)
            r_ac_f = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.day(1), demean=False, rpii=1)
            v_ac_f = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.day(1), demean=False, rpii=1)
            result[f"{v_type}.{ret_type}.pv.acr.s{shift}"] = r_ac*r
            result[f"{v_type}.{ret_type}.pv.acrs.s{shift}"] = ca.TsSum(r_ac*r, iih.min(30))
            result[f"{v_type}.{ret_type}.pv.acrd.s{shift}"] = ca.TsSum(r_ac*r, iih.day(1))
            result[f"{v_type}.{ret_type}.pv.acvr.s{shift}"] = v_ac*r
            result[f"{v_type}.{ret_type}.pv.acvrs.s{shift}"] = ca.TsSum(v_ac*r, iih.min(30))
            result[f"{v_type}.{ret_type}.pv.acvrd.s{shift}"] = ca.TsSum(v_ac*r, iih.day(1))

            result[f"{v_type}.{ret_type}.pv.ac.f.r.s{shift}"] = r_ac_f*r
            result[f"{v_type}.{ret_type}.pv.ac.f.rs.s{shift}"] = ca.TsSum(r_ac_f*r, iih.min(30))
            result[f"{v_type}.{ret_type}.pv.ac.f.rd.s{shift}"] = ca.TsSum(r_ac_f*r, iih.day(1))
            result[f"{v_type}.{ret_type}.pv.ac.f.vr.s{shift}"] = v_ac_f*r
            result[f"{v_type}.{ret_type}.pv.ac.f.vrs.s{shift}"] = ca.TsSum(v_ac_f*r, iih.min(30))
            result[f"{v_type}.{ret_type}.pv.ac.f.vrd.s{shift}"] = ca.TsSum(v_ac_f*r, iih.day(1))
    # return alpha_ca.closures.bop.rkzs(result)
    return result

def atc_clos_pv_short(v_type):
    result = {}
    for shift in [iih.min(5)]:
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            acr = ca.Na20(f"ret."+ret_type)
            r = ca.Na20(f"{v_type}."+ret_type)
            acv = ca.TsSum(acr, iih.day(1), rpii=1)
            r_ac = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.min(60), rpii=1)
            v_ac = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.min(60), rpii=1)
            r_ac_f = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.min(60), demean=False, rpii=1)
            v_ac_f = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.min(60), demean=False, rpii=1)
            result[f"{v_type}.{ret_type}.pv.acr.s{shift}"] = r_ac*r
            result[f"{v_type}.{ret_type}.pv.acrs.s{shift}"] = ca.TsSum(r_ac*r, iih.min(30))
            result[f"{v_type}.{ret_type}.pv.acvr.s{shift}"] = v_ac*r
            result[f"{v_type}.{ret_type}.pv.acvrs.s{shift}"] = ca.TsSum(v_ac*r, iih.min(30))

            result[f"{v_type}.{ret_type}.pv.ac.f.r.s{shift}"] = r_ac_f*r
            result[f"{v_type}.{ret_type}.pv.ac.f.rs.s{shift}"] = ca.TsSum(r_ac_f*r, iih.min(30))
            result[f"{v_type}.{ret_type}.pv.ac.f.vr.s{shift}"] = v_ac_f*r
            result[f"{v_type}.{ret_type}.pv.ac.f.vrs.s{shift}"] = ca.TsSum(v_ac_f*r, iih.min(30))
    # return alpha_ca.closures.bop.rkzs(result)
    return result

def atc_clos_vp(v_type):
    result = {}
    for shift in [1, iih.min(30)]:
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            acr = ca.Na20(f"{v_type}."+ret_type)
            r = ca.Na20(f"ret."+ret_type)
            acv = ca.TsSum(acr, iih.day(1), rpii=1)
            r_ac = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.day(1), rpii=1)
            v_ac = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.day(1), rpii=1)
            r_ac_f = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.day(1), demean=False, rpii=1)
            v_ac_f = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.day(1), demean=False, rpii=1)
            result[f"{v_type}.{ret_type}.vp.acr.s{shift}"] = r_ac*r
            result[f"{v_type}.{ret_type}.vp.acrs.s{shift}"] = ca.TsSum(r_ac*r, iih.min(30))
            result[f"{v_type}.{ret_type}.vp.acrd.s{shift}"] = ca.TsSum(r_ac*r, iih.day(1))
            result[f"{v_type}.{ret_type}.vp.acvr.s{shift}"] = v_ac*r
            result[f"{v_type}.{ret_type}.vp.acvrs.s{shift}"] = ca.TsSum(v_ac*r, iih.min(30))
            result[f"{v_type}.{ret_type}.vp.acvrd.s{shift}"] = ca.TsSum(v_ac*r, iih.day(1))

            result[f"{v_type}.{ret_type}.vp.ac.f.r.s{shift}"] = r_ac_f*r
            result[f"{v_type}.{ret_type}.vp.ac.f.rs.s{shift}"] = ca.TsSum(r_ac_f*r, iih.min(30))
            result[f"{v_type}.{ret_type}.vp.ac.f.rd.s{shift}"] = ca.TsSum(r_ac_f*r, iih.day(1))
            result[f"{v_type}.{ret_type}.vp.ac.f.vr.s{shift}"] = v_ac_f*r
            result[f"{v_type}.{ret_type}.vp.ac.f.vrs.s{shift}"] = ca.TsSum(v_ac_f*r, iih.min(30))
            result[f"{v_type}.{ret_type}.vp.ac.f.vrd.s{shift}"] = ca.TsSum(v_ac_f*r, iih.day(1))
    # return alpha_ca.closures.bop.rkzs(result)
    return result

def atc_clos_vp_short(v_type):
    result = {}
    for shift in [iih.min(5)]:
        for ret_type in alpha_ca.closures.bop.rdcp_types:
            acr = ca.Na20(f"{v_type}."+ret_type)
            r = ca.Na20(f"ret."+ret_type)
            acv = ca.TsSum(acr, iih.day(1), rpii=1)
            r_ac = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.min(60), rpii=1)
            v_ac = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.min(60), rpii=1)
            r_ac_f = ca.TsCorr([acr, ca.TsLag(acr, shift)], iih.min(60), demean=False, rpii=1)
            v_ac_f = ca.TsCorr([acv, ca.TsLag(acv, shift)], iih.min(60), demean=False, rpii=1)
            result[f"{v_type}.{ret_type}.vp.acr.s{shift}"] = r_ac*r
            result[f"{v_type}.{ret_type}.vp.acrs.s{shift}"] = ca.TsSum(r_ac*r, iih.min(30))
            result[f"{v_type}.{ret_type}.vp.acvr.s{shift}"] = v_ac*r
            result[f"{v_type}.{ret_type}.vp.acvrs.s{shift}"] = ca.TsSum(v_ac*r, iih.min(30))

            result[f"{v_type}.{ret_type}.vp.ac.f.r.s{shift}"] = r_ac_f*r
            result[f"{v_type}.{ret_type}.vp.ac.f.rs.s{shift}"] = ca.TsSum(r_ac_f*r, iih.min(30))
            result[f"{v_type}.{ret_type}.vp.ac.f.vr.s{shift}"] = v_ac_f*r
            result[f"{v_type}.{ret_type}.vp.ac.f.vrs.s{shift}"] = ca.TsSum(v_ac_f*r, iih.min(30))
    # return alpha_ca.closures.bop.rkzs(result)
    return result

class NUGGS:
    pass
class TERMS:
    @staticmethod
    def atc_rdcp():
        return atc_clos("ret")
    @staticmethod
    def atc_rdcp_sv0():
        return atc_clos("sv0")
    @staticmethod
    def atc_rdcp_sv1():
        return atc_clos("sv1")
    @staticmethod
    def atc_x_rdcp():
        return atc_clos_cross("ret")
    @staticmethod
    def atc_x_rdcp_sv0():
        return atc_clos_cross("sv0")
    @staticmethod
    def atc_x_rdcp_sv1():
        return atc_clos_cross("sv1")
    @staticmethod
    def atc_clos_pv_sv0():
        return atc_clos_pv("sv0")
    @staticmethod
    def atc_clos_pv_sv1():
        return atc_clos_pv("sv1")
    @staticmethod
    def atc_clos_vp_sv0():
        return atc_clos_vp("sv0")
    @staticmethod
    def atc_clos_vp_sv1():
        return atc_clos_vp("sv1")

class TERMS_SHORT:
    @staticmethod
    def atc_rdcp_short():
        return atc_clos_short("ret")
    @staticmethod
    def atc_rdcp_sv0_short():
        return atc_clos_short("sv0")
    @staticmethod
    def atc_rdcp_sv1_short():
        return atc_clos_short("sv1")
    @staticmethod
    def atc_x_rdcp_short():
        return atc_clos_cross_short("ret")
    @staticmethod
    def atc_x_rdcp_sv0_short():
        return atc_clos_cross_short("sv0")
    @staticmethod
    def atc_x_rdcp_sv1_short():
        return atc_clos_cross_short("sv1")
    @staticmethod
    def atc_clos_pv_sv0_short():
        return atc_clos_pv_short("sv0")
    @staticmethod
    def atc_clos_pv_sv1_short():
        return atc_clos_pv_short("sv1")
    @staticmethod
    def atc_clos_vp_sv0_short():
        return atc_clos_vp_short("sv0")
    @staticmethod
    def atc_clos_vp_sv1_short():
        return atc_clos_vp_short("sv1")
