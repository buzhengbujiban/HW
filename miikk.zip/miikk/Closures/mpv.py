from canopus_py.ca_expr import *
import alpha_ca.closures

mpvds = {
    "mpvd.spr":"mpvd.spr",
    "mpvd.rskm":"mpvd.rskm",
    "mpvd.rskb":"mpvd.rskb",
    "mpvd.rsdm":"mpvd.rsdm",
    "mpvd.rsdb":"mpvd.rsdb",
    "mpvd.vsk":"mpvd.vsk",
    "mpvd.vsd":"mpvd.vsd",
    "mpvd.tvr":"mpvd.tvr",
    "mpvd.amihud":"mpvd.amihud",
    "mpvd.impres":"mpvd.impres",
    "mpvd.trdsz":"mpvd.trdsz",
    "mpvd.trdtvr":"mpvd.trdtvr",
    "mpvd.sw":"mpvd.sw",
    "mpvd.bsw":"mpvd.bsw",
    "mpvd.vrpo":"mpvd.vrpo",
    "mpvd.vtpo":"mpvd.vtpo",
    "mpvd.vrpb":"mpvd.vrpb",
    "mpvd.vtpb":"mpvd.vtpb",
    "mpvd.osdb":"mpvd.osdb",
    "mpvd.osdm":"mpvd.osdm",
}

mpvhs = {
    "mpvh.spr":"mpvh.spr",
    "mpvh.rskm":"mpvh.rskm",
    "mpvh.rskb":"mpvh.rskb",
    "mpvh.rsdm":"mpvh.rsdm",
    "mpvh.rsdb":"mpvh.rsdb",
    "mpvh.vsk":"mpvh.vsk",
    "mpvh.vsd":"mpvh.vsd",
    "mpvh.tvr":"mpvh.tvr",
    "mpvh.amihud":"mpvh.amihud",
    "mpvh.impres":"mpvh.impres",
    "mpvh.trdsz":"mpvh.trdsz",
    "mpvh.trdtvr":"mpvh.trdtvr",
    "mpvh.sw":"mpvh.sw",
    "mpvh.bsw":"mpvh.bsw",
    "mpvh.vrpo":"mpvh.vrpo",
    "mpvh.vtpo":"mpvh.vtpo",
    "mpvh.vrpb":"mpvh.vrpb",
    "mpvh.vtpb":"mpvh.vtpb",
}


def mpvd():
    result = {}
    w = iih.day(1)
    std_b = ca.TsStd(f"ret.b", w, demean=False)
    std_m = ca.TsStd(f"ret.m", w, demean=False)
    result["mpvd.spr"] = std_b/std_m
    result["mpvd.rskm"] = ca.TsSkew(ca.Na20(f"ret.m"), w)
    result["mpvd.rskb"] = ca.TsSkew(ca.Na20(f"ret.b"), w)
    result["mpvd.rsdm"] = ca.TsStd(ca.Na20(f"ret.m"), w)
    result["mpvd.rsdb"] = ca.TsStd(ca.Na20(f"ret.b"), w)

    v = ca.Na20(ca.Diff("dollarVolumeTotal"))

    result["mpvd.vsk"] = ca.TsSkew(v, w)
    result["mpvd.vsd"] = ca.TsStd(v, w)/ca.TsMean(v, w)

    result["mpvd.tvr"] = ca.TsSum(v, w) / ca("free.mv")

    result["mpvd.amihud"] = ca.Abs(ca.TsSum(ca.Na20(ca("ret.o")), w))/(ca.TsSum(v, w)+ca.C(100))

    abs_ret = ca.Abs(ca(f"ret.o"))*(~ca.IsFirstII())
    sqrt_v  = ca.Abs(ca.Na20(ca.NumPow(ca("buyNotl")-ca("sellNotl"), 0.5)))
    result["mpvd.impres"] = ca.Sel(ca.TsReg([abs_ret,sqrt_v], w), "beta_0")
    result["mpvd.trdsz"] = ca.TsSum(v, w)/ca.TsSum(ca.Na20(ca.Diff("tradesTotal")), w)
    result["mpvd.trdtvr"] = ca.TsSum(v, w)/ca.TsSum(ca.Na20(ca.Diff("tradesTotal")), w)/ca("free.mv")

    px_o = ca.C(1) + ca.TsSum(ca.Na20("ret.o"), w)
    px_b = ca.C(1) + ca.TsSum(ca.Na20("ret.b"), w)
    px_h_o = ca.TsMax(px_o, w)
    px_l_o = ca.TsMin(px_o, w)
    px_h_b = ca.TsMax(px_b, w)
    px_l_b = ca.TsMin(px_b, w)

    vwap_o = ca.IfElse(ca.Abs(ca.TsSum(v, w, rpii=1))<=ca.C(100), ca.C(1), ca.TsSum(px_o*v, w, rpii=1)/ca.TsSum(v, w, rpii=1))
    vwap_b = ca.IfElse(ca.Abs(ca.TsSum(v, w, rpii=1))<=ca.C(100), ca.C(1), ca.TsSum(px_b*v, w, rpii=1)/ca.TsSum(v, w, rpii=1))
    twap_o = ca.TsMean(px_o, w)
    twap_b = ca.TsMean(px_b, w)

    result["mpvd.sw"] = px_h_o - px_l_o
    result["mpvd.bsw"] = px_h_b - px_l_b

    result["mpvd.vrpo"] = ca.Na20(vwap_o - (px_l_o + px_h_o) / ca.C(2))
    result["mpvd.vtpo"] = ca.Na20(vwap_o - twap_o)
    result["mpvd.vrpb"] = ca.Na20(vwap_b - (px_l_b + px_h_b) / ca.C(2))
    result["mpvd.vtpb"] = ca.Na20(vwap_b - twap_b)

    ov_b_abs = ca.TsSum(ca.Abs(ca("ret.b"))*(ca.IsFirstII()), w)
    id_b_std = ca.TsStd(ca("ret.b")*(~ca.IsFirstII()), w, demean=False)
    ov_m_abs = ca.TsSum(ca.Abs(ca("ret.m"))*(ca.IsFirstII()), w)
    id_m_std = ca.TsStd(ca("ret.m")*(~ca.IsFirstII()), w, demean=False)

    result["mpvd.osdb"] = ca.Min(ov_b_abs/(id_b_std*ca.C(7)), ca.C(5))
    result["mpvd.osdm"] = ca.Min(ov_m_abs/(id_m_std*ca.C(7)), ca.C(5))

    # result["ov_b_abs"] = ca.TsSum(ca.Abs(ca("ret.b"))*(ca.IsFirstII()), w)
    # result["id_b_std"] = ca.TsStd(ca("ret.b")*(~ca.IsFirstII()), w, demean=False)
    # result["ov_m_abs"] = ca.TsSum(ca.Abs(ca("ret.m"))*(ca.IsFirstII()), w)
    # result["id_m_std"] = ca.TsStd(ca("ret.m")*(~ca.IsFirstII()), w, demean=False)
    # result["id_m_sum"] = ca.TsSum(ca("ret.m")*(~ca.IsFirstII()), w, demean=False)

    # result["retb"] = ca("ret.b")
    # result["retm"] = ca("ret.m")
    # result["retm_id"] = ca("ret.m")*(~ca.IsFirstII())
    # result["retbsum"] = ca.TsSum(ca.Na20(ca("ret.b")), w)
    # result["retmsum"] = ca.TsSum(ca.Na20(ca("ret.m")), w)
    # result["vwap_o"] = vwap_o
    # result["px_h_o"] = px_h_o
    # result["px_l_o"] = px_l_o
    # result["px_o"] = px_o
    # result["v"] = v
    # result["px_o*v"] = px_o*v
    # result["ca.TsSum(px_o*v, w)"] = ca.TsSum(px_o*v, w)
    # result["ca.TsSum(v, w)"] = ca.TsSum(v, w)

    return {k:ca.Na20(v) for k,v in result.items()}

def mpvh():
    result = {}
    w = iih.min(60)
    std_b = ca.TsStd((~ca.IsFirstII())*f"ret.b", w, demean=False, rpii=1)
    std_m = ca.TsStd((~ca.IsFirstII())*f"ret.m", w, demean=False, rpii=1)
    result["mpvh.spr"] = std_b/std_m
    result["mpvh.rskm"] = ca.TsSkew(ca.Na20(f"ret.m"), w, rpii=1)
    result["mpvh.rskb"] = ca.TsSkew(ca.Na20(f"ret.b"), w, rpii=1)
    result["mpvh.rsdm"] = ca.TsStd(ca.Na20(f"ret.m"), w, rpii=1)
    result["mpvh.rsdb"] = ca.TsStd(ca.Na20(f"ret.b"), w, rpii=1)

    v = ca.Na20(ca.Diff("dollarVolumeTotal"))

    result["mpvh.vsk"] = ca.TsSkew(v, w, rpii=1)
    result["mpvh.vsd"] = ca.TsStd(v, w)/ca.TsMean(v, w, rpii=1)

    result["mpvh.tvr"] = ca.TsSum(v, w, rpii=1) / ca("free.mv")

    result["mpvh.amihud"] = ca.Abs(ca.TsSum(ca.Na20((~ca.IsFirstII())*ca("ret.o")), w, rpii=1))/(ca.TsSum(v, w)+ca.C(100))

    abs_ret = ca.Abs(ca(f"ret.o"))*(~ca.IsFirstII())
    sqrt_v  = ca.Abs(ca.Na20(ca.NumPow(ca("buyNotl")-ca("sellNotl"), 0.5)))
    result["mpvh.impres"] = ca.Sel(ca.TsReg([abs_ret,sqrt_v], w, rpii=1), "beta_0")
    result["mpvh.trdsz"] = ca.TsSum(v, w, rpii=1)/ca.TsSum(ca.Na20(ca.Diff("tradesTotal")), w, rpii=1)
    result["mpvh.trdtvr"] = ca.TsSum(v, w, rpii=1)/ca.TsSum(ca.Na20(ca.Diff("tradesTotal")), w, rpii=1)/ca.TsSum(ca.Na20(ca.Diff("tradesTotal")), w)/ca("free.mv")

    px_o = ca.C(1) + ca.TsSum((~ca.IsFirstII())*ca.Na20("ret.o"), w, rpii=1)
    px_b = ca.C(1) + ca.TsSum((~ca.IsFirstII())*ca.Na20("ret.b"), w, rpii=1)
    px_h_o = ca.TsMax(px_o, w, rpii=1)
    px_l_o = ca.TsMin(px_o, w, rpii=1)
    px_h_b = ca.TsMax(px_b, w, rpii=1)
    px_l_b = ca.TsMin(px_b, w, rpii=1)

    vwap_o = ca.IfElse(ca.TsSum(v, w, rpii=1)==ca.C(0), ca.C(1), ca.TsSum(px_o*v, w, rpii=1)/ca.TsSum(v, w, rpii=1))
    vwap_b = ca.IfElse(ca.TsSum(v, w, rpii=1)==ca.C(0), ca.C(1), ca.TsSum(px_b*v, w, rpii=1)/ca.TsSum(v, w, rpii=1))
    twap_o = ca.TsMean(px_o, w, rpii=1)
    twap_b = ca.TsMean(px_b, w, rpii=1)

    result["mpvh.sw"] = px_h_o - px_l_o
    result["mpvh.bsw"] = px_h_b - px_l_b

    result["mpvh.vrpo"] = vwap_o - (px_l_o + px_h_o) / ca.C(2)
    result["mpvh.vtpo"] = vwap_o - twap_o
    result["mpvh.vrpb"] = vwap_b - (px_l_b + px_h_b) / ca.C(2)
    result["mpvh.vtpb"] = vwap_b - twap_b

    return {k:ca.Na20(v) for k,v in result.items()}

class NUGGS:
    @staticmethod
    def I_mpv_mpvd():
        return mpvd()
    @staticmethod
    def I_mpv_mpvh():
        return mpvh()
    @staticmethod
    def I_mpv_tprx():
        return {
            "add_cnt.I":ca.Diff("add_cnt"),
            "trd_cnt.I":ca.Diff("trd_cnt"),     
            "trd_notl.I":ca.Diff("trd_notl"),  
            "bbo_chg_cnt.I":ca.Diff("bbo_chg_cnt"),  
            "bbo_chg_rct_cnt1.I":ca.Diff("bbo_chg_rct_cnt1"),  
            "bbo_chg_rct_cnt2.I":ca.Diff("bbo_chg_rct_cnt2"),  
            "bbo_chg_rct_cnt3.I":ca.Diff("bbo_chg_rct_cnt3"),
        }
    
class TERMS_SHORT:
    @staticmethod
    def mpvh():
        # return alpha_ca.closures.bop.rkzs(mpvh())
        return mpvh()
    
class TERMS:
    @staticmethod
    def mpvd():
        # return alpha_ca.closures.bop.rkzs(mpvd())
        return mpvd()
    @staticmethod
    def mpvh():
        # return alpha_ca.closures.bop.rkzs(mpvh())
        return mpvh()
    @staticmethod
    def mpvd_iirk():
        # return alpha_ca.closures.bop.rkzs(alpha_ca.closures.bop.iirk(mpvds, 10, True))
        return alpha_ca.closures.bop.iirk(mpvds, 10, True)
    @staticmethod
    def mpvh_iirk():
        # return alpha_ca.closures.bop.rkzs(alpha_ca.closures.bop.iirk(mpvhs, 10, True))
        return alpha_ca.closures.bop.iirk(mpvhs, 10, True)
    @staticmethod
    def mpvd_iiir():
        # return alpha_ca.closures.bop.rkzs(alpha_ca.closures.bop.iiir(mpvds, 10, True))
        return alpha_ca.closures.bop.iiir(mpvds, 10, True)
    @staticmethod
    def mpvh_iiir():
        # return alpha_ca.closures.bop.rkzs(alpha_ca.closures.bop.iiir(mpvhs, 10, True))
        return alpha_ca.closures.bop.iiir(mpvhs, 10, True)
    @staticmethod
    def mpvd_iizs():
        # return alpha_ca.closures.bop.rkzs(alpha_ca.closures.bop.iizs(mpvds, 10, True))
        return alpha_ca.closures.bop.iizs(mpvds, 10, True)
    @staticmethod
    def mpvh_iizs():
        # return alpha_ca.closures.bop.rkzs(alpha_ca.closures.bop.iizs(mpvhs, 10, True))
        return alpha_ca.closures.bop.iizs(mpvhs, 10, True)
