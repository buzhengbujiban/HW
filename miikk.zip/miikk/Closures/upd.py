from canopus_py.ca_expr import *
import alpha_ca.closures

# ts selection on time, volume, volume diff, volatility
# yinzi qiege lun

def upd_std(terms_dict):
    result = {}
    for w in [iih.min(120), iih.day(1), iih.day(2), iih.day(5)]:
        for k,v in terms_dict.items():
            std_diff = ca.TsUDStdDiff(ca.Na20(v), w, rpii=5)
            std_u = ca.Sel(std_diff, "U")
            std_d = ca.Sel(std_diff, "D")
            result[f"upd.std.{k}.{w}"] = std_diff
            result[f"upd.stda.{k}.{w}"] = ca.Abs(std_diff)
            result[f"upd.n.std.{k}.{w}"] = std_diff/(std_u+std_d)
            result[f"upd.n.stda.{k}.{w}"] = ca.Abs(std_diff)/(std_u+std_d)
            result[f"upd.stda.udr.{k}.{w}"] = ca.RegRes(std_u, std_d)/(std_u+std_d)
            result[f"upd.stda.dur.{k}.{w}"] = ca.RegRes(std_d, std_u)/(std_u+std_d)

    return result

class NUGGS:
    pass
class TERMS:
    @staticmethod
    def upd_std_ret():
        terms = {
            "ret."+i:"ret."+i for i in alpha_ca.closures.bop.rdcp_types
        }
        # return alpha_ca.closures.bop.rkzs(upd_std(terms))
        return upd_std(terms)
    @staticmethod
    def upd_std_sv0():
        terms = {
            "sv0."+i:"sv0."+i for i in alpha_ca.closures.bop.rdcp_types
        }
        # return alpha_ca.closures.bop.rkzs(upd_std(terms))
        return upd_std(terms)
    @staticmethod
    def upd_std_sv1():
        terms = {
            "sv1."+i:"sv1."+i for i in alpha_ca.closures.bop.rdcp_types
        }
        # return alpha_ca.closures.bop.rkzs(upd_std(terms))
        return upd_std(terms)
    @staticmethod
    def upd_std_sv():
        terms = {
            "sv":ca.Na20((ca("buyNotl")-ca("sellNotl"))/ca("turnover.rw22")),
        }
        # return alpha_ca.closures.bop.rkzs(upd_std(terms))
        return upd_std(terms)
