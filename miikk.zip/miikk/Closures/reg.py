from canopus_py.ca_expr import *
import alpha_ca.closures

class NUGGS:
    @staticmethod
    def I_ResRet_rdcp(ret="backward.ret5m"):
        ret = ca.Na20(ret)
        return alpha_ca.closures.bop.rdcp({"ret":ret})

    @staticmethod
    def I_ResRet_hlres(ret="backward.ret5m"):
        # TODO: adj price
        ts_max_1 = ca.TsMax(ca.Na20("high"), iih.day(1), rpii=1)
        ts_min_1 = ca.TsMin(ca.Na20("low"), iih.day(1), rpii=1)

        ts_max_5 = ca.TsMax(ca.Na20("high"), iih.day(5), rpii=5)
        ts_min_5 = ca.TsMin(ca.Na20("low"), iih.day(5), rpii=5)

        ts_mm_1 = (ts_max_1 + ts_min_1)/ca.C(2)
        ts_mm_5 = (ts_max_5 + ts_min_5)/ca.C(2)

        h_ret_1 = ca.Clip(ca.Na20((ts_max_1-ca.TsLag(ts_max_1, 1))/ca.TsLag(ts_max_1, 1)), 0.03)
        l_ret_1 = ca.Clip(ca.Na20((ts_min_1-ca.TsLag(ts_min_1, 1))/ca.TsLag(ts_min_1, 1)), 0.03)
        h_ret_5 = ca.Clip(ca.Na20((ts_max_5-ca.TsLag(ts_max_5, 1))/ca.TsLag(ts_max_5, 1)), 0.03)
        l_ret_5 = ca.Clip(ca.Na20((ts_min_5-ca.TsLag(ts_min_5, 1))/ca.TsLag(ts_min_5, 1)), 0.03)

        m_ret_1 = ca.Clip(ca.Na20((ts_mm_1-ca.TsLag(ts_mm_1, 1))/ca.TsLag(ts_mm_1, 1)), 0.03)
        m_ret_5 = ca.Clip(ca.Na20((ts_mm_5-ca.TsLag(ts_mm_5, 1))/ca.TsLag(ts_mm_5, 1)), 0.03)

        d_ret_1 = ca.Clip(h_ret_1-l_ret_1, 0.03)
        d_ret_5 = ca.Clip(h_ret_5-l_ret_5, 0.03)

        ret = ca(ret)

        return {
            "h_res_1": ca.RegRes(h_ret_1, ret),
            "l_res_1": ca.RegRes(l_ret_1, ret),
            "hlm_res_1": ca.RegRes(m_ret_1, ret),
            "hlm_res_5": ca.RegRes(m_ret_5, ret),
            "h_res_5": ca.RegRes(h_ret_5, ret),
            "l_res_5": ca.RegRes(l_ret_5, ret),
            "hld_res_1": ca.RegRes(d_ret_1, ret),
            "hld_res_5": ca.RegRes(d_ret_5, ret),
        }

    @staticmethod
    def I_ResRet_vrs(ret="backward.ret5m"):
        ret = ca(ret)
        tvr = ca.Diff("dollarVolumeTotal")
        rescaled_ret = ca.Na20(ca.IfElse(
            ca.IIndex() <= ca.C(1),
            ret,
            ret*tvr*ca.C(iih.day(1))/ca("turnover.rw22")
        ))
        return {
            "vrs_res": ca.RegRes(rescaled_ret, ret),
            "vrs_ret": rescaled_ret,
        }
    
    #sv1
    @staticmethod
    def _I_ResV_rv0():
        vb = ca.NumLog1p(ca.Na20("buyNotl"))
        vs = ca.NumLog1p(ca.Na20("sellNotl"))
        va = ca.NumLog1p(ca.Na20("sellNotl")+ca.Na20("buyNotl"))
        return alpha_ca.closures.bop.rdcp({
            "vib0": (vb-vs)*va,
        })
    
    #sv0
    @staticmethod
    def _I_ResV_rv1():
        vib = ca.Na20("buyNotl")-ca.Na20("sellNotl")
        vib_sqrt = ca.NumPow(vib*ca.C(iih.day(1))/ca("turnover.rw22"), 0.5)
        return alpha_ca.closures.bop.rdcp({
            "vib": vib_sqrt ,
        })

    #sv1
    @staticmethod
    def I_ResV_sv1():
        vb = ca.NumLog1p(ca.Na20("buyNotl"))
        vs = ca.NumLog1p(ca.Na20("sellNotl"))
        va = ca.NumLog1p(ca.Na20("sellNotl")+ca.Na20("buyNotl"))
        return alpha_ca.closures.bop.rdcp({
            "sv1": (vb-vs)*va,
        })
    
    #sv0
    @staticmethod
    def I_ResV_sv0():
        vib = ca.Na20("buyNotl")-ca.Na20("sellNotl")
        vib_sqrt = ca.NumPow(vib*ca.C(iih.day(1))/ca("turnover.rw22"), 0.5)
        return alpha_ca.closures.bop.rdcp({
            "sv0": vib_sqrt ,
        })

class TERMS:
    pass