class NUGGS:
    pass
class TERMS:
    pass