from canopus_py.ca_expr import *
import alpha_ca.closures

class NUGGS:
    @staticmethod
    def D_bod_windL4():
        result = {}
        l4_inds = [
            '6210101010', '6210101020', '6210102010', '6210102020', '6210102030', '6210102040', '6210102050', '6215101010',
            '6215101011', '6215101020', '6215101030', '6215101040', '6215101050', '6215102010', '6215103010', '6215103020', '6215104010', '6215104020', '6215104030', '6215104040', '6215104045', '6215104050', '6215105010', '6215105020', '6220101010',
            '6220102010', '6220103010', '6220104010', '6220104020', '6220105010', '6220106010', '6220106015', '6220106020', '6220107010', '6220201010', '6220201050', '6220201060', '6220201070', '6220202010', '6220202020', '6220301010', '6220302010', '6220303010', '6220304010', '6220304020', '6220305010', '6220305020', '6220305030', '6225101010',
            '6225101020', '6225102010', '6225102020', '6225201010', '6225201020', '6225201040', '6225201050', '6225202010', '6225203010', '6225203020', '6225203030', '6225301020', '6225301030', '6225301040', '6225302010', '6225302020', '6225401000', '6225401010', '6225401020', '6225401030', '6225401040', '6225501010', 
            '6225502010', # before 20190520
            '6225502020', '6225503010', 
            '6225503020', # before 20200302
            '6225504020', '6225504040', '6225504050', '6225504060', '6230101010',
            '6230101020', '6230101030', '6230101040', '6230201010', '6230201020', '6230201030', '6230202010', '6230202030', '6230301010', '6230302010', '6235101010',
            '6235101020', '6235102010', '6235102015', '6235102020', '6235201010', '6235202010', '6235202011', '6235203010', '6240101010',
            '6240101015', '6240201020', '6240201030', '6240201040', '6240203010', '6240203020', '6240203030', '6240301020', '6240301030', '6240301040', '6245101010',
            '6245102010', '6245102020', '6245103010', '6245103020', '6245103030', '6245201020', '6245202010', '6245202020', '6245203010', '6245203015', '6245203020', '6245203030', '6245301010', '6245301020', '6250101010',
            '6250101020',
            '6255101010', '6255102010', '6255103010', '6255104010', 
            '6255105010', # before 20200302
            '6255105020', '6260102020',
            '6260102030', '6260102040',
        ]

        l1_inds = sorted(list(set([ind[:4] for ind in l4_inds])))
        l2_inds = sorted(list(set([ind[:6] for ind in l4_inds])))
        l3_inds = sorted(list(set([ind[:8] for ind in l4_inds])))

        l1_ind_vals  = [ca.C(int(i)) for i in l1_inds]
        l1_ind_conds = []
        for ind in l1_inds:
            l4s = [i for i in l4_inds if i[:4] == ind]
            print(l4s)
            l1_ind_conds += [sum([ca.Na20(ca.V(i, allow_missing=True)) for i in l4s], start=ca.C(0))>ca.C(0)]
        result["windL1"] = ca.Switch(l1_ind_conds, l1_ind_vals)

        l2_ind_vals  = [ca.C(int(i)) for i in l2_inds]
        l2_ind_conds = []
        for ind in l2_inds:
            l4s = [i for i in l4_inds if i[:6] == ind]
            l2_ind_conds += [sum([ca.Na20(ca.V(i, allow_missing=True)) for i in l4s], start=ca.C(0))>ca.C(0)]
        result["windL2"] = ca.Switch(l2_ind_conds, l2_ind_vals)

        l3_ind_vals  = [ca.C(int(i)) for i in l3_inds]
        l3_ind_conds = []
        for ind in l3_inds:
            l4s = [i for i in l4_inds if i[:8] == ind]
            l3_ind_conds += [sum([ca.Na20(ca.V(i, allow_missing=True)) for i in l4s], start=ca.C(0))>ca.C(0)]
        result["windL3"] = ca.Switch(l3_ind_conds, l3_ind_vals)

        l4_ind_vals  = [ca.C(int(i)) for i in l4_inds]
        l4_ind_conds = []
        for ind in l4_inds:
            l4s = [i for i in l4_inds if i[:10] == ind]
            l4_ind_conds += [sum([ca.Na20(ca.V(i, allow_missing=True)) for i in l4s], start=ca.C(0))>ca.C(0)]

        result["windL4"] = ca.Switch(l4_ind_conds, l4_ind_vals)
        return result

class TERMS:
    @staticmethod
    def res_ret_grpmom(group_list = None, group_list_id = None):
        result = {}
        if group_list is None:
            ind_group = ca.AggGrouping(alpha_ca.closures.bop.inds_CNE5)
            grouping = [ind_group]+[ca.Grouping(i) for i in ["windL1", "windL2", "windL3", "windL4"]]
        else:
            assert group_list_id is not None
            grouping = [ca.Grouping(i) for i in group_list]
        # print(group_list)
        # print(grouping)
        # exit(0)
        for gi, grp in enumerate(grouping):
            for gvi, grp_val in enumerate(["tot.mv", ca.Diff("dollarVolumeTotal"), ca.Diff("dollarVolumeTotal")/ca.Diff("tradesTotal")]):
                for d in [1, 5, 20]:
                    for rdcp_type in ["b", "i", "s"]:
                        for seed in ["ret"]:
                        # for seed in ["ret", "sv0", "sv1"]:
                            gprk = ca.GroupRank(ca.Na20(grp_val), grp)
                            res_ret_wgt_mean = ca.GroupMean(
                                ca.Na20(f"{seed}.{rdcp_type}")*(ca.Max(gprk, ca.C(0))-ca.C(1)), 
                                grp
                            )
                            term_label = f"idg.g{gi}.gv{gvi}.{seed}.{rdcp_type}.d{d}"
                            if group_list_id is not None:
                                term_label = f"{group_list_id}.{term_label}"
                            result[term_label] = ca.TsSum(
                                res_ret_wgt_mean, 
                                iih.day(d)
                            )
            
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def wind_gprk_subrk():
        result = {}
        for d in [1, 5, 20]:
            for rdcp_type in alpha_ca.closures.bop.rdcp_types:
                seed = ca.Na20(f"ret.{rdcp_type}")
                ret_sum = ca.TsSum(seed, iih.day(d))
                group_l1 = ca.Grouping("windL1")
                group_l2 = ca.Grouping("windL2")
                gprk1 = ca.GroupRank(ret_sum, group_l1)
                gprk2 = ca.GroupRank(ret_sum, group_l2)
                result[f"gpsubrk.{rdcp_type}.d{d}.df"] = gprk1-gprk2
                result[f"gpsubrk.{rdcp_type}.d{d}.r12"] = ca.RegRes(gprk1, gprk2)
                result[f"gpsubrk.{rdcp_type}.d{d}.r21"] = ca.RegRes(gprk2, gprk1)
        # return alpha_ca.closures.bop.rkzs(result)
        return result
