from canopus_py.ca_expr import *
import alpha_ca.closures
#import alpha_ca.closures as clos

# ts selection on time, volume, volume diff, volatility
# yinzi qiege lun

def ts_sel(sel_key, sel_value):
    result = {}
    for window_day in [1,5]:
        for sel_min in [30, 60]:
            und_rs = {}
            for ret_type in alpha_ca.closures.bop.rdcp_types:
                r = ca.Na20(f"ret.{ret_type}")
                sv0 = ca.Na20(f"sv0.{ret_type}")
                sv1 = ca.Na20(f"sv1.{ret_type}")
                und_rs["ret."+ret_type+".ov"] = r
                und_rs["ret."+ret_type+".nov"] = r*(~ca.IsFirstII())
                und_rs["sv0."+ret_type] = sv0
                und_rs["sv1."+ret_type] = sv1
            rs = ";".join([str(i) for i in und_rs.values()])
            full_sel_top = ca.TsSel(rs, sel_value, iih.day(window_day), iih.min(sel_min)*window_day, True)
            full_sel_bot = ca.TsSel(rs, sel_value, iih.day(window_day), iih.min(sel_min)*window_day, False)

            for k,v in und_rs.items():
                tss_top = ca.Sel(full_sel_top, str(v))
                tss_bot = ca.Sel(full_sel_bot, str(v))
                result[f"tss.{sel_key}.{k}.d{window_day}.m{sel_min}"] = tss_top - tss_bot
                result[f"tss.{sel_key}.{k}.d{window_day}.m{sel_min}.rtb"] = ca.RegRes(tss_top,tss_bot)
                result[f"tss.{sel_key}.{k}.d{window_day}.m{sel_min}.rbt"] = ca.RegRes(tss_bot,tss_top)
                result[f"tss.{sel_key}.{k}.d{window_day}.m{sel_min}.rto"] = ca.RegRes(tss_top,ca.TsSum(v, iih.day(1), rpii=1))
                result[f"tss.{sel_key}.{k}.d{window_day}.m{sel_min}.rbo"] = ca.RegRes(tss_bot,ca.TsSum(v, iih.day(1), rpii=1))
    return result

def ts_sel_smooth():
    result = {}
    window_day = 1
    rets = ["ret.o", "ret.m", "ret.b", "ret.bp"]
    pxs = [ca.TsSum(ca.Na20(r), iih.day(window_day)) for r in rets]
    rps = {
        "ret.o":"ret.o", 
        "ret.m":"ret.m", 
        "ret.b":"ret.b", 
        "ret.bp":"ret.bp",
        "px.o":ca.TsSum(ca.Na20("ret.o"), iih.day(window_day)) ,
        "px.m":ca.TsSum(ca.Na20("ret.m"), iih.day(window_day)) ,
        "px.b":ca.TsSum(ca.Na20("ret.b"), iih.day(window_day)) ,
        "px.bp":ca.TsSum(ca.Na20("ret.bp"), iih.day(window_day)),
    }
    # swing = ca.Na20(ca("high")-ca("low"))
    # volume = ca.Na20(ca.Diff("dollarVolumeTotal"))
    und_vs = {
        "swing": ca.Na20(ca("high")-ca("low")),
        "volume": ca.Na20(ca.Diff("dollarVolumeTotal")),
    }

    vs = ";".join([str(i) for i in und_vs.values()])

    for rpk,rpv in rps.items():
        full_sel_tops = {}
        full_sel_bots = {}
        for m in [30, 60, 90, 120]:
            full_sel_tops[m] = ca.TsSel(vs, ca.Na20(rpv), iih.day(window_day), iih.min(m)*window_day, True)
            full_sel_bots[m] = ca.TsSel(vs, ca.Na20(rpv), iih.day(window_day), iih.min(m)*window_day, False)
        for k,v in und_vs.items():
            tops = [ca.Sel(full_sel_tops[m], str(v)) for m in [30, 60, 90, 120]]
            bots = [ca.Sel(full_sel_bots[m], str(v)) for m in [30, 60, 90, 120]]

            result[f"tsss.{k}.{rpk}.d{window_day}"] = sum(tops, ca.C(0))-sum(bots, ca.C(0))
            result[f"tsss.{k}.{rpk}.d{window_day}.rtb"] = ca.RegRes(sum(tops, ca.C(0)), sum(bots, ca.C(0)))
            result[f"tsss.{k}.{rpk}.d{window_day}.rbt"] = ca.RegRes(sum(tops, ca.C(0)), sum(bots, ca.C(0)))

    return result

def ts_sel_vwap_diff(sel_key, sel_value):
    result = {}

    window_day = 1
    sel_min = 60

    volume = ca.Na20(ca.Diff("dollarVolumeTotal"))
    rets = ["ret.o", "ret.m", "ret.b", "ret.bp"]
    pxs = [ca.TsSum(ca.Na20(r), iih.day(window_day)) for r in rets]

    vps = []

    for px in pxs:
        vps += [volume*px]

    vps_str = ";".join([str(i) for i in vps]+[str(volume)])

    full_sel_top = ca.TsSel(vps_str, sel_value, iih.day(window_day), iih.min(sel_min)*window_day, True)
    full_sel_bot = ca.TsSel(vps_str, sel_value, iih.day(window_day), iih.min(sel_min)*window_day, False)

    for i, px in enumerate(pxs):
        ret_type = rets[i].split(".")[1]
        tss_top = ca.Sel(full_sel_top, str(vps[i]))
        tss_bot = ca.Sel(full_sel_bot, str(vps[i]))
        tss_vol = ca.Sel(full_sel_bot, str(volume))
        vwap = ca.TsSum(px*volume, iih.day(window_day))/ca.TsSum(volume, iih.day(window_day))
        vwap_top = tss_top/tss_vol
        vwap_bot = tss_bot/tss_vol
        result[f"tssv.tb.{sel_key}.{ret_type}.d{window_day}.m{sel_min}"] = (vwap_top - vwap_bot)/vwap
        result[f"tssv.tbd.{sel_key}.{ret_type}.d{window_day}.m{sel_min}"] = (vwap_top + vwap_bot - vwap*ca.C(2))/vwap
        result[f"tssv.tv.{sel_key}.{ret_type}.d{window_day}.m{sel_min}"] = (vwap_top - vwap)/vwap
        result[f"tssv.bv.{sel_key}.{ret_type}.d{window_day}.m{sel_min}"] = (vwap_bot - vwap)/vwap

    return result

def ts_reverse_sel():
    result = {}
    ret_labels = ["o", "m", "b", "bp"]
    rets = ["ret."+l for l in ret_labels]
    reths = [ca.TsSum(ca.Na20(r)*(~ca.IsFirstII()), iih.min(60), rpii=1) for r in rets]
    window_days = 5
    mpvhs = [
        "mpvh.spr","mpvh.rskm","mpvh.rskb","mpvh.rsdm","mpvh.rsdb",
        "mpvh.vsk","mpvh.vsd","mpvh.amihud","mpvh.impres","mpvh.trdsz","mpvh.trdtvr",
        "mpvh.sw","mpvh.bsw","mpvh.vrpo","mpvh.vtpo","mpvh.vrpb","mpvh.vtpb",
    ]
    mpvhs_str = ";".join(mpvhs)
    for ri, ret in enumerate(reths):
        for sel_min in [30, 60]:
            full_sel_top = ca.TsSel(mpvhs_str, ca.Na20(ret), iih.day(window_days), iih.min(sel_min)*window_days, True)
            full_sel_bot = ca.TsSel(mpvhs_str, ca.Na20(ret), iih.day(window_days), iih.min(sel_min)*window_days, False)
            for mpvh in mpvhs:
                mpvh_label = mpvh.split(".")[1]
                ret_label = ret_labels[ri]
                tss_top = ca.Sel(full_sel_top, mpvh)
                tss_bot = ca.Sel(full_sel_bot, mpvh)
                result[f"tss.rev.{mpvh_label}.{ret_label}.m{sel_min}"] = tss_top - tss_bot
                result[f"tss.rev.{mpvh_label}.{ret_label}.m{sel_min}.rtb"] = ca.RegRes(tss_top,tss_bot)
                result[f"tss.rev.{mpvh_label}.{ret_label}.m{sel_min}.rbt"] = ca.RegRes(tss_bot,tss_top)
                result[f"tss.rev.{mpvh_label}.{ret_label}.m{sel_min}.rto"] = ca.RegRes(tss_top,ca.TsSum(ca.Na20(mpvh), iih.day(1), rpii=1))
                result[f"tss.rev.{mpvh_label}.{ret_label}.m{sel_min}.rbo"] = ca.RegRes(tss_bot,ca.TsSum(ca.Na20(mpvh), iih.day(1), rpii=1))
    return result


class NUGGS:
    pass
class TERMS:
    @staticmethod
    def ii_ts_sel():
        result = ts_sel("ii", ca.IIndex())
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def vl_ts_sel():
        result = ts_sel("vl", ca.Na20(ca.Diff("dollarVolumeTotal")/ca("turnover.rw22")))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def dv_ts_sel():
        result = ts_sel("dv", ca.Na20(ca.Diff(ca.Diff("dollarVolumeTotal"))/ca("turnover.rw22")))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def arm_ts_sel():
        result = ts_sel("arm", ca.Abs("ret.m")*(~ca.IsFirstII()))
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def arb_ts_sel():
        result = ts_sel("arb", ca.Abs("ret.b")*(~ca.IsFirstII()))
        # return alpha_ca.closures.bop.rkzs(result)    
        return result

    @staticmethod
    def mpvh_spr_ts_sel():
        result = ts_sel("mpvh.spr", "mpvh.spr")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_rskm_ts_sel():
        result = ts_sel("mpvh.rskm", "mpvh.rskm")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_rskb_ts_sel():
        result = ts_sel("mpvh.rskb", "mpvh.rskb")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_rsdm_ts_sel():
        result = ts_sel("mpvh.rsdm", "mpvh.rsdm")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_rsdb_ts_sel():
        result = ts_sel("mpvh.rsdb", "mpvh.rsdb")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vsk_ts_sel():
        result = ts_sel("mpvh.vsk", "mpvh.vsk")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vsd_ts_sel():
        result = ts_sel("mpvh.vsd", "mpvh.vsd")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_amihud_ts_sel():
        result = ts_sel("mpvh.amihud", "mpvh.amihud")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_impres_ts_sel():
        result = ts_sel("mpvh.impres", "mpvh.impres")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_trdsz_ts_sel():
        result = ts_sel("mpvh.trdsz", "mpvh.trdsz")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_trdtvr_ts_sel():
        result = ts_sel("mpvh.trdtvr", "mpvh.trdtvr")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_sw_ts_sel():
        result = ts_sel("mpvh.sw", "mpvh.sw")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_bsw_ts_sel():
        result = ts_sel("mpvh.bsw", "mpvh.bsw")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vrpo_ts_sel():
        result = ts_sel("mpvh.vrpo", "mpvh.vrpo")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vtpo_ts_sel():
        result = ts_sel("mpvh.vtpo", "mpvh.vtpo")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vrpb_ts_sel():
        result = ts_sel("mpvh.vrpb", "mpvh.vrpb")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vtpb_ts_sel():
        result = ts_sel("mpvh.vtpb", "mpvh.vtpb")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def ts_sel_smooth():
        result = ts_sel_smooth()
        # return alpha_ca.closures.bop.rkzs(result)
        return result

    @staticmethod
    def mpvh_spr_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.spr", "mpvh.spr")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_rskm_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.rskm", "mpvh.rskm")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_rskb_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.rskb", "mpvh.rskb")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_rsdm_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.rsdm", "mpvh.rsdm")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_rsdb_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.rsdb", "mpvh.rsdb")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vsk_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.vsk", "mpvh.vsk")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vsd_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.vsd", "mpvh.vsd")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_amihud_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.amihud", "mpvh.amihud")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_impres_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.impres", "mpvh.impres")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_trdsz_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.trdsz", "mpvh.trdsz")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_trdtvr_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.trdtvr", "mpvh.trdtvr")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_sw_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.sw", "mpvh.sw")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_bsw_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.bsw", "mpvh.bsw")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vrpo_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.vrpo", "mpvh.vrpo")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vtpo_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.vtpo", "mpvh.vtpo")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vrpb_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.vrpb", "mpvh.vrpb")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def mpvh_vtpb_ts_sel_vwap():
        result = ts_sel_vwap_diff("mpvh.vtpb", "mpvh.vtpb")
        # return alpha_ca.closures.bop.rkzs(result)
        return result
    @staticmethod
    def ts_reverse_sel():
        # return alpha_ca.closures.bop.rkzs(ts_reverse_sel())
        return ts_reverse_sel()