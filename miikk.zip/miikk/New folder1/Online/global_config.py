import os
from online2024final.dump_shm import *
import online2024final

WORKDIR = f"/data/beef2/{os.environ['USER']}/online_testing"
os.makedirs(WORKDIR, exist_ok=True, mode=0o771)
DATADIR = os.path.join(WORKDIR, "data")
os.makedirs(DATADIR, exist_ok=True, mode=0o771)
FITDIR  = os.path.join(WORKDIR, "fit")
os.makedirs(FITDIR, exist_ok=True, mode=0o771)

# ===============================SDI config
DEFAULT_CONFIG = dict(
    Y_pattern = {"pattern": online2024final.terms.Y, "columns": [], "calc_f": get_overnight_intraday_ret},
    W_pattern = {"pattern": online2024final.terms.W, "columns": ['is.active'], "calc_f": wgt_mul_index},
    univ = "G2548",
    is_start=20180101, is_end=20221231, os_start=20230101, os_end=20241227,
    stats_vd_start=20220101, fit_vd_start=20220701,
    exclude_start_date=20200201, exclude_end_date=20200231,
    is_output_ii=list(range(1,49,2)), os_output_ii=list(range(1,49,1)),
)