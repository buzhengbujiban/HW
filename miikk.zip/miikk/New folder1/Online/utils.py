from __future__ import annotations
import onnxruntime as ort
import pickle
from typing import List,Tuple,Dict
import xarray as xr
import os, shutil, json
import pickle
import subprocess
from pathlib import Path

from canopus_py.rnodes.ca_node import CANode, dump_term_sizes, dump_term_quantile
from canopus_py.rnodes.stats_node import StatsNode
from canopus_py.nb_utils import *
import online2024final
from online2024final.dump_shm import *
from online2024final.global_config import DEFAULT_CONFIG, WORKDIR, DATADIR, FITDIR

SDI = ['time', 'date', 'sid']

def get_univ_active(rroot=DATADIR, label='univ_active', start_date:int=None, end_date:int=None):
    base_config = CANode.base_config()
    base_config["EVENTS.market"] = "CNEQ"
    base_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    base_config["OUTPUT.terms"] = True

    CAv24Path = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels"
    file_pattern = os.path.join(CAv24Path, "I/fq5m/BB/terms.YYYYMMDD.sdiv")
    base_config["EVENTS.busdate_pattern"] = file_pattern
    base_config["DATA.panels"] += ["5min"]
    base_config["DATA.5min.pattern"] = file_pattern
    base_config["DATA.5min.columns"] = ['is.active']

    panel_name = "st_panel"
    base_config["DATA.panels"] += [panel_name]
    base_config[f"DATA.{panel_name}.pattern"] = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/D/eod/sid_st/st_YYYYMMDD.sdiv"  # 往前能到2007年
    base_config[f"DATA.{panel_name}.inclusive"] = False
    base_config[f"DATA.{panel_name}.columns"] = ["st"]

    panel_name = "index"
    index_columns = ["csi300", "csi500", "zz1000"]  # "sh50", "csi300", "csi500", "zz1000", "sci50"
    base_config["DATA.panels"] += [panel_name]
    base_config[f"DATA.{panel_name}.pattern"] = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"
    base_config[f"DATA.{panel_name}.inclusive"] = False
    base_config[f"DATA.{panel_name}.columns"] = index_columns

    panel_name = "univ_x"
    x_columns = ["topx", "midx"]  # , "smlx", "botx"
    base_config["DATA.panels"] += [panel_name]
    base_config[f"DATA.{panel_name}.pattern"] = "/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv"
    base_config[f"DATA.{panel_name}.inclusive"] = False
    base_config[f"DATA.{panel_name}.columns"] = x_columns

    univ_indicator = {}
    for univ in index_columns+x_columns:
        univ_indicator[univ] = ca.Sign(ca.Na20(univ))
    univ_indicator["csi800"] = ca.Sign(ca.Na20("csi300")) | ca.Sign(ca.Na20("csi500"))
    univ_indicator["zz1000_midx"] = ca.Sign(ca.Na20("zz1000")) | ca.Sign(ca.Na20("midx"))
    univ_indicator["ooi"] = ~(ca.Sign(ca.Na20("csi300")) | ca.Sign(ca.Na20("csi500")) | ca.Sign(ca.Na20("zz1000")))

    active = ca.Na20('is.active') * (~ca.Na20("st"))
    node = CANode(base_config, label=label, clean_dir_name=True, rnode_root=rroot, chain_name='')
    for univ, indicator in univ_indicator.items():
        node.node_config["CA.terms"][f"{univ}.active"] = ca.Na20(active * indicator)
        node.node_config["CA.terms"][univ] = indicator
    node.node_config["CA.terms"]['is.active'] = ca.Na20(active)

    node.set_run_dates()
    start_date = 0 if start_date is None else start_date
    end_date = 30000000 if end_date is None else end_date
    node.run_periods = [d for d in node.run_periods if d >= start_date and d <= end_date]
    node.run(para_spec=80)


def get_features_from_extra_tasks(extra_tasks_config):
    all_features = set()
    for task in extra_tasks_config:
        all_features = all_features.union(task["dataset"]["use_x_names"])
    all_features = sorted(list(all_features))
    return all_features

def get_feature_model_period(folder):
    feature_names = read_json(os.path.join(folder, "feature_names.json"))
    if "model.onnx" in os.listdir(folder):
        model_path = os.path.join(folder, "model.onnx")
    elif "lgb.model" in os.listdir(folder):
        model_path = os.path.join(folder, "lgb.model")
    elif "model.encoder.onnx" in os.listdir(folder) and "model.encoder_decoder.onnx" in os.listdir(folder):
        model_path = (os.path.join(folder, "model.encoder.onnx"), os.path.join(folder, "model.encoder_decoder.onnx"))
    else:
        raise ValueError("model not found")
    fit_task_cfg = read_json(os.path.join(folder, "fit_task_cfg.json"))
    periods = fit_task_cfg["task"]
    return feature_names, model_path, periods

def canopus_inference_allinone_helper(
    expt_folder, X_pattern=None,
    fit_ids=None, inference_periods=["valid", "test"], specified_run_periods=None,
    slurm_cfg=None, para_spec=80, **kwargs
):
    busdate_pattern = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"
    fitting_cfg = read_json(os.path.join(expt_folder, "fitting_cfg.json"))
    if X_pattern is None:  # 优先使用指定的X_pattern，比如可以用1min的pattern来inference
        with open(os.path.join(expt_folder, "X_pattern.pkl"), 'rb') as f:
            X_pattern = pickle.load(f)
    if fit_ids is None:  # 优先用指定的fit_ids，有些fit可能不用
        fit_ids = sorted([folder for folder in os.listdir(expt_folder) if re.match(r"^fit\.\d+$", folder)])
    rolling = "roller" in fitting_cfg

    if rolling:
        roll_type = fitting_cfg["roller"]["roll_type"]
        roll_ids = sorted([folder for folder in os.listdir(os.path.join(expt_folder, fit_ids[0])) if folder.startswith("roll.")])
        for roll_id in roll_ids:
            model_dict = {}
            shared_run_periods = None  # 确保多个fit的run_periods是相同的
            for fit_id in fit_ids:
                fit_folder = os.path.join(expt_folder, fit_id)
                folder = os.path.join(fit_folder, roll_id)
                feature_names, model_path, periods = get_feature_model_period(folder)
                run_periods = get_run_periods(busdate_pattern, **periods["test"])
                if roll_type == "vanilla" and roll_id == "roll.0":  # 目前rolling的valid都用第一个roll的
                    run_periods += get_run_periods(busdate_pattern, **periods["valid"])
                if roll_type == "croll" and roll_id == "roll.3":  # TODO: 目前croll默认分成4份，roll.3对应的是train period最接近样本外的日期，用它来inference样本外
                    run_periods += get_run_periods(busdate_pattern, **fitting_cfg["task"]["test"])
                if shared_run_periods is None:
                    shared_run_periods = run_periods
                else:
                    assert shared_run_periods == run_periods
                model_dict[fit_id] = {"feature_names": feature_names, "model_path": model_path}
            canopus_inference_allinone(X_pattern, model_dict=model_dict, outdir=expt_folder, run_periods=shared_run_periods if specified_run_periods is None else specified_run_periods, slurm_cfg=slurm_cfg, para_spec=para_spec, **kwargs)
    else:
        model_dict = {}
        shared_run_periods = None  # 确保多个fit的run_periods是相同的
        for fit_id in fit_ids:
            fit_folder = os.path.join(expt_folder, fit_id)
            folder = fit_folder
            feature_names, model_path, periods = get_feature_model_period(folder)
            run_periods = sorted(reduce(list.__add__, [get_run_periods(busdate_pattern, **periods[p]) for p in inference_periods]))
            if shared_run_periods is None:
                shared_run_periods = run_periods
            else:
                assert shared_run_periods == run_periods
            model_dict[fit_id] = {"feature_names": feature_names, "model_path": model_path}
        canopus_inference_allinone(X_pattern, model_dict=model_dict, outdir=expt_folder, run_periods=shared_run_periods if specified_run_periods is None else specified_run_periods, slurm_cfg=slurm_cfg, para_spec=para_spec, **kwargs)

def get_underlying_function(function):
    if isinstance(function, partial):
        function = function.func
    return function

def canopus_inference_allinone(
    X_pattern: Dict[str, dict|List[dict]], model_dict:dict, outdir:str, 
    run_periods:List[str]=None, start_date:str|int=None, end_date:str|int=None, univ="G2548",
    include_alpha_residual:list=[], freq_m=5, ae_infer=["encoded", "decoded"],
    slurm_cfg=None, para_spec=80,
):
    busdate_pattern = "/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv"
    CANode.DEFAULT_CA_BINARY = "/data/nasData/apps/autobld/equity/canopus"
    node_config = CANode.base_config()
    node_config["EVENTS.market"] = "CNEQ"
    node_config["EVENTS.busdate_pattern"] = busdate_pattern
    if univ in UNIV:
        node_config["CA.univ"] = UNIV[univ]
    elif univ in ["sh50", "csi300", "csi500", "zz1000", "sci50"] :
        node_config["CA.univ"] = f"/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv:{univ}"
    elif univ == "csi800":
        node_config["CA.univ"] = f"/data/beef2/junming/data/index_component/terms.YYYYMMDD.sdiv:{univ}"
    elif univ in ["topx", "midx", "smlx", "botx"]:
        node_config["CA.univ"] = f"/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv:{univ}"
    else:
        raise NotImplementedError(f"Unknown {univ}")
    node_config["OUTPUT.terms"] = True
    node_config["CA.freq_m"] = freq_m

    if include_alpha_residual or "reg_residual" in ae_infer:
        panel_name = "weight_panel"
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = online2024final.terms.W
        node_config[f"DATA.{panel_name}.columns"] = ['is.active']
        panel_name = "st_panel"
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = online2024final.terms.ST
        node_config[f"DATA.{panel_name}.inclusive"] = False
        node_config[f"DATA.{panel_name}.columns"] = ["st"]
        panel_name = "y_panel"
        node_config["DATA.panels"] += [panel_name]
        node_config[f"DATA.{panel_name}.pattern"] = online2024final.terms.Y
        w = ca.Na20('is.active') * (~ca.Na20("st"))

    for Xname, pattern_dicts in X_pattern.items():  # 支持多个Xname,一个Xname对应shm中的一个label，即一个文件
        configurate_node(node_config=node_config, label=Xname, pattern_dicts=pattern_dicts)
    feature_expr_map = node_config.pop("CA.terms")  # 要pop出来，否则这些x也会被inference dump出来
    node_config["CA.terms"] = {}

    if run_periods is None:  # 优先用指定的run_periods
        run_periods = get_run_periods(busdate_pattern, start_date=start_date, end_date=end_date)

    suffix = "_1m" if freq_m == 1 else ''
    outdir = os.path.normpath(outdir)
    parts = outdir.split(os.sep)
    if parts[-1] == "expt_folder":  # new
        parts = parts[:-1]
    rnode_root = '/'.join(parts[:-1])
    chain_name = parts[-1]
    node = CANode(node_config, rnode_root=rnode_root, chain_name=chain_name, label="canopus_inference_alpha"+suffix, clean_dir_name=True)
    per_fit_inference = False
    
    for fit_id, info in model_dict.items():
        feature_names = info["feature_names"]
        model_path = info["model_path"]
        x = [feature_expr_map[term] for term in feature_names]
        if isinstance(model_path, tuple):  # ae, then per_fit_inference
            per_fit_inference = True
            encoder_path, encoder_decoder_path = model_path
            if "encoded" in ae_infer:
                encoder_output = ca.NnAlpha("onnx", encoder_path, x)
                session = ort.InferenceSession(encoder_path)
                bottleneck_dim = session.get_outputs()[0].shape[1]
                encoded_node = CANode(node_config, rnode_root="", chain_name=os.path.join(outdir, fit_id), label="canopus_inference_encoded"+suffix, clean_dir_name=True)
                for i in range(bottleneck_dim):
                    encoded_node.node_config["CA.terms"][f"encoded_{i}"] = ca.Sel(encoder_output, f"v{i}")
                encoded_node.run_periods = run_periods
                if ca.use_nugg_cache:
                    encoded_node.node_config["CA.nuggs"] = ca.get_nugg_cache()
                encoded_node.run(para_spec=para_spec, slurm_cfg=slurm_cfg)
            if "decoded" in ae_infer:
                decoded_node = CANode(node_config, rnode_root="", chain_name=os.path.join(outdir, fit_id), label="canopus_inference_decoded"+suffix, clean_dir_name=True)
                decoder_output = ca.NnAlpha("onnx", encoder_decoder_path, x)
                for i, term in enumerate(feature_names):
                    decoded_node.node_config["CA.terms"][f"decoded_{i}"] = ca.Sel(decoder_output, f"v{i}")
                decoded_node.run_periods = run_periods
                if ca.use_nugg_cache:
                    decoded_node.node_config["CA.nuggs"] = ca.get_nugg_cache()
                decoded_node.run(para_spec=para_spec, slurm_cfg=slurm_cfg)
            if "reg_residual" in ae_infer:
                resi_node = CANode(node_config, rnode_root="", chain_name=os.path.join(outdir, fit_id), label="canopus_inference_reg_residual"+suffix, clean_dir_name=True)
                decoder_output = ca.NnAlpha("onnx", encoder_decoder_path, x)
                for i, term in enumerate(feature_names):
                    resi_node.node_config["CA.terms"][f"resi_{i}"] = ca.RegRes(ca.Na20(term), ca.Sel(decoder_output, f"v{i}"), w=w)
                resi_node.run_periods = run_periods
                if ca.use_nugg_cache:
                    resi_node.node_config["CA.nuggs"] = ca.get_nugg_cache()
                resi_node.run(para_spec=para_spec, slurm_cfg=slurm_cfg)
        else:  # 正常alpha inference
            if model_path.endswith("model.onnx"):
                alpha = ca.NnAlpha("onnx", model_path, x)
            elif model_path.endswith("lgb.model"):
                alpha = ca.TreeAlpha("lgb", model_path, x)
            else:
                raise NotImplementedError(f"Unknown model type: {model_path}")
            node.node_config["CA.terms"][f"{fit_id}.alpha"] = alpha
            for y in include_alpha_residual:
                node.node_config["CA.terms"][f"{fit_id}.{y}.res"] = ca.RegRes(ca.Na20(y), alpha, w=w)
    if not per_fit_inference:
        node.run_periods = run_periods
        if ca.use_nugg_cache:
            node.node_config["CA.nuggs"] = ca.get_nugg_cache()
        node.run(para_spec=para_spec, slurm_cfg=slurm_cfg)



def extract_para(d, para=None):
    if para is None:
        para = {}
    for k, v in d.items():
        if isinstance(v, dict):
            extract_para(v, para)
        else:
            para[k] = v
    return pd.Series(para)

def get_paras(expt_folder, exclude=[]):
    if "expt_folder" in os.listdir(expt_folder):
        expt_folder = os.path.join(expt_folder, "expt_folder")
    fit_ids = [folder for folder in os.listdir(expt_folder) if re.match(r"^fit\.\d+$", folder) and folder not in exclude]
    fit_ids = sorted(fit_ids, key=lambda s: int(s.split('.')[1]))
    scenarios = read_json(os.path.join(expt_folder, "scenarios.json"))
    for fit_id in scenarios.keys():  # temp hack
        try:
            scenarios[fit_id]["dataset"]["wIs"] = list(scenarios[fit_id]["dataset"]["wIs"].keys())[0]
        except Exception as e:
            pass
    paras = [extract_para(scenarios[fit_id]) for fit_id in fit_ids]
    paras = dict(zip(fit_ids, paras))
    paras = pd.DataFrame(paras).T
    return paras

def get_concat_data(pattern, start_date=None, end_date=None, columns:List[str]=None, return_type="df", drop_last=0):
    dates = get_run_periods(pattern, start_date, end_date, drop_last=drop_last)
    files = [pattern.replace("YYYYMMDD", str(date)) for date in dates]
    read_func = read_shm_as_xr if pattern.startswith("/dev/shm/") else panel.read
    if columns is None:
        xarrs = [read_func(file) for file in files]
    else:
        xarrs = [read_func(file).sel(V=columns) for file in files]
    xarr = xr.concat(xarrs, dim="D")
    if xarr.dims != ("S", "D", "I", "V"):
        xarr = xarr.transpose("S", "D", "I", "V")
    if return_type == "xr":
        return xarr
    df = panel.sdiv2df(xarr, order='C')
    return df

def get_ridge_coefficients(combined_valid, features, weight="weight", target='y', alpha=0.1, ensemble_name='', ols=False, nonnegative=True):
    from sklearn.linear_model import Ridge, LinearRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.pipeline import make_pipeline
    w1_combined_valid = combined_valid[combined_valid[weight] == 1].copy()
    X_train, y_train = w1_combined_valid[features], w1_combined_valid[target]
    if ols:
        model = LinearRegression(fit_intercept=False).fit(X_train, y_train)
        coefficients = model.coef_
    else:
        X_scaler = StandardScaler(with_mean=False)
        X_train = X_scaler.fit_transform(X_train)
        y_scaler = StandardScaler(with_mean=False)
        y_train = y_scaler.fit_transform(y_train.to_frame()).squeeze()
        model = Ridge(alpha=alpha, fit_intercept=False).fit(X_train, y_train)
        coefficients = model.coef_ / X_scaler.scale_ * y_scaler.scale_
    if nonnegative:
        coefficients = np.where(coefficients < 0, 0, coefficients)
    coefficients = pd.Series(coefficients, index=features).round(6)
    print(f"---------{ensemble_name}:coefficients---------")
    print(coefficients)
    
    return coefficients

def calc_stats(
    node_name, pattern_dict:dict|list, start_date=20230101, end_date=20240731, exclude_days:List[int]=[20240201,20240202,20240205,20240206,20240207,20240208],
    rename_col=True, labels=["mret24h"], alpha_columns:List[str]=None, rename_map={},
    univ=None, wgt_dict:dict={"w_c1": None}, num_groups=0, raw_only=False, extra_transform=[], ema_hl=[], output_iis: Dict[str, List[int]]=None, require_terms=False,
    external_labels:List[dict]=[], vd_start=None, os_start=None,
    refresh_data=False, wyweighted_pow=None, wy="mret24h", condition_separate=False, ensemble_weights:Dict[str,dict]={},
    slurm_cfg=None, para_spec=120,
    rnode_root="/data/beef2/junming/rroot",
):

    CANode.DEFAULT_CA_BINARY = "/data/beef2/bin/unstable/canopus"
    node_dir = os.path.join(rnode_root, node_name)
    if os.path.exists(node_dir):
        shutil.rmtree(node_dir)
    base_config = CANode.base_config()
    ca_node = CANode(base_config, rnode_root=rnode_root, chain_name='', label=node_name, clean_dir_name=True)
    # 加载univ:注意univ能影响后续的zs或者group
    if univ is None:
        ca_node.node_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    elif univ in ["sh50", "csi300", "csi500", "zz1000"]:
        ca_node.node_config["CA.univ"] = f"/data/nasData/chinaEquityData/panel/index/index-YYYYMMDD.sdiv:{univ}"
    elif univ in ["topx", "midx", "smlx", "botx"]:
        ca_node.node_config["CA.univ"] = f"/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv:{univ}"
    elif univ in ["csi800", "zz1000_midx", "ooi"]:
        ca_node.node_config["CA.univ"] = f"{DATADIR}/univ_active/terms.YYYYMMDD.sdiv:{univ}"
    else:
        raise NotImplementedError(f"Unknown Univ: {univ}")

    panel_name = "st_panel"
    ca_node.node_config["DATA.panels"] += [panel_name]
    ca_node.node_config[f"DATA.{panel_name}.pattern"] = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/D/eod/sid_st/st_YYYYMMDD.sdiv"  # 往前能到2007年
    ca_node.node_config[f"DATA.{panel_name}.inclusive"] = False
    ca_node.node_config[f"DATA.{panel_name}.columns"] = ["st"]

    w_terms = {}
    for name, w in wgt_dict.items():
        w = ca.C(1) if w is None else ca.Sign(ca.Na20(w))  # 暂时只支持上面的index和univ_x
        w *= (~ca.Na20("st"))
        if wyweighted_pow:
            w *=ca.Na20(ca.NumPow(ca.Abs(wy), wyweighted_pow))
        w_terms[name] = w

    if output_iis is not None:  # e.g. {"9:35": [1], "op": list(range(1,7))}
        w_ii_terms = {}
        for ii_name, output_ii in output_iis.items():
            ii_wgt = ca.C(0)
            for ii in output_ii:
                ii_wgt = ii_wgt | (ca.IIndex() == ca.C(ii))
            w_ii_terms |= {f"{name}.{ii_name}": w & ii_wgt for name, w in w_terms.items()}
        w_terms |= w_ii_terms
    ca_node.node_config["STATS.w_terms"] = w_terms  # wt.csv Canopus背后还会自动乘上is.active

    # 加载5min&label
    CAv24Path = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels"
    y_pattern = os.path.join(CAv24Path, "Y/Y_V5/terms.YYYYMMDD.sdiv")
    w_pattern = os.path.join(CAv24Path, "I/fq5m/BB/terms.YYYYMMDD.sdiv")
    ca_node.node_config["EVENTS.busdate_pattern"] = y_pattern  # "/data/beef2/data/CA.v24.1001/CNEQ/Panels/Y/Y_V5/terms.YYYYMMDD.sdiv"  # Y 没啥问题 跟原来对的上
    ca_node.node_config["DATA.panels"] += ["5min"]
    ca_node.node_config["DATA.5min.pattern"] = w_pattern
    ca_node.node_config["DATA.5min.columns"] = ["is.active"]
    ca_node.node_config["DATA.panels"] += ["Y"]
    ca_node.node_config["DATA.Y.pattern"] = y_pattern
    y_columns = read_columns_from_pattern(y_pattern)
    ca_node.node_config["DATA.Y.columns"] = y_columns
    y_terms = {y: y for y in y_columns}
    y_terms['bpret24h'] = ca("mret24h") - ca("bret24h")
    y_terms['mret_ovnt'] = ca("mret1o") - ca("mret0e")
    y_terms['bret_ovnt'] = ca("bret1o") - ca("bret0e")
    y_terms['mret24h1h'] = ca("mret24h") - ca("mret1h")
    y_terms['bpret1h'] = ca("mret1h") - ca("bret1h")
    thresholds = [0.07]
    for threshold in thresholds:
        term = "mret24h"
        y_terms[f"{term}.clip{threshold:.2f}"] = ca.Na20(ca.IfElse(ca(term) > ca.C(threshold), ca.C(threshold), ca.IfElse(ca(term) < ca.C(-threshold), ca.C(-threshold), ca(term))))
    for external_label_dict in external_labels:
        panel_name = external_label_dict["name"]
        pattern = external_label_dict["pattern"]
        ca_node.node_config["DATA.panels"] += [panel_name]
        ca_node.node_config[f"DATA.{panel_name}.pattern"] = pattern
        columns = read_columns_from_pattern(pattern)
        if external_label_dict["rename"]:
            columns = [f"{panel_name}__{col}" for col in columns]
            ca_node.node_config[f"DATA.{panel_name}.column_masks"] = columns
        assert len(np.intersect1d(columns, list(y_terms.keys()))) == 0, f"duplicated y columns: {columns}"
        y_terms.update({y: ca(y) for y in columns})
    ca_node.node_config["OUTPUT.stats"] = (len(labels) > 0)
    ca_node.node_config["STATS.y_terms"] = {k: v for k, v in y_terms.items() if k in labels}
    ca_node.node_config["OUTPUT.terms"] = require_terms

    # 加载yhat/alpha
    yhats = []
    ## 从inference panel中直接读取某些列
    sizes_dict_all = {}
    quantiles_median_list = []
    for panel_name, pattern in pattern_dict.items():
        if ":" in pattern:
            pattern, columns = pattern.split(":")
            columns = columns.split(",")
        else:
            columns = [col for col in read_columns_from_pattern(pattern) if col not in ['y', 'weight']]
        if "mad" in extra_transform:
            assert not rename_col, "conflict: mad and rename_col"
            try:
                sizes_dict = dump_term_sizes(pattern, dates=None, refresh_data=refresh_data, mad=True)
            except FileNotFoundError:
                try:
                    sizes_dict = dump_term_sizes(pattern, dates=None, refresh_data=True, mad=True)
                except PermissionError:
                    sizes_dict = dump_term_sizes(pattern, dates=None, refresh_data=True, dump_files=False, mad=True)
            sizes_dict_all |= sizes_dict  # 如果是这样的话就不允许rename_col了注意！！feature不能有重名的
        if "normal" in extra_transform:
            assert not rename_col, "conflict: normal and rename_col"
            try:
                quantiles_median, nuniques_series = dump_term_quantile(pattern, dates=None, refresh_data=refresh_data, dump_files=True, bins=100)
            except FileNotFoundError:
                try:
                    quantiles_median, nuniques_series = dump_term_quantile(pattern, dates=None, refresh_data=True, dump_files=True, bins=100)
                except PermissionError:
                    quantiles_median, nuniques_series = dump_term_quantile(pattern, dates=None, refresh_data=True, dump_files=False, bins=100)
            quantiles_median_list.append(quantiles_median)
        
        ca_node.node_config["DATA.panels"] += [panel_name]
        ca_node.node_config[f"DATA.{panel_name}.pattern"] = pattern
        ca_node.node_config[f"DATA.{panel_name}.columns"] = columns
        I = panel.get_coords(find_files_from_pattern(pattern)[-1], "I")
        if len(I) == 1:
            inclusive = False if I[0] == "00:00:00" else True
            ca_node.node_config[f"DATA.{panel_name}.inclusive"] = inclusive
        if rename_col:  # 主要是有多个panel的时候可能会重名
            renamed_columns = [f"{panel_name}__{col}" for col in columns]
            ca_node.node_config[f"DATA.{panel_name}.column_masks"] = renamed_columns
            yhats.extend(renamed_columns)
        else:
            yhats.extend(columns)
    if quantiles_median_list:
        quantiles_median = pd.concat(quantiles_median_list, axis=0)

    yhats = {rename_map.get(yhat, yhat): yhat for yhat in yhats}  # list to dict to fit in yhat_ensemble
    yhat_names = list(yhats.keys())
    if len(set(yhat_names)) != len(yhat_names):
        counts = pd.Series(yhat_names).value_counts()
        print(counts[counts>1])
        raise ValueError(f"NAME CONFLICT")
    ## 由ensemble得到一些yhat,yhat名字是在rename_col和rename_map之后
    for rename, ensemble_weight in ensemble_weights.items():
        yhat_ensemble = ca.C(0)
        for yhat, weight in ensemble_weight.items():
            yhat_ensemble += ca.C(weight) * ca.Na20(yhats[yhat])
        yhats[rename] = yhat_ensemble

    if alpha_columns is not None:
        yhats = {k:v for k,v in yhats.items() if k in alpha_columns}

    # 对yhat进行处理
    wgt = ca.Na20('is.active') * (~ca.Na20("st"))  # 下面zs和group要用
    for yhat_name, yhat in yhats.items():  # string yhat names
        if raw_only:
            ca_node.node_config["CA.terms"][yhat_name] = ca.Na20(yhat)
        elif condition_separate: # 可以多写一些condition_separate方法
            ca_node.node_config["CA.terms"][f"{yhat_name}.pos"] = ca.Na20(ca.IfElse(ca(yhat) > ca.C(0), ca(yhat), ca.C(0)))
            ca_node.node_config["CA.terms"][f"{yhat_name}.neg"] = ca.Na20(ca.IfElse(ca(yhat) < ca.C(0), ca(yhat), ca.C(0)))
        else:
            ca_node.node_config["CA.terms"][f"{yhat_name}.raw"] = ca.Na20(yhat)
            if "zs" in extra_transform:
                ca_node.node_config["CA.terms"][f"{yhat_name}.zs"] = ca.Na20(ca.XsZScore(ca.IfElse(wgt, yhat, ca.C("nan"))))
            if "mad" in extra_transform:
                ca_node.node_config["CA.terms"][f"{yhat_name}.mad"] = ca.Na20(ca.Clip(ca(yhat) / ca.C(sizes_dict_all[yhat]), 5))
            if "normal" in extra_transform:
                bin_edges = quantiles_median.loc[yhat]
                if bin_edges.isna().all():  # nunique个数不够算不出bin
                    pass # term = ca.Na20(yhat)
                else:
                    ca_node.node_config["CA.terms"][f"{yhat_name}.normal"] = ca.Na20(ca.NormalDist(ca(yhat), bin_edges.tolist()))
        for hl in ema_hl:
            ca_node.node_config["CA.terms"][f"{yhat_name}.ema{hl}"] = ca.Ema(ca.Na20(yhat), hl, rpii=0)
        # ca_node.node_config["CA.terms"][f"{yhat}.dm"] = ca.Na20(ca(yhat) - ca.XsMean(ca.IfElse(wgt, yhat, ca.C("nan"))))
    ## 多空分组
    if num_groups:
        for yhat_name, yhat in yhats.items():
            for g in range(1, num_groups+1):
                start = ca.C(-1 + 2*(g-1)/num_groups)
                end = ca.C(-1 + 2*g/num_groups)
                masked_yhat = ca(yhat) * ca.IfElse(wgt, ca.C(1), ca.C("nan"))
                ca_node.node_config["CA.terms"][f"{yhat_name}.g{g}"] = ca.IfElse((ca.XsRank2(masked_yhat)>start)&(ca.XsRank2(masked_yhat)<=end), ca.C(1), ca.C(0))
                for hl in ema_hl:
                    masked_ema_yhat = ca.Ema(ca.Na20(yhat), hl, rpii=0) * ca.IfElse(wgt, ca.C(1), ca.C("nan"))
                    ca_node.node_config["CA.terms"][f"{yhat_name}.ema{hl}.g{g}"] = ca.IfElse((ca.XsRank2(masked_ema_yhat)>start)&(ca.XsRank2(masked_ema_yhat)<=end), ca.C(1), ca.C(0))

    # run CANode & StatsNode
    ca_node.set_run_dates()
    start_date = 0 if start_date is None else int(start_date)
    end_date = 30000000 if end_date is None else int(end_date)
    ca_node.run_periods = [i for i in ca_node.run_periods if i >= start_date and i <= end_date and i not in exclude_days]
    if ca.use_nugg_cache:
        ca_node.node_config["CA.nuggs"] = ca.get_nugg_cache()
    ca_node.run(para_spec=para_spec, slurm_cfg=slurm_cfg)
    if ca_node.node_config["OUTPUT.stats"]:
        try:
            StatsNode({
                "wgts":list(ca_node.node_config["STATS.w_terms"].keys()),
                "vd_start":vd_start,
                "os_start":os_start,
            }, xy_pattern=ca_node).run(print_df=True, refresh_data=True, corr_threshold=0.7).run()
        except Exception as e:  # mret24h.res not found
            print(f"running StatsNode error: {e}")


def show_stats(
    node_name, select:str|list="raw",
    diffs:List[Tuple[str, str]]=[], labels=["mret24h"], alpha_columns:List[str]=None, ws:List[str]=None, show_g=[1, 10], p='all',
    return_dfss=False, stats_dir='/data/beef2/junming/rroot/calc_stats/'
):
    find_dates_from_pattern.cache_clear()
    panel_stats_dir = os.path.join(stats_dir, node_name)
    newest_stats = max([f for f in os.listdir(panel_stats_dir) if re.match(r'\d{3}\.stats', f)])
    df, ss, _ = StatsNode.read_stats(os.path.join(panel_stats_dir, newest_stats))
    if return_dfss:
        return df, ss
    
    alpha_index = df.index.get_level_values(2).unique()
    if ws is None:
        ws = df.index.get_level_values(0).unique().tolist()
    if select is None:
        if alpha_columns is not None:
            alpha_index = np.array([f for f in alpha_columns if f in alpha_index])
        df = df[df.index.get_level_values(2).isin(alpha_index)]
        df = df[df.index.get_level_values(0).isin(ws)]
        for label in labels:
            label_df = df[df.index.get_level_values(1) == label]
            if alpha_columns is None:
                cpdf(label_df.sort_values(("is", "FR"), ascending=False, key=abs), 200)
            else:
                cpdf(label_df.loc[(slice(None), slice(None), alpha_index)], 200)
            ss_all = sel_all_series(ss, x=alpha_index.tolist(), w=["w_c1"], y=[label], p=p)
            plot_stats(ss_all)
            
    else:  # 有raw或者zs等后缀
        if alpha_columns is not None:
            alpha_index = alpha_index[np.array([a[:a.rfind(".")] in alpha_columns for a in alpha_index])]
        
        alpha_g = alpha_index[np.array([bool(re.match(r"g\d", x[-1])) for x in alpha_index.str.split(".")])].tolist()
        alpha_processed = {}
        other_processed_methods = set([x.split(".")[-1] for x in np.setdiff1d(alpha_index, alpha_g)])  # {'raw', 'zs'}
        for method in other_processed_methods:
            alpha_processed[method] = alpha_index[alpha_index.str.endswith(f'.{method}')].tolist()
        
        num_groups = len(np.unique([f.split(".")[-1] for f in alpha_g]))  # 注意这里默认每个alpha都在calc的时候分了一样的组数
        if show_g is not None:
            alpha_g = [a for a in alpha_g if int(a.split(".")[-1][1:]) in show_g]
        alpha_processed["g"] = alpha_g
        if isinstance(select, str):
            select = [select]
        alpha_select = []
        for sel in select:
            alpha_select.extend(alpha_processed[sel])
        
        df.loc[df.index.get_level_values(2).isin(alpha_g),  ('is', 'FR')] *= np.sqrt(num_groups)  # 需要adjust一下，分母np.sqrt(w.sum())，这个数字除以np.sqrt(num_groups)才是正确的等权组合FR
        
        df = df[df.index.get_level_values(2).isin(alpha_select)]
        df = df[df.index.get_level_values(0).isin(ws)]
            
        for label in labels:
            for w in ws:
                cpdf(df[(df.index.get_level_values(1) == label) & (df.index.get_level_values(0) == w)], 200)
                series_diffs = []
                for (alpha1, alpha2) in diffs:
                    for sel in select:
                        if sel == "g":
                            for g in show_g:
                                alpha1_s_name, alpha2_s_name = f"{alpha1}.{sel}{g}", f"{alpha2}.{sel}{g}"
                                s_diff = series_diff(ss, alpha1_s_name, alpha2_s_name, p, w, label)
                                series_diffs.append(s_diff)
                                print(f"Diff({alpha1_s_name}, {alpha2_s_name}) Sharpe: {SR(s_diff): .2f}")
                        else:
                            alpha1_s_name, alpha2_s_name = f"{alpha1}.{sel}", f"{alpha2}.{sel}"
                            s_diff = series_diff(ss, alpha1_s_name, alpha2_s_name, p, w, label)
                            series_diffs.append(s_diff)
                            print(f"Diff({alpha1_s_name}, {alpha2_s_name}) Sharpe: {SR(s_diff): .2f}")
                ss_all = sel_all_series(ss, x=alpha_select, w=w, y=[label], p=p)
                ss_g = [s * np.sqrt(num_groups) for s in ss_all if s.name.split("|")[0] in alpha_g]
                ss_other = [s for s in ss_all if s.name.split("|")[0] not in alpha_g]
                plot_stats(ss_g+ss_other + series_diffs)

def SR(df_FR_series):
    return (df_FR_series.mean() / df_FR_series.std() * np.sqrt(252))


def dump_KDteacher(expt_folder, fit_ys):
    valid_start, valid_end = DEFAULT_CONFIG["fit_vd_start"], DEFAULT_CONFIG["is_end"]  # use validation set to perform ridge
    w_name, y_names = "is.active", fit_ys
    drop_last = 1
    w = get_concat_data(online2024final.terms.W, columns=[w_name], start_date=valid_start, end_date=valid_end, drop_last=drop_last)
    y = get_concat_data(online2024final.terms.Y, columns=y_names, start_date=valid_start, end_date=valid_end, drop_last=drop_last)

    paras = get_paras(expt_folder)
    panel_name = Path(expt_folder).stem
    pattern_list = [{
        "pattern": os.path.join(expt_folder, "canopus_inference_alpha/terms.YYYYMMDD.sdiv"), "name": panel_name,
        "columns": {f"{fit_id}.alpha": f"{paras.loc[fit_id, 'fit_y']}_{paras.loc[fit_id, 'group_name']}" for fit_id in paras.index}
    }]

    pattern_dict = {}
    rename_map = {}
    for d in pattern_list:
        pattern_dict[d['name']] = f"{d['pattern']}:{','.join(d['columns'].keys())}"
        rename_map |= {f"{d['name']}__{k}": v for k, v in d['columns'].items()}

    yhats_valid_list = []
    for d in pattern_list:
        yhats_valid_list.append(get_concat_data(d["pattern"], start_date=valid_start, end_date=valid_end, columns=list(d["columns"].keys())).rename(columns=d["columns"]))

    combined_valid = None
    for yhat in yhats_valid_list:
        if combined_valid is None:
            combined_valid = yhat
        else:
            combined_valid = combined_valid.merge(yhat, on=SDI)
    combined_valid = combined_valid.merge(w, on=SDI, how='left').merge(y, on=SDI, how='left')

    ensemble_weights = {}
    for fit_y in fit_ys:
        features = combined_valid.columns[combined_valid.columns.str.startswith(f"{fit_y}_batch")].tolist()
        ensemble_weights[f"en_{fit_y}"] = get_ridge_coefficients(combined_valid, features=features, weight=w_name, target=fit_y, ensemble_name=f"en_{fit_y}").to_dict()

    node_name = "teacher"
    calc_stats(node_name, pattern_dict, rename_map=rename_map, ensemble_weights=ensemble_weights, labels=[],
               start_date=DEFAULT_CONFIG["is_start"], end_date=DEFAULT_CONFIG["os_end"],
               require_terms=True, alpha_columns=list(ensemble_weights.keys()), raw_only=True, rnode_root=expt_folder,)
    print(f"teacher panel at {expt_folder} is dumped!")


def tree_impSRtopfs_fitting(imp_fit_ys, SR_fit_ys, slurm=True, batch_num=1500):
    from qrfitter3.reports.utils import lgb_importance_df

    rnode_root = FITDIR
    slurm_folder = os.path.join(rnode_root, "slurm")
    slurm_task_name = "static"
    os.makedirs(os.path.join(slurm_folder, slurm_task_name), mode=0o700, exist_ok=True)
    cmd_file_path = os.path.join(slurm_folder, slurm_task_name, 'all_fit_jobs.sh')
    commands_log_file = os.path.join(slurm_folder, slurm_task_name, 'logs')

    node_name = "terms_stats"
    df, ss = show_stats(node_name=node_name, return_dfss=True, stats_dir=DATADIR)
    yhat_patterns = {}
    with open(cmd_file_path, 'w') as out_file:
        for fit_y in imp_fit_ys + SR_fit_ys:
            if fit_y in imp_fit_ys:
                method = "imp"
                model_file = os.path.join(rnode_root, f"tree_forfs_{fit_y}/expt_folder/fit.0/lgb.model")
                print(model_file)
                features = lgb_importance_df(model_file)[0].sort_values("score_by_gain", ascending=False)["term"].tolist()[:batch_num]
            else:
                method = "SR"
                label_df = df.xs("w_c1").xs(fit_y)
                ratio = (label_df[("vd", method)] / label_df[("is", method)])
                features = (label_df[("is", method)].abs() * (ratio.clip(lower=0, upper=1) ** 0.5)).dropna().sort_values(ascending=False).index.tolist()[:batch_num]
            
            fitting_name = f"{fit_y}_{method}{batch_num}"
            Xname = f"X.{fitting_name}"
            X_pattern = {Xname: {"pattern": online2024final.terms.mlp_all_latest, "columns": features}}
            temp_file_folder = os.path.join(slurm_folder, slurm_task_name, fitting_name)  # 临时存放X_pattern和rolling等文件，因为不好通过command 传递
            os.makedirs(temp_file_folder, mode=0o700, exist_ok=True)
            X_pattern_path = os.path.join(temp_file_folder, "X_pattern.pkl")
            with open(X_pattern_path, "wb") as f:
                pickle.dump(X_pattern, f)
            script_path = os.path.join(os.path.dirname(__file__), "tree.py")
            cmd_line = f"python {script_path} --fitting_name {fitting_name} --X_pattern {X_pattern_path} \
                --fit_y {fit_y} --rnode_root {rnode_root}"
            out_file.write(cmd_line)
            out_file.write('\n')
            yhat_patterns[fit_y] = os.path.join(FITDIR, fitting_name, 'canopus_inference_alpha/terms.YYYYMMDD.sdiv')
    if slurm:
        cmd = f"""cat {cmd_file_path} | run-parallel -w {commands_log_file} -k \
        --slurm --slurmQueue fqueue --ompThreads 100 --timeout 23:59:59 --retries 0 --memPerCpu 8000 --slurmExclude ps1,ps5,ps6"""
    else:
        cmd = f"cat {cmd_file_path} | run-parallel -j 1 -w {commands_log_file} -k"
    print(cmd)
    subprocess.run(cmd, shell=True, text=True)
    return yhat_patterns


def get_ensemble_weights_24h(pattern_list):
    valid_start, valid_end = DEFAULT_CONFIG["fit_vd_start"], DEFAULT_CONFIG["is_end"]  # use validation set to perform ridge
    w_name, y_name = "is.active", "mret24h"
    drop_last = 1
    w = get_concat_data(online2024final.terms.W, columns=[w_name], start_date=valid_start, end_date=valid_end, drop_last=drop_last)
    y = get_concat_data(online2024final.terms.Y, columns=[y_name], start_date=valid_start, end_date=valid_end, drop_last=drop_last)

    yhats_valid_list = []
    for d in pattern_list:
        yhats_valid_list.append(get_concat_data(d["pattern"], start_date=valid_start, end_date=valid_end, columns=list(d["columns"].keys()), drop_last=drop_last).rename(columns=d["columns"]))
    combined_valid = None
    for yhat in yhats_valid_list:
        if combined_valid is None:
            combined_valid = yhat
        else:
            combined_valid = combined_valid.merge(yhat, on=SDI)
    combined_valid = combined_valid.merge(w, on=SDI, how='left').merge(y, on=SDI, how='left')

    mlp_all = ["MLP_mret24h", "MLP_bret24h", "MLP_bpret24h"]
    tree_all = ["Tree_mret24h", "Tree_bret24h", "Tree_bpret24h",]
    tree_mlp_mret = ["Tree_mret24h", "MLP_mret24h",]
    tree_mlp_bpret = ["Tree_bpret24h", "MLP_bpret24h",]
    mlp_tree_all = mlp_all + tree_all
    model_dict = {
        "mlp_all": mlp_all,
        "tree_all": tree_all,
        "mlp_tree_all": mlp_tree_all,
        "tree_mlp_mret": tree_mlp_mret,
    }
    ensemble_weights = {}
    for name, models in model_dict.items():
        coefficients = get_ridge_coefficients(combined_valid, features=models, weight=w_name, target=y_name, ensemble_name=name)  # , alpha=1e7
        ensemble_weights[name] = coefficients.to_dict()
    ensemble_weights["tree_mlp_mbp"] = {k: 0.3 for k in tree_mlp_mret} | {k: 0.2 for k in tree_mlp_bpret}
    return ensemble_weights

def get_ensemble_weights_1h(pattern_list):
    valid_start, valid_end = DEFAULT_CONFIG["fit_vd_start"], DEFAULT_CONFIG["is_end"]  # use validation set to perform ridge
    w_name, y_name = "is.active", "mret1h"
    w = get_concat_data(online2024final.terms.W, columns=[w_name], start_date=valid_start, end_date=valid_end)
    y = get_concat_data(online2024final.terms.Y, columns=[y_name], start_date=valid_start, end_date=valid_end)

    yhats_valid_list = []
    for d in pattern_list:
        yhats_valid_list.append(get_concat_data(d["pattern"], start_date=valid_start, end_date=valid_end, columns=list(d["columns"].keys())).rename(columns=d["columns"]))
    combined_valid = None
    for yhat in yhats_valid_list:
        if combined_valid is None:
            combined_valid = yhat
        else:
            combined_valid = combined_valid.merge(yhat, on=SDI)
    combined_valid = combined_valid.merge(w, on=SDI, how='left').merge(y, on=SDI, how='left')
    model_dict = {
        "New_FGTE_Tree": ['Newlrstep', 'FGTE_2g', "tree"],
    }

    ensemble_weights = {}
    for name, models in model_dict.items():
        coefficients = get_ridge_coefficients(combined_valid, features=models, weight=w_name, target=y_name, ensemble_name=name)
        ensemble_weights[name] = coefficients.to_dict()
    return ensemble_weights


def dump_combined_model_CAjson(pattern_list, ensemble_weights, horizon="24h"): # 1h
    for i, pattern_dict in enumerate(pattern_list):
        config = read_json(pattern_dict["pattern"].replace("terms.YYYYMMDD.sdiv", "config.json"))
        config["CA.terms"] = {rename: config["CA.terms"][fit_id] for fit_id, rename in pattern_dict['columns'].items()}
        for model_term in config["CA.terms"].values():
            model_file = re.search(r',([^,]+),', model_term).group(1)
            if os.path.isfile(model_file):
                assert os.path.exists(model_file)
                os.chmod(model_file, 0o664)
        if i == 0:
            result_config = copy.deepcopy(config)
            all_panel_patterns = [config[f"DATA.{panel}.pattern"] for panel in config["DATA.panels"]]
        else:
            for panel in config["DATA.panels"]:
                panel_pattern = config[f"DATA.{panel}.pattern"]
                if panel_pattern not in all_panel_patterns:
                    print(f"{panel_pattern} not in all_panel_patterns")
                    all_panel_patterns.append(panel_pattern)
                    if panel in result_config["DATA.panels"]:  # pattern不在里面但panel名称跟已有的重了
                        panel = f"{panel}_{i}"
                        print(f"rename to {panel}_{i}")
                    result_config["DATA.panels"].append(panel)
                    result_config[f"DATA.{panel}.pattern"] = panel_pattern
            result_config["CA.terms"].update(config["CA.terms"])

    for en in ensemble_weights.keys():
        en_term = ca.C(0)
        for term, weight in ensemble_weights[en].items():
            en_term += ca.C(weight) * result_config["CA.terms"][term]
        result_config["CA.terms"][en] = en_term

    # ========= 改terms路径
    for panel in result_config['DATA.panels']:
        del result_config[f'DATA.{panel}.pattern']
        del result_config[f'DATA.{panel}.inclusive']
    replace_patterns = online2024final.terms.test_release_1220 if horizon=='24h' else online2024final.terms.test_release_1220_1m
    result_config['DATA.panels'] = []
    for i, pattern in enumerate(replace_patterns):
        panel_name = f"panel_{i}"
        result_config['DATA.panels'] += [panel_name]
        result_config[f'DATA.{panel_name}.pattern'] = pattern
    # ========= 改terms路径

    outdir = os.path.join(WORKDIR, f"alpha_{horizon}")
    os.makedirs(outdir, exist_ok=True)
    result_config["OUTPUT.dir"] = outdir

    CAjson_path = os.path.join(outdir, f"alpha_{horizon}.json")
    json.dump(result_config, open(CAjson_path, "w"), indent=2, default=str)
    ensemble_weights_path = os.path.join(outdir, f"ensemble_weights_{horizon}.json")
    json.dump(ensemble_weights, open(ensemble_weights_path, "w"), indent=2, default=str)
    return CAjson_path

def run_CAjson(CAjson_path, slurm=True):
    outdir = os.path.dirname(CAjson_path)
    dates = [d for d in find_dates_from_pattern(online2024final.terms.W) if d >=DEFAULT_CONFIG["fit_vd_start"] and d <= DEFAULT_CONFIG["os_end"]]
    lines = [f"/data/nasData/apps/autobld/equity/canopus {CAjson_path} {date}" for date in dates]
    file_path = os.path.join(outdir, "commands.txt")
    write_non_empty_lines(file_path, lines)
    cmd = f"cat {file_path} | run-parallel -j 120 -w {os.path.join(outdir, 'logs')} -k"
    if slurm:
        cmd += " --slurm --slurmQueue fqueue --ompThreads 1 --timeout 10:00:00 --retries 1 --memPerCpu 10000"
    print(cmd)
    subprocess.run(cmd, shell=True, text=True)

def separate_2step_infer_config():
    # 以下主要是将上述1h的CAjson拆成两部，第一步config是对nn所用的feature在2458上做截面zscore，第二步是只在300上infer提高推理速度
    # 而24h的features已经做了zscore，所以只用做第二步简化
    horizon = "1h"
    config = read_json(os.path.join(WORKDIR, f"alpha_{horizon}/alpha_{horizon}.json"))
    ensemble_weights = read_json(os.path.join(WORKDIR, f"alpha_{horizon}/ensemble_weights_{horizon}.json"))

    config_zs = copy.deepcopy(config)
    config_infer = copy.deepcopy(config)

    alpha_expr_dict = {}
    terms_dict = None
    for alpha_name in ['FGTE_2g', 'Newlrstep']:
        alpha_expr = config["CA.terms"][alpha_name]
        operator, model_file, term_list_str = alpha_expr.split(",")
        term_list_str = term_list_str.removesuffix(")")
        term_list = term_list_str.split(";")
        if terms_dict is None:
            terms_dict = {term.removeprefix("Na20(XsZScore(").removesuffix("))")+'.zs': term.removeprefix("Na20(").removesuffix(")") for term in term_list}  # {term.zs: zs(term)}
        term_list_str = ";".join([f"Na20({term})" for term in terms_dict.keys()])
        alpha_expr = ','.join([operator, model_file, term_list_str])+')'
        alpha_expr_dict[alpha_name] = alpha_expr
    terms_dict |= {term.removeprefix("Na20(XsZScore(").removesuffix("))"): term.removeprefix("Na20(XsZScore(").removesuffix("))") for term in term_list}  # {term: term} 原值也要保存
    alpha_expr_dict['tree'] = config["CA.terms"]['tree']
    for en in ensemble_weights.keys():
        en_term = ca.C(0)
        for term, weight in ensemble_weights[en].items():
            en_term += ca.C(weight) * alpha_expr_dict[term]
        alpha_expr_dict[en] = str(en_term)

    config_zs["CA.terms"] = terms_dict
    combined_terms_outdir = os.path.join(config_zs['OUTPUT.dir'], "test")
    config_zs['OUTPUT.dir'] = combined_terms_outdir
    json.dump(config_zs, open(os.path.join(WORKDIR, f"alpha_{horizon}/config_zs.json"), "w"), indent=2, default=str)

    config_infer["CA.terms"] = alpha_expr_dict
    config_infer['CA.univ'] = "/data/bees3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/D/bod/index/index-YYYYMMDD.sdiv:csi300"
    config_infer['OUTPUT.dir'] = os.path.join(combined_terms_outdir, "yhat")
    panel_name = "combined_panel"
    config_infer['DATA.panels'] = [panel_name]
    config_infer[f"DATA.{panel_name}.pattern"] = os.path.join(combined_terms_outdir, "terms.YYYYMMDD.sdiv")
    json.dump(config_infer, open(os.path.join(WORKDIR, f"alpha_{horizon}/config_infer.json"), "w"), indent=2, default=str)


    horizon = "24h"
    config = read_json(os.path.join(WORKDIR, f"alpha_{horizon}/alpha_{horizon}.json"))
    config['CA.univ'] = "/data/bees3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/D/bod/index/index-YYYYMMDD.sdiv:csi300"
    json.dump(config, open(os.path.join(WORKDIR, f"alpha_{horizon}/config_infer.json"), "w"), indent=2, default=str)