from __future__ import annotations
from online2024final.qrfitter3_node import *
from online2024final.dump_shm import *
from online2024final.utils import canopus_inference_allinone_helper
from online2024final.global_config import DEFAULT_CONFIG, FITDIR
import argparse
import functools
import pickle

def error_handler(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        error = None
        try:
            return func(*args, **kwargs)
        except Exception as e:
            print(f"Error occurred: {e}")
            error = e
        finally:
            clear_shm()  # !!此举会清除当前机器上shm里的所有东西，适合在单机只有当前一个fitting任务时用，如slurm
        if error is not None:
            raise Exception(error)
    return wrapper


def main(
    fitting_name, X_pattern: Dict[str, dict|List[dict]],
    Y_pattern:dict={"Y": DEFAULT_CONFIG["Y_pattern"]}, fit_y="mret24h", 
    W_pattern:dict={"W": DEFAULT_CONFIG["W_pattern"]}, fit_w="is.active",
    model="lgbnew", univ=DEFAULT_CONFIG["univ"], sampling_w=None, rolling:dict=None, load_para_spec=80, dump_config_only_list=[],
    extra_tasks_config:dict=None, grid_tasks_config:dict=None, fit_para_spec=1,
    rnode_root=FITDIR,
    canopus_inference=True, canopus_inference_periods=["valid", "test"],
    for_fs=False, task_i:int=0  # task_i是为了在当前job中执行get_extra_tasks中的第i部分
):
    data = copy.deepcopy(X_pattern)
    data.update(Y_pattern | W_pattern)
    assert len(X_pattern) == 1, "tree can only have one X file."
    Xname, Yname, Wname = list(X_pattern.keys())[0], list(Y_pattern.keys())[0], list(W_pattern.keys())[0]
    is_end = DEFAULT_CONFIG["os_end"] if isinstance(rolling, dict) and rolling.get("roll_type", None)=="vanilla" else DEFAULT_CONFIG["is_end"]
    output_ii = list(range(1,49,3)) if for_fs else DEFAULT_CONFIG["is_output_ii"]
    # configs = [{  # for testing
    #     "univ": univ, "start_date": "20221201", "end_date": "20230110",
    # }]
    configs = [{
        "univ": univ, "start_date": DEFAULT_CONFIG["is_start"], "end_date": is_end, "output_ii": output_ii,
        "exclude_start_date": DEFAULT_CONFIG["exclude_start_date"], "exclude_end_date": DEFAULT_CONFIG["exclude_end_date"], 
    }]
    if canopus_inference:
        start_ends = prepare_shm(data=data, configs=configs, d_concat=True, dump_config_only_list=dump_config_only_list, para_spec=load_para_spec, rnode_root=rnode_root, chain_name=fitting_name)
        train_start_end = start_ends[0]
    else:
        configs.append({
            "univ": univ, "start_date": DEFAULT_CONFIG["os_start"], "end_date": DEFAULT_CONFIG["os_end"], "output_ii": DEFAULT_CONFIG["os_output_ii"],
        })
        start_ends = prepare_shm(data=data, configs=configs, d_concat=True, dump_config_only_list=dump_config_only_list, para_spec=load_para_spec, rnode_root=rnode_root, chain_name=fitting_name)
        train_start_end, test_start_end = start_ends
        inference_dataset_config = QRFitter3Node.base_concat_dataset_config(start_end=test_start_end, Xname=Xname, Yname=Yname, Wname=Wname)
        inference_dataset_config["fit_w"] = fit_w
        inference_dataset_config["fit_y"] = fit_y                                   
    dataset_config = QRFitter3Node.base_concat_dataset_config(start_end=train_start_end, Xname=Xname, Yname=Yname, Wname=Wname)
    fitter_config = QRFitter3Node.base_fitter_config(model=model)  # lgbnew DF, lgb for all fs due to low memory usage
    task_config = {
        "train": {"start_date": str(DEFAULT_CONFIG["is_start"]), "end_date": str(DEFAULT_CONFIG["fit_vd_start"]-1)},
        "valid": {"start_date": str(DEFAULT_CONFIG["fit_vd_start"]), "end_date": str(DEFAULT_CONFIG["is_end"])},
        "test": {"start_date": str(DEFAULT_CONFIG["os_start"]), "end_date": str(DEFAULT_CONFIG["os_end"])},
    }
    dataset_config["fit_w"] = fit_w
    dataset_config["fit_y"] = fit_y
    if sampling_w is not None:
        dataset_config["sampling_w"] = sampling_w

    if fitter_config["class"] == "lgbRegressor":
        lr_map = {"mret1h": 0.02, "mret24h": 0.01, "bret24h": 0.015, "bpret24h": 0.002, "mret5e": 0.002}
        lr = lr_map.get(fit_y, 0.01)
        if for_fs:
            lr *= 2
        fitter_config["para_dict"]['learning_rate'] = lr

    qf_config = {
        "canopus_inference": canopus_inference,
        "fitting_name": fitting_name,
        "dataset": dataset_config,
        "fitter": fitter_config,
        "task": task_config,
    }
    if extra_tasks_config is not None:
        qf_config["extra_tasks"] = extra_tasks_config
    if grid_tasks_config is not None:
        qf_config["grid_tasks"] = grid_tasks_config

    if canopus_inference:
        if "extra_tasks" in qf_config:
            for task in qf_config["extra_tasks"]:
                if "inference_dataset" in task:
                    del task["inference_dataset"]
    else:
        qf_config["inference_dataset"] = inference_dataset_config
    if rolling is not None:
        roller_confg = QRFitter3Node.base_roller_config(**rolling)
        qf_config["roller"] = roller_confg  # 如果指定了roller，就算task存在也会优先用roller，主要是因为croll inference要用task中的test period
    qf3 = QRFitter3Node(qf_config, label="expt_folder", clean_dir_name=True, rnode_root=rnode_root, chain_name=fitting_name)
    pkl_path = os.path.join(qf3.stage_dir(), "X_pattern.pkl")
    with open(pkl_path, "wb") as f:
        pickle.dump(X_pattern, f)
    os.chmod(pkl_path, 0o700)
    qf3.gen_tasks()
    qf3.run(para_spec="1")
    prepare_shm(data=data, clear_data=True, d_concat=True)

    if canopus_inference:
        canopus_inference_allinone_helper(expt_folder=str(qf3.stage_dir()), inference_periods=canopus_inference_periods, univ=univ, slurm_cfg={"smem": 10000, "retries": 2, "timeout": "01:00:00"})

if __name__ == "__main__":
    print("__main__")
    default_param_names = [
        "fit_y", "fit_w", "model", "univ", "sampling_w",
        "load_para_spec", "fit_para_spec", "rnode_root", "canopus_inference", "for_fs", "task_i"
    ]
    parser = argparse.ArgumentParser()
    parser.add_argument('--fitting_name', type=str, required=True)
    parser.add_argument('--X_pattern', type=str, required=True, help="pkl file path of X_pattern")
    parser.add_argument('--Y_pattern', type=str, default=None, help="pkl file path of Y_pattern")
    parser.add_argument('--W_pattern', type=str, default=None, help="pkl file path of W_pattern")
    parser.add_argument('--rolling', type=str, default=None, help="json file path of rolling")
    parser.add_argument('--extra_tasks_config', type=str, default=None, help="json file path of extra_tasks_config")
    parser.add_argument('--grid_tasks_config', type=str, default=None, help="json file path of grid_tasks_config")
    parser.add_argument("--dump_config_only_list", nargs="+", type=str, default=[])
    parser.add_argument("--canopus_inference_periods", nargs="+", type=str, default=["valid", "test"])
    signature = inspect.signature(main)
    for param_name, param in signature.parameters.items():
        if param_name in default_param_names and param.default is not inspect.Parameter.empty:  # Check for default values
            parser.add_argument(
                f"--{param_name}",
                type=type(param.default),
                default=param.default,
                help=f"Default: {param.default}"
            )
    
    args = parser.parse_args()
    with open(args.X_pattern, 'rb') as f:
        args.X_pattern = pickle.load(f)
    if args.Y_pattern is None:
        args.Y_pattern = {"Y": DEFAULT_CONFIG["Y_pattern"]}
    else:
        with open(args.Y_pattern, 'rb') as f:
            args.Y_pattern = pickle.load(f)
    if args.W_pattern is None:
        args.W_pattern = {"W": DEFAULT_CONFIG["W_pattern"]}
    else:
        with open(args.W_pattern, 'rb') as f:
            args.W_pattern = pickle.load(f)
    if args.rolling is not None:
        args.rolling = read_json(args.rolling)
    if args.extra_tasks_config is not None:
        args.extra_tasks_config = read_json(args.extra_tasks_config)
    if args.grid_tasks_config is not None:
        args.grid_tasks_config = read_json(args.grid_tasks_config)
    args_dict = vars(args)
    print(args_dict)
    error_handler(main)(**args_dict)

