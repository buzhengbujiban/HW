from qrfitter3.nnfitter.learner import *
from tqdm import tqdm
import math


class MyLearner(MLPLearner):
    def _data_processing_step(self, config, X, y, w):
        if "y_noise_std" in config:
            std = config["y_noise_std"]
            if std > 0:
                noise = torch.randn_like(y) * std
                y += noise
        if "x_noise_std_min" in config and "x_noise_std_max" in config:
            input_size = X.shape[1]
            std = torch.tensor(np.linspace(config["x_noise_std_min"], config["x_noise_std_max"], input_size), dtype=X.dtype, device=X.device).unsqueeze(0)
            noise = torch.randn_like(X) * std
            X += noise
            if config.get("adjust_std", False):
                X /= (1+std**2)**0.5
        elif "x_noise_std" in config:
            std = config["x_noise_std"]
            if std > 0:
                noise = torch.randn_like(X) * std
                X += noise
                if config.get("adjust_std", False):
                    X /= (1+std**2)**0.5
        if "reverse_probability" in config:
            p_reverse = config["reverse_probability"]
            if p_reverse > 0:
                batch_size = X.shape[0]
                arr = np.random.choice([1, -1], size=batch_size, p=[1-p_reverse, p_reverse])
                if "random_probability" in config:
                    p_random = config["random_probability"]
                    if p_random > 0:
                        indices_to_replace = np.where(arr == -1)[0]
                        num_to_replace = int(p_random * len(indices_to_replace))
                        replace_indices = np.random.choice(indices_to_replace, size=num_to_replace, replace=False)
                        arr[replace_indices] = np.random.uniform(-1, 1, size=num_to_replace)
                multiplier = torch.tensor(arr, dtype=X.dtype, device=X.device)
                X *= multiplier.unsqueeze(1)
                y *= multiplier
        if "barra_random" in config:
            mode = config["barra_random"]["mode"]
            std = config["barra_random"]["noise_std"]
            include_res = config["barra_random"]["include_res"]
            if hasattr(self, "barra_random_cache"):
                n_components = self.barra_random_cache["n_components"]
                component_list = self.barra_random_cache["component_list"]
                res_i = self.barra_random_cache["res_i"]
            else:
                self.barra_random_cache = {}
                components = np.unique([f.split("__")[1] for f in self.feature_names])
                n_components = len(components)
                self.barra_random_cache["n_components"] = n_components
                component_list = []
                for i in range(n_components):
                    name_set = set([f.split("__")[1] for f in self.feature_names[i::n_components]])
                    assert len(name_set) == 1, f"{name_set=}, {i=}"
                    component_name = list(name_set)[0]
                    component_list.append(component_name)
                    if component_name == "res":
                        self.barra_random_cache["res_i"] = i
                        res_i = i
                self.barra_random_cache["component_list"] = component_list
        if "mixup" in config:
            alpha = config["mixup"]["alpha"]
            sample_wise = config["mixup"].get("sample_wise", False)
            append = config["mixup"].get("append", False)
            valid_only = config["mixup"].get("valid_only", False)
            if valid_only:
                X, y, w = X[w>0], y[w>0], w[w>0]
            batch_size = X.size(0)
            device = X.device
            dtype = X.dtype
            index = torch.randperm(batch_size).to(device)
            if sample_wise:
                lambda_val = np.random.beta(alpha, alpha, size=batch_size)
                lambda_val_x = torch.from_numpy(np.expand_dims(lambda_val, axis=tuple(range(1, len(X.size()))))).to(dtype).to(device)
                lambda_val_yw = torch.from_numpy(np.expand_dims(lambda_val, axis=tuple(range(1, len(y.size()))))).to(dtype).to(device)
                mixed_X = lambda_val_x * X + (1 - lambda_val_x) * X[index, :]
                mixed_y = lambda_val_yw * y + (1 - lambda_val_yw) * y[index]
                mixed_w = lambda_val_yw * w + (1 - lambda_val_yw) * w[index]
            else:
                lambda_val = np.random.beta(alpha, alpha, size=1)
                lambda_val = torch.from_numpy(lambda_val).to(dtype).to(device)
                mixed_X = lambda_val * X + (1 - lambda_val) * X[index, :]
                mixed_y = lambda_val * y + (1 - lambda_val) * y[index]
                mixed_w = lambda_val * w + (1 - lambda_val) * w[index]
            if append:
                X = torch.concat([X, mixed_X], dim=0)
                y = torch.concat([y, mixed_y], dim=0)
                w = torch.concat([w, mixed_w], dim=0)
            else:
                X, y, w = mixed_X, mixed_y, mixed_w
        return X, y, w


class AELearner(MLPLearner):
    def __init__(self, config):
        super().__init__(config)
        self.dataset_var = {}
    
    def _init_w_field(self):
        if "w_field" in self.config:
            w_field = self.config["w_field"]
            self.w_field = torch.Tensor([w_field[f] for f in self.feature_names]).to(self.device)  # 确保w_field tensor中的数字是按照feature_names排序的
        else:
            self.w_field = None
        self.logger.info(f"self.w_field: {self.w_field}")

    def calculate_dataset_var(self, dataset: TorchDataset, set_name: str):
        self.logger.info(f"Calculating var for {set_name} set.")
        dataloader = DataLoader(
            dataset=dataset, batch_size=self.batch_size, shuffle=False,
            num_workers=self.dataloader_workers, collate_fn=my_collate_fn
        )
        weighted_sum = 0
        weighted_square_sum = 0
        weight_sum = 0

        for minibatch in dataloader:
            X, y, w, attr, all_y = minibatch
            w = w.unsqueeze(dim=1)  # (B, 1)
            weighted_sum += torch.sum(w * X, dim=0)  # (F,)
            weighted_square_sum += torch.sum(w * (X ** 2), dim=0)  # (F,)
            weight_sum += torch.sum(w)

        weighted_mean = weighted_sum / weight_sum  # (F,)
        weighted_var = (weighted_square_sum / weight_sum) - (weighted_mean ** 2)  # (F,)
        if hasattr(self, "w_field") and self.w_field is not None:
            var = ((self.w_field.cpu() * weighted_var).sum() / self.w_field.cpu().sum()).item()
        else:
            var = torch.mean(weighted_var).item()  # mean over features
        self.dataset_var[set_name] = var
        self.logger.info(f"var={var:.2f}")

    def _train_step(self, minibatch, step):
        """Return train loss after finishing one step train"""
        X, y, w = minibatch[0], minibatch[1], minibatch[2]
        t0 = time.time()
        X, y, w = X.to(self.device), y.to(self.device), w.to(self.device)
        t1 = time.time()
        if "data_processing_config" in self.config:
            X_, y_, w_ = self.data_processing_step(self.config["data_processing_config"], X, y, w)
            pred = self.model(X_)
        else:
            pred = self.model(X)
        # print(f"X.shape: {X.shape}, pred.shape: {pred.shape}, w.shape: {w.shape},")
        loss = self.loss_fn(pred, X, w, self.w_field)  # (B, F), (B, F), (B,), (F) or None
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        t2 = time.time()
        loss = loss.cpu().item()
        self.recorder.LogStep("train/loss", loss)
        self.recorder.LogStep("train/R-squared", 1 - loss/self.dataset_var['train'])
        todevice, forwardbackward = t1-t0, t2-t1
        return todevice, forwardbackward
    
    def _valid_step(self, dataset: TorchDataset, set_name: str, context: Union[dict,None] = None):
        self.model.eval()
        dataloader = DataLoader(
            dataset=dataset, batch_size=self.batch_size, shuffle=False,
            num_workers=self.dataloader_workers, collate_fn=my_collate_fn
        )
        batch_loss_list = []
        with torch.no_grad():  # don't need to calculate gradients in evaluation
            for step, minibatch in enumerate(dataloader):
                X, y, w, attr, all_y = minibatch
                X, y, w = X.to(self.device), y.to(self.device), w.to(self.device)
                pred = self.model(X)
                loss = self.loss_fn(pred, X, w)
                batch_loss_list.append(loss.cpu().item())
        loss = np.mean(batch_loss_list)
        r2 = 1 - loss/self.dataset_var[set_name]
        prefix = '' if set_name is None else f"{set_name}/"
        self.recorder.LogEpoch(prefix+'loss', round(loss, 5))
        self.recorder.LogEpoch(prefix+'R-squared', round(r2, 5))

    def predict(self, dataset: TorchDataset, set_name: str) -> pd.DataFrame:
        "predict encoded & residual"
        self.model.eval()  # enter eval mode, e.g. batchnorm should stop learning parameter and dropout layers should stop dropping neurons
        encoded_save_folder = os.path.join(self.output_dir, f"encoded_{set_name}")
        residual_save_folder = os.path.join(self.output_dir, f"residual_{set_name}")
        os.makedirs(encoded_save_folder, exist_ok=True)
        os.makedirs(residual_save_folder, exist_ok=True)
        dataset.getitem_mode = "daily"
        for date_idx, date in tqdm(enumerate(dataset.Ds)):
            day_X, day_y, day_w, day_attr, day_all_y = dataset[date_idx]
            num_batch = math.ceil(day_X.shape[0] / self.batch_size)
            encoded_list = []
            attr_list = []
            if self.config.get("inference_residual", False):
                residual_list = []
            with torch.no_grad():
                for i in range(num_batch):
                    s, e = i * self.batch_size, (i+1) * self.batch_size
                    X, attr = torch.from_numpy(day_X[s:e, :]), day_attr[s:e, :]
                    X = X.to(self.device)
                    encoded = self.model.encode(X)
                    encoded_list.append(encoded.cpu())
                    attr_list.append(attr)
                    if self.config.get("inference_residual", False):
                        decode_X = self.model.decode(encoded)
                        residual = X - decode_X
                        residual_list.append(residual.cpu())
            attr = np.vstack(attr_list)
            attr_df = pd.DataFrame(attr, columns=dataset.attr_names)
            encoded = torch.vstack(encoded_list).numpy()
            encoded_df = pd.DataFrame(encoded, columns=[f"encoded_{i}" for i in range(encoded.shape[1])])
            encoded_df = pd.concat([attr_df, encoded_df], axis=1)
            warnings.filterwarnings("ignore", category=FutureWarning)  # panel.py:290, future_stack=True
            xarr = panel.df2sdiv(encoded_df)
            panel.write(os.path.join(encoded_save_folder, f"terms.{date}.sdiv"), xarr)
            if self.config.get("inference_residual", False):
                residual = torch.vstack(residual_list).numpy()
                residual_df = pd.DataFrame(residual, columns=[f"resi_{i}" for i in range(len(dataset.x_names))])  # [v1] V dimension is too long: 62081
                residual_df = pd.concat([attr_df, residual_df], axis=1)
                xarr = panel.df2sdiv(residual_df)
                panel.write(os.path.join(residual_save_folder, f"terms.{date}.sdiv"), xarr)
        if self.device == "cuda":
            torch.cuda.empty_cache()
        dataset.getitem_mode = "sample"

    def save_yhat(self, dataset: TorchDataset, set_name: str, save=True):
        self.logger.info(f"Predicting {set_name} set.")
        self._valid_step(dataset, set_name)
        self.logger.info(f"{set_name} set: {self.recorder.ToString()}")
        self.recorder.Clear()
        if save:
            self.predict(dataset, set_name)
    
    def save_model(self, dataset:TorchDataset, name='model'):
        self.logger.info(f"Saving model.")
        self.model.eval().cpu()
        try:
            torch.save(self.model, self.model_path(name=name))
        except Exception as e:
            print(e)
            torch.save(self.model.state_dict(), os.path.join(self.output_dir, "model.pth"))

        feature_names = dataset.x_names.tolist()
        example_input = torch.randn(1, len(feature_names))
        model_onnx_path = self.model_path(name=f"{name}.encoder_decoder", type='onnx')
        model_encoder_onnx_path = self.model_path(name=f"{name}.encoder", type='onnx')
        torch.onnx.export(
            self.model,                # PyTorch 模型
            example_input,        # 示例输入张量
            model_onnx_path,         # 导出的 ONNX 文件名
            export_params=True,   # 导出模型参数
            input_names=['input'],    # 模型输入名称（可选）
            output_names=['output'],  # 模型输出名称（可选）
            dynamic_axes={'input': {0: 'batch_size'},  # 动态轴的定义
                        'output': {0: 'batch_size'}}
        )
        torch.onnx.export(
            self.model.encoder,                # PyTorch 模型
            example_input,        # 示例输入张量
            model_encoder_onnx_path,         # 导出的 ONNX 文件名
            export_params=True,   # 导出模型参数
            input_names=['input'],    # 模型输入名称（可选）
            output_names=['output'],  # 模型输出名称（可选）
            dynamic_axes={'input': {0: 'batch_size'},  # 动态轴的定义
                        'output': {0: 'batch_size'}}
        )
        self.model.to(self.device)

    def run(self, datasets: Dict[str, TorchDataset]):
        self._init_fot_fit()
        self._init_model(datasets['train'])
        self.save_feature_names()
        self._init_w_field()
        for set_name, dataset in datasets.items():
            self.calculate_dataset_var(dataset, set_name)
        self.fit(datasets['train'], datasets['valid'], datasets.get('test', None))
        self.save_model(datasets['train'])
        for set_name, dataset in datasets.items():
            save = set_name == 'test'
            self.save_yhat(dataset, set_name, save)
        self.logger.info(f"The End. expt_name: {self.config['expt_name']}")
    
    def run_inference(self, datasets: Dict[str, TorchDataset]):
        """can be called independently from run()"""
        self._init_for_inference()
        self._init_model(list(datasets.values())[0], load_existing=True)
        for set_name, dataset in datasets.items():
            self.calculate_dataset_var(dataset, set_name)
            self.save_yhat(dataset, set_name)



