from online2024final.global_config import DEFAULT_CONFIG, WORKDIR, DATADIR, FITDIR
import online2024final
from online2024final import mlp, tree
from online2024final.dump_shm import get_overnight_intraday_ret, xszscore


pattern_list = online2024final.terms.test_release_1220_1m[-3: -1]  # 跑通再跑全部panel
nn_fitting_name = "mlp_CAPQ_1m"
Xname = f"X.{nn_fitting_name}"
X_pattern = {Xname: {"pattern": pattern_list, "calc_f": xszscore},}
extra_tasks_config = mlp.get_extra_tasks_networks()
mlp.main(nn_fitting_name, X_pattern, fit_y="mret1h", extra_tasks_config=extra_tasks_config, canopus_inference=True)

tree_fitting_name = "tree_CAPQ_1m"
Xname = f"X.{tree_fitting_name}"
X_pattern = {Xname: {"pattern": pattern_list,},}
tree.main(tree_fitting_name, X_pattern, canopus_inference=True, fit_y='mret1h')