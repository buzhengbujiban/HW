from online2024final.qrfitter3_node import *
from online2024final.utils import get_features_from_extra_tasks, canopus_inference_allinone_helper
from online2024final.global_config import DEFAULT_CONFIG, DATADIR, FITDIR
import online2024final
from online2024final.utils import calc_stats, show_stats
from online2024final.dump_shm import *
import pickle
import math


def get_extra_tasks_genKDteacher(KD_fit_ys=["mret24h", "bret24h"]):
    extra_tasks = []
    node_name = "terms_stats"
    df, ss = show_stats(node_name=node_name, return_dfss=True, stats_dir=DATADIR)
    nbatch = 4
    drop_nbatch = 1  # worst features to drop
    batch_num = 1500
    for fit_y in KD_fit_ys:
        method = "FR" if fit_y == 'mret1h' else "SR"
        label_df = df.xs("w_c1").xs(fit_y)
        ratio = (label_df[("vd", method)] / label_df[("is", method)])
        sorted_features = (label_df[("is", method)].abs() * (ratio.clip(lower=0, upper=1) ** 0.5)).dropna().sort_values(ascending=False).index.tolist() # 用根号ratio来加权is的FR
        for i in range(nbatch - drop_nbatch):
            features = sorted_features[i*batch_num: (i+1)*batch_num]
            extra_tasks.append({
                "dataset": {"use_x_names": features, "group_name": f"batch{i}_{len(features)}", "fit_y": fit_y},
                "inference_dataset": {"use_x_names": features, "group_name": f"batch{i}_{len(features)}", "fit_y": fit_y},
            })
    return extra_tasks

def get_extra_tasks_KD_addnoise(
    fit_ys=["mret24h", "bret24h", "bpret24h", "mret5e"], KD_fit_ys=["mret24h", "bret24h"],
    x_stds=[0, 0.5, 1, 1.5], w_y_w_teacher=[[1,4]]
):
    extra_tasks = []
    node_name = "terms_stats"
    df, ss = show_stats(node_name=node_name, return_dfss=True, stats_dir=DATADIR)
    batch_num = 1500

    for fit_y in fit_ys:
        method = "FR" if fit_y == 'mret1h' else "SR"
        label_df = df.xs("w_c1").xs(fit_y)
        ratio = (label_df[("vd", method)] / label_df[("is", method)])
        sorted_features = (label_df[("is", method)].abs() * (ratio.clip(lower=0, upper=1) ** 0.5)).dropna().sort_values(ascending=False).index.tolist() # 用根号ratio来加权is的FR
        features = sorted_features[:batch_num]
        for x_std in x_stds:
            extra_tasks.append({
                "fitter":{
                    "data_processing_config": {
                        "x_noise_std": x_std,
                    },
                },
                "dataset": {"use_x_names": features, "group_name": f"{batch_num}",  "fit_y": fit_y},
                "inference_dataset": {"use_x_names": features, "group_name": f"{batch_num}", "fit_y": fit_y},
            })
        if fit_y in KD_fit_ys:
            teacher = f"en_{fit_y}"
            for w_field in w_y_w_teacher:
                extra_tasks.append({
                    "fitter":{
                        "randomrestart_config": {
                            "earlystop_config": {"monitor_key": [{f'valid/cor_{fit_y}': {"delta": 0.1, "mode": "max"}}]}
                        },
                        "w_field": w_field,
                        "loss_fn": ["wmse_ml",{}],
                    },
                    "dataset": {"use_x_names": features, "group_name": f"{batch_num}",  "fit_y": [fit_y, teacher]},
                    "inference_dataset": {"use_x_names": features, "group_name": f"{batch_num}", "fit_y": [fit_y, teacher]},
                })
    return extra_tasks

def get_extra_tasks_networks():

    extra_tasks = []
    extra_tasks.append({
        "fitter":{
            "lr_scheduler": ["CustomWarmupLRScheduler", {"after_warmup_strategy": "step", "after_warmup_args": {'step_size': 3, 'gamma': 0.5}}],
            "model_config": {
                "class": "MLP3NEW",
                "module_path": MYMODELS_PATH,
                "kwargs": {
                    "hidden_size": [512, 256, 64, 32, 16],
                    "dropout_rate": 0.3,
                    "norm_type": None,
                    "resnet": True,
                    "self_gating": True,
                    "lastlayer_reg": False,
                }
            },
        },
    })
    extra_tasks.append({
        "fitter":{
            "model_config": {
                "class": "FeatureGroupTransformer",
                "module_path": MYMODELS_PATH,
                "kwargs": {
                    "norm_type": None,
                    "resnet": True,
                    "n_group": 2,
                    "attn_dropout_rate": 0,
                    "attn_norm_type": "LayerNorm",
                }
            }
        },
    })
    return extra_tasks


def main(
    fitting_name, X_pattern: Dict[str, dict|List[dict]],
    Y_pattern:dict={"Y": DEFAULT_CONFIG["Y_pattern"]}, fit_y="mret24h", 
    W_pattern:dict={"W": DEFAULT_CONFIG["W_pattern"]}, fit_w="is.active",
    model="mlp3", univ=DEFAULT_CONFIG["univ"], sampling_w=None, rolling:bool|dict=False, load_para_spec=80, dump_config_only_list=[],
    extra_tasks_config:dict=None, grid_tasks_config:dict=None, fit_para_spec=24,
    rnode_root=FITDIR,
    canopus_inference=True, canopus_inference_periods=["valid", "test"],
):
    data = copy.deepcopy(X_pattern)
    data.update(Y_pattern | W_pattern)
    is_end = DEFAULT_CONFIG["os_end"] if isinstance(rolling, dict) and rolling.get("roll_type", None)=="vanilla" else DEFAULT_CONFIG["is_end"]
    configs = [{
        "univ": univ, "start_date": DEFAULT_CONFIG["is_start"], "end_date": is_end, "output_ii": DEFAULT_CONFIG["is_output_ii"],
        "exclude_start_date": DEFAULT_CONFIG["exclude_start_date"], "exclude_end_date": DEFAULT_CONFIG["exclude_end_date"], 
    }]
    if not canopus_inference:
        configs.append({
            "univ": univ, "start_date": DEFAULT_CONFIG["os_start"], "end_date": DEFAULT_CONFIG["os_end"], "output_ii": DEFAULT_CONFIG["os_output_ii"],
        })
    prepare_shm(data=data, configs=configs, dump_config_only_list=dump_config_only_list, para_spec=load_para_spec, rnode_root=rnode_root, chain_name=fitting_name)
    Xname, Yname, Wname = list(X_pattern.keys()), list(Y_pattern.keys())[0], list(W_pattern.keys())[0]
    dataset_config = QRFitter3Node.base_dataset_config(Xname=Xname, Yname=Yname, Wname=Wname)
    fitter_config = QRFitter3Node.base_fitter_config(model=model, enable_RR=True)  # "mlp3"  "mlp3NEW"  "FTT"
    task_config = {
        "train": {"start_date": str(DEFAULT_CONFIG["is_start"]), "end_date": str(DEFAULT_CONFIG["fit_vd_start"]-1)},
        "valid": {"start_date": str(DEFAULT_CONFIG["fit_vd_start"]), "end_date": str(DEFAULT_CONFIG["is_end"])},
        "test": {"start_date": str(DEFAULT_CONFIG["os_start"]), "end_date": str(DEFAULT_CONFIG["os_end"])},
    }
    dataset_config["fit_w"] = fit_w
    dataset_config["fit_y"] = fit_y
    if sampling_w is not None:
        dataset_config["sampling_w"] = sampling_w
    if fit_y == 'mret1h':
        fitter_config["randomrestart_config"]["earlystop_config"]["delta"] = 0.01

    qf_config = {
        "canopus_inference": canopus_inference,
        "fitting_name": fitting_name,
        "dataset": dataset_config,
        "fitter": fitter_config,
        "task": task_config,
    }
    if extra_tasks_config is not None:
        qf_config["extra_tasks"] = extra_tasks_config
    if grid_tasks_config is not None:
        qf_config["grid_tasks"] = grid_tasks_config

    if canopus_inference:
        if "extra_tasks" in qf_config:
            for task in qf_config["extra_tasks"]:
                if "inference_dataset" in task:
                    del task["inference_dataset"]
    if rolling:
        roller_confg = QRFitter3Node.base_roller_config(**rolling)
        qf_config["roller"] = roller_confg  # 如果指定了roller，就算task存在也会优先用roller，主要是因为croll inference要用task中的test period
    qf3 = QRFitter3Node(qf_config, label="expt_folder", clean_dir_name=True, rnode_root=rnode_root, chain_name=fitting_name)
    pkl_path = os.path.join(qf3.stage_dir(), "X_pattern.pkl")
    with open(pkl_path, "wb") as f:
        pickle.dump(X_pattern, f)
    os.chmod(pkl_path, 0o700)
    qf3.gen_tasks(gpus=[str(i) for i in range(0,8)])  # [str(i) for i in range(4,8)] # final control on gpu devices of fitting
    qf3.run(para_spec=str(fit_para_spec))
    prepare_shm(data=data, clear_data=True)

    if canopus_inference:
        canopus_inference_allinone_helper(expt_folder=str(qf3.stage_dir()), inference_periods=canopus_inference_periods, univ=univ, slurm_cfg={"smem": 12000, "retries": 2, "timeout": "04:00:00"},)