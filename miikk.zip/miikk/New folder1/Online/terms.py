import os
import numpy as np

CAv24Path = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels"
# Y = os.path.join(CAv24Path, "Y/Y_V5/terms.YYYYMMDD.sdiv")
# W = os.path.join(CAv24Path, "I/fq5m/BB/terms.YYYYMMDD.sdiv")
# ST = os.path.join(CAv24Path, "D/eod/sid_st/st_YYYYMMDD.sdiv")

Y = "/data/beef3/data/CA.v24.1220.test_release/CNEQ/Panels/Y/Y_V5/terms.YYYYMMDD.sdiv"
W = "/data/bees3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/I/fq5m/BB/terms.YYYYMMDD.sdiv"
ST = "/data/bees3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/D/eod/sid_st/st_YYYYMMDD.sdiv"


# ===============================for 1h alpha terms
CAPQ_1m = ["/data/beef2/junming/data/CAPQ_1m_241001_5min/terms.YYYYMMDD.sdiv"]  # downsample source code see: /data/nfshome/junming/git/junming/Codes/fit_ca/canopus_scripts/get_data.py


# ===============================for 24h/5e alpha terms
ca1999 = [os.path.join(CAv24Path, "T/CA1999/terms.YYYYMMDD.sdiv")]

bk = [
    os.path.join("/data/beef2/mike/shared/bk23_terms", bk_folder, batch_folder, "selected1.YYYYMMDD.sdiv")
    for bk_folder in ["bk2", "bk3"] for batch_folder in os.listdir(os.path.join("/data/beef2/mike/shared/bk23_terms", bk_folder))
]

pq_ema = [  # pq_ema 筛选时比较膨胀
    "/data/beef3/mike/shared/PQ.v24.1001/pq_ema_tp_None_pas/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_ema_tp_None_add/selected1.YYYYMMDD.sdiv", 
    "/data/beef3/mike/shared/PQ.v24.1001/pq_ema_tp_None_cxl/selected1.YYYYMMDD.sdiv", 
    "/data/beef3/mike/shared/PQ.v24.1001/pq_ema_tp_None_act/selected1.YYYYMMDD.sdiv", 
    "/data/beef3/mike/shared/PQ.v24.1001/pq_ema_tp_tproxy_5m_bboc3_p1_pas/selected1.YYYYMMDD.sdiv", 
    "/data/beef3/mike/shared/PQ.v24.1001/pq_ema_tp_tproxy_5m_bboc3_p1_add/selected1.YYYYMMDD.sdiv", 
    "/data/beef3/mike/shared/PQ.v24.1001/pq_ema_tp_tproxy_5m_bboc3_p1_cxl/selected1.YYYYMMDD.sdiv", 
    "/data/beef3/mike/shared/PQ.v24.1001/pq_ema_tp_tproxy_5m_bboc3_p1_act/selected1.YYYYMMDD.sdiv",
]

pq_flow = [  # pq_flow 方差可能不太一致
    "/data/beef3/mike/shared/PQ.v24.1001/pq_sum_pas_rdcp_pas/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_mean_pas_rdcp_pas/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_sum_add_rdcp_add/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_mean_add_rdcp_add/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_std_add_rdcp_add/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_sum_cxl_rdcp_cxl/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_mean_cxl_rdcp_cxl/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_std_cxl_rdcp_cxl/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_sum_act_rdcp_act/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_mean_act_rdcp_act/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_std_act_rdcp_act/selected1.YYYYMMDD.sdiv",
]

pq_act_old = [  # 关于深市active单的修复前terms，是上面pq_ema和pq_flow的子集
    "/data/beef3/mike/shared/PQ.v24.1001/pq_ema_tp_None_act/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_ema_tp_tproxy_5m_bboc3_p1_act/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_sum_act_rdcp_act/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_mean_act_rdcp_act/selected1.YYYYMMDD.sdiv",
    "/data/beef3/mike/shared/PQ.v24.1001/pq_std_act_rdcp_act/selected1.YYYYMMDD.sdiv",
]

# 关于深市active单的修复后terms，对应把pq_act_old的每个batch拆成了limit跟market
pq_act_fix_folder = "/data/beef3/mike/shared/PQ.v24.1001_fixact"
pq_act_fix_exclude_batch = ["pq_mean_actl", "pq_std_actl", "pq_sum_actl", "pq_mean_actm", "pq_std_actm", "pq_sum_actm"]
pq_act_new = [os.path.join(pq_act_fix_folder, batch, "selected1.YYYYMMDD.sdiv") for batch in os.listdir(pq_act_fix_folder) if batch not in pq_act_fix_exclude_batch]

gp_pv = [
    "/data/beef3/guopeng/release.24.10/gpfea.24.10/gp978_u1/selected1.YYYYMMDD.sdiv",
    "/data/beef3/guopeng/release.24.12/tssel/tssel_batch/terms.YYYYMMDD.sdiv"
]

# 最终所有24h/5e pv terms集合
mlp_all_latest = ca1999 + bk + np.setdiff1d(pq_ema + pq_flow, pq_act_old).tolist() + pq_act_new + gp_pv


# 国鹏的另类数据terms，两个不同来源
guopeng_anns_all = [  # 中信
    "/data/beef3/guopeng/research/daily_fea/events_bret5e/events_pv_sign/000.ca.events_pv_sign/terms.YYYYMMDD.sdiv", 
    "/data/beef3/guopeng/research/daily_fea/events_bret5e/events_mpv_sign/000.ca.events_mpv_sign/terms.YYYYMMDD.sdiv", 
    "/data/beef3/guopeng/research/daily_fea/events_bret5e/events_auc7_sign/000.ca.events_auc7_sign/terms.YYYYMMDD.sdiv", 
    "/data/beef3/guopeng/research/daily_fea/events_bret5e/events_ppq_sign/000.ca.events_ppq_sign/terms.YYYYMMDD.sdiv", 
    "/data/beef3/guopeng/research/daily_fea/events_bret5e/events_ppq_sign_batch1/000.ca.events_ppq_sign_batch1/terms.YYYYMMDD.sdiv", 
    "/data/beef3/guopeng/release.24.12/anns_senti_stats_o1/anns_senti_stats_o1/terms.YYYYMMDD.sdiv",
]

guopeng_tushare_all = [  # tushare
    "/data/beef3/guopeng/research/daily_fea/tushare_alter/block_trade/bt_terms_combine/000.ca.bt_terms_combine/terms.YYYYMMDD.sdiv", 
    "/data/beef3/guopeng/research/daily_fea/tushare_alter/block_trade/bt_terms_p/000.ca.bt_terms_p/terms.YYYYMMDD.sdiv", 
    "/data/beef3/guopeng/research/daily_fea/tushare_alter/block_trade/bt_terms_vr/000.ca.bt_terms_vr/terms.YYYYMMDD.sdiv", 
    "/data/beef3/guopeng/research/daily_fea/tushare_alter/block_trade/bt_terms_xsreg/000.ca.bt_terms_xsreg/terms.YYYYMMDD.sdiv", 
    "/data/beef3/guopeng/research/daily_fea/tushare_alter/block_trade/bt_terms_yyb/000.ca.bt_terms_yyb/terms.YYYYMMDD.sdiv", 
    "/data/beef3/guopeng/research/daily_fea/tushare_alter/report_rc/test_rptstats_long/000.ca.test_rptstats_long/terms.YYYYMMDD.sdiv",
    "/data/beef3/guopeng/research/daily_fea/tushare_alter/margin/test_margin_data/000.ca.test_margin_data/terms.YYYYMMDD.sdiv",
]

test_release_1220 = ["/data/beer1/data/CAPQ.v24.1220.test_release/CNEQ/Panels/T/fq5m/CAPQ_merged/selected1.YYYYMMDD.sdiv"]

test_release_1220_1m = [
    '/data/beer1/data/CAPQ.v24.1220.test_release/CNEQ/Panels/T/fq1m/PQ_add/terms.YYYYMMDD.sdiv',
    '/data/beer1/data/CAPQ.v24.1220.test_release/CNEQ/Panels/T/fq1m/CA_merged/terms.YYYYMMDD.sdiv',
    '/data/beer1/data/CAPQ.v24.1220.test_release/CNEQ/Panels/T/fq1m/PQ_cxl/terms.YYYYMMDD.sdiv',
    '/data/beer1/data/CAPQ.v24.1220.test_release/CNEQ/Panels/T/fq1m/PQ_bk3/terms.YYYYMMDD.sdiv',
    '/data/beer1/data/CAPQ.v24.1220.test_release/CNEQ/Panels/T/fq1m/PQ_bk2/terms.YYYYMMDD.sdiv',
    '/data/beer1/data/CAPQ.v24.1220.test_release/CNEQ/Panels/T/fq1m/PQ_pas/terms.YYYYMMDD.sdiv',
    '/data/beer1/data/CAPQ.v24.1220.test_release/CNEQ/Panels/T/fq1m/PQ_act/terms.YYYYMMDD.sdiv'
]
