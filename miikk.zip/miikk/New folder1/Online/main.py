# qrfitter3 commit ff145130599a46a041005f6d521958ae62ef2f0c
import os
from functools import partial, reduce
from online2024final.utils import get_univ_active, calc_stats, get_features_from_extra_tasks, dump_KDteacher, tree_impSRtopfs_fitting, \
    get_paras, get_ensemble_weights_24h, get_ensemble_weights_1h, dump_combined_model_CAjson, run_CAjson, separate_2step_infer_config
from online2024final.global_config import DEFAULT_CONFIG, WORKDIR, DATADIR, FITDIR
import online2024final
from online2024final import mlp, tree
from online2024final.dump_shm import get_overnight_intraday_ret, xszscore



# get_univ_active(rroot=DATADIR, start_date=DEFAULT_CONFIG["is_start"], end_date=DEFAULT_CONFIG["os_end"])

# calc_stats(
#     node_name="terms_stats", pattern_dict={f"terms_all{i}": pattern for i, pattern in enumerate(online2024final.terms.mlp_all_latest)}, univ="zz1000_midx",
#     start_date=DEFAULT_CONFIG["is_start"], end_date=DEFAULT_CONFIG["os_end"], vd_start=DEFAULT_CONFIG["stats_vd_start"], os_start=DEFAULT_CONFIG["os_start"],
#     labels=["mret1h", "mret24h", "bret24h", "bpret24h", "mret5e"], 
#     rename_col=False, raw_only=True, para_spec=120, # slurm_cfg={"smem": 12000, "retries": 1, "timeout": "20:00:00", "slurmBatch": 3},
#     rnode_root=DATADIR
# )


## =============================== 24h alpha ===============================
### ------------------------------- MLP -------------------------------
# fit_ys = ["mret24h", "bret24h", "bpret24h", "mret5e"]
# KD_fit_ys = ["mret24h", "bret24h"]
# teacher_fitting_name = f"mlp_genKD_batch1500droplast"
# Xname = f"X.{teacher_fitting_name}"
# extra_tasks_config = mlp.get_extra_tasks_genKDteacher(KD_fit_ys=KD_fit_ys)
# all_features = get_features_from_extra_tasks(extra_tasks_config)
# X_pattern = {Xname: {"pattern": online2024final.terms.mlp_all_latest, "columns": all_features},}
# mlp.main(
#     teacher_fitting_name, X_pattern, extra_tasks_config=extra_tasks_config,
#     dump_config_only_list=[], canopus_inference=True, canopus_inference_periods=["train", "valid", "test"]
# )
# dump_KDteacher(expt_folder=os.path.join(FITDIR, teacher_fitting_name), fit_ys=KD_fit_ys)

student_fitting_name = f"mlp_KDstudent_batch1500droplast"
# Xname = f"X.{student_fitting_name}"
# extra_tasks_config = mlp.get_extra_tasks_KD_addnoise(fit_ys=fit_ys, KD_fit_ys=KD_fit_ys)
# all_features = get_features_from_extra_tasks(extra_tasks_config)
# X_pattern = {Xname: {"pattern": online2024final.terms.mlp_all_latest, "columns": all_features},}
# teacher_panel = os.path.join(FITDIR, teacher_fitting_name, "teacher/terms.YYYYMMDD.sdiv")
# Y_pattern = {"Y": {"pattern": online2024final.terms.Y, "columns": [], "calc_f": partial(get_overnight_intraday_ret, teacher_panel=teacher_panel)},}
# mlp.main(student_fitting_name, X_pattern, Y_pattern=Y_pattern, dump_config_only_list=[], extra_tasks_config=extra_tasks_config, canopus_inference=True, fit_para_spec=24)

### ------------------------------- Tree -------------------------------
# imp_fit_ys = ["mret24h", "bret24h"]
# SR_fit_ys = ["bpret24h", "mret5e"]
# for fit_y in imp_fit_ys:
#     fitting_name = f"tree_forfs_{fit_y}"
#     Xname = f"X.{fitting_name}"
#     X_pattern = {Xname: {"pattern": online2024final.terms.mlp_all_latest,}}
#     tree.main(fitting_name, X_pattern, fit_y=fit_y, for_fs=True, canopus_inference=True)
# tree_yhat_patterns = tree_impSRtopfs_fitting(imp_fit_ys=imp_fit_ys, SR_fit_ys=SR_fit_ys, slurm=False)

### ------------------------------- Ensemble / Inference -------------------------------
tree_yhat_patterns = {  # TODO: temp hack so that no need for rerun last line
    "mret24h": os.path.join(FITDIR, 'mret24h_imp1500/canopus_inference_alpha/terms.YYYYMMDD.sdiv'),
    "bret24h": os.path.join(FITDIR, 'bret24h_imp1500/canopus_inference_alpha/terms.YYYYMMDD.sdiv'),
    "bpret24h": os.path.join(FITDIR, 'bpret24h_SR1500/canopus_inference_alpha/terms.YYYYMMDD.sdiv'),
}
pattern_list = []
for fit_y in ["mret24h", "bret24h", "bpret24h"]:
    pattern_list.append({"pattern": tree_yhat_patterns[fit_y], "name": f"Tree_{fit_y}", "columns": {"fit.0.alpha": f"Tree_{fit_y}"}})
expt_folder = os.path.join(FITDIR, student_fitting_name)
paras = get_paras(expt_folder)
mret24h_fit_id = paras.loc[[fit_y[0] == "mret24h" for fit_y in paras['fit_y']]].index[0]
bret24h_fit_id = paras[(paras["fit_y"] == "bret24h") & (paras["x_noise_std"] == 0)].index[0]
bpret24h_fit_id = paras[(paras["fit_y"] == "bpret24h") & (paras["x_noise_std"] == 1)].index[0]
pattern_list.append({
    "pattern": os.path.join(expt_folder, "canopus_inference_alpha/terms.YYYYMMDD.sdiv"), "name": "mlp_mretKD",
    "columns": {f"{mret24h_fit_id}.alpha": "MLP_mret24h", f"{bret24h_fit_id}.alpha": "MLP_bret24h", f"{bpret24h_fit_id}.alpha": "MLP_bpret24h"},
})

ensemble_weights_24h = get_ensemble_weights_24h(pattern_list)
alpha_24h_json = dump_combined_model_CAjson(pattern_list, ensemble_weights_24h, horizon="24h")
# run_CAjson(alpha_24h_json, slurm=True)
## =============================== 24h alpha ===============================



## =============================== 1h alpha ===============================
nn_fitting_name = "mlp_CAPQ_1m"
# Xname = f"X.{nn_fitting_name}"
# X_pattern = {Xname: {"pattern": online2024final.terms.CAPQ_1m, "calc_f": xszscore},}  # xszscore, partial(normalization, pattern_list=pattern)
# extra_tasks_config = mlp.get_extra_tasks_networks()
# mlp.main(nn_fitting_name, X_pattern, fit_y="mret1h", extra_tasks_config=extra_tasks_config, canopus_inference=True)

tree_fitting_name = "tree_CAPQ_1m"
# Xname = f"X.{tree_fitting_name}"
# X_pattern = {Xname: {"pattern": online2024final.terms.CAPQ_1m,},}
# tree.main(tree_fitting_name, X_pattern, canopus_inference=True, fit_y='mret1h')

# expt_folder = os.path.join(FITDIR, nn_fitting_name)
# paras = get_paras(expt_folder)
# Newlrstep_fit_id = paras[(paras["class"] == "MLP3NEW")].index[0]
# FGTE_2g_fit_id = paras[(paras["class"] == "FeatureGroupTransformer")].index[0]
# pattern_list = [
#     {"pattern": os.path.join(FITDIR, nn_fitting_name, 'canopus_inference_alpha/terms.YYYYMMDD.sdiv'), "name": "nn", 
#      "columns": {f"{Newlrstep_fit_id}.alpha": "Newlrstep", f"{FGTE_2g_fit_id}.alpha": "FGTE_2g",}},
#     {"pattern": os.path.join(FITDIR, tree_fitting_name, 'canopus_inference_alpha/terms.YYYYMMDD.sdiv'), "name": "tree", 
#      "columns": {"fit.0.alpha": "tree",}},
# ]
# ensemble_weights_1h = get_ensemble_weights_1h(pattern_list)
# alpha_1h_json = dump_combined_model_CAjson(pattern_list, ensemble_weights_1h, horizon="1h")
# run_CAjson(alpha_1h_json, slurm=True)

## =============================== 1h alpha ===============================

# separate_2step_infer_config()



# ================================================================= for csi300 quick testing
# calc_stats(
#     node_name="terms_stats", pattern_dict={f"terms_all{i}": pattern for i, pattern in enumerate(online2024final.terms.mlp_all_latest)}, univ="topx",
#     start_date=DEFAULT_CONFIG["is_start"], end_date=DEFAULT_CONFIG["os_end"], vd_start=DEFAULT_CONFIG["stats_vd_start"], os_start=DEFAULT_CONFIG["os_start"],
#     labels=["mret1h", "mret24h", "bret24h", "bpret24h", "mret5e"], 
#     rename_col=False, raw_only=True, para_spec=120, slurm_cfg={"smem": 12000, "retries": 1, "timeout": "20:00:00", "slurmBatch": 3},
#     rnode_root=DATADIR
# )

# 完全按照SR挑特征的tree
# imp_fit_ys = []
# SR_fit_ys = ["mret24h", "bret24h", "bpret24h", "mret5e"]
# tree_impSRtopfs_fitting(imp_fit_ys=imp_fit_ys, SR_fit_ys=SR_fit_ys, slurm=True)

# 只有add noise，没有KD的mlp
# fitting_name = f"mlp_SR1500_addG"
# Xname = f"X.{fitting_name}"
# extra_tasks_config = mlp.get_extra_tasks_KD_addnoise(fit_ys=fit_ys, KD_fit_ys=[])
# all_features = get_features_from_extra_tasks(extra_tasks_config)
# X_pattern = {Xname: {"pattern": online2024final.terms.mlp_all_latest, "columns": all_features},}
# mlp.main(fitting_name, X_pattern, dump_config_only_list=[], extra_tasks_config=extra_tasks_config, canopus_inference=True, fit_para_spec=24)


# fit_ys = ["mret24h", "bret24h", "bpret24h", "mret5e"]
# KD_fit_ys = ["mret24h", "bret24h"]
# teacher_fitting_name = f"mlp_genKD_batch1500droplast"
# Xname = f"X.{teacher_fitting_name}"
# extra_tasks_config = mlp.get_extra_tasks_genKDteacher(KD_fit_ys=KD_fit_ys)
# all_features = get_features_from_extra_tasks(extra_tasks_config)
# X_pattern = {Xname: {"pattern": online2024final.terms.mlp_all_latest, "columns": all_features},}
# mlp.main(
#     teacher_fitting_name, X_pattern, extra_tasks_config=extra_tasks_config,
#     dump_config_only_list=[], canopus_inference=True, canopus_inference_periods=["train", "valid", "test"]
# )
# dump_KDteacher(expt_folder=os.path.join(FITDIR, teacher_fitting_name), fit_ys=KD_fit_ys)


# fitting_name = f"mlp_KDstudent_batch1500droplast"
# Xname = f"X.{fitting_name}"
# extra_tasks_config = mlp.get_extra_tasks_KD_addnoise(fit_ys=fit_ys, KD_fit_ys=KD_fit_ys)
# all_features = get_features_from_extra_tasks(extra_tasks_config)
# X_pattern = {Xname: {"pattern": online2024final.terms.mlp_all_latest, "columns": all_features},}
# teacher_panel = os.path.join(FITDIR, teacher_fitting_name, "teacher/terms.YYYYMMDD.sdiv")
# Y_pattern = {"Y": {"pattern": online2024final.terms.Y, "columns": [], "calc_f": partial(get_overnight_intraday_ret, teacher_panel=teacher_panel)},}
# mlp.main(fitting_name, X_pattern, Y_pattern=Y_pattern, dump_config_only_list=[], extra_tasks_config=extra_tasks_config, canopus_inference=True, fit_para_spec=24)