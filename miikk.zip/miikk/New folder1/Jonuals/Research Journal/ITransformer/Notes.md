# ITRANSFORMER: INVERTED TRANSFORMERS ARE EFFECTIVE FOR TIME SERIES FORECASTING（ICLR 2024 Spotlight）
## Motivation & Idea
- 之前常见的将transformer应用于时序预测的做法是：将同时刻的多变量embed到“indistinguishable channels”，然后使用attention来捕捉时序上的依赖。慢慢有研究者发现，像这样紧紧只是捕捉数值上的时序关系“numerical but less semantic”，那么简单的linear layers也能做到甚至更好（Notes：linear layers怎么用的？需要读一下这里引的论文）。
- 作者认为上述这种设计对于multivariate time series forecasting任务来说是不合理的，基于以下几点考虑：
    1. 同时刻上的不同特征基本上有着不同的物理含义（such as 温度湿度风速），简单地将它们embed到一个token里会导致变量间相关性这个信息丢失
    2. 单一time step的token可能很难展示出有用的信息，因为感受野被受限在当前时刻了；并且有些尽管被标注为same timestamp但事实上是time-unaligned的
    3. 时序上的顺序信息很重要，attention是permutation-invariant的，不适合。
- 因此作者提出了**inverted transformer**，也就是跟传统transformer时序预测的做法反过来，先将单个特征的时序embed为一个variate token，然后再应用attention来学习变量间的相关性。

（Notes：总结来说就是linear embedding无法捕捉input间的相关性，attention更适合。attention不适合学应用在时序维度，用linear更能捕捉时序上的全局信息。而我的concern是不同的variate time series共享一样的Embedding、Projection和FFN结构合理吗，不同特征的时序pattern能是一样的？）

## Method Details
![overall framework of ITransformer](./structure.png)
- Layer Norm：作者认为transformer中的LN是应用在同一时刻上的特征维度上，这样会使各特征的信息互相混淆，“leading to oversmooth time series”。在inverted版本里，作者将normalization独立用在每个特征的时序上。
- FFN：作者引用了一些工作support自己用MLP来抽取时序特征的合理性、以及MLP应该be shared within distinct time series。然后“We propose a rational explanation that the neurons of MLP are
taught to portray the intrinsic properties of any time series, such as the amplitude, periodicity, and even frequency spectrums (neuron as a filter), serving as a more advantageous predictive representation learner than the self-attention applied on time points.”，后面用实验证明这个观点。
- Self-attention：由于inverted了，现在的pre-softmax score $q_i^Tk_j$是代表变量间的correlation了，更interpretable。

（Notes：这个LN我觉得确实更加合理。至于MLP for time series，我还要进一步读下他引的文献。如果这个inverted transformer结构work的话，self-attention可能会是一个不错的特征贡献度的衡量方式）

## Experiment Results
- 作者选取了多个时序预测数据集，以及近三年来10个广为人知的nn预测模型作为benchmark，发现itransformer在mse和mae上都基本是最优的。
- 对于一些为了解决平方复杂度的attention变体，作者将variate和time做invert的思想apply上去作为对应的itransformer，发现基本上都比非inverted版本有明显提升
- 在inverted之后，variate的数目变得training-inference可以不一致。作者用20%特征来训练，在全特征下inference，发现效果相差很少。这表明FFN是可以学到transferable time series representation。
- 作者选取了一些时序样本来观察multivariate attention map，发现在网络第一个block的attention map与该样本的lookback correlation更相似、而最后一个block的attention map与该样本的future correlation更相似，由此得出结论是在前馈的过程中网络能逐步encode过去的representation、学习decode出对future prediction有用的信息。
- increase lookback length在inverted后重新变得有用
- 消融实验etc