# A time series is worth 64 words- Long-term forecasting with transformers （ICLR 2023）

Zeng et al.在Are Transformers Effective for Time Series Forecasting? 中question了transformer-based models在多步时序预测的能力，并用简单的线性模型就轻松outperform各路XXFormer。对此，作者提出channel-independence patch time series Transformer（PatchTST）模型，其主要novelty有二：
1. Pathching，也就是将整个时序输入切割成块作为token来enhance locality。这对应着Zeng指出的此前XX Former都将各timestamp单独tokenize，损失了local semantic information。Patching有助于纳入前后信息，类似于扩大感受野。
    
    除此之外，对于长输入序列，patching也有助于降低时间空间复杂度。相比起downsample或者sparse attention这类降低复杂度方法，patching不会损失信息。

2. Channel Independence，也就是将各个variate单独处理，不会像channel-mixing一样对一个包含多特征的feature做embedding来混合信息。对why CI works，作者列出以下几点原因
    - Adaptability：不同variate的serie可以习得不一样的attention patterns，而channel-mixing则是要share同一个时序attention map。作者给出了几组截然不同的特征attention map为佐证。
    - 虽然channel-mixing更flexible，他可以学习cross-channel correlation，但它需要更多的数据才能同时学好跨channel和跨timestamp的信息。作者给出的佐证是他发现CI model比CM model需要更少的数据就能得到更好的样本外loss。而CM model在前几个epcoch就观察到oos loss下降并上升，同时CI model还在稳步下降，说明CM model过拟合得更快。另外，作者认为CI is more robust to noise，因为如果在个别特征序列中噪音很大，那么在CI模型下它只会影响到自己的预测，在CM下则会通过embedding影响到别的特征序列。

    作者还propose用GNN来学习cross- channel relationships。

## Patch TST Structure
![Structure](structure.png)