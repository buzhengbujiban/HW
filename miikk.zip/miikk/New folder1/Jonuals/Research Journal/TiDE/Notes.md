# Long-term Forecasting with TiDE: Time-series Dense Encoder

Zeng et al.在Are Transformers Effective for Time Series Forecasting? 中使用了简单线性模型就outperform了一众transformer-based模型。本文作者认为这样简单的线性模型无法对时序的非线性关系进行建模，另外也并未使用到除了时间序列以外的supporting covariates。因此propose Time-series Dense Encoder (TiDE)这种完全基于MLP的模型架构。作者还证明了该模型的简单线性版本在linear dynamic system中能达到最优误差。

## Covariates
作者简要地介绍了除了多元时间序列本身以外，还有可能会有相关的动态或静态的协变量，这些变量是在做预测前就能知道的。对于动态变量，它们可能是对所有时序都一样的全局变量，比如day of the week；抑或是针对某个时序的，比如某个具体商品随着时间变化的discount rate。对于静态变量，例子有某个商品的静态属性。

这些协变量对于时序预测可能是至关重要的，模型应当需要有能力处理它们。

## Model
![Architecture](architecture.png)

- 模型全部使用MLP来encode历史时间序列以及协变量，然后也使用MLP来decode，其基础的单元是一个基于dense层的残差块。整个模型是channel independencede，沿用了PatchTST的这个设置。也就是说模型的输入和输出都是一个个单独的时间序列，而模型的参数是在所有时序上共享的。

- Dense Encoder的输入有三类，第一个是历史时间序列，第二个是静态协变量，第三个是动态协变量。其中对于动态协变量，作者使用了feature projection来进行降维并拉平。注意这里的动态协变量是可以用到历史+未来的所有时间步的，是预先可知的。这三类输入拼接在一起作为dense encoder的输入，经过多个残差块。

- Dense Decoder将Dense Encoder的输入作为输入，同样经过多个残差块之后得到一个pH维向量，然后reshape成为p*H维的矩阵，其中H是future horizon。

- Temporal Decoder将上述Dense Decoder的输入、以及feature projection的输入concat在一起作为输入，输入每个时间步的预测值。这里相当于给未来的协变量加了一条快速通道，这对于那些重要协变量来说十分重要，比如在零售需求预测中的holiday动态协变量就会十分重要且影响很直接。对于这些具有直接影响的变量，不加highway而是经过多层变换的话未必能学到很好的信息。

- 最后还为历史序列加了一个残差连接，确保Zeng et al.的简单线性模型是本模型的subclass。

## Experiment
只说说几个点：
- 作者沿用了AutoFormer的使用训练集的mean和std做标准化的做法，train：valid：test = 7:1:2
- 使用了minute of the hour，hour of the day etc来作为全局动态协变量，使用了一篇论文中的方法来normalize这些变量，可以学习一下
- 实验都做了5次（应该是调了随机种子）来比较mean，以及计算std来看显著性
- 在look-back=192时TiDE就比PatchTST快了十倍，因为没有用attention机制