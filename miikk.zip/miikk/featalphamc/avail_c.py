#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from jobs.rnodes.rnode import RNode, SlurmCfg
from canopus_py.rnodes.ca_node import CANode
from canopus_py.ca_expr import *
from canopus_py.ca_stats import *

from mc_utils import *

import math

import GV
msg = GV.data()
OUTPUT = GV.fea()
LEN = 240
RPM = 20


#循环结构
'''
def qqe():

    close = msg['close.1min']
    n = 711
    diff_n = 237
    smooth = 474
    factor = 4.236
    diff = 237
    len_LST = 237

    close_diff = close-ca.TsLag(close, diff_n, rpii=RPM)
    up = ca.IfElse(close_diff>ca.C(0), close_diff, ca.C(0))
    dn = ca.IfElse(close_diff<ca.C(0), -close_diff, ca.C(0))

    emaup = ca.Ema(up, span2hl(n), rpii=RPM)
    emadn = ca.Ema(dn, span2hl(n), rpii=RPM)
    rsi_ = ca.C(100)-(ca.C(100)/(ca.C(1)+emaup/emadn))
    rsi_ = ca.IfElse(myequal(emadn, ca.C(1.19209e-07)), ca.C(100), rsi_)

    rsi_ma = ca.Ema(rsi_, span2hl(smooth), rpii=RPM)
    rsi_ma_tr = ca.Abs(rsi_ma-ca.TsLag(rsi_ma, diff, rpii=RPM))

    smoothed_rsi_tr_ma = ca.Ema(rsi_ma_tr, span2hl(2*n-1), rpii=RPM)
    dar = ca.C(factor)* ca.Ema(smoothed_rsi_tr_ma, span2hl(2*n-1), rpii=RPM)

    upperband = rsi_ma + dar
    lowerband = rsi_ma - dar

    long = ca.IfElse()

    L1dx = int(len_LST)-1
    L2dx = int(2*len_LST)-1

    c_rsi = rsi_ma
    p_rsi = ca.TsLag(rsi_ma, L1dx, rpii=RPM)
    c_long = 

    #"E_qqe", "E_qqe_long", "E_qqe_short", "E_qqe_rsi_ma", "E_qqe_dar", "E_qqe_upB", "E_qqe_doB"
'''

def brar():

    open = msg['open.1min']
    high = msg['high.1min']
    low = msg['low.1min']
    close = msg['close.1min']

    n = 948
    diff_n = 237
    k = 240 

    D_open = ca.TsLag(open, k, rpii=RPM)
    D_high = ca.TsMax(high, k, rpii=RPM)
    D_low = ca.TsMin(low, k, rpii=RPM)

    high_open_range = D_high-D_open
    open_low_range = D_open-D_low 
    close_shift = ca.TsLag(close, diff_n, rpii=RPM)

    hcy = D_high-close_shift
    cyl = close_shift-D_low
    hcy = leEps2Na(hcy, hcy)
    hcy = ca.Na20(hcy)
    cyl = leEps2Na(cyl, cyl)
    cyl = ca.Na20(cyl)

    ar = ca.TsSum(high_open_range, n, rpii=RPM)
    ol_sum = ca.TsSum(open_low_range, n, rpii=RPM)
    ar /= ol_sum
    ar = leEps2Na(ar, ol_sum)

    br = ca.TsSum(hcy, n, rpii=RPM)
    cyl_sum = ca.TsSum(cyl, n, rpii=RPM)
    br /= cyl_sum
    ar = leEps2Na(ar, cyl_sum)

    ar = scale_v(ar, 0.5)
    ar = compress_outlier(ar, 10.0)
    br = scale_v(br, 0.5)
    br = compress_outlier(br, 10.0)
    
    OUTPUT[f"F.E_bara_ar"] = ar
    OUTPUT[f"F.E_bara_br"] = br


def coppock(n, fast, slow, name):

    close = msg['close.1min']

    deno = ca.TsLag(close, fast, rpii=RPM) 
    roc0 = (close-deno)/deno*ca.C(100.0)
    roc0 = leEps2Na(roc0, deno)

    deno = ca.TsLag(close, slow, rpii=RPM) 
    roc1 = (close-deno)/deno*ca.C(100.0)
    roc1 = leEps2Na(roc1, deno)

    total_roc = roc0 + roc1
    feature = ca.Ema(total_roc, span2hl(n), rpii=RPM)
    OUTPUT[f"F.E_coppock{name}"] = feature

'''
#循环
#近似
def ebsw(n, bars, diff_c, diff_HP, name):

    close = msg['close.1min']

    alpha1 = (1-math.sin(360/n)) / math.cos(360/n)
    a1 = math.exp(-math.sqrt(2) * math.pi / bars)
    b1 = 2 * a1 * math.cos(math.sqrt(2) * 180 / bars)
    c2 = b1
    c3 = -1 * a1 * a1
    c1 = 1 - c2 - c3
    
    close = ca.Na20(close)
    lastClose = ca.TsLag(close, diff_c, rpii=RPM)
    
    HP = ca.C(0.5*(1 + alpha1))*ca.Ema(close-lastClose, 0.5*(1 + alpha1)/(1 + 2*alpha1), rpii=RPM)
'''

def STCIndicator(n_slow, n_fast, cycle, s1, s2, name):

    close = msg['close.1min']

    c_fast = ca.Ema(close, span2hl(n_fast), rpii=RPM)
    c_slow = ca.Ema(close, span2hl(n_slow), rpii=RPM)
    macd = c_fast-c_slow
    macd_min = ca.TsMin(macd, cycle, rpii=RPM)
    macd_max = ca.TsMax(macd, cycle, rpii=RPM)

    stoch = (macd-macd_min)/(macd_max-macd_min+ca.C(1.19209e-07))
    stoch_ema = ca.Ema(stoch, span2hl(s1), rpii=RPM)
    stoch_ema_min = ca.TsMin(stoch_ema, cycle, rpii=RPM)
    stoch_ema_max = ca.TsMax(stoch_ema, cycle, rpii=RPM)
    stoch2 = (stoch_ema-stoch_ema_min)/(stoch_ema_max-stoch_ema_min+ca.C(1.19209e-07))
    feature = ca.Ema(stoch2, span2hl(s2), rpii=RPM)

    OUTPUT[f"F.E_stc{name}"] = feature

def aobv():

    close = msg['close.1min']
    volume = msg['dollarVolume.1min']
    diff_n = 237
    n_slow = 1185
    n_fast = 711
    n_max = 711
    n_min = 711
    run_length = 711

    volume = ca.TsMean(volume, diff_n, rpii=RPM)
    obv = ca.IfElse(close<ca.TsLag(close, diff_n, rpii=RPM), ca.C(0)-volume, volume)
    obv = ca.IfElse(myequal(close, ca.TsLag(close, diff_n, rpii=RPM)), ca.C(0), obv)

    count = ca.TsSum(ca.C(1), diff_n+1, rpii=RPM) #>self.n
    obv = ca.IfElse(count<=ca.C(diff_n), volume, obv)

    m_mine = ca.TsSum(obv, int(240*RPM), rpii=RPM) #>self.n
    mine_adj = m_mine/volume
    mine_adj = scale_v(mine_adj, 0.5)

    obv_ = mine_adj

    obv_maF = ca.TsMean(obv_, n_fast, rpii=RPM)
    obv_maS = ca.TsMean(obv_, n_slow, rpii=RPM)
    obv_max = ca.TsMax(obv_, n_max, rpii=RPM)
    obv_min = ca.TsMax(obv_, n_min, rpii=RPM)

    obv_maF_d = obv_maF-ca.TsLag(obv_maF, run_length, rpii=RPM)
    obv_maS_d = obv_maS-ca.TsLag(obv_maS, run_length, rpii=RPM)

    increase_fast = obv_maF_d>ca.C(0)
    decrease_fast = obv_maF_d<ca.C(0)
    increase_slow = obv_maS_d>ca.C(0)
    decrease_slow = obv_maS_d<ca.C(0)

    pb = increase_fast & decrease_slow
    bi = increase_fast & increase_slow
    obv_long = ca.IfElse(pb | bi, ca.C(1), ca.C(0))

    pt = decrease_fast & increase_slow
    bd = decrease_fast & decrease_slow
    obv_short = ca.IfElse(pt | bd, ca.C(1), ca.C(0))

    OUTPUT["F.E_obv_maF"] = scale_v(obv_maF, 0.5)
    OUTPUT["F.E_obv_maS"] = scale_v(obv_maS, 0.5)
    OUTPUT["F.E_obv_max"] = scale_v(obv_max, 0.5)
    OUTPUT["F.E_obv_min"] = scale_v(obv_min, 0.5)
    OUTPUT["F.E_obv_long"] = obv_long
    OUTPUT["F.E_obv_short"] = obv_short

'''
#循环
def hwc():
'''

def massi():

    high = msg['high.1min']
    low = msg['low.1min']
    fast = 711
    slow = 1185
    n_D = 237

    high_max = ca.TsMax(high, n_D, rpii=RPM)
    low_min = ca.TsMin(low, n_D, rpii=RPM)

    high_low_range = high_max-low_min
    hl_ema1 = ca.Ema(high_low_range, span2hl(fast), rpii=RPM)
    hl_ema2 = ca.Ema(hl_ema1, span2hl(fast), rpii=RPM)

    feature = hl_ema1/hl_ema2
    OUTPUT["F.E_massiD"] = leEps2Na(feature, hl_ema2)


def zlma():

    close = msg['close.1min']
    length = 711
    lag = int(0.5 * (length - 1))

    nor = ca.TsMean(close, 1185, rpii=RPM)
    close_diff = ca.C(2.0)*close-ca.TsLag(close, lag, rpii=RPM)
    feature = ca.Ema(close_diff, hl2span(length), rpii=RPM)
    feature /= nor

    OUTPUT["F.E_zlma"] = leEps2Na(feature, nor)








