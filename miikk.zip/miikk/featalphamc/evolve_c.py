#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from jobs.rnodes.rnode import RNode, SlurmCfg
from canopus_py.rnodes.ca_node import CANode
from canopus_py.ca_expr import *
from canopus_py.ca_stats import *

from mc_utils import *

import GV
msg = GV.data()
OUTPUT = GV.fea()
LEN = 240
RPM = 20

def Mine26():

    close = msg['close.1min']
    volume = msg['dollarVolume.1min']
    turnover_d = msg['turnover.daily']
    high_d = msg['high.daily']
    low_d = msg['low.daily']
    n = 240

    up = close/ca.TsLag(high_d, n, rpii=RPM)
    down = close/ca.TsLag(low_d, n, rpii=RPM)
    vp = volume/ca.TsLag(turnover_d, n, rpii=RPM)

    up *= vp
    down *= vp

    up = scale_v(up, 0.5) 
    up = compress_outlier(up, 0.5)
    down = scale_v(down, 0.5)
    down = compress_outlier(down, 0.5)

    OUTPUT[f"F.E_Mine26_up"] = up
    OUTPUT[f"F.E_Mine26_down"] = down

#
#def Mine27():


def pdist():

    open = msg['open.1min']
    high = msg['high.1min']
    low = msg['low.1min']
    close = msg['close.1min']
    n = 240
    drift = 480
    offset = 240

    close_ma = ca.Ema(close, span2hl(1185), rpii=RPM)
    high_max = ca.TsMax(high, n, rpii=RPM)
    low_min = ca.TsMin(low, n, rpii=RPM)
    open_d = ca.TsLag(open, n, rpii=RPM)

    pdist = ca.C(2)*(high_max-low_min)
    pdist += ca.Abs(open_d-ca.TsLag(close, drift, rpii=RPM))
    pdist -= ca.Abs(close-open_d)

    pdist /= close_ma 
    pdist = leEps2Na(pdist, close_ma) 

    OUTPUT[f"F.E_pdist1"] = pdist
    OUTPUT[f"F.E_pdist2"] = pdist-ca.TsLag(pdist, offset, rpii=RPM)


def thermo():

    high = msg['high.1min']
    low = msg['low.1min']
    length = 1185
    drift = 237
    offset = 0
    long = 2.0
    short = 0.5

    thermoL = ca.Abs(ca.TsLag(low, drift, rpii=RPM)-low)
    thermoH = ca.Abs(high-ca.TsLag(high, drift, rpii=RPM))

    thermo = mymax(thermoL, thermoH)
    thermo_ma = ca.Ema(thermo, span2hl(length), rpii=RPM)
    thermo_long = ca.IfElse(thermo<thermo_ma*ca.C(long), ca.C(1.), ca.C(0))
    thermo_short = ca.IfElse(thermo>thermo_ma*ca.C(short), ca.C(1.), ca.C(0))

    #OUTPUT[f"F.E_thermo_long"] = thermo_long
    OUTPUT[f"F.E_thermo_short"] = thermo_short


def ui():

    close = msg['close.1min']
    length = 1185
    scalar = 100
    offset = 0

    highest_close = ca.TsMax(close, length, rpii=RPM)
    downside = ca.C(scalar)*(close-highest_close)
    downside /= highest_close
    d2 = downside * downside
    feature = ca.TsMean(d2, length, rpii=RPM)
    feature /= ca.C(length)

    feature = scale_v(feature, 0.5)

    OUTPUT[f"F.E_ui"] = feature


def entropy():

    close = msg['close.1min']
    length = 2370

    sum_close = ca.TsSum(close, length, rpii=RPM)
    p = close/sum_close
    p = leEps2Na(p, sum_close)

    p = -p*ca.Log(p)/ca.Log(ca.C(2.0))

    feature = ca.TsSum(p, length, rpii=RPM)
    feature = scale_v(feature, 0.5)

    OUTPUT[f"F.E_entropy"] = feature


def MinIndicator():

    feature = ca.IIndex()
    OUTPUT[f"F.E_min"] = feature

#    
#def IndusIndicator()

    
