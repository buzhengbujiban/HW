#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from jobs.rnodes.rnode import RNode, SlurmCfg
from canopus_py.rnodes.ca_node import CANode
from canopus_py.ca_expr import *
from canopus_py.ca_stats import *

from mc_utils import *

import GV
msg = GV.data()
OUTPUT = GV.fea()
LEN = 240
RPM = 20

def PivotIndicator():

    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]
    diff_n = 237

    feature = ca.TsLag(close, diff_n, rpii=RPM) + ca.TsLag(high, diff_n, rpii=RPM) + ca.TsLag(low, diff_n, rpii=RPM)
    nor = ca.TsMean(close, 711, rpii=RPM)
    feature /= nor
    OUTPUT["F.M_c_special_pivot"] = leEps2Na(feature, nor) 

def Mine1(n, name):

    buyNotl = msg["buyNotl.1min"]
    buyQty = msg["buyQty.1min"]
    sellNotl = msg["sellNotl.1min"]
    sellQty = msg["sellQty.1min"]

    buyNotl = ca.DayAccum(buyNotl, rpii=1)
    buyQty = ca.DayAccum(buyQty, rpii=1)
    sellNotl = ca.DayAccum(sellNotl, rpii=1)
    sellQty = ca.DayAccum(sellQty, rpii=1)

    r = sellNotl/sellQty-buyNotl/buyQty
    r = leEps2Na(r, sellQty*buyQty) 
    feature = ca.Ema(r, span2hl(n), rpii=RPM)
    OUTPUT[f"F.{name}_N_c_mine1"] = feature


def Mine2(n, name):

    buyNotl = msg["buyNotl.1min"]
    bidSize = msg["bidSize.1min"]
    bidPrice = msg["bidPrice.1min"]

    buyNotl = ca.DayAccum(buyNotl, rpii=1)
    bidSize = ca.DayAccum(bidSize, rpii=1)

    r = bidSize*bidPrice/buyNotl
    r = leEps2Na(r, buyNotl) 
    feature = ca.Ema(r, span2hl(n), rpii=RPM)
    OUTPUT[f"F.{name}_N_c_mine2"] = feature


def Mine3(n, name):

    sellNotl = msg["sellNotl.1min"]
    askSize = msg["askSize.1min"]
    askPrice = msg["askPrice.1min"]

    sellNotl = ca.DayAccum(sellNotl, rpii=1)
    askSize = ca.DayAccum(askSize, rpii=1)

    r = askSize*askPrice/sellNotl
    r = leEps2Na(r, sellNotl) 
    feature = ca.Ema(r, span2hl(n), rpii=RPM)
    OUTPUT[f"F.{name}_N_c_mine3"] = feature

def Mine6(n, name):

    buyNotl = msg["buyNotl.1min"]
    sellNotl = msg["sellNotl.1min"]

    buyNotl = ca.DayAccum(buyNotl, rpii=1)
    sellNotl = ca.DayAccum(sellNotl, rpii=1)

    r = buyNotl/sellNotl-ca.C(1.0)
    r = leEps2Na(r, sellNotl) 
    feature = ca.Ema(r, span2hl(n), rpii=RPM)
    OUTPUT[f"F.{name}_N_c_mine6"] = feature


def Mine7(n, name):

    buyNotl = msg["buyNotl.1min"]
    close = msg["close.1min"]

    buyNotl = ca.DayAccum(buyNotl, rpii=1)

    deno = buyNotl*close
    feature = (buyNotl-ca.TsLag(buyNotl, n, rpii=RPM))*(close-ca.TsLag(close, n, rpii=RPM))/deno

    OUTPUT[f"F.{name}_N_c_mine7"] = leEps2Na(feature, deno) 


def Mine8(n, name):

    buyNotl = msg["buyNotl.1min"]
    close = msg["close.1min"]

    buyNotl = ca.DayAccum(buyNotl, rpii=1)

    buyNotl_d1 = buyNotl-ca.TsLag(buyNotl, n, rpii=RPM)

    deno = buyNotl*close
    feature = (buyNotl_d1-ca.TsLag(buyNotl_d1, n, rpii=RPM))*(close-ca.TsLag(close, n, rpii=RPM))/deno

    OUTPUT[f"F.{name}_N_c_mine8"] = leEps2Na(feature, deno) 


def Mine9(n, name):

    sellNotl = msg["sellNotl.1min"]
    close = msg["close.1min"]

    sellNotl = ca.DayAccum(sellNotl, rpii=1)

    deno = sellNotl*close
    feature = (sellNotl-ca.TsLag(sellNotl, n, rpii=RPM))*(close-ca.TsLag(close, n, rpii=RPM))/deno

    OUTPUT[f"F.{name}_N_c_mine9"] = leEps2Na(feature, deno) 


def Mine10(n, name):

    sellNotl = msg["sellNotl.1min"]
    close = msg["close.1min"]

    sellNotl = ca.DayAccum(sellNotl, rpii=1)

    sellNotl_d1 = sellNotl-ca.TsLag(sellNotl, n, rpii=RPM)

    deno = sellNotl*close
    feature = (sellNotl_d1-ca.TsLag(sellNotl_d1, n, rpii=RPM))*(close-ca.TsLag(close, n, rpii=RPM))/deno

    OUTPUT[f"F.{name}_N_c_mine10"] = leEps2Na(feature, deno) 


def Mine11(n, name):

    buyNotl = msg["buyNotl.1min"]
    sellNotl = msg["sellNotl.1min"]
    close = msg["close.1min"]

    buyNotl = ca.DayAccum(buyNotl, rpii=1)
    sellNotl = ca.DayAccum(sellNotl, rpii=1)
    bsNotl = buyNotl+sellNotl

    deno = bsNotl*close
    feature = (bsNotl-ca.TsLag(bsNotl, n, rpii=RPM))*(close-ca.TsLag(close, n, rpii=RPM))/deno

    OUTPUT[f"F.{name}_N_c_mine11"] = leEps2Na(feature, deno) 

#Mine13-17 Mine20 21 需要新算子

def Mine18(m, n, name):

    buyNotl = msg["buyNotl.1min"]
    sellNotl = msg["sellNotl.1min"]

    rn = buyNotl+sellNotl
    rm = buyNotl-sellNotl

    deno = ca.Ema(rn, span2hl(n), rpii=RPM)
    nume = ca.Ema(rm, span2hl(m), rpii=RPM)
    feature = nume/deno

    OUTPUT[f"F.{name}_N_c_mine18"] = leEps2Na(feature, deno) 


def Mine19(n, name):

    buyNotl = msg["buyNotl.1min"]
    sellNotl = msg["sellNotl.1min"]

    buyNotl = ca.DayAccum(buyNotl, rpii=1)
    sellNotl = ca.DayAccum(sellNotl, rpii=1)

    r = buyNotl-sellNotl

    a = ca.Ema(r, span2hl(n), rpii=RPM)
    b = ca.TsStd(r, n, rpii=RPM)
    feature = a/b

    OUTPUT[f"F.{name}_N_c_mine19"] = leEps2Na(feature, b) 

def Mine22(n, name):

    buyNotl = msg["buyNotl.1min"]
    sellNotl = msg["sellNotl.1min"]

    buyNotl = ca.DayAccum(buyNotl, rpii=1)
    sellNotl = ca.DayAccum(sellNotl, rpii=1)

    r = buyNotl-sellNotl

    nor = ca.Ema(ca.Abs(r), span2hl(n), rpii=RPM)
    feature = r/nor

    OUTPUT[f"F.{name}_N_c_mine22"] = leEps2Na(feature, nor) 


def Mine23(n, name):

    buyNotl = msg["buyNotl.1min"]
    sellNotl = msg["sellNotl.1min"]

    r = buyNotl-sellNotl

    feature = ca.Ema(r, span2hl(n), rpii=RPM)

    nor = ca.TsMean(buyNotl+sellNotl, 1185, rpii=RPM)
    feature = feature/nor

    OUTPUT[f"F.{name}_N_c_mine23"] = leEps2Na(feature, nor) 
