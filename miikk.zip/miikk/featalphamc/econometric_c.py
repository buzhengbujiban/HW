#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from jobs.rnodes.rnode import RNode, SlurmCfg
from canopus_py.rnodes.ca_node import CANode
from canopus_py.ca_expr import *
from canopus_py.ca_stats import *

from mc_utils import *

import GV
msg = GV.data()
OUTPUT = GV.fea()
LEN = 240
RPM = 20


def DailyReturnIndicator():

    close = msg["close.1min"]
    diff_n = 390
    
    deno = ca.TsLag(close, diff_n, rpii=RPM)
    dr = close/deno-ca.C(1.0)
    dr *= ca.C(100.0)

    OUTPUT["F.M_c_stat_r"] = dr


def VWMAIndicator():

    close = msg["close.1min"]
    volume = msg['dollarVolume.1min']
    n = 300
    
    pv = close*volume
    v_ma = ca.TsMean(volume, n, rpii=RPM)
    pv_ma = ca.TsMean(pv, n, rpii=RPM)

    feature = pv_ma/v_ma
    feature = leEps2Na(feature, v_ma)
    nor = ca.TsMean(ca.Abs(feature), n, rpii=RPM)
    feature /= nor
    OUTPUT["F.M_c_stat_vwma"] = leEps2Na(feature, nor)

def VWAPIndicator():

    close = msg["close.1min"]
    high = msg["high.1min"]
    low = msg["low.1min"]
    volume = msg['dollarVolume.1min']
    n = 300

    tp = (close+high+low)/ca.C(3.0)
    tpv = tp*volume

    m_tpv = ca.TsSum(tpv, int(RPM*240), rpii=RPM)
    m_v = ca.TsSum(volume, int(RPM*240), rpii=RPM)
    feature = m_tpv/m_v

    nor = ca.TsMean(ca.Abs(feature), n, rpii=RPM)
    feature /= nor
    OUTPUT["F.M_c_stat_vwap"] = leEps2Na(feature, nor)

def KurtosisIndicator():

    close = msg["close.1min"]
    n = 600

    feature = ca.TsKurt(close, n, rpii=RPM)-ca.C(3.) #canopus没有减去3.
    feature = ca.Sign(feature)*ca.NumPow(ca.Abs(feature), 0.45)
    OUTPUT["F.M_c_stat_kurt"] = feature

def SkewIndicator():

    close = msg["close.1min"]
    n = 600

    feature = ca.TsSkew(close, n, rpii=RPM)
    feature = ca.Sign(feature)*ca.NumPow(ca.Abs(feature), 0.45)
    OUTPUT["F.M_c_stat_skew"] = feature


def ZScorendicator():

    close = msg["close.1min"]
    n = 600

    stdev = ca.TsStd(close, n, rpii=RPM)
    mean = ca.TsMean(close, n, rpii=RPM)
    feature = (close-mean)/stdev
    OUTPUT["F.M_c_stat_zscore"] = leEps2Na(feature, stdev)

#用std近似
def MADIndicator():

    close = msg["close.1min"]
    n = 600

    ma_V = ca.TsMean(close, n, rpii=RPM)
    close_long = ca.TsMean(close, 1185, rpii=RPM)
    feature = ca.TsStd(close-ma_V, n, rpii=RPM)/close_long

    OUTPUT["F.M_c_stat_mad"] = leEps2Na(feature, close_long)


#用std近似
def RealizedAbsVolatIndicator():
    
    close = msg["close.1min"]
    n = 600 
    diff_n = 1
    #dm = true

    close = ca.Log(close)
    dr = close-ca.TsLag(close, diff_n, rpii=RPM)
    dr_mean = ca.TsMean(dr, n, rpii=RPM)
    x = ca.TsStd(dr-dr_mean, n, rpii=RPM)*ca.C(n)
    close_long = ca.TsMean(close, 1185, rpii=RPM)

    feature = x/close_long
    OUTPUT["F.M_c_volat_reaabsvolat"] = leEps2Na(feature, close_long)

    
