#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from jobs.rnodes.rnode import RNode, SlurmCfg
from canopus_py.rnodes.ca_node import CANode
from canopus_py.ca_expr import *
from canopus_py.ca_stats import *

from mc_utils import *

import GV
msg = GV.data()
OUTPUT = GV.fea()
LEN = 240
RPM = 20


def warmup():
    OUTPUT["open"] = ca("open.1min")
    OUTPUT["open.daily"] = ca("open.daily")
    OUTPUT["open.adjusted"] = ca("open.adjusted")
    OUTPUT["adj.factor.locf.adjusted"] = ca("adj.factor.locf.adjusted")

def OHLCV():

    nor_O = ca.TsMean(msg['open.1min'], LEN*2, rpii=RPM)
    nor_H = ca.TsMean(nor_O, LEN*2, rpii=RPM)
    nor_L = ca.TsMean(nor_H, LEN*2, rpii=RPM)
    nor_C = ca.TsMean(nor_L, LEN*2, rpii=RPM)
    nor_V = ca.TsMean(msg['dollarVolume.1min'], LEN*5, rpii=RPM)

    O = msg['open.1min']/nor_O
    H = msg['high.1min']/nor_H
    L = msg['low.1min']/nor_L
    C = msg['close.1min']/nor_C
    V = msg['dollarVolume.1min']/nor_V

    O = leEps2Na(O, nor_O)
    H = leEps2Na(H, nor_H)
    L = leEps2Na(L, nor_L)
    C = leEps2Na(C, nor_C)
    V = leEps2Na(V, nor_V)

    OUTPUT["F.open"] = O
    OUTPUT["F.high"] = H
    OUTPUT["F.low"] = L
    OUTPUT["F.close"] = C
    OUTPUT["F.dollarVolumeTotalUnit"] = V


def RSIIndicator():
    close = msg["close.1min"]
    close_diff = close-ca.TsLag(close, 1, rpii=RPM)
    up = ca.IfElse(close_diff>ca.C(0), close_diff, ca.C(0))
    dn = ca.IfElse(close_diff<ca.C(0), ca.C(0)-close_diff, ca.C(0))

    emaup = ca.Ema(up, span2hl(839), rpii=RPM)
    emadn = ca.Ema(dn, span2hl(839), rpii=RPM)

    feature = ca.C(100)-ca.C(100)/(ca.C(1)+emaup/emadn)
    OUTPUT["F.M_c_mome_rsi"] = leEps2Na(feature, emadn)


def MFIIndicator():

    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]
    volume = msg['dollarVolume.1min']

    tp = (high+low+close)/ca.C(3.0)
    tp_diff = tp-ca.TsLag(tp, 1, rpii=RPM)
    a = ca.IfElse(tp_diff<ca.C(0), ca.C(-1), ca.C(0))
    up_down = ca.IfElse(tp_diff>ca.C(0), ca.C(1), a)

    mf = tp*volume*up_down

    mf_p = ca.IfElse(mf>=ca.C(0), mf, ca.C(0))
    mf_n = ca.IfElse(mf<ca.C(0), mf, ca.C(0))

    n_positive_mf = ca.TsSum(mf_p, 420, rpii=RPM)
    n_negative_mf = ca.TsSum(ca.Abs(mf_n), 420, rpii=RPM)

    demo = n_positive_mf+n_negative_mf
    feature = ca.C(100)*n_positive_mf/demo
    feature = leEps2Na(feature, demo)
    feature = ca.IfElse(feature<ca.C(0), ca.C(0), feature)
    
    OUTPUT["F.M_c_mome_mfi"] = feature

def TSIIndicator():

    close = msg["close.1min"]
    m = close-ca.TsLag(close, 1, rpii=RPM)
    m1 =  ca.Ema(ca.Ema(m, span2hl(750), rpii=RPM), span2hl(390), rpii=RPM)
    m2 =  ca.Ema(ca.Ema(ca.Abs(m), span2hl(750), rpii=RPM), span2hl(390), rpii=RPM)

    feature = ca.C(100)*m1/m2
    OUTPUT["F.M_c_mome_tsi"] = leEps2Na(feature, m2)

def UltimateOscillator():

    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]

    #bp = close-ca.IfElse(low<ca.TsLag(close, 1, rpii=RPM), low, ca.TsLag(close, 1, rpii=RPM))
    bp = close-mymin(low, ca.TsLag(close, 1, rpii=RPM))
    tr = mymax(high, ca.TsLag(close, 1, rpii=RPM)) - mymin(low, ca.TsLag(close, 1, rpii=RPM))
    #tr = ca.IfElse(high>ca.TsLag(close, 1, rpii=RPM), high, ca.TsLag(close, 1, rpii=RPM)) - ca.IfElse(low<ca.TsLag(close, 1, rpii=RPM), low, ca.TsLag(close, 1, rpii=RPM))

    sumtrs = ca.TsSum(tr, 210, rpii=RPM)
    sumtrm = ca.TsSum(tr, 420, rpii=RPM)
    sumtrl = ca.TsSum(tr, 840, rpii=RPM)

    avg_s = ca.TsSum(bp, 210, rpii=RPM)
    avg_m = ca.TsSum(bp, 420, rpii=RPM)
    avg_l = ca.TsSum(bp, 840, rpii=RPM)

    avg_s /= sumtrs
    avg_m /= sumtrm
    avg_l /= sumtrl

    avg_s = leEps2Na(avg_s, sumtrs)
    avg_m = leEps2Na(avg_m, sumtrm)
    avg_l = leEps2Na(avg_l, sumtrl)

    feature = ca.C(100.0)*((ca.C(4)*avg_s)+(ca.C(2)*avg_m)+(ca.C(1)*avg_l))/ca.C(4+2+1)
    OUTPUT["F.M_c_mome_uo"] = feature


def StochasticOscillator():

    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]

    smin = ca.TsMin(low, 420, rpii=RPM)
    smax = ca.TsMax(high, 420, rpii=RPM)
    demo = smax-smin
    stock_k = ca.C(100)*(close-smin)/demo
    stock_k = leEps2Na(stock_k, demo)
    feature = ca.TsMean(stock_k, 90, rpii=RPM)

    OUTPUT["F.M_c_mome_stoch"] = feature


'''
#循环结构计算图没法展开，可能canopus_c++加上全局buff可以, 最好是直接写一个c++算子
def KAMAIndicator():

    n = 300 

    close = msg["close.1min"]
    temp_del0, temp_del1 = myfillna(close, ca.TsLag(close, 1, rpii=RPM))
    close = temp_del0
    close_prev = temp_del1

    count = ca.TsSum(ca.C(1), n+1, rpii=RPM) #>self.n 300
    #m_close_0 = ca.IfElse(count<=ca.C(1.5), close, ca.C(0))

    vol = ca.Abs(close-ca.TsLag(close, 1, rpii=RPM))
    ER_num = close-ca.TsLag(close, n, rpii=RPM)
    ER_den = ca.TsSum(vol, n, rpii=RPM)

    ER = ER_num/ER_den
    ER = leEps2Na(ER, ER_den)

    sc = ER*ca.C(2.0/(60+1)-2.0/(900+1.0))+ca.C(2/(900+1.0))
    sc = sc*sc
    feature_prev = ca.TsSum(feature, 1, rpii=RPM)
    feature = ca.IfElse(count<=ca.C(1.5), close, feature_prev + sc*(close-feature_prev))
    feature = ca.Ema(feature, span2hl(n), rpii=RPM)
    #feature = ca.Sign(feature)*ca.NumPow(ca.Abs(feature), 0.45)
    #feature_prev = ca.TsSum(feature, 1, rpii=RPM)

    OUTPUT["F.M_cA_mome_kama"] = feature
'''

def ROCIndicator():

    close = msg["close.1min"]
    deno = ca.TsLag(close, 360, rpii=RPM)
    feature = ca.C(100.0)*(close-deno)/deno
    OUTPUT["F.M_c_mome_roc"] = leEps2Na(feature, deno)

def AwesomeOscillatorIndicator():
    
    high = msg["high.1min"]
    low = msg["low.1min"]
    mp = ca.C(0.5)*(high+low)

    shortv = ca.TsMean(mp, 150, rpii=RPM)
    longv = ca.TsMean(mp, 1020, rpii=RPM)
    feature = (shortv-longv)/longv 
    OUTPUT["F.M_c_mome_ao"] = leEps2Na(feature, longv)

def WilliamsRIndicator():
    
    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]
    hh = ca.TsMax(high, 420, rpii=RPM)
    ll = ca.TsMin(low, 420, rpii=RPM)
    demo = hh-ll
    feature = ca.C(-100.0)*(hh-close)/demo
    OUTPUT["F.M_c_mome_wr"] = leEps2Na(feature, demo)

def AroonIndicator():
    
    close = msg["close.1min"]
    aroon_up = ca.C(100)*(ca.C(750)-ca.TsMaxT(close, 750, rpii=RPM))/ca.C(750)
    aroon_down = ca.C(100)*(ca.C(750)-ca.TsMinT(close, 750, rpii=RPM))/ca.C(750)
    arron_diff = aroon_up-aroon_down
    OUTPUT["F.M_c_trend_aroon_up"] = aroon_up
    OUTPUT["F.M_c_trend_aroon_down"] = aroon_down
    OUTPUT["F.M_c_trend_aroon_diff"] = arron_diff

def MACD():

    close = msg["close.1min"]
    emafast = ca.Ema(close, span2hl(360), rpii=RPM)
    emaslow = ca.Ema(close, span2hl(780), rpii=RPM)
    macd = (emafast-emaslow)/emaslow
    macd_signal = ca.Ema(macd, span2hl(270), rpii=RPM)
    macd_diff = macd-macd_signal

    OUTPUT["F.M_c_trend_macd"] = macd
    OUTPUT["F.M_c_trend_macd_signal"] = macd_signal
    OUTPUT["F.M_c_trend_macd_diff"] = macd_diff


def EMAIndicator():
    
    close = msg["close.1min"]
    close_ema = ca.Ema(close, span2hl(360), rpii=RPM)
    close_ma = ca.TsMean(close_ema, 1185, rpii=RPM)
    feature = close_ema/close_ma

    OUTPUT["F.M_c_trend_ema_fast"] = leEps2Na(feature, close_ma)

def TRIXIndicator():

    close = msg["close.1min"]
    ema1 = ca.Ema(close, span2hl(450), rpii=RPM)
    ema2 = ca.Ema(ema1, span2hl(450), rpii=RPM)
    ema3 = ca.Ema(ema2, span2hl(450), rpii=RPM)
    deno = ca.TsLag(ema3, 1, rpii=RPM)
    feature = ca.C(100.0)*(ema3/deno-ca.C(1.0))
    OUTPUT["F.M_c_trend_trix"] = leEps2Na(feature, deno)

def MassIndex():
    
    high = msg["high.1min"]
    low = msg["low.1min"]
    amplitude = high-low
    ema1 = ca.Ema(amplitude, span2hl(270), rpii=RPM)
    ema2 = ca.Ema(ema1, span2hl(270), rpii=RPM)
    mass = ema1/ema2
    feature = ca.TsSum(mass, 750, rpii=RPM)
    feature = ca.NumPow(feature, 0.5)
    OUTPUT["F.M_c_trend_mass"] = leEps2Na(feature, ema2)

def IchimokuIndicator():

    high = msg["high.1min"]
    low = msg["low.1min"]
    conv = ca.C(0.5)*(ca.TsMax(high, 270, rpii=RPM)+ca.TsMin(low, 270, rpii=RPM))
    base = ca.C(0.5)*(ca.TsMax(high, 780, rpii=RPM)+ca.TsMin(low, 780, rpii=RPM))

    #visual = False
    spana = ca.C(0.5)*(conv+base)
    spanb = ca.C(0.5)*(ca.TsMax(high, 1560, rpii=RPM)+ca.TsMin(low, 1560, rpii=RPM))

    spana_long = ca.TsMean(spana, 1185, rpii=RPM)
    spanb_long = ca.TsMean(spanb, 1185, rpii=RPM)

    spana /= spana_long
    spanb /= spanb_long

    OUTPUT["F.M_c_trend_ichimoku_a"] = leEps2Na(spana, spana_long)
    OUTPUT["F.M_c_trend_ichimoku_b"] = leEps2Na(spanb, spanb_long)

def KSTIndicator():

    close = msg["close.1min"]

    deno = ca.TsLag(close, 300, rpii=RPM)
    roc1 = close/deno-ca.C(1.0)
    roc1 = leEps2Na(roc1, deno)

    deno = ca.TsLag(close, 450, rpii=RPM)
    roc2 = close/deno-ca.C(1.0)
    roc2 = leEps2Na(roc2, deno)

    deno = ca.TsLag(close, 600, rpii=RPM)
    roc3 = close/deno-ca.C(1.0)
    roc3 = leEps2Na(roc3, deno)

    deno = ca.TsLag(close, 900, rpii=RPM)
    roc4 = close/deno-ca.C(1.0)
    roc4 = leEps2Na(roc4, deno)

    rocma1 = ca.TsMean(roc1, 300, rpii=RPM)
    rocma2 = ca.TsMean(roc2, 300, rpii=RPM)
    rocma3 = ca.TsMean(roc3, 300, rpii=RPM)
    rocma4 = ca.TsMean(roc4, 450, rpii=RPM)

    kst = ca.C(100.0)*(rocma1+ca.C(2.0)*rocma2+ca.C(3.0)*rocma3+ca.C(4.0)*rocma4)
    kst_sig = ca.TsMean(kst, 270, rpii=RPM)

    OUTPUT["F.M_c_trend_kst"] = kst
    OUTPUT["F.M_c_trend_kst_sig"] = kst_sig


def DPOIndicator():

    close = msg["close.1min"]

    close_lag = ca.TsLag(close, 301, rpii=RPM)
    close_ma = ca.TsMean(close, 600, rpii=RPM)
    feature = close_lag/close_ma-ca.C(1.0)

    OUTPUT["F.M_c_trend_dpo"] = leEps2Na(feature, close_ma)


#std近似
def CCIIndicator():

    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]

    pp = (high+low+close)/ca.C(3.0)

    mean_pp = ca.TsMean(pp, 600, rpii=RPM)
    deno = ca.C(0.015)*ca.TsStd(pp, 600, rpii=RPM)
    feature = (pp-mean_pp)/deno
    feature = ca.Sign(feature)*ca.NumPow(ca.Abs(feature), 0.45)
    
    OUTPUT["F.M_c_trend_cci"] = leEps2Na(feature, deno)


def VortexIndicator():

    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]

    tr = mymax(high, ca.TsLag(close, 1, rpii=RPM)) - mymin(low, ca.TsLag(close, 1, rpii=RPM)) 
    trn = ca.TsSum(tr, 420, rpii=RPM)

    vmp = ca.Abs(high-ca.TsLag(low, 1, rpii=RPM))
    vmm = ca.Abs(low-ca.TsLag(high, 1, rpii=RPM))
    vip = ca.TsSum(vmp, 420, rpii=RPM)
    vin = ca.TsSum(vmm, 420, rpii=RPM)

    vip /= trn
    vin /= trn

    vip = leEps2Na(vip, trn)
    vin = leEps2Na(vin, trn)

    vid = vip-vin
    
    OUTPUT["F.M_c_trend_vortex_vid"] = vid
    OUTPUT["F.M_c_trend_vortex_vip"] = vip
    OUTPUT["F.M_c_trend_vortex_vin"] = vin


def AverageTrueRange():

    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]

    cs = ca.TsLag(close, 1, rpii=RPM)
    tr = mymax(high, cs)-mymin(low, cs)
    feature = ca.Ema(tr, 420, rpii=RPM)
    close_ema = ca.Ema(close, 420, rpii=RPM)
    feature /= close_ema
    
    OUTPUT["F.M_c_volat_atr"] = leEps2Na(feature, close_ema)


def BollingerBands():

    close = msg["close.1min"]

    mavg = ca.TsMean(close, 600, rpii=RPM)
    mavg_long = ca.TsMean(close, 1200, rpii=RPM)
    mstd = ca.TsStd(close, 600, rpii=RPM)

    hband = mavg+ca.C(2)*mstd
    lband = mavg-ca.C(2)*mstd 
    wband = (hband-lband)/mavg*ca.C(100)
    wband = leEps2Na(wband, mavg)
    deno = hband-lband
    pband = (close-lband)/deno
    pband = leEps2Na(pband, deno)
    #hband_i = ca.IfElse(close>hband, ca.C(1), ca.C(0))
    #lband_i = ca.IfElse(close<lband, ca.C(1), ca.C(0))
    mavg /= mavg_long
    hband /= mavg_long
    lband /= mavg_long

    mavg = leEps2Na(mavg, mavg_long)
    hband = leEps2Na(hband, mavg_long)
    lband = leEps2Na(lband, mavg_long)

    pband = ca.Sign(pband)*ca.NumPow(ca.Abs(pband), 0.5)

    OUTPUT["F.M_c_volat_bb_lband"] = lband
    OUTPUT["F.M_c_volat_bb_mavg"] = mavg
    OUTPUT["F.M_c_volat_bb_hband"] = hband
    OUTPUT["F.M_c_volat_bb_wband"] = wband
    OUTPUT["F.M_c_volat_bb_pband"] = pband
    #OUTPUT["F.M_c_volat_bb_lband_i"] = lband_i
    #OUTPUT["F.M_c_volat_bb_hband_i"] = hband_i


def KeltnerChannel():

    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]

    basis = ca.Ema(close, 600, rpii=RPM)
    tr = mymax(high, ca.TsLag(close, 237, rpii=RPM)) - mymin(low, ca.TsLag(close, 237, rpii=RPM)) 
    atr = ca.Ema(tr, 600, rpii=RPM)
    mavg_long = ca.Ema(close, 1200, rpii=RPM)

    lower = basis-ca.C(2)*atr
    upper = basis+ca.C(2)*atr

    mavg = basis
    lband = lower
    hband = upper

    #hband_i = ca.IfElse(close>hband, ca.C(1), ca.C(0))
    #lband_i = ca.IfElse(close<lband, ca.C(1), ca.C(0))
    mavg /= mavg_long
    hband /= mavg_long
    lband /= mavg_long

    mavg = leEps2Na(mavg, mavg_long)
    hband = leEps2Na(hband, mavg_long)
    lband = leEps2Na(lband, mavg_long)

    OUTPUT["F.M_c_volat_kc_lband"] = lband
    OUTPUT["F.M_c_volat_kc_mavg"] = mavg
    OUTPUT["F.M_c_volat_kc_hband"] = hband
    #OUTPUT["F.M_c_volat_kc_lband_i"] = lband_i
    #OUTPUT["F.M_c_volat_kc_hband_i"] = hband_i


def DonchianChannel():

    close = msg["close.1min"]

    hband = ca.TsMax(close, 237, rpii=RPM)
    lband = ca.TsMin(close, 237, rpii=RPM)

    mavg = (hband+lband)/ca.C(2.0)
    mavg_long = ca.Ema(mavg, 1185, rpii=RPM)

    #hband_i = ca.IfElse(close>hband, ca.C(1), ca.C(0))
    #lband_i = ca.IfElse(close<lband, ca.C(1), ca.C(0))
    mavg /= mavg_long
    hband /= mavg_long
    lband /= mavg_long

    mavg = leEps2Na(mavg, mavg_long)
    hband = leEps2Na(hband, mavg_long)
    lband = leEps2Na(lband, mavg_long)

    OUTPUT["F.M_c_volat_dc_lband"] = lband
    OUTPUT["F.M_c_volat_dc_mavg"] = mavg
    OUTPUT["F.M_c_volat_dc_hband"] = hband
    #OUTPUT["F.M_c_volat_dc_lband_i"] = lband_i
    #OUTPUT["F.M_c_volat_dc_hband_i"] = hband_i


def OnBalanceVolumeIndicator():

    close = msg["close.1min"]
    volume = msg['dollarVolume.1min']
    diff_n = 237

    vol_long = ca.TsMean(volume, diff_n, rpii=RPM)
    volume = vol_long
    obv = ca.IfElse(close<ca.TsLag(close, diff_n, rpii=RPM), ca.C(0)-volume, volume)
    obv = ca.IfElse(myequal(close, ca.TsLag(close, diff_n, rpii=RPM)), ca.C(0), obv)
    
    count = ca.TsSum(ca.C(1), diff_n+1, rpii=RPM) #>self.n
    obv = ca.IfElse(count<=ca.C(diff_n), volume, obv)

    feature = ca.TsSum(obv, int(RPM*240), rpii=RPM)
    feature = feature/vol_long
    feature = ca.Sign(feature)*ca.NumPow(ca.Abs(feature), 0.5)
    OUTPUT["F.M_c_volume_obv"] = leEps2Na(feature, vol_long)

def ChaikinMoneyFlowIndicator():

    close = msg["close.1min"]
    volume = msg['dollarVolume.1min']
    n = 237
    diff_n = 237

    vol_long = ca.Ema(volume, span2hl(n), rpii=RPM)
    volume = vol_long
    close_long = ca.TsMean(close, 1185, rpii=RPM)

    fi = (close-ca.TsLag(close, diff_n, rpii=RPM))*volume
    feature = ca.Ema(fi, span2hl(n), rpii=RPM)
    deno = vol_long*close_long
    feature /= deno

    OUTPUT["F.M_c_volume_fi"] = leEps2Na(feature, deno)

    

def EaseOfMovementIndicator():

    high = msg["high.1min"]
    low = msg["low.1min"]
    volume = msg['dollarVolume.1min']
    high_d = msg["high.daily"]
    low_d = msg["low.daily"]
    n = 1185
    #diff_n = 237
    divisor = 100000000.0
    #divisor = 0.0001

    high_prev = ca.TsLag(high_d, 237, rpii=RPM) #yesterday
    low_prev = ca.TsLag(low_d, 237, rpii=RPM)

    max_v = ca.TsMax(high, int(RPM*240), rpii=RPM)
    min_v = ca.TsMin(low, int(RPM*240), rpii=RPM)

    emv = (max_v-high_prev+min_v-low_prev)*(max_v-min_v)/(ca.C(2.0)*volume)
    
    emv *= ca.C(divisor)
    emv = leEps2Na(emv, volume)

    emv = ca.Na20(emv)

    nor = ca.TsMean(ca.Abs(emv), n, rpii=RPM)
    feature = emv/nor
    OUTPUT["F.M_c_volume_em"] = feature #leEps2Na(feature, nor)
    #OUTPUT["F.M_c_volume_em"] = emv


def VolumePriceTrendIndicator():

    close = msg["close.1min"]
    volume = msg['dollarVolume.1min']
    diff_n = 237

    nor = ca.TsLag(close, diff_n, rpii=RPM)
    vpt = volume*(close/nor-ca.C(1.0))
    vpt = leEps2Na(vpt, nor)

    m_vpt = ca.TsSum(vpt, int(RPM*240), rpii=RPM)
    vol_ma = ca.TsMean(volume, int(5*diff_n), rpii=RPM)
    feature = m_vpt/vol_ma
    OUTPUT["F.M_c_volume_vpt"] = leEps2Na(feature, vol_ma)


''' #not in cols 
def NegativeVolumeIndexIndicator():
    g_node = GV.g_node()
    msg = GV.data()

    close = msg["close.1min"]
    volume = msg['dollarVolume.1min']
    diff_n = 390
    nvi0 = 1000.0

    nor = ca.TsLag(close, diff_n, rpii=RPM)
    price_change = close/nor-ca.C(1.0)
    price_change = leEps2Na(price_change, nor)

    ratio = ca.IfElse(ca.TsLag(volume, diff_n, rpii=RPM)>volume, ca.C(1.0)+price_change, ca.C(0.0))
    ratio_cum = ca.TsSum(ratio, int(RPM*240), rpii=RPM) + ca.C(1.0)
    m_nvi = ratio_cum*ca.C(nvi0)

    OUTPUT["F.M_c_volume_nvi"] = m_nvi
'''

def check():
    OUTPUT["close"] = ca("close.1min")
    OUTPUT["close.daily"] = ca("close.daily")
    OUTPUT["close.adjusted"] = ca("close.adjusted")
    OUTPUT["open.ratio"] = msg['open.1min']
    OUTPUT["close.ratio"] = msg['close.1min']
    OUTPUT["lastTradePrice.ratio"] = msg['lastTradePrice.1min']
    OUTPUT["dollarVolumeTotal.ratio"] = msg['dollarVolumeTotal.1min']
    OUTPUT["dollarVolume.ratio"] = msg['dollarVolume.1min']