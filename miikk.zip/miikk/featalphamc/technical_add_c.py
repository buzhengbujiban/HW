#!/usr/bin/env python
# -*- coding: UTF-8 -*-

from jobs.rnodes.rnode import RNode, SlurmCfg
from canopus_py.rnodes.ca_node import CANode
from canopus_py.ca_expr import *
from canopus_py.ca_stats import *

from mc_utils import *

import GV
msg = GV.data()
OUTPUT = GV.fea()
LEN = 240
RPM = 20


def ADXIndicator_new(): #canopus自动fillna，因此不需要myfillna
    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]
    n = 420
    diff_n = 1

    cs = ca.TsLag(close, diff_n, rpii=RPM)
    tr = mymax(high, cs)-mymin(low, cs)
    atr_ = ca.Ema(tr, span2hl(n), rpii=RPM)

    up = high - ca.TsLag(high, diff_n, rpii=RPM)
    dn = ca.TsLag(low, diff_n, rpii=RPM) - low

    pos = ca.IfElse((up>dn)&(up>ca.C(0)), up, ca.C(0))
    neg = ca.IfElse((up<dn)&(dn>ca.C(0)), dn, ca.C(0))

    k = ca.C(100.0)/atr_
    k = leEps2Na(k, atr_)

    dmp = k*ca.Ema(pos, span2hl(n), rpii=RPM)
    dmn = k*ca.Ema(neg, span2hl(n), rpii=RPM)
    deno = dmp + dmn
    dx = ca.C(100.0) * ca.Abs(dmp - dmn) / deno
    dx = leEps2Na(dx, deno)

    adx = ca.Ema(dx, span2hl(n), rpii=RPM)

    OUTPUT["F.M_cA_trend_adx"] = adx
    OUTPUT["F.M_cA_trend_adx_pos"] = dmp
    OUTPUT["F.M_cA_trend_adx_neg"] = dmn

def ASIIndicator():

    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]
    open = msg["open.1min"]
    n = 420
    diff_n = 1

    close_shift = ca.TsLag(close, diff_n, rpii=RPM)
    high_shift = ca.TsLag(high, diff_n, rpii=RPM)
    open_shift = ca.TsLag(open, diff_n, rpii=RPM)
    low_shift = ca.TsLag(low, diff_n, rpii=RPM)

    nume = close_shift-close+ca.C(0.5)*(close_shift-open_shift)+ca.C(0.25)*(close-open)
    a, b = high_shift-close, close-low_shift
    K = ca.IfElse(a>b, a, b)
    a, b = high-close_shift, close_shift-low
    TR = ca.IfElse(a>b, a, b)
    TR = ca.IfElse(TR>high-low, TR, high-low)

    R1 = high-close_shift-ca.C(0.5)*(close_shift-low)+ca.C(0.25)*(close_shift-open_shift)
    R2 = low-close_shift-ca.C(0.5)*(high-close_shift)+ca.C(0.25)*(close_shift-open_shift)
    R3 = high-low+ca.C(0.25)*(close_shift-open_shift)

    R = ca.IfElse(myequal(TR, high-close_shift), R1, R3)
    R = ca.IfElse(myequal(TR, close_shift-low), R2, R)

    T = ca.TsMax(high-low, n, rpii=RPM)
    SI = ca.C(50.0)*K/T*nume/R
    SI = leEps2Na(SI, T*R)

    feature = ca.Ema(SI, span2hl(n), rpii=RPM)

    feature = ca.Sign(feature)*ca.NumPow(ca.Abs(feature), 0.45)
    
    OUTPUT["F.M_cA_asi"] = feature

''' #not in cols
def CHIIndicator():

    close = msg["close.1min"]
    n = 420 

    expect = ca.TsMean(close, n, rpii=RPM)
    expect = leEps2Na(expect, expect)

    feature = ca.TsMean((close-expect)*(close-expect)/expect, n, rpii=RPM)
    OUTPUT["F.CHIIndicator"] = feature
'''

def ELRIndicator():

    close = msg["close.1min"]
    n = 390

    close_ewm = ca.Ema(close, span2hl(n), rpii=RPM)
    bull = ca.TsMax(close, n, rpii=RPM)/close_ewm - ca.C(1.0)
    bear = ca.TsMin(close, n, rpii=RPM)/close_ewm - ca.C(1.0)

    bull = leEps2Na(bull, close_ewm)
    bear = leEps2Na(bear, close_ewm)

    OUTPUT["F.M_cA_elr_bull"] = bull
    OUTPUT["F.M_cA_elr_bear"] = bear

#近似
def EPMAIndicator():
    close = msg["close.1min"]
    n = 390

    nor = ca.TsMean(close, 1185, rpii=RPM)
    feature = ca.Ema(close, n, rpii=RPM)
    feature /= nor

    OUTPUT["F.M_cA_epma"] = feature


def SHARPEIndicator():
    close = msg["close.1min"]
    n = 390 
    diff_n = 1

    close = ca.Log(close)
    roc = close - ca.TsLag(close, diff_n, rpii=RPM)
    stdev = ca.TsStd(roc, n, rpii=RPM)

    feature = roc/stdev
    stdev = leEps2Na(feature, stdev)

    feature = ca.Sign(feature)*ca.NumPow(ca.Abs(feature), 0.45)
    OUTPUT["F.M_cA_sharp"] = feature


def PVIIndicator():
    close = msg["close.1min"]
    volume = msg['dollarVolume.1min']

    n = 390 
    diff_n = 1 
    pvi0 = 1000.0

    close = ca.Na20(close)
    volume = ca.Na20(volume)

    close_shift = ca.TsLag(close, diff_n, rpii=RPM)
    price_change = close/close_shift-ca.C(1.0)
    price_change = leEps2Na(price_change, close_shift)

    ratio = ca.IfElse(ca.TsLag(volume, diff_n, rpii=RPM)<volume, ca.C(1.0)+price_change, ca.C(0.0))
    ratio_cum = ca.TsSum(ratio, int(RPM*240), rpii=RPM) + ca.C(1.0)
    m_nvi = ratio_cum*ca.C(pvi0)

    OUTPUT["F.M_cA_pvi"] = m_nvi

def chop():
    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]
    length = 420 
    atr_length = 30
    scalar = 100
    diff_n = 1

    cs = ca.TsLag(close, diff_n, rpii=RPM)
    tr = mymax(high, cs)-mymin(low, cs)
    atr_ = ca.Ema(tr, span2hl(atr_length), rpii=RPM)
    atr_sum = ca.TsSum(atr_, length, rpii=RPM)

    diff = ca.TsMax(high, length, rpii=RPM) - ca.TsMin(low, length, rpii=RPM)
    feature = ca.C(scalar)*(ca.Log(atr_sum)/ca.Log(ca.C(10))-ca.Log(diff)/ca.Log(ca.C(10)))
    feature = feature/ca.Log(ca.C(length))*ca.Log(ca.C(10))

    OUTPUT["F.M_cA_pt_chop"] = feature



def cksp():

    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]
    p = 300 
    x = 1
    q = 270
    diff_n = 10

    cs = ca.TsLag(close, diff_n, rpii=RPM)
    tr = mymax(high, cs)-mymin(low, cs)
    atr_ = ca.Ema(tr, span2hl(p), rpii=RPM)

    long_stop_ = ca.TsMax(high, p, rpii=RPM)-ca.C(x)*atr_
    long_stop_ = ca.TsMax(long_stop_, q, rpii=RPM)

    short_stop_ = ca.TsMin(high, p, rpii=RPM)+ca.C(x)*atr_
    short_stop_ = ca.TsMin(short_stop_, q, rpii=RPM)

    nor = ca.TsMean(close, 1185, rpii=RPM)
    long_stop_ /= nor
    short_stop_ /= nor

    OUTPUT["F.M_cA_pt_cksp_long"] = leEps2Na(long_stop_, nor)
    OUTPUT["F.M_cA_pt_cksp_short"] = leEps2Na(short_stop_, nor)

def increasing():

    close = msg["close.1min"]
    diff_n = 30

    increasing = ca.IfElse(close>ca.TsLag(close, diff_n, rpii=RPM), ca.C(2.), ca.C(0.))
    feature = increasing-ca.C(1.)

    OUTPUT["F.M_cA_pt_increasing"] = feature


def linear_decay():

    close = msg["close.1min"]
    n = 5 
    diff_n = 1

    nor = ca.TsMean(close, 1185, rpii=RPM)
    diff = ca.TsLag(close, diff_n, rpii=RPM) - (ca.C(1.0/n))

    feature = mymax(close, diff)
    feature /= nor
    OUTPUT["F.M_cA_pt_ldecay"] = feature

def qstick():

    open = msg["open.1min"]
    close = msg["close.1min"]
    n = 300

    diff = close-open
    feature = ca.Ema(diff, span2hl(n), rpii=RPM)
    nor = ca.TsMean(close, 1185, rpii=RPM)
    feature /= nor

    OUTPUT["F.M_cA_pt_qstick"] = feature

def pgo():

    high = msg["high.1min"]
    low = msg["low.1min"]
    close = msg["close.1min"]
    n = 420
    diff_n = 237

    pgo = close-ca.Ema(close, span2hl(n), rpii=RPM)

    cs = ca.TsLag(close, diff_n, rpii=RPM)
    tr = mymax(ca.TsMax(high, diff_n, rpii=RPM), cs)-mymin(ca.TsMin(low, diff_n, rpii=RPM), cs)
    atr_ = ca.Ema(tr, span2hl(n), rpii=RPM)
    aatr_ = ca.Ema(atr_, span2hl(n), rpii=RPM)

    feature = pgo/aatr_
    feature = ca.Sign(feature)*ca.NumPow(ca.Abs(feature), 0.5)
    OUTPUT["F.M_cA_pt_pgo"] = leEps2Na(feature, aatr_)


def psl():

    open = msg["open.1min"]
    close = msg["close.1min"]
    n = 360
    scalar = 100

    diff = ca.Sign(open-close)
    feature = ca.C(scalar)*ca.TsSum(diff, n, rpii=RPM)/ca.C(n)
    OUTPUT["F.M_cA_pt_psl"] = feature


def pvo():

    volume = msg['dollarVolume.1min']
    fast = 360
    slow = 780
    signal = 270
    scalar = 100

    fastma = ca.Ema(volume, span2hl(fast), rpii=RPM)
    slowma = ca.Ema(volume, span2hl(slow), rpii=RPM)
    pvo = ca.C(scalar) * (fastma - slowma)
    pvo /= slowma

    pvo = leEps2Na(pvo, slowma)
    pvo = ca.Sign(pvo)*ca.NumPow(ca.Abs(pvo), 0.5)
    signalma = ca.Ema(pvo, span2hl(signal), rpii=RPM)
    histogram = pvo - signalma

    OUTPUT["F.M_cA_pt_pvo_sig"] = signalma
    OUTPUT["F.M_cA_pt_pvo_hist"] = histogram

def rvgi():

    high_d = msg['high.daily']
    low_d = msg['low.daily']
    close_d = msg['close.daily']
    close = msg['close.1min']
    n1 = 420
    n2 = 120
    diff_n = 237

    high_low_range = ca.TsLag(high_d, diff_n, rpii=RPM)-ca.TsLag(low_d, diff_n, rpii=RPM)
    close_open_range = close-ca.TsLag(close_d, diff_n, rpii=RPM)

    numerator = ca.Ema(close_open_range, span2hl(n2), rpii=RPM)
    denominator = ca.Ema(high_low_range, span2hl(n2), rpii=RPM)

    numerator = ca.TsSum(numerator, n1, rpii=RPM)
    denominator = ca.TsSum(denominator, n1, rpii=RPM)
    rvgi = numerator/denominator
    rvgi = leEps2Na(rvgi, denominator)
    signal = ca.Ema(rvgi, span2hl(n2), rpii=RPM)

    OUTPUT["F.M_cA_pt_rvgi"] = rvgi
    OUTPUT["F.M_cA_pt_rvgi_signal"] = signal


def slope():

    close = msg['close.1min']
    n = 30

    slope = (close-ca.TsLag(close, n, rpii=RPM))/ca.C(n)
    x = slope

    feature = x - ca.NumPow(x, 3)/ca.C(3) + ca.NumPow(x, 5)/ca.C(5) - ca.NumPow(x, 7)/ca.C(7) #atan
    OUTPUT["F.M_cA_pt_slope"] = feature


def eri():

    high = msg['high.1min']
    low = msg['low.1min']
    close = msg['close.1min']
    n = 390 

    ema_ = ca.Ema(close, span2hl(n), rpii=RPM)

    bull = ca.TsMax(high, n, rpii=RPM) - ema_
    bear = ca.TsMin(low, n, rpii=RPM) - ema_
    bull /= ema_
    bear /= ema_
    OUTPUT["F.M_cA_pt_eri_bull"] = leEps2Na(bull, ema_)
    OUTPUT["F.M_cA_pt_eri_bear"] = leEps2Na(bear, ema_) 

#近似
def fisher():

    high = msg['high.1min']
    low = msg['low.1min']
    n = 270
    signal = 30

    hl2_ = ca.C(0.5)*(high+low)
    highest_hl2 = ca.TsMax(hl2_, n, rpii=RPM)
    lowest_hl2 = ca.TsMin(hl2_, n, rpii=RPM)
    hlr = highest_hl2-lowest_hl2
    hlr = ca.IfElse(hlr<ca.C(0.001), ca.C(0.001), hlr)
    hlr = leEps2Na(hlr, hlr)

    position = ((hl2_ - lowest_hl2) / hlr) - ca.C(0.5)
    position = leEps2Na(position, hlr)

    m_v = ca.C(0.66)*ca.TsSum(position, int(RPM*240), rpii=RPM)
    m_v = ca.IfElse(m_v<ca.C(-0.99), ca.C(-0.99), m_v)
    m_v = ca.IfElse(m_v>ca.C(0.99), ca.C(0.99), m_v)

    a = ca.Log((ca.C(1)+m_v)/(ca.C(1)-m_v))
    a = ca.Na20(a)

    m_fisherV = ca.C(0.5)*ca.TsSum(a, int(RPM*240), rpii=RPM)
    signalma = ca.TsLag(m_fisherV, signal, rpii=RPM)

    m_fisherV = ca.Sign(m_fisherV)*ca.NumPow(ca.Abs(m_fisherV), 0.45)
    signalma = ca.Sign(signalma)*ca.NumPow(ca.Abs(signalma), 0.45)

    OUTPUT["F.M_cA_pt_fisher"] = m_fisherV
    OUTPUT["F.M_cA_pt_fisher_sig"] = signalma


def kdj():

    high = msg['high.1min']
    low = msg['low.1min']
    close = msg['close.1min']
    n = 270
    signal = 90

    highest_high = ca.TsMax(high, n, rpii=RPM)
    lowest_low = ca.TsMin(low, n, rpii=RPM)
    deno = highest_high-lowest_low
    fastk = ca.C(100.0) * (close-lowest_low)/deno
    fastk = leEps2Na(fastk, deno)

    k = ca.Ema(fastk, span2hl(signal), rpii=RPM)
    d = ca.Ema(k, span2hl(signal), rpii=RPM)
    j = ca.C(3)*k-ca.C(2)*d

    OUTPUT["F.M_cA_pt_kdj_k"] = k
    OUTPUT["F.M_cA_pt_kdj_d"] = d
    OUTPUT["F.M_cA_pt_kdj_j"] = j

#近似
def cg():
    
    close = msg['close.1min']
    n = 300

    close = ca.Na20(close)
    deno = ca.TsMean(close, n, rpii=RPM)
    numerator = ca.Ema(close, span2hl(n), rpii=RPM)

    feature = ca.C(-150)*numerator/deno
    OUTPUT["F.M_cA_pt_cg"] = leEps2Na(feature, deno)




    












    

