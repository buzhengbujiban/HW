import os

import argparse
import bisect
import json5
import numpy as np
import pandas as pd
from pandas import Series
import xarray as xr

import panel
import pytbl




def get_df_Fourier_spread_by_sid(pt, date, T, deltat, w, clockFreq):
    '''
    获取多只股票的tbl数据, 预处理后, 按sid分组, 得到dict{sid: df}
    '''

    df = pytbl.tbl_read(pt.replace('YYYYMMDD', str(date)))
    df = df[df['TS']!=0]           # 去掉无效的msg: TS, P, Q, Sid都为0
    df['Sid'] = df['Sid'].round().astype(int)
    df['date'] = int(date)


    df['TS_CN'] = pd.to_datetime(df['TS'] + 3600 * 8, unit='s')       # datetime时间: 转换为中国时区: yy-mm-dd-hh-mm-ss
    df['TS_sod'] = (df['TS'] + 3600 * 8) % 86400                      # 从sod开始计算的日内秒数
    
    df = df.sort_values(by='TS_sod').reset_index(drop=True)   # 不同股票并行时, TS不一定严格递增, 手动排序处理

    noon_idx = bisect.bisect_right(df['TS_sod'], 3600 * 12)        # 插入排序: 12:00的idx, 上半段是am, 下半段是pm
    TS_intrading_am = df['TS_sod'].iloc[:noon_idx] - 3600 * 9.5    # 连续的timestamp, 单位s, 上午
    TS_intrading_pm = df['TS_sod'].iloc[noon_idx:] - 3600 * 11     # 连续的timestamp, 单位s, 下午

    TS_intrading = pd.concat([TS_intrading_am, TS_intrading_pm])
    df['TS_intrading'] = TS_intrading.values                          # 连续交易的秒数

    Fourier_spread_sdiv = xr.concat([cal_Fourier_spread(df_sid.set_index('TS_CN'), T, deltat, w, clockFreq) for sid, df_sid in df.groupby('Sid')], dim='S').sortby('S')

    return Fourier_spread_sdiv


def cal_Fourier_spread(df, T, deltat, w, clockFreq):
    '''
    计算df的Fourier各阶振幅
    T             # 时间窗口, 表示最大可看到T的频率发单, 单位: s
    deltat        # q(t)的平滑窗口
    w             # 衰减率, t-T时刻的衰减系数为w
    clockfreq     # timewindow刷新频率, 单位: s

    return: SDIV, 其中S=1, D=1
    '''
    sid = str(df['Sid'].iloc[0])
    date = str(df['date'].iloc[0])


    omega0 = 2 * np.pi / T    # 最小的频率
    lamda = -np.log(w) / T    # ema系数

    # 根据 clockFreq 生成的标准index: 09:31-15:00, =60为240行, =300为48行
    standard_index = pd.date_range(f"{date} 09:3{clockFreq//60}", f"{date} 11:30", freq=f'{clockFreq//60}min').append(
                    pd.date_range(f"{date} 13:0{clockFreq//60}", f"{date} 15:00", freq=f'{clockFreq//60}min'))

    tmp_lst = []

    for T0 in range(1, 61):
        n = T // T0

        Fourier_cumsum_resampled_without_ema = (df['Q'] * np.exp(-1j * n * omega0 * df['TS_intrading']) * np.exp(lamda * df['TS_intrading'])* deltat / T).resample(
                                                f'{clockFreq//60}min', label='right').sum().cumsum().reindex(standard_index).rename(f'{T0}s')

        tmp_lst.append(Fourier_cumsum_resampled_without_ema)
        # df[f'{T0}s'] = ((df['Q'] * np.exp(-1j * n * omega0 * df['TS_intrading']) * np.exp(lamda * df['TS_intrading'])).cumsum() * deltat / T * np.exp(-lamda * df['TS_intrading'])).abs()

    ema = np.exp(-lamda * Series(np.arange(clockFreq, 60 * 60 * 4 + 1, clockFreq), index=standard_index))
    Fourier_result = pd.concat(tmp_lst, axis=1).mul(ema, axis=0).abs()

    Fourier_result.index = Fourier_result.index.map(lambda x: str(x)[-8:])   # 转换成SDIV标准格式的index: '09:31:00'

    # 转换成SDIV

    xarr = xr.DataArray(
        Fourier_result.values,                      # 数据值
        dims=['I', 'V'],                  # 指定行和列的名称
        coords={                          # 添加坐标
            'I': Fourier_result.index,              # 行坐标
            'V': Fourier_result.columns,            # 列坐标
        }, 
    ).expand_dims(S=[sid], D=[date]).transpose('S', 'D', 'I', 'V')

    return xarr


def Fourier_start_oneday(date, cfg_path):
    # 读取配置文件
    with open(cfg_path, 'r') as file:
        cfg = json5.load(file)

    Fourier_spread_sdiv = get_df_Fourier_spread_by_sid(cfg['tbl_pattern'], str(date), cfg['T'], cfg['deltat'], cfg['w'], cfg['clockFreq'])
    panel.write(cfg['sdiv_save_pattern'].replace('YYYYMMDD', str(date)), Fourier_spread_sdiv)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Fourier.Node')
    parser.add_argument('--date', type=str, required=True, help='date', )
    parser.add_argument('--cfg', type=str, required=True, help='cfg', )
    
    args = parser.parse_args()
    date = args.date
    cfg_path = args.cfg
    Fourier_start_oneday(date, cfg_path)