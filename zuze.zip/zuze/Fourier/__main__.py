
import os
import sys

import busdates
from datetime import datetime
import shutil
import subprocess


import argparse
import json5
from Fourier import Fourier_oneday
from minialpha.utils.utils import MultiRunBasic, timedelta_to_str
import pattern_helper


if __name__ == '__main__':
    start_time = datetime.now()
    print(f'{start_time.strftime("%Y-%m-%d %H:%M:%S")}    Fourier begins!')
    print()

    parser = argparse.ArgumentParser(description='Fourier')
    parser.add_argument('--cfg', type=str, required=True, help='cfg', )
    args = parser.parse_args()
    cfg_path = args.cfg    # 获取命令行参数中的文件路径


    # 读取配置文件
    with open(cfg_path, 'r') as file:
        cfg = json5.load(file)


    # mkdir to save Fourier sdiv
    sdiv_save_path = os.path.dirname(cfg['sdiv_save_pattern'])
    os.makedirs(sdiv_save_path, exist_ok=True)

    # get walk dates: intersection of tbl pattern exist days & subscribed start/end dates
    pattern_exist_dates = set(map(str, pattern_helper.find_dates_from_pattern(cfg['tbl_pattern'])))
    walk_dates = sorted(pattern_exist_dates)


    if cfg['slurm_config']['slurm']:
        # write tasks.txt for slurm
        slurm_start_time = datetime.now()
        print(f'{slurm_start_time.strftime("%Y-%m-%d %H:%M:%S")}  Fourier, slurm begins')
        print()

        SlurmPath = f'{sdiv_save_path}/slurm'
        os.makedirs(SlurmPath, exist_ok=True)
        with open(f'{SlurmPath}/tasks.txt', "w") as file:

            for date in walk_dates:
                line = f'python /data/nfshome/zuze/git/zuze/Fourier/Fourier_oneday.py --date {date} --cfg {cfg_path}'
                file.write(line + "\n")  # 手动添加换行符

        command = f"cat {SlurmPath}/tasks.txt | run-parallel \
            --sourceProfile -w {SlurmPath} -j 1  --ompThreads {cfg['slurm_config']['omp_threads']} --slurm --slurmForceProgress \
                -smem {cfg['slurm_config']['smem']} --keepJobOut --retries {cfg['slurm_config']['retries']} --timeout {cfg['slurm_config']['timeout']} \
                --slurmQueue {cfg['slurm_config']['slurmQueue']} --slurmJobName {cfg['slurm_config']['slurmJobName']}"
        result = subprocess.run(command, shell=True, stdout=sys.stdout, stderr=sys.stderr)

        slurm_end_time = datetime.now()
        print(f'{slurm_end_time.strftime("%Y-%m-%d %H:%M:%S")}  Fourier, slurm ends')
        print(f'slurm use time: {timedelta_to_str(slurm_end_time-slurm_start_time)}')
        print()


    else:
        multiprocess_start_time = datetime.now()
        print(f'{multiprocess_start_time.strftime("%Y-%m-%d %H:%M:%S")}  Fourier, multiprocess begins')
        print()

        def go(date):
            Fourier_oneday.Fourier_start_oneday(date, cfg_path)
        MultiRunBasic(go, walk_dates, cfg['multiprocess_num'])

        multiprocess_end_time = datetime.now()
        print(f'{multiprocess_end_time.strftime("%Y-%m-%d %H:%M:%S")}  Fourier, multiprocess ends')
        print(f'multiprocess use time: {timedelta_to_str(multiprocess_end_time-multiprocess_start_time)}')
        print()


    # global: 把config文件copy到pattern目录下, 以供备份
    shutil.copy(cfg_path, f'{sdiv_save_path}/{os.path.basename(cfg_path)}')
    print()
    print(f'copy config to AlphaSavePath: ')
    print(f'from: {cfg_path}')
    print(f'to: {sdiv_save_path}/{os.path.basename(cfg_path)}')
    print()