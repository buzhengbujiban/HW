### act类的Filter Msg: 即Base msg是act类, 用多种filter标准来筛选, 得到多种stats

import pqsum_py.msg_info as mi
from pqsum_py.runner import PQSumNode
from jobs.rnodes.rnode import RNode
from pattern_helper import *

from pathlib import Path
import argparse
import copy

from pqsum_py.utils import *

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='PQSumNode')
    parser.add_argument('--univ', type=str, required=True, help='universe', choices=["hs300", "zz500", "non800", "G2548"])
    args = parser.parse_args()

    RNode.RNODE_ROOT = "/data/bees3/unsafe/zuze/pqsum_py/rroot"
    RNode.GLOBAL_TASKNAME = f"{Path(__file__).stem}_{args.univ}"

    def set_node_params(node):
        node.startTime = "09:31:00"
        node.stopTime = "15:01:00"
        node.clockFreq = 60
        node.univ = args.univ

        node.slurm_enable = True
        node.slurm_cfg = {
            "slurm": True, 
            "slurmQueue": 'fqueue', 
            "slurmJobName": "MyFilterMsg.act",
            "slurmForceProgress": 1, "retries": 2,
            "omp_threads":10,
            "timeout":"01:00:00",
            # "slurmNfs": 'nas6:2', 
            # "slurmBatch": 5, 
            "smem": 5000,
        }

        # node.use_persid_md = False
        node.parallel_spec = '1'
        node.use_persid_md = False
        node.persid_threads = 10

        if node.univ == "G2548":
            node.univ = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
        if node.univ == "gp500":
            node.univ = "/data/beef3/zuze/Univ/gp500/gp500.csv"
        # node.univ = f"sids:1,1988"
        # node.univ = f"sids:1988"
        node.sdate = 20171001
        node.edate = 20240930


    def is_addact_B():  # 被动买单
        return mi.act.IsValid & mi.act.IsB  & mi.bk.InTrading
    def is_addact_S():  # 被动卖单
        return mi.act.IsValid & mi.act.IsS  & mi.bk.InTrading

    def is_tail_0(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(0)
    def is_tail_1(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(1)
    def is_tail_2(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(2)
    def is_tail_3(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(3)
    def is_tail_4(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(4)
    def is_tail_5(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(5)
    def is_tail_6(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(6)
    def is_tail_7(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(7)
    def is_tail_8(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(8)
    def is_tail_9(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(9)


    def get_pq_stats():
        return {
            'c': mi.ut.C(1),
            'q': mi.act.Q,
            'pq': mi.act.P * mi.act.Q,
            'D': mi.act.D2,            # 实际价格减去BBO价格
            'Dq': mi.act.D2 * mi.act.Q, 
        }


# 注: 所有 P==BBO (即mi.act.D2 == 0)的FilterMsg, 都已加上IsBBO的标签, 这类Stats的D2和D2q全局为0, 生成因子时需注意
# hit_qBBO和Q100大概率会出现D2=0

    add_cfg = gen_pqsum_config(
        filters={
            # 全部addact: 被动add
            'addact.B.all': is_addact_B(), 
            'addact.S.all': is_addact_S(), 

            # 1. 按尾数划分: 尾数0-9
            'addact.B.tail0': is_addact_B() & is_tail_0(mi.act.P), 
            'addact.B.tail1': is_addact_B() & is_tail_1(mi.act.P), 
            'addact.B.tail2': is_addact_B() & is_tail_2(mi.act.P), 
            'addact.B.tail3': is_addact_B() & is_tail_3(mi.act.P), 
            'addact.B.tail4': is_addact_B() & is_tail_4(mi.act.P), 
            'addact.B.tail5': is_addact_B() & is_tail_5(mi.act.P), 
            'addact.B.tail6': is_addact_B() & is_tail_6(mi.act.P), 
            'addact.B.tail7': is_addact_B() & is_tail_7(mi.act.P), 
            'addact.B.tail8': is_addact_B() & is_tail_8(mi.act.P), 
            'addact.B.tail9': is_addact_B() & is_tail_9(mi.act.P), 
            'addact.S.tail0': is_addact_S() & is_tail_0(mi.act.P), 
            'addact.S.tail1': is_addact_S() & is_tail_1(mi.act.P), 
            'addact.S.tail2': is_addact_S() & is_tail_2(mi.act.P), 
            'addact.S.tail3': is_addact_S() & is_tail_3(mi.act.P), 
            'addact.S.tail4': is_addact_S() & is_tail_4(mi.act.P), 
            'addact.S.tail5': is_addact_S() & is_tail_5(mi.act.P), 
            'addact.S.tail6': is_addact_S() & is_tail_6(mi.act.P), 
            'addact.S.tail7': is_addact_S() & is_tail_7(mi.act.P), 
            'addact.S.tail8': is_addact_S() & is_tail_8(mi.act.P), 
            'addact.S.tail9': is_addact_S() & is_tail_9(mi.act.P), 


            # 2. 从众效应: 按Follow/Reverse 当前盘口imba来划分, BQ>AQ时挂买单为Follow, BQ<=AQ时挂买单为Reverse
            'addact.B.FolImba1': is_addact_B() & (mi.bk.BQ(0) > mi.bk.AQ(0)),                               # 从众: 在BQ0 > AQ0时挂被动买单
            'addact.B.FolImba1_isBBO': is_addact_B() & (mi.act.D2 == 0)  & (mi.bk.BQ(0) > mi.bk.AQ(0)),      # 从众: 挂对方BBO
            'addact.B.FolImba1_gtBBO': is_addact_B() & (mi.act.D2 > 0) & (mi.bk.BQ(0) > mi.bk.AQ(0)),         # 从众: 挂对方BBO以外
            'addact.B.RevImba1': is_addact_B() & (mi.bk.BQ(0) <= mi.bk.AQ(0)),                              # 反向: 在BQ0 <= AQ0时挂被动买单
            'addact.B.RevImba1_isBBO': is_addact_B() & (mi.act.D2 == 0)  & (mi.bk.BQ(0) <= mi.bk.AQ(0)),     # 反向: 挂对方BBO
            'addact.B.RevImba1_gtBBO': is_addact_B() & (mi.act.D2 > 0) & (mi.bk.BQ(0) <= mi.bk.AQ(0)),        # 反向: 挂对方BBO以外
            'addact.S.FolImba1': is_addact_S() & (mi.bk.BQ(0) < mi.bk.AQ(0)),                               # 从众: 在BQ0 > AQ0时挂被动买单
            'addact.S.FolImba1_isBBO': is_addact_S() & (mi.act.D2 == 0)  & (mi.bk.BQ(0) < mi.bk.AQ(0)),      # 从众: 挂对方BBO
            'addact.S.FolImba1_gtBBO': is_addact_S() & (mi.act.D2 > 0) & (mi.bk.BQ(0) < mi.bk.AQ(0)),         # 从众: 挂对方BBO以外
            'addact.S.RevImba1': is_addact_S() & (mi.bk.BQ(0) >= mi.bk.AQ(0)),                              # 反向: 在BQ0 <= AQ0时挂被动买单
            'addact.S.RevImba1_isBBO': is_addact_S() & (mi.act.D2 == 0)  & (mi.bk.BQ(0) >= mi.bk.AQ(0)),     # 反向: 挂对方BBO
            'addact.S.RevImba1_gtBBO': is_addact_S() & (mi.act.D2 > 0) & (mi.bk.BQ(0) >= mi.bk.AQ(0)),        # 反向: 挂对方BBO以外

            # 3. 提取Q=100的add
            'addact.B.Q100': is_addact_B() & (mi.act.Q == mi.ut.C(100)), 
            'addact.S.Q100': is_addact_S() & (mi.act.Q == mi.ut.C(100)), 

            # 4. act按Lvl划分: 等于BBO/大于BBO/距离BBO在一个spread以内/以外
            'addact.B.Lvl_isBBO': is_addact_B() & (mi.act.D2 == 0),      # act order: P == BBO
            'addact.B.Lvl_gtBBO': is_addact_B() & (mi.act.D2 > 0),     # act order: P > BBO
            'addact.B.Lvl_leqSP': is_addact_B() & (mi.act.D2 > 0) & (mi.act.D2 <= mi.act.SP),    # act order: BBO < P <= BBO + SP(成交前一瞬间的spread)
            'addact.B.Lvl_gtSP': is_addact_B() & (mi.act.D2 > mi.act.SP),  # act order: P > BBO + SP(成交前一瞬间的spread)
            'addact.S.Lvl_isBBO': is_addact_S() & (mi.act.D2 == 0),      # act order: P == BBO
            'addact.S.Lvl_gtBBO': is_addact_S() & (mi.act.D2 > 0),     # act order: P < BBO
            'addact.S.Lvl_leqSP': is_addact_S() & (mi.act.D2 > 0) & (mi.act.D2 <= mi.act.SP),    # act order: BBO > P >= BBO - SP(成交前一瞬间的spread)
            'addact.S.Lvl_gtSP': is_addact_S() & (mi.act.D2 > mi.act.SP),  # act order: P < BBO - SP(成交前一瞬间的spread)


            # 5. 击穿BBO的订单: 大前提mi.act.Q >= mi.act.LQ
            'addact.B.hit': is_addact_B() & (mi.act.Q >= mi.act.LQ),                                        # 主动单的Q >= 对方Q0, 作为一定击穿的判断条件
            # 'addact.B.hit': is_addact_B() & (mi.act.LV > 0),  # 等价写法, 击穿层数>0
            'addact.B.hit_pisBBO': is_addact_B() & (mi.act.Q >= mi.act.LQ) & (mi.act.D2 == 0),     # 主动单的Q >= 对方Q0, 且P == 对方P0
            'addact.B.hit_qBBO': is_addact_B() & (mi.act.Q == mi.act.LQ),                                   # 主动单的Q == 对方Q0, 也即刚好sweep一层
            'addact.B.hit_pqisBBO': is_addact_B() & (mi.act.Q == mi.act.LQ) & (mi.act.D2 == 0),    # 主动单的Q == 对方Q0, 且P == 对方P0

            'addact.B.hit_geq_lv1': is_addact_B() & (mi.act.LV >= mi.ut.C(1)),                 # 至少击穿1层
            'addact.B.hit_eq_lv1': is_addact_B() & (mi.act.LV == mi.ut.C(1)) & (mi.act.CL),    # 刚好击穿1层
            'addact.B.hit_geq_lv2': is_addact_B() & (mi.act.LV >= mi.ut.C(2)),                 # 至少击穿2层
            'addact.B.hit_eq_lv2': is_addact_B() & (mi.act.LV == mi.ut.C(2)) & (mi.act.CL),    # 刚好击穿2层
            'addact.B.hit_geq_lv3': is_addact_B() & (mi.act.LV >= mi.ut.C(3)),                 # 至少击穿3层
            'addact.B.hit_eq_lv3': is_addact_B() & (mi.act.LV == mi.ut.C(3)) & (mi.act.CL),    # 刚好击穿3层
            'addact.B.hit_eq_lv': is_addact_B() & (mi.act.CL),                                 # 刚好击穿xx层

            'addact.S.hit': is_addact_S() & (mi.act.Q >= mi.act.LQ),                                        # 主动单的Q >= 对方Q0, 作为一定击穿的判断条件
            # 'addact.S.hit': is_addact_S() & (mi.act.LV > 0),  # 等价写法, 击穿层数>0
            'addact.S.hit_pisBBO': is_addact_S() & (mi.act.Q >= mi.act.LQ) & (mi.act.D2 == 0),     # 主动单的Q >= 对方Q0, 且P == 对方P0
            'addact.S.hit_qBBO': is_addact_S() & (mi.act.Q == mi.act.LQ),                                   # 主动单的Q == 对方Q0, 也即刚好sweep一层
            'addact.S.hit_pqisBBO': is_addact_S() & (mi.act.Q == mi.act.LQ) & (mi.act.D2 == 0),    # 主动单的Q == 对方Q0, 且P == 对方P0

            'addact.S.hit_geq_lv1': is_addact_S() & (mi.act.LV >= mi.ut.C(1)),                 # 至少击穿1层
            'addact.S.hit_eq_lv1': is_addact_S() & (mi.act.LV == mi.ut.C(1)) & (mi.act.CL),    # 刚好击穿1层
            'addact.S.hit_geq_lv2': is_addact_S() & (mi.act.LV >= mi.ut.C(2)),                 # 至少击穿2层
            'addact.S.hit_eq_lv2': is_addact_S() & (mi.act.LV == mi.ut.C(2)) & (mi.act.CL),    # 刚好击穿2层
            'addact.S.hit_geq_lv3': is_addact_S() & (mi.act.LV >= mi.ut.C(3)),                 # 至少击穿3层
            'addact.S.hit_eq_lv3': is_addact_S() & (mi.act.LV == mi.ut.C(3)) & (mi.act.CL),    # 刚好击穿3层
            'addact.S.hit_eq_lv': is_addact_S() & (mi.act.CL),                                 # 刚好击穿xx层

        }, 
        p2 = get_pq_stats(), 
    )











    full_node = PQSumNode([
        add_cfg, 
    ], label="MyFilterMsg.act", 
        exe=PQSumNode.PQSUM_RELEASE_EXE
    )



    set_node_params(full_node)

    full_node.out = f"/data/bees3/unsafe/zuze/pqsum_py/pshared/MyFilterMsg/act/act.YYYYMMDD.sdiv"
    full_node.init_galpha()

    full_node.run(
        # single_date=20211231
    )


