### cxl类的Filter Msg: 即Base msg是cxl类, 用多种filter标准来筛选, 得到多种stats

import pqsum_py.msg_info as mi
from pqsum_py.runner import PQSumNode
from jobs.rnodes.rnode import RNode
from pattern_helper import *

from pathlib import Path
import argparse
import copy

from pqsum_py.utils import *

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='PQSumNode')
    parser.add_argument('--univ', type=str, required=True, help='universe', choices=["hs300", "zz500", "non800", "G2548"])
    args = parser.parse_args()

    RNode.RNODE_ROOT = "/data/bees3/unsafe/zuze/pqsum_py/rroot"
    RNode.GLOBAL_TASKNAME = f"{Path(__file__).stem}_{args.univ}"

    def set_node_params(node):
        node.startTime = "09:31:00"
        node.stopTime = "15:01:00"
        node.clockFreq = 60
        node.univ = args.univ

        node.slurm_enable = True
        node.slurm_cfg = {
            "slurm": True, 
            "slurmQueue": 'fqueue', 
            "slurmJobName": "MyFilterMsg.cxl",
            "slurmForceProgress": 1, "retries": 2,
            "omp_threads":10,
            "timeout":"01:00:00",
            # "slurmNfs": 'nas6:2', 
            # "slurmBatch": 5, 
            "smem": 5000,
        }

        # node.use_persid_md = False
        node.parallel_spec = '1'
        node.use_persid_md = False
        node.persid_threads = 10

        if node.univ == "G2548":
            node.univ = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
        if node.univ == "gp500":
            node.univ = "/data/beef3/zuze/Univ/gp500/gp500.csv"
        # node.univ = f"sids:1,1988"
        # node.univ = f"sids:1988"
        node.sdate = 20171001
        node.edate = 20240930


    def is_cxl_B():  # 撤销买单
        return mi.cxl.IsValid & mi.cxl.IsB  & mi.bk.InTrading
    def is_cxl_S():  # 撤销卖单
        return mi.cxl.IsValid & mi.cxl.IsS  & mi.bk.InTrading
    
    def get_pq_stats():
        return {
            'c': mi.ut.C(1),
            'q': mi.cxl.Q,
            'pq': mi.cxl.P * mi.cxl.Q,
            'D': - mi.cxl.D,            # 实际价格减去BBO价格, 加负号使得值为正
            'Dq': - mi.cxl.D * mi.cxl.Q, 
            'T': mi.cxl.T, 
        }

    def TransProb_glob():  # 全局成交概率, 即当前order在总队列中的排位, 值越大表示越靠前, 更容易成交
        return mi.ut.C(1) - (mi.cxl.TTQ + mi.cxl.QB) / mi.bk.BQTotalSnap

    def TransProb_inlv():  # 当前档位成交概率, 即当前order在该档位中的排位, 值越大表示越靠前, 更容易成交
        return mi.ut.C(1) - mi.cxl.QB / (mi.cxl.QB + mi.cxl.Q + mi.cxl.QA)
    
    def TransProb_mean():     # 两个成交概率的等权平均
        return (TransProb_glob() + TransProb_inlv()) / 2


    cxl_cfg = gen_pqsum_config(
        filters = {
            # 0. 全部cxl(分买卖方)
            'cxl.B.all': is_cxl_B(), 
            'cxl.S.all': is_cxl_S(), 

            # 1. 从众效应: 按 Follow/Reverse 当前盘口imba来划分, BQ>AQ时撤买单为Follow, BQ<=AQ时撤买单为Reverse
            'cxl.B.FolImba1': is_cxl_B() & (mi.bk.BQ(0) > mi.bk.AQ(0)),                               # 从众: 在BQ0 > AQ0时撤买单
            'cxl.B.FolImba1_lv012': is_cxl_B() & (mi.cxl.L <= 2)  & (mi.bk.BQ(0) > mi.bk.AQ(0)),      # 从众: 撤盘口3档
            'cxl.B.FolImba1_lv2p': is_cxl_B() & (mi.cxl.L > 2) & (mi.bk.BQ(0) > mi.bk.AQ(0)),         # 从众: 撤3档以外
            'cxl.B.RevImba1': is_cxl_B() & (mi.bk.BQ(0) <= mi.bk.AQ(0)),                              # 反向: 在BQ0 <= AQ0时撤买单
            'cxl.B.RevImba1_lv012': is_cxl_B() & (mi.cxl.L <= 2)  & (mi.bk.BQ(0) <= mi.bk.AQ(0)),     # 反向: 撤盘口3档
            'cxl.B.RevImba1_lv2p': is_cxl_B() & (mi.cxl.L > 2) & (mi.bk.BQ(0) <= mi.bk.AQ(0)),        # 反向: 撤3档以外
            'cxl.S.FolImba1': is_cxl_S() & (mi.bk.BQ(0) < mi.bk.AQ(0)),                               # 从众: 在BQ0 > AQ0时撤买单
            'cxl.S.FolImba1_lv012': is_cxl_S() & (mi.cxl.L <= 2)  & (mi.bk.BQ(0) < mi.bk.AQ(0)),      # 从众: 撤盘口3档
            'cxl.S.FolImba1_lv2p': is_cxl_S() & (mi.cxl.L > 2) & (mi.bk.BQ(0) < mi.bk.AQ(0)),         # 从众: 撤3档以外
            'cxl.S.RevImba1': is_cxl_S() & (mi.bk.BQ(0) >= mi.bk.AQ(0)),                              # 反向: 在BQ0 <= AQ0时撤买单
            'cxl.S.RevImba1_lv012': is_cxl_S() & (mi.cxl.L <= 2)  & (mi.bk.BQ(0) >= mi.bk.AQ(0)),     # 反向: 撤盘口3档
            'cxl.S.RevImba1_lv2p': is_cxl_S() & (mi.cxl.L > 2) & (mi.bk.BQ(0) >= mi.bk.AQ(0)),        # 反向: 撤3档以外

            # 2. 按撤单档位的厚薄(BQTotal / BLTotal的三倍/三分之一)为阈值来划分
            'cxl.B.lvlBig': is_cxl_B() & (mi.cxl.QB > mi.bk.BQTotalSnap / mi.bk.BLTotal() * 3), 
            'cxl.B.lvlMed': is_cxl_B() & (mi.cxl.QB >= mi.bk.BQTotalSnap / mi.bk.BLTotal() / 3) & (mi.cxl.QB <= mi.bk.BQTotalSnap / mi.bk.BLTotal() * 3), 
            'cxl.B.lvlSml': is_cxl_B() & (mi.cxl.QB < mi.bk.BQTotalSnap / mi.bk.BLTotal() / 3), 
            'cxl.S.lvlBig': is_cxl_S() & (mi.cxl.QB > mi.bk.AQTotalSnap / mi.bk.ALTotal() * 3), 
            'cxl.S.lvlMed': is_cxl_S() & (mi.cxl.QB >= mi.bk.AQTotalSnap / mi.bk.ALTotal() / 3) & (mi.cxl.QB <= mi.bk.AQTotalSnap / mi.bk.ALTotal() * 3), 
            'cxl.S.lvlSml': is_cxl_S() & (mi.cxl.QB < mi.bk.AQTotalSnap / mi.bk.ALTotal() / 3), 

            # 3. 提取Q=100的cxl
            'cxl.B.Q100': is_cxl_B() & (mi.cxl.Q == mi.ut.C(100)), 
            'cxl.S.Q100': is_cxl_S() & (mi.cxl.Q == mi.ut.C(100)), 

            # 4. 按撤单当时的预估成交概率来划分: 全局成交概率glob, 当前档位成交概率inlv, 加权成交概率mean
            'cxl.B.TransProbBig_glob': is_cxl_B() & (TransProb_glob() > 0.9), 
            'cxl.B.TransProbMed_glob': is_cxl_B() & (TransProb_glob() >= 0.5) & (TransProb_glob() <= 0.9), 
            'cxl.B.TransProbSml_glob': is_cxl_B() & (TransProb_glob() < 0.5), 
            'cxl.S.TransProbBig_glob': is_cxl_S() & (TransProb_glob() > 0.9), 
            'cxl.S.TransProbMed_glob': is_cxl_S() & (TransProb_glob() >= 0.5) & (TransProb_glob() <= 0.9), 
            'cxl.S.TransProbSml_glob': is_cxl_S() & (TransProb_glob() < 0.5), 
            'cxl.B.TransProbBig_inlv': is_cxl_B() & (TransProb_inlv() > 0.9), 
            'cxl.B.TransProbMed_inlv': is_cxl_B() & (TransProb_inlv() >= 0.5) & (TransProb_inlv() <= 0.9), 
            'cxl.B.TransProbSml_inlv': is_cxl_B() & (TransProb_inlv() < 0.5), 
            'cxl.S.TransProbBig_inlv': is_cxl_S() & (TransProb_inlv() > 0.9), 
            'cxl.S.TransProbMed_inlv': is_cxl_S() & (TransProb_inlv() >= 0.5) & (TransProb_inlv() <= 0.9), 
            'cxl.S.TransProbSml_inlv': is_cxl_S() & (TransProb_inlv() < 0.5), 
            'cxl.B.TransProbBig_mean': is_cxl_B() & (TransProb_mean() > 0.9), 
            'cxl.B.TransProbMed_mean': is_cxl_B() & (TransProb_mean() >= 0.5) & (TransProb_mean() <= 0.9), 
            'cxl.B.TransProbSml_mean': is_cxl_B() & (TransProb_mean() < 0.5), 
            'cxl.S.TransProbBig_mean': is_cxl_S() & (TransProb_mean() > 0.9), 
            'cxl.S.TransProbMed_mean': is_cxl_S() & (TransProb_mean() >= 0.5) & (TransProb_mean() <= 0.9), 
            'cxl.S.TransProbSml_mean': is_cxl_S() & (TransProb_mean() < 0.5), 

            # 5. 撤掉该lvl的相对大单(占该层比例>=50%)
            'cxl.B.RelBig_inlv': is_cxl_B() & (mi.cxl.Q >= mi.cxl.QB + mi.cxl.QA), 
            'cxl.S.RelBig_inlv': is_cxl_S() & (mi.cxl.Q >= mi.cxl.QB + mi.cxl.QA), 

            # 6. 按撤单等待时间分类: <1m/1-5m/5-30m/>30m
            'cxl.B.wait_lt_1m': is_cxl_B() & (mi.cxl.T < 60), 
            'cxl.B.wait_1_to_5m': is_cxl_B() & (mi.cxl.T >= 60) & (mi.cxl.T < 300), 
            'cxl.B.wait_5_to_30m': is_cxl_B() & (mi.cxl.T >= 300) & (mi.cxl.T < 1800), 
            'cxl.B.wait_gt_30m': is_cxl_B() & (mi.cxl.T >= 1800),
            'cxl.S.wait_lt_1m': is_cxl_S() & (mi.cxl.T < 60), 
            'cxl.S.wait_1_to_5m': is_cxl_S() & (mi.cxl.T >= 60) & (mi.cxl.T < 300), 
            'cxl.S.wait_5_to_30m': is_cxl_S() & (mi.cxl.T >= 300) & (mi.cxl.T < 1800), 
            'cxl.S.wait_gt_30m': is_cxl_S() & (mi.cxl.T >= 1800),  

            # 7. 按部分成交来划分: 撤掉的单没成交/成交小于50%/成交大于50%
            'cxl.B.PartTradeNot': is_cxl_B() & (mi.cxl.Q / mi.cxl.Orig_Q() == 1), # 没成交
            'cxl.B.PartTradeSml': is_cxl_B() & (mi.cxl.Q / mi.cxl.Orig_Q() > 0.5) & (mi.cxl.Q / mi.cxl.Orig_Q() < 1), # 成交量小于50%
            'cxl.B.PartTradeBig': is_cxl_B() & (mi.cxl.Q / mi.cxl.Orig_Q() <= 0.5), # 成交量大于等于50%
            'cxl.S.PartTradeNot': is_cxl_S() & (mi.cxl.Q / mi.cxl.Orig_Q() == 1), # 没成交
            'cxl.S.PartTradeSml': is_cxl_S() & (mi.cxl.Q / mi.cxl.Orig_Q() > 0.5) & (mi.cxl.Q / mi.cxl.Orig_Q() < 1), # 成交量小于50%
            'cxl.S.PartTradeBig': is_cxl_S() & (mi.cxl.Q / mi.cxl.Orig_Q() <= 0.5), # 成交量大于等于50%

            # 8. 按挂/撤的Lvl差值来划分
            'cxl.B.Lvl_gt_orig': is_cxl_B() & (mi.cxl.L >  mi.cxl.Orig_L()),  # 撤单的lvl大于origin add的lvl, 即更难成交了, 此时撤单是正常的
            'cxl.B.Lvl_eq_orig': is_cxl_B() & (mi.cxl.L == mi.cxl.Orig_L()),  # 撤单的lvl等于origin add的lvl
            'cxl.B.Lvl_lt_orig': is_cxl_B() & (mi.cxl.L <  mi.cxl.Orig_L()),  # 撤单的lvl小于origin add的lvl, 即更容易成交了, 此时撤单比较反常
            'cxl.S.Lvl_gt_orig': is_cxl_S() & (mi.cxl.L >  mi.cxl.Orig_L()),  # 撤单的lvl大于origin add的lvl, 即更难成交了, 此时撤单是正常的
            'cxl.S.Lvl_eq_orig': is_cxl_S() & (mi.cxl.L == mi.cxl.Orig_L()),  # 撤单的lvl等于origin add的lvl
            'cxl.S.Lvl_lt_orig': is_cxl_S() & (mi.cxl.L <  mi.cxl.Orig_L()),  # 撤单的lvl小于origin add的lvl, 即更容易成交了, 此时撤单比较反常

            # 9. 按挂/撤的D差值来划分
            'cxl.B.D_gt_orig': is_cxl_B() & (mi.cxl.D <  mi.cxl.Orig_D()),  # 撤单的D(的绝对值)大于origin add的D, 即更难成交了, 此时撤单是正常的
            'cxl.B.D_eq_orig': is_cxl_B() & (mi.cxl.D == mi.cxl.Orig_D()),  # 撤单的D(的绝对值)等于origin add的D
            'cxl.B.D_lt_orig': is_cxl_B() & (mi.cxl.D >  mi.cxl.Orig_D()),  # 撤单的D(的绝对值)小于origin add的D, 即更容易成交了, 此时撤单比较反常
            'cxl.S.D_gt_orig': is_cxl_S() & (mi.cxl.D <  mi.cxl.Orig_D()),  # 撤单的D(的绝对值)大于origin add的D, 即更难成交了, 此时撤单是正常的
            'cxl.S.D_eq_orig': is_cxl_S() & (mi.cxl.D == mi.cxl.Orig_D()),  # 撤单的D(的绝对值)等于origin add的D
            'cxl.S.D_lt_orig': is_cxl_S() & (mi.cxl.D >  mi.cxl.Orig_D()),  # 撤单的D(的绝对值)小于origin add的D, 即更容易成交了, 此时撤单比较反常
        }, 
        p2 = get_pq_stats(), 
    )

    full_node = PQSumNode([
        cxl_cfg, 
    ], label="MyFilterMsg.cxl", 
        exe=PQSumNode.PQSUM_RELEASE_EXE
    )

    set_node_params(full_node)

    full_node.out = f"/data/bees3/unsafe/zuze/pqsum_py/pshared/MyFilterMsg/cxl/cxl.YYYYMMDD.sdiv"
    full_node.init_galpha()

    full_node.run(
        # single_date=20211231
    )







