### add类的Filter Msg: 即Base msg是add类, 用多种filter标准来筛选, 得到多种stats

import pqsum_py.msg_info as mi
from pqsum_py.runner import PQSumNode
from jobs.rnodes.rnode import RNode
from pattern_helper import *

from pathlib import Path
import argparse
import copy

from pqsum_py.utils import *

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='PQSumNode')
    parser.add_argument('--univ', type=str, required=True, help='universe', choices=["hs300", "zz500", "non800", "G2548"])
    args = parser.parse_args()

    RNode.RNODE_ROOT = "/data/bees3/unsafe/zuze/pqsum_py/rroot"
    RNode.GLOBAL_TASKNAME = f"{Path(__file__).stem}_{args.univ}"

    def set_node_params(node):
        node.startTime = "09:31:00"
        node.stopTime = "15:01:00"
        node.clockFreq = 60
        node.univ = args.univ

        node.slurm_enable = True
        node.slurm_cfg = {
            "slurm": True, 
            "slurmQueue": 'fqueue', 
            "slurmJobName": "MyFilterMsg.add",
            "slurmForceProgress": 1, "retries": 2,
            "omp_threads":10,
            "timeout":"01:00:00",
            # "slurmNfs": 'nas6:2', 
            # "slurmBatch": 5, 
            "smem": 5000,
        }

        # node.use_persid_md = False
        node.parallel_spec = '1'
        node.use_persid_md = False
        node.persid_threads = 10

        if node.univ == "G2548":
            node.univ = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
        if node.univ == "gp500":
            node.univ = "/data/beef3/zuze/Univ/gp500/gp500.csv"
        # node.univ = f"sids:1,1988"
        # node.univ = f"sids:1988"
        node.sdate = 20171001
        node.edate = 20240930


    def is_addpas_B():  # 被动买单
        return mi.add.IsValid & mi.add.IsB  & mi.bk.InTrading
    def is_addpas_S():  # 被动卖单
        return mi.add.IsValid & mi.add.IsS  & mi.bk.InTrading

    def is_tail_0(price):  # price = mi.add.P for addpas; mi.act.P for addact
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(0)
    def is_tail_1(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(1)
    def is_tail_2(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(2)
    def is_tail_3(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(3)
    def is_tail_4(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(4)
    def is_tail_5(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(5)
    def is_tail_6(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(6)
    def is_tail_7(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(7)
    def is_tail_8(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(8)
    def is_tail_9(price):
        return mi.ut.Mod(mi.ut.Round(price * mi.ut.C(100)), 10) == mi.ut.C(9)


    def get_pq_stats():
        return {
            'c': mi.ut.C(1),
            'q': mi.add.Q,
            'pq': mi.add.P * mi.add.Q,
            'D': - mi.add.D,            # 实际价格减去BBO价格, 加负号使得值为正
            'Dq': - mi.add.D * mi.add.Q, 
        }



    add_cfg = gen_pqsum_config(
        filters={
            # 全部addpas: 被动add
            'addpas.B.all': is_addpas_B(), 
            'addpas.S.all': is_addpas_S(), 

            # 1. 按尾数划分: 尾数0-9
            'addpas.B.tail0': is_addpas_B() & is_tail_0(mi.add.P), 
            'addpas.B.tail1': is_addpas_B() & is_tail_1(mi.add.P), 
            'addpas.B.tail2': is_addpas_B() & is_tail_2(mi.add.P), 
            'addpas.B.tail3': is_addpas_B() & is_tail_3(mi.add.P), 
            'addpas.B.tail4': is_addpas_B() & is_tail_4(mi.add.P), 
            'addpas.B.tail5': is_addpas_B() & is_tail_5(mi.add.P), 
            'addpas.B.tail6': is_addpas_B() & is_tail_6(mi.add.P), 
            'addpas.B.tail7': is_addpas_B() & is_tail_7(mi.add.P), 
            'addpas.B.tail8': is_addpas_B() & is_tail_8(mi.add.P), 
            'addpas.B.tail9': is_addpas_B() & is_tail_9(mi.add.P), 
            'addpas.S.tail0': is_addpas_S() & is_tail_0(mi.add.P), 
            'addpas.S.tail1': is_addpas_S() & is_tail_1(mi.add.P), 
            'addpas.S.tail2': is_addpas_S() & is_tail_2(mi.add.P), 
            'addpas.S.tail3': is_addpas_S() & is_tail_3(mi.add.P), 
            'addpas.S.tail4': is_addpas_S() & is_tail_4(mi.add.P), 
            'addpas.S.tail5': is_addpas_S() & is_tail_5(mi.add.P), 
            'addpas.S.tail6': is_addpas_S() & is_tail_6(mi.add.P), 
            'addpas.S.tail7': is_addpas_S() & is_tail_7(mi.add.P), 
            'addpas.S.tail8': is_addpas_S() & is_tail_8(mi.add.P), 
            'addpas.S.tail9': is_addpas_S() & is_tail_9(mi.add.P), 


            # 2. 从众效应: 按Follow/Reverse 当前盘口imba来划分, BQ>AQ时挂买单为Follow, BQ<=AQ时挂买单为Reverse
            'addpas.B.FolImba1': is_addpas_B() & (mi.bk.BQ(0) > mi.bk.AQ(0)),                               # 从众: 在BQ0 > AQ0时挂被动买单
            'addpas.B.FolImba1_lv012': is_addpas_B() & (mi.add.L <= 2)  & (mi.bk.BQ(0) > mi.bk.AQ(0)),      # 从众: 挂盘口3档
            'addpas.B.FolImba1_lv2p': is_addpas_B() & (mi.add.L > 2) & (mi.bk.BQ(0) > mi.bk.AQ(0)),         # 从众: 挂3档以外
            'addpas.B.RevImba1': is_addpas_B() & (mi.bk.BQ(0) <= mi.bk.AQ(0)),                              # 反向: 在BQ0 <= AQ0时挂被动买单
            'addpas.B.RevImba1_lv012': is_addpas_B() & (mi.add.L <= 2)  & (mi.bk.BQ(0) <= mi.bk.AQ(0)),     # 反向: 挂盘口3档
            'addpas.B.RevImba1_lv2p': is_addpas_B() & (mi.add.L > 2) & (mi.bk.BQ(0) <= mi.bk.AQ(0)),        # 反向: 挂3档以外
            'addpas.S.FolImba1': is_addpas_S() & (mi.bk.BQ(0) < mi.bk.AQ(0)),                               # 从众: 在BQ0 > AQ0时挂被动买单
            'addpas.S.FolImba1_lv012': is_addpas_S() & (mi.add.L <= 2)  & (mi.bk.BQ(0) < mi.bk.AQ(0)),      # 从众: 挂盘口3档
            'addpas.S.FolImba1_lv2p': is_addpas_S() & (mi.add.L > 2) & (mi.bk.BQ(0) < mi.bk.AQ(0)),         # 从众: 挂3档以外
            'addpas.S.RevImba1': is_addpas_S() & (mi.bk.BQ(0) >= mi.bk.AQ(0)),                              # 反向: 在BQ0 <= AQ0时挂被动买单
            'addpas.S.RevImba1_lv012': is_addpas_S() & (mi.add.L <= 2)  & (mi.bk.BQ(0) >= mi.bk.AQ(0)),     # 反向: 挂盘口3档
            'addpas.S.RevImba1_lv2p': is_addpas_S() & (mi.add.L > 2) & (mi.bk.BQ(0) >= mi.bk.AQ(0)),        # 反向: 挂3档以外


            # 3. 按挂单档位的厚薄(BQTotal / BLTotal的三倍/三分之一)为阈值来划分
            'addpas.B.lvlBig': is_addpas_B() & (mi.add.QB > mi.bk.BQTotalSnap / mi.bk.BLTotal() * 3), 
            'addpas.B.lvlMed': is_addpas_B() & (mi.add.QB >= mi.bk.BQTotalSnap / mi.bk.BLTotal() / 3) & (mi.add.QB <= mi.bk.BQTotalSnap / mi.bk.BLTotal() * 3), 
            'addpas.B.lvlSml': is_addpas_B() & (mi.add.QB < mi.bk.BQTotalSnap / mi.bk.BLTotal() / 3), 
            'addpas.S.lvlBig': is_addpas_S() & (mi.add.QB > mi.bk.AQTotalSnap / mi.bk.ALTotal() * 3), 
            'addpas.S.lvlMed': is_addpas_S() & (mi.add.QB >= mi.bk.AQTotalSnap / mi.bk.ALTotal() / 3) & (mi.add.QB <= mi.bk.AQTotalSnap / mi.bk.ALTotal() * 3), 
            'addpas.S.lvlSml': is_addpas_S() & (mi.add.QB < mi.bk.AQTotalSnap / mi.bk.ALTotal() / 3), 

            # 4. 提取Q=100的add
            'addpas.B.Q100': is_addpas_B() & (mi.add.Q == mi.ut.C(100)), 
            'addpas.S.Q100': is_addpas_S() & (mi.add.Q == mi.ut.C(100)), 

            # 5. 按挂单档位离BBO的远近(用成交概率来刻画), 离盘口越近, 值越小
            'addpas.B.TransProbBig': is_addpas_B() & ((mi.add.TTQB + mi.add.QB) / mi.bk.BQTotalSnap < 0.1), 
            'addpas.B.TransProbMed': is_addpas_B() & ((mi.add.TTQB + mi.add.QB) / mi.bk.BQTotalSnap >= 0.1) & (mi.add.TTQB / mi.bk.BQTotalSnap <= 0.5), 
            'addpas.B.TransProbSml': is_addpas_B() & ((mi.add.TTQB + mi.add.QB) / mi.bk.BQTotalSnap > 0.5), 
            'addpas.S.TransProbBig': is_addpas_S() & ((mi.add.TTQB + mi.add.QB) / mi.bk.AQTotalSnap < 0.1), 
            'addpas.S.TransProbMed': is_addpas_S() & ((mi.add.TTQB + mi.add.QB) / mi.bk.AQTotalSnap >= 0.1) & (mi.add.TTQB / mi.bk.AQTotalSnap <= 0.5), 
            'addpas.S.TransProbSml': is_addpas_S() & ((mi.add.TTQB + mi.add.QB) / mi.bk.AQTotalSnap > 0.5), 


        }, 
        p2 = get_pq_stats(), 
    )

    full_node = PQSumNode([
        add_cfg, 
    ], label="MyFilterMsg.add", 
        exe=PQSumNode.PQSUM_RELEASE_EXE
    )

    set_node_params(full_node)

    full_node.out = f"/data/bees3/unsafe/zuze/pqsum_py/pshared/MyFilterMsg/add/add.YYYYMMDD.sdiv"
    full_node.init_galpha()

    full_node.run(
        # single_date=20211231
    )


