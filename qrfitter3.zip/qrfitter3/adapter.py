def fitter_adapter(config):
    from qrfitter3.mlfitter import learner as ml_learner_module
    from qrfitter3.nnfitter.run import run_fit_task as run_fit_nn_task
    from qrfitter3.mlfitter.run import run_fit_task as run_fit_ml_task
    fitter_config = config['fitter']
    if getattr(ml_learner_module, fitter_config["class"], None) is None:
        return run_fit_nn_task  # nn fitter has a more flexible way to define learner
    else:
        return run_fit_ml_task
    

def inference_adapter(config):
    from qrfitter3.mlfitter import learner as ml_learner_module
    from qrfitter3.nnfitter.run import run_inference_task as run_inference_nn_task
    from qrfitter3.mlfitter.run import run_inference_task as run_inference_ml_task
    fitter_config = config['fitter']
    if getattr(ml_learner_module, fitter_config["class"], None) is None:
        return run_inference_nn_task  # nn fitter has a more flexible way to define learner
    else:
        return run_inference_ml_task