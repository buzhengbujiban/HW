import argparse
from qrfitter3.utils import read_json
from qrfitter3.adapter import fitter_adapter


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("config_path")
    args = parser.parse_args()
    config = read_json(args.config_path)
    run_fit_task = fitter_adapter(config)
    run_fit_task(config)