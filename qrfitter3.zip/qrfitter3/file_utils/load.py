import os
import gc
import json
import logging
from typing import Tuple, List, Dict, Optional
import SharedArray as sa
import numpy as np
import traceback
import getpass
import time

from nnfitter.utils import get_logger, level_dict
logger = get_logger(name='shm_load')

from .provider import BlockProvider


def get_shm_key():
    usr = getpass.getuser()
    key = f"shm://{usr}.qrfitter.{time.time()}"
    if "SLURM_JOB_ID" in os.environ:
        usr = os.environ["SLURM_JOB_USER"]
        jid = os.environ["SLURM_JOB_ID"]
        key = f"shm://{usr}.qrfitter.{jid}"
    return key

def get_shm_key_ds(ds: List[BlockProvider]):
    dates = [d.date for d in ds]
    date_start, date_end = min(dates), max(dates)
    dirname, filename = ds[0].dirname, ds[0].filename
    usr = getpass.getuser()
    #key = f"shm://{usr}.{os.path.join(dirname, f'{date_start}-{date_end}', filename)}"
    file_key = os.path.join(dirname, f'{date_start}-{date_end}', filename).replace("/", ".")
    key = f"shm://{usr}.{file_key}"
    return key

def _load_one_feature_file_as_array_wrapper(d: BlockProvider, x, xstart, shm_key):
    share_arr_t = sa.attach(shm_key)
    share_arr = share_arr_t.T
    feature_array, _, isOK = d.load() 
    if isOK:
        assert x == feature_array.shape[0], f"date={d.date} rows mismatch. expected={x} got={feature_array.shape[0]}"
        share_arr[xstart:(xstart+x), :] = feature_array
    else:  # do nothing
        pass

    del feature_array
    del share_arr_t
    del share_arr

    gc.collect()
    return isOK

def load_block(ds: List[BlockProvider], threads=16, delete=True, verbose=1) -> Tuple[np.ndarray, List[str], str|None]:
    global logger
    logger.setLevel(level_dict[verbose])

    'load feature files for a given list'
    if len(ds) == 1:
        output_array, feature_names, _ = ds[0].load()
        return output_array, feature_names, None
    logger.debug(f'IO threads {threads},  share memory version!')

    shm_key = get_shm_key_ds(ds)

    # return array if it is already in share memory
    try :
        output_array = sa.attach(shm_key).T  # UserWarning: PyTorch does not support non-writable tensors   # TODO: test transpose
        feature_names = ds[0].get_columns()
    except FileNotFoundError:
        logger.debug(f"share memory does not exist: {shm_key}")
    else:
        logger.info(f"share memory already exists: {shm_key}")
        return output_array, feature_names, shm_key
        
    # first read all shapes and prepare parameters
    params_list, row_len, col_len = prepare_param(ds, shm_key)

    # create ShareArray
    dtype = ds[0].get_dtype()
    itemsize = 8 if dtype==np.float64 else 4
    logger.debug(f"create share momery: {shm_key}, size={col_len*row_len*itemsize/1024/1024:.1f}M")
    share_arr_t = sa.create(shm_key, (col_len, row_len), dtype=dtype)
    logger.debug(f"create share momery: done.")
    exp = None
    try:
        feature_names, ret_array = do_load(ds, threads, params_list, row_len, share_arr_t)
    except Exception as e:
        logger.error(f"found an exception {e}", flush=True)
        logger.error(traceback.format_exc(), flush=True)
        sa.delete(shm_key)
        shm_key = None
        exp = e
    finally:
        if delete:
            logger.debug(f"clear share memory: {shm_key}", flush=True)
            sa.delete(shm_key)
            shm_key = None
        else:
            logger.info(f"share memory not deleted yet: {shm_key}, PLEASE REMEMBER TO DELETE LATER")
    if exp is not None:
        raise exp
    return ret_array, feature_names, shm_key

def prepare_param(ds: List[BlockProvider], shm_key):
    params_list = []
    row_len = 0
    col_len = 0
    logger.debug("preparing param...")
    for d in ds:
        x, y = d.get_shape() # pytbl.get_shape(fn)
        params_list.append((d, x, row_len, shm_key))
        if col_len == 0:
            col_len = y
        elif y != col_len:
            raise Exception("{} has different number of columns {} than {}".format(d.date, y, col_len))
        row_len += x
    return params_list, row_len, col_len

def do_load(ds, threads, params_list, row_len, share_arr_t):
    logger.debug(f"loading datasets size={len(ds)} threads={threads} row_len={row_len}")
    from multiprocessing import Pool
    share_arr = share_arr_t.T
    pool = Pool(processes=min(threads, len(ds)))
    isOk_list = pool.starmap(_load_one_feature_file_as_array_wrapper, params_list)
    logger.debug("return Pool results.")
    # load the first file again, just to get the feature names
    feature_names = ds[0].get_columns() # pytbl.get_columns(params_list[0][0])
    all_sampling_index = np.zeros(row_len, dtype=np.int64)
    index_cursor = 0
    for i, isOk in enumerate(isOk_list):
        if isOk:
            start_idx = params_list[i][2]
            end_idx = start_idx + params_list[i][1]
            for id in range(start_idx, end_idx):
                all_sampling_index[index_cursor] = id
                index_cursor += 1

    if index_cursor != row_len:
        ret_array = share_arr[all_sampling_index[:index_cursor]]
    else:
        ret_array = share_arr
    logger.debug("last step to reframe data.")
    del share_arr_t
    del share_arr

    del all_sampling_index
    del isOk_list
    logger.debug("finish del array, start pool.close and gc.collect")
    pool.close()
    gc.collect()
    logger.debug(f"loading datasets DONE. size={len(ds)} threads={threads} row_len={row_len}")
    return feature_names,ret_array