import typing
import xarray as xr
import pytbl
import os
import numpy as np
import qr
import pandas as pd
import re
import functools
import h5py

quiet = False


def block_quiet(b=None) -> bool:
    global quiet
    if b is not None:
        quiet = b
    return quiet

def filesize(f):
    return os.stat(f).st_size

def dates_from(file_name, date_start=None, date_end=None):
    def date_ok(datestr):
        fn = file_name.replace("YYYYMMDD", "{date}").format(date=datestr)
        return os.access(fn, os.F_OK) and (filesize(fn) > 2000)

    if (date_start is None) and (date_end is None):
        # assume is {dirname}/date/{filename} patterm
        date_pattern = re.compile(r"\d{8}")
        dirname = os.path.dirname(os.path.dirname(file_name))
        date_list = filter(date_pattern.search, os.listdir(dirname))
        date_list = [d for d in date_list if len(d) == 8]
        date_list.sort()
    else:
        date_list = qr.bd.get_range(date_start, date_end)
    return [d for d in date_list if date_ok(d)]


def load_one_feature_file_as_array(file_name, columns_need=None):
    "load one feature file"
    # if not block_quiet():
    #     print("loading as np array {}".format(file_name), flush=True)
    if file_name.endswith(".tbl"):
        df = qr.tbl_read(file_name)
    elif file_name.endswith(".tbl2"):
        df = qr.tbl2_read(file_name)
    elif (file_name.endswith(".sdiv")) or (file_name.endswith(".sdiv2")):
        df = (
            qr.sdiv_read(file_name)
            if file_name.endswith(".sdiv")
            else qr.sdiv2_read(file_name)
        )
        df.coords["S"] = df.S.astype(int)
        df = qr.panel.sdiv2df(df)
        df["rec_epoch"] = df["date"] + " " + df["time"]
        df["rec_epoch"] = list(map(qr.str_to_epoch, df["rec_epoch"]))
        df["date"] = df["date"].astype(int)
    else:
        raise NotImplementedError(f"{file_name} type file not defined.")
    if df is None:
        print("array is empty")
        return None, None, False
    if columns_need is not None:
        cols = [x for x in df.columns if x in columns_need]
        df = df[cols]
    feature_names = list(df.columns)
    feature_array = df.values
    return feature_array, feature_names, True


def get_column_sdiv(fn):
    Vs = qr.sdiv_coords(fn, dim="V")
    return list(
        np.union1d(Vs, ["sid", "rec_epoch", "date"])
    )  # value potential have sid, rec_epoch, date


def get_columns(fn):
    if fn.endswith(".sdiv"):
        return get_column_sdiv(fn)
    return pytbl.get_columns(fn)


def get_shape_sdiv(fn):
    SDI = [len(qr.sdiv_coords(fn, dim=d)) for d in ["S", "D", "I"]]
    Vs = len(get_column_sdiv(fn))
    return (functools.reduce(lambda x, y: x * y, SDI), Vs)


def get_shape(fn):
    if fn.endswith(".sdiv"):
        return get_shape_sdiv(fn)
    return get_shape_tbl(fn)


def get_shape_tbl(fn):
    try:
        r = pytbl.get_shape(fn)
    except OSError as err:
        print("File: {} Error: {}".format(fn, err))
        raise
    except Exception as e:
        print("File: {} Exception {}".format(fn, e))
        raise
    return r

def get_dtype_tbl(fn):
    with h5py.File(fn, 'r') as file:
        if pytbl.DATASET_F64 in file:
            return np.float64
        return np.float32
    
def get_dtype(fn):
    if fn.endswith(".sdiv"):
        return np.float64  # TODO: get_dtype_sdiv
    return get_dtype_tbl(fn)


class BlockProvider(object):
    def __init__(self, date):
        self.date = date

    def get_shape(self):
        """should not load entire data"""
        pass

    def get_columns(self) -> typing.List[str]:
        """should not load entire data"""
        pass

    def load(self):
        """return (feature array, feature names, and succeed flag)"""
        pass


class SingleFile(BlockProvider):
    def __init__(
        self,
        date,
        dirname,
        filename,
        columns_need=None,
        filepattern="{dirname}/{date}/{filename}",
    ):
        super().__init__(date)
        self.dirname = dirname
        self.filename = filename
        self.fn = filepattern.format(
            dirname=self.dirname, date=date, filename=self.filename
        )
        self.columns_need = columns_need
        self.cm = None

    @classmethod
    def from_dict(clz, date, cfg):
        return clz(
            date,
            cfg["dirname"],
            cfg["filename"],
            cfg.get("columns_need"),
            cfg.get("filepattern", "{dirname}/{date}/{filename}"),
        )

    def get_shape(self):
        dshape = get_shape(self.fn)
        return (dshape[0], len(self.get_columns()))

    def get_columns(self):
        if self.cm is None:
            cm = get_columns(self.fn)
            if self.columns_need is not None:
                cm = [x for x in cm if x in self.columns_need]
            self.cm = cm
        return self.cm

    def get_dtype(self):
        return get_dtype(self.fn)

    def load(self):
        return load_one_feature_file_as_array(self.fn, columns_need=self.columns_need)


"""provide data from multiple tbl files. """


class MultiFileVCat(BlockProvider):
    # intersect columns from all data
    def __init__(self, date, dirnames, filenames, columns_need=None, filepattern=None):
        assert len(dirnames) == len(
            filenames
        ), "dirnames and filenames must have same length"
        if filepattern is None:
            filepattern = ["{dirname}/{date}/{filename}" for _ in filenames]
        else:
            assert len(filepattern) == len(
                filenames
            ), "filepattern and filenames must have same length"
        super().__init__(date)
        self.tbls = [
            SingleFile(
                date=date,
                dirname=dirname,
                filename=filename,
                columns_need=columns_need,
                filepattern=fp,
            )
            for dirname, filename, fp in zip(dirnames, filenames, filepattern)
        ]
        self.cm = None

    @classmethod
    def from_dict(clz, date, cfg):
        return clz(date, cfg["dirnames"], cfg["filenames"], cfg.get("columns_need"))

    def get_columns(self):
        if self.cm is None:
            columns = [d.get_columns() for d in self.tbls]
            cm = set.intersection(*map(set, columns))
            self.cm = sorted(cm)
        return self.cm

    def get_shape(self):
        shapes = [d.get_shape() for d in self.tbls]
        # shape is [n_rows, n_columns]
        # TODO: potentially crash if tbl file has 0 rows - need to revise pytbl implementation
        return (sum(shape[0] for shape in shapes), len(self.get_columns()))

    def load(self):
        alldata = [d.load() for d in self.tbls]
        # here we assume _load_one_feature_file_as_array returns (feature_array, feature_names, read_ok)

        # doing this means we need to read files again, but feature_names returned from _load_one_feature_file_as_array
        # could be empty, making it unstable and thus unusable.
        columns = self.get_columns()
        # arrays = [array[:, [features.index(x) for x in columns]] for array, features, ok in alldata if ok]
        arrays = []
        for array, features, ok in alldata:
            if not ok or len(features) == 0:
                continue
            cols = [features.index(x) for x in columns]
            arrays.append(array[:, cols])
        if len(arrays) == 0:
            return None, None, False
        # TODO(john): sort by epoch, sid?
        return np.concatenate(arrays), columns, True


"""provide data from multiple tbl files by hcat (left join)."""


class MultiFileHCat(BlockProvider):
    def __init__(
        self,
        date,
        dirnames,
        filenames,
        x_names,
        on=["sid", "rec_epoch"],
        tol=1.0,
        columns_pattern_exclude=None,
        columns_need=None,
        filepattern=None,
    ):
        assert len(dirnames) == len(
            filenames
        ), "dirnames and filenames must have same length"
        if filepattern is None:
            filepattern = ["{dirname}/{date}/{filename}" for _ in filenames]
        else:
            assert len(filepattern) == len(
                filenames
            ), "filepattern and filenames must have same length"
        super().__init__(date)
        self.tbls = [
            SingleFile(
                date=date,
                dirname=dirname,
                filename=filename,
                columns_need=columns_need,
                filepattern=fp,
            )
            for dirname, filename, fp in zip(dirnames, filenames, filepattern)
        ]
        self.x_names = x_names  # columns pattern
        self.x_names_excludes = (
            columns_pattern_exclude
            if columns_pattern_exclude is not None
            else [None for _ in x_names]
        )
        self.df_cols = None
        self.on = on
        self.rdf = None
        self.tol = tol
        self.cm = None

    @classmethod
    def from_dict(clz, date, cfg):
        return clz(
            date,
            cfg["dirnames"],
            cfg["filenames"],
            cfg["x_names"],
            on=cfg.get("on", ["sid", "rec_epoch"]),
            tol=cfg.get("tol", 1.0),
            columns_need=cfg.get("columns_need"),
        )

    def get_columns(self):
        if self.cm is None:
            columns = [pd.Series(d.get_columns()) for d in self.tbls]
            self.df_cols = []
            self.cm = []
            for i, col in enumerate(columns):
                if self.x_names[i]:
                    n = col[col.str.contains(self.x_names[i])].tolist()
                    assert (
                        len(n) > 0
                    ), f"no columns for pattern={self.x_names[i]}: {col.values}"
                else:
                    n = col.tolist()
                if self.x_names_excludes[i]:
                    if isinstance(self.x_names_excludes[i], str):
                        n = [x for x in n if self.x_names_excludes[i] not in x]
                    else:
                        assert isinstance(self.x_names_excludes[i], list)
                        n = [
                            x
                            for x in n
                            if all([exc not in x for exc in self.x_names_excludes[i]])
                        ]
                    assert (
                        len(n) > 0
                    ), f"no columns after exclude pattern={self.x_names_excludes[i]}"
                for ion in self.on:
                    assert (
                        col == ion
                    ).any(), f"{ion} not in columns {col} from {self.tbls[i].fn}"
                    if ion not in n:
                        n = [ion] + n
                self.df_cols.append(n)
                for name in n:
                    assert (name in self.on) or (
                        name not in self.cm
                    ), f"{name} dup in {i}-th data."
                    if name not in self.cm:
                        self.cm.append(name)
        return self.cm

    def get_shape(self):
        first_shape = self.tbls[0].get_shape()
        columns = self.get_columns()
        return (first_shape[0], len(columns))

    def _load(self):
        if self.rdf is not None:
            return self.rdf
        self.get_columns()
        alldata = [d.load() for d in self.tbls]
        rdf = None
        for i, (array, features, ok) in enumerate(alldata):
            if not ok or len(features) == 0:
                continue
            x_vars_columns = [features.index(x_name) for x_name in self.df_cols[i]]
            subdf = pd.DataFrame(array[:, x_vars_columns], columns=self.df_cols[i])
            subdf = subdf.drop_duplicates(subset=self.on, keep="last")
            if rdf is None:
                rdf = subdf
                continue
            arows = rdf.shape[0]
            if arows == 0:
                continue
            # rdf = pd.merge(rdf, subdf, on=self.on, how="inner")
            rdf = pd.merge(rdf, subdf, on=self.on, how="left")
            # check merge ratio
            subdf_cols = [i for i in subdf.columns if i not in self.on]
            if len(subdf_cols) > 0:
                subdf_col = subdf_cols[0]
                valid_rows = rdf[subdf_col].notna().sum()
                ratio = valid_rows * 1.0 / (1.0 * arows)
                print(f"ratio for date={self.date} i={i} is {ratio}")
                assert (
                    ratio >= self.tol
                ), f"merging dropped more rows than tol={self.tol}, ratio={ratio}, col={subdf_col} valid_rows={valid_rows}"
        assert (
            rdf.shape == self.get_shape()
        ), f"date={self.date} df.shape={rdf.shape} get_shape={self.get_shape()}"
        self.rdf = rdf

    def load(self):
        self._load()
        if self.rdf is None:
            return None, None, False
        feature_names = list(self.rdf.columns)
        feature_array = self.rdf.values
        return feature_array, feature_names, True


class BlockFactory(object):
    def __init__(self):
        self.map = {}
        self.add("single", SingleFile)
        self.add("vcat", MultiFileVCat)
        self.add("hcat", MultiFileHCat)

    def add(self, key, clazz):
        assert key not in self.map, "ERROR: dup detected for {} {}".format(
            key, self.map[key]
        )
        assert hasattr(
            clazz, "from_dict"
        ), f"{clazz} does not have classmethod `from_dict` defined"
        self.map[key] = clazz

    def create(self, key, date, cfg):
        return self.map[key].from_dict(date, cfg)

    def supported(self):
        return self.map.keys()

    def is_support(self, key):
        return key in self.map


g_block_factory = BlockFactory()


def block_factory():
    global g_block_factory
    return g_block_factory
