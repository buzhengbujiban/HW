import os
from qrfitter3.utils import get_months_between_dates, get_run_periods

def fix_start_month(start_month, end_month, max_months):
    if max_months <= 0:
        return start_month
    
    assert isinstance(start_month, str) and len(start_month) == 6, 'wrong format for start_month: %s' % start_month
    months = get_months_between_dates(start_month+'01', end_month+'31')
    if len(months) <= max_months:
        return start_month
    else:
        return months[-(max_months)]
    

class Roller:
    def __init__(
        self, config
        # start_date, end_date,
        # test_start_month, test_window, valid_window, 
        # reverse_valid=False, gen_next_month=False, max_train_months=-1  # len(train+valid)<=max_train_months
    ):
        roll_type = config.get('roll_type', 'vanilla')
        if roll_type == 'vanilla':
            self.set_vanilla_rolling(config)
        elif roll_type == "croll":
            self.set_croll_rolling(config)
        elif roll_type == "croll_pro":
            self.set_croll_pro_rolling(config)
        else:
            raise ValueError(f'Roll type {roll_type} not supported')
        self.add_date()

    def set_croll_pro_rolling(self, config):
        
        start_date = config['start_date']
        end_date = config['end_date']
        test_start_month = config['test_start_month']
        valid_window = config.get('valid_window')
        croll_folds = config['croll_folds']
        months = get_months_between_dates(start_date, end_date)

        train_ranges = []
        test_ranges = []
        valid_ranges = []
        fold_names = []

        if test_start_month <= months[-1]:
            start_idx = months.index(test_start_month)  # throws ex if not present
        else:
            start_idx = len(months)
        croll_months = months[:start_idx]
        all_start, all_end = croll_months[0], croll_months[-1]
        CAv24Path = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels"
        Y = os.path.join(CAv24Path, "Y/Y_V5/terms.YYYYMMDD.sdiv")
        all_dates = get_run_periods(Y, f"{all_start}01", f"{all_end}31")  # TODO: 使用每日更新的pattern file

        test_len = len(croll_months) // croll_folds
        for i in range(croll_folds):
            if i == croll_folds-1:
                te_start, te_end = croll_months[i*test_len], croll_months[-1]
            else:
                te_start, te_end = croll_months[i*test_len], croll_months[(i+1)*test_len-1]
            va_start, va_end = croll_months[i*test_len-valid_window], croll_months[i*test_len-1]
            print(i, va_start, va_end, te_start, te_end)
            te_dates = get_run_periods(Y, f"{te_start}01", f"{te_end}31")
            va_dates = get_run_periods(Y, f"{va_start}01", f"{va_end}31")
            tr_dates = [d for d in all_dates if d not in te_dates+va_dates]
            train_ranges.append(tr_dates)
            valid_ranges.append((va_start, va_end))
            test_ranges.append((te_start, te_end))
            fold_names.append('tr:%s-%s;va:%s-%s;te:%s-%s' % ("na", "na", va_start, va_end, te_start, te_end))
        self.train_ranges = train_ranges
        self.valid_ranges = valid_ranges
        self.test_ranges = test_ranges
        self.fold_names = fold_names

    def set_croll_rolling(self, config):
        start_date = config['start_date']
        end_date = config['end_date']
        test_start_month = config['test_start_month']
        # croll_folds = config['croll_folds']
        croll_folds = 4
        # TODO: croll_folds has to be 3 or 4. Because now range is continuous [start, end]

        months = get_months_between_dates(start_date, end_date)
        # print(months)

        train_ranges = []
        test_ranges = []
        valid_ranges = []
        fold_names = []

        if test_start_month <= months[-1]:
            start_idx = months.index(test_start_month)  # throws ex if not present
        else:
            start_idx = len(months)
        croll_months = months[:start_idx]
        def split_list_indices(k, m):
            target_len = len(k) // m
            remainder = len(k) % m
            sub_list_indices = []
            start = 0
            for i in range(m):
                end = start + target_len + (1 if i < remainder else 0)
                sub_list_indices.append((start, end))
                start = end
            return sub_list_indices

        idxes = split_list_indices(croll_months, croll_folds)

        tr_start, tr_end = months[idxes[0][0]], months[idxes[1][1]-1]
        va_start, va_end = months[idxes[3][0]], months[idxes[3][1]-1]
        te_start, te_end = months[idxes[2][0]], months[idxes[2][1]-1]
        train_ranges.append((tr_start, tr_end))
        valid_ranges.append((va_start, va_end))
        test_ranges.append((te_start, te_end))
        fold_names.append('tr:%s-%s;va:%s-%s;te:%s-%s' % (tr_start, tr_end, va_start, va_end, te_start, te_end))

        tr_start, tr_end = months[idxes[1][0]], months[idxes[2][1]-1]
        va_start, va_end = months[idxes[0][0]], months[idxes[0][1]-1]
        te_start, te_end = months[idxes[3][0]], months[idxes[3][1]-1]
        train_ranges.append((tr_start, tr_end))
        valid_ranges.append((va_start, va_end))
        test_ranges.append((te_start, te_end))
        fold_names.append('tr:%s-%s;va:%s-%s;te:%s-%s' % (tr_start, tr_end, va_start, va_end, te_start, te_end))

        tr_start, tr_end = months[idxes[1][0]], months[idxes[2][1]-1]
        va_start, va_end = months[idxes[3][0]], months[idxes[3][1]-1]
        te_start, te_end = months[idxes[0][0]], months[idxes[0][1]-1]
        train_ranges.append((tr_start, tr_end))
        valid_ranges.append((va_start, va_end))
        test_ranges.append((te_start, te_end))
        fold_names.append('tr:%s-%s;va:%s-%s;te:%s-%s' % (tr_start, tr_end, va_start, va_end, te_start, te_end))

        tr_start, tr_end = months[idxes[2][0]], months[idxes[3][1]-1]
        va_start, va_end = months[idxes[0][0]], months[idxes[0][1]-1]
        te_start, te_end = months[idxes[1][0]], months[idxes[1][1]-1]
        train_ranges.append((tr_start, tr_end))
        valid_ranges.append((va_start, va_end))
        test_ranges.append((te_start, te_end))
        fold_names.append('tr:%s-%s;va:%s-%s;te:%s-%s' % (tr_start, tr_end, va_start, va_end, te_start, te_end))

        self.train_ranges = train_ranges
        self.valid_ranges = valid_ranges
        self.test_ranges = test_ranges
        self.fold_names = fold_names
        # print(self.fold_names)

    def set_vanilla_rolling(self, config):
        start_date = config.get('start_date')
        end_date = config.get('end_date')
        test_start_month = config.get('test_start_month')
        test_window = config.get('test_window')
        valid_window = config.get('valid_window')
        gen_next_month = config.get('gen_next_month', False)
        reverse_valid = config.get('reverse_valid', False)
        max_train_months = config.get('max_train_months', -1)

        months = get_months_between_dates(start_date, end_date)
        # print(months)
        if test_start_month <= months[-1]:
            start_idx = months.index(test_start_month)  # throws ex if not present
        else:
            start_idx = len(months)

        train_ranges = []
        test_ranges = []
        valid_ranges = []
        fold_names = []

        while start_idx < len(months):  # start_idx is the index of test_start_month
            if reverse_valid:  # valid set before train
                va_start = months[0]
                tr_end = months[start_idx - 1]
                va_start = fix_start_month(va_start, tr_end, max_train_months)  # len(train+valid)<=max_train_months
                va_start_idx = months.index(va_start)
                va_end = months[va_start_idx + valid_window - 1]
                tr_start = months[va_start_idx + valid_window]
            else:
                tr_start = months[0]
                va_end = months[start_idx - 1]
                tr_start = fix_start_month(tr_start, va_end, max_train_months)  # len(train+valid)<=max_train_months
                va_start = months[start_idx - valid_window]
                tr_end = months[start_idx - valid_window - 1]
                
            te_start = months[start_idx]
            te_end = months[min(start_idx + test_window - 1, len(months) - 1)]
            
            train_ranges.append((tr_start, tr_end))
            valid_ranges.append((va_start, va_end))
            test_ranges.append((te_start, te_end))
            fold_names.append('tr:%s-%s;va:%s-%s;te:%s-%s' % (tr_start, tr_end, va_start, va_end, te_start, te_end))

            start_idx += test_window

        if gen_next_month:
            tr_start = months[0]
            va_end = months[len(months) - 1]
            tr_start = fix_start_month(tr_start, va_end, max_train_months)
            va_start = months[len(months) - valid_window]
            tr_end = months[len(months) - valid_window - 1]
            train_ranges.append((tr_start, tr_end))
            valid_ranges.append((va_start, va_end))
            test_ranges.append(None)
            fold_names.append('tr:%s-%s;va:%s-%s;te:empty' % (tr_start, tr_end, va_start, va_end))

        self.train_ranges = train_ranges
        self.valid_ranges = valid_ranges
        self.test_ranges = test_ranges
        self.fold_names = fold_names

    def add_date(self):
        all_ranges = [self.train_ranges, self.valid_ranges, self.test_ranges]
        for ranges in all_ranges:
            for i, r in enumerate(ranges):
                if isinstance(r, tuple):
                    start, end = r
                    start, end = f"{start}01", f"{end}31"
                    ranges[i] = (start, end)

    def iter(self, start: int=None, end: int=None):
        start = 0 if start is None else start
        end = len(self.train_ranges) if end is None else end
        end = min(len(self.train_ranges), end)
        # print(start, end, self.train_ranges)
        for i in range(start, end):
            yield i, self.fold_names[i], self.train_ranges[i], self.valid_ranges[i], self.test_ranges[i]

# for i in Roller({
#         "roll_type":"croll",
#         # "roll_type":"vanilla",
#         "start_date":        "20200102",
#         "end_date":          "20231231",
#         "test_start_month":  "202301",
#         "test_window":       4,
#         "valid_window":      2,
#         "croll_folds":       4,
#         "gen_next_month":    True,
#         "reverse_valid":    True,
#         "max_train_months":  18
#     }).iter():
#     print(i)