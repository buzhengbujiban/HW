import numpy as np
import pandas as pd
import collections
import torch
import torch.nn as nn
from torch.optim import lr_scheduler
import torch.nn.functional as F
from torch.nn.modules.loss import MSELoss
# from torchmetrics.regression import MeanAbsolutePercentageError
import warnings
warnings.filterwarnings("ignore", category=UserWarning)


def setup_seed(seed=3407):
    np.random.seed(seed) #1
    torch.manual_seed(seed) #2 
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic=True #only applies to CUDA convolution operations, 会让dialation慢百倍！！！ 但是可能减少很多内存


class Recorder:
    """record data from each step"""

    def __init__(self):
        self.from_epoch = dict()
        self.from_step = collections.defaultdict(list)

    def LogStep(self, key, value):
        self.from_step[key].append(value)

    def LogEpoch(self, key, value):
        self.from_epoch[key] = value

    def Accumulate(self):
        for key, values in self.from_step.items():
            self.from_epoch[key] = np.mean(values).round(10)
            # if not (key.endswith('loss') or key.endswith('R-squared')):
            #     warnings.warn(f"Accumulate method for {key} hasn't been defined yet", RuntimeWarning)

    def ToString(self):
        return str(self.from_epoch)

    def Clear(self):
        self.from_epoch.clear()
        self.from_step.clear()

def wmse(input: torch.Tensor, target: torch.Tensor, weight: torch.Tensor):
    return (weight * (input - target) ** 2).sum() / (weight.sum() + 1e-9)

def covariance_loss(H):
    H = H - H.mean(dim=0, keepdim=True)  # 去均值
    cov_matrix = (H.T @ H) / (H.shape[0] - 1)  # 计算协方差矩阵
    cov_matrix = cov_matrix - torch.diag(torch.diag(cov_matrix))  # 只保留非对角线元素
    return torch.norm(cov_matrix, p='fro')  # Frobenius 范数

def pearson_corr(y_pred, y_true, sample_weight=None, demean=True):
    """
    Compute the Pearson correlation coefficient.
    
    :param y_pred: (batch_size,) - Predicted values
    :param y_true: (batch_size,) - Ground truth values
    :param sample_weight: (batch_size,) or None - Sample weights (optional)
    :return: Scalar correlation coefficient (between -1 and 1)
    """
    if sample_weight is not None:
        sample_weight = sample_weight / sample_weight.sum()
    else:
        sample_weight = torch.ones_like(y_true) / y_true.numel()
    if demean:
        mean_true = (sample_weight * y_true).sum()
        mean_pred = (sample_weight * y_pred).sum()
        var_true = (sample_weight * (y_true - mean_true) ** 2).sum()
        var_pred = (sample_weight * (y_pred - mean_pred) ** 2).sum()
        cov = (sample_weight * (y_true - mean_true) * (y_pred - mean_pred)).sum()
    else:
        var_true = (sample_weight * y_true**2).sum()
        var_pred = (sample_weight * y_pred**2).sum()
        cov = (sample_weight *  y_true* y_pred).sum()

    return cov / (torch.sqrt(var_true) * torch.sqrt(var_pred) + 1e-8)

class WMSEloss(nn.Module):

    def forward(self, input: torch.Tensor, target: torch.Tensor, weight: torch.Tensor):
        return wmse(input, target, weight)

class WMSE_Orthohidden(nn.Module):
    def __init__(self, lambda_cov=1):
        super(WMSE_Orthohidden, self).__init__()
        self.lambda_cov = lambda_cov
        print(f"{self.lambda_cov=}")

    def forward(self, input: torch.Tensor, target: torch.Tensor, weight: torch.Tensor, last_hidden: torch.Tensor):
        mse = wmse(input, target, weight)
        valid_hidden = last_hidden[weight>0]
        orth_penalty = self.lambda_cov * covariance_loss(valid_hidden)
        loss = mse + orth_penalty
        loss_dict = {"mse": mse, "orth_penalty": orth_penalty, "loss": loss}
        # print(f"{loss=}")
        return loss_dict

class WSRloss(nn.Module):
    def __init__(self, alpha=1, groupby='month', use_mse=True, SR_only=False):
        super(WSRloss, self).__init__()
        self.alpha = alpha
        self.groupby = groupby
        self.use_mse = use_mse
        self.SR_only = SR_only
        print(f"{self.alpha=}, {self.groupby=}, {self.use_mse=}")
        assert self.groupby in ['sample', 'month']
        
    def forward(self, input: torch.Tensor, target: torch.Tensor, weight: torch.Tensor, attr: np.ndarray):
        # print("========================================================")
        loss_dict = {}
        if self.use_mse:
            mse = wmse(input, target, weight)
            loss_dict["mse"] = mse
            # print(f"{mse=}")
        returns = input * target
        if self.groupby == 'month':
            months = np.vectorize(lambda x: x[:6])(attr[:, 1])
            unique_months = np.unique(months)
            if len(unique_months) < 10:
                loss = 0 * input.sum()
                # print(f"{loss=}")
                return {"loss": loss}
            monthly_returns = []
            # print(f"{input.shape}, {unique_months.shape=}")
            for m in unique_months:
                mask = (months == m)  # 找出当前月份的样本
                weighted_mean = (returns[mask] * weight[mask]).sum() / (weight[mask].sum() + 1e-9)
                monthly_returns.append(weighted_mean)
            monthly_returns = torch.stack(monthly_returns)
            return_mean = monthly_returns.mean()
            return_var = monthly_returns.var()
            # print(f"{return_mean=}, {return_var=}")
            var_part = return_var * self.alpha
            if self.SR_only:
                loss = var_part
            else:
                if self.use_mse:
                    loss = var_part + mse
                else:
                    loss = var_part - return_mean
            loss_dict["var"] = var_part
            loss_dict["ret"] = return_mean
        elif self.groupby == 'sample':
            weighted_mean = (returns * weight).sum() / (weight.sum() + 1e-9)
            diff = returns - weighted_mean
            variance = (weight * diff * diff).sum() / (weight.sum() + 1e-9)
            # print(f"{weighted_mean=}, {variance=}")
            # weighted_std = torch.sqrt(variance)
            if self.use_mse:
                loss = variance * self.alpha + mse
            else:
                loss = variance * self.alpha - weighted_mean
            loss_dict["var"] = variance * self.alpha
            loss_dict["ret"] = weighted_mean
        loss_dict["loss"] = loss
        # print(f"{loss=}")
        return loss_dict

class ConcordanceCorrCoefLoss(torch.nn.Module):
    def __init__(self, demean=True):
        super().__init__()
        self.demean = demean

    def forward(self, y_pred, y_true, sample_weight=None):
        """
        Compute the Concordance Correlation Coefficient (CCC) loss.
        
        :param y_pred: (batch_size,) or (batch_size, 1) - Predicted values
        :param y_true: (batch_size,) or (batch_size, 1) - Ground truth values
        :param sample_weight: (batch_size,) or None - Sample weights (optional)
        :return: Scalar loss (1 - CCC)
        """
        
        if sample_weight is not None:
            sample_weight = sample_weight / sample_weight.sum()
        else:
            sample_weight = torch.ones_like(y_true) / y_true.numel()

        mean_true = (sample_weight * y_true).sum()
        mean_pred = (sample_weight * y_pred).sum()

        var_true = (sample_weight * (y_true - mean_true) ** 2).sum()
        var_pred = (sample_weight * (y_pred - mean_pred) ** 2).sum()
        cov = (sample_weight * (y_true - mean_true) * (y_pred - mean_pred)).sum()

        rho = cov / (torch.sqrt(var_true) * torch.sqrt(var_pred) + 1e-8)
        ccc = (2 * rho * torch.sqrt(var_true) * torch.sqrt(var_pred)) / (
                var_true + var_pred + (mean_true - mean_pred) ** 2 + 1e-8)

        return 1 - ccc  # Minimize 1 - CCC

class CorrWithMSELoss(torch.nn.Module):
    def __init__(self, alpha=0, demean=False):
        super().__init__()
        self.alpha = alpha
        self.demean = demean

    def forward(self, input: torch.Tensor, target: torch.Tensor, weight: torch.Tensor):
        mse = self.alpha * wmse(input, target, weight)
        corr = pearson_corr(input, target, weight, demean=self.demean)
        loss = mse - corr
        loss_dict = {"mse": mse, "corr": corr, "loss": loss}
        return loss_dict

class WMSEForMultiLoss(nn.Module):  # single yhat multi y
    def forward(self, input: torch.Tensor, target: torch.Tensor, weight: torch.Tensor, w_field: torch.Tensor=None):
        if w_field is None:
            w_field = torch.ones(target.shape[-1], dtype=target.dtype, device=target.device)
        assert (weight.ndim == 1 and weight.shape[0] == target.shape[0]) and (w_field.ndim == 1 and w_field.shape[0] == target.shape[-1]), f"weight shape: {weight.shape}, w_field shape: {w_field.shape}, target shape: {target.shape},"
        field_wise_wmse = (w_field * (input.unsqueeze(1)-target)**2).sum(axis=1) / (w_field.sum() + 1e-9)  # first mean over features, then weighted mean over samples
        sample_wise_wmse = (weight * field_wise_wmse).sum() / (weight.sum() + 1e-9)
        return sample_wise_wmse

class WMSEForMultiTarget(nn.Module):  # multi yhat multi y
    def forward(self, input: torch.Tensor, target: torch.Tensor, weight: torch.Tensor, w_field: torch.Tensor=None):
        if w_field is None:
            w_field = torch.ones(target.shape[-1], dtype=target.dtype, device=target.device)
        assert (weight.ndim == 1 and weight.shape[0] == target.shape[0]) and (w_field.ndim == 1 and w_field.shape[0] == target.shape[-1]), f"weight shape: {weight.shape}, w_field shape: {w_field.shape}, target shape: {target.shape},"
        field_wise_wmse = (w_field * (input-target)**2).sum(axis=1) / (w_field.sum() + 1e-9)  # first mean over features, then weighted mean over samples
        sample_wise_wmse = (weight * field_wise_wmse).sum() / (weight.sum() + 1e-9)
        return sample_wise_wmse
class UncertaintyWeighting(nn.Module):
    def __init__(self, num_outputs):
        super(UncertaintyWeighting, self).__init__()
        self.num_outputs = num_outputs
        params = torch.ones(num_outputs, requires_grad=True, dtype=torch.float32)
        self.params = nn.Parameter(params)

    def forward(self, input, target):
        # Ensure input and target have the same shape
        assert input.shape == target.shape, "Input and target must have the same shape"

        # Calculate MSE loss for each output without reduction
        mse_losses = F.mse_loss(input, target, reduction='none')  # Shape: (batch, n)
        
        # Compute the mean of the MSE losses along the batch dimension
        mean_mse_losses = mse_losses.mean(dim=0)  # Shape: (n,)
        
        # Calculate the final weighted loss using the automatic weighting
        weighted_loss = 0.5 / (self.params ** 2) * mean_mse_losses + torch.log(1 + self.params ** 2)
        loss_sum = weighted_loss.sum()

        return loss_sum

class GradnormLoss(torch.nn.Module):

    def __init__(self, num_outputs):

        # initialize the module using super() constructor
        super(GradnormLoss, self).__init__()
        # assign the weights for each task
        self.num_outputs = num_outputs
        self.weights = torch.nn.Parameter(torch.ones(num_outputs, requires_grad=True, dtype=torch.float32))
        # loss function
        self.mse_loss = MSELoss()

    
    def forward(self, input, target):
        # check if the number of tasks is equal to this size
        assert(input.size(1) == self.num_outputs)
        task_loss = []
        for i in range(self.num_outputs):
            task_loss.append(self.mse_loss(input[:, i], target[:, i]))
        task_loss = torch.stack(task_loss)
        weighted_task_loss = torch.sum(torch.mul(self.weights, task_loss))
        return task_loss, weighted_task_loss


class DynamicWeightAverage(torch.nn.Module):

    def __init__(self, num_outputs):

        # initialize the module using super() constructor
        super(DynamicWeightAverage, self).__init__()
        # assign the weights for each task
        self.num_outputs = num_outputs
        self.weights = torch.ones(num_outputs, dtype=torch.float32, requires_grad=False).cuda()
        # loss function
        self.mse_loss = MSELoss()

    
    def forward(self, input, target):
        # check if the number of tasks is equal to this size
        assert(input.size(1) == self.num_outputs)
        if self.weights.device != input.device:
            self.weights = self.weights.to(input.device)
        task_loss = []
        for i in range(self.num_outputs):
            task_loss.append(self.mse_loss(input[:, i], target[:, i]))
        task_loss = torch.stack(task_loss)
        weighted_task_loss = torch.sum(torch.mul(self.weights, task_loss))
        return task_loss, weighted_task_loss

def get_loss_function(loss_fn_name: str, loss_fn_para: dict) -> callable:
    if loss_fn_name == "mse":
        return torch.nn.MSELoss(**loss_fn_para)
    elif loss_fn_name == "huber":
        return torch.nn.HuberLoss(**loss_fn_para)
    # elif loss_fn_name == "mape":
    #     return MeanAbsolutePercentageError(**loss_fn_para)
    elif loss_fn_name == "mae":
        return torch.nn.L1Loss(**loss_fn_para)
    elif loss_fn_name == "wmse":
        return WMSEloss()
    elif loss_fn_name == "wSR":
        return WSRloss(**loss_fn_para)
    elif loss_fn_name == "Corr":
        return CorrWithMSELoss(**loss_fn_para)
    elif loss_fn_name == "WMSE_Orthohidden":
        return WMSE_Orthohidden(**loss_fn_para)
    elif loss_fn_name == "CCC":
        return ConcordanceCorrCoefLoss(**loss_fn_para)
    elif loss_fn_name == "wmse_mt":
        return WMSEForMultiTarget()
    elif loss_fn_name == "wmse_ml":
        return WMSEForMultiLoss()
    elif loss_fn_name == "uncw":
        return UncertaintyWeighting(**loss_fn_para)
    elif loss_fn_name == "gradn":
        return GradnormLoss(**loss_fn_para)
    elif loss_fn_name == "dwa":
        return DynamicWeightAverage(**loss_fn_para)

class dummy_lr_scheduler:
    def __init__(self):
        pass

    def step(self):
        return

class CustomWarmupLRScheduler(lr_scheduler._LRScheduler):
    def __init__(self, optimizer, warmup_epochs=1,
                 after_warmup_strategy='constant', after_warmup_args=None,
                 last_epoch=-1):
        self.warmup_epochs = warmup_epochs  # 1 stands for no warm up, use warmup_end_lr at 1st step
        self.warmup_end_lr = optimizer.param_groups[0]['lr']  # 以后可以每个组不一样的lr
        self.after_warmup_strategy = after_warmup_strategy
        self.after_warmup_args = after_warmup_args if after_warmup_args else {}
        self.initial_lr = [0 for _ in optimizer.param_groups]  # 以后可以每个组不一样的lr
        super(CustomWarmupLRScheduler, self).__init__(optimizer, last_epoch)

    def get_lr(self):
        current_epoch = self.last_epoch + 1

        if current_epoch <= self.warmup_epochs:
            # Linearly increase learning rate during warmup
            factor = current_epoch / self.warmup_epochs
            return [base_lr + factor * (self.warmup_end_lr - base_lr) for base_lr in self.initial_lr]
        else:
            # After warmup, apply selected strategy
            if self.after_warmup_strategy == 'constant':
                return [self.warmup_end_lr for _ in self.optimizer.param_groups]
            elif self.after_warmup_strategy == 'step':
                step_size = self.after_warmup_args.get('step_size', 5)
                gamma = self.after_warmup_args.get('gamma', 0.1)
                return [self.warmup_end_lr * (gamma ** ((current_epoch - self.warmup_epochs) // step_size))
                        for _ in self.optimizer.param_groups]
            elif self.after_warmup_strategy == 'exponential':
                gamma = self.after_warmup_args.get('gamma', 0.95)
                return [self.warmup_end_lr * (gamma ** (current_epoch - self.warmup_epochs))
                        for _ in self.optimizer.param_groups]
            else:
                raise ValueError("Invalid after_warmup_strategy. Choose from 'constant', 'step', or 'exponential'.")

def get_lr_scheduler(
    optimizer, lr_scheduler_type: str, lr_sched_para: dict
) -> callable:
    if lr_scheduler_type is None:
        return dummy_lr_scheduler()
    else:
        try:
            lr_scheduler_class = globals()[lr_scheduler_type]
        except KeyError:
            lr_scheduler_class = getattr(lr_scheduler, lr_scheduler_type)
        finally:
            return lr_scheduler_class(optimizer, **lr_sched_para)
    

def my_collate_fn(batch):
    if isinstance(batch[0], tuple):  # 常规的[self.dataset[idx] for idx in possibly_batched_index]
        if len(batch) == 1:  # 兼容xs mode
            X, y, w, attr, all_y = batch[0]
            X, y, w, all_y = torch.from_numpy(X), torch.from_numpy(y), torch.from_numpy(w), torch.from_numpy(all_y)  # UserWarning: The given NumPy array is not writable
            return X, y, w, attr, all_y
        X, y, w, attr, all_y = zip(*batch)
        X = torch.from_numpy(np.stack(X, axis=0))
        y = torch.from_numpy(np.stack(y, axis=0))
        w = torch.from_numpy(np.stack(w, axis=0))
        attr = np.stack(attr, axis=0)  # torch不支持<U8
        all_y = torch.from_numpy(np.stack(all_y, axis=0))
        return X, y, w, attr, all_y
    else:  # data = self.dataset.__getitems__(possibly_batched_index)
        assert isinstance(batch[0], torch.Tensor), type(batch[0])  # 此时batch[0]应该当是带batch_size维的X
        return batch

def my_collate_fn_combine(batch):
    feature1, feature2, y1, y2, w, attr, all_y = zip(*batch)
    feature1 = torch.from_numpy(np.stack(feature1, axis=0))
    feature2 = torch.from_numpy(np.stack(feature2, axis=0))
    y1 = torch.from_numpy(np.stack(y1, axis=0))
    y2 = torch.from_numpy(np.stack(y2, axis=0))
    w = torch.from_numpy(np.stack(w, axis=0))
    attr = np.stack(attr, axis=0)  # torch does not support <U8
    all_y = torch.from_numpy(np.stack(all_y, axis=0))
    return feature1, feature2, y1, y2, w, attr, all_y

def my_collate_fn_con(batch):
    feature1, y1, w, attr = zip(*batch)
    feature1 = torch.from_numpy(np.stack(feature1, axis=0))
    y1 = torch.from_numpy(np.stack(y1, axis=0))
    w = torch.from_numpy(np.stack(w, axis=0))
    attr = np.stack(attr, axis=0)  # torch does not support <U8
    return feature1, y1, w, attr

def xsclip_yhat(yhat, n=5):
    """inplace进行n倍std xsclip yhat, 只处理那些w>0的样本"""
    yhat_w1 = yhat[yhat['weight']>0]
    grouped = yhat_w1.groupby(['D', 'I'])
    mean = grouped['yhat'].transform('mean')
    std = grouped['yhat'].transform('std')
    lb = mean - n * std
    ub = mean + n * std
    yhat.loc[yhat['weight']>0, 'yhat'] = np.clip(yhat_w1['yhat'], lb, ub)

from scipy.stats import zscore
def clip_and_zscore(group, p, col="yhat"):
    clipped_group = group.copy()
    values = group[col].values
    lower_percentile = np.percentile(values, p)
    upper_percentile = np.percentile(values, 100-p)
    clipped_values = np.clip(values, lower_percentile, upper_percentile)
    clipped_group[col] = zscore(clipped_values)
    return clipped_group

def xszscore_yhat(yhat, p=5):
    if pd.__version__ == '2.2.0':
        return yhat.groupby(['D', 'I']).apply(lambda x: clip_and_zscore(x, p), include_groups=False).reset_index()
    else:
        return yhat.groupby(['D', 'I']).apply(lambda x: clip_and_zscore(x, p)).reset_index()

if __name__ == "__main__":
    batch_size = 4
    num_outputs = 3
    input = torch.randn(batch_size, num_outputs)
    target = torch.randn(batch_size, num_outputs)

    loss_fn = GradnormLoss(num_outputs)
    task_loss, weighted_task_loss = loss_fn(input, target)

    print("Task Loss:", task_loss)
    print("Weighted Task Loss:", weighted_task_loss)