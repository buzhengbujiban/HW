import os, copy, subprocess
DATASET_MODULE_PATH = f"/data/nfshome/{os.environ['USER']}/git/qrfitter3/qrfitter3/nnfitter/torch_dataset_sdiv.py"
LEARNER_MODULE_PATH = f"/data/nfshome/{os.environ['USER']}/git/qrfitter3/qrfitter3/nnfitter/learner.py"
from qrfitter3.utils import load_class, save_json, copy_folder_contents
from pytbl import tbl_read


def run_fit_task(config):
    if "randomrestart_config" in config['fitter'] and config['fitter']["randomrestart_config"]["enable"] and config['fitter']["randomrestart_config"].get("parallel", False):
        run_rr_task(config)
        exit()
    dataset_config, task_config, fitter_config = config['dataset'], config['task'], config['fitter']
    inference_dataset_config = config.get("inference_dataset", dataset_config)
    fitter_config.update({"outdir": task_config["outdir"], "expt_name": config["fitting_name"]})

    datasets = {}
    for set_name in ["train", "valid"]:
        dates = task_config[set_name]
        assert isinstance(dates, (dict, list)), f"dates doesn't support type {type(dates)}"
        dataset_module_path = dataset_config.get("module_path", DATASET_MODULE_PATH)
        datasets[set_name] = load_class(dataset_module_path, dataset_config["class"])(config=dataset_config, dates=dates)
    if not config.get("canopus_inference", False):  # 如果用canopus_inference则无需配test dataset
        dates = task_config["test"]
        assert isinstance(dates, (dict, list)), f"dates doesn't support type {type(dates)}"
        inference_dataset_module_path = inference_dataset_config.get("module_path", DATASET_MODULE_PATH)
        datasets["test"] = load_class(inference_dataset_module_path, inference_dataset_config["class"])(config=inference_dataset_config, dates=dates)
    learner_module_path = fitter_config.get("module_path", LEARNER_MODULE_PATH)
    learner = load_class(learner_module_path, fitter_config["class"])(fitter_config)
    learner.run(datasets)


def run_rr_task(config):
    task_config, fitter_config = config['task'], config['fitter']
    randomrestart_config = fitter_config.pop("randomrestart_config")  # overwrite old logic
    fitter_config["earlystop_config"] = randomrestart_config["earlystop_config"]
    monitor_key = randomrestart_config["earlystop_config"]["monitor_key"]  # e.g. valid/cor
    mode = randomrestart_config["earlystop_config"]["mode"]  # max or min
    restart_num = randomrestart_config["restart_num"]
    njobs = randomrestart_config.get("parallel_njobs", restart_num+1)
    outdir = task_config["outdir"]
    fit_tasks_jsons = []
    for seed in range(restart_num+1):
        outdir_seed = os.path.join(outdir, f"seed.{seed}")
        os.makedirs(outdir_seed, exist_ok=True)
        config_seed = copy.deepcopy(config)
        config_seed["fitter"].update({"seed": seed})
        config_seed["task"].update({"outdir": outdir_seed})
        seed_fit_task_cfg_path = os.path.join(outdir_seed, "fit_task_cfg.json")
        save_json(config_seed, seed_fit_task_cfg_path)
        os.chmod(seed_fit_task_cfg_path, 0o700)
        fit_tasks_jsons.append(seed_fit_task_cfg_path)
    seed_jobs_file = os.path.join(outdir, 'all_seed_jobs.sh')
    with open(seed_jobs_file, 'w') as out_file:
        for task_json in fit_tasks_jsons:
            cmd_line = f"python /data/nfshome/{os.environ['USER']}/git/qrfitter3/qrfitter3/apps/run_fit_task.py {task_json}"
            out_file.write(cmd_line)
            out_file.write('\n')
    os.chmod(seed_jobs_file, 0o700)
    commands_log_file = os.path.join(outdir, "logs")
    os.makedirs(commands_log_file, exist_ok=True)
    os.chmod(commands_log_file, 0o700)
    cmd = f"cat {seed_jobs_file} | run-parallel -j {njobs} -w {commands_log_file} -k"
    subprocess.run(cmd, shell=True, text=True)

    seed_performance = {}
    set_name, metric = monitor_key.split("/")
    for seed in range(restart_num+1):
        set_resuls = tbl_read(os.path.join(outdir, f"seed.{seed}", "set_results.tbl")).set_index("set")
        seed_performance[f"seed.{seed}"] = set_resuls.loc[set_name, metric]
    seed_id = eval(mode)(seed_performance, key=seed_performance.get)
    print(f"{seed_performance=}, {seed_id=} is the {mode} one.")
    copy_folder_contents(src_folder=os.path.join(outdir, f"seed.{seed}"), dest_folder=outdir)


def run_inference_task(config):
    inference_dataset_config, task_config, fitter_config = config['inference_dataset'], config['task'], config['fitter']
    fitter_config.update({"outdir": task_config["outdir"]})
    set_name, dates = task_config["set_name"], task_config["period"]
    inference_dataset_module_path = inference_dataset_config.get("module_path", DATASET_MODULE_PATH)
    dataset = load_class(inference_dataset_module_path, inference_dataset_config["class"])(config=inference_dataset_config, dates=dates)
    learner_module_path = fitter_config.get("module_path", LEARNER_MODULE_PATH)
    learner = load_class(learner_module_path, fitter_config["class"])(fitter_config)
    if "inference" in task_config["task"]:
        learner.run_inference({set_name: dataset})
    if "inference_hidden" in task_config["task"]:
        learner.run_inference_last_hidden({set_name: dataset})