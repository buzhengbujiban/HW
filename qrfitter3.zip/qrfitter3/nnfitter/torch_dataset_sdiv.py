import numpy as np
import pandas as pd
import copy
import os, sys
from typing import Dict, List
import math
from collections import defaultdict, deque
import torch
from torch.utils.data import Dataset
from torch.utils.data.sampler import WeightedRandomSampler
import bisect
from tqdm import tqdm
from torch.utils.data import Sampler
import xarray as xr
from typing import Union

from pattern_helper import *
from array_shm import read_shm_as_xr
import panel #, qr

def read_sdiv_as_xr(path):
    if path.startswith("/dev/shm"):
        return read_shm_as_xr(path)
    return panel.read(path).astype(np.float32)

def get_range(all_dates, start_date, end_date):
    i = bisect.bisect_left(all_dates, start_date)
    j = bisect.bisect_right(all_dates, end_date)
    return all_dates[i:j]

def all_arrays_equal(arr_list):
    if len(arr_list) <= 1:
        return True
    first_array = arr_list[0]
    return all((array == first_array).all() for array in arr_list)

def reshape_arr(arr, flatten, dimD):
    if flatten:
        return arr.reshape(-1, arr.shape[-1])  # (D, I, S, V) -> (DIS, V)
    else:
        return np.squeeze(arr, axis=dimD)  # -> (I, S, V)

def sdiv2sev(arr):
    return arr.reshape(arr.shape[0], arr.shape[1]*arr.shape[2], arr.shape[3])


def get_data_oneday(config, date: str):
    flatten = config["dataset_type"].lower() == "tabular"
    dims = []
    Ss, Is = [], []
    x_arrs, x_names = [], []
    
    for path in config["x_files"]:
        xarr = read_sdiv_as_xr(path.replace("YYYYMMDD", str(date)))
        dims.append(xarr.dims)  # (D, I, S, V)
        Ss.append(xarr.coords['S'].values)
        Is.append(xarr.coords['I'].values)
        x_arrs.append(reshape_arr(xarr.values, flatten, xarr.dims.index("D")))
        x_names.append(xarr.coords['V'].values)

    if isinstance(config["y_file"], str):
        y_xarr = read_sdiv_as_xr(config["y_file"].replace("YYYYMMDD", str(date)))
    elif isinstance(config["y_file"], list):
        y_xarrs = [read_sdiv_as_xr(y_file.replace("YYYYMMDD", str(date))) for y_file in config["y_file"]]
        assert all_arrays_equal([y_xarr.coords['S'].values for y_xarr in y_xarrs]), f"S coordinate doesn't match for y_files on {date}"
        assert all_arrays_equal([y_xarr.coords['I'].values for y_xarr in y_xarrs]), f"I coordinate doesn't match for y_files on {date}"
        y_xarr = xr.concat(y_xarrs, dim="V")
    dims.append(y_xarr.dims)
    Ss.append(y_xarr.coords['S'].values)
    Is.append(y_xarr.coords['I'].values)
    y_arr = reshape_arr(y_xarr.values, flatten, y_xarr.dims.index("D"))
    y_names = y_xarr.coords['V'].values

    if isinstance(config["w_file"], str):
        w_xarr = read_sdiv_as_xr(config["w_file"].replace("YYYYMMDD", str(date)))
    elif isinstance(config["w_file"], list):
        w_xarrs = [read_sdiv_as_xr(w_file.replace("YYYYMMDD", str(date))) for w_file in config["w_file"]]
        assert all_arrays_equal([w_xarr.coords['S'].values for w_xarr in w_xarrs]), f"S coordinate doesn't match for w_files on {date}"
        assert all_arrays_equal([w_xarr.coords['I'].values for w_xarr in w_xarrs]), f"I coordinate doesn't match for w_files on {date}"
        w_xarr = xr.concat(w_xarrs, dim="V")
    dims.append(w_xarr.dims)
    Ss.append(w_xarr.coords['S'].values)
    Is.append(w_xarr.coords['I'].values)
    w_arr = reshape_arr(w_xarr.values, flatten, w_xarr.dims.index("D"))
    w_names = w_xarr.coords['V'].values

    # 确保当天的所有x y w文件的dims以及S和I是一致的
    assert len(set(dims)) == 1, f"xarray.dims don't match for xyw files on {date}"
    assert all_arrays_equal(Ss), f"S coordinate doesn't match for xyw files on {date}"
    assert all_arrays_equal(Is), f"I coordinate doesn't match for xyw files on {date}"
    dim = dims[0]
    D = date  # str
    S, I = Ss[0], Is[0]  # legnth: #symbol, #interval
    # 得到当天x的V维
    x_names = np.hstack(x_names)
    assert len(x_names) == len(set(x_names)), "x_names conflict"

    return x_arrs, y_arr, w_arr, x_names, y_names, w_names, dim, D, I, S


def get_data(config, dates: Union[Dict, List[str]]):
    common_dates = set(find_dates_from_pattern(config["x_files"][0]))
    for x_file in config["x_files"][1:]:
        common_dates = common_dates.intersection(find_dates_from_pattern(x_file))

    if isinstance(config["y_file"], str):
        common_dates = common_dates.intersection(find_dates_from_pattern(config["y_file"]))
    elif isinstance(config["y_file"], list):
        for y_file in config["y_file"]:
            common_dates = common_dates.intersection(find_dates_from_pattern(y_file))
    else:
        raise TypeError(f"type not supported: {type(config['y_file'])}")
    
    if isinstance(config["w_file"], str):
        common_dates = common_dates.intersection(find_dates_from_pattern(config["w_file"]))
    elif isinstance(config["w_file"], list):
        for w_file in config["w_file"]:
            common_dates = common_dates.intersection(find_dates_from_pattern(w_file))
    else:
        raise TypeError(f"type not supported: {type(config['w_file'])}")
    
    all_dates = [str(d) for d in sorted(common_dates)]
    if isinstance(dates, Dict):
        dates = get_range(all_dates, dates["start_date"], dates["end_date"])
    else:  # 直接指定list of dates
        if isinstance(dates[0], int):
            dates = [str(x) for x in dates]
        dates_missing = [x for x in dates if x not in all_dates]
        if len(dates_missing) != 0:
            print(f"WARNING: missing dates {dates_missing} in common_dates")
            print(dates_missing)
    if "exclude_dates" in config:  # 比如202002月可以暂时在这exclude掉
        exclude_dates = config["exclude_dates"]
        if isinstance(exclude_dates, Dict):
            invalid_dates = get_range(all_dates, exclude_dates["start_date"], exclude_dates["end_date"])
        elif isinstance(exclude_dates, List):
            invalid_dates = []
            for start_end in exclude_dates:
                invalid_dates.extend(get_range(all_dates, start_end["start_date"], start_end["end_date"]))
        else:
            raise TypeError("invalid type")
        dates = [d for d in dates if d not in invalid_dates]
    assert len(dates) > 0, "No valid dates"
    dims = []
    Ds, Ss, Is, Vs = [], [], [], []  # all list of length #dates
    xs, ys, ws = [], [], []
    for date in tqdm(dates):
        x_arrs, y_arr, w_arr, x_names, y_names, w_names, dim, D, I, S = get_data_oneday(config, date)
        dims.append(dim)
        Ds.append(D)
        Ss.append(S)
        Is.append(I)
        Vs.append(np.hstack([x_names, y_names, w_names]))
        xs.append(x_arrs)
        ys.append(y_arr)
        ws.append(w_arr)
    
    assert len(set(dims)) == 1, "xarray.dims don't match among dates"  # 虽然mlp ds好像不一定要确保这个，但这个比较natural的事情还是assert一下以免发生奇奇怪怪的问题
    dim = dims[0]
    assert dim.index("V") == 3, "V should be at dim 3"  # 上面的flatten以及下面的getitem都依赖这一点
    assert all_arrays_equal(Vs), "V coordinate doesn't match among dates"
    if config["dataset_type"].lower() == "ts":
        assert all_arrays_equal(Ss) and all_arrays_equal(Is), "S and I coordinates don't match across dates for ts dataset"

    return xs, ys, ws, x_names, y_names, w_names, dim, Ds, Is, Ss


def get_attrs(dim, Ds, Is, Ss):
    fast_changing_coord = dim[-2]  # left to V, either I or S；means when idx increases, the coordinate that changes faster. e.g. S in (D,I,S,V)
    attrs = []
    for i, date in enumerate(Ds):
        I_date, S_date = Is[i], Ss[i]
        D_array = np.array([date] * (len(I_date)*len(S_date)))
        if fast_changing_coord == "S":  # (D,I,S,V)
            I_array = np.repeat(I_date, len(S_date))
            S_array = np.tile(S_date, len(I_date))
        else:  # (D,S,I,V)
            S_array = np.repeat(S_date, len(I_date))
            I_array = np.tile(I_date, len(S_date))
        DIS_date = np.vstack([D_array, I_array, S_array]).T
        attrs.append(DIS_date)
    return attrs


class BinarySampler(Sampler):
    """只sample weight=1的样本"""
    def __init__(self, weights, shuffle):
        self.weights = np.where(weights!=0)[0].tolist()
        self.shuffle = shuffle

    def __iter__(self):
        if self.shuffle:
            np.random.shuffle(self.weights)
            print("sample_idxs shuffled")
        return iter(self.weights)

    def __len__(self):
        return len(self.weights)


class BinarySamplerByMonth(Sampler):
    """只sample weight=1的样本，并且顺序是每月一个样本这样循环"""
    def __init__(self, weights, attrs, shuffle):
        self.shuffle = shuffle
        indices = np.where(weights!=0)[0].tolist()
        attrs = attrs[indices]
        df = pd.DataFrame({'date': attrs[:, 1], 'index': indices})
        df['month'] = df['date'].astype(str).str[:6]  # 提取 YYYYMM
        self.month_groups = df.groupby('month')['index'].apply(deque).to_dict()
        self.indices = indices

    def __iter__(self):
        month_groups = copy.deepcopy(self.month_groups)
        if self.shuffle:
            for indices in month_groups.values():
                np.random.shuffle(indices)
            print("month_groups indices shuffled")
        months = sorted(month_groups.keys())
        result = []
        while any(month_groups.values()):  # 直到所有月份的样本都用完
            for m in months:
                if month_groups[m]:  # 该月仍有剩余样本
                    result.append(month_groups[m].popleft())
        return iter(result)

    def __len__(self):
        return len(self.indices)


class MLPDataset(Dataset):
    def __init__(self, config, dates):
        # print(qr.cpu_mem_usage("Initializing MLPDataset"))
        xs, ys, ws, x_names, y_names, w_names, dim, Ds, Is, Ss = get_data(config, dates)
        self.single_xfile = len(xs[0]) == 1
        if self.single_xfile:
            xs = [xs_date[0] for xs_date in xs]
            self.nV = config.get("use_firstnV", len(x_names))
        else:
            self.nV = len(x_names)  # fetching first n terms, not supported in multifile
        self.xs, self.ys, self.ws = xs, ys, ws  # all list of length #dates
        self.x_names, self.y_names, self.w_names = x_names, y_names, w_names
        self.dim = dim  # e.g. (D,I,S,V)
        self.Ds, self.Is, self.Ss = Ds, Is, Ss  # all list of length #dates
        print(f"{self.Ds[0]=} to {self.Ds[-1]=}")
        self.attrs = get_attrs(self.dim, self.Ds, self.Is, self.Ss)  # of length #dates for tabular dataset
        self.attr_names = ["D", "I", "S"]
        fit_y = config.get("fit_y", None)
        if fit_y is None:
            self.fit_y_idx = np.where(np.isin(self.y_names, self.y_names))[0]
        elif isinstance(fit_y, list):  # multi target
            self.fit_y_idx = [np.where(self.y_names == name)[0][0] for name in fit_y]
        else:
            self.fit_y_idx = np.where(y_names==fit_y)[0][0]
        self.fit_w_idx = np.where(w_names==config["fit_w"])[0][0]
        self.fit_ys = [y[..., self.fit_y_idx] for y in self.ys]
        self.fit_ws = [w[..., self.fit_w_idx] for w in self.ws]
        if "wIs" in config:  # e.g. {10: ['09:35:00'], 5: ['09:45:00']}  调高某些I的loss权重
            wIs = config["wIs"]
            for D_idx in range(len(self.fit_ws)):
                for w, Is in wIs.items():
                    self.fit_ws[D_idx] = self.fit_ws[D_idx] * np.where(np.isin(self.attrs[D_idx][:, 1], Is), np.array(w, dtype=self.fit_ws[D_idx].dtype), 1)
        assert not ("sampling_w" in config and "sampling_Is" in config)
        if "sampling_w" in config:  # 通过专门一列sampling_w!=0来控制sample哪些样本做训练
            self.sampling_w_idx = np.where(w_names==config["sampling_w"])[0][0]
            self.sampling_ws = [w[..., self.sampling_w_idx] for w in self.ws]
        if "sampling_Is" in config:  # e.g. ['09:35:00'], 只sample这部分样本做训练
            self.sampling_ws = [np.isin(attr[:, 1], config["sampling_Is"]).astype(int) for attr in self.attrs]
        if "use_x_names" in config:
            use_x_names = config["use_x_names"]  # 选择部分features，包括其顺序
            all_x_names = self.x_names.tolist()
            if not use_x_names == all_x_names:
                self.x_idxs = np.array([all_x_names.index(name) for name in use_x_names])  # order of terms matters in sequential learning
                self.x_names = np.array(use_x_names)
        
        sample_num_list = [len(self.Is[i])*len(self.Ss[i]) for i in range(len(self.Ds))]  # 每一天的样本数
        self.sample_num_per_day = sample_num_list[0] if len(set(sample_num_list)) == 1 else None
        self.sample_daily_cumsum = np.cumsum(sample_num_list)  # e.g. array([ 10000,  20050,  30000]) for 3 days
        interval_num_list = [len(self.Is[i]) for i in range(len(self.Ds))]  # 每一天的截面数
        self.interval_num_per_day = interval_num_list[0] if len(set(interval_num_list)) == 1 else None
        self.interval_daily_cumsum = np.cumsum(interval_num_list)  # e.g. array([ 24,  48,  72]) for 3 days
        self.getitem_mode = "xs" if config["dataset_type"].lower() == "xs" else "sample"
        self.dtype = self.ys[0].dtype

    def __len__(self):
        if self.getitem_mode == "sample":  # normal behavior
            return self.sample_daily_cumsum[-1]
        elif self.getitem_mode == 'xs':  # 整个截面作为一个样本
            return self.interval_daily_cumsum[-1]
        elif self.getitem_mode == "daily":  # 整一天作为一个样本
            return len(self.Ds)
    
    def get_sampler(self, shuffle):
        if not hasattr(self, "sampling_ws"):
            return None
        weights = np.array([self.__getitem__(i, True) for i in range(len(self))])
        sampler = BinarySampler(weights, shuffle=shuffle)
        return sampler

    def __getitem__(self, idx, fetch_sampling_weight=False):
        
        if self.getitem_mode == "sample":  # normal behavior
            if self.sample_num_per_day is None:  # 每天样本数不同
                D_idx = bisect.bisect_right(self.sample_daily_cumsum, idx)
                if D_idx > 0:
                    idx -= self.sample_daily_cumsum[D_idx-1]
            else:
                D_idx, idx = idx // self.sample_num_per_day, idx % self.sample_num_per_day
            if fetch_sampling_weight:
                return self.sampling_ws[D_idx][idx]
            
            if self.single_xfile:  # 支持单一xfile或多files
                X = self.xs[D_idx][idx, :self.nV]
            else:
                X = np.hstack([x_arr[idx, :] for x_arr in self.xs[D_idx]])
            if hasattr(self, "x_idxs"):  # 支持取部分features
                X = X[self.x_idxs]
            y = self.fit_ys[D_idx][idx]
            w = self.fit_ws[D_idx][idx]
            attr = self.attrs[D_idx][idx, :]
            all_y = self.ys[D_idx][idx, :]
            return X, y, w, attr, all_y  # (F,), float, float, (3,), (Y,)
        
        elif self.getitem_mode == "daily":  # to support per day inference&save
            D_idx = idx
            X = self.xs[D_idx][:, :self.nV]
            if hasattr(self, "x_idxs"):
                X = X[:, self.x_idxs]
            y = self.fit_ys[D_idx]
            w = self.fit_ws[D_idx]
            attr = self.attrs[D_idx]
            all_y = self.ys[D_idx]
            return X, y, w, attr, all_y  # (B, F), (B,), (B,), (B, 3), (B, Y)

        elif self.getitem_mode == "xs":  # 一个截面为一个样本item
            if self.interval_num_per_day is None:  # 每天截面不同
                D_idx = bisect.bisect_right(self.interval_num_per_day, idx)
                if D_idx > 0:
                    idx -= self.interval_num_per_day[D_idx-1]
            else:
                D_idx, idx = idx // self.interval_num_per_day, idx % self.interval_num_per_day

            if self.single_xfile:  # 支持单一xfile或多files
                X = self.xs[D_idx][idx, :, :self.nV]
            else:
                X = np.hstack([x_arr[idx, :, :] for x_arr in self.xs[D_idx]])
            if hasattr(self, "x_idxs"):  # 支持取部分features
                X = X[:, self.x_idxs]
            y = self.fit_ys[D_idx][idx, :]
            w = self.fit_ws[D_idx][idx, :]
            attr = np.array([[self.Ds[D_idx]]*len(self.Ss[0]), [self.Is[0][idx]]*len(self.Ss[0]), self.Ss[0]]).T
            # attr = self.attrs[D_idx][idx, :, :]
            all_y = self.ys[D_idx][idx, :, :]
            return X, y, w, attr, all_y  # (C, F), (C,), (C,), (C, 3), (C, Y)  C stands for number of codes

class GapSampler(Sampler):
    def __init__(self, dataset, shuffle):
        self.dataset = dataset
        self.shuffle = shuffle

    def __iter__(self):
        valid_indices = self.dataset.get_gap_sample_idxs()
        if self.shuffle:
            np.random.shuffle(valid_indices)
            print("sample_idxs shuffled")
        return iter(valid_indices)

    def __len__(self):
        return len(self.dataset.get_gap_sample_idxs())


class TSDataset(MLPDataset):
    def __init__(self, config, dates):
        assert config["dataset_type"].lower() == "ts", "This should be a ts dataset"
        super(TSDataset, self).__init__(config, dates)
        self.kernel_size = config["kernel_size"]
        self.dilation = config["dilation"]

        self.dimS = self.dim.index("S") - 1  # e.g. dim = ('D', 'I', 'S', 'V'), with 'D' squeezed out in data, dimS=1
        self.nI, self.nS = len(self.Is[0]), len(self.Ss[0])
        self.bwindow = self.dilation * (self.kernel_size-1)  # backward looking window length, excluding current time point
        self.nD_drop = math.ceil(self.bwindow / self.nI)  # 完整地drop掉开头这几天（而不是给最后一天留下几条I）会给后面的各种index计算带来很大的方便
        self.sample_num_per_day = self.nI * self.nS
        self.sample_gap = config.get("sample_gap", None)
    
    def __len__(self):
        return (len(self.Ds) - self.nD_drop) * self.sample_num_per_day

    def get_DIS_idx(self, idx):
        D_idx, idx = idx // self.sample_num_per_day, idx % self.sample_num_per_day
        D_idx += self.nD_drop
        I_idx, S_idx = idx // self.nS, idx % self.nS
        return D_idx, I_idx, S_idx
    
    def get_sampler(self, shuffle):
        if self.sample_gap is None:
            return None
        sampler = GapSampler(self, shuffle=shuffle)
        return sampler

    def get_gap_sample_idxs(self):
        sids = list(range(self.nS))
        np.random.shuffle(sids)
        sid_perIgroup = math.ceil(self.nS / self.sample_gap)
        Igroup = (list(range(self.sample_gap)) * sid_perIgroup)[:self.nS]
        sid_sampleI_map = dict(zip(sids, Igroup))
        sample_idxs = []
        for idx in range(len(self)):
            D_idx, I_idx, S_idx = self.get_DIS_idx(idx)
            if I_idx % self.sample_gap == sid_sampleI_map[S_idx]:
                sample_idxs.append(idx)
        return sample_idxs  # length = len(self) / self.sample_gap
    
    def __getitem__(self, idx, fetch_sampling_weight=False):
        D_idx, I_idx, S_idx = self.get_DIS_idx(idx)
        nbD = math.ceil((self.bwindow - I_idx) / self.nI)  # number of backward looking dates, except for today
        
        if fetch_sampling_weight:
            if self.dimS == 1:
                i_sampling_w = np.s_[I_idx, S_idx, self.sampling_w_idx]
            else:
                i_sampling_w = np.s_[S_idx, I_idx, self.sampling_w_idx]
            return self.ws[D_idx][i_sampling_w]
        
        if self.dimS == 1:
            i_x = np.s_[:, S_idx, :self.nV]
            i_y = np.s_[I_idx, S_idx, self.fit_y_idx]
            i_fit_w = np.s_[I_idx, S_idx, self.fit_w_idx]
            i_all_y = np.s_[I_idx, S_idx, :]
        else:
            i_x = np.s_[S_idx, :, :self.nV]
            i_y = np.s_[S_idx, I_idx, self.fit_y_idx]
            i_fit_w = np.s_[S_idx, I_idx, self.fit_w_idx]
            i_all_y = np.s_[S_idx, I_idx, :]

        if self.single_xfile:
            X = [self.xs[d][i_x] for d in range(D_idx-nbD, D_idx+1)] # take (I, V) arrays for a single S from multiple dates
        else:
            X = [np.hstack([x_arr[i_x] for x_arr in self.xs[d]]) for d in range(D_idx-nbD, D_idx+1)]  # (I_d, V_n) -> (I_d, V), VERY time-consuming
        X = np.vstack(X)  # concatenate along dates, time-consuming
        if hasattr(self, "x_idxs"):  # 支持取部分features
            X = X[:, self.x_idxs]
        end_Iidx = nbD * self.nI + I_idx
        start_Iidx = end_Iidx - self.bwindow
        X = X[start_Iidx: end_Iidx+1: self.dilation, :]
        y = self.ys[D_idx][i_y]
        w = self.ws[D_idx][i_fit_w]
        attr = np.array([self.Ds[D_idx], self.Is[0][I_idx], self.Ss[0][S_idx]])
        all_y = self.ys[D_idx][i_all_y]
        return X, y, w, attr, all_y  # (T, F), float, float, (3,), (Y,)

    def __getitems__(self, idxs):
        bs = len(idxs)
        X = np.zeros((bs, self.kernel_size, len(self.x_names)), dtype=self.dtype)
        y = np.zeros((bs, len(self.fit_y_idx)), dtype=self.dtype) if isinstance(self.fit_y_idx, list) else np.zeros((bs,), dtype=self.dtype)
        w = np.zeros((bs,), dtype=self.dtype)
        attr = np.zeros((bs, len(self.attr_names)), dtype='<U8')
        all_y = np.zeros((bs, len(self.y_names)), dtype=np.float32)
        for i, idx in enumerate(idxs):
            sample = self.__getitem__(idx)
            _X, _y, _w, _attr, _all_y = sample
            X[i], y[i], w[i], attr[i], all_y[i] = _X, _y, _w, _attr, _all_y
        X, y, w, all_y = torch.from_numpy(X), torch.from_numpy(y), torch.from_numpy(w), torch.from_numpy(all_y)
        return X, y, w, attr, all_y  # (B, T, F), (B,), (B,), (B, 3), (B, Y)


class LengthGroupedBatchSampler(Sampler):
    def __init__(self, dataset, batch_size, shuffle=True):
        self.dataset = dataset
        self.batch_size = batch_size
        self.length_to_indices = self._group_by_length()
        self.shuffle = shuffle

    def _group_by_length(self):
        length_to_indices = defaultdict(list)
        for idx in range(len(self.dataset)):
            _, I_idx, _, _ = self.dataset.get_DIS_idx(idx)
            length = I_idx + 1
            length_to_indices[length].append(idx)
        return length_to_indices

    def __iter__(self):
        # Shuffle indices within each group and form batches
        batches = []
        for length, indices in self.length_to_indices.items():
            if self.shuffle:
                np.random.shuffle(indices)  # Shuffle indices for this length
            for i in range(0, len(indices), self.batch_size):
                batches.append(indices[i:i + self.batch_size])  # drop_last=False
        num_batch = len(batches)
        batch_idxs = list(range(num_batch))
        if self.shuffle:
            np.random.shuffle(batch_idxs)  # Shuffle the order of batch_idx
        for batch_idx in batch_idxs:
            yield batches[batch_idx]

    def __len__(self):
        num_batch = 0
        for length, indices in self.length_to_indices.items():
            num_batch += math.ceil(len(indices) / self.batch_size)
        return num_batch


class TSDatasetIntraDay(MLPDataset):
    def __init__(self, config, dates):
        assert config["dataset_type"].lower() == "ts", "This should be a ts dataset"
        super(TSDatasetIntraDay, self).__init__(config, dates)
        self.dimS = self.dim.index("S") - 1  # e.g. dim = ('D', 'I', 'S', 'V'), with 'D' squeezed out in data, dimS=1
        self.kernel_size = config["kernel_size"]  # max look back window
        self.dilation = config["dilation"]

    def get_DIS_idx(self, idx):
        if self.sample_num_per_day is None:  # 每天样本数不同
            D_idx = bisect.bisect_right(self.sample_daily_cumsum, idx)
            if D_idx > 0:
                idx -= self.sample_daily_cumsum[D_idx-1]
        else:
            D_idx, idx = idx // self.sample_num_per_day, idx % self.sample_num_per_day
        I_idx, S_idx = idx // len(self.Ss[D_idx]), idx % len(self.Ss[D_idx])
        return D_idx, I_idx, S_idx, idx

    def get_batch_sampler(self, batch_size, shuffle):
        sampler = LengthGroupedBatchSampler(self, batch_size, shuffle)
        return sampler

    def __getitem__(self, idx):
        D_idx, I_idx, S_idx, idx = self.get_DIS_idx(idx)
        max_length = math.ceil((I_idx+1) / self.dilation)
        if self.kernel_size >= max_length:
            start_Iidx = 0
        else:
            start_Iidx = I_idx - (self.kernel_size-1) * self.dilation
        end_Iidx = I_idx+1
        iI = slice(start_Iidx, end_Iidx, self.dilation)
        if self.dimS == 1:
            i_x = np.s_[iI, S_idx, :self.nV]
            i_y = np.s_[I_idx, S_idx, self.fit_y_idx]
            i_fit_w = np.s_[I_idx, S_idx, self.fit_w_idx]
            i_all_y = np.s_[I_idx, S_idx, :]
        else:
            i_x = np.s_[S_idx, iI, :self.nV]
            i_y = np.s_[S_idx, I_idx, self.fit_y_idx]
            i_fit_w = np.s_[S_idx, I_idx, self.fit_w_idx]
            i_all_y = np.s_[S_idx, I_idx, :]
        if self.single_xfile:
            X = self.xs[D_idx][i_x]
        else:
            X = np.hstack([x_arr[i_x] for x_arr in self.xs[D_idx]])
        if hasattr(self, "x_idxs"):  # 支持取部分features
            X = X[:, self.x_idxs]
        y = self.ys[D_idx][i_y]
        w = self.ws[D_idx][i_fit_w]
        attr = self.attrs[D_idx][idx, :]
        all_y = self.ys[D_idx][i_all_y]
        return X, y, w, attr, all_y  # (T, F), float, float, (3,), (Y,)


def get_data_d_concat(dataset_config):
    dims = []
    Ss, Ds, Is = [], [], []

    x_xarr = read_sdiv_as_xr(dataset_config["x_files"])
    Ds.append(x_xarr.coords['D'].values)
    Ss.append(x_xarr.coords['S'].values)
    Is.append(x_xarr.coords['I'].values)
    x_names = x_xarr.coords['V'].values
    #print(x_xarr.D.values, x_xarr.shape)
    
    y_xarr = read_sdiv_as_xr(dataset_config["y_file"])
    Ds.append(y_xarr.coords['D'].values)
    Ss.append(y_xarr.coords['S'].values)
    Is.append(y_xarr.coords['I'].values)
    y_names = y_xarr.coords['V'].values
    #print(y_xarr.D.values, y_xarr.shape)

    w_xarr = read_sdiv_as_xr(dataset_config["w_file"])
    Ds.append(w_xarr.coords['D'].values)
    Ss.append(w_xarr.coords['S'].values)
    Is.append(w_xarr.coords['I'].values)
    w_names = w_xarr.coords['V'].values
    #print(w_xarr.D.values, w_xarr.shape)

    #assert all_arrays_equal(Ss) and all_arrays_equal(Ds) and all_arrays_equal(Is), "S, D and I coordinates don't match across files"
    #D, S, I = Ds[0], Is[0], Ss[0]

    dim = x_xarr.dims
    assert dim == y_xarr.dims
    assert dim == w_xarr.dims

    return x_xarr, y_xarr, w_xarr, x_names, y_names, w_names, dim


class TSDatasetDConcat(Dataset):
    def __init__(self, config, dates):
        self.kernel_size = config["kernel_size"]
        self.dilation = config["dilation"]
        self.getitem_mode = "xs" if config.get("dataset_type", "ts").lower() == "xs" else "sample"
        x_arr, y_arr, w_arr, x_names, y_names, w_names, dim = get_data_d_concat(config)
        assert dim == ('S', 'D', 'I', 'V')
        # print(f"{dates=}")
        assert (x_arr.S.values == y_arr.S.values).all() and (x_arr.S.values == w_arr.S.values).all()
        assert (x_arr.D.values == y_arr.D.values).all() and (x_arr.D.values == w_arr.D.values).all()
        assert (x_arr.I.values == y_arr.I.values).all() and (x_arr.I.values == w_arr.I.values).all()
        self.S, self.I = x_arr.S.values, x_arr.I.values
        self.allD = x_arr.D.values
        self.D = self.allD[(self.allD >= dates["start_date"]) & (self.allD <= dates["end_date"])]
        self.nD_before_this_set = len(self.allD[self.allD < dates["start_date"]])
        
        assert len(self.I) == 1, "This is a dataset for daily data"
        self.x_arr, self.y_arr, self.w_arr = x_arr.values.squeeze(2), y_arr.values.squeeze(2), w_arr.values.squeeze(2)  # (S, D, V)
        self.x_names, self.y_names, self.w_names = x_names, y_names, w_names
        self.attr_names = ["S", "D", "I"]
        
        self.fit_y_idx = np.where(y_names==config["fit_y"])[0][0]
        self.fit_w_idx = np.where(w_names==config["fit_w"])[0][0]
        assert "sampling_w" in config
        self.sampling_w_idx = np.where(w_names==config["sampling_w"])[0][0]
        self.sampling_by_month = config.get("sampling_by_month", False)

        self.nD, self.nS = len(self.D), len(self.S)
        self.bwindow = self.dilation * (self.kernel_size-1)  # backward looking window length, excluding current time point
        max_bwindow_in_data = len(self.allD[:bisect.bisect_left(self.allD, dates["start_date"])])
        self.nD_drop_in_this_set = max(0, self.bwindow-max_bwindow_in_data)

        if "use_x_names" in config:
            use_x_names = config["use_x_names"]  # 选择部分features，包括其顺序
            all_x_names = self.x_names.tolist()
            if not use_x_names == all_x_names:
                self.x_idxs = np.array([all_x_names.index(name) for name in use_x_names])  # order of terms matters in sequential learning
                self.x_names = np.array(use_x_names)

    def __len__(self):
        if self.getitem_mode == "sample":  # normal behavior
            return (self.nD - self.nD_drop_in_this_set) * self.nS
        elif self.getitem_mode == 'xs':  # 整个截面作为一个样本
            return self.nD - self.nD_drop_in_this_set

    def get_sampler(self, shuffle=True):
        if self.getitem_mode == 'xs':
            return None  # no sampler, dataloader will random sample as normal
        weights = [self.__getitem__(i, True) for i in range(len(self))]
        weights, attrs = list(zip(*weights))
        weights, attrs = np.array(weights), np.array(attrs)
        if self.sampling_by_month:
            sampler = BinarySamplerByMonth(weights, attrs, shuffle=shuffle)
        else:
            sampler = BinarySampler(weights, shuffle=shuffle)
        return sampler
    
    def __getitem__(self, idx, fetch_sampling_weight=False):
        if self.getitem_mode == "sample":  # normal behavior
            D_idx, S_idx = idx // self.nS, idx % self.nS
            D_idx += self.nD_before_this_set + self.nD_drop_in_this_set
            attr = np.array([self.S[S_idx], self.allD[D_idx], self.I[0]])

            if fetch_sampling_weight:
                return self.w_arr[S_idx, D_idx, self.sampling_w_idx], attr
            
            window_start_idx = D_idx - self.dilation * (self.kernel_size-1)
            # print(S_idx, D_idx, window_start_idx)
            X = self.x_arr[S_idx, window_start_idx: D_idx+1: self.dilation, :]
            if hasattr(self, "x_idxs"):  # 支持取部分features
                X = X[:, self.x_idxs]
            y = self.y_arr[S_idx, D_idx, self.fit_y_idx]    
            w = self.w_arr[S_idx, D_idx, self.fit_w_idx]
            all_y = self.y_arr[S_idx, D_idx, :]
        elif self.getitem_mode == 'xs':  # 整个截面作为一个样本
            D_idx = idx + self.nD_before_this_set + self.nD_drop_in_this_set
            sampling_weight = self.w_arr[:, D_idx, self.sampling_w_idx]  # (S,)
            S_idxs = (sampling_weight==1)  # 只考虑那些该sample的样本，一是不希望这些样本影响到其邻票；二是fit w中若未剔除这些样本，那么后续这些样本也会参与loss计算
            Ss, DI = self.S[S_idxs], np.array([self.allD[D_idx], self.I[0]])
            attr = np.hstack([Ss[:, None], np.tile(DI, (len(Ss), 1))])
            window_start_idx = D_idx - self.dilation * (self.kernel_size-1)
            X = self.x_arr[S_idxs, window_start_idx: D_idx+1: self.dilation, :]  # (S, T, F)
            if hasattr(self, "x_idxs"):  # 支持取部分features
                X = X[:, :, self.x_idxs]
            y = self.y_arr[S_idxs, D_idx, self.fit_y_idx]
            w = self.w_arr[S_idxs, D_idx, self.fit_w_idx]
            all_y = self.y_arr[S_idxs, D_idx, :]
        return X, y, w, attr, all_y  #  # (S, T, F), (S,), (S,), (S, 3), (S, Y)
    
class ConDataset(Dataset):
    def __init__(self, config, dates):
        # Read feature1, y1, w, and attributes
        data = self.get_data(config, dates)
        ws, xs, ys, w_names, x_names, y_names, dim, Ds, Is, Ss, attrs = data

        self.xs = xs  # list of length #dates
        self.ys = ys
        self.ws = ws
        self.dim = dim  # e.g. (D, I, S, V)
        self.Ds, self.Is, self.Ss = Ds, Is, Ss  # list of length #dates
        self.attrs = attrs  # for tabular dataset
        self.attr_names = ["D", "I", "S"]
        self.fit_w_idx = np.where(w_names == config["fit_w"])[0][0]
        self.fit_ws = [w[..., self.fit_w_idx] for w in self.ws]
        self.y_names = y_names
        self.x_names = x_names
        print(self.fit_ws[0].shape)
        if "sampling_w" in config:
            self.sampling_w_idx = np.where(w_names == config["sampling_w"])[0][0]
            self.sampling_ws = [w[..., self.sampling_w_idx] for w in self.ws]

        sample_num_list = [len(Is[i]) * len(Ss[i]) for i in range(len(Ds))]  # sample number per day
        self.sample_num_per_day = sample_num_list[0] if len(set(sample_num_list)) == 1 else None
        self.sample_daily_cumsum = np.cumsum(sample_num_list)

    def __len__(self):
        return self.sample_daily_cumsum[-1]

    def get_weighted_sampler(self):
        if not hasattr(self, "sampling_ws"):
            return None
        weights = [self.__getitem__(i, True) for i in range(len(self))]
        sampler = WeightedRandomSampler(weights=weights, num_samples=len(weights), replacement=True)
        return sampler

    def __getitem__(self, idx, fetch_sampling_weight=False):
        if self.sample_num_per_day is None:  # different sample number per day
            D_idx = bisect.bisect_right(self.sample_daily_cumsum, idx)
            if D_idx > 0:
                idx -= self.sample_daily_cumsum[D_idx - 1]
        else:
            D_idx, idx = idx // self.sample_num_per_day, idx % self.sample_num_per_day

        if fetch_sampling_weight:
            return self.sampling_ws[D_idx][idx]

        xs = self.xs[D_idx][idx, :]
        ys = self.ys[D_idx][idx, :]
        w = self.fit_ws[D_idx][idx]
        attr = self.attrs[D_idx][idx, :]

        return xs, ys, w, attr

    def get_data_oneday(self, config, date: str):
        flatten = config["dataset_type"].lower() == "tabular"
        dims = []
        Ss, Is = [], []

        w_xarr = read_sdiv_as_xr(config["w_file"].replace("YYYYMMDD", str(date)))
        dims.append(w_xarr.dims)
        Ss.append(w_xarr.coords['S'].values)
        Is.append(w_xarr.coords['I'].values)
        w_arr = reshape_arr(w_xarr.values, flatten, w_xarr.dims.index("D"))
        w_names = w_xarr.coords['V'].values

        feature1_xarr = read_sdiv_as_xr(config["x_file"].replace("YYYYMMDD", str(date)))
        dims.append(feature1_xarr.dims)
        Ss.append(feature1_xarr.coords['S'].values)
        Is.append(feature1_xarr.coords['I'].values)
        feature1_arr = reshape_arr(feature1_xarr.values, flatten, feature1_xarr.dims.index("D"))
        feature1_names = feature1_xarr.coords['V'].values

        y1_xarr = read_sdiv_as_xr(config["y_file"].replace("YYYYMMDD", str(date)))
        dims.append(y1_xarr.dims)
        Ss.append(y1_xarr.coords['S'].values)
        Is.append(y1_xarr.coords['I'].values)
        y1_arr = reshape_arr(y1_xarr.values, flatten, y1_xarr.dims.index("D"))
        y1_names = y1_xarr.coords['V'].values

        # 确保当天的所有x y w feature1 y1文件的dims以及S和I是一致的
        assert len(set(dims)) == 1, f"xarray.dims don't match for xyw feature1 y1 files on {date}"
        assert all_arrays_equal(Ss), f"S coordinate doesn't match for xyw feature1 y1 files on {date}"
        assert all_arrays_equal(Is), f"I coordinate doesn't match for xyw feature1 y1 files on {date}"
        dim = dims[0]
        D = date  # str
        S, I = Ss[0], Is[0]  # length: #symbol, #interval
        # 得到当天x的V维
        feature1_names = np.hstack(feature1_names)

        return w_arr, w_names, feature1_arr, y1_arr, feature1_names, y1_names, dim, D, I, S

    def get_data(self, config, dates: Union[Dict, List[str]]):
        common_dates = set(find_dates_from_pattern(config["y_file"]))
        common_dates = common_dates.intersection(find_dates_from_pattern(config["w_file"]))
        common_dates = common_dates.intersection(find_dates_from_pattern(config["x_file"]))
        all_dates = [str(d) for d in sorted(common_dates)]
        if isinstance(dates, Dict):
            dates = get_range(all_dates, dates["start_date"], dates["end_date"])
        else:
            dates_missing = [x for x in dates if x not in all_dates]
            assert len(dates_missing) == 0, f"missing dates {dates_missing} in {config['y_file']}"
        assert len(dates) > 0, "No valid dates"
        dims = []
        Ds, Ss, Is, Vs = [], [], [], []  # all list of length #dates
        ws, feature1s, y1s = [], [], []
        for date in tqdm(dates):
            data_oneday = self.get_data_oneday(config, date)
            w_arr, w_names, feature1_arr, y1_arr, feature1_names, y1_names, dim, D, I, S = data_oneday
            dims.append(dim)
            Ds.append(D)
            Ss.append(S)
            Is.append(I)
            Vs.append(np.hstack([w_names, feature1_names, y1_names]))
            ws.append(w_arr)
            feature1s.append(feature1_arr)
            y1s.append(y1_arr)
        
        assert len(set(dims)) == 1, "xarray.dims don't match among dates"  # 虽然mlp ds好像不一定要确保这个，但这个比较natural的事情还是assert一下以免发生奇奇怪怪的问题
        dim = dims[0]
        assert dim.index("V") == 3, "V should be at dim 3"  # 上面的flatten以及下面的getitem都依赖这一点
        assert all_arrays_equal(Vs), "V coordinate doesn't match among dates"
        if config["dataset_type"].lower() == "tabular":
            attrs = get_attrs(dim, Ds, Is, Ss)  # 对于tabular ds，x y w在get_data_oneday中被flatten为(DIS, V)，因此也生成一个flatten版本的attrs使得__getitem__统一且快速
        else:
            attrs = None
        if config["dataset_type"].lower() == "ts":
            assert all_arrays_equal(Ss) and all_arrays_equal(Is), "S and I coordinates don't match across dates for ts dataset"

        return ws, feature1s, y1s, w_names, feature1_names, y1_names, dim, Ds, Is, Ss, attrs

    def get_attrs(self, dim, Ds, Is, Ss):
        fast_changing_coord = dim[-2]  # left to V, either I or S
        attrs = []
        for i, date in enumerate(Ds):
            I_date, S_date = Is[i], Ss[i]
            D_array = np.array([date] * (len(I_date)*len(S_date)))
            if fast_changing_coord == "S":  # (D, I, S, V)
                I_array = np.repeat(I_date, len(S_date))
                S_array = np.tile(S_date, len(I_date))
            else:  # (D, S, I, V)
                S_array = np.repeat(S_date, len(I_date))
                I_array = np.tile(I_date, len(S_date))
            DIS_date = np.vstack([D_array, I_array, S_array]).T
            attrs.append(DIS_date)
        return attrs


