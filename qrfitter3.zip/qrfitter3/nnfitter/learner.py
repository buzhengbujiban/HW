import os
import inspect
import socket
from typing import Tuple, Dict, Optional
from collections import defaultdict
import numpy as np
import pandas as pd
import torch
from torch.utils.data.dataloader import DataLoader
from torch.utils.data import Dataset as TorchDataset
from torchinfo import summary
import inspect
from scipy.stats import zscore
from pytbl import tbl_write
from qrfitter3.evaluator import rcor, cor, pcor, fr, FR, PFR, evaluate

from qrfitter3.utils import *
from qrfitter3.nnfitter.train_utils import *
from qrfitter3.nnfitter.callbacks import *
NETWORK_ZOO_PATH = f"/data/nfshome/{os.environ['USER']}/git/qrfitter3/qrfitter3/nnfitter/network_zoo/network.py"


class MLPLearner:
    def __init__(self, config):
        self.config = config
        os.environ["CUDA_VISIBLE_DEVICES"] = self.config["device_id"]
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.output_dir = self.config["outdir"]
        self.batch_size = self.config.get("batch_size", 4096)
        self.dataloader_workers = self.config.get("dataloader_workers", 0)
        self.recorder = Recorder()
        self.my_collate_fn = my_collate_fn

    def _init_fot_fit(self):
        self.seed = self.config.get("seed", 3407)
        setup_seed(self.seed)
        self._update_config()
        os.makedirs(self.output_dir, exist_ok=True)
        save_json(self.config, os.path.join(self.output_dir, "updated_fitter_cfg.json"))  # 将该次实验的config存档
        os.chmod(os.path.join(self.output_dir, "updated_fitter_cfg.json"), 0o700)
        log_fn = os.path.join(self.output_dir, "train_log.log")
        self.logger = get_logger(log_fn, name=log_fn)
        os.chmod(log_fn, 0o700)
        self.logger.info(self.config)

        self.max_epoch = self.config["max_epoch"]
        self.eval_start_epoch = self.config["eval_start_epoch"]
        self.eval_fraction = self.config.get("eval_fraction", 1)
        if self.eval_fraction <= 0 or not isinstance(self.eval_fraction, int):
            raise ValueError("eval_fraction must be a positive integer")

    def _init_for_inference(self):
        log_fn = os.path.join(self.output_dir, "inference_log.log")
        self.logger = get_logger(log_fn, name=log_fn)
        os.chmod(log_fn, 0o700)
        self.logger.info(self.config)

    def _update_config(self):
        self.config['device'] = self.device
        self.config['seed'] = self.seed
        self.config['hostname'] = socket.gethostname()
        self.config['pid'] = os.getpid()

    def _init_model(self, dataset: TorchDataset, load_existing=False):
        # X = dataset.__getitem__(0)[0]  # shape (F,) for mlp input, should be (T, F) for ts input
        bs = 2 if self.batch_size > 1 else 1  # 兼容xs mode
        minibatch = self.my_collate_fn([dataset[idx] for idx in range(bs)])
        X, y, w = minibatch[:3]
        if "data_processing_config" in self.config:
            X, y, w = self._data_processing_step(self.config["data_processing_config"], X, y, w)  # 这个可能会改变X的形状
        model_class_name = self.config["model_config"]["class"]
        model_module_path = self.config["model_config"].get("module_path", NETWORK_ZOO_PATH)
        model_class = load_class(model_module_path, model_class_name)
        if load_existing:  # load model from same outdir, for inference purpose
            # self.model = torch.jit.load(self.model_path())
            self.model = torch.load(self.config.get("existing_model_path", self.model_path()))
            self.logger.info(f"Loaded model from {self.model_path()}")
        else:  # existing_model_path is for loading the whole exact same model; share_model_path is for partilly loading some blocks
            if "existing_model_path" in self.config:
                existing_model_path = self.config["existing_model_path"]
                self.model = torch.load(existing_model_path)
                self.logger.info(f"Loaded model from {existing_model_path}")
            else:
                model_param = self.config["model_config"]["kwargs"]
                model_param["input_size"] = X.shape[-1]
                self.model = model_class(**model_param)
                if "share_model_path" in self.config:
                    share_model_path = self.config["share_model_path"]  # dict: e.g. {"head0": {"path": "folder0/model.pt", "name": "head"}, "output_layer": "folder/model.pt"}
                    for submodule_name, source_module_path in share_model_path.items():
                        if isinstance(source_module_path, dict):
                            source_module = getattr(torch.load(source_module_path["path"]), source_module_path["name"])
                        else:
                            source_module = torch.load(source_module_path)
                        setattr(self.model, submodule_name, source_module)
                    if hasattr(self.model, "init_after_load_share"):  # 有些model在load share之后需要进行一些处理
                        self.logger.info(f"init_after_load_share")
                        self.model.init_after_load_share()  # 自行在init_after_load_share决定哪些部分需要grad以应对更复杂的情况
                    self.logger.info(f"Load share model from {share_model_path}")
                        
        self.model.to(self.device)
        try:
            # input_size = X.shape if self.batch_size == 1 else (self.batch_size,)+X.shape  # 兼容xs
            input_size = X.shape
            self.logger.info(summary(self.model, input_size=input_size, verbose=0))
        except Exception as e:
            print("X.shape", X.shape)
            for name, param in self.model.named_parameters():
                if param.requires_grad:
                    print(f"Parameter name: {name}, Shape: {param.shape}")
            raise(e)
        self.input_size = X.shape[-1]
        self.feature_names = dataset.x_names.tolist()
        self.y_names = dataset.y_names[dataset.fit_y_idx]

    def _configure_callback(self):
        self.callbacks = list()
        self.callbacks.append(SpeedProfilerCallback())
        if self.config.get("enable_tensorboard", True):
            self.callbacks.append(TensorboardCallback(os.path.join(self.output_dir, "tensorboard"), logtest=self.config.get("evaltest", False)))
        if self.config.get("earlystop_config", {}) and self.config["earlystop_config"]["enable"]:
            del self.config["earlystop_config"]["enable"]
            self.callbacks.append(EarlyStopCallback(**self.config["earlystop_config"]))
        if self.config.get("swa_config", {}) and self.config["swa_config"]["enable"]:
            del self.config["swa_config"]["enable"]
            self.callbacks.append(SWACallback(**self.config["swa_config"]))
            self.swa_model = None
        if self.config.get("randomrestart_config", {}) and self.config["randomrestart_config"]["enable"]:
            del self.config["randomrestart_config"]["enable"]
            self.callbacks.append(RandomRestartCallback(**self.config["randomrestart_config"]))

    def model_path(self, save_folder:str=None, name='model', type="pt"):
        if save_folder is None:
            save_folder = self.output_dir
        os.makedirs(save_folder, exist_ok=True)
        return os.path.join(save_folder, f"{name}.{type}")

    def save_model(self, dataset:TorchDataset, save_folder:str=None, name='model'):
        self.logger.info(f"Saving model.")
        self.model.eval().cpu()
        try:
            print("saving self.model...")
            model_path = self.model_path(save_folder=save_folder, name=name, type="pt")
            torch.save(self.model, model_path)
            os.chmod(model_path, 0o700)
        except Exception as e:
            print(f"torch.save error: {e}")
            print("saving self.model.state_dict()...")
            model_path = self.model_path(save_folder=save_folder, name=name, type="pth")
            torch.save(self.model.state_dict(), model_path)
            os.chmod(model_path, 0o700)
        try:
            print("saving onnx...")
            example_input = torch.randn(1, self.input_size)
            model_onnx_path = self.model_path(save_folder=save_folder, name=name, type="onnx")
            torch.onnx.export(
                self.model,                # PyTorch 模型
                example_input,        # 示例输入张量
                model_onnx_path,         # 导出的 ONNX 文件名
                export_params=True,   # 导出模型参数
                input_names=['input'],    # 模型输入名称（可选）
                output_names=['output'],  # 模型输出名称（可选）
                dynamic_axes={'input': {0: 'batch_size'},  # 动态轴的定义
                            'output': {0: 'batch_size'}},
                verbose=True
            )
            os.chmod(model_onnx_path, 0o700)
        except Exception as e:  # 有时候onnx不work
            print(f"onnx error: {e}")
        self.model.to(self.device)
        self.model.train()
    
    def save_share_model(self, name='share_model'):
        self.logger.info(f"Saving share_model.")
        self.model.share_model.eval()
        try:
            torch.save(self.model.share_model, self.model_path(name=name))
        except Exception as e:
            print(e)
            torch.save(self.model.share_model.state_dict(), os.path.join(self.output_dir, "share_model.pth")) 

    def _configure_optimizer(self):
        optimizer, optimizer_para = self.config.get("optimizer", ["Adam", {}])
        params_optimizer_config = self.config.get("params_optimizer_config", None)  # e.g. {"layer1": {"lr": 0.001, "weight_decay": 1}}
        if params_optimizer_config is None:
            if self.config.get("norm_no_decay", False):
                no_decay = []
                decay = []
                for name, param in self.model.named_parameters():
                    if "norm.weight" in name or "norm.bias" in name or "BN_" in name:  # 需要自行在network中给normalization层起名为norm
                        no_decay.append(param)
                    else:
                        decay.append(param)
                params = [{'params': decay}, {'params': no_decay, 'weight_decay': 0.0}]
            else:
                params = self.model.parameters()
        else:
            params = []
            for module, optimizer_config in params_optimizer_config.items():
                optimizer_config.update({'params': getattr(self.model, module).parameters()})
                params.append(optimizer_config)
            other_params = [param for name, param in self.model.named_parameters() if name.split(".")[0] not in params_optimizer_config]
            params.append({'params': other_params})
        self.optimizer = getattr(torch.optim, optimizer)(
            params=params,
            lr=float(self.config["learning_rate"]),
            weight_decay=float(self.config["l2_decay"]),
            **optimizer_para
        )
        # print(self.optimizer.state_dict())
        self.lr_scheduler = get_lr_scheduler(
            self.optimizer, *self.config.get("lr_scheduler", (None, None))
        )
        self.logger.info(f"{self.lr_scheduler=}")

    def _init_w_field(self):  # FIXME: call it somewhere
        self.w_field = self.config.get("w_field", None)
        if self.w_field is not None:
            self.w_field = torch.tensor(self.w_field, device=self.device)

    def _configure_loss(self):
        self.loss_fn = get_loss_function(*self.config["loss_fn"])
        # self.loss_fn.to(self.device)  # Some loss functions may have parameter tensors. Yet it makes no difference for functions like MSE
        self._init_w_field()

    def _get_dataloader(self, dataset: TorchDataset, set_name: str):
        self.logger.info(f"{set_name}: {len(dataset)=}")
        is_trainset = (set_name.lower() == 'train')
        batch_size = self.batch_size
        batch_sampler = None
        sampler = None
        shuffle = is_trainset

        enable_sampler_on_datasets = self.config.get("enable_sampler_on_datasets", ["train", "valid"])  # note: valid or test may not need sampler, it depends
        if set_name.lower() in enable_sampler_on_datasets:
            if hasattr(dataset, "get_batch_sampler"):
                batch_sampler = dataset.get_batch_sampler(self.batch_size, shuffle=is_trainset)
                batch_size = 1
                sampler = None
                shuffle = False  # shuffling is supposed to be done in batch_sampler
                self.logger.info(f"{set_name} set batch num at batch_sampler : {len(batch_sampler)}")
            elif hasattr(dataset, "get_sampler"):
                sampler = dataset.get_sampler(shuffle=is_trainset)
                if sampler is not None:
                    shuffle = False  # shuffling is supposed to be done in sampler
                    self.logger.info(f"{set_name} set size at sampler : {len(sampler)}")
        dataloader = DataLoader(
            dataset=dataset, batch_size=batch_size, shuffle=shuffle, batch_sampler=batch_sampler, sampler=sampler,
            num_workers=self.dataloader_workers, collate_fn=self.my_collate_fn
        )  # pin_memory主要加快了to.device但使得get_data变慢了。prefetch_factor在num_workers>0时默认是2，但卡点在get_data时这个没用
        return dataloader

    def _data_processing_step(self, config, X, y, w, is_inference=False):
        pass

    def _train_step(self, minibatch, step):
        """Return train loss after finishing one step train"""
        X, y, w, attr = minibatch[:4]
        t0 = time.time()
        X, y, w = X.to(self.device), y.to(self.device), w.to(self.device)
        t1 = time.time()
        if "data_processing_config" in self.config:
            X, y, w = self._data_processing_step(self.config["data_processing_config"], X, y, w)
        if self.config.get("require_last_hidden", False):
            pred, last_hidden = self.model(X, require_last_hidden=True)
        else:
            pred = self.model(X)
        param_names = inspect.signature(self.loss_fn.forward).parameters.keys()
        kwargs = {}
        if "w_field" in param_names:
            kwargs["w_field"] = self.w_field
        if "attr" in param_names:
            kwargs["attr"] = attr
        if "last_hidden" in param_names:
            kwargs["last_hidden"] = last_hidden
        loss = self.loss_fn(pred, y, w, **kwargs)
        if isinstance(loss, dict):
            loss_dict = loss
            loss = loss_dict.pop("loss")
            for key, value in loss_dict.items():
                self.recorder.LogStep(f"train/{key}", value.cpu().item())
        if "input_l1_alpha" in self.config:
            assert isinstance(self.model, load_class(NETWORK_ZOO_PATH, "MLP3")), f"model type: {type(self.model)} not supported for input layer L1"
            l1_alpha = self.config["input_l1_alpha"]
            l1_reg = l1_alpha * torch.norm(self.model.layers[0].block.linear.weight, p=1)
            self.recorder.LogStep("train/l1_loss", l1_reg.cpu().item())
            self.recorder.LogStep("train/emp_loss", loss.cpu().item())
            loss += l1_reg
        self.optimizer.zero_grad()
        loss.backward()
        if self.config.get("clip_grad_norm", False):
            torch.nn.utils.clip_grad_norm_(
                self.model.parameters(),
                max_norm=5.0,    # 推荐值范围：1.0-5.0
                norm_type=2      # L2范数
            )
        self.optimizer.step()
        t2 = time.time()

        self.recorder.LogStep("train/loss", loss.cpu().item())
        todevice, forwardbackward = t1-t0, t2-t1
        return todevice, forwardbackward

    def _valid_step(self, dataset: TorchDataset, set_name: str, context: dict):
        yhat_df, metrics = self.predict(dataset, set_name=set_name)
        eval_metrics = self.evaluate(yhat_df)
        eval_metrics.update(metrics)
        for key, value in eval_metrics.items():
            key = key if set_name is None else f"{set_name}/{key}"
            self.recorder.LogEpoch(key, value)
        context[f'{set_name}/yhat'] = yhat_df.loc[yhat_df['weight']>0, 'yhat'].values  # 避免涨跌停样本对分布图的干扰
        if self.config.get("save_yhat_every_epoch", False):
            save_folder = os.path.join(self.output_dir, "yhat", f"epoch{context['epoch']}")
            save_df_as_sdiv_daily(yhat_df, save_folder, fn="yhat")
        if self.config.get("save_model_every_epoch", True):
            self.save_model(dataset, save_folder=os.path.join(self.output_dir, "epoch_models"), name=f"model.epoch{context['epoch']}")

    def fit(self, train_dataset: TorchDataset, valid_dataset: TorchDataset, test_dataset: Optional[TorchDataset]=None):
        self._configure_loss()
        self._configure_optimizer()
        self._configure_callback()
        train_dataloader = self._get_dataloader(train_dataset, set_name="train")

        for callback in self.callbacks:
            callback.BeforeTrain(self)

        if self.config.get("evalvalid_onstart", False):  # 训练开始之前看下valid上的results，对于一些load init模型比较有用
            self._valid_step(valid_dataset, set_name='valid', context=dict())
            self.logger.info(f"evaluation results: {self.recorder.ToString()}")
            self.recorder.Clear()

        step = 0
        steps_per_epoch = len(train_dataloader)
        eval_intervals = [round(steps_per_epoch * i / self.eval_fraction) for i in range(self.eval_fraction)]
        
        continue_flag = True
        for epoch in range(1, self.max_epoch+1):  # epoch和step都是从1开始计数
            self.logger.info(
                f"------------Train Epoch {epoch} / {self.max_epoch}----------------"
            )
            self.logger.info(f"lr: {self.optimizer.param_groups[0]['lr']}")
            context = dict()  # reset context every epoch
            context["epoch"] = epoch
            for callback in self.callbacks:
                callback.BeforeEpoch(self, context, epoch)

            self.model.train()
            get_data_time = 0
            train_step_time = 0
            todevice_time, forwardbackward_time = 0, 0
            train_it = iter(train_dataloader)  # __iter__ of sampler/batch_sampler will be called internally
            while True:
                try:
                    t0 = time.time()
                    minibatch = next(train_it)
                    t1 = time.time()
                    get_data_time += t1- t0
                except StopIteration:
                    break
                else:
                    step += 1
                    t2 = time.time()
                    todevice, forwardbackward = self._train_step(minibatch, step)
                    t3 = time.time()
                    train_step_time += t3 - t2
                    todevice_time += todevice
                    forwardbackward_time += forwardbackward

                    for callback in self.callbacks:
                        callback.AfterStep(self, dict(), step)

                    """ Evaluation after training """
                    if step % steps_per_epoch in eval_intervals:
                        t4 = time.time()
                        self._valid_step(valid_dataset, set_name='valid', context=context)
                        if self.config.get("evaltrain", False):
                            self._valid_step(train_dataset, set_name='train', context=context)
                        if self.config.get("evaltest", False) and test_dataset is not None:
                            self._valid_step(test_dataset, set_name='test', context=context)
                        t5 = time.time()
                        valid_time = t5 - t4

                        """ Print Log generated from training and evaluating """
                        self.recorder.Accumulate()
                        self.logger.info(f"step: {step}, evaluation results: {self.recorder.ToString()}")
                        self.model.train()
                        context["train_dataset"] = train_dataset
                        for callback in self.callbacks:
                            continue_flag = continue_flag and callback.AfterEval(
                                self, context, epoch, step  # tensorboard会记录本轮的学习率
                            )

            context["get_data_time"] = get_data_time
            context["train_step_time"] = train_step_time
            context["todevice_time"] = todevice_time
            context["forwardbackward_time"] = forwardbackward_time
            context["valid_time"] = valid_time
            for callback in self.callbacks:
                callback.AfterEpochTrain(self, context, epoch)
            
            """ Post Epoch """
            if not context.get("optimizer_reinitialized", False):  # RandomRestartCallback会重置optimizer和lr_scheduler
                if self.config.get("scheduler_listen", False):
                    self.lr_scheduler.step(self.recorder.from_epoch[self.config["scheduler_listen"]])
                else:
                    self.lr_scheduler.step()  # step后的学习率用在下一轮

            """ Execute callback AfterEpoch() """
            for callback in self.callbacks:
                callback.AfterEpoch(self, context, epoch)
            
            self.recorder.Clear()

            # stop training due to early stop
            if not continue_flag:
                break

        for callback in self.callbacks:
            if isinstance(callback, SWACallback):
                context = {'loader': train_dataloader}
            else:
                context = None
            callback.AfterTrain(self, context=context)

        del train_dataloader
        if self.device == "cuda":
            torch.cuda.empty_cache()

    def predict(self, dataset: TorchDataset, set_name: Optional[str]='test') -> pd.DataFrame:
        self.model.eval()  # enter eval mode, e.g. batchnorm should stop learning parameter and dropout layers should stop dropping neurons
        dataloader = self._get_dataloader(dataset, set_name=set_name)
        pred_list = []
        label_list = []
        weight_list = []
        attr_list = []
        last_hidden_list = []
        # all_y_list = []
        metric_list = defaultdict(list)
        with torch.no_grad():  # don't need to calculate gradients in evaluation
            for step, minibatch in enumerate(dataloader):
                X, y, w, attr, all_y = minibatch
                X, y, w = X.to(self.device), y.to(self.device), w.to(self.device)
                if "data_processing_config" in self.config:
                    X, y, w = self._data_processing_step(self.config["data_processing_config"], X, y, w, is_inference=True)
                pred = self.model(X).cpu()
                if self.config.get("require_last_hidden", False):
                    pred, last_hidden = self.model(X, require_last_hidden=True)
                    pred, last_hidden = pred.cpu(), last_hidden.cpu()
                    last_hidden_list.append(last_hidden)
                else:
                    pred = self.model(X).cpu()
                y, w = y.cpu(), w.cpu()
                pred_list.append(pred)
                label_list.append(y)
                weight_list.append(w)
                attr_list.append(attr)
                # all_y_list.append(all_y)
                param_names = inspect.signature(self.loss_fn.forward).parameters.keys()
                kwargs = {}
                if "w_field" in param_names:
                    kwargs["w_field"] = self.w_field
                if "attr" in param_names:
                    kwargs["attr"] = attr
                if "last_hidden" in param_names:
                    kwargs["last_hidden"] = last_hidden
                loss = self.loss_fn(pred, y, w, **kwargs)
                if isinstance(loss, dict):
                    loss_dict = loss
                    for key, value in loss_dict.items():
                        metric_list[key].append(value.item())
                else:
                    metric_list['loss'].append(loss.item())
        if pred_list[0].dim() == 1:  # normal yhat
            pred = torch.hstack(pred_list).numpy()
        else:  # multi-output
            pred = torch.vstack(pred_list).numpy()
        if label_list[0].dim() == 1:  # single label
            label = torch.hstack(label_list).numpy()
        else:  # multi label
            label = torch.vstack(label_list).numpy()
        weight = torch.hstack(weight_list).numpy()
        attr = np.vstack(attr_list)
        # all_y = torch.vstack(all_y_list).numpy()
        metrics = {key: np.mean(value_list) for key, value_list in metric_list.items()}

        yhat_df = pd.DataFrame(attr, columns=dataset.attr_names)
        if pred.ndim == 1:
            yhat_df['yhat'] = pred
        else:
            pred_df = pd.DataFrame(pred, columns=[f"pred_{i}" for i in range(pred.shape[1])])
            yhat_df = pd.concat([yhat_df, pred_df], axis=1)
        if label.ndim == 1:  # temp for single yhat multi y
            yhat_df['y'] = label
        else:
            for i, name in enumerate(self.y_names):
                yhat_df[f'y_{name}'] = label[:, i]
        yhat_df['weight'] = weight
        # all_y_df = pd.DataFrame(all_y, columns=dataset.y_names)  
        # yhat_df = pd.concat([yhat_df, all_y_df], axis=1)  # do not save all y for saving strorage
        if len(last_hidden_list) > 0:
            last_hidden = torch.vstack(last_hidden_list).numpy()
            last_hidden_df = pd.DataFrame(last_hidden, columns=[f"hidden_{i}" for i in range(last_hidden.shape[1])])
            yhat_df = pd.concat([yhat_df, last_hidden_df], axis=1)
        del dataloader
        if self.device == "cuda":
            torch.cuda.empty_cache()

        return yhat_df, metrics

    def evaluate(self, yhat_df: pd.DataFrame, D="D") -> dict:
        if self.config.get("xsclip_yhat", False):
            xsclip_yhat(yhat_df)
        if self.config.get("xszscore_yhat", False):
            yhat_df = xszscore_yhat(yhat_df, p=self.config.get("xszscore_p", 5))
        res = evaluate(yhat_df, self, D=D)
        return res
    
    def save_yhat(self, dataset: TorchDataset, set_name: str):
        self.logger.info(f"Predicting {set_name} set.")
        yhat_df, metrics = self.predict(dataset, set_name=set_name)
        eval_metrics = self.evaluate(yhat_df)
        eval_metrics.update(metrics)
        for key, value in eval_metrics.items():
            self.recorder.LogEpoch(key, value)
        self.logger.info(f"{set_name} set: {self.recorder.ToString()}")
        self.recorder.Clear()
        save_folder = self.config.get("save_yhat_folder", os.path.join(self.output_dir, "yhat"))
        if set_name in self.config.get("save_yhat_sets", []): # to save storage
            save_df_as_sdiv_daily(yhat_df, save_folder, fn="yhat")
        return eval_metrics

    def interpret(self, datasets: Dict[str, TorchDataset]):
        if self.config.get("interpret", False):
            # self._dump_feature_importance(datasets['valid'], 'valid')
            pass

    def save_feature_names(self):
        path = os.path.join(self.output_dir, "feature_names.json")
        save_json(self.feature_names, path)
        os.chmod(path, 0o700)
    
    def run(self, datasets: Dict[str, TorchDataset]):
        self._init_fot_fit()
        self._init_model(datasets['train'])
        self.save_feature_names()
        self.fit(datasets['train'], datasets['valid'], datasets.get('test', None))
        if hasattr(self, "swa_model"):
            assert self.swa_model is not None, "No swa_model"
            self.model = self.swa_model
        self.save_model(datasets['train'])
        if self.config.get("save_share_model", False):
            self.save_share_model()
        set_results = {}
        for set_name, dataset in datasets.items():
            eval_metrics = self.save_yhat(dataset, set_name)
            set_results[set_name] = eval_metrics
        set_results = pd.DataFrame(set_results).T.reset_index(names=["set"])
        set_results_path = os.path.join(self.output_dir, "set_results.tbl")
        tbl_write(set_results, path=set_results_path)
        os.chmod(set_results_path, 0o700)
        self.interpret(datasets)
        if self.config.get("inference_last_hidden", False):
            self.run_inference_last_hidden(dataset=datasets['test'])
        
        self.logger.info(f"The End. expt_name: {self.config['expt_name']}")
    
    def run_inference(self, datasets: Dict[str, TorchDataset]):
        """can be called independently from run()"""
        self._init_for_inference()
        self._init_model(list(datasets.values())[0], load_existing=True)
        self._configure_loss()  # inference may need loss for evaluate
        for set_name, dataset in datasets.items():
            self.save_yhat(dataset, set_name)

    def run_inference_last_hidden(self, datasets: Dict[str, TorchDataset]):
        """can be called independently from run()"""
        self._init_for_inference()
        self.logger.info("Running inference last hidden")
        self._init_model(list(datasets.values())[0], load_existing=True)
        self.model.get_last_hidden = True
        for set_name, dataset in datasets.items():
            yhat, _ = self.predict(dataset)
            save_folder = os.path.join(self.output_dir, f"y_hat_{set_name}")
            save_df_as_sdiv_daily(yhat, save_folder, fn="yhat")
        self.model.get_last_hidden = False


class MultiTargetLearner(MLPLearner):

    def __init__(self, config):
        super(MultiTargetLearner, self).__init__(config)
        self.my_collate_fn = my_collate_fn

    def _init_model(self, dataset: TorchDataset, load_existing=False):
        X = dataset.__getitem__(0)  # shape (F,) for mlp input, should be (T, F) for ts input
        feature1_dim = X[0].shape[-1]
        output_size = X[1].shape[-1]
        # print(feature1_dim, feature2_dim, output_size)
        # sys.exit(0)
        if self.config.get("load_model_path", None):
            self.model = torch.load(self.config.get("load_model_path", None))
        else:
            model_class, model_param = self.config["model_config"]["class"], self.config["model_config"]["kwargs"]
            model_module_path = self.config["model_config"].get("module_path", NETWORK_ZOO_PATH)
            model_param["input_size"] = feature1_dim
            model_param["output_size"] = output_size
            self.model = load_class(model_module_path, model_class)(**model_param)
            # print(model_param)
            if self.share_model_path:
                loaded_share_model = torch.load(self.share_model_path)
                self.model.share_model.load_state_dict(loaded_share_model.state_dict())
                self.logger.info(f"Load share model from {self.share_model_path}")

        if "share_model_require_grad" in self.config:    
            for param in self.model.share_model.parameters():
                        param.requires_grad = self.share_model_require_grad
            # print(self.share_model_require_grad)
            # for name, param in self.model.share_model.named_parameters():
            #     print(f"{name}: {param.requires_grad}")
            # sys.exit()
    
        self.model.to(self.device)
        self.logger.info(summary(self.model, input_size=(self.batch_size,)+X[0].shape, verbose=0))
        self.output_size = output_size
        self.y_names = dataset.y_names[dataset.fit_y_idx]


    def save_share_model(self, name='share_model'):
        self.logger.info(f"Saving share model.")
        self.model.share_model.eval()
        try:
            torch.save(self.model.share_model, self.model_path(name=name))
        except Exception as e:
            print(e)
            torch.save(self.model.share_model.state_dict(), os.path.join(self.output_dir, "model.pth")) 
        
    def _configure_optimizer(self):
        optimizer, optimizer_para = self.config.get("optimizer", ["Adam", {}])
        params = [{'params': self.model.parameters()}]
        if self.config["loss_fn"][0] == "uncw":
            params.append({'params': self.loss_fn.parameters(), 'weight_decay': 0})

        self.optimizer = getattr(torch.optim, optimizer)(
            params=params,
            lr=float(self.config["learning_rate"]),
            weight_decay=float(self.config["l2_decay"]),
            **optimizer_para
        )
        self.lr_scheduler = get_lr_scheduler(
            self.optimizer, *self.config.get("lr_scheduler", (None, None))
        )

    def _configure_loss(self):
        self.loss_fn = get_loss_function(*self.config["loss_fn"])
        loss_plen = len(inspect.signature(self.loss_fn.forward).parameters)
        self.loss_require_w = True if loss_plen >= 3 else False  # 留一些灵活性给那些不接受weight的loss_fn
        self.loss_fn.to(self.device)  # Some loss functions may have parameter tensors. Yet it makes no difference for functions like MSE
        self.w_field = self.config.get("w_field", None)
        if self.w_field is not None:
            # assert len(self.w_field)==self.output_size
            self.w_field = torch.tensor(self.w_field, device=self.device)
        print(f"---------{self.loss_fn}------------")
        # sys.exit()

    def _valid_step(self, dataset: TorchDataset, set_name: str, context: dict):
        yhat_df = self.predict(dataset)
        eval_metrics = self.evaluate(yhat_df)

        for key, value in eval_metrics.items():
            key = key if set_name is None else f"{set_name}/{key}"
            self.recorder.LogEpoch(key, value)
        
        return yhat_df

    def _train_step(self, minibatch, step):
        """Return train loss after finishing one step train"""
        # self.logger.info(f"{self.w_field}")
        feature1, y1, w = minibatch[0], minibatch[1], minibatch[2]

        t0 = time.time()
        feature1, y1, w = feature1.to(self.device), y1.to(self.device),  w.to(self.device)
        t1 = time.time()
        
        pred1 = self.model(feature1) 

        if self.loss_require_w:
            loss = self.loss_fn(pred1, y1, w, self.w_field)
        else:
            loss = self.loss_fn(pred1, y1)

        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        t2 = time.time()

        self.recorder.LogStep("train/loss", loss.cpu().item())
        todevice, forwardbackward = t1-t0, t2-t1
        return todevice, forwardbackward


    def predict(self, dataset: TorchDataset) -> pd.DataFrame:
        self.model.eval()
        dataloader = DataLoader(
            dataset=dataset, batch_size=self.batch_size, shuffle=False,
            num_workers=self.dataloader_workers, collate_fn=self.my_collate_fn
        )
        pred_list = []
        label_list = []
        weight_list = []
        attr_list = []
        with torch.no_grad():
            for step, minibatch in enumerate(dataloader):
                feature, y, w, attr, _ = minibatch
                pred = self.model(feature.to(self.device))
                pred = pred.cpu() 
                pred_list.append(pred)
                label_list.append(y.cpu())
                weight_list.append(w)
                attr_list.append(attr)
        pred = torch.vstack(pred_list).numpy()
        label = torch.vstack(label_list).numpy()
        weight = torch.hstack(weight_list).numpy()
        attr = np.vstack(attr_list)

        yhat_df = pd.DataFrame(attr, columns=dataset.attr_names)
        for i, name in enumerate(self.y_names):
            yhat_df[f'yhat_{name}'] = pred[:, i]
            yhat_df[f'y_{name}'] = label[:, i]
        yhat_df['weight'] = weight

        del dataloader
        if self.device == "cuda":
            torch.cuda.empty_cache()

        return yhat_df

    def evaluate(self, yhat_df: pd.DataFrame) -> dict:
        res = dict()
        total_cor = 0

        yhat = np.column_stack([yhat_df[f'yhat_{name}'].values for name in self.y_names])
        y = np.column_stack([yhat_df[f'y_{name}'].values for name in self.y_names])
        w = yhat_df['weight'].values

        if hasattr(self, "loss_fn"):
            args = (yhat, y, w) if self.loss_require_w else (yhat, y)
            res["loss"] = round(self.loss_fn.cpu()(*[torch.from_numpy(arg) for arg in args]).item(), 10)

        # Clipping and z-score normalization for groups based on 'I' and 'D'
        def clip_and_zscore(group):
            clipped_group = group.copy()
            for col in group.columns:
                if col not in ['I', 'D', 'weight'] and ('yhat_' in col):
                    values = group[col].values
                    lower_percentile = np.percentile(values, 5)
                    upper_percentile = np.percentile(values, 95)
                    clipped_values = np.clip(values, lower_percentile, upper_percentile)
                    clipped_group[col] = zscore(clipped_values)
            return clipped_group

        yhat_df = yhat_df.groupby(['I', 'D']).apply(clip_and_zscore).reset_index(drop=True)
        self.loss_fn.to(self.device)
        for name in self.y_names:
            x = yhat_df[f'yhat_{name}'].values
            y = yhat_df[f'y_{name}'].values
            w = yhat_df['weight'].values
            
            cor_value = cor(x, y, w)
            res[f"cor_{name}"] = round(cor_value, 1)
            res[f"FR_{name}"] = round(FR(x, y, w), 1)
            if pd.__version__ == '2.2.0':
                xy_series = yhat_df.groupby("D").apply(lambda df: (df[f"yhat_{name}"]*df[f"y_{name}"]).mean(), include_groups=False)
            else:
                xy_series = yhat_df.groupby("D").apply(lambda df: (df[f"yhat_{name}"]*df[f"y_{name}"]).mean())
            res[f"SR_{name}"] = round(xy_series.mean() / xy_series.std() * np.sqrt(252), 1)
            total_cor += cor_value
        
        res["mean_cor"] = round(total_cor / len(self.y_names), 1)
        return res
    
    def run(self, datasets: Dict[str, TorchDataset]):
        self._init_fot_fit()
        self._init_model(datasets['train'])
        self.fit(datasets['train'], datasets['valid'], datasets['test'])
        if hasattr(self, "swa_model"):
            assert self.swa_model is not None, "No swa_model"
            self.model = self.swa_model
        self.save_model()
        if self.config.get("save_share_model", False):
            self.save_share_model()
        self.save_feature_names()
        for set_name, dataset in datasets.items():
            self.save_yhat(dataset, set_name)
        self.interpret(datasets)
        if self.config.get("inference_last_hidden", False):
            self.run_inference_last_hidden(dataset=datasets['test'])
        
        self.logger.info(f"The End. expt_name: {self.config['expt_name']}")

class GradnormLearner(MultiTargetLearner):

    def _configure_optimizer(self):
        optimizer, optimizer_para = self.config.get("optimizer", ["Adam", {}])
        params = [{'params': self.model.parameters()}]
        if self.config["loss_fn"][0] in ["uncw", "gradn"]:
            params.append({'params': self.loss_fn.parameters(), 'weight_decay': 0})

        self.optimizer = getattr(torch.optim, optimizer)(
            params=params,
            lr=float(self.config["learning_rate"]),
            weight_decay=float(self.config["l2_decay"]),
            **optimizer_para
        )
        self.lr_scheduler = get_lr_scheduler(
            self.optimizer, *self.config.get("lr_scheduler", (None, None))
        )

    def _configure_loss(self):
        self.loss_fn = get_loss_function(*self.config["loss_fn"])
        loss_plen = len(inspect.signature(self.loss_fn.forward).parameters)
        self.loss_require_w = True if loss_plen >= 3 else False  # 留一些灵活性给那些不接受weight的loss_fn
        self.loss_fn.to(self.device)  # Some loss functions may have parameter tensors. Yet it makes no difference for functions like MSE
        self.w_field = self.config.get("w_field", None)
        if self.w_field is not None:
            # assert len(self.w_field)==self.output_size
            self.w_field = torch.tensor(self.w_field, device=self.device)
        print(self.loss_fn.weights)
        # sys.exit()


    def _train_step(self, minibatch, step):
        """Return train loss after finishing one step train"""
        feature1, y1, w = minibatch[0], minibatch[1], minibatch[2]

        t0 = time.time()
        feature1, y1, w = feature1.to(self.device), y1.to(self.device),  w.to(self.device)
        t1 = time.time()
        
        pred1 = self.model(feature1) 

        task_loss, loss = self.loss_fn(pred1, y1)

        if self.epoch == 1 and step==1:
            # set L(0)
            if torch.cuda.is_available():
                self.initial_task_loss = task_loss.data.cpu()
            else:
                self.initial_task_loss = task_loss.data
            self.initial_task_loss = self.initial_task_loss.numpy()
            self.last1_task_loss = task_loss
            self.last2_task_loss = task_loss

        self.optimizer.zero_grad()
        if self.config["loss_fn"][0] == "dwa":
            # Compute the weighting lambda_k(t) for DWA
            with torch.no_grad():
                train_rate = self.last1_task_loss / self.last2_task_loss
                exp_train_rate = torch.exp(train_rate / self.config.get("dwa_temperature", 1))
                weights = len(task_loss) * exp_train_rate / torch.sum(exp_train_rate)
                weights = weights / torch.sum(weights) * len(task_loss)
                self.last2_task_loss = self.last1_task_loss
                self.last1_task_loss = task_loss
                self.loss_fn.weights = weights
            loss = torch.sum(torch.mul(weights, task_loss))
            loss.backward()

            self.optimizer.step()

        elif self.config["loss_fn"][0] == "gradn":
            loss.backward(retain_graph=True)
            self.loss_fn.weights.grad.data = self.loss_fn.weights.grad.data * 0.0

            W = self.model.share_model.get_last_share_layer()
            norms = []
            for i in range(len(task_loss)):
                # get the gradient of this task loss with respect to the shared parameters
                gygw = torch.autograd.grad(task_loss[i], W.parameters(), retain_graph=True)
                # compute the norm
                norms.append(torch.norm(torch.mul(self.loss_fn.weights[i], gygw[0])))
            norms = torch.stack(norms)

            if torch.cuda.is_available():
                loss_ratio = task_loss.data.cpu().numpy() / self.initial_task_loss
            else:
                loss_ratio = task_loss.data.numpy() / self.initial_task_loss

            # r_i(t)
            inverse_train_rate = loss_ratio / np.mean(loss_ratio)
            #print('r_i(t): {}'.format(inverse_train_rate))


            # compute the mean norm \tilde{G}_w(t) 
            if torch.cuda.is_available():
                mean_norm = np.mean(norms.data.cpu().numpy())
            else:
                mean_norm = np.mean(norms.data.numpy())
            #print('tilde G_w(t): {}'.format(mean_norm))


            # compute the GradNorm loss 
            # this term has to remain constant
            constant_term = torch.tensor(mean_norm * (inverse_train_rate ** self.config.get("gradn_alpha", 0.5)), requires_grad=False)
            if torch.cuda.is_available():
                constant_term = constant_term.cuda()
            #print('Constant term: {}'.format(constant_term))
            # this is the GradNorm loss itself
            grad_norm_loss = torch.sum(torch.abs(norms - constant_term))
            #print('GradNorm loss {}'.format(grad_norm_loss))

            # compute the gradient for the weights
            self.loss_fn.weights.grad = torch.autograd.grad(grad_norm_loss, self.loss_fn.weights)[0]
            self.optimizer.step()

            normalize_coeff = len(task_loss) / torch.sum(self.loss_fn.weights.data, dim=0)
            self.loss_fn.weights.data = self.loss_fn.weights.data * normalize_coeff
        
        else:
            raise ValueError("no such loss function")
        t2 = time.time()

        self.recorder.LogStep("train/loss", loss.cpu().item())
        todevice, forwardbackward = t1-t0, t2-t1
        return todevice, forwardbackward


    def evaluate(self, yhat_df: pd.DataFrame) -> dict:
        self.logger.info(self.loss_fn.weights)
        res = dict()
        total_cor = 0

        yhat = np.column_stack([yhat_df[f'yhat_{name}'].values for name in self.y_names])
        y = np.column_stack([yhat_df[f'y_{name}'].values for name in self.y_names])
        w = yhat_df['weight'].values

        if hasattr(self, "loss_fn"):
            args = (yhat, y, w) if self.loss_require_w else (yhat, y)
            res["loss"] = round(self.loss_fn.cpu()(*[torch.from_numpy(arg) for arg in args])[1].item(), 10)

        # Clipping and z-score normalization for groups based on 'I' and 'D'
        def clip_and_zscore(group):
            clipped_group = group.copy()
            for col in group.columns:
                if col not in ['I', 'D', 'weight'] and ('yhat_' in col):
                    values = group[col].values
                    lower_percentile = np.percentile(values, 5)
                    upper_percentile = np.percentile(values, 95)
                    clipped_values = np.clip(values, lower_percentile, upper_percentile)
                    clipped_group[col] = zscore(clipped_values)
            return clipped_group

        yhat_df = yhat_df.groupby(['I', 'D']).apply(clip_and_zscore).reset_index(drop=True)
        self.loss_fn.to(self.device)
        for name in self.y_names:
            x = yhat_df[f'yhat_{name}'].values
            y = yhat_df[f'y_{name}'].values
            w = yhat_df['weight'].values
            
            cor_value = cor(x, y, w)
            res[f"cor_{name}"] = round(cor_value, 1)
            res[f"FR_{name}"] = round(FR(x, y, w), 1)
            # res[f"fr_{name}"] = round(fr(x, y, w), 1)
            total_cor += cor_value
        
        res["mean_cor"] = round(total_cor / len(self.y_names), 1)
        return res