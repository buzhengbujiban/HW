import os
import io
import time
from abc import ABC, abstractmethod
from typing import Dict, Tuple, List
import numpy as np
from copy import deepcopy
import torch
import torch.nn as nn
from torch.optim.swa_utils import AveragedModel


class Callback(ABC):

    def BeforeTrain(self, learner, context=None):
        pass
    
    def BeforeEpoch(self, learner, context, epoch):
        pass

    def AfterStep(self, learner, context, step):
        pass

    def AfterEpochTrain(self, learner, context, epoch):
        pass

    def AfterEpoch(self, learner, context, epoch) -> bool:
        return True

    def AfterTrain(self, learner, context=None):
        pass

    def AfterEval(self, learner, context, epoch, step):
        return True


class TensorboardCallback(Callback):
    def __init__(self, log_dir, logtest=False):
        from torch.utils.tensorboard import SummaryWriter
        self.logtest = logtest
        # self.grad_hist_samp_rate = grad_hist_samp_rate  # may delay training
        self.tensorboard_train = SummaryWriter(log_dir=os.path.join(log_dir, "train"))
        self.tensorboard_valid = SummaryWriter(log_dir=os.path.join(log_dir, "valid"))
        if self.logtest:
            self.tensorboard_test = SummaryWriter(log_dir=os.path.join(log_dir, "test"))
        os.chmod(log_dir, 0o700)
        # self.tensorboard_train.add_graph(model, dummy_input, use_strict_trace=False)
        # self.tensorboard_train.add_text("config", str(config))1

    def AfterStep(self, learner, context, step):
        pass
        # if random.random() < self.grad_hist_samp_rate:  # down sample
        #     TensorboardCallback._add_grad_hist(
        #         self.tensorboard_train, learner.model, step
        #     )

    def AfterEpoch(self, learner, context, epoch) -> bool:
        # Draw scalar plot
        for key, value in learner.recorder.from_epoch.items():
            if key.startswith("train/"):  # train/mse or valid/mse
                tensorboard_writer = self.tensorboard_train
            elif key.startswith("valid/"):
                tensorboard_writer = self.tensorboard_valid
            elif key.startswith("test/"):
                tensorboard_writer = self.tensorboard_test
            else:
                raise ValueError(f"Unrecognized key name {key}")
            key = key.split("/", maxsplit=1)[1]
            tensorboard_writer.add_scalar(key, value, epoch)
        self.tensorboard_valid.add_scalar(
            "other/weight_l2norm",
            TensorboardCallback._l2norm(learner.model),
            epoch,
        )
        self.tensorboard_valid.add_scalar(
            "other/learning_rate", learner.optimizer.param_groups[0]["lr"], epoch
        )

        # Draw distribution plot
        if "train/yhat" in context:
            TensorboardCallback._add_distribution(self.tensorboard_valid, "output/train_yhat", context["train/yhat"], epoch)
        if "valid/yhat" in context:
            TensorboardCallback._add_distribution(self.tensorboard_valid, "output/valid_yhat", context["valid/yhat"], epoch)
        if "test/yhat" in context:
            TensorboardCallback._add_distribution(self.tensorboard_test, "output/test_yhat", context["test/yhat"], epoch)
        return True

    def AfterTrain(self, learner, context=None):
        self.tensorboard_train.flush()
        self.tensorboard_train.close()
        self.tensorboard_valid.flush()
        self.tensorboard_valid.close()
        if self.logtest:
            self.tensorboard_test.flush()
            self.tensorboard_test.close()


    @staticmethod
    def _add_grad_hist(tensorboard, model, step):
        with torch.no_grad():
            for name, param in model.named_parameters():
                if param.grad is None:
                    continue
                tensorboard.add_histogram(f"grad/{name}", param.grad, step)
                tensorboard.add_scalar(
                    f"grad_l2norm/{name}", torch.norm(param.grad.cpu()).item(), step
                )

    @staticmethod
    def _add_distribution(tensorboard, tag, x, step):
        import seaborn as sns
        import matplotlib.pyplot as plt
        sns.set_style("whitegrid")
        fig, ax = plt.subplots()
        sns.histplot(x, stat='density', ax=ax)
        mean, std, _min, _max = np.nanmean(x), np.nanstd(x, ddof=1), np.nanmin(x), np.nanmax(x)
        ax.text(0.02, 0.98, f"m={mean:.5f}\ns={std:.5f}\nmin={_min:.4f}\nmax={_max:.4f}", transform=ax.transAxes, verticalalignment='top')
        tensorboard.add_figure(tag=tag, figure=fig, global_step=step)

    @staticmethod
    def _l2norm(model, obj="para"):
        total_norm = 0
        for p in model.parameters():
            if obj == "para":
                norm = p.norm(2)
            elif obj == "grad":
                norm = p.grad.data.norm(2)
            total_norm += norm.item() ** 2
        total_norm = total_norm ** 0.5
        return total_norm

class EarlyStopCallback(Callback):
    def __init__(self, monitor_key:str|List[dict], patience, mode="max", delta=0, fix_num_eval:bool|int=False, **kwargs):
        """
        monitor_key: e.g. "valid/cor" or [{f'valid/cor_{fit_y}': {"delta": 0.1, "mode": "max"}}]. 若为list则靠前的key更重要.
        patience: 容忍的没有提升的最大周期数.
        fix_num_eval: 如果为int,则是固定轮数停
        """
        if isinstance(monitor_key, str):
            self.monitor_keys = [{monitor_key: {"delta": delta, "mode": mode}}]  # 默认 delta 为 0，mode 为 "min"
        elif isinstance(monitor_key, list):
            if all(isinstance(d, dict) for d in monitor_key):
                self.monitor_keys = monitor_key
            else:
                raise ValueError("monitor_key 列表中的元素应为字典")
        else:
            raise ValueError("monitor_key 应该是字符串或字典的列表")

        self.monitor_keys_dict = {k: v for d in self.monitor_keys for k, v in d.items()}
        
        self.best_score = {
            key: -np.inf if config["mode"] == "max" else np.inf 
            for key, config in self.monitor_keys_dict.items()
        }
        self.best_epoch = 0
        self.exploration_epochs = 0
        self.best_param = None
        self.patience = patience
        self.monitor_keys = list(self.monitor_keys_dict.keys())
        self.deltas = [self.monitor_keys_dict[key]["delta"] for key in self.monitor_keys]
        self.modes = [self.monitor_keys_dict[key]["mode"] for key in self.monitor_keys]
        self.fix_num_eval = fix_num_eval
        self.num_eval = 0

    def _better(self, current_vals, best_vals, deltas, modes):
        for cur_val, best_val, delta, mode in zip(current_vals, best_vals, deltas, modes):
            if mode == "max" and cur_val > best_val + delta:
                return True
            elif mode == "min" and cur_val < best_val - delta:
                return True
            elif cur_val != best_val:
                return False
        return False

    def AfterEval(self, learner, context, epoch, step) -> bool:
        monitor_values = [learner.recorder.from_epoch.get(key, None) for key in self.monitor_keys]
        if not all(value is not None for value in monitor_values):
            missing_keys = [key for key, value in zip(self.monitor_keys, monitor_values) if value is None]
            raise ValueError(f"Monitor key not exists: {missing_keys}")

        # 无论根据哪种早停，都maintain self.best_score，供RandomRestart择优。
        if self.fix_num_eval:  # 根据固定轮数早停并选择best model paras
            for key, value in zip(self.monitor_keys, monitor_values):
                self.best_score[key] = value
            self.best_epoch = epoch
            self.best_param = deepcopy(learner.model.state_dict())
            self.num_eval += 1
            if self.num_eval >= self.fix_num_eval:
                return False
        else:  # 根据monitor_values早停并选择best model paras
            best_values = [self.best_score[key] for key in self.monitor_keys]
            if self._better(monitor_values, best_values, self.deltas, self.modes):
                for key, value in zip(self.monitor_keys, monitor_values):
                    self.best_score[key] = value
                self.exploration_epochs = 0
                self.best_epoch = epoch
                self.best_param = deepcopy(learner.model.state_dict())
            else:
                self.exploration_epochs += 1
                if self.exploration_epochs >= self.patience:
                    learner.logger.info(f"-------Training early stopped at Epoch:{epoch}, Step: {step}-------")
                    return False
        return True

    def AfterTrain(self, learner, context=None):
        best_score_str = ', '.join([f"{key}: {self.best_score[key]:.3f}" for key in self.monitor_keys])
        learner.logger.info(
            f"Best model is from Epoch:{self.best_epoch}, with scores {best_score_str}"
        )
        if self.best_param is not None:
            learner.model.load_state_dict(self.best_param)
            learner.logger.info("Finish restore best model.")

class RandomRestartCallback(Callback):
    def __init__(self, restart_num, earlystop_config, **kwargs):
        self.restart_num = restart_num
        self.restart = 0
        self.es_callbacks = []
        if "enable" in earlystop_config:
            del earlystop_config["enable"]
        self.earlystop_config = earlystop_config
        self.current_es_callback = EarlyStopCallback(**self.earlystop_config)

    def AfterEval(self, learner, context, epoch, step) -> bool:
        continue_flag = self.current_es_callback.AfterEval(learner, context, epoch, step)
        if not continue_flag:  # 如果 EarlyStopCallback 返回 False 才执行下面的 restart 逻辑
            if self.restart < self.restart_num:
                self.restart += 1
                learner.logger.info(f"-------Training restarted for {self.restart} time-------")
                # 将原 EarlyStopCallback 储存起来（里面有 best score 和 best param），然后换上新的 EarlyStopCallback
                self.es_callbacks.append(self.current_es_callback)
                self.current_es_callback = EarlyStopCallback(**self.earlystop_config)
                # 重新定义 model，也就是重新初始化参数
                learner._init_model(context["train_dataset"])
                # 优化器的动量和方差估计都是从头开始的，不会受到之前训练的影响
                learner._configure_optimizer()
                context["optimizer_reinitialized"] = True
            else:  # restart 次数已用尽
                self.es_callbacks.append(self.current_es_callback)
                # 找到 score 最好的 es_callback 并将其替换回 self.current_es_callback
                for i, callback in enumerate(self.es_callbacks):
                    learner.logger.info(f"callback{i}, best_score: {callback.best_score}")
                best_callback = self.es_callbacks[0]
                best_values = [best_callback.best_score[key] for key in best_callback.monitor_keys]
                for callback in self.es_callbacks[1:]:
                    current_values = [callback.best_score[key] for key in callback.monitor_keys]
                    if callback._better(current_values, best_values, callback.deltas, callback.modes):
                        # print(current_values, best_values)
                        print(f'score compare {best_callback.best_score} with {callback.best_score}')
                        best_callback = callback
                        best_values = current_values
                self.current_es_callback = best_callback
                learner.logger.info(f"best callback's best_score: {self.current_es_callback.best_score}")
                return False
        return True

    def AfterTrain(self, learner, context=None):
        self.current_es_callback.AfterTrain(learner, context)


class SpeedProfilerCallback(Callback):
    def __init__(self):
        self.epoch_start_time = None
        self.epoch_end_time = None
        self.train_time_sum = 0
        self.valid_time_sum = 0
        self.train_step_time_sum = 0
        self.get_data_time_sum = 0

    def BeforeEpoch(self, learner, context, epoch):
        self.epoch_start_time = time.time()
        
    def AfterEpoch(self, learner, context, epoch) -> bool:
        epoch_end_time = time.time()
        epoch_time = epoch_end_time-self.epoch_start_time
        get_data_time = context["get_data_time"]
        train_step_time = context["train_step_time"]
        todevice_time = context["todevice_time"]
        forwardbackward_time = context["forwardbackward_time"]
        valid_time = context["valid_time"]
        train_time = epoch_time - valid_time
        learner.logger.info(
            f"Epoch {epoch} Train Time: {train_time/60:.0f} min, Valid Time: {valid_time/60:.0f} min. "
            f"Train Step time:{train_step_time/60:.0f} min, Get data time:{get_data_time/60:.0f} min. "
            f"todevice_time: {todevice_time/60:.0f} min, forwardbackward_time: {forwardbackward_time/60:.0f} min"
        )
        self.train_time_sum += train_time
        self.valid_time_sum += valid_time
        self.train_step_time_sum += train_step_time
        self.get_data_time_sum += get_data_time
        return True

    def AfterTrain(self, learner, context=None):
        learner.logger.info(
            f"Training Time: {self.train_time_sum/3600:.1f} h, Valid Time: {self.valid_time_sum/3600:.1f} h. "
            f"Train Step time:{self.train_step_time_sum/3600:.1f} h, Get data time:{self.get_data_time_sum/3600:.1f} h."
        )


class CustomAveragedModel(AveragedModel):
    # PyTorch 的 JIT 编译器不支持变长参数（*args 和 **kwargs）的forward函数定义
    def forward(self, x):
        return self.module(x)
    
class SWACallback(Callback):
    def __init__(self, monitor_key, mode, tolerance):
        """
        mode = 'min' / 'max'
        """
        self.monitor_key = monitor_key
        self.mode = mode
        self.best_score = -np.inf if self.mode == "max" else np.inf
        self.swa_model: nn.Module = None
        self.selected_models: Dict[int, Tuple[nn.Module, float]] = {}  # {epoch: (model, monitor_key)}
        self.tolerance = tolerance

    def BeforeTrain(self, learner):
        self.swa_model = CustomAveragedModel(learner.model)

    def _better(self, val):
        if self.mode == "max":
            return val > self.best_score
        elif self.mode == "min":
            return val < self.best_score
        else:
            raise NotImplementedError(f"Not support mode: {self.mode}..")

    def _tolerate(self, val):
        if self.mode == "max":
            return val >= self.best_score - self.tolerance
        elif self.mode == "min":
            return val <= self.best_score + self.tolerance
        else:
            raise NotImplementedError(f"Not support mode: {self.mode}..")

    def AfterEpoch(self, learner, context, epoch) -> bool:
        monitor_value = learner.recorder.from_epoch.get(self.monitor_key, None)
        assert monitor_value is not None, f"self.monitor_key {self.monitor_key} does not exist"
        if self._better(monitor_value):
            self.best_score = monitor_value
            to_delete =[]
            for _epoch, (model, value) in self.selected_models.items():
                if not self._tolerate(value):
                    to_delete.append(_epoch)
            for _epoch in to_delete:
                del self.selected_models[_epoch]
            self.selected_models[epoch] = (deepcopy(learner.model), monitor_value)
        else:
            if self._tolerate(monitor_value):
                self.selected_models[epoch] = (deepcopy(learner.model), monitor_value)
        content = []
        for _epoch, (model, value) in self.selected_models.items():
            content.append((_epoch, value))
        learner.logger.info(f"{self.__class__.__name__}: Selected epochs&{self.monitor_key} {content}")
        return True

    def AfterTrain(self, learner, context):
        for epoch, (model, value) in self.selected_models.items():
            learner.logger.info(f"Epoch {epoch} seleted for swa, whose {self.monitor_key} is {value:.3f}")
            self.swa_model.update_parameters(model)
        loader = context['loader']
        torch.optim.swa_utils.update_bn(loader, self.swa_model, device=learner.device)
        learner.swa_model = self.swa_model
        learner.logger.info(f"{self.__class__.__name__}: Finish adding swa_model to learner.")