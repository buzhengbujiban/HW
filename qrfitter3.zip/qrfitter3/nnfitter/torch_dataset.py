import os, sys
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple
from collections import defaultdict
import gc
from joblib import Parallel, delayed
import bisect

from torch.utils.data import Dataset

import qr
import qr_utils
from from_fitter2.utils import get_months_between_dates
from file_utils import SingleFile, dates_from, load_block


def load_processed_data_oneday(date_dir, filenames):
    dfs = [qr.tbl_read(os.path.join(date_dir, fn)) for fn in filenames]  # df_x, df_y, df_attr
    return dfs


def load_processed_data_pd(
    dirname: str, filenames: List[str], date_start: str, date_end: str,
    threads=16, filepattern: str=None
):
    """Deprecated version of loading daily processed data"""
    print(qr.cpu_mem_usage("Loading processed data......"))
    if filepattern is None:
        filepattern = '{dirname}/{date}/{filename}'
    filepattern = filepattern.format(dirname=dirname,filename=filenames[0],date='{date}')
    date_list = dates_from(filepattern, date_start=date_start, date_end=date_end)
    if threads == 1:
        dfs = [load_processed_data_oneday(os.path.join(dirname, date), filenames) for date in date_list]
    else:
        dfs = Parallel(n_jobs=threads, backend='loky', verbose=1)(delayed(load_processed_data_oneday)(os.path.join(dirname, date), filenames) for date in date_list)
    print(qr.cpu_mem_usage("Finish loading dfs......"))
    xs, ys, attrs = list(zip(*dfs))
    df_x = pd.concat(xs, axis=0)
    df_y = pd.concat(ys, axis=0)
    df_attr = pd.concat(attrs, axis=0)
    print(qr.cpu_mem_usage("Finish concating......"))
    return df_x, df_y, df_attr


def load_processed_data(
    dirname: str, filenames: List[str], date_start: str, date_end: str,
    threads=32, filepattern: str=None, delete: bool=False, store_per_month: bool=False
):
    """
    Args:
        dirname: processed_data folder path
        filenames: files for one date, e.g. ['x.tbl', 'y.tbl', 'attr.tbl']
        date_start, date_end
        delete: if True, delete array in shm after loading
    """
    print(qr.cpu_mem_usage("Loading processed data......"))
    if filepattern is None:
        filepattern = '{dirname}/{date}/{filename}'
    filepattern = filepattern.format(dirname=dirname,filename=filenames[0],date='{date}')
    date_list = dates_from(filepattern, date_start=date_start, date_end=date_end)
    shm_keys = []
    if store_per_month:
        data_dict = defaultdict(list)  # {month: [x, y, attr]}
        months = get_months_between_dates(date_start, date_end)
        for fn in filenames:
            for month in months:
                ds = [SingleFile(date, dirname, fn) for date in date_list if date.startswith(month)]
                if len(ds) > 0:  # 例如month=201907没有数据
                    data_array, feature_names, shm_key = load_block(ds, threads, delete=delete)
                    data_dict[month].append((data_array, feature_names))
                    shm_keys.append(shm_key)
    else:
        data_dict = {}
        for fn in filenames:
            ds = [SingleFile(date, dirname, fn) for date in date_list]
            data_array, feature_names, shm_key = load_block(ds, threads, delete=delete)
            data_dict[fn] = (data_array, feature_names)
            shm_keys.append(shm_key)
    
    return data_dict, shm_keys


class MLPTorchDataset(Dataset):
    def __init__(self, df_x: pd.DataFrame|Tuple[np.ndarray, List[str]], df_y: pd.DataFrame|Tuple[np.ndarray, List[str]], df_attr: pd.DataFrame|Tuple[np.ndarray, List[str]], fit_label_name: str, weight_name: str|None = None):
        if isinstance(df_x, pd.DataFrame) and isinstance(df_y, pd.DataFrame) and isinstance(df_attr, pd.DataFrame):
            assert len(df_x) == len(df_y) == len(df_attr), "lengths don't match"
            self.x, self.x_names = df_x.values, df_x.columns.to_list()
            self.attr, self.attr_names = df_attr.values, df_attr.columns.to_list()
            self.y = df_y[fit_label_name].values.squeeze()
            self.w = df_attr[weight_name].values.squeeze()
            self.y_names = df_y.columns.to_list()
            self.other_y_names = [col for col in df_y.columns if col != fit_label_name]
            self.other_y = df_y[self.other_y_names].values if len(self.other_y_names) > 0 else None
            if 'real' in df_attr.columns:
                self.valid_indices = np.where(df_attr['real'])[0]
            else:
                self.valid_indices = list(range(len(df_attr)))
        else:
            assert df_x[0].shape[0] == df_y[0].shape[0] == df_attr[0].shape[0], f"lengths don't match: {df_x[0].shape}, {df_y[0].shape}, {df_attr[0].shape}"
            self.x, self.x_names = df_x
            self.attr, self.attr_names = df_attr
            all_ys, self.y_names = df_y
            fit_y_idx = self.y_names.index(fit_label_name)
            self.y = all_ys[:, fit_y_idx]
            if weight_name is None:
                self.w = np.ones_like(self.y)
            else:
                weight_idx = self.attr_names.index(weight_name)
                self.w = self.attr[:, weight_idx]
            self.other_y_names = [col for col in self.y_names if col != fit_label_name]
            other_y_indices = [idx for idx in range(len(self.y_names)) if idx != fit_y_idx]
            self.other_y = all_ys[:, other_y_indices] if len(self.other_y_names) > 0 else None
            if "real" in self.attr_names:
                real_idx = self.attr_names.index("real")
                self.valid_indices = np.where(self.attr[:, real_idx])[0]
            else:
                self.valid_indices = list(range(self.x.shape[0]))

    def __len__(self):
        return len(self.valid_indices)

    def __getitem__(self, idx):
        idx = self.valid_indices[idx]
        X = self.x[idx, :]
        y = self.y[idx]
        w = self.w[idx]
        attr = self.attr[idx, :]
        other_y = self.other_y[idx, :] if len(self.other_y_names) > 0 else [np.nan]
        return X, y, w, attr, other_y  # (F,), float, float, (A,), (Y,)

    
class TSTorchDataset(MLPTorchDataset):

    def __init__(self, df_x: pd.DataFrame|Tuple[np.ndarray, List[str]], df_y: pd.DataFrame|Tuple[np.ndarray, List[str]], df_attr: pd.DataFrame|Tuple[np.ndarray, List[str]], fit_label_name: str, weight_name: str|None = None, kernel_size: int=33, dilation: int=3):
        super().__init__(df_x, df_y, df_attr, fit_label_name, weight_name)
        # kernel_size和dilation是跟卷积层的参数用了一样的术语
        self.kernel_size = kernel_size
        self.dilation = dilation
    
    def __getitem__(self, idx):
        idx = self.valid_indices[idx]
        window_start_idx = idx - self.dilation * (self.kernel_size-1)
        X = self.x[window_start_idx: idx+1: self.dilation, :]  # idx是时序尾
        # 注意现在是通过每天给每个合约前面padding上足够的0并sortby S D I，从而确保以valid_idx作为时序尾的样本其整个window都是一个同一个sid的
        y = self.y[idx]
        w = self.w[idx]
        attr = self.attr[idx, :]
        other_y = self.other_y[idx, :] if len(self.other_y_names) > 0 else [np.nan]
        return X, y, w, attr, other_y  # (T, F), float, float, (A,), (Y,)

class MLPTorchDatasetMonthly(Dataset):

    def __init__(self, data_dict: Dict[str, Tuple[np.ndarray, List[str]]], fit_label_name: str, weight_name: str|None = None) -> None:
        self.x, self.y, self.w, self.attr, self.other_y = [], [], [], [], []  # all of them will have the length equal to len(months)
        valid_indices = []
        for month, data in data_dict.items():
            x, x_names = data[0]
            all_ys, y_names = data[1]
            attr, attr_names = data[2]
            self.x.append(x)
            self.attr.append(attr)

            fit_y_idx = y_names.index(fit_label_name)
            y = all_ys[:, fit_y_idx]
            other_y_names = [col for col in y_names if col != fit_label_name]
            other_y_indices = [idx for idx in range(len(y_names)) if idx != fit_y_idx]
            other_y = all_ys[:, other_y_indices] if len(other_y_names) > 0 else None
            self.y.append(y)
            self.other_y.append(other_y)
            if weight_name is None:
                w = np.ones_like(y)
            else:
                weight_idx = attr_names.index(weight_name)
                w = attr[:, weight_idx]
            self.w.append(w)

            real_idx = attr_names.index("real")
            month_valid_indices = np.where(attr[:, real_idx])[0]
            valid_indices.append(month_valid_indices)

        valid_monthly_num = [len(month_valid_indices) for month_valid_indices in valid_indices]
        self.valid_monthly_cumsum = np.cumsum(valid_monthly_num)  # e.g. array([ 2334580,  5406839,  8909289, 12343734, 15262365, 18469897, 22234758, 25682539, 29249173, 31861541, 35406986, 39190616]) for 12 months
        self.valid_indices = valid_indices

        self.x_names, self.attr_names, self.y_names, self.other_y_names = x_names, attr_names, y_names, other_y_names  # 虽然不太优雅

    def __len__(self):
        return self.valid_monthly_cumsum[-1]
    
    def __getitem__(self, idx):
        # 将一个基于全样本的idx转换到（month_idx, idx）即第几个月以及该月第几个有效样本
        month_idx = bisect.bisect_right(self.valid_monthly_cumsum, idx)
        if month_idx > 0:
            idx -= self.valid_monthly_cumsum[month_idx-1]
        idx = self.valid_indices[month_idx][idx]
        X = self.x[month_idx][idx, :]
        y = self.y[month_idx][idx]
        w = self.w[month_idx][idx]
        attr = self.attr[month_idx][idx, :]
        other_y = self.other_y[month_idx][idx, :] if len(self.other_y_names) > 0 else [np.nan]
        return X, y, w, attr, other_y  # (F,), float, float, (A,), (Y,)


class TSTorchDatasetMonthly(MLPTorchDatasetMonthly):

    def __init__(self, data_dict: Dict[str, Tuple[np.ndarray, List[str]]], fit_label_name: str, weight_name: str|None = None, kernel_size: int=33, dilation: int=3):
        super().__init__(data_dict, fit_label_name, weight_name)
        # kernel_size和dilation是跟卷积层的参数用了一样的术语
        self.kernel_size = kernel_size
        self.dilation = dilation
    
    def __getitem__(self, idx):
        month_idx = bisect.bisect_right(self.valid_monthly_cumsum, idx)
        if month_idx > 0:
            idx -= self.valid_monthly_cumsum[month_idx-1]
        idx = self.valid_indices[month_idx][idx]
        window_start_idx = idx - self.dilation * (self.kernel_size-1)
        X = self.x[month_idx][window_start_idx: idx+1: self.dilation, :]  # idx是时序尾
        # 注意现在是通过每天给每个合约前面padding上足够的0并sortby S D I，从而确保以valid_idx作为时序尾的样本其整个window都是一个同一个sid的
        y = self.y[month_idx][idx]
        w = self.w[month_idx][idx]
        attr = self.attr[month_idx][idx, :]
        other_y = self.other_y[month_idx][idx, :] if len(self.other_y_names) > 0 else [np.nan]
        return X, y, w, attr, other_y  # (T, F), float, float, (A,), (Y,)


if __name__ == '__main__':
    dirname = '/data/bees1/safe/junming/padl/processed_data/feature_all_rolling10norm_pad100_20190801-20240409_7.5s'
    filenames = ['x.tbl', 'y.tbl', 'attr.tbl']
    # date_start, date_end = '20190801', '20201231'  # 16个月242特征，一倍dfs 160G，峰值两倍在concat320G
    date_start, date_end = '20200101', '20201231'
    data_dict = load_processed_data(dirname, filenames, date_start, date_end, store_per_month=True)
    # df_x, df_y, df_attr = load_processed_data_pd(dirname, filenames, date_start, date_end)
    label_name = 'ret300.1s'
    # ds = MLPTorchDataset(data_dict['x.tbl'], data_dict['y.tbl'], data_dict['attr.tbl'], label_name)
    ds = MLPTorchDatasetMonthly(data_dict, label_name)
    print()
