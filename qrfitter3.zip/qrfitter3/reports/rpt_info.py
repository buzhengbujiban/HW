

import os
import socket
from functools import lru_cache
from qrfitter3.utils import read_json
import pandas as pd
import busdates 
from pytbl import tbl_read
import utils

class ReportInfo():
    def __init__(self, cfg_path, scenarios="fit.main"):
        super().__init__()
        self.cfg_path = cfg_path
        self.config = read_json(os.path.join(cfg_path, 'fitting_cfg.json'))
        self.config['hostname'] = socket.gethostname()
        self.config['pid'] = os.getpid()
        self.config['user'] = os.environ["USER"]
        self.dataset_config, self.fitter_config = self.config['dataset'], self.config['fitter']
        self.scenarios = scenarios
        self.target_y = self.dataset_config['fit_y']
        self.config['roll'] = sorted([i for i in os.listdir(os.path.join(cfg_path, self.scenarios)) if i.startswith('roll.')])
        self.config['SAVE_FILE_NAME'] = read_json(os.path.join(cfg_path, self.scenarios, self.config['roll'][0], 'updated_fitter_cfg.json'))['SAVE_FILE_NAME']
        self.load_roll_results_files()
        

    @property
    @lru_cache()
    def basic_info(self):
        info_cfg = {
            "host": self.config['hostname'],
            "user": self.config['user'],
            "pid": self.config['pid'],
        }
        info_cfg.update(self.dataset_config)
        info_cfg['fitter_type'] = self.fitter_config['class']
        info_cfg['fitter_cfg'] = os.path.join(self.cfg_path, 'fitting_cfg.json')
        
        return pd.Series(info_cfg)
    
    @property
    @lru_cache()
    def fit_params(self):
        d = self.fitter_config['para_dict']
        if 'para_dict' in d:
            d = d['para_dict']
        return pd.Series(d)
    
    @property
    @lru_cache()
    def train_test_cor(self) -> pd.Series:
        ss = []
        for roll, result in self.roll_results.items():
            ss.append(pd.Series({
            'train_start': result['train_by_month']['date'].min(),
            'train_end': result['train_by_month']['date'].max(),
            'test_start': result['test_by_month']['date'].min(),
            'test_end': result['test_by_month']['date'].max(),
            'train_cor': result['train_by_month'].mean()[f'cor.{self.target_y}'].round(4),
            'test_cor': result['test_by_month'].mean()[f'cor.{self.target_y}'].round(4)
        }, name=f"{roll}"))
        return pd.DataFrame(ss)
    
    @property
    @lru_cache()
    def monthly_metric_test(self):
        ss = []
        for roll, result in self.roll_results.items():
            ss.append(result['test_by_month'])
        df = pd.concat(ss)
        return df.set_index('date')

    @property
    @lru_cache()
    def daily_metric_test(self):
        ss = []
        for roll, result in self.roll_results.items():
            ss.append(result['test_by_date'])
        df = pd.concat(ss)
        return df.set_index('date')
    
    @property
    @lru_cache()
    def model_info(self):
        roll = self.config['roll'][-1]
        return self.roll_results[roll]['model_file'], self.config['SAVE_FILE_NAME'], roll
    
    @lru_cache()
    def load_roll_results_files(self):
        self.roll_results = {}
        for roll in self.config['roll']:
            roll_path = os.path.join(self.cfg_path, self.scenarios, roll)
            self.roll_results[roll] = {}
            self.roll_results[roll]['train_by_month'] = tbl_read(os.path.join(roll_path, 'train_by_month.tbl'))
            self.roll_results[roll]['test_by_month'] = tbl_read(os.path.join(roll_path, 'test_by_month.tbl'))
            self.roll_results[roll]['test_by_date'] = tbl_read(os.path.join(roll_path, 'test_by_date.tbl'))
            if roll == self.config['roll'][-1]: #only load the most recent 
                self.roll_results[roll]['fit_rounds'] = tbl_read(os.path.join(roll_path, f"{self.config['SAVE_FILE_NAME']}_rounds.tbl"))
                self.roll_results[roll]['model_file'] = os.path.join(roll_path, f"{self.config['SAVE_FILE_NAME']}.model")
    
    @lru_cache()
    def rounds_df_plot(self):
        roll = self.config['roll'][-1]
        utils.rounds_df_plot(self.roll_results[roll]['fit_rounds'], title=f"cor at each fitting epoch of {roll}")

    

    def _get_evaluation_summary(self):
        pass
    
if __name__ == '__main__':
    ReportInfo('/data/bees1/safe/ruud/equity_fitting/expt_res/testqf3')