#!/bin/bash

set -eo pipefail
script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd -P)
pushd ${script_dir}
bash ../run_roll_task_report.sh /data/bees1/safe/ruud/equity_fitting/expt_res/testqf3 report.html
pytest --disable-warnings -n 5
popd
