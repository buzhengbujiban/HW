import os
import json
import pandas as pd
import numpy as np
from collections import OrderedDict
import sys
import importlib
from fitter2.evaluator import cor, fr, FR
from curses.ascii import isdigit
import qr

# evaluator cor is in %
def cor_0(x,y,w): return cor(x,y,w) * 1e-2
# evaluator FR is in bps
def FR_0(pred,y,w): return FR(pred,y,w) * 1e-4

def fr_0(pred,y,w): return fr(pred, y, w)

def sd_0(x, w=1):
    # sqrt(mean(x * x * weight)) / sqrt(mean(weight))
    var = np.mean(x*x*w)
    return np.sqrt(var) / np.sqrt(np.mean(w))


def y_hat_df_metrics(df, target_name):
    gdf = df[['date', 'y_hat', 'y', 'w']].groupby('date')
    metric_df = gdf.apply(lambda df: pd.Series({
        f'cor.{target_name}': cor_0(df.y_hat, df.y, df.w) * 100,
        f'fr.{target_name}': fr_0(df.y_hat, df.y, df.w),
        f'FR.{target_name}': FR_0(df.y_hat, df.y, df.w) * 1e4,
    }))
    return metric_df

def where_regex(array_like, patterns=None, exclude=None):
    if not isinstance(array_like, pd.Series):
        array_like = pd.Series(array_like)
    if isinstance(patterns, str):
        patterns = [patterns]
    flag = np.zeros_like(array_like, dtype=bool)
    if patterns:
        for pattern in patterns:
            f = array_like.str.contains(pattern)
            flag |= f
    else: # if patterns not specified, then get all names
        flag = ~flag
    if exclude:
        if isinstance(exclude, str):
            exclude = [exclude]
        for e in exclude:
            f = array_like.str.contains(e) == False
            flag &= f
    columns = array_like[flag].to_list()
    return columns


def relative(underscore_file, *args):
    dir = os.path.dirname(os.path.realpath(underscore_file))
    return os.path.join(dir, *args)

def mkold_file(fn):
    if not os.path.exists(fn):  
        return
    stat = os.stat(fn)
    if stat.st_size == 0:
        # remove empty file
        qr.Log.i("removing empty file {}".format(fn))
        os.remove(fn)
        return    
    # mkold
    os.system(f"mkold {fn}")

def mkold_before_write(fn):
    qr.Log.i(f"writting to {fn}")
    mkold_file(fn)

def tbl_write_ex(df, fn):
    """ remove empty file or rename existing file"""
    mkold_file(fn)
    qr.tbl_write(df, fn)

def tbl_read_ex(fn):
    qr.Log.i(f"reading {fn}")
    df = qr.tbl_read(fn)
    if "sid" in df.columns:
        df["sid"] = df["sid"].astype(int)
    return df

def rmtree(path:str):
    import shutil
    qr.Log.i(f"removing {path}")
    shutil.rmtree(path)

def read_json(fn, **kwargs):
    """Read json file as dict, and interp `${CUR_DIR}, and kwargs
    """
    qr.Log.i(f"reading json {fn}")
    env = {'CUR_DIR': relative(fn)}
    env.update(kwargs)
    with open(fn) as fh:
        cfg = json.load(fh, object_pairs_hook=OrderedDict)
        cfg = interp(cfg, env)
    return cfg


def custom_serializer(obj):
    if callable(obj):
        return obj.__name__  # Store the function name
    return None

def write_json(cfg, fn, indent=2):
    """ write cfg as of dict to json file `fn`.
    * create folders when necessary.
    * mkold outout if already exists.
    """
    outdir = os.path.dirname(fn)
    if not os.path.exists(outdir):
        qr.Log.i(f"creating {outdir}")
        os.makedirs(outdir)
    mkold_before_write(fn)
    with open(fn, "w") as fh:
        json.dump(cfg, fh, indent=indent, default=custom_serializer)

def all_unique(lst):
    seen = set()
    for v in lst:
        if v in seen:
            return False, v
        seen.add(v)
    return True, None

def assert_all_unique(lst):
    r, dup = all_unique(lst)
    assert r, f"not all unique, dup[{dup}], all[{lst}]"

def interp0(cmd, env):
    for v in env:
        tgt = env[v]
        pattern = '${%s}' % v
        if pattern in cmd:
            if isinstance(tgt, str):
                cmd = cmd.replace(pattern, tgt)
            else:
                cmd = cmd.replace(pattern, str(tgt))
    return cmd

def interp(w, env):
	if isinstance(w, str):
		return interp0(w, env)
	elif isinstance(w, list):
		return [interp(x, env) for x in w]
	elif isinstance(w, dict):
		return {k:interp(v, env) for k,v in w.items()}
	else:
		return w

ip_to_hname = None

def init_ip_to_home():
    global ip_to_hname
    if ip_to_hname is not None:
        return
    try:
        lines = [l.split() for l in os.popen("goto show", "r").readlines()]
        ip_to_hname = {l[2]:l[0] for l in lines}
        return True
    except:
        return False

def hostname_internal():
    global ip_to_hname
    ip = os.popen("hostname -i").read().strip().split()
    if len(ip) > 0:
        ip = ip[0]
    if ip not in ip_to_hname:
        return hostname_socket()
    n = ip_to_hname[ip]
    if isdigit(n[0]):
        n = f"R{n}"
    return n

def hostname_socket():
    import socket
    return socket.gethostname()

def hostname():
    if ip_to_hname is None:
        if init_ip_to_home():
            return hostname_internal()
    else:
        return hostname_internal()
    return hostname_socket()

def username():
    return os.environ["USER"]

def package_versions(**kwargs):
    r = {}
    r['python'] = '.'.join([str(i) for i in sys.version_info[:3]])
    r['numpy'] = np.__version__
    r['pandas'] = pd.__version__
    for m in kwargs:
        if kwargs[m]:
            module = importlib.import_module(m, package=None)
            if hasattr(module, '__version__'):
                r[m] = module.__version__ 
            elif hasattr(module, '__path__'):
                p = module.__path__
                if isinstance(p, list):
                    p = p[0]
                r[m] = p
            else:
                # ignore
                continue
    return pd.Series(r)

def load_x_names(x_names):
    if not isinstance(x_names, str):
        return x_names
    assert os.path.exists(x_names), f"x_names file not exist. {x_names}"
    if x_names.endswith(".py"):
        x_names = eval(open(x_names).read())
    else:
        fn = x_names
        x_names = [x for line in open(fn).readlines() for x in line.split()]
    return x_names