import multiprocessing
import os
import datetime
from multiprocessing import Pool
from functools import lru_cache
import qr

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import xgboost as xgb

import busdates
import pd_utils
import qrfitter3.reports.mf_utils as mfu

def ab_to_html(a, b, attr_name, print_name, a_name="Ensemble", b_name="Base"):
    from IPython.display import display, Markdown, HTML
    a_df = ensure_dataframe(getattr(a, attr_name))
    b_df = ensure_dataframe(getattr(b, attr_name))
    display(Markdown(f'<b><span style="color:red">{a_name}</span> {print_name}</b>'))
    display(HTML(a_df.to_html()))
    display(Markdown(f'<b><span style="color:red">{b_name}</span> {print_name}</b>'))
    display(HTML(b_df.to_html()))

def jupyter_input(env_var="JUPYTER_INPUT_PYTHON"):
    input_str = os.getenv(env_var)
    if not input_str: return None
    input_dict = eval(input_str)
    return input_dict

def jupyter_input_dict(env_var="JUPYTER_INPUT_PYTHON"):
    input_str = os.getenv(env_var)
    if not input_str: return {}
    input_dict = eval(input_str)
    return input_dict

def ensure_dataframe(s):
    assert isinstance(s, (pd.DataFrame, pd.Series))
    if isinstance(s, pd.DataFrame): return s
    return s.to_frame().T

def pd_set_max_option():
    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)
    pd.set_option('display.max_colwidth', 1000)

def with_pd_max_option(func):
    with pd.option_context(
        'display.max_rows', 500,
        'display.max_columns', 500,
        'display.width', 1000,
        'display.max_colwidth', 1000):
        func()

def jupyter_title(title):
    now = datetime.datetime.now().strftime('%b %d, %Y')
    txt = f"""
<font size=5><center><b>{title}</b></center></font>
<center>evo confidential</center>
<center>{now}</center>"""
    return txt

def rounds_df_plot(dfs, cor_cols=['train_cor', 'test_cor'], ylabel="%", title="cor at each fitting epoch"):
    if isinstance(dfs, list):
        df = sum(dfs) / len(dfs)
    else:
        df = dfs
    df.plot(y=cor_cols, grid=True, ylabel=ylabel, title=title)

def rounds_df_plot_posneg(rounds_df,target):
    plt.figure(figsize=(12,8))

    tmp=rounds_df[[f'train_cor',f'test_cor']+[f'train_pcor_pos',f'test_pcor_pos']+[f'train_pcor_neg',f'test_pcor_neg']]*100
    tmp.columns = [f"{x}={tmp[x].values[-1]:.2f}%" for x in tmp.columns]

    tmprmse=rounds_df[[f'train_fitloss',f'test_fitloss']+[f'train_rmse_pos',f'test_rmse_pos']+[f'train_rmse_neg',f'test_rmse_neg']]
    tmprmse.columns = [f"{x}={tmprmse[x].values[-1]:.2e}" for x in tmprmse.columns]

    tmpfr=rounds_df[[f'train_fr',f'test_fr']+[f'train_fr_pos',f'test_fr_pos']+[f'train_fr_neg',f'test_fr_neg']]
    tmpfr.columns = [f"{x}={tmpfr[x].values[-1]:.2f}" for x in tmpfr.columns]

    ax = plt.subplot(3,3,1)
    tmp[[x for x in tmp.columns if x.split('=')[0] in ['train_cor','test_cor']]].plot(grid=True, title=f'all samples | COR0',ax=ax)
    plt.ylabel('COR(%)')
    ax = plt.subplot(3,3,2)
    tmprmse[[x for x in tmprmse.columns if x.split('=')[0] in ['train_fitloss','test_fitloss']]].plot(grid=True, title=f'samples | fitloss',ax=ax)
    plt.ylabel('fitloss')
    ax = plt.subplot(3,3,3)
    tmpfr[[x for x in tmpfr.columns if x.split('=')[0] in ['train_fr','test_fr']]].plot(grid=True, title=f'all samples | fr',ax=ax)
    plt.ylabel('fr')
    plt.axhline(0.8, ls='--',color='black',lw=1)
    plt.axhline(1.2, ls='--',color='black',lw=1)


    ax = plt.subplot(3,3,4)
    tmp[[x for x in tmp.columns if x.split('=')[0] in ['train_pcor_pos','train_pcor_neg']]].plot(grid=True, title=f'trainset | PCOR',ax=ax, color=['red','green'])
    plt.ylabel('PCOR(%)')
    ax = plt.subplot(3,3,5)
    tmprmse[[x for x in tmprmse.columns if x.split('=')[0] in ['train_rmse_pos','train_rmse_neg']]].plot(grid=True, title=f'trainset | rmse',ax=ax, color=['red','green'])
    plt.ylabel('rmse')
    ax = plt.subplot(3,3,6)
    tmpfr[[x for x in tmpfr.columns if x.split('=')[0] in ['train_fr_pos','train_fr_neg']]].plot(grid=True, title=f'trainset | fr',ax=ax, color=['red','green'])
    plt.ylabel('fr')
    plt.axhline(0.8, ls='--',color='black',lw=1)
    plt.axhline(1.2, ls='--',color='black',lw=1)

    ax = plt.subplot(3,3,7)
    tmp[[x for x in tmp.columns if x.split('=')[0] in ['test_pcor_pos','test_pcor_neg']]].plot(grid=True, title=f'testset | PCOR',ax=ax, color=['red','green'])
    plt.ylabel('PCOR(%)')
    ax = plt.subplot(3,3,8)
    tmprmse[[x for x in tmprmse.columns if x.split('=')[0] in ['test_rmse_pos','test_rmse_neg']]].plot(grid=True, title=f'testset | rmse',ax=ax, color=['red','green'])
    ax = plt.subplot(3,3,9)
    tmpfr[[x for x in tmpfr.columns if x.split('=')[0] in ['test_fr_pos','test_fr_neg']]].plot(grid=True, title=f'testset | fr',ax=ax, color=['red','green'])
    plt.axhline(0.8, ls='--',color='black',lw=1)
    plt.axhline(1.2, ls='--',color='black',lw=1)

    plt.suptitle(f'train test scores at each rounds (average rolls) | {target}')
    plt.tight_layout()

def series_sid_univ(dates, cores=50):
    """get sid's universe, and return as pandas Series
    """
    pool = Pool(cores)
    date_univs = pool.map(pd_utils.get_sid_univ, dates)
    sid_univ_dict = {}
    for u in date_univs:
        sid_univ_dict.update(u)
    return pd.Series(sid_univ_dict, name="univ")

def dataframe_sid_univ(dates, cores=50):
    date_univs=qr.get_multidays_func(dates,myfunc=qr.get_sid_univ,njobs=cores)
    date_univs=pd.DataFrame(date_univs)
    date_univs.index=dates
    date_univs=date_univs.stack().reset_index()
    date_univs.columns=['date','sid','univ']
    date_univs['date']=date_univs['date'].astype(int)
    date_univs['sid']=date_univs['sid'].astype(int)
    return date_univs

def dataframe_sid_industry(dates, cores=50):
    # SOD availabel
    indcode=pd.read_csv(f'{qr.Paths.panel_root}/industry-name-map.csv')
    date_inds = qr.get_multidays_info(dates, qr.Paths.industry1_path('{date}'), njobs=cores)
    date_inds['industry.code'] = date_inds.iloc[:,:-3].idxmax(1).astype(int)
    tmp = (date_inds.iloc[:,:-4].max(axis=1)<1)
    assert not tmp.any(), f"following date sid has no industry:\n{date_inds.loc[tmp,['sid','date']]}"
    date_inds=date_inds.merge(indcode, on='industry.code',how='left')
    date_inds['date']=date_inds['date'].astype(int)
    date_inds['sid']=date_inds['sid'].astype(int)
    return date_inds[['sid','date','industry.code','industry.name','industry.ename']]

def dateframe_sid_rollstates(dates, cores=50):
    # EOD availabel, use pDate
    date_rollstats = qr.get_multidays_info(dates, qr.Paths.panel_daily_roll_stat_path('{date}'), njobs=cores)
    date_rollstats['date'] = list(map(qr.bd.next_date, date_rollstats['date']))
    date_rollstats['date']=date_rollstats['date'].astype(int)
    date_rollstats['sid']=date_rollstats['sid'].astype(int)
    return date_rollstats.drop('time',axis=1)

def attribute_sid_univ(df, df_univ):
    ans = pd.merge(df, df_univ, on=['date','sid'], how="left")
    ans['univ'] = ans['univ'].fillna("other")
    return ans

def left_compose(*functions):
    import functools
    return functools.reduce(lambda f, g: lambda x: g(f(x)), functions, lambda x: x)

def dataframe_unique_len(df: pd.DataFrame):
    """ call np.unique and then len for every column
    """
    unique_len = left_compose(np.unique, len)
    return df.apply(unique_len)

def daily_y_hat_metric(df):
    d = {}
    d['n.stock'] = df.sid.unique().shape[0]
    d['ret.mean(bps)'] = df.y.mean() * 1e4
    d['alp.mean(bps)'] = df.y_hat.mean() * 1e4
    d['ret.sd(%)'] = mfu.sd_0 (df.y, df.w) * 1e2
    d['alp.sd(%)'] = mfu.sd_0 (df.y_hat, df.w)  * 1e2
    d['cor(%)']    = mfu.cor_0(df.y_hat, df.y, df.w) * 1e2
    d['fr']        = mfu.fr_0 (df.y_hat, df.y, df.w)
    d['FR(bps)']   = mfu.FR_0 (df.y_hat, df.y, df.w) * 1e4
    return pd.Series(d)

def daily_y_hat_big_alpha_metric(df, thres=20e-4):
    bdf = df.loc[df.y_hat.abs() > thres]
    N = bdf.shape[0]
    SIZE = df.shape[0]
    WIN = ((df.y > 0) == (df.y_hat > 0)).sum()
    d = {}
    d['big_ratio(%)'] = (N / SIZE) * 100
    d['win_ratio(%)'] = (WIN / SIZE) * 100
    d['ret.mean(bps)'] = bdf.y.mean() * 1e4
    d['alp.mean(bps)'] = bdf.y_hat.mean() * 1e4
    d['ret.sd(%)'] = mfu.sd_0 (bdf.y, bdf.w) * 1e2
    d['alp.sd(%)'] = mfu.sd_0 (bdf.y_hat, bdf.w)  * 1e2
    d['cor(%)']    = mfu.cor_0(bdf.y_hat, bdf.y, bdf.w) * 1e2
    d['fr']        = mfu.fr_0 (bdf.y_hat, bdf.y, bdf.w)
    d['FR(bps)']   = mfu.FR_0 (bdf.y_hat, bdf.y, bdf.w) * 1e4
    return pd.Series(d)
    
def attribute_daily_y_hat(df, dates, cores=50, inplace=False, univ=1, month=1, industry=1, spread=0, ex=1, mid=0,
                          rollstats=0):
    if not inplace:
        df = df.copy()
    if univ:
        # add univ column
        if 'univ' not in df.columns:
            df_univ = dataframe_sid_univ(dates=dates, cores=cores)
            df = attribute_sid_univ(df, df_univ=df_univ)
    if month:
        # add month column
        df['month'] = (df.date // 100).astype(np.int32)
    if industry:
        # add industry column
        if 'industry' not in df.columns:
            df_ind = dataframe_sid_industry(dates=dates, cores=cores)
            df_ind = df_ind.rename(columns={'industry.ename':'industry'})
            df = df.merge(df_ind[['sid','date','industry']], on=['sid','date'],how='left')
            df['industry'] = df['industry'].fillna('Unknown')
    if rollstats:
        if 'turnover.rw22' not in df.columns:
            df_rolls = dateframe_sid_rollstates(dates=dates, cores=cores)
            df = df.merge(df_rolls, on=['sid','date'],how='left')
    if ex:
        if 'exch' not in df.columns:
            df["exch"] = list(map(qr.get_sid_ex().get, df.sid))
            df['exch'] = df['exch'].fillna('Unknown')
    if spread:
        df['secs'] = round((df['epoch']%86400-5400)/60)*60
        assert df['OB.spread'].min()>=0
        df['OB.spread.bps'] = df['OB.spread']/df['OB.mid']*1e4
        df['gp.spreadbps'] = pd.cut(df['OB.spread.bps'],bins=[0,3.5,7,10.5,14,20,df['OB.spread.bps'].max()],precision=2)
    if mid:
        assert df['OB.mid'].min()>=0
        df['gp.mid'] = pd.qcut(df.groupby(['date','sid'])['OB.mid'].transform('median'),q=5)
        amin = df['gp.mid'].min()
        df['gp.mid'] = df['gp.mid'].cat.rename_categories({amin:pd.Interval(left=0,right=amin.right, closed='both')} )
        
    return df

def y_hat_df_FR_bps(df): return mfu.FR_0(df.y_hat, df.y, df.w) * 1e4
def y_hat_df_FR_bps_safe(df, minlen=1): return 0 if len(df) < minlen else y_hat_df_FR_bps(df)
def daily_df_cumFR(df, minlen=1): return df.groupby('date').apply(y_hat_df_FR_bps_safe, minlen=minlen).cumsum()

def cumFR_for_attr_daily_y_hat(input_df, group='univ', minlen=1):
    #if 'date' in input_df.columns:
    #    input_df = input_df.set_index('date')
    idf = input_df.groupby(group).apply(daily_df_cumFR, minlen=minlen)
    if isinstance(idf, pd.Series):
        # different shape of each group, unstack and fillna
        # https://stackoverflow.com/questions/37715246/pandas-groupby-apply-behavior-returning-a-series-inconsistent-output-type
        idf = idf.unstack().T.fillna(method='ffill')
    else:
        idf = idf.T
    idf.index = pd.to_datetime(idf.index.astype(np.int32).astype(str), format="%Y%m%d")
    return idf

def plot_cumFR(daily_metric, target_name):
    if 'date' in daily_metric.columns:
        daily_metric = daily_metric.set_index('date')
    daily_FR_df = daily_metric.loc[:,daily_metric.columns.str.contains('FR')]
    daily_FR_df_cum = daily_FR_df.cumsum()
    daily_FR_df_cum.index = pd.to_datetime(daily_FR_df_cum.index.astype(np.int32).astype(str), format="%Y%m%d")
    total_FR = daily_FR_df_cum[f'FR.{target_name}'][-1]
    hn = daily_FR_df_cum.shape[1]
    if hn < 5:
        daily_FR_df_cum.plot(grid=True, title=f"cumFR over dates: {total_FR:.0f}bps", ylabel="bps",cmap='rainbow')
    else:
        daily_FR_df_cum.plot(grid=True, title=f"cumFR over dates: {total_FR:.0f}bps", ylabel="bps", figsize=(hn*1.5, hn),cmap='rainbow')

# def plot_cumFR_plotly(df, title):
#     import plotly.express as px
#     fig = px.line(df)
#     fig.update_layout(title=title, xaxis_title="date", yaxis_title="bps")
#     fig.show()

def plot_cumFR_plotly(df, title):
    import plotly.express as px
    fig = px.line(df)
    width = max(len(df.columns) * 50, 800)
    fig.update_layout(title=title, yaxis_title="bps", autosize=False, width=width, height=600)
    fig.show()

def plot_barh_plotly(df, terms_size, title, xlabel, ylabel="term"):
    import plotly.express as px
    fig = px.bar(df, orientation="h", barmode="group")
    size = max(terms_size * 30, 800)
    fig.update_layout(title=title, xaxis_title=xlabel, yaxis_title=ylabel, autosize=False, width=600, height=size)
    fig.show()

def plot_fr_ma(daily_metric: pd.DataFrame, target_name, fr_col=None, ylabel="fr", title="fr over dates"):
    if fr_col is None:
        fr_col = f'fr.{target_name}'
    if 'date' in daily_metric.columns:
        daily_metric = daily_metric.set_index('date')
    assert fr_col in daily_metric.columns, f"column {fr_col} not exist in dataframe. {daily_metric.columns}"
    df = daily_metric[[fr_col]]
    df.columns = [f'{x}={df[x].mean():.2f}' for x in df.columns]
    df.index = pd.to_datetime(df.index.astype(np.int32).astype(str), format="%Y%m%d")
    roll_df = df.rolling(10).mean()
    roll_df.columns = [f"{fr_col}.ma"]

    # plotting
    sns.set_style("whitegrid")
    sns.lineplot(data=df, alpha=.5)
    sns.lineplot(data=roll_df)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.xticks(rotation=45)

def xgb_plot_importance(xgb_model, x_names, figsize=None):
    booster = xgb.Booster()
    booster.load_model(xgb_model)
    # create dict to use later
    dict_features = dict(enumerate(x_names))
    if figsize is None:
        figsize = (8, round(len(x_names)/5))
    fig, ax = plt.subplots(1,1,figsize=figsize)
    # feat importance with names f1,f2,...
    axsub = xgb.plot_importance(booster, ax=ax)
    # get the original names back
    Text_yticklabels = list(axsub.get_yticklabels())
    dict_features = dict(enumerate(x_names))
    lst_yticklabels = [ Text_yticklabels[i].get_text().lstrip('f') for i in range(len(Text_yticklabels))]
    lst_yticklabels = [ dict_features[int(i)] for i in lst_yticklabels]
    axsub.set_yticklabels(lst_yticklabels)
    # plt.show()

def xgb_importance_df(xgb_model):
    import xgboost as xgb
    booster = xgb.Booster()
    booster.load_model(xgb_model)
    fmap = os.path.join(os.path.dirname(xgb_model), "xgb.fmap")
    weight = booster.get_score(fmap=fmap, importance_type="weight")
    gain = booster.get_score(fmap=fmap, importance_type="gain")
    cover = booster.get_score(fmap=fmap, importance_type="cover")

    # total_gain = booster.get_score(fmap='/data/nasData/chinaEquityData/john/HD/base/modelflow/task_2/xgb.fmap', importance_type="total_gain")
    # total_cover = booster.get_score(fmap='/data/nasData/chinaEquityData/john/HD/base/modelflow/task_2/xgb.fmap', importance_type="total_cover")

    rank_df = pd.DataFrame({
        'term': weight.keys(),
        'weight': weight.values(),
    })
    rank_df['gain'] = list(gain.values())
    rank_df['cover'] = list(cover.values())
    # rank_df['total_gain'] = list(total_gain.values())
    # rank_df['total_cover'] = list(total_cover.values())
    return rank_df.sort_values('weight', ascending=False).reset_index(drop=True), 'weight'

def regression_importance_df(regression_model, x_names):
    import joblib   # after sklearn version>0.21
    regressor = joblib.load(regression_model)
    #term = regressor.feature_names_in_, #available in sklearn version 1.0, BUT current version is 0.24
    term = x_names
    df = pd.DataFrame({
        'term': term,
        'absolute_value_of_weight': np.abs(regressor.coef_),
        'weight': regressor.coef_,
    })
    df = df.sort_values('absolute_value_of_weight', ascending=False)
    return df.reset_index(drop=True), 'absolute_value_of_weight'

def lgb_importance_df(lgb_model):
    import lightgbm as lgb
    booster = lgb.Booster(model_file=lgb_model)
    s_split = booster.feature_importance(importance_type="split")
    s_gain = booster.feature_importance(importance_type="gain")
    n = booster.feature_name()
    df = pd.DataFrame({
        'term': n,
        'score_by_split': s_split,
        'score_by_gain': s_gain,
    })

    df = df.sort_values('score_by_split', ascending=False)
    return df.reset_index(drop=True), 'split'

class ProviderMixin(object):
    """common methods based on `provider` property
    - date_start
    - date_end
    - portable_busdates
    - y_names
    """
    @property
    @lru_cache()
    def date_start(self): return self.provider.date_start
    
    @property
    @lru_cache()
    def date_end(self): return self.provider.date_end

    @property
    def y_names(self): return self.provider.y_names

    @property
    @lru_cache()
    def portable_busdates(self): return busdates.PortableBusDates('SSE', self.date_start, self.date_end)

class DatasetMixin(object):
    """common methods based on `dataset` property
    - train_start_month
    - train_end_month
    - test_start_month
    - test_end_month
    """
    @property
    @lru_cache()
    def train_start_month(self): return self.dataset['train_start_month']

    @property
    @lru_cache()
    def train_end_month(self): return self.dataset['train_end_month']
    
    @property
    @lru_cache()
    def test_start_month(self): return self.dataset['test_start_month']

    @property
    @lru_cache()
    def test_end_month(self): return self.dataset['test_end_month']

class TaskMixin(object):
    """common methods based on `task` property
    - target_name
    - x_names
    """
    @property
    def target_name(self): return self.task.target_name

    @property
    def x_names(self): return self.task.dataset.x_names

class DailyMetricMixin(TaskMixin):
    """common methods based on `daily_metric_test` and `task` property
    - target_name
    - x_names
    - daily_test_cumFR
    - daily_total_FR
    """
    @property
    @lru_cache()
    def daily_test_cumFR(self):
        daily_FR_df = self.daily_metric_test.loc[:,self.daily_metric_test.columns.str.contains('FR')]
        daily_FR_df_cum = daily_FR_df.cumsum()
        daily_FR_df_cum.index = pd.to_datetime(daily_FR_df_cum.index.astype(np.int32).astype(str), format="%Y%m%d")
        return daily_FR_df_cum

    @property
    @lru_cache()
    def daily_total_FR(self): return self.daily_test_cumFR[f'FR.{self.target_name}'][-1]

class YhatTestMixin(ProviderMixin):
    """common methods based on `y_hat_test` and `provider` property

    from ProviderMixin
    ==================
    - date_start
    - date_end
    - portable_busdates
    - y_names

    from YhatTestMixin
    ====================
    - attri_y_hat_test
    - daily_cumFR_by_group
    """
    @property
    @lru_cache()
    def attri_y_hat_test(self): return attribute_daily_y_hat(self.y_hat_test, self.portable_busdates.bdates, spread='OB.spread' in self.y_hat_test.columns,mid='OB.mid' in self.y_hat_test.columns)

    @lru_cache()
    def daily_cumFR_by_group(self, group):
        assert group in self.attri_y_hat_test.columns, f'invalid group={group}'
        return cumFR_for_attr_daily_y_hat(self.attri_y_hat_test, group=group)

class MonthlyMetricTest(TaskMixin):
    """
    common methods based on `monthly_metric_test` and `task` property
    - target_name
    - x_names
    - test_cor
    """
    @property
    @lru_cache()
    def test_cor(self): return self.monthly_metric_test.mean()[f'cor.{self.target_name}']

def estimate_beta(x, y):
    # number of observations/points
    n = np.size(x)
  
    # mean of x and y vector
    m_x = np.mean(x)
    m_y = np.mean(y)
  
    # calculating cross-deviation and deviation about x
    SS_xy = np.sum(y*x) - n*m_y*m_x
    SS_xx = np.sum(x*x) - n*m_x*m_x
  
    # calculating regression coefficients
    b_1 = SS_xy / SS_xx
    b_0 = m_y - b_1*m_x
  
    return (b_0, b_1)

def plot_with_ma_ax(df, name, ax):
    import matplotlib.dates as mdates
    fmt = mdates.DateFormatter('%y-%m-%d')
    df_roll = df.rolling(10).mean()
    df_roll.columns = [f'{name}.ma(10d)']
    sns.set_style("whitegrid")
    sns.lineplot(data=df, alpha=.5, ax=ax)
    sns.lineplot(data=df_roll, ax=ax)
    ax.set_ylabel(name)
    ticks = df.iloc[::22].index
    ax.set_xticks(ticks)
    ax.set_xticklabels(ticks, rotation=45)
    ax.xaxis.set_major_formatter(fmt)
    # ax.set_xticks(rotation=45);

def plot_metrics(term:str, train_df: pd.DataFrame, test_df: pd.DataFrame, y_hat_col:str, groupby_col:str):
    assert y_hat_col in train_df.columns, train_df.columns
    assert y_hat_col in test_df.columns, test_df.columns
    assert groupby_col in test_df.columns, test_df.columns
    assert 'date' in test_df.columns, test_df.columns
    assert 'wgt' in test_df.columns, test_df.columns

    # train
    y = train_df[y_hat_col].values
    x = train_df[term].values
    beta0, beta1 = estimate_beta(x, y)
    # test
    test_df['y_hat'] = test_df[term].values * beta1 + beta0
    # fr
    label = f'fr_of_{term}'
    fig, axs = plt.subplots(1, 4, figsize=(25, 3))
    fig.suptitle(f'cor, fr w/ {y_hat_col}')
    test_df.groupby(groupby_col).apply(lambda d:  pd.Series({label: mfu.fr_0(d.y_hat, d[y_hat_col], d.wgt)})).plot(marker='o', ax=axs[0], grid=True);
    plot_with_ma_ax(test_df.groupby('date').apply(lambda d:  pd.Series({label: mfu.fr_0(d.y_hat, d[y_hat_col], d.wgt)})), label, axs[1])
    # cor
    label = f'cor_of_{term}'
    test_df.groupby(groupby_col).apply(lambda d:  pd.Series({label: mfu.cor_0(d.y_hat, d[y_hat_col], d.wgt)})).plot(marker='o', ax=axs[2], grid=True);
    plot_with_ma_ax(test_df.groupby('date' ).apply(lambda d:  pd.Series({label: mfu.cor_0(d.y_hat, d[y_hat_col], d.wgt)})), label, axs[3])
    
def parallel_load(loader, sdate, edate, cores):
    dates = qr.busdates.PortableBusDates('SSE', sdate, edate).bdates
    pool = multiprocessing.Pool(cores)
    dfs = pool.map(loader, dates)
    return pd.concat(dfs)


def rpt_gen(cfg_path, report_path):
    sh_file = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'run_roll_task_report.sh')
    cmd = f"bash {sh_file} {cfg_path} {report_path}"
    os.system(f'{cmd}')
