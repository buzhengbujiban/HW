#!/bin/bash

set -eo pipefail

# use conda dev9 env
cfg_path=$1
output=`realpath $2`
script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd -P)
export JUPYTER_INPUT_PYTHON="{'cfg_path':'$cfg_path'}"
source activate /data/nas2Data/apps/anaconda3/envs/dev9 
jupyter-nbconvert ${script_dir}/rpt_roll_task.ipynb --execute --to html --no-input --output $output
