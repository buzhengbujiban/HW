import numpy as np
import pandas as pd
import numba as nb
from scipy.stats import rankdata
import torch

from qrfitter3.utils import flatten_list

@nb.guvectorize(['void(float64[:], float64[:], float64[:])'], '(n),(n)->()',target='parallel',nopython=True)
def cal_pearsonr(x,y,out):
    # (k, n), (1, n) -> (k) cal correlation between y and each x. row-wise correlation!
    x_demean = x - np.nanmean(x)
    y_demean = y - np.nanmean(y)
    
    out[0] = np.nansum(x_demean*y_demean) / np.sqrt(np.nansum(x_demean**2)*np.nansum(y_demean**2))
    
def rcor(x, y, w):
    x1 = rankdata(x, method='average')
    y1 = rankdata(y, method='average')
    return pcor(x1, y1, w)

def cor(x, y, w):
    # sum(x * y * weight) / sqrt(sum(x * x * weight)) / sqrt(sum(y * y * weight))
    return 100 * np.dot(x*y, w) / np.sqrt(np.dot(x*x, w)) / np.sqrt(np.dot(y*y, w))

def pcor(x, y, w):
    x = x - np.average(x, weights=w)  # average = sum(a * weights) / sum(weights)
    y = y - np.average(y, weights=w)
    return cor(x,y,w)

def fr(x, y, w):
    # sum(x * y * weight) / sum(x * x * weight)
    return np.dot(x*y, w) / np.dot(x*x, w)


def FR(x, y, w):
    # mean(x * y * weight) / sqrt(mean(x * x * weight)) / sqrt(mean(weight))
    return 1e4 * np.mean(x*y*w) / np.sqrt(np.mean(x*x*w)) / np.sqrt(np.mean(w))

def PFR(x, y, w):
    x = x - np.mean(x)
    y = y - np.mean(y)
    # mean(x * y * weight) / sqrt(mean(x * x * weight)) / sqrt(mean(weight))
    return 1e4 * np.mean(x*y*w) / np.sqrt(np.mean(x*x*w)) / np.sqrt(np.mean(w))

def _customized_metric_cor_weight(preds, labels, weights):
    if weights is None:
        weights = np.ones_like(preds)  # refer to lightgbm.basic.Dataset.set_weight()
    score = cor(x=preds, y=labels, w=weights)
    return 'cor', score, True

def _customized_metric_cor(preds, labels):
    score = cor(x=preds, y=labels, w=np.ones_like(preds))
    return 'cor', score, True


def feval_cor(y_hat, dmat):
    y = dmat.get_label()
    w = dmat.get_weight()
    return 'cor', cor(y_hat, y, w)

def feval_cor_fr(y_hat, dmat):
    # encode cor and fr into one value: 
    # [myfr][mycor:5][sign(myfr):1][sign(mycor):1], sign: 1: stats>=0
    y = dmat.get_label()
    w = dmat.get_weight()
    mycor = cor(y_hat, y, w) 
    myfr = fr(y_hat, y, w)
    print ('cor:', mycor, 'fr:', myfr)
    # encode:
    cor_fr = (int(abs(myfr*100))*100000  + int(abs(mycor)*100))*100 + (myfr>=0)*10+(mycor>=0)  
    return 'cor_fr', int(cor_fr)

def decode_fr_from_cor_fr(cor_fr):
    # fr = math.floor(cor_fr/10) / 100
    fr = (cor_fr//10000000)/100
    if (cor_fr%100<10):
        fr *= -1
    return fr

def decode_cor_from_cor_fr(cor_fr):
    cor = ((cor_fr%10000000)//100)/100
    if cor_fr%10<=0:
        cor *= -1
    return cor
class DateGrouper:
    def __init__(self, date_vec):
        self.date_vec = date_vec

    def by_month(self):
        months = self.date_vec // 100
        unique_months = np.unique(months)
        return [(str(int(month)), months == month) for month in unique_months]

    def by_date(self):
        unique_dates = np.unique(self.date_vec)
        return [(str(int(date)), self.date_vec == date) for date in unique_dates]

    def by_all(self):
        months = self.date_vec // 100
        unique_months = np.unique(months)
        name = '%d-%d' % (min(unique_months), max(unique_months))
        return [(name, np.ones((self.date_vec.shape[0], )))]

#TODO: add SR rcor
class Evaluator:
    def __init__(self, y_hat, dataset, groups, col_labels, print_pcor):
        if isinstance(dataset, dict):
            assert dataset['Y'] is not None and dataset['y_names'] is not None
            assert y_hat.shape[0] == dataset['Y'].shape[0]
            self.y_hat = y_hat
            self.Y = dataset['Y']
            self.y_colnames = dataset['y_names']
            self.n = dataset['Y'].shape[0]
            if dataset['w'] is None:
                self.w = np.ones((self.n, ))
            else:
                self.w = dataset['w']
        else: # dataset is wrapped in qrfitter2 or qrfitter
            assert dataset.Y is not None and dataset.y_colnames is not None
            assert y_hat.shape[0] == dataset.Y.shape[0]
            self.y_hat = y_hat
            self.Y = dataset.Y
            self.y_colnames = dataset.y_colnames
            self.n = dataset.Y.shape[0]
            if dataset.w is None:
                self.w = np.ones((self.n, ))
            else:
                self.w = dataset.w

        self.groups = groups
        self.col_labels = col_labels
        self.print_pcor = print_pcor

    def save_y_hat(self, outfile):
        #import pytbl
        #pytbl.tbl_write()

        #self.y_hat
        pass

    def calculate_metrics(self):
        n_groups = len(self.groups)
        if n_groups > 100:
            print('warning: too many groups %d > 100!' % n_groups)
        ys = self.Y.shape[1]

        cor_table = np.zeros((n_groups, ys))
        pcor_table = np.zeros((n_groups, ys))
        fr_table = np.zeros((n_groups, ys))
        FR_table = np.zeros((n_groups, ys))

        for i, (grp_name, grp_idx) in enumerate(self.groups):
            for j in range(ys):
                # remove nan in Y label
                validmask = ~np.isnan(self.Y[grp_idx, j]) 
                y_hat = self.y_hat[grp_idx][validmask]
                y = self.Y[grp_idx, j][validmask]
                w = self.w[grp_idx][validmask]
                cor_table[i, j] = cor(y_hat, y, w)
                pcor_table[i, j] = pcor(y_hat, y, w)
                fr_table[i, j] = fr(y_hat, y, w)
                FR_table[i, j] = FR(y_hat, y, w)

        grp_names = [grp_name for grp_name, _ in self.groups]
        cor_labels = ['cor.' + l for l in self.col_labels]
        pcor_labels = ['pcor.' + l for l in self.col_labels]
        fr_labels = ['fr.' + l for l in self.col_labels]
        FR_labels = ['FR.' + l for l in self.col_labels]
        
        if self.print_pcor:
            df = pd.DataFrame(np.hstack([cor_table, pcor_table,fr_table, FR_table]),
                          index=grp_names,
                          columns=flatten_list([cor_labels, pcor_labels,fr_labels, FR_labels]))
        else:
            df = pd.DataFrame(np.hstack([cor_table,fr_table, FR_table]),
                          index=grp_names,
                          columns=flatten_list([cor_labels,fr_labels, FR_labels]))
        return df


def evaluate(yhat_df: pd.DataFrame, learner=None, D="date") -> dict:
    res = dict()
    if learner is not None and isinstance(learner.y_names, np.ndarray):  # temp for single yhat multi y
        x = yhat_df['yhat'].values
        w = yhat_df['weight'].values
        for name in learner.y_names:
            y = yhat_df[f'y_{name}'].values
            res[f"cor_{name}"] = round(cor(x, y, w), 1)
            res[f"FR_{name}"] = round(FR(x, y, w), 1)
            res[f"fr_{name}"] = round(fr(x, y, w), 1)
            if pd.__version__ == '2.2.0':
                xy_series = yhat_df.groupby("D").apply(lambda x: (x['yhat']*x[f'y_{name}']*x["weight"]).mean(), include_groups=False)
            else:
                xy_series = yhat_df.groupby("D").apply(lambda x: (x['yhat']*x[f'y_{name}']*x["weight"]).mean(), include_groups=False)
            res[f"SR_{name}"] = round(xy_series.mean() / xy_series.std() * np.sqrt(252), 1)
    else:
        x = yhat_df['yhat'].values
        y = yhat_df['y'].values
        w = yhat_df['weight'].values
        # if learner is not None and hasattr(learner, "loss_fn"):  # only for nn
        #     args = (x,y,w)
        #     try:
        #         res["loss"] = round(learner.loss_fn.cpu()(*[torch.from_numpy(arg) for arg in args]).item(), 10)
        #     except Exception as e:  # TODO:loss_fn可能需要其他输入
        #         res["loss"] = np.nan
        res["cor"] = round(cor(x, y, w), 1)
        res["pcor"] = round(pcor(x, y, w), 1)
        res["rcor"] = round(rcor(x, y, w), 1)
        res["fr"] = round(fr(x, y, w), 1)
        res["FR"] = round(FR(x, y, w), 1)
        if pd.__version__ == '2.2.0':
            xy_series = yhat_df.groupby(D).apply(lambda x: (x['yhat']*x['y']*x["weight"]).mean(), include_groups=False)
        else:
            xy_series = yhat_df.groupby(D).apply(lambda x: (x['yhat']*x['y']*x["weight"]).mean())
        res["SR"] = round(xy_series.mean() / xy_series.std() * np.sqrt(252), 1)
    return res