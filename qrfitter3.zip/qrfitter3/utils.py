# -*- coding: utf-8 -*-
import itertools
import os, sys
import datetime
from time import mktime
import pandas as pd
import numpy as np
import re
import shutil
import yaml
import json
import logging
import warnings
import psutil
import time
import panel
from typing import Union
import importlib.util


def set_order(a):
    b = list(pd.unique(a))
    return b
    
def get_epoch_from_date_and_time(date, time):
    date = int(date)
    year = date // 10000
    month = (date % 10000) // 100
    day = date % 100
    
    time = time.split(':')
    hours = int(time[0])
    mins = int(time[1])
    secs = int(time[2])

    dt =  datetime.datetime(year, month, day, hours, mins, secs)
    return int(mktime(dt.timetuple()))

def get_months_between_dates(date_start, date_end):
    'Return YYYYMM string list for months between (inclusive)'
    if date_start > date_end:
        return []
    if isinstance(date_start, int):
        year_start = date_start // 10000
    else:
        year_start = int(date_start[:4])
    if isinstance(date_end, int):
        year_end = date_end // 10000
    else:
        year_end = int(date_end[:4])
    months = ['{}{:>02}'.format(a, b) for (a, b) in itertools.product(range(year_start, year_end+1),
                                                            range(1, 13))]
    return [m for m in months if date_start[:6] <= m <= date_end[:6]]


def get_next_month_for_date(cur_date):
    'Return YYYYMM string for next month'
    if isinstance(cur_date, int):
        year = cur_date // 10000
        month = (cur_date % 10000) // 100
    else:
        year = int(cur_date[:4])
        month = int(cur_date[4:6])
    if month == 12:
        year = year + 1
        month = 1
    else:
        month = month + 1
    return '{}{:>02}'.format(year, month)

def next_month(datestr):
    year = int(datestr[:4])
    month = int(datestr[4:6])
    month += 1
    if month >= 13:
        month = 1
        year += 1
    return '%d%02d' % (year, month)

def feature_name_to_alpha_name(feature_name):
    'Feature names are in xxx-xxx-xxx format, remove the last one'
    return '-'.join(feature_name.split('-')[:-1])


def y_colnames_to_col_labels(y_colnames, pattern=None):
    """
    input customized pattern.  
    notes：json时需要在`\`前加入`\`来防止转译！！！！！！

    useful pattern:
    # 保留两段数字和结尾，'mret24h1b'->'24h1b' : '(\-?\d+\D+\d+\D+)$'
    # 保留最后数字和结尾，'mret_cum24h'->'24h' : "(\-?\d+\D+)$"
    # 去掉开头特定字符，如去掉开头mret, ret，'^mret(.+)$'
    """

    ## bacward compatibility
    if pattern is None or isinstance(pattern, str):
        if pattern is None:
            print ("WARNING: pattern = None is for backward compatibility; don't use it in the future; set pattern as '^mret(.+)$'")
            pattern = '^mret(.+)$' # default is removing starting 'mret'
        
        labels = []
        pattern_compile = re.compile(pattern)
        for x in y_colnames:
            label = pattern_compile.findall(x) #'mret24h1b'->'24h1b'
            if len(label)>0:
                label = label[0]
            else:
                label = x
            labels.append(label)
        return labels
    elif isinstance(pattern, dict):
        labels = []
        for x in y_colnames:
            if x in pattern:
                labels.append(pattern[x]) # use map
            else:
                labels.append(x) # unchanged
        return labels
    else:
        raise Exception("Unknown pattern type")
    

def make_dir(path, show_warning=True):
    if not os.path.exists(path):
        os.makedirs(path)
    elif show_warning:
        print('WARNING: path already exists', path)
    else:
        pass


def flatten_list(lst):
    return list(itertools.chain(*lst))


def filesize(f):
    return os.stat(f).st_size


def write_lines(filename, lines):
    with open(filename, 'w') as f:
        for line in lines:
            f.write(line)
            f.write('\n')


def read_lines(filename):
    lines = open(filename).readlines()
    return [line.strip() for line in lines]


def turn_pattern_to_list(pattern, colnames):
    if not isinstance(pattern, list): 
        # pattern is a str(python3) or unicode(python2) 
        return list(filter(re.compile(pattern).search, colnames))
    else:
        assert isinstance(pattern, list)
        return pattern

def train_test_split(ds, cfg):
    """
    支持多种train_test_split，想增加可以继续。
    目前默认default是原本的
    cfg = {
        "type":"time_split",
        "train_ratio":0.8
    }
    """
    mtype = cfg.get("type","time_split") # default is time_split
    if mtype=="time_split":
        gap_bdays = int(cfg.get("gap_days",0))
        if "train_start_month" in cfg: # 保持和原本一致
            ds_train = ds.get_data_by_month_range(cfg['train_start_month'], cfg['train_end_month'], gap=gap_bdays)
            if cfg['do_test']:
                ds_test = ds.get_data_by_month_range(cfg['test_start_month'], cfg['test_end_month'])
            else:
                ds_test = None
        else:
            train_ratio = float(cfg["train_ratio"])
            dates = np.unique(ds.extra["date"])
            test_idx = int(len(dates)*train_ratio)
            assert (test_idx>0) and (test_idx<len(dates)), f"wrong test idx {test_idx} out of {len(dates)}"
            train_sdate = dates[0]
            train_edate = dates[test_idx-gap_bdays-1]
            test_sdate = dates[test_idx]
            test_edate = dates[-1]
            ds_train = ds.get_data_by_date_range(train_sdate, train_edate)
            ds_test = ds.get_data_by_date_range(test_sdate, test_edate)        
    elif mtype=="no_eval":
        ds_train = ds
        ds_test = ds.get_data_by_bool(np.zeros_like(ds.w, dtype=bool))
    else:
        raise NotImplementedError(f"{mtype}")
    wgt_hl = cfg.get("wgt_hl", "inf")
    if wgt_hl != "inf":
        wgt_hl = float(wgt_hl)
        print("using wgt_hl", wgt_hl)
        date = ds_train.extra["date"]
        dates = np.sort(np.unique(date))[::-1]
        extra_wgts = np.zeros(date.shape)
        for i, d in enumerate(dates):
            extra_wgts[date == d] = 2 ** ( - i / wgt_hl)
        ds_train.w *= extra_wgts
        print("HL DEBUG", dates, date, extra_wgts, ds_train.w)
    sid_wgt_mult = cfg.get("sid_wgt_mult", {})
    if len(sid_wgt_mult) > 0:
        print("SWM debug", sid_wgt_mult)
        sid = ds_train.extra['sid']
        extra_wgts = np.zeros(sid.shape) + 1
        for s, mult in sid_wgt_mult.items():
            extra_wgts[sid == int(s)] = mult
        ds_train.w *= extra_wgts

        sid = ds_test.extra['sid']
        extra_wgts = np.zeros(sid.shape) + 1
        for s,mult in sid_wgt_mult.items():
            extra_wgts[sid == int(s)] = mult
        ds_test.w *= extra_wgts


    print("Train:", ds_train)
    print("Test:",ds_test)
    return ds_train, ds_test

class Map(dict):
    """
    Example:
    m = Map({'first_name': 'Eduardo'}, last_name='Pool', age=24, sports=['Soccer'])
    """
    def __init__(self, *args, **kwargs):
        super(Map, self).__init__(*args, **kwargs)
        for arg in args:
            if isinstance(arg, dict):
                for k, v in arg.items():
                    self[k] = v

        if kwargs:
            for k, v in kwargs.items():
                self[k] = v

    def __getattr__(self, attr):
        return self.get(attr)

    def __setattr__(self, key, value):
        self.__setitem__(key, value)

    def __setitem__(self, key, value):
        super(Map, self).__setitem__(key, value)
        self.__dict__.update({key: value})

    def __delattr__(self, item):
        self.__delitem__(item)

    def __delitem__(self, key):
        super(Map, self).__delitem__(key)
        del self.__dict__[key]


level_dict = {0: logging.DEBUG, 1: logging.INFO, 2: logging.WARNING}

def get_logger(filename=None, verbose=1, name=None):
    
    formatter = logging.Formatter(
        "[%(asctime)s][%(filename)s][line:%(lineno)d][%(levelname)s] %(message)s"
    )
    logger = logging.getLogger(name)
    logger.setLevel(level_dict[verbose])
    
    if filename is not None:
        fh = logging.FileHandler(filename, "w")
        fh.setFormatter(formatter)
        logger.addHandler(fh)
 
    sh = logging.StreamHandler()
    sh.setFormatter(formatter)
    logger.addHandler(sh)
 
    return logger

def read_yaml(path: str) -> dict:
    with open(path, encoding='utf-8', mode='r') as f:
        data = yaml.load(f.read(), Loader=yaml.FullLoader)
    return data

def save_yaml(data:dict, path: str):
    with open(path, encoding='utf-8', mode='w') as f:
        yaml.dump(data=data, stream=f, allow_unicode=True)

def read_json(path: str):
    with open(path, 'r') as file:
        data = json.load(file)
    return data

def save_json(data, path: str) -> dict:
    with open(path, 'w') as file:
        json.dump(data, file, indent=4, sort_keys=True)


def recreate_folder(folder_path):
    if os.path.exists(folder_path):
        shutil.rmtree(folder_path)
    os.makedirs(folder_path)

def save_df_as_sdiv_daily(df, folder, fn='yhat', S='S', D='D', I='I'):
    warnings.filterwarnings("ignore", category=FutureWarning)  # panel.py:290, future_stack=True
    os.makedirs(folder, exist_ok=True)
    for date, date_df in df.groupby(D):
        xarr = panel.df2sdiv(date_df, S=S, D=D, I=I)
        panel.write(os.path.join(folder, f"{fn}.{date}.sdiv"), xarr)

def is_process_running(pid):
    try:
        process = psutil.Process(pid)
    except psutil.NoSuchProcess:
        return False
    else:
        return True
    
def wait_for_processes(pids: Union[int, list]):
    """等待pids中所有进程结束"""
    if isinstance(pids, int):
        pids = [pids]
    while any([is_process_running(pid) for pid in pids]):
        time.sleep(300)

def check_valid_test_monotonicity(set_results, task_outdir):
    user_path_dict = {
        "junming": "/data/bees1/safe/junming/equity_fitting/valid_test_warning_flag",
    }
    if os.environ['USER'] not in user_path_dict:
        return
    flag_folder = user_path_dict[os.environ['USER']]
    baseline = read_json(os.path.join(flag_folder, "baseline.json"))
    baseline_valid_FR, baseline_test_FR = baseline["valid"]["FR"], baseline["test"]["FR"]
    fit_valid_FR, fit_test_FR = set_results["valid"]["FR"], set_results["test"]["FR"]
    warning_log_path = os.path.join(flag_folder, "warning_log.txt")
    log_info = None
    if fit_valid_FR > baseline_valid_FR and fit_test_FR < baseline_test_FR:
        log_info = f"valid_FR:{fit_valid_FR:.1f} > baseline:{baseline_valid_FR:.1f}, while test_FR:{fit_test_FR:.1f} < baseline:{baseline_test_FR:.1f}. fit_folder: {task_outdir}" + '\n'
    elif fit_valid_FR < baseline_valid_FR and fit_test_FR > baseline_test_FR:
        log_info = f"valid_FR:{fit_valid_FR:.1f} < baseline:{baseline_valid_FR:.1f}, while test_FR:{fit_test_FR:.1f} > baseline:{baseline_test_FR:.1f}. fit_folder: {task_outdir}" + '\n'
    if log_info is not None:
        if os.path.exists(warning_log_path):
            with open(warning_log_path, 'a') as file:
                file.write(log_info)
        else:  # 如不存在则创建文件
            with open(warning_log_path, 'w') as file:
                file.write(log_info)


def get_run_periods(pattern, start_date:str=None, end_date:str=None):
    from pattern_helper import find_dates_from_pattern
    run_periods = find_dates_from_pattern(pattern)
    start_date = 0 if start_date is None else int(start_date)
    end_date = 30000000 if end_date is None else int(end_date)
    run_periods = [d for d in run_periods if d >= start_date and d <= end_date]
    return run_periods


def load_class(file_path, class_name):
    """从py文件中动态加载类"""
    # 检查文件是否存在
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"File '{file_path}' does not exist.")
    # 加载模块
    module_name = os.path.splitext(os.path.basename(file_path))[0]  # 提取文件名作为模块名
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module  # 动态加载后将module添加到 sys.modules, for pickle at torch.save
    spec.loader.exec_module(module)  # 动态加载模块
    class_object = getattr(module, class_name)
    globals()[class_name] = class_object  # 动态加载后将类声明到全局, for pickle at torch.save
    return class_object

def copy_folder_contents(src_folder, dest_folder):
    """
    递归地将 src 文件夹复制到 dst 文件夹
    """
    if not os.path.exists(dest_folder):
        os.makedirs(dest_folder)
    
    for item in os.listdir(src_folder):
        src_path = os.path.join(src_folder, item)
        dst_path = os.path.join(dest_folder, item)
        
        if os.path.isdir(src_path):
            copy_folder_contents(src_path, dst_path)
        else:
            shutil.copy2(src_path, dst_path)