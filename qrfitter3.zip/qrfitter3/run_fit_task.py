import argparse
from qrfitter3.nnfitter.run import run_fit_task
from qrfitter3.utils import read_json


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument("config_path")
    args = parser.parse_args()
    config = read_json(args.config_path)
    run_fit_task(config)