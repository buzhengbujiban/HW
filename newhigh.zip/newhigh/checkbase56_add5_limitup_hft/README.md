# checkbase56_add5_limitup_hft —— 基于 checkafterbase 选股池的 raw_long_table 数据管线

## 目的
在 `checkafterbase_limitup` 选股池（最宽的"破前高 + 涨停回踩"基础池，342 个交易日、
20240430~20250930）之上，参考 `jk/DataLoader` 的数据读取方式，逐 tick 抽取 LOB /
ordertrans，计算 lags（未来收益标签），并 merge 成 `raw_long_table`，供后续高频因子
（factor1_mini）/ 信号 / 回测复用。

> 选用 checkafterbase 作为 universe 的原因：checkafterbase56 / checkafterbase56_add5
> 等都是它的子集，在最宽的池上抽一遍数据，后续子集策略可直接复用同一份 raw_long_table。

## 数据根目录
```
NEW_ROOT = /home/datamake119/data1/user118/newhigh/checkbase_hft
├── daily_results/{date}.pkl              # step0：universe（{"date","universe_codes"}）
├── lob_sh|lob_sz/{date}_lob.parquet      # step1a：抽取后的 LOB
├── ordertrans_sh|ordertrans_sz/{date}_ordertrans.fea  # step1b：抽取后的逐笔
├── lags/lags_{date}.parquet              # step2：盘口指标 + 未来收益 lags
└── raw_long_table/
    ├── sh_ordertranlob/{date}.parquet    # step3：沪市合并结果
    └── sz_ordertranlob/{date}.parquet    # step3：深市合并结果
```

## 流程（均为单日脚本，便于 echo / xargs 并行与断点恢复）
| step | 脚本 | 说明 |
|------|------|------|
| 0 | `build_universe.py`     | 从 `checkafterbase_limitup/segments_daily/{date}.parquet` 取 code，写 universe pkl |
| 1a | `extract_lob.py`        | 谓词下推抽取沪深 LOB（code 为 int），输出 lob_sh/lob_sz |
| 1b | `extract_ordertrans.py` | arrow `is_in` 抽取沪深 ordertrans（code 为 `xxxxxx.SH/SZ`） |
| 2 | `lags_process_all.py`    | 经 `DataLoader(lob_root=NEW_ROOT)` 读 LOB，逐 tick 算 ap/bp/as/bs 与 LA10/60/3600/43200/EOD/EOD1/2/5/SVWAP1/2/5 |
| 3 | `create_long_table_sh.py` / `create_long_table_sz.py` | ordertrans + lob + lags 三表 merge，输出 raw_long_table |

口径与 `jk/hft/` 下同名脚本完全一致，唯一差异是数据根目录指向 `NEW_ROOT`、universe
来源指向 checkafterbase 池。

## 批量运行
```bash
bash run_all.sh all                  # step0~3，全部日期
bash run_all.sh step1 20250121       # 只跑 step1 单天
PARALLEL=24 bash run_all.sh all      # 指定并行度（默认 24）
```

## 已验证（2025-01-21）
- universe：31 只
- LOB：lob_sh 37.7MB / lob_sz 81.0MB
- ordertrans：SH 2,384,428 + SZ 3,411,345 = 5,795,773 条
- lags：5,795,773 行 / 31 股
- raw_long_table：SH 2,384,428 行、SZ 3,411,345 行；LA10 非空率约 96.6%
