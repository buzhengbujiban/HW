"""
step3-SZ —— 合并 ordertrans_sz + lob_sz + lags 生成深市 raw_long_table（单日，便于 echo 并行）。

输入（均来自本管线 NEW_ROOT）：
  - lags ：{NEW_ROOT}/lags/lags_{date}.parquet
  - ordertrans_sz：{NEW_ROOT}/ordertrans_sz/{date}_ordertrans.fea
  - lob_sz：{NEW_ROOT}/lob_sz/{date}_lob.parquet

输出：
  {NEW_ROOT}/raw_long_table/sz_ordertranlob/{date}.parquet

逻辑与 jk/hft/create_long_table_sz.py 完全一致（merge key 对齐 + .SZ 后缀），
仅改：数据根目录 -> NEW_ROOT；改为单日 argparse，便于 echo 并行与断点恢复。

用法：
  python create_long_table_sz.py --date 20250121
  # echo 并行：
  #   ls {NEW_ROOT}/lags | sed 's/lags_//;s/.parquet//' \
  #     | xargs -P 12 -I{} python create_long_table_sz.py --date {}
"""

from __future__ import annotations

import os
import argparse
import logging

import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("checkbase_hft.long_table_sz")

NEW_ROOT = "/home/datamake119/data1/user118/newhigh/checkbase_hft"
LAGS_DIR = os.path.join(NEW_ROOT, "lags")
OUTPUT_DIR = os.path.join(NEW_ROOT, "raw_long_table", "sz_ordertranlob")

ADD_COLS = ['date', 'LA10', 'LA60', 'LA3600', 'LA43200', 'LAEOD', 'LAEOD1',
            'LAEOD2', 'LAEOD5', 'LASVWAP1', 'LASVWAP2', 'LASVWAP5']


def _read_tick_file(path):
    if path.endswith(".fea"):
        return pd.read_feather(path)
    return pd.read_parquet(path)


def process_long_table(date: str):
    lags_path = os.path.join(LAGS_DIR, f"lags_{date}.parquet")
    ot_path = os.path.join(NEW_ROOT, "ordertrans_sz", f"{date}_ordertrans.fea")
    lob_path = os.path.join(NEW_ROOT, "lob_sz", f"{date}_lob.parquet")

    for p in (lags_path, ot_path, lob_path):
        if not os.path.exists(p):
            logger.info("%s 缺少输入文件: %s，跳过", date, p)
            return

    lags0014 = pd.read_parquet(lags_path)
    trans_order = _read_tick_file(ot_path)
    ssa0014 = pd.read_parquet(lob_path)

    # 1) lags 的 code 加 .SZ 后缀
    lags0014 = lags0014.copy()
    lags0014["code"] = lags0014["code"].astype(str).str.zfill(6) + ".SZ"
    lags0014["time"] = lags0014["time"].astype("int64")
    lags0014["seq_num"] = lags0014["seq_num"].astype("int64")

    # 2) LOB code int32 -> "xxxxxx.SZ"
    ssa0014["code"] = ssa0014["code"].astype("int64").astype(str).str.zfill(6) + ".SZ"
    ssa0014["time"] = ssa0014["time"].astype("int64")
    ssa0014["seq_num"] = ssa0014["seq_num"].astype("int64")

    # 3) trans_order merge key 类型对齐
    trans_order["code"] = trans_order["code"].astype(str)
    trans_order["time"] = trans_order["time"].astype("int64")
    trans_order["number"] = trans_order["number"].astype("int64")
    trans_order['size'] = trans_order['volume']

    ssa0014 = ssa0014.merge(lags0014[ADD_COLS + ['seq_num', 'code', 'time']],
                            on=['code', 'time', 'seq_num'], how='left', suffixes=("", "_lags"))

    trans_order_lags = trans_order.merge(
        ssa0014, left_on=['code', 'time', 'number'],
        right_on=['code', 'time', 'seq_num'], how='left', suffixes=("", "_lob"))

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_path = os.path.join(OUTPUT_DIR, f"{date}.parquet")
    trans_order_lags.to_parquet(out_path)
    logger.info("%s SZ raw_long_table 保存 %d 行 -> %s", date, len(trans_order_lags), out_path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, required=True, help="交易日 YYYYMMDD")
    args = parser.parse_args()
    process_long_table(args.date)


if __name__ == "__main__":
    main()
