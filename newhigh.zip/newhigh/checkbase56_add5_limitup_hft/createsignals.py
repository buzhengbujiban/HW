#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
createsignals.py —— step5：读取 factor1_mini 因子文件，为每个因子：
  (a) 画"因子值 x-bins  vs  各 lag(尤其 LASVWAP1) 的 y-mean"曲线图，
      用于人工/自动观察"因子值大到什么程度，下一段大概率获得正收益"；
  (b) 据此选出每个因子的阈值 threshold_i（默认：LASVWAP1 的 bin 均值由负转正、
      且其后保持为正 的最小因子值；可用 --quantile 改为分位数法）；
  (c) 输出"因子 i > 阈值 i"时、**下一个 tick 的 mid** 作为买入参考价的表格。

输入：
  {FACTOR_DIR}/factor1_mini_{date}.parquet（step4 输出）
输出：
  {OUT_DIR}/curves/{factor}__{lag}.png            —— x-bins vs y-mean 曲线
  {OUT_DIR}/thresholds.csv                         —— 每个因子选定阈值
  {OUT_DIR}/signals/{factor}_{date}.parquet        —— 触发信号 + 买入参考价(next_mid)
  {OUT_DIR}/signals_all.parquet                    —— 合并所有日期/因子的信号表

用法：
  python createsignals.py                       # 用全部已有 factor 日期
  python createsignals.py --date 20250121       # 只用单天
  python createsignals.py --quantile 0.7        # 阈值改为因子分位数法
"""

from __future__ import annotations

import argparse
import glob
import logging
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("checkbase_hft.createsignals")

NEW_ROOT = "/home/datamake119/data1/user118/newhigh/checkbase_hft"
FACTOR_DIR = os.path.join(NEW_ROOT, "factors", "factor1_mini")
OUT_DIR = os.path.join(NEW_ROOT, "signals")

FACTOR_COLS = [
    "size_add_newlevel1_BSimb",
    "trdact_BSimb_diff",
    "size_add_newlevel1_prob_BSimb",
    "size_trdact_allormorelevel1_prob_BSimb",
    "size_trdact_atlevel1_prob_BSimb",
]
LA_COLS = ["LA10", "LA60", "LA3600", "LA43200",
           "LAEOD", "LAEOD1", "LAEOD2", "LAEOD5",
           "LASVWAP1", "LASVWAP2", "LASVWAP5"]
TARGET_LAG = "LASVWAP1"   # 选阈值时主要观察的标签
N_BINS = 30               # x-bins 数量


def _load_factor_data(date: str | None) -> pd.DataFrame:
    if date:
        files = [os.path.join(FACTOR_DIR, f"factor1_mini_{date}.parquet")]
    else:
        files = sorted(glob.glob(os.path.join(FACTOR_DIR, "factor1_mini_*.parquet")))
    frames = []
    for f in files:
        if not os.path.exists(f):
            continue
        df = pd.read_parquet(f)
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def _bin_curve(fv: pd.Series, lag: pd.Series, n_bins: int):
    """按因子值分位数分箱，返回 (每箱因子均值, 每箱 lag 均值, 每箱样本数, 每箱因子右边界)。"""
    d = pd.DataFrame({"f": fv, "y": lag}).replace([np.inf, -np.inf], np.nan).dropna()
    if len(d) < n_bins * 5:
        return None
    try:
        d["bin"], edges = pd.qcut(d["f"], n_bins, labels=False, retbins=True, duplicates="drop")
    except ValueError:
        return None
    g = d.groupby("bin")
    x = g["f"].mean().to_numpy()
    y = g["y"].mean().to_numpy()
    cnt = g["y"].size().to_numpy()

    right = edges[1:][: len(x)]
    return x, y, cnt, right


def _plot_curves(df: pd.DataFrame, out_dir: str):
    """对每个因子，画 x-bins vs 各 lag 的 y-mean。重点 lag 单独大图。"""
    cur_dir = os.path.join(out_dir, "curves")
    os.makedirs(cur_dir, exist_ok=True)
    for fac in FACTOR_COLS:
        if fac not in df.columns:
            continue
        # 汇总图：所有 lag 叠加（已标准化到各自范围便于看符号变化）
        fig, ax = plt.subplots(figsize=(9, 5))
        for lag in LA_COLS:
            if lag not in df.columns:
                continue
            res = _bin_curve(df[fac], df[lag], N_BINS)
            if res is None:
                continue
            x, y, cnt, right = res
            ax.plot(x, y, marker=".", ms=3, lw=1, label=lag)
        ax.axhline(0, color="k", lw=0.8, ls="--")
        ax.set_title(f"{fac}: factor x-bins vs mean(lag)")
        ax.set_xlabel(fac)
        ax.set_ylabel("mean forward return (lag)")
        ax.legend(fontsize=7, ncol=2)
        fig.tight_layout()
        fig.savefig(os.path.join(cur_dir, f"{fac}__ALL.png"), dpi=110)
        plt.close(fig)

        # 重点 lag 单独图（含样本量副轴）
        res = _bin_curve(df[fac], df[TARGET_LAG], N_BINS)
        if res is None:
            continue
        x, y, cnt, right = res
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.plot(x, y, marker="o", ms=4, color="tab:blue", label=f"mean({TARGET_LAG})")
        ax.axhline(0, color="k", lw=0.8, ls="--")
        ax.set_xlabel(fac)
        ax.set_ylabel(f"mean({TARGET_LAG})", color="tab:blue")
        ax2 = ax.twinx()
        ax2.bar(x, cnt, width=(x.max() - x.min()) / (len(x) * 1.5),
                alpha=0.2, color="tab:gray", label="count")
        ax2.set_ylabel("count", color="tab:gray")
        ax.set_title(f"{fac} vs mean({TARGET_LAG})")
        fig.tight_layout()
        fig.savefig(os.path.join(cur_dir, f"{fac}__{TARGET_LAG}.png"), dpi=110)
        plt.close(fig)
    logger.info("曲线图已保存到 %s", cur_dir)


def _pick_threshold(df: pd.DataFrame, fac: str, quantile: float | None) -> float | None:
    """选阈值：
      - quantile 指定时：取因子的该分位数；
      - 否则：在 x-bins vs mean(LASVWAP1) 曲线上，找"因子值越大、bin 均值稳定为正"
        的最小因子值（即最后一个由负转正且其后均为正的拐点）。
    """
    if quantile is not None:
        v = df[fac].replace([np.inf, -np.inf], np.nan).dropna()
        return float(v.quantile(quantile)) if len(v) else None

    res = _bin_curve(df[fac], df[TARGET_LAG], N_BINS)
    if res is None:
        return None
    x, y, cnt, right = res
    # 从高到低扫描，找到"从最高 bin 起连续为正"的最低因子值
    pos = y > 0
    if not pos.any():
        return None
    thr = None
    for i in range(len(x) - 1, -1, -1):
        if pos[i]:
            thr = float(x[i])
        else:
            break
    # 若最高 bin 不为正，则退化为"均值>0 的最小因子值"
    if thr is None:
        idx = np.where(pos)[0]
        thr = float(x[idx.min()])
    return thr


def _pick_threshold_with_fallback(df: pd.DataFrame, fac: str, quantile: float | None,
                                  fallback_q: float = 0.8) -> float | None:
    """先用曲线拐点法选阈值；若拿不到（小样本/全负），退化为因子的 fallback_q 分位数。"""
    thr = _pick_threshold(df, fac, quantile)
    if thr is None or (isinstance(thr, float) and np.isnan(thr)):
        v = df[fac].replace([np.inf, -np.inf], np.nan).dropna()
        if len(v):
            thr = float(v.quantile(fallback_q))
            logger.info("因子 %s 曲线法无正区间，退化为 %.0f%% 分位阈值 %.4f", fac, fallback_q * 100, thr)
    return thr



def build_signals(df: pd.DataFrame, thresholds: dict[str, float], out_dir: str) -> pd.DataFrame:
    """对每个因子，取 factor > threshold 的 tick，输出 next_mid 作为买入参考价。"""
    sig_dir = os.path.join(out_dir, "signals")
    os.makedirs(sig_dir, exist_ok=True)
    all_sig = []
    for fac, thr in thresholds.items():
        if thr is None or fac not in df.columns:
            continue
        # ===== 触发：因子 i > 阈值 i =====
        mask = (df[fac] > thr) & df["next_mid"].notna()
        sub = df.loc[mask, ["date", "code", "time", "seq_num", "bp1", "sp1", "mid", "next_mid"] + LA_COLS].copy()
        if sub.empty:
            continue
        sub["factor"] = fac
        sub["threshold"] = thr
        sub["factor_value"] = df.loc[mask, fac].to_numpy()
        sub = sub.rename(columns={"next_mid": "buy_ref_price"})  # 买入参考价 = 下一 tick 的 mid
        # 每只票每天只保留首个触发信号（日内首次出现即买入）
        sub = sub.sort_values(["date", "code", "time", "seq_num"])
        first = sub.groupby(["date", "code"], as_index=False).first()
        for d in first["date"].unique():
            day = first[first["date"] == d]
            day.to_parquet(os.path.join(sig_dir, f"{fac}_{str(d).replace('-', '')}.parquet"), index=False)
        all_sig.append(first)
        logger.info("因子 %s 阈值 %.4f：触发 %d 只(票,日) 信号", fac, thr, len(first))

    if not all_sig:
        return pd.DataFrame()
    sig_all = pd.concat(all_sig, ignore_index=True)
    sig_all.to_parquet(os.path.join(out_dir, "signals_all.parquet"), index=False)
    logger.info("合并信号表 -> %s（%d 行）", os.path.join(out_dir, "signals_all.parquet"), len(sig_all))
    return sig_all


def main():
    parser = argparse.ArgumentParser(description="step5：因子曲线 + 阈值 + 买入参考价信号表")
    parser.add_argument("--date", type=str, default=None, help="只用单天 YYYYMMDD；缺省用全部")
    parser.add_argument("--quantile", type=float, default=None,
                        help="阈值改用因子分位数法（如 0.7）；缺省用曲线拐点法")
    args = parser.parse_args()

    os.makedirs(OUT_DIR, exist_ok=True)
    df = _load_factor_data(args.date)
    if df.empty:
        logger.error("无 factor1_mini 数据，先跑 step4")
        return
    logger.info("载入因子数据 %d 行，%d 票，日期数=%d",
                len(df), df["code"].nunique(), df["date"].nunique())

    # (a) 画曲线
    _plot_curves(df, OUT_DIR)

    # (b) 选阈值（曲线拐点法，失败则退化为分位数兜底，保证 5 个因子都有阈值）
    thresholds = {fac: _pick_threshold_with_fallback(df, fac, args.quantile) for fac in FACTOR_COLS}

    thr_df = pd.DataFrame([{"factor": f, "threshold": t} for f, t in thresholds.items()])
    thr_df.to_csv(os.path.join(OUT_DIR, "thresholds.csv"), index=False)
    logger.info("阈值表:\n%s", thr_df.to_string(index=False))

    # (c) 输出买入参考价信号表
    build_signals(df, thresholds, OUT_DIR)


if __name__ == "__main__":
    main()
