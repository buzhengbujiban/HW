#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
factor1_mini.py —— step4：仿照 jk/hft/factors/factor1.py，在本管线的 raw_long_table 上
构造并推广 5 个一档买卖盘口因子，**universe 收窄到最终选股池**（raw_long_table 的子集）。

== 5 个目标因子 ==
  1. size_add_newlevel1_BSimb            —— 新增"更优买一/卖一"挂单【量】的 B/S 失衡
                                            （推广：直接对 新增更优一档的 size 做 BSimb，
                                              不再除以全部新增挂单量）
  2. trdact_BSimb_diff                   —— 主动买/卖成交【笔数】净额的 cumsum-ewm
  3. size_add_newlevel1_prob_BSimb       —— 新增更优一档量占全部新增量的"概率"的 B/S 失衡
  4. size_trdact_allormorelevel1_prob_BSimb —— 主动成交吃掉≥1档量占比的 B/S 失衡
  5. size_trdact_atlevel1_prob_BSimb     —— 主动成交恰好吃 1档量占比的 B/S 失衡

口径与 factor1.py 完全一致（cumsum-ewm 近似窗口和、主动方向、吃档/新增一档判定），
差异：
  - 数据源指向本管线 raw_long_table（价格列已是浮点真实价，无需 *10000 还原）
  - universe 仅保留"最终选股池"当日 code（FINAL_POOL_DIR/{date}.parquet 的 code）
  - 额外输出 bp1/sp1/mid/next_mid（供 step5 用"下一个 tick 的 mid"作买入参考价）
    以及 LA 标签（尤其 LASVWAP1，供 step5 画 x-bins vs y-mean、step6 回测）

输出：
  {OUTPUT_DIR}/factor1_mini/factor1_mini_{date}.parquet
  列：date, code(6位), time, seq_num, bp1, sp1, mid, next_mid,
      <5 因子>, LA10/LA60/LA3600/LA43200/LAEOD/LAEOD1/LAEOD2/LAEOD5/LASVWAP1/2/5

用法：
  python factor1_mini.py --date 20250121 --max-workers 8
  # echo 并行：
  #   ls {OUTPUT_DIR}/.. 同 run_all.sh
"""

from __future__ import annotations

import argparse
import logging
import os
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("checkbase_hft.factor1_mini")

NEW_ROOT = "/home/datamake119/data1/user118/newhigh/checkbase_hft"
# 最终选股池（破前高 + 94%limit_up + 两天前中午/收盘=涨停 等全部条件）——raw_long_table 的子集
FINAL_POOL_DIR = "/home/datamake119/data1/user118/newhigh/checkafterbase56_add5_limitup/segments_daily"


class Config:
    RAW_DIR = os.path.join(NEW_ROOT, "raw_long_table")
    MARKETS = ("sz", "sh")
    OUTPUT_DIR = os.path.join(NEW_ROOT, "factors")

    HL_LEVEL1 = 500          # 一档计数/量的窗口半衰期
    HL_TRDACT_DIFF = 250     # trdact_BSimb_diff 半衰期
    MAX_WORKERS = 8

    # 连续竞价时段（含端点），HHMMSSmmm
    AM_START, AM_END = 93000000, 113000000
    PM_START, PM_END = 130000000, 145700000

    # 输出对齐到的标签列
    LACOLS = ['LA10', 'LA60', 'LA3600', 'LA43200', 'LAEOD', 'LAEOD1', 'LAEOD2',
              'LAEOD5', 'LASVWAP1', 'LASVWAP2', 'LASVWAP5']
    # 读长表所需列（新 schema）
    USE_COLS = ["code", "time", "date", "type", "side",
                "volume", "sellorder", "buyorder",
                "price", "size", "seq_num", "number",
                "bp1", "sp1", "bv1", "sv1"] + LACOLS

    # 输出抽样步长（每只股票内每 STRIDE 个事件取 1 行）。最终池股票很少，默认 1 全保留。
    STRIDE = 1


def cumsum_minus_ewm(values: np.ndarray, halflife: float) -> np.ndarray:
    """cumsum_from_open(x) - cumsum_from_open(x).ewm(halflife).mean()。NaN 视为不计入(按 0)。"""
    s = pd.Series(values, dtype="float64")
    cum = s.fillna(0.0).cumsum()
    ewm = cum.ewm(halflife=halflife, adjust=False, ignore_na=True).mean()
    return (cum - ewm).to_numpy()


def _ratio(a: pd.Series, b: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / b


def _bsimb(b: pd.Series, s: pd.Series) -> pd.Series:
    """B/S 失衡 = (B - S) / (B + S)。"""
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b - s) / (b + s)


def _one_stock(date: str, code: str, tbl_df: pd.DataFrame, cfg: Config) -> pd.DataFrame | None:
    if tbl_df.empty:
        return None

    tbl_df = tbl_df.sort_values(["time", "seq_num"]).reset_index(drop=True)

    # ---- 盘口 mid 与下一 tick 的 mid（供买入参考价）----
    bp1 = tbl_df["bp1"].astype("float64").to_numpy()
    sp1 = tbl_df["sp1"].astype("float64").to_numpy()
    bp1 = np.where(bp1 > 0, bp1, np.nan)
    sp1 = np.where(sp1 > 0, sp1, np.nan)
    mid = (bp1 + sp1) / 2.0
    mid = np.where(np.isnan(mid), bp1, mid)
    mid = np.where(np.isnan(mid), sp1, mid)
    mid = pd.Series(mid).ffill().to_numpy()
    next_mid = np.full(len(mid), np.nan)
    next_mid[:-1] = mid[1:]

    out = tbl_df[["date", "code", "time", "seq_num"] + cfg.LACOLS].copy()
    out["bp1"] = bp1
    out["sp1"] = sp1
    out["mid"] = mid
    out["next_mid"] = next_mid

    # ---- 方向（委托行）----
    fc = tbl_df["functionCode"].astype(str)
    o_is_buy = fc == "B"
    o_is_sell = fc == "S"

    # ---- 成交侧 trdact：用"委托行且下一事件为成交(T)"近似主动单 ----
    eat_buy = o_is_buy & (tbl_df["orderKind"].shift(-1) == "T") & (tbl_df["orderPrice"] >= tbl_df["sp1"])
    eat_sell = o_is_sell & (tbl_df["orderKind"].shift(-1) == "T") & (tbl_df["orderPrice"] <= tbl_df["bp1"])

    tbl_df["size_trdact_B"] = tbl_df["size"].where(eat_buy, np.nan)
    tbl_df["size_trdact_S"] = tbl_df["size"].where(eat_sell, np.nan)
    tbl_df["cnt_trdact_B"] = eat_buy * 1.0
    tbl_df["cnt_trdact_S"] = eat_sell * 1.0

    # 吃掉 >=1 档（量）
    tbl_df["cnt_trdact_allormorelevel1_B"] = eat_buy & (tbl_df["orderVolume"] >= tbl_df["sv1"])
    tbl_df["cnt_trdact_allormorelevel1_S"] = eat_sell & (tbl_df["orderVolume"] >= tbl_df["bv1"])
    tbl_df["size_trdact_allormorelevel1_B"] = tbl_df["size"].where(tbl_df["cnt_trdact_allormorelevel1_B"], np.nan)
    tbl_df["size_trdact_allormorelevel1_S"] = tbl_df["size"].where(tbl_df["cnt_trdact_allormorelevel1_S"], np.nan)

    # 恰好吃 1 档（量相等）
    tbl_df["cnt_trdact_atlevel1_B"] = eat_buy & (tbl_df["orderVolume"] == tbl_df["sv1"])
    tbl_df["cnt_trdact_atlevel1_S"] = eat_sell & (tbl_df["orderVolume"] == tbl_df["bv1"])
    tbl_df["size_trdact_atlevel1_B"] = tbl_df["size"].where(tbl_df["cnt_trdact_atlevel1_B"], np.nan)
    tbl_df["size_trdact_atlevel1_S"] = tbl_df["size"].where(tbl_df["cnt_trdact_atlevel1_S"], np.nan)

    # ---- 委托侧 add：新增更优一档 ----
    new_buy = (o_is_buy & (tbl_df["bp1"] > 0) & (tbl_df["bv1"] == tbl_df["size"]) &
               (tbl_df["orderPrice"] > tbl_df["bp1"].shift()) & (tbl_df["orderKind"].shift(-1) != "T"))
    new_sell = (o_is_sell & (tbl_df["sp1"] > 0) & (tbl_df["sv1"] == tbl_df["size"]) &
                (tbl_df["orderPrice"] < tbl_df["sp1"].shift()) & (tbl_df["orderKind"].shift(-1) != "T"))

    tbl_df["add_size_B"] = tbl_df["orderVolume"].where(o_is_buy, np.nan)
    tbl_df["add_size_S"] = tbl_df["orderVolume"].where(o_is_sell, np.nan)
    tbl_df["add_size_newlevel1_B"] = tbl_df["orderVolume"].where(new_buy, np.nan)
    tbl_df["add_size_newlevel1_S"] = tbl_df["orderVolume"].where(new_sell, np.nan)

    def cum_ewm(col: str, hl: float) -> pd.Series:
        return pd.Series(cumsum_minus_ewm(tbl_df[col].to_numpy("float64"), hl), index=tbl_df.index)

    # ===== 成交侧累计 =====
    f_size_B = cum_ewm("size_trdact_B", cfg.HL_LEVEL1)
    f_size_S = cum_ewm("size_trdact_S", cfg.HL_LEVEL1)
    f_size_lvl1_B = cum_ewm("size_trdact_allormorelevel1_B", cfg.HL_LEVEL1)
    f_size_lvl1_S = cum_ewm("size_trdact_allormorelevel1_S", cfg.HL_LEVEL1)
    f_size_atlvl1_B = cum_ewm("size_trdact_atlevel1_B", cfg.HL_LEVEL1)
    f_size_atlvl1_S = cum_ewm("size_trdact_atlevel1_S", cfg.HL_LEVEL1)

    # 因子4：size_trdact_allormorelevel1_prob_BSimb
    prob_lvl1_B = _ratio(f_size_lvl1_B, f_size_B)
    prob_lvl1_S = _ratio(f_size_lvl1_S, f_size_S)
    out["size_trdact_allormorelevel1_prob_BSimb"] = _bsimb(prob_lvl1_B, prob_lvl1_S)

    # 因子5：size_trdact_atlevel1_prob_BSimb
    prob_at_B = _ratio(f_size_atlvl1_B, f_size_B)
    prob_at_S = _ratio(f_size_atlvl1_S, f_size_S)
    out["size_trdact_atlevel1_prob_BSimb"] = _bsimb(prob_at_B, prob_at_S)

    # 因子2：trdact_BSimb_diff（主动买卖笔数净额的 cumsum-ewm）
    net = (tbl_df["cnt_trdact_B"].fillna(0.0) - tbl_df["cnt_trdact_S"].fillna(0.0))
    out["trdact_BSimb_diff"] = pd.Series(
        cumsum_minus_ewm(net.to_numpy("float64"), cfg.HL_TRDACT_DIFF), index=tbl_df.index)

    # ===== 委托侧累计 =====
    f_add_size_B = cum_ewm("add_size_B", cfg.HL_LEVEL1)
    f_add_size_S = cum_ewm("add_size_S", cfg.HL_LEVEL1)
    f_add_size_new_B = cum_ewm("add_size_newlevel1_B", cfg.HL_LEVEL1)
    f_add_size_new_S = cum_ewm("add_size_newlevel1_S", cfg.HL_LEVEL1)

    # 因子1：size_add_newlevel1_BSimb（直接对"新增更优一档量"做 B/S 失衡，推广版）
    out["size_add_newlevel1_BSimb"] = _bsimb(f_add_size_new_B, f_add_size_new_S)

    # 因子3：size_add_newlevel1_prob_BSimb（新增更优一档量占全部新增量之比 的 B/S 失衡）
    prob_new_B = _ratio(f_add_size_new_B, f_add_size_B)
    prob_new_S = _ratio(f_add_size_new_S, f_add_size_S)
    out["size_add_newlevel1_prob_BSimb"] = _bsimb(prob_new_B, prob_new_S)

    if cfg.STRIDE > 1:
        out = out.iloc[::cfg.STRIDE]
    return out


FACTOR_COLS = [
    "size_add_newlevel1_BSimb",
    "trdact_BSimb_diff",
    "size_add_newlevel1_prob_BSimb",
    "size_trdact_allormorelevel1_prob_BSimb",
    "size_trdact_atlevel1_prob_BSimb",
]


def _load_final_pool_codes(date: str) -> set[str]:
    """最终选股池当日 code（6 位纯数字）。"""
    path = os.path.join(FINAL_POOL_DIR, f"{date}.parquet")
    if not os.path.exists(path):
        return set()
    df = pd.read_parquet(path, columns=["code"])
    if df.empty:
        return set()
    return set(df["code"].astype(str).str.zfill(6).tolist())


def _read_long_table(date: str, cfg: Config, pool_codes: set[str]) -> pd.DataFrame:
    """读沪深一体长表，谓词下推取连续竞价时段，并按最终池 code 收窄 universe。"""
    time_filters = [
        [("time", ">=", cfg.AM_START), ("time", "<=", cfg.AM_END)],
        [("time", ">=", cfg.PM_START), ("time", "<=", cfg.PM_END)],
    ]
    # pool_codes 带后缀供过滤（沪 .SH / 深 .SZ）
    pool_suffixed = set()
    for c in pool_codes:
        pool_suffixed.add(f"{c}.SH" if c.startswith("6") else f"{c}.SZ")

    frames = []
    for market in cfg.MARKETS:
        path = Path(cfg.RAW_DIR) / f"{market}_ordertranlob" / f"{date}.parquet"
        if not path.exists():
            continue
        df = pd.read_parquet(path, columns=cfg.USE_COLS, filters=time_filters)
        if df.empty:
            continue
        df["code"] = df["code"].astype(str)
        df = df[df["code"].isin(pool_suffixed)]
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["time"] = df["time"].astype("int64")

    # ---- schema 兼容层：新 schema → factor1 旧字段名（价格已是浮点真实价，不再 *10000）----
    type_s = df["type"].astype(str)
    side_s = df["side"].astype(str).where(df["side"].notna(), "")
    is_trade = (type_s == "T").to_numpy()
    is_cxl = (type_s == "D").to_numpy()
    fc = np.where(is_cxl, "C", np.where(~is_trade, side_s.to_numpy(), ""))
    df["functionCode"] = fc
    df["orderKind"] = type_s.to_numpy()
    df["orderPrice"] = df["price"]
    df["orderVolume"] = df["volume"]
    df["bidOrder"] = df["buyorder"]
    df["askOrder"] = df["sellorder"]
    # 纯 6 位 code 用于输出
    df["code"] = df["code"].str[:6]
    return df


def _one_stock_worker(args):
    date, code, sub_df, cfg = args
    return _one_stock(date, code, sub_df, cfg)


def build_one_day(date: str, cfg: Config) -> pd.DataFrame:
    pool_codes = _load_final_pool_codes(date)
    if not pool_codes:
        logger.warning("%s 最终选股池为空，跳过", date)
        return pd.DataFrame()

    table_df = _read_long_table(date, cfg, pool_codes)
    if table_df.empty:
        logger.warning("%s 长表(收窄后)无数据，跳过", date)
        return pd.DataFrame()

    groups = list(table_df.groupby("code", sort=False))
    logger.info("%s 最终池股票 %d / 长表命中 %d 只，max_workers=%d",
                date, len(pool_codes), len(groups), cfg.MAX_WORKERS)

    frames = []
    max_workers = max(1, int(cfg.MAX_WORKERS))
    if max_workers == 1:
        for code, sub_df in groups:
            frame = _one_stock(date, str(code), sub_df, cfg)
            if frame is not None and not frame.empty:
                frames.append(frame)
    else:
        tasks = [(date, str(code), sub_df, cfg) for code, sub_df in groups]
        with ProcessPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(_one_stock_worker, t): t[1] for t in tasks}
            for fut in as_completed(futures):
                code = futures[fut]
                try:
                    frame = fut.result()
                except Exception as exc:
                    logger.exception("%s %s 计算失败：%s", date, code, exc)
                    raise
                if frame is not None and not frame.empty:
                    frames.append(frame)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def process_day(date: str, cfg: Config) -> str:
    by_date_dir = Path(cfg.OUTPUT_DIR) / "factor1_mini"
    by_date_dir.mkdir(parents=True, exist_ok=True)
    out_path = by_date_dir / f"factor1_mini_{date}.parquet"
    if out_path.exists():
        logger.info("skip %s（已存在）", date)
        return f"skip {date}"

    df = build_one_day(date, cfg)
    if df.empty:
        logger.warning("empty %s", date)
        # 写空文件，便于 echo 并行断点判断
        cols = ["date", "code", "time", "seq_num", "bp1", "sp1", "mid", "next_mid"] + FACTOR_COLS + cfg.LACOLS
        pd.DataFrame(columns=cols).to_parquet(out_path, index=False)
        return f"empty {date}"
    df.to_parquet(out_path, index=False)
    logger.info("ok %s rows=%d codes=%d -> %s", date, len(df), df["code"].nunique(), out_path)
    return f"ok {date} rows={len(df)} codes={df['code'].nunique()}"


def main():
    parser = argparse.ArgumentParser(description="factor1_mini：最终池 universe 上的 5 个一档盘口因子（单日）")
    parser.add_argument("--date", type=str, required=True, help="交易日 YYYYMMDD")
    parser.add_argument("--max-workers", type=int, default=8, help="单日内股票并行进程数")
    args = parser.parse_args()
    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")

    cfg = Config()
    cfg.MAX_WORKERS = args.max_workers
    process_day(args.date, cfg)


if __name__ == "__main__":
    main()
