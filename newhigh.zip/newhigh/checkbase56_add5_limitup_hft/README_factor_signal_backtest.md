# checkbase56_add5_limitup_hft —— 因子 / 信号 / 回测（step4~step6）

承接 step0~step3（`run_all.sh`）生成的 `raw_long_table/{sh,sz}_ordertranlob/{date}.parquet`。
universe 已收窄到**最终选股池**（破前高 + 曾涨到 94% limit_up + 两天前中午/收盘=涨停 等全部条件，
目录 `checkafterbase56_add5_limitup/segments_daily/{date}.parquet`，它是 raw_long_table 的子集）。

## step4 — `factor1_mini.py`
仿照 `jk/hft/factors/factor1.py`，在本管线 raw_long_table 上构造并推广 **5 个一档盘口因子**
（universe 仅保留最终池当日 code）：

| # | 因子 | 含义 |
|---|------|------|
| 1 | `size_add_newlevel1_BSimb` | 新增"更优买一/卖一"挂单**量**的 B/S 失衡（推广：直接对新增更优一档 size 做 BSimb） |
| 2 | `trdact_BSimb_diff` | 主动买/卖成交**笔数**净额的 cumsum-ewm |
| 3 | `size_add_newlevel1_prob_BSimb` | 新增更优一档量 / 全部新增量 之比 的 B/S 失衡 |
| 4 | `size_trdact_allormorelevel1_prob_BSimb` | 主动成交吃掉 ≥1 档量占比 的 B/S 失衡 |
| 5 | `size_trdact_atlevel1_prob_BSimb` | 主动成交恰好吃 1 档量占比 的 B/S 失衡 |

口径与 factor1.py 一致（cumsum-ewm 近似窗口和、主动方向、吃档/新增一档判定）。
差异：价格列已是浮点真实价（不再 *10000）；额外输出 `bp1/sp1/mid/next_mid`（下一 tick 的 mid 作买入参考价）
以及 `LA10/60/3600/43200/LAEOD*/LASVWAP1/2/5` 标签。

```bash
python factor1_mini.py --date 20250121 --max-workers 8
# 输出: {NEW_ROOT}/factors/factor1_mini/factor1_mini_{date}.parquet
```

## step5 — `createsignals.py`
1. 画 **因子值 x-bins vs 各 lag 的 y-mean** 曲线（重点 `LASVWAP1`），观察因子大到何处下一段大概率正收益；
2. 自动选阈值（曲线法：从高 bin 起连续为正的最低因子值；无正区间则退化为 80% 分位兜底）；
3. 触发 `因子 i > 阈值 i` 时，输出**下一个 tick 的 mid 作为买入参考价**。

```bash
python createsignals.py                 # 用全部已有 factor 日期
python createsignals.py --quantile 0.7  # 阈值改分位数法
# 输出: {NEW_ROOT}/signals/{curves/*.png, thresholds.csv, signals/*.parquet, signals_all.parquet}
```

## step6 — `backtest_checkafterbase56_add5_limitup.py`
对每个因子分别回测：选股日 D 以 `buy_ref_price`（下一 tick mid）等权买入当日触发的票，
在 **第 2/3/5 个交易日**分别以 **开盘价 / 收盘价** 卖出（6 个 label），
每日组合收益截面等权，按选股日累乘成净值曲线。

```bash
python backtest_checkafterbase56_add5_limitup.py
# 输出: {NEW_ROOT}/signals/backtest/{factor}_returns.csv, {factor}_equity.png, summary.csv
```

## 一键
```bash
bash run_all.sh step4            # 全部日期算因子
bash run_all.sh step4 20250121   # 单天
python createsignals.py && python backtest_checkafterbase56_add5_limitup.py
```

> 注：单日样本下净值仅作流程验证；跑满多日（先 `bash run_all.sh all`）后曲线才有统计意义。
