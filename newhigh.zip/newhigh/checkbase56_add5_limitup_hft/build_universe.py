"""
step0 —— 从 checkafterbase_limitup 选股池构造 universe pkl（供后续 extract 复用）。

【重要修正】我们想要的是「选股日 D 后一天 D+1 的日内高频 lob/ordertrans」，
所以选股池里 date=D 的 code 应该被映射到 **下一交易日 D+1** 这一天去抽取高频。
本脚本因此把 universe pkl 落盘到 daily_results/{D+1}.pkl（而不是 {D}.pkl），
后续 extract_lob.py / extract_ordertrans.py 就会自动用 D+1 那天的高频源做过滤。

为什么从 checkafterbase_limitup：
  checkafterbase_limitup 是最宽的"破前高+涨停回踩"基础池，checkafterbase56 /
  checkafterbase56_add5 等都是它的子集。在它上面 extract 出 lob/ordertrans 并算
  raw_long_table 后，后续所有子集策略都能直接复用同一份 raw_long_table，不必重复抽取。

输入：
  /home/datamake119/data1/user118/newhigh/checkafterbase_limitup/segments_daily/{D}.parquet
    （字段含 date, code(6位), limit_up_price, ...）

输出：
  {NEW_ROOT}/daily_results/{D+1}.pkl
    结构：{"date": D+1, "select_date": D, "universe_codes": [6位纯代码, ...]}
    —— 与 build_up_7 的 daily_results 同构，使 extract_lob.py / extract_ordertrans.py
       能以同样的方式按 D+1 读取 universe。

用法：
  python build_universe.py --date 20250121      # 单日：把 20250121 选出的票映射到 20250122
  python build_universe.py --all                # 全部可用日
  # 并行（注意 --date 传的是选股日 D，会自动落到 D+1）：
  #   ls .../checkafterbase_limitup/segments_daily | sed 's/.parquet//' \
  #     | xargs -P 24 -I{} python build_universe.py --date {}
"""

from __future__ import annotations

import os
import glob
import pickle
import logging
import argparse
import datetime

import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ========== 路径 ==========
POOL_DIR = "/home/datamake119/data1/user118/newhigh/checkafterbase_limitup/segments_daily"

# 本 hft 管线专用的数据根目录（lob/ordertrans/lags/raw_long_table 都放这里）
NEW_ROOT = "/home/datamake119/data1/user118/newhigh/checkbase_hft"
DAILY_DIR = os.path.join(NEW_ROOT, "daily_results")

# 交易日历来源（与 DataLoader / find_segments 一致）
LIMIT_UP_PRICE_PATH = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea/LIMIT_UP_PRICE.pkl"

_TRADING_CAL: list[datetime.date] | None = None


def _load_trading_calendar() -> list[datetime.date]:
    """升序 datetime.date 交易日列表。"""
    global _TRADING_CAL
    if _TRADING_CAL is None:
        lu = pd.read_pickle(LIMIT_UP_PRICE_PATH)
        _TRADING_CAL = sorted(lu.index)
    return _TRADING_CAL


def _next_trading_day(date_int: str) -> str | None:
    """date_int=YYYYMMDD -> 下一交易日 YYYYMMDD；找不到返回 None。"""
    d = datetime.datetime.strptime(date_int, "%Y%m%d").date()
    cal = _load_trading_calendar()
    later = [x for x in cal if x > d]
    if not later:
        return None
    return min(later).strftime("%Y%m%d")


def build_one(select_date_int: str) -> int:
    """读取 D 的选股池，落盘到 D+1 的 universe pkl。"""
    pool_path = os.path.join(POOL_DIR, f"{select_date_int}.parquet")
    if not os.path.exists(pool_path):
        logger.info("选股日 %s: 池 parquet 不存在", select_date_int)
        return 0

    next_date_int = _next_trading_day(select_date_int)
    if next_date_int is None:
        logger.info("选股日 %s: 找不到下一交易日，跳过", select_date_int)
        return 0

    df = pd.read_parquet(pool_path, columns=["date", "code"])
    if df.empty:
        logger.info("选股日 %s: 池为空", select_date_int)
        codes: list[str] = []
    else:
        codes = sorted(set(df["code"].astype(str).str.zfill(6).tolist()))

    os.makedirs(DAILY_DIR, exist_ok=True)
    # 关键：universe pkl 用 D+1 命名 —— extract_lob/ordertrans 会按这个日期取高频源
    out_path = os.path.join(DAILY_DIR, f"{next_date_int}.pkl")
    with open(out_path, "wb") as f:
        pickle.dump(
            {
                "date": next_date_int,          # 高频抽取日（D+1）
                "select_date": select_date_int,  # 选股日（D），便于回溯
                "universe_codes": codes,
            },
            f,
        )
    logger.info("选股日 %s -> 高频日 %s: 写出 universe %d 只 -> %s",
                select_date_int, next_date_int, len(codes), out_path)
    return len(codes)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, default=None,
                        help="选股日 D（YYYYMMDD）；universe pkl 会写到 D+1.pkl")
    parser.add_argument("--all", action="store_true", help="处理 POOL_DIR 下全部选股日")
    args = parser.parse_args()

    if args.all:
        files = sorted(glob.glob(os.path.join(POOL_DIR, "*.parquet")))
        dates = [os.path.basename(f).replace(".parquet", "") for f in files]
        logger.info("共 %d 个选股日待构造 universe（均映射到 D+1）", len(dates))
        for d in dates:
            build_one(d)
    elif args.date:
        build_one(args.date)
    else:
        parser.error("请提供 --date 或 --all")


if __name__ == "__main__":
    main()
