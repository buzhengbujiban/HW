#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
step2 —— 由 checkbase universe 的 LOB（lob_sh/lob_sz）逐 tick 计算盘口基础指标 +
未来收益指标 lags（与 jk/hft/lags_process_all.py 完全同口径）。

唯一差异：把 DataLoader 的 lob_root 指向本管线的 NEW_ROOT，使其读取
  {NEW_ROOT}/lob_sh/{date}_lob.parquet、{NEW_ROOT}/lob_sz/{date}_lob.parquet，
输出到 {NEW_ROOT}/lags/lags_{date}.parquet。

指标定义（基准均为"下一个 tick 的 mid"）：
  ap1/bp1/as1/bs1，LA10/LA60/LA600/LA3600，LA43200(尾盘14:56)，LAEOD(盘内收盘)，
  LAEOD1/2/5(叠加复权跨日收益)，LASVWAP1/2/5(叠加早盘 vwap 跨日收益)。

用法：
  python lags_process_all.py --date 20250121 --max-workers 20
  # echo 并行：
  #   ls {NEW_ROOT}/lob_sh {NEW_ROOT}/lob_sz | grep _lob | sed 's/_lob.parquet//' | sort -u \
  #     | xargs -P 12 -I{} python lags_process_all.py --date {}
"""

from __future__ import annotations

import argparse
import logging
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, "/home/user118/.local/.nogd/jk")
from DataLoader import StockDataLoader as DataLoader  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("checkbase_hft.lags")

# 本管线数据根目录
NEW_ROOT = "/home/datamake119/data1/user118/newhigh/checkbase_hft"


class Config:
    CLOSE_ADJ_PATH = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea/CLOSE_PRICE_2.pkl"
    VWAP_MORNING_PATH = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea/OPEN_PRICE_2.pkl"
    LOB_PRICE_SCALE = 10000.0
    OUTPUT_DIR = NEW_ROOT            # lags 输出到 {NEW_ROOT}/lags
    LOB_ROOT = NEW_ROOT              # DataLoader 读取 {NEW_ROOT}/lob_sh|lob_sz
    DATASET = "LL_tick_lob_limit_up"
    FWD_SECONDS = {"LA10": 10, "LA60": 60, "LA600": 600, "LA3600": 3600}
    FWD_ABS_SECONDS = {"LA43200": 53760}
    FWD_DAYS = {"LAEOD1": 1, "LAEOD2": 2, "LAEOD5": 5}
    FWD_DAYS_VWAP = {"LASVWAP1": 1, "LASVWAP2": 2, "LASVWAP5": 5}
    MAX_WORKERS = 20


def lob_time_to_sec(t: np.ndarray) -> np.ndarray:
    t = t.astype("int64")
    ms = t % 1000
    rest = t // 1000
    s = rest % 100
    rest = rest // 100
    m = rest % 100
    h = rest // 100
    return (h * 3600 + m * 60 + s + ms / 1000.0).astype("float64")


def _one_stock(date, code, g, ret_map, vwap_map, cfg) -> pd.DataFrame | None:
    g = g.sort_values("time").reset_index(drop=True)
    n = len(g)
    if n == 0:
        return None

    ap1 = g["sp1"].to_numpy("float64") / cfg.LOB_PRICE_SCALE
    bp1 = g["bp1"].to_numpy("float64") / cfg.LOB_PRICE_SCALE
    as1 = g["sv1"].to_numpy("float64")
    bs1 = g["bv1"].to_numpy("float64")

    ap1 = np.where(ap1 > 0, ap1, np.nan)
    bp1 = np.where(bp1 > 0, bp1, np.nan)

    mid = (ap1 + bp1) / 2.0
    mid = np.where(np.isnan(mid), ap1, mid)
    mid = np.where(np.isnan(mid), bp1, mid)
    mid = pd.DataFrame(np.where(ap1 > bp1, mid, np.nan))[0].ffill().values

    sec = lob_time_to_sec(g["time"].to_numpy())

    next_mid = np.full(n, np.nan)
    next_mid[:-1] = mid[1:]

    def future_mid(delta_sec):
        target = sec + delta_sec
        pos = np.searchsorted(sec, target, side="left")
        fmid = np.full(n, np.nan)
        valid = pos < n
        fmid[valid] = mid[pos[valid]]
        return fmid

    def abs_time_mid(abs_sec):
        pos = int(np.searchsorted(sec, abs_sec, side="left"))
        val = mid[pos] if pos < n else np.nan
        return np.full(n, val)

    def ret(fwd_price):
        with np.errstate(invalid="ignore", divide="ignore"):
            return fwd_price / next_mid - 1.0

    out = pd.DataFrame({
        "seq_num": g["seq_num"].to_numpy(),
        "date": date,
        "code": code,
        "time": g["time"].to_numpy(),
        "ap1": ap1, "bp1": bp1, "as1": as1, "bs1": bs1,
    })

    for name, delta in cfg.FWD_SECONDS.items():
        out[name] = ret(future_mid(delta))
    for name, abs_sec in cfg.FWD_ABS_SECONDS.items():
        out[name] = ret(abs_time_mid(abs_sec))

    valid_mid = mid[~np.isnan(mid)]
    last_mid = valid_mid[-1] if valid_mid.size else np.nan
    laeod = ret(np.full(n, last_mid))
    out["LAEOD"] = laeod

    for name in cfg.FWD_DAYS:
        ret_series = ret_map.get(name)
        if ret_series is None or code not in ret_series.index:
            out[name] = np.nan
            continue
        ret_n = ret_series.get(code, np.nan)
        out[name] = (1.0 + laeod) * (1.0 + ret_n) - 1.0

    for name in cfg.FWD_DAYS_VWAP:
        vret_series = vwap_map.get(name)
        if vret_series is None or code not in vret_series.index:
            out[name] = np.nan
            continue
        vret_n = vret_series.get(code, np.nan)
        out[name] = (1.0 + laeod) * (1.0 + vret_n) - 1.0

    return out


class LagsBuilder:
    def __init__(self, cfg: Config = None):
        self.cfg = cfg or Config()
        # 关键：把 lob_root 指向本管线 NEW_ROOT
        self.dl = DataLoader(lob_root=self.cfg.LOB_ROOT)
        self.close_adj = None
        self.vwap_morning = None
        self.trade_dates = None

    def load_data(self):
        close_adj = pd.read_pickle(self.cfg.CLOSE_ADJ_PATH)
        close_adj.index = pd.to_datetime(close_adj.index).strftime("%Y%m%d")
        close_adj.columns = close_adj.columns.astype(str)
        self.close_adj = close_adj
        self.trade_dates = sorted(close_adj.index)

        vwap = pd.read_pickle(self.cfg.VWAP_MORNING_PATH)
        vwap.index = pd.to_datetime(vwap.index).strftime("%Y%m%d")
        vwap.columns = vwap.columns.astype(str)
        vwap = vwap.where(vwap > 0)
        self.vwap_morning = vwap

    def future_ret_map(self, date: str) -> dict:
        cfg = self.cfg
        idx = self.trade_dates
        if date not in idx or date not in self.close_adj.index:
            return {}
        pos = idx.index(date)
        base = self.close_adj.loc[date]
        res = {}
        for name, off in cfg.FWD_DAYS.items():
            fpos = pos + off
            if fpos < len(idx) and idx[fpos] in self.close_adj.index:
                res[name] = self.close_adj.loc[idx[fpos]] / base - 1.0
            else:
                res[name] = None
        return res

    def future_vwap_map(self, date: str) -> dict:
        cfg = self.cfg
        idx = self.trade_dates
        if date not in idx or date not in self.vwap_morning.index:
            return {}
        pos = idx.index(date)
        base = self.vwap_morning.loc[date]
        res = {}
        for name, off in cfg.FWD_DAYS_VWAP.items():
            fpos = pos + off
            if fpos < len(idx) and idx[fpos] in self.vwap_morning.index:
                res[name] = self.vwap_morning.loc[idx[fpos]] / base - 1.0
            else:
                res[name] = None
        return res

    def build_one_day(self, date: str) -> pd.DataFrame:
        try:
            lob = self.dl.read_limit_up_lob(
                date, market="both",
                columns=["code", "time", "bp1", "bv1", "sp1", "sv1", "seq_num"],
                as_pandas=True,
            )
        except FileNotFoundError as exc:
            logger.warning("%s LOB 文件不存在：%s", date, exc)
            return pd.DataFrame()
        if lob.empty:
            logger.warning("%s LOB 为空，跳过", date)
            return pd.DataFrame()

        ret_map = self.future_ret_map(date)
        vwap_map = self.future_vwap_map(date)

        groups = [(f"{int(code):06d}", g) for code, g in lob.groupby("code", sort=False)]
        max_workers = max(1, int(self.cfg.MAX_WORKERS))

        frames = []
        if max_workers == 1:
            for code, g in groups:
                frame = _one_stock(date, code, g, ret_map, vwap_map, self.cfg)
                if frame is not None and not frame.empty:
                    frames.append(frame)
        else:
            with ProcessPoolExecutor(max_workers=max_workers) as executor:
                futures = {executor.submit(_one_stock, date, code, g, ret_map, vwap_map, self.cfg): code
                           for code, g in groups}
                for fut in as_completed(futures):
                    code = futures[fut]
                    try:
                        frame = fut.result()
                    except Exception as exc:
                        logger.exception("%s %s 计算失败：%s", date, code, exc)
                        raise
                    if frame is not None and not frame.empty:
                        frames.append(frame)

        if not frames:
            return pd.DataFrame()
        return pd.concat(frames, ignore_index=True)

    def run_one(self, date: str):
        self.load_data()
        by_date_dir = Path(self.cfg.OUTPUT_DIR) / "lags"
        by_date_dir.mkdir(parents=True, exist_ok=True)
        out_path = by_date_dir / f"lags_{date}.parquet"
        if out_path.exists():
            logger.info("%s 已存在，跳过", date)
            return
        df = self.build_one_day(date)
        if df.empty:
            logger.info("%s 无数据", date)
            return
        df.to_parquet(out_path, index=False)
        logger.info("%s 保存 %d 行 %d 股 -> %s", date, len(df), df["code"].nunique(), out_path)


def main():
    parser = argparse.ArgumentParser(description="checkbase universe 逐 tick lags")
    parser.add_argument("--date", type=str, required=True, help="交易日 YYYYMMDD")
    parser.add_argument("--max-workers", type=int, default=20, help="单日内各股票并行进程数")
    args = parser.parse_args()
    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")

    cfg = Config()
    cfg.MAX_WORKERS = args.max_workers
    builder = LagsBuilder(cfg)
    builder.run_one(args.date)


if __name__ == "__main__":
    main()
