#!/usr/bin/env bash
# =============================================================================
# checkbase56_add5_limitup_hft 数据管线 step0~step3：生成 raw_long_table
#
# 数据根目录 NEW_ROOT = /home/datamake119/data1/user118/newhigh/checkbase_hft
# universe 来源 = checkafterbase_limitup/segments_daily（最宽基础池，子集可复用）
#
# 步骤：
#   step0  build_universe.py        从选股池构造 {NEW_ROOT}/daily_results/{date}.pkl
#   step1a extract_lob.py           抽取 lob_sh / lob_sz
#   step1b extract_ordertrans.py    抽取 ordertrans_sh / ordertrans_sz
#   step2  lags_process_all.py      由 lob 生成 lags
#   step3  create_long_table_sh/sz  合并生成 raw_long_table/{sh,sz}_ordertranlob
#
# 用法：
#   bash run_all.sh all                 # 跑全部步骤、全部日期
#   bash run_all.sh step0               # 只跑 step0（全部日期）
#   bash run_all.sh step1 20250121      # 只跑 step1 单天
#   PARALLEL=24 bash run_all.sh all     # 指定并行度
# =============================================================================
# set -uo pipefail

PY=/home/lwyxyz/anaconda3/envs/myenv/bin/python
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NEW_ROOT="/home/datamake119/data1/user118/newhigh/checkbase_hft"
POOL_DIR="/home/datamake119/data1/user118/newhigh/checkafterbase_limitup/segments_daily"
PARALLEL="${PARALLEL:-200}"

STEP="${1:-all}"
ONE_DATE="${2:-}"

# 待处理日期列表
all_pool_dates() {
  ls "$POOL_DIR" 2>/dev/null | sed 's/.parquet//'
}
universe_dates() {
  ls "$NEW_ROOT/daily_results" 2>/dev/null | sed 's/.pkl//'
}
lags_dates() {
  ls "$NEW_ROOT/lags" 2>/dev/null | sed 's/lags_//;s/.parquet//'
}
lt_dates() {
  ls "$NEW_ROOT/raw_long_table/sz_ordertranlob" 2>/dev/null | sed 's/.parquet//'
}

dates_for_step0() { [ -n "$ONE_DATE" ] && echo "$ONE_DATE" || all_pool_dates; }
dates_for_extract() { [ -n "$ONE_DATE" ] && echo "$ONE_DATE" || universe_dates; }
dates_for_lags() { [ -n "$ONE_DATE" ] && echo "$ONE_DATE" || universe_dates; }
dates_for_lt() { [ -n "$ONE_DATE" ] && echo "$ONE_DATE" || lags_dates; }
dates_for_factor() { [ -n "$ONE_DATE" ] && echo "$ONE_DATE" || all_pool_dates; }


run_step0() {
  echo "=== step0 build_universe (P=$PARALLEL) ==="
  dates_for_step0 | xargs -P "$PARALLEL" -I{} "$PY" "$DIR/build_universe.py" --date {}
}
run_step1() {
  echo "=== step1a extract_lob (P=$PARALLEL) ==="
  dates_for_extract | xargs -P "$PARALLEL" -I{} "$PY" "$DIR/extract_lob.py" --date {}
  echo "=== step1b extract_ordertrans (P=$PARALLEL) ==="
  dates_for_extract | xargs -P "$PARALLEL" -I{} "$PY" "$DIR/extract_ordertrans.py" --date {}
}
run_step2() {
  echo "=== step2 lags_process_all (P=$PARALLEL) ==="
  dates_for_lags | xargs -P "$PARALLEL" -I{} "$PY" "$DIR/lags_process_all.py" --date {} --max-workers 200
}
run_step3() {
  echo "=== step3 create_long_table SH (P=$PARALLEL) ==="
  dates_for_lt | xargs -P "$PARALLEL" -I{} "$PY" "$DIR/create_long_table_sh.py" --date {}
  echo "=== step3 create_long_table SZ (P=$PARALLEL) ==="
  dates_for_lt | xargs -P "$PARALLEL" -I{} "$PY" "$DIR/create_long_table_sz.py" --date {}
}
run_step4() {
  echo "=== step4 factor1_mini (P=$PARALLEL) ==="
  dates_for_factor | xargs -P "$PARALLEL" -I{} "$PY" "$DIR/factor1_mini.py" --date {} --max-workers 8
}

case "$STEP" in
  step0) run_step0 ;;
  step1) run_step1 ;;
  step2) run_step2 ;;
  step3) run_step3 ;;
  step4) run_step4 ;;
  all)   run_step0; run_step1; run_step2; run_step3; run_step4 ;;
  *) echo "未知步骤: $STEP（可用 step0/step1/step2/step3/step4/all）"; exit 1 ;;
esac


echo "完成：$STEP"
