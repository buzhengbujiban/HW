#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
backtest_checkafterbase56_add5_limitup.py —— step6：分因子回测 + 出图。

策略（对每个因子分别回测）：
  - 在选股日 D 的"日内"（信号触发的下一 tick mid，即 step5 的 buy_ref_price）记录买入价，
    把当日该因子触发的所有股票【等权合成】成一个组合（即"在 D 下一个交易日之前记录买入价、
    等权买入这些票"）。
  - 卖出方式两类、各 3 个持有期：
      (A) 第 2 / 3 / 5 个交易日以【开盘价】卖出   -> label: open_d2 / open_d3 / open_d5
      (B) 第 2 / 3 / 5 个交易日【结束以收盘价】卖出 -> label: close_d2 / close_d3 / close_d5
    其中"第 k 天"以 D 为第 1 天计：D+ (k-1) 个交易日。
  - 单票收益 = 卖出价 / 买入价 - 1；当日组合收益 = 截面等权平均；
    各 label 的"收益曲线" = 按选股日排序的每日组合收益累乘净值。

数据：
  - 买入价：signals_all.parquet 的 buy_ref_price（step5 输出）
  - 卖出价：DataLoader 风格的日频面板 OPEN_PRICE / CLOSE_PRICE（DAILY_ROOT 下 pkl，
            index=交易日(date), columns=纯6位 code）

输出：
  {OUT_DIR}/backtest/{factor}_returns.csv         —— 每个(因子,选股日) 的各 label 组合收益
  {OUT_DIR}/backtest/{factor}_equity.png          —— 各 label 净值收益曲线
  {OUT_DIR}/backtest/summary.csv                  —— 各因子各 label 的均值/胜率/末期净值

用法：
  python backtest_checkafterbase56_add5_limitup.py
  python backtest_checkafterbase56_add5_limitup.py --signals /path/to/signals_all.parquet
"""

from __future__ import annotations

import argparse
import datetime
import logging
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("checkbase_hft.backtest")

NEW_ROOT = "/home/datamake119/data1/user118/newhigh/checkbase_hft"
SIGNALS_PATH = os.path.join(NEW_ROOT, "signals", "signals_all.parquet")
OUT_DIR = os.path.join(NEW_ROOT, "signals", "backtest")
DAILY_ROOT = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea"

FACTOR_COLS = [
    "size_add_newlevel1_BSimb",
    "trdact_BSimb_diff",
    "size_add_newlevel1_prob_BSimb",
    "size_trdact_allormorelevel1_prob_BSimb",
    "size_trdact_atlevel1_prob_BSimb",
]
HOLD_DAYS = [2, 3, 5]   # 第 k 个交易日（D 为第 1 天）

_PANELS: dict[str, pd.DataFrame] = {}


def _load_panel(field: str) -> pd.DataFrame:
    if field not in _PANELS:
        df = pd.read_pickle(os.path.join(DAILY_ROOT, f"{field}.pkl")).sort_index()
        df.columns = df.columns.astype(str)
        _PANELS[field] = df
    return _PANELS[field]


def _to_date(x) -> datetime.date:
    """signal 表的 date 可能是 'YYYY-MM-DD' 或 'YYYYMMDD' 字符串。"""
    s = str(x)
    if "-" in s:
        return datetime.datetime.strptime(s[:10], "%Y-%m-%d").date()
    return datetime.datetime.strptime(s[:8], "%Y%m%d").date()


def _sell_price_on_kth(cal: list[datetime.date], d_idx: int, k: int,
                       panel: pd.DataFrame, code: str) -> float:
    """第 k 个交易日（D 为第 1 天 -> 偏移 k-1）的 panel 价格。"""
    j = d_idx + (k - 1)
    if j >= len(cal):
        return np.nan
    day = cal[j]
    if day not in panel.index or code not in panel.columns:
        return np.nan
    v = panel.loc[day, code]
    return float(v) if pd.notna(v) else np.nan


def backtest_factor(sig: pd.DataFrame, fac: str,
                    open_p: pd.DataFrame, close_p: pd.DataFrame,
                    cal: list[datetime.date]) -> pd.DataFrame:
    """对单个因子回测，返回每个选股日各 label 的等权组合收益。"""
    sub = sig[sig["factor"] == fac].copy()
    if sub.empty:
        return pd.DataFrame()
    sub["d"] = sub["date"].map(_to_date)
    cal_pos = {d: i for i, d in enumerate(cal)}

    rows = []
    for d, grp in sub.groupby("d"):
        if d not in cal_pos:
            continue
        di = cal_pos[d]
        rec = {"date": d, "n_stocks": len(grp)}
        # 每个持有期 / 卖出方式，先算单票收益，再截面等权
        for k in HOLD_DAYS:
            r_open, r_close = [], []
            for _, row in grp.iterrows():
                code = str(row["code"]).zfill(6)
                buy = float(row["buy_ref_price"])
                if not (buy > 0):
                    continue
                so = _sell_price_on_kth(cal, di, k, open_p, code)
                sc = _sell_price_on_kth(cal, di, k, close_p, code)
                if so == so:  # not nan
                    r_open.append(so / buy - 1.0)
                if sc == sc:
                    r_close.append(sc / buy - 1.0)
            rec[f"open_d{k}"] = float(np.mean(r_open)) if r_open else np.nan
            rec[f"close_d{k}"] = float(np.mean(r_close)) if r_close else np.nan
        rows.append(rec)

    return pd.DataFrame(rows).sort_values("date").reset_index(drop=True)


def plot_equity(ret_df: pd.DataFrame, fac: str, out_dir: str):
    """把每个选股日的组合收益按时间累乘成净值，画各 label 收益曲线。"""
    if ret_df.empty:
        return
    label_cols = [c for c in ret_df.columns if c.startswith("open_d") or c.startswith("close_d")]
    fig, ax = plt.subplots(figsize=(10, 5.5))
    x = pd.to_datetime(ret_df["date"])
    for c in label_cols:
        equity = (1.0 + ret_df[c].fillna(0.0)).cumprod()
        style = "-" if c.startswith("close") else "--"
        ax.plot(x, equity, style, marker="o", ms=3, label=c)
    ax.axhline(1.0, color="k", lw=0.8, ls=":")
    ax.set_title(f"{fac} 等权组合净值（买入=下一tick mid；卖出=第2/3/5日 开/收）")
    ax.set_xlabel("选股日 D")
    ax.set_ylabel("净值")
    ax.legend(fontsize=8, ncol=2)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(os.path.join(out_dir, f"{fac}_equity.png"), dpi=120)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description="step6：分因子回测 + 收益曲线")
    parser.add_argument("--signals", type=str, default=SIGNALS_PATH, help="signals_all.parquet 路径")
    args = parser.parse_args()

    if not os.path.exists(args.signals):
        logger.error("找不到信号表 %s，请先跑 step5", args.signals)
        return
    sig = pd.read_parquet(args.signals)
    if sig.empty:
        logger.error("信号表为空")
        return
    os.makedirs(OUT_DIR, exist_ok=True)

    open_p = _load_panel("OPEN_PRICE")
    close_p = _load_panel("CLOSE_PRICE")
    cal = sorted(open_p.index)

    summary_rows = []
    for fac in FACTOR_COLS:
        ret_df = backtest_factor(sig, fac, open_p, close_p, cal)
        if ret_df.empty:
            logger.info("因子 %s 无信号，跳过", fac)
            continue
        ret_df.to_csv(os.path.join(OUT_DIR, f"{fac}_returns.csv"), index=False)
        plot_equity(ret_df, fac, OUT_DIR)

        for k in HOLD_DAYS:
            for kind in ("open", "close"):
                col = f"{kind}_d{k}"
                v = ret_df[col].dropna()
                if v.empty:
                    continue
                summary_rows.append({
                    "factor": fac, "label": col,
                    "n_days": len(v),
                    "mean_ret": float(v.mean()),
                    "win_rate": float((v > 0).mean()),
                    "final_equity": float((1.0 + v).prod()),
                })
        logger.info("因子 %s 回测完成：%d 个选股日 -> %s",
                    fac, len(ret_df), os.path.join(OUT_DIR, f"{fac}_equity.png"))

    if summary_rows:
        summ = pd.DataFrame(summary_rows)
        summ.to_csv(os.path.join(OUT_DIR, "summary.csv"), index=False)
        logger.info("汇总:\n%s", summ.to_string(index=False))
        logger.info("summary -> %s", os.path.join(OUT_DIR, "summary.csv"))


if __name__ == "__main__":
    main()
