# newhigh: 连续上涨区段 + raw_long_table 过滤

## 流程

### Step 1 — `find_segments.py`
- 输入：
  - `build_up_7` universe：`/home/datamake119/data1/user118/newhigh/limit_7_up/daily_results/{date}.pkl`
  - 1min bar：`/home/datamake119/data1/user118/newhigh/limit_7_up/min_data/{date}_min.fea`（已按 universe 过滤）
  - 第二天 open：`/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea/OPEN_PRICE.pkl`
- 逻辑：
  - 仅取连续竞价时段（930~1457）
  - 以 1min `price`（close）计算 `ret>=0` 的连续段，长度 `>= cont (default=3)` 视为"连续上涨区段"
  - 对相邻两个上涨区段 S1 -> S2 同时满足：
    1. `gap_bars < len(S1) * scale` (default scale=1)
    2. `start_price2 <= end_price1`
    3. `end_price2 > end_price1`
    4. `start_price2 > start_price1`
- 输出（每天一个 parquet）：`/home/datamake119/data1/user118/newhigh/newhigh_segments/segments_daily/{date}.parquet`
  - 字段：`date, code, t_start, t_end, len1, len2, start_price1, end_price1, start_price2, end_price2, day_max_after_end, next_open`
  - `t_start` = 第一段起始价格对应的 1min bar 时间（HHMM）
  - `t_end`   = 第二段中首次 `close > end_price1` 的 1min bar 时间（HHMM）

### Step 2 — `filter_long_table.py`
- 输入：
  - segments：上一步输出
  - 原 raw_long_table：`/home/datamake119/data1/user118/hft/raw_long_table/sh_ordertranlob/{date}.parquet`、`.../sz_ordertranlob/{date}.parquet`
- 逻辑：
  - 同一 (date, code) 可能有多个区段，取所有 `[t_start, t_end]` 区间的并集
  - 将 1min bar 区间扩展为 raw_long_table 的 `time`（HHMMSSmmm）整型区间：
    `[t_start*100000, (t_end+1)*100000 - 1]`
  - 沪深两市分别读取、按 code+time 过滤后合并
- 输出：`/home/datamake119/data1/user118/hft/raw_long_table_newhigh/{date}.parquet`

## 批量运行
```bash
bash run_all.sh                 # step1 + step2，全部可用日期，并行
bash run_all.sh 20250102        # 仅跑单天
bash run_all.sh step1 20250102  # 只跑 step1 单天
PARALLEL1=24 PARALLEL2=12 bash run_all.sh
```

## 已验证（2025-01-02）
- Step1：154 条 (date, code) 记录，62 只股票，~2.2s
- Step2：1,640,035 条原始 long_table 记录，~14s
