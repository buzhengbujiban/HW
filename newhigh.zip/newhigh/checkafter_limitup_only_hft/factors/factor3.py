#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
factor3.py —— 拉升打压难度系数 + 连续反映羊群系数 + 控盘单区间价格偏向。

基于 order+trans+lob 一体长表构造，严格复用 factor1/factor2 框架。

因子 3：拉升打压难度系数（updown_tough）
-----------------------------------------
- acttrd_B: 买委托(functionCode=='B') 且 下一行是成交(orderKind.shift(-1)=='T')
- trd集群: acttrd_B 发生后，紧随其后连续 orderKind=='T' 的条目
- acttrd_B_sizeavgtick: acttrd_B 的 size / (trd集群最后price - trd集群开始price)
  即「每推动一个 tick 需要多少量」，衡量拉升难度
- acttrd_B_sizeavgtick_prob = cum_ewm(sizeavgtick) / cum_ewm(size_acttrd)
- updown_tough = BSimb(acttrd_B_sizeavgtick_prob, acttrd_S_sizeavgtick_prob)

因子 4：连续反映羊群系数（herd_react）
---------------------------------------
- acttrd_B 发生后，后续 20 个 event 中统计：
  acttrd_B 个数/size、addlevel1_S 个数/size、acttrd_S 个数/size
- react_prob = cum_ewm(react_metric) / cum_ewm(acttrd)
- BSimb 对称构造

因子 5：控盘单所在区间价格偏向（pctcxltrd）
--------------------------------------------
- mid = (bp1 + sp1) / 2
- price_std = price_lob.rolling(5000).std()
- 在 mid ± price_std * scale 范围内的事件中：
  pctcxltrd_B = cxl_B 价格均值 / trd_B 价格均值 - 1
- pctcxltrd_BSimb = BSimb(cum_ewm(pctcxltrd_B), cum_ewm(pctcxltrd_S))
"""

from __future__ import annotations

import argparse
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("hft.factor3")


class Config:
    # 一体长表目录（含 sz_ordertranlob / sh_ordertranlob 两个子目录）
    RAW_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/raw_long_table"
    MARKETS = ("sz", "sh")
    OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/factors"

    HL_LEVEL1 = 1000         # 基础 halflife
    HL_REACT = 500          # 羊群反应 halflife
    HL_PCTCXL = 500         # 控盘价格偏向 halflife
    MAX_WORKERS = 100

    # 羊群系数回看 event 数
    HERD_LOOKFORWARD = 20
    # 控盘单价格偏向的 scale 参数
    PCTCXL_SCALE = 1.5
    # 价格 rolling 窗口
    PCTCXL_ROLL_WINDOW = 900

    # 连续竞价时段（含端点），HHMMSSmmm
    AM_START, AM_END = 93000000, 113000000
    PM_START, PM_END = 130000000, 145700000

    # 读长表只取需要的列，省内存
    LACOLS = ['LA10', 'LA3600', 'LA43200', 'LA60', 'LAEOD', 'LAEOD1', 'LAEOD2',
       'LAEOD5', 'LASVWAP1', 'LASVWAP2', 'LASVWAP5']
    # 注：新长表 schema 与旧版差异较大，这里读入新字段，
    # 下方 _read_long_table 末尾会做兼容映射。
    USE_COLS = ["code", "time", "date", "type", "side",
                "volume", "sellorder", "buyorder",
                "price", "size", "seq_num", "number",
                "bp1", "sp1", "bv1", "sv1",
                "bp2", "sp2", "price_lob"] + LACOLS


def time_to_sec(t: np.ndarray) -> np.ndarray:
    """逐笔 time(HHMMSSmmm) -> 当日秒数(float)。"""
    t = t.astype("int64")
    ms = t % 1000
    rest = t // 1000
    s = rest % 100
    rest = rest // 100
    m = rest % 100
    h = rest // 100
    return (h * 3600 + m * 60 + s + ms / 1000.0).astype("float64")


def cumsum_minus_ewm(values: np.ndarray, halflife: float) -> np.ndarray:
    """cumsumfromopen(x) - cumsumfromopen(x).ewm(halflife).mean()。

    NaN 表示该事件不计入（cumsum 按 0 处理）。返回与 values 等长数组。
    """
    s = pd.Series(values, dtype="float64")
    cum = s.fillna(0.0).cumsum()
    ewm = cum.ewm(halflife=halflife, adjust=False, ignore_na=True).mean()
    return (cum - ewm).to_numpy()


def _ratio(a: pd.Series, b: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / b


def _bsimb(b: pd.Series, s: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b - s) / (b + s)




def _compute_sizeavgtick(tbl_df: pd.DataFrame, acttrd_B: pd.Series, acttrd_S: pd.Series):
    """计算 acttrd 的 size 和 price_delta，分别输出 B/S 两侧。向量化实现。

    trd集群定义：acttrd 事件后紧随的连续 orderKind=='T' 条目。
    acttrd_B 行：price_delta = last - first（拉升方向）
    acttrd_S 行：price_delta = first - last（打压方向）
    acttrd_B 和 acttrd_S 不会在同一行同时为 True（由 functionCode 决定方向）。

    返回 4 个 Series：(vsize_B, prx_delta_B, vsize_S, prx_delta_S)
    仅在对应 acttrd 行有值，其余 NaN。

    向量化思路：
    1. 对 is_trade 列做 cumsum，仅在 T 行递增 → 同一个连续 T 簇内 cumsum 值连续
    2. 用 cumsum 值与行号的差值 (idx - cumsum) 作为"簇 id"：
       同一段连续 T 行中 idx-cumsum 不变，非 T 行或新 T 簇会变
    3. 按簇 groupby 取首/末 tradePrice，映射回 acttrd 行
    """
    # 合并 B/S mask，因为它们不重叠
    acttrd_any = acttrd_B | acttrd_S
    n = len(tbl_df)
    idx = tbl_df.index  # 已 reset_index，即 0..n-1

    is_T = (tbl_df["orderKind"].values.astype(str) == "T")
    tp = tbl_df["tradePrice"].values.astype("float64")

    # 1) 对 T 行做 cumsum → 连续 T 块内值连续递增
    t_cumsum = np.cumsum(is_T)

    # 2) 簇 id = 行号 - t_cumsum：同一段连续 T 行中此值不变
    #    不同 T 簇之间被非 T 行隔开，簇 id 不同
    row_idx = np.arange(n)
    cluster_id = row_idx - t_cumsum  # 仅对 T 行有意义

    # 3) 只看 T 行，按 cluster_id 分组取首/末 tradePrice
    t_mask = is_T
    t_positions = np.where(t_mask)[0]

    if t_positions.size == 0:
        return pd.Series(np.full(n, np.nan), index=idx)

    t_cid = cluster_id[t_positions]
    t_price = tp[t_positions]

    # 找每个簇的第一个和最后一个 T 行
    # 簇边界：cid 与前一个不同 → 簇首；cid 与后一个不同 → 簇尾
    cid_diff = np.diff(t_cid)
    # 簇首位置（在 t_positions 中的索引）
    cluster_start_tidx = np.empty(len(t_positions), dtype="int64")
    cluster_end_tidx = np.empty(len(t_positions), dtype="int64")

    # 簇首：第一个元素 + cid_diff != 0 的后一个
    is_cluster_start = np.empty(len(t_positions), dtype=bool)
    is_cluster_start[0] = True
    is_cluster_start[1:] = cid_diff != 0

    is_cluster_end = np.empty(len(t_positions), dtype=bool)
    is_cluster_end[-1] = True
    is_cluster_end[:-1] = cid_diff != 0

    # 簇首价格和簇末价格，映射到每个 T 行
    # 用 cumsum 技巧把簇首/末的价格 forward-fill 到簇内所有 T 行
    start_price_arr = np.full(len(t_positions), np.nan)
    end_price_arr = np.full(len(t_positions), np.nan)

    # 簇首价格：在 is_cluster_start 处赋值，然后 ffill
    start_price_arr[is_cluster_start] = t_price[is_cluster_start]
    # ffill: 用 pandas 快速实现
    start_price_arr = pd.Series(start_price_arr).ffill().values

    # 簇末价格：在 is_cluster_end 处赋值，然后 bfill（反向填充到簇内）
    end_price_arr[is_cluster_end] = t_price[is_cluster_end]
    end_price_arr = pd.Series(end_price_arr).bfill().values

    # 4) 簇长度 >= 2 才有价差；簇只有 1 行时 start==end，price_delta=0 → 不计
    # 簇首行的全局位置：用来定位 acttrd（acttrd 行 = 簇首行 - 1）
    cluster_start_global = t_positions[is_cluster_start]
    cluster_first_price = t_price[is_cluster_start]
    cluster_last_price = end_price_arr[is_cluster_start]

    # 簇内 T 行数（用 np.diff 簇首索引）
    start_indices = np.where(is_cluster_start)[0]
    cluster_lengths = np.empty(len(start_indices), dtype="int64")
    cluster_lengths[:-1] = np.diff(start_indices)
    cluster_lengths[-1] = len(t_positions) - start_indices[-1]

    # 5) acttrd 行 = 簇首全局位置 - 1（acttrd 是紧接在 T 簇前面的委托行）
    acttrd_row = cluster_start_global - 1

    # 过滤：acttrd_row >= 0 且确实是 acttrd（B 或 S）
    acttrd_any_vals = acttrd_any.values
    acttrd_B_arr = acttrd_B.values
    acttrd_S_arr = acttrd_S.values
    valid = (acttrd_row >= 0) & (acttrd_row < n)
    valid[valid] = acttrd_any_vals[acttrd_row[valid]]

    # 6) 分 B/S 两侧输出
    result_B = np.full(n, np.nan, dtype="float64")
    delta_B = np.full(n, np.nan, dtype="float64")
    result_S = np.full(n, np.nan, dtype="float64")
    delta_S = np.full(n, np.nan, dtype="float64")

    if valid.any():
        v_acttrd = acttrd_row[valid]
        v_first = cluster_first_price[valid]
        v_last = cluster_last_price[valid]
        v_size = tbl_df["size"].values.astype("float64")[v_acttrd]

        # 判断每个有效 acttrd 行是 B 还是 S
        v_is_B = acttrd_B_arr[v_acttrd]
        v_is_S = acttrd_S_arr[v_acttrd]

        # B 侧：price_delta = last - first（拉升方向）
        # S 侧：price_delta = first - last（打压方向）
        raw_delta = np.where(v_is_B, v_last - v_first, v_first - v_last)

        # 对手方一档量：B 侧看 sv1，S 侧看 bv1
        sv1_arr = tbl_df["sv1"].values.astype("float64")
        bv1_arr = tbl_df["bv1"].values.astype("float64")
        opponent_level1 = np.where(v_is_B, sv1_arr[v_acttrd], bv1_arr[v_acttrd])

        # price_delta 修正逻辑：
        #   == 0 且 size == 对手一档量 → 0.01（恰好吃完一档）
        #   == 0 且 size != 对手一档量 → 0.005（没推动价格，半档近似）
        #   > 0 → raw_delta + 0.01
        #   < 0 → NaN（方向反了不记入）
        is_zero = raw_delta == 0
        is_positive = raw_delta > 0
        is_eq_level1 = np.isclose(v_size, opponent_level1, rtol=1e-9)

        price_delta = np.full_like(raw_delta, np.nan)
        price_delta[is_zero & is_eq_level1] = 0.01 * 10000
        price_delta[is_zero & ~is_eq_level1] = 0.002 * 10000
        price_delta[is_positive] = raw_delta[is_positive] + 0.01 * 10000

        good = ~np.isnan(price_delta)

        # B 侧赋值（仅 acttrd_B 行）
        good_B = good & v_is_B
        result_B[v_acttrd[good_B]] = v_size[good_B]
        delta_B[v_acttrd[good_B]] = price_delta[good_B]

        # S 侧赋值（仅 acttrd_S 行）
        good_S = good & v_is_S
        result_S[v_acttrd[good_S]] = v_size[good_S]
        delta_S[v_acttrd[good_S]] = price_delta[good_S]

    return (pd.Series(result_B, index=idx), pd.Series(delta_B, index=idx),
            pd.Series(result_S, index=idx), pd.Series(delta_S, index=idx))



def _compute_herd_react(tbl_df: pd.DataFrame, trigger_mask: pd.Series,
                        target_mask: pd.Series, metric: str,
                        lookforward: int) -> pd.Series:
    """在 trigger 事件后的 lookforward 个 event 中统计 target 事件的 cnt 或 size。

    向量化实现：对 target_mask 的 cumsum / (target_mask * size) 的 cumsum 做前移窗口差分。
    metric='cnt' 返回个数；metric='size' 返回 size 之和。
    仅在 trigger 行有值，其余 NaN。
    """
    n = len(tbl_df)
    idx = tbl_df.index

    if metric == "cnt":
        vals = target_mask.astype("float64").values
    else:
        vals = (target_mask * tbl_df["size"]).astype("float64").values

    # cumsum（NaN 视作 0）
    cumvals = np.cumsum(np.nan_to_num(vals, nan=0.0))
    # 在 trigger 行: result = cumvals[i+lookforward] - cumvals[i]
    trigger_pos = np.where(trigger_mask.values)[0]
    result = np.full(n, np.nan, dtype="float64")

    if trigger_pos.size == 0:
        return pd.Series(result, index=idx)

    end_pos = trigger_pos + lookforward
    end_pos = np.minimum(end_pos, n - 1)

    result[trigger_pos] = cumvals[end_pos] - cumvals[trigger_pos]

    return pd.Series(result, index=idx)

def _compute_pctcxltrd(tbl_df: pd.DataFrame, cxl_mask: pd.Series,
                       trd_mask: pd.Series, mid: pd.Series,
                       price_std: pd.Series, scale: float) -> pd.Series:
    """计算区间内 cxl 价格均值 / trd 价格均值 - 1。

    在每个事件行，用 rolling 口径：
    - 取当前 mid ± price_std * scale 范围内的 cxl/trd 事件
    - 用 cum_ewm 近似滚动均值
    这里简化为：先标记 in_range，再对 in_range 内的 cxl/trd 价格做 cum_ewm。
    """
    n = len(tbl_df)
    # 价格范围上下界
    upper = mid + price_std * scale
    lower = mid - price_std * scale

    # 撤单价格用 orderPrice（撤单行的 orderPrice 是被撤委托的价格）
    op = tbl_df["orderPrice"].values.astype("float64")
    # 成交价格用 tradePrice
    tp = tbl_df["tradePrice"].values.astype("float64")

    upper_v = upper.values.astype("float64")
    lower_v = lower.values.astype("float64")

    # cxl 在范围内：cxl_mask & orderPrice 在 [lower, upper]
    cxl_in_range = cxl_mask.values & (op >= lower_v) & (op <= upper_v)
    # trd 在范围内：trd_mask & tradePrice 在 [lower, upper]
    trd_in_range = trd_mask.values & (tp >= lower_v) & (tp <= upper_v)

    # cxl 价格（范围内），其余 NaN
    cxl_price = np.where(cxl_in_range, op, np.nan)
    # trd 价格（范围内），其余 NaN
    trd_price = np.where(trd_in_range, tp, np.nan)

    return pd.Series(cxl_price, index=tbl_df.index), pd.Series(trd_price, index=tbl_df.index)


def _one_stock(date: str, code: str, tbl_df: pd.DataFrame, cfg: Config) -> pd.DataFrame | None:
    """单股票：计算拉升打压难度 + 羊群反应 + 控盘价格偏向因子。"""
    if tbl_df.empty:
        return None

    tbl_df = tbl_df.sort_values(["time", "seq_num"]).reset_index(drop=True)
    out = tbl_df[["date", "code", "time", "seq_num"] + cfg.LACOLS].copy()

    # ====================================================================
    # 前置清洗：修正无效盘口价 + 为市价单/本方最优价单填充合理的 orderPrice
    # ====================================================================
    tbl_df['sp1'] = np.where(tbl_df['sp1'] <= 0, tbl_df['bp1'] * 0.7, tbl_df['sp1'])
    tbl_df['bp1'] = np.where(tbl_df['bp1'] > 5 * tbl_df['sp1'], tbl_df['sp1'] * 1.3, tbl_df['bp1'])
    tbl_df['bp1'] = np.where(tbl_df['bp1'] <= 0, tbl_df['sp1'], tbl_df['bp1'])
    tbl_df['orderPrice'] = np.where(
        (tbl_df['orderKind'].astype(str) == '1') & (tbl_df['functionCode'] == 'B'),
        tbl_df['price_lob'] * 1.3,
        np.where(
            (tbl_df['orderKind'].astype(str) == '1') & (tbl_df['functionCode'] == 'S'),
            tbl_df['price_lob'] * 0.7, tbl_df['orderPrice']))
    tbl_df['orderPrice'] = np.where(
        (tbl_df['orderKind'].astype(str) == 'U') & (tbl_df['functionCode'] == 'B'),
        tbl_df['price_lob'],
        np.where(
            (tbl_df['orderKind'].astype(str) == 'U') & (tbl_df['functionCode'] == 'S'),
            tbl_df['price_lob'], tbl_df['orderPrice']))

    fc = tbl_df["functionCode"].astype(str)
    ok = tbl_df["orderKind"].astype(str)
    o_is_buy = fc == "B"
    o_is_sell = fc == "S"
    is_cxl = fc == "C"
    is_trade = ok == "T"

    # 主动买/卖委托：委托行且下一行是成交
    acttrd_B = o_is_buy & (ok.shift(-1) == "T")
    acttrd_S = o_is_sell & (ok.shift(-1) == "T")

    # 新增更优一档（用于羊群系数中的 addlevel1_S / addlevel1_B）
    new_buy = (o_is_buy & (tbl_df["bp1"] > 0) & (tbl_df["bv1"] == tbl_df["size"])
               & (tbl_df["orderPrice"] > tbl_df["bp1"].shift()) & (ok.shift(-1) != "T"))
    new_sell = (o_is_sell & (tbl_df["sp1"] > 0) & (tbl_df["sv1"] == tbl_df["size"])
                & (tbl_df["orderPrice"] < tbl_df["sp1"].shift()) & (ok.shift(-1) != "T"))

    def cum_ewm(col: str, hl: float) -> pd.Series:
        """对长表的某列做 cumsum-ewm。"""
        return pd.Series(cumsum_minus_ewm(tbl_df[col].to_numpy("float64"), hl),
                         index=tbl_df.index)

    # ==========================================================================
    # 因子3：拉升打压难度系数（updown_tough）
    # ==========================================================================
    # acttrd 的 size（仅 acttrd 行有值）
    tbl_df["size_acttrd_B"] = tbl_df["size"].where(acttrd_B, np.nan)
    tbl_df["size_acttrd_S"] = tbl_df["size"].where(acttrd_S, np.nan)

    # sizeavgtick：acttrd 的 size / trd集群价格变化（每个 tick 需要多少量）
    (tbl_df["vsize_B"], tbl_df["prx_delta_B"],
     tbl_df["vsize_S"], tbl_df["prx_delta_S"]) = _compute_sizeavgtick(tbl_df, acttrd_B, acttrd_S)
    tbl_df["sizeavgtick_B"] = tbl_df["vsize_B"] / tbl_df['prx_delta_B']
    tbl_df["sizeavgtick_S"] = tbl_df["vsize_S"] / tbl_df['prx_delta_S']

    # cum_ewm
    tbl_df["f_sizeavgtick_B"] = cum_ewm("sizeavgtick_B", cfg.HL_LEVEL1)
    tbl_df["f_sizeavgtick_S"] = cum_ewm("sizeavgtick_S", cfg.HL_LEVEL1)
    tbl_df["f_size_acttrd_B"] = cum_ewm("size_acttrd_B", cfg.HL_LEVEL1)
    tbl_df["f_size_acttrd_S"] = cum_ewm("size_acttrd_S", cfg.HL_LEVEL1)

    # sizeavgtick_prob = cum_ewm(sizeavgtick) / cum_ewm(size_acttrd)
    tbl_df["sizeavgtick_B_prob"] = _ratio(tbl_df["f_sizeavgtick_B"], tbl_df["f_size_acttrd_B"])
    tbl_df["sizeavgtick_S_prob"] = _ratio(tbl_df["f_sizeavgtick_S"], tbl_df["f_size_acttrd_S"])

    # updown_tough = BSimb(sizeavgtick_B_prob, sizeavgtick_S_prob)
    # 含义：B 侧难度越大（每 tick 需要更多量）且 S 侧容易 → 正值，说明拉升难打压易
    out["updown_tough_BSimb"] = _bsimb(
        tbl_df["sizeavgtick_B_prob"],
        tbl_df["sizeavgtick_S_prob"])

    out['sizeavgtick_BSimb'] = _bsimb(
        tbl_df["f_sizeavgtick_B"],
        tbl_df["f_sizeavgtick_S"]
    )
    # ==========================================================================
    # 因子4：连续反映羊群系数（herd_react）
    # ==========================================================================
    lf = cfg.HERD_LOOKFORWARD

    # acttrd_B 发生后 20 个 event 中 acttrd_B 的 cnt/size
    tbl_df["react_acttrd_B_cnt_afterB"] = _compute_herd_react(
        tbl_df, acttrd_B, acttrd_B, "cnt", lf)
    tbl_df["react_acttrd_B_size_afterB"] = _compute_herd_react(
        tbl_df, acttrd_B, acttrd_B, "size", lf)

    # acttrd_B 发生后 20 个 event 中 addlevel1_S 的 cnt/size
    tbl_df["react_addlevel1_S_cnt_afterB"] = _compute_herd_react(
        tbl_df, acttrd_B, new_sell, "cnt", lf)
    tbl_df["react_addlevel1_S_size_afterB"] = _compute_herd_react(
        tbl_df, acttrd_B, new_sell, "size", lf)

    # acttrd_B 发生后 20 个 event 中 acttrd_S 的 cnt/size
    tbl_df["react_acttrd_S_cnt_afterB"] = _compute_herd_react(
        tbl_df, acttrd_B, acttrd_S, "cnt", lf)
    tbl_df["react_acttrd_S_size_afterB"] = _compute_herd_react(
        tbl_df, acttrd_B, acttrd_S, "size", lf)

    # 对称：acttrd_S 发生后的反应
    tbl_df["react_acttrd_S_cnt_afterS"] = _compute_herd_react(
        tbl_df, acttrd_S, acttrd_S, "cnt", lf)
    tbl_df["react_acttrd_S_size_afterS"] = _compute_herd_react(
        tbl_df, acttrd_S, acttrd_S, "size", lf)

    tbl_df["react_addlevel1_B_cnt_afterS"] = _compute_herd_react(
        tbl_df, acttrd_S, new_buy, "cnt", lf)
    tbl_df["react_addlevel1_B_size_afterS"] = _compute_herd_react(
        tbl_df, acttrd_S, new_buy, "size", lf)

    tbl_df["react_acttrd_B_cnt_afterS"] = _compute_herd_react(
        tbl_df, acttrd_S, acttrd_B, "cnt", lf)
    tbl_df["react_acttrd_B_size_afterS"] = _compute_herd_react(
        tbl_df, acttrd_S, acttrd_B, "size", lf)

    # acttrd 笔数（作为分母）
    tbl_df["cnt_acttrd_B"] = acttrd_B.astype("float64").where(acttrd_B, np.nan)
    tbl_df["cnt_acttrd_S"] = acttrd_S.astype("float64").where(acttrd_S, np.nan)

    # cum_ewm 分子分母
    tbl_df["f_cnt_acttrd_B"] = cum_ewm("cnt_acttrd_B", cfg.HL_REACT)
    tbl_df["f_cnt_acttrd_S"] = cum_ewm("cnt_acttrd_S", cfg.HL_REACT)

    # --- acttrd_B 后跟随 acttrd_B 的 cnt ---
    tbl_df["f_react_acttrd_B_cnt_afterB"] = cum_ewm("react_acttrd_B_cnt_afterB", cfg.HL_REACT)
    tbl_df["react_acttrd_B_cnt_afterB_prob"] = _ratio(
        tbl_df["f_react_acttrd_B_cnt_afterB"], tbl_df["f_cnt_acttrd_B"])
    # 对称：acttrd_S 后跟随 acttrd_S 的 cnt
    tbl_df["f_react_acttrd_S_cnt_afterS"] = cum_ewm("react_acttrd_S_cnt_afterS", cfg.HL_REACT)
    tbl_df["react_acttrd_S_cnt_afterS_prob"] = _ratio(
        tbl_df["f_react_acttrd_S_cnt_afterS"], tbl_df["f_cnt_acttrd_S"])
    # BSimb: acttrd_B 后的同向跟随 vs acttrd_S 后的同向跟随
    out["herd_acttrd_cnt_react_BSimb"] = _bsimb(
        tbl_df["react_acttrd_B_cnt_afterB_prob"],
        tbl_df["react_acttrd_S_cnt_afterS_prob"])

    # --- acttrd_B 后跟随 acttrd_B 的 size ---
    tbl_df["f_react_acttrd_B_size_afterB"] = cum_ewm("react_acttrd_B_size_afterB", cfg.HL_REACT)
    tbl_df["react_acttrd_B_size_afterB_prob"] = _ratio(
        tbl_df["f_react_acttrd_B_size_afterB"], tbl_df["f_cnt_acttrd_B"])
    tbl_df["f_react_acttrd_S_size_afterS"] = cum_ewm("react_acttrd_S_size_afterS", cfg.HL_REACT)
    tbl_df["react_acttrd_S_size_afterS_prob"] = _ratio(
        tbl_df["f_react_acttrd_S_size_afterS"], tbl_df["f_cnt_acttrd_S"])
    out["herd_acttrd_size_react_BSimb"] = _bsimb(
        tbl_df["react_acttrd_B_size_afterB_prob"],
        tbl_df["react_acttrd_S_size_afterS_prob"])

    # --- acttrd_B 后跟随 addlevel1_S 的 cnt ---
    tbl_df["f_react_addlevel1_S_cnt_afterB"] = cum_ewm("react_addlevel1_S_cnt_afterB", cfg.HL_REACT)
    tbl_df["react_addlevel1_S_cnt_afterB_prob"] = _ratio(
        tbl_df["f_react_addlevel1_S_cnt_afterB"], tbl_df["f_cnt_acttrd_B"])
    tbl_df["f_react_addlevel1_B_cnt_afterS"] = cum_ewm("react_addlevel1_B_cnt_afterS", cfg.HL_REACT)
    tbl_df["react_addlevel1_B_cnt_afterS_prob"] = _ratio(
        tbl_df["f_react_addlevel1_B_cnt_afterS"], tbl_df["f_cnt_acttrd_S"])
    out["herd_addlevel1_cnt_react_BSimb"] = _bsimb(
        tbl_df["react_addlevel1_S_cnt_afterB_prob"],
        tbl_df["react_addlevel1_B_cnt_afterS_prob"])

    # --- acttrd_B 后跟随 addlevel1_S 的 size ---
    tbl_df["f_react_addlevel1_S_size_afterB"] = cum_ewm("react_addlevel1_S_size_afterB", cfg.HL_REACT)
    tbl_df["react_addlevel1_S_size_afterB_prob"] = _ratio(
        tbl_df["f_react_addlevel1_S_size_afterB"], tbl_df["f_cnt_acttrd_B"])
    tbl_df["f_react_addlevel1_B_size_afterS"] = cum_ewm("react_addlevel1_B_size_afterS", cfg.HL_REACT)
    tbl_df["react_addlevel1_B_size_afterS_prob"] = _ratio(
        tbl_df["f_react_addlevel1_B_size_afterS"], tbl_df["f_cnt_acttrd_S"])
    out["herd_addlevel1_size_react_BSimb"] = _bsimb(
        tbl_df["react_addlevel1_S_size_afterB_prob"],
        tbl_df["react_addlevel1_B_size_afterS_prob"])

    # --- acttrd_B 后跟随 acttrd_S（反向）的 cnt ---
    tbl_df["f_react_acttrd_S_cnt_afterB"] = cum_ewm("react_acttrd_S_cnt_afterB", cfg.HL_REACT)
    tbl_df["react_acttrd_S_cnt_afterB_prob"] = _ratio(
        tbl_df["f_react_acttrd_S_cnt_afterB"], tbl_df["f_cnt_acttrd_B"])
    tbl_df["f_react_acttrd_B_cnt_afterS"] = cum_ewm("react_acttrd_B_cnt_afterS", cfg.HL_REACT)
    tbl_df["react_acttrd_B_cnt_afterS_prob"] = _ratio(
        tbl_df["f_react_acttrd_B_cnt_afterS"], tbl_df["f_cnt_acttrd_S"])
    out["herd_counter_cnt_react_BSimb"] = _bsimb(
        tbl_df["react_acttrd_S_cnt_afterB_prob"],
        tbl_df["react_acttrd_B_cnt_afterS_prob"])

    # --- acttrd_B 后跟随 acttrd_S（反向）的 size ---
    tbl_df["f_react_acttrd_S_size_afterB"] = cum_ewm("react_acttrd_S_size_afterB", cfg.HL_REACT)
    tbl_df["react_acttrd_S_size_afterB_prob"] = _ratio(
        tbl_df["f_react_acttrd_S_size_afterB"], tbl_df["f_cnt_acttrd_B"])
    tbl_df["f_react_acttrd_B_size_afterS"] = cum_ewm("react_acttrd_B_size_afterS", cfg.HL_REACT)
    tbl_df["react_acttrd_B_size_afterS_prob"] = _ratio(
        tbl_df["f_react_acttrd_B_size_afterS"], tbl_df["f_cnt_acttrd_S"])
    out["herd_counter_size_react_BSimb"] = _bsimb(
        tbl_df["react_acttrd_S_size_afterB_prob"],
        tbl_df["react_acttrd_B_size_afterS_prob"])

    # ==========================================================================
    # 因子5：控盘单所在区间价格偏向（pctcxltrd）
    # ==========================================================================
    # mid = (bp1 + sp1) / 2
    mid = (tbl_df["price_lob"]) 
    # price_std = price_lob 的 rolling std（5000 event 窗口）
    price_std = tbl_df["price_lob"].astype("float64").rolling(
        window=cfg.PCTCXL_ROLL_WINDOW, min_periods=500).std()
    # 无效 std 填 0（前 100 行无法算 std）
    price_std = price_std.fillna(50000)

    scale = cfg.PCTCXL_SCALE
    upper = mid + price_std * scale
    lower = mid - price_std * scale

    # 撤单方向
    cxl_is_buy = is_cxl & (tbl_df["bidOrder"] > 0)
    cxl_is_sell = is_cxl & (tbl_df["askOrder"] > 0)

    # 成交方向（用于 trd 价格）
    trd_is_buy = is_trade & (tbl_df["bidOrder"] > tbl_df["askOrder"])
    trd_is_sell = is_trade & (tbl_df["askOrder"] > tbl_df["bidOrder"])

    # 撤单行的 orderPrice 全为 NaN，改用 price_lob 作为撤单价格代理
    # 原因：一体长表中撤单行没有 orderPrice，但 price_lob 是该事件发生后的最新成交价，
    # 可以近似该撤单对应的价格区域
    cxl_price_proxy = tbl_df["price_lob"].astype("float64")
    tp = tbl_df["tradePrice"].astype("float64")

    # 在范围内的 cxl_B / trd_B 价格
    in_range_cxl_B = cxl_is_buy & (cxl_price_proxy >= lower) & (cxl_price_proxy <= upper)
    in_range_trd_B = trd_is_buy & (tp >= lower) & (tp <= upper)
    in_range_cxl_S = cxl_is_sell & (cxl_price_proxy >= lower) & (cxl_price_proxy <= upper)
    in_range_trd_S = trd_is_sell & (tp >= lower) & (tp <= upper)

    # cxl/trd 价格（范围内才有值，用于 ewm 累计均值近似）
    tbl_df["cxlprice_B"] = cxl_price_proxy.where(in_range_cxl_B, np.nan)
    tbl_df["trdprice_B"] = tp.where(in_range_trd_B, np.nan)
    tbl_df["cxlprice_S"] = cxl_price_proxy.where(in_range_cxl_S, np.nan)
    tbl_df["trdprice_S"] = tp.where(in_range_trd_S, np.nan)

    # 用 size 加权 ewm 做滚动均值近似：
    # weighted_price_ewm = ewm(price * size) / ewm(size)
    # 即 VWAP 式的加权平均价，对大单赋予更高权重
    hl_pctcxl = cfg.HL_PCTCXL
    size_f = tbl_df["size"].astype("float64")

    # cxl_B 的 size 加权价格
    cxl_B_ps = (tbl_df["cxlprice_B"] * size_f).ewm(halflife=hl_pctcxl, ignore_na=True, adjust=True).mean()
    cxl_B_sw = size_f.where(in_range_cxl_B, np.nan).ewm(halflife=hl_pctcxl, ignore_na=True, adjust=True).mean()
    cxlprice_B_ewm = _ratio(cxl_B_ps, cxl_B_sw)

    # trd_B 的 size 加权价格
    trd_B_ps = (tbl_df["trdprice_B"] * size_f).ewm(halflife=hl_pctcxl, ignore_na=True, adjust=True).mean()
    trd_B_sw = size_f.where(in_range_trd_B, np.nan).ewm(halflife=hl_pctcxl, ignore_na=True, adjust=True).mean()
    trdprice_B_ewm = _ratio(trd_B_ps, trd_B_sw)

    # cxl_S 的 size 加权价格
    cxl_S_ps = (tbl_df["cxlprice_S"] * size_f).ewm(halflife=hl_pctcxl, ignore_na=True, adjust=True).mean()
    cxl_S_sw = size_f.where(in_range_cxl_S, np.nan).ewm(halflife=hl_pctcxl, ignore_na=True, adjust=True).mean()
    cxlprice_S_ewm = _ratio(cxl_S_ps, cxl_S_sw)

    # trd_S 的 size 加权价格
    trd_S_ps = (tbl_df["trdprice_S"] * size_f).ewm(halflife=hl_pctcxl, ignore_na=True, adjust=True).mean()
    trd_S_sw = size_f.where(in_range_trd_S, np.nan).ewm(halflife=hl_pctcxl, ignore_na=True, adjust=True).mean()
    trdprice_S_ewm = _ratio(trd_S_ps, trd_S_sw)

    # pctcxltrd_B = cxl_B 价格均值 / trd_B 价格均值 - 1
    # 含义：撤单买的价格相对成交买的价格偏高多少，正值=撤单在高位（试探性挂单）
    # 注意：pctcxltrd 本身已经是比值型（偏离度），量级很小，直接对 pctcxltrd 做 BSimb
    pctcxltrd_B_raw = _ratio(trdprice_B_ewm, cxlprice_B_ewm)
    pctcxltrd_S_raw = _ratio(cxlprice_S_ewm, trdprice_S_ewm)

    # 对 pctcxltrd 直接取 BSimb（不再过 cum_ewm，因为 ewm 均价本身已经平滑）
    # BSimb 的分母 (B+S) 在两侧都极小时会爆炸，所以用 clip 限制到 [-1,1]
    out["pctcxltrd_BSimb"] = _bsimb(pctcxltrd_B_raw, pctcxltrd_S_raw).clip(-1.0, 1.0)
    out["pctcxltrd_BSimb_opp"] = _bsimb(pctcxltrd_B_raw, 1 / pctcxltrd_S_raw).clip(-1.0, 1.0)

    return out[::100]


def _read_long_table(date: str, cfg: Config) -> pd.DataFrame:
    """读取沪深一体长表，在读取层(parquet filters)就只取连续竞价时段。"""
    time_filters = [
        [("time", ">=", cfg.AM_START), ("time", "<=", cfg.AM_END)],
        [("time", ">=", cfg.PM_START), ("time", "<=", cfg.PM_END)],
    ]
    frames = []
    for market in cfg.MARKETS:
        path = Path(cfg.RAW_DIR) / f"{market}_ordertranlob" / f"{date}.parquet"
        if not path.exists():
            continue
        df = pd.read_parquet(path, columns=cfg.USE_COLS, filters=time_filters)
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["code"] = df["code"].astype(str)
    df["time"] = df["time"].astype("int64")

    # ====================================================================
    # === schema 兼容层：新长表字段 → 旧因子代码使用的字段名 ===
    # ====================================================================
    price_cols = ["price", "price_lob",
                  "bp1", "bp2", "bp3", "bp4", "bp5",
                  "sp1", "sp2", "sp3", "sp4", "sp5"]
    for c in price_cols:
        if c in df.columns:
            v = df[c].astype("float64").to_numpy()
            v = np.where(np.isnan(v) | (v <= 0), -10000.0, v * 10000.0)
            df[c] = v.astype("int64")

    type_s = df["type"].astype(str)
    side_s = df["side"].astype(str).where(df["side"].notna(), "")
    is_trade = (type_s == "T").to_numpy()
    is_cxl = (type_s == "D").to_numpy()
    fc = np.where(is_cxl, "C", np.where(~is_trade, side_s.to_numpy(), ""))
    df["functionCode"] = fc
    df["orderKind"] = type_s.to_numpy()
    df["orderPrice"] = df["price"]
    df["orderVolume"] = df["volume"]
    df["tradePrice"] = df["price"]      # 新 schema 中成交价/委托价统一为 price
    df["bidOrder"] = df["buyorder"]
    df["askOrder"] = df["sellorder"]
    df["order"] = df["number"]

    return df


def _one_stock_worker(args):
    """进程池工作函数：解包参数后调用 _one_stock。"""
    date, code, sub_df, cfg = args
    return _one_stock(date, code, sub_df, cfg)


def build_one_day(date: str, cfg: Config) -> pd.DataFrame:
    """单日：读一体长表，对每只股票并行计算因子。"""
    table_df = _read_long_table(date, cfg)
    if table_df.empty:
        logger.warning("%s 无长表数据，跳过", date)
        return pd.DataFrame()

    groups = list(table_df.groupby("code", sort=False))
    logger.info("%s 股票数=%d，单日内并行 max_workers=%d", date, len(groups), cfg.MAX_WORKERS)

    frames = []
    max_workers = max(1, int(cfg.MAX_WORKERS))
    if max_workers == 1:
        for code, sub_df in tqdm(groups, desc=date):
            frame = _one_stock(date, str(code), sub_df, cfg)
            if frame is not None and not frame.empty:
                frames.append(frame)
    else:
        tasks = [(date, str(code), sub_df, cfg) for code, sub_df in groups]
        with ProcessPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(_one_stock_worker, t): t[1] for t in tasks}
            for fut in tqdm(as_completed(futures), total=len(futures), desc=date):
                code = futures[fut]
                try:
                    frame = fut.result()
                except Exception as exc:
                    logger.exception("%s %s 计算失败：%s", date, code, exc)
                    raise
                if frame is not None and not frame.empty:
                    frames.append(frame)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def process_day(date: str, cfg: Config) -> str:
    """处理单个交易日并保存；已存在则跳过(断点恢复)。"""
    by_date_dir = Path(cfg.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "")
    by_date_dir.mkdir(parents=True, exist_ok=True)
    out_path = by_date_dir / f"factor3_{date}.parquet"
    if out_path.exists():
        logger.info("skip %s（已存在）", date)
        return f"skip {date}"

    df = build_one_day(date, cfg)
    if df.empty:
        logger.warning("empty %s", date)
        return f"empty {date}"
    df.to_parquet(out_path, index=False)
    logger.info("ok %s rows=%d codes=%d -> %s", date, len(df), df["code"].nunique(), out_path)
    return f"ok {date} rows={len(df)} codes={df['code'].nunique()}"


def main():
    parser = argparse.ArgumentParser(
        description="拉升打压难度 + 羊群反应 + 控盘价格偏向因子（单日，股票级并行）")
    parser.add_argument("--date", type=str, default="20250822",
                        help="交易日 YYYYMMDD（只处理这一天）")
    parser.add_argument("--max-workers", type=int, default=100,
                        help="单日内对股票并行的进程数，默认 100")
    args = parser.parse_args()

    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")

    cfg = Config()
    cfg.MAX_WORKERS = args.max_workers
    logger.info("处理交易日 %s，股票级并行 max_workers=%d", args.date, cfg.MAX_WORKERS)
    process_day(args.date, cfg)


if __name__ == "__main__":
    import shutil, os, stat
    _src = Path(__file__).resolve()
    _dst = Path(Config.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "") / _src.name
    if not _dst.exists():
        _dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(_src, _dst)
        os.chmod(_dst, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    main()
