#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
fr_realization.py —— BSimb 高频因子对 LA10~LASVWAP5 标签的 realization fr 曲线。

任务目标
--------
参照 spillover/fr_backtest.py 的思路：逐交易日计算因子 x 对各标签 y 的 fr，
画出每个交易日 fr 的累计(cumulative)曲线，用来看因子方向的稳定性。

fr 定义
-------
fr = ∑(x - xmean)(y - ymean) / var(x) = cov(x, y) / var(x)
即 x→y 的 OLS 回归斜率(beta)。x 为因子、y 为标签。
对每个交易日，把当天所有 (股票, time) 的样本汇总成一个截面，算出一个标量 fr。

两条线
------
- l2：x 用因子原始值，fr 反映因子数值大小与 y 的关系。
- l1：x 先去均值再取 sign(只保留方向)，fr 反映"只用因子方向"对 y 的预测力。

数据
----
  每个文件已包含 BSimb 因子列 + LA10~LASVWAP5 标签列 + (date,code,time) 键。
  无需再额外读取 lags 文件。

输出
----
- 逐日 fr 明细 CSV：fr_daily_all.csv（含各因子各 label 的 l1/l2 fr）。
- 图：每个因子两张 PNG（l1、l2），每张图内画 11 个 label 的 fr 累计曲线。

设计原则：代码简洁、命名清晰、日志明确、逐日并行、先小样本验证。
"""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # 无显示环境下保存图片
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from joblib import Parallel, delayed
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("hft.fr_realization")


class Config:
    FACTOR_NAME = "factor1"
    FACTOR_DIR = f"/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/factors/{FACTOR_NAME}"
    OUTPUT_DIR = f"/home/user118/.local/.nogd/jk/newhigh/checkafter_limitup_only_hft/fr_output/{FACTOR_NAME}/"

    # 标签列（LA10 ~ LASVWAP5）
    LABEL_COLS = ["LA10", "LA60", "LA3600", "LA43200",
                "LAEOD", "LAEOD1", "LAEOD2", "LAEOD5",
                "LASVWAP1", "LASVWAP2", "LASVWAP5"]

    KEY_COLS = ["date", "code", "time","seq_num"]
    # 单日截面最少样本数，过少则该日 fr 记为 NaN
    MIN_SAMPLES = 100
    MAX_WORKERS = 125
    X_CENTER = True   # 计算 fr 时是否对 x 去均值
    Y_CENTER = True   # 计算 fr 时是否对 y 去均值

def _fr(x: np.ndarray, y: np.ndarray,
        x_center: bool = True, y_center: bool = True) -> float:
    """fr = ∑xc·yc / ∑xc²。

    x_center=True  -> xc = x - mean(x)；False -> xc = x（不去均值）
    y_center=True  -> yc = y - mean(y)；False -> yc = y（不去均值）
    """
    xc = (x - x.mean()) if x_center else x
    yc = (y - y.mean()) if y_center else y
    denom = np.dot(xc, xc)
    if denom <= 0:
        return np.nan
    return float(np.dot(xc, yc) / np.sqrt(denom))


def _factor_cols(df: pd.DataFrame) -> list[str]:
    """因子 = 列名含 BSimb 的列。"""
    return [c for c in df.columns if "BSimb" in c]


def fr_one_day(date: str, cfg: Config) -> pd.DataFrame | None:


    fpath = Path(cfg.FACTOR_DIR) / f"{cfg.FACTOR_NAME}_{date}.parquet"
    if not fpath.exists():
        return None

    df = pd.read_parquet(fpath)[::2]
    factors = _factor_cols(df)
    # 确认标签列存在
    labels = [c for c in cfg.LABEL_COLS if c in df.columns]
    if not factors or not labels:
        logger.warning("%s 缺少因子列或标签列，跳过", date)
        return None

    # 只保留需要的列
    use_cols = cfg.KEY_COLS + factors + labels
    df = df[use_cols]

    if df.empty:
        logger.warning("%s 数据为空", date)
        return None

    records = []
    for fac in factors:
        for lab in labels:
            sub = df[[fac, lab]].dropna()
            n = len(sub)
            if n < cfg.MIN_SAMPLES:
                records.append({"date": date, "factor": fac, "label": lab,
                                "fr_l1": np.nan, "fr_l2": np.nan, "n": n})
                continue
            x = sub[fac].to_numpy("float64")
            y = sub[lab].to_numpy("float64")
            # l2：原始因子值
            fr_l2 = _fr(x, y, x_center=cfg.X_CENTER, y_center=cfg.Y_CENTER)
            # l1：去均值后只保留方向 sign
            x_sign = np.sign(x - x.mean())
            fr_l1 = _fr(x_sign, y, x_center=cfg.X_CENTER, y_center=cfg.Y_CENTER)
            records.append({"date": date, "factor": fac, "label": lab,
                            "fr_l1": fr_l1, "fr_l2": fr_l2, "n": n})

    return pd.DataFrame(records)


def list_dates(cfg: Config, start: str | None, end: str | None) -> list[str]:
    fdir = Path(cfg.FACTOR_DIR)
    prefix = f"{cfg.FACTOR_NAME}_"
    dates = sorted(p.stem.replace(prefix, "") for p in fdir.glob(f"{prefix}*.parquet"))
    if start:
        dates = [d for d in dates if d >= start]
    if end:
        dates = [d for d in dates if d <= end]
    return dates


def collect_fr(cfg: Config, dates: list[str]) -> pd.DataFrame:
    """逐日并行计算 fr（使用 joblib.Parallel），汇总成长表。"""
    n_jobs = max(1, int(cfg.MAX_WORKERS))
    results = Parallel(n_jobs=n_jobs)(
        delayed(fr_one_day)(d, cfg) for d in tqdm(dates, desc="fr")
    )
    frames = [r for r in results if r is not None and not r.empty]
    if not frames:
        return pd.DataFrame()
    out = pd.concat(frames, ignore_index=True)
    return out.sort_values(["factor", "label", "date"]).reset_index(drop=True)


def plot_factor(fr_long: pd.DataFrame, factor: str, line: str, cfg: Config) -> str:
    """画单个因子、单条线(l1 或 l2)的各 label fr 累计曲线。

    line: "fr_l1" 或 "fr_l2"。横轴=date，纵轴=逐日 fr 的 cumsum，每个 label 一条线。
    """
    out_dir = Path(cfg.OUTPUT_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)

    sub = fr_long[fr_long["factor"] == factor]
    cmap = plt.get_cmap("tab20")
    labels = cfg.LABEL_COLS

    fig, ax = plt.subplots(figsize=(13, 7))
    for i, lab in enumerate(labels):
        g = sub[sub["label"] == lab].sort_values("date")
        if g.empty:
            continue
        x = pd.to_datetime(g["date"], format="%Y%m%d")
        cum = g[line].fillna(0.0).cumsum()
        n_days = len(g)
        cum_daily_avg = cum / n_days  # 曲线形状不变，y 轴刻度为 daily 平均 fr
        mean = g[line].mean()
        ax.plot(x, cum_daily_avg, color=cmap(i % 20), lw=1.5,
                label=f"{lab} (fr_mean={mean:.4g})")

    ax.axhline(0, color="gray", lw=0.8)
    tag = "l1(sign(x))" if line == "fr_l1" else "l2(raw x)"
    ax.set_title(f"Cumulative fr (daily avg scale)  |  factor={factor}  |  {tag}")
    ax.set_xlabel("date")
    ax.set_ylabel("daily average fr")
    ax.legend(loc="upper left", fontsize=8, ncol=2)
    ax.grid(True, alpha=0.3)
    fig.autofmt_xdate()
    fig.tight_layout()

    suffix = "l1" if line == "fr_l1" else "l2"
    out_path = out_dir / f"fr_{factor}_{suffix}.png"
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    logger.info("已保存 %s", out_path)
    return str(out_path)


def _time_to_hms(t: np.ndarray) -> np.ndarray:
    """将 HHMMSSmmm 格式的 time 转为 HH:MM:SS 字符串，用于 x 轴显示。"""
    t = t.astype("int64")
    ms = t % 1000
    rest = t // 1000
    s = rest % 100
    rest = rest // 100
    m = rest % 100
    h = rest // 100
    return np.array([f"{hh:02d}:{mm:02d}:{ss:02d}" for hh, mm, ss in zip(h, m, s)])


def _pick_sample_codes(df: pd.DataFrame, n_sh: int = 2, n_sz: int = 2) -> list[str]:
    """从 df 中挑选样本股票：n_sh 只 688 开头（科创板），n_sz 只 00/300 开头（深市）。"""
    codes = df["code"].astype(str).unique()
    sh_codes = sorted([c for c in codes if c.startswith("688")])[:n_sh]
    sz_codes = sorted([c for c in codes if c.startswith("00") or c.startswith("300")])[:n_sz]
    return sh_codes + sz_codes


def plot_intraday_factors(cfg: Config, date: str):
    """对指定日期，挑选 4 只样本股票，绘制各因子日内变化图（2x2 子图）。"""
    fpath = Path(cfg.FACTOR_DIR) / f"{cfg.FACTOR_NAME}_{date}.parquet"
    if not fpath.exists():
        logger.warning("plot_intraday: %s 文件不存在，跳过", fpath)
        return

    df = pd.read_parquet(fpath)
    factors = _factor_cols(df)
    if not factors:
        logger.warning("plot_intraday: %s 无因子列", date)
        return

    sample_codes = _pick_sample_codes(df)
    if len(sample_codes) == 0:
        logger.warning("plot_intraday: %s 无满足条件的股票", date)
        return
    logger.info("plot_intraday: date=%s, sample_codes=%s", date, sample_codes)

    out_dir = Path(cfg.OUTPUT_DIR) / "intraday"
    out_dir.mkdir(parents=True, exist_ok=True)

    for fac in factors:
        n_codes = len(sample_codes)
        ncols = 2
        nrows = (n_codes + 1) // 2
        fig, axes = plt.subplots(nrows, ncols, figsize=(16, 5 * nrows), squeeze=False)

        for idx, code in enumerate(sample_codes):
            ax = axes[idx // ncols][idx % ncols]
            sub = df[df["code"].astype(str) == code].sort_values("time")
            if sub.empty:
                ax.set_title(f"{code} (no data)")
                continue
            time_arr = sub["time"].to_numpy()
            fac_arr = sub[fac].to_numpy("float64")

            # x 轴用 HH:MM:SS 字符串
            time_labels = _time_to_hms(time_arr)
            x_pos = np.arange(len(time_labels))
            ax.plot(x_pos, fac_arr, lw=0.6, alpha=0.8)
            ax.set_title(f"{code}", fontsize=11)
            ax.set_ylabel(fac, fontsize=9)
            ax.grid(True, alpha=0.3)
            ax.axhline(0, color="gray", lw=0.5)

            # x 轴抽稀显示
            n_ticks = min(10, len(x_pos))
            tick_idx = np.linspace(0, len(x_pos) - 1, n_ticks, dtype=int)
            ax.set_xticks(x_pos[tick_idx])
            ax.set_xticklabels(time_labels[tick_idx], rotation=45, fontsize=7)

        # 隐藏多余的子图
        for idx in range(n_codes, nrows * ncols):
            axes[idx // ncols][idx % ncols].set_visible(False)

        fig.suptitle(f"Intraday factor: {fac}  |  date={date}", fontsize=13)
        fig.tight_layout(rect=[0, 0, 1, 0.96])
        out_path = out_dir / f"intraday_{fac}_{date}.png"
        fig.savefig(out_path, dpi=150)
        plt.close(fig)
        logger.info("已保存 %s", out_path)


def run(cfg: Config, start: str | None, end: str | None, limit_days: int | None):
    dates = list_dates(cfg, start, end)
    if limit_days is not None:
        dates = dates[:limit_days]
    if not dates:
        logger.warning("无可处理交易日，退出")
        return
    logger.info("待处理交易日数：%d（%s ~ %s），max_workers=%d",
                len(dates), dates[0], dates[-1], cfg.MAX_WORKERS)

    fr_long = collect_fr(cfg, dates)
    if fr_long.empty:
        logger.warning("fr 结果为空，结束")
        return

    out_dir = Path(cfg.OUTPUT_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)
    fr_long.to_csv(out_dir / "fr_daily_all.csv", index=False)
    logger.info("逐日 fr 明细已保存 -> %s", out_dir / "fr_daily_all.csv")

    # 每个因子出 l1、l2 两张图
    for factor in sorted(fr_long["factor"].unique()):
        plot_factor(fr_long, factor, "fr_l1", cfg)
        plot_factor(fr_long, factor, "fr_l2", cfg)

    # 用开头日绘制日内因子变化图（4只样本股票 2x2 子图）
    plot_intraday_factors(cfg, dates[0])

    logger.info("全部完成，输出目录：%s", out_dir)


def main():
    parser = argparse.ArgumentParser(description="BSimb 因子对 LA 标签的 realization fr 曲线")
    parser.add_argument("--start", type=str, default="20240430", help="起始日 YYYYMMDD（默认不限制）")
    parser.add_argument("--end", type=str, default="20240731", help="结束日 YYYYMMDD（默认不限制）")
    parser.add_argument("--fac_name", type=str, default="factor7", help="结束日 YYYYMMDD")
    parser.add_argument("--limit-days", type=int, default=None, help="只处理前 N 天（小样本验证）")
    parser.add_argument("--max-workers", type=int, default=75, help="逐日并行进程数")
    parser.add_argument("--x-center", type=int, default=1,
                        help="计算 fr 时是否对 x 去均值（1=True, 0=False，默认 1）")
    parser.add_argument("--y-center", type=int, default=0,
                        help="计算 fr 时是否对 y 去均值（1=True, 0=False，默认 1）")
    args = parser.parse_args()

    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")


    class Config:
        FACTOR_NAME = args.fac_name
        FACTOR_DIR = f"/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/factors/{FACTOR_NAME}"
        OUTPUT_DIR = f"/home/user118/.local/.nogd/jk/newhigh/checkafter_limitup_only_hft/fr_outputy_center_{args.y_center}/{FACTOR_NAME}/"

        # 标签列（LA10 ~ LASVWAP5）
        LABEL_COLS = ["LA10", "LA60", "LA3600", "LA43200",
                    "LAEOD", "LAEOD1", "LAEOD2", "LAEOD5",
                    "LASVWAP1", "LASVWAP2", "LASVWAP5"]

        KEY_COLS = ["date", "code", "time","seq_num"]
        # 单日截面最少样本数，过少则该日 fr 记为 NaN
        MIN_SAMPLES = 100
        MAX_WORKERS = args.max_workers
        X_CENTER = bool(args.x_center)
        Y_CENTER = bool(args.y_center)
    cfg = Config()
    logger.info("x_center=%s, y_center=%s", cfg.X_CENTER, cfg.Y_CENTER)

    run(cfg, start=args.start, end=args.end, limit_days=args.limit_days)


if __name__ == "__main__":
    main()
