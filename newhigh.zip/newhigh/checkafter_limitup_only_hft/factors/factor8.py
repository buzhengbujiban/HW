#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
factor8.py —— 集中度(HHI)因子：基于 order+trans+lob 一体长表。

因子 14：集中度 (Herfindahl-Hirschman Index)
---------------------------------------------
对各类事件的 size / timesec / gap 序列计算 HHI 集中度：
    HHI_B = cum_ewm(x_B^2) / cum_ewm(x_B)^2
并输出买卖不平衡：
    {metric}_{event}_BSimb_HHI = _imb(HHI_B, HHI_S)

事件类型：
  add_eff        有效被动挂单（side='B/S' & 非主动成交 & 价格在 mid ± prxstd 内）
  add_atlevel1   挂在一档的被动挂单（functionCode='B/S' & 非主动成交 & price>=bp1 / price<=sp1）
  acttrd         主动成交（委托行且下一行是成交 orderKind.shift(-1)=='T'）
  cxl_eff        有效撤单（cancel 且 bv1~bv5 / sv1~sv5 至少一档量变化）
  cxl_atlevel1   撤一档（cancel 且 bp1/sp1 变化 或 bp1/sp1 不变但 bp2/sp2 变化）
  cxl_atlevel2   撤二档（cancel 且 bp2/sp2 价不变量变 或 bp1/sp1 不变 bp2/sp2 变了）
  cxl_atlevel12  撤一二档并集

度量 metric：
  size           事件的 size（成交/撤单/委托量）
  timesec        连续交易时间（秒，下午减午休 1.5h）
  gap_invpure    相对上一条非成交(type!='T')行的时间间隔+0.01 的倒数
  gap_inv_{i}    相对上一条同类事件的时间间隔+0.01 的倒数

输出因子（共 21 个）：
  size_{i}_BSimb_HHI                 (i 含 cxl_atlevel12，共 6 个)
  timesec_{i}_BSimb_HHI              (i 不含 cxl_atlevel12，共 5 个)
  gap_invpure_{i}_BSimb_HHI          (i 不含 cxl_atlevel12，共 5 个)
  gap_inv_{i}_BSimb_HHI              (i 不含 cxl_atlevel12，共 5 个)

对齐口径
--------
- 只保留连续竞价时段：time ∈ [93000000,113000000] ∪ [130000000,145700000]。
- 按 code 分组、组内按 (time,seq_num) 升序做 cumsum-ewm。
- 输出行与该日长表（时段过滤后）一致，最后 [::100] 抽稀。

输出
----
/home/datamake119/.../factors/factor8/factor8_<date>.parquet
"""

from __future__ import annotations

import argparse
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("hft.factor8")


class Config:
    RAW_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/raw_long_table"
    MARKETS = ("sz", "sh")
    OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/factors"

    HL_HHI = 5000              # HHI cum_ewm halflife
    PRX_ROLL_WINDOW = 5000     # prxstd rolling std 窗口
    PRX_STD_FILL = 200         # rolling std 无效时的填充值（*10000 口径）
    PRX_STD_COEFF = 1.0        # add_eff 的 prxstd 系数

    MAX_WORKERS = 40

    # 连续竞价时段（含端点），HHMMSSmmm
    AM_START, AM_END = 93000000, 113000000
    PM_START, PM_END = 130000000, 145700000

    LACOLS = ['LA10', 'LA3600', 'LA43200', 'LA60', 'LAEOD', 'LAEOD1', 'LAEOD2',
              'LAEOD5', 'LASVWAP1', 'LASVWAP2', 'LASVWAP5']
    # 需要五档量（bv1~bv5 / sv1~sv5）用于 cxl_eff 判定
    USE_COLS = ["code", "time", "date", "type", "side",
                "volume", "sellorder", "buyorder", "number",
                "price", "size", "seq_num", "price_lob",
                "bp1", "bp2", "sp1", "sp2",
                "bv1", "bv2", "bv3", "bv4", "bv5",
                "sv1", "sv2", "sv3", "sv4", "sv5"] + LACOLS


# ======================================================================
# 工具函数
# ======================================================================

def time_to_sec(t: np.ndarray) -> np.ndarray:
    """逐笔 time(HHMMSSmmm) -> 当日秒数(float)。"""
    t = t.astype("int64")
    ms = t % 1000
    rest = t // 1000
    s = rest % 100
    rest = rest // 100
    m = rest % 100
    h = rest // 100
    return (h * 3600 + m * 60 + s + ms / 1000.0).astype("float64")


def cumsum_minus_ewm(values: np.ndarray, halflife: float) -> np.ndarray:
    """cumsumfromopen(x) - cumsumfromopen(x).ewm(halflife).mean()。
    NaN 视为 0 参与 cumsum。"""
    s = pd.Series(values, dtype="float64")
    cum = s.fillna(0.0).cumsum()
    ewm = cum.ewm(halflife=halflife, adjust=False, ignore_na=True).mean()
    return (cum - ewm).to_numpy()


def _ratio(a, b):
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / b


def _imb(b, s):
    """买卖不平衡 (b - s) / (b + s)。"""
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b - s) / (b + s)


# ======================================================================
# 单股票因子计算
# ======================================================================

def _one_stock(date: str, code: str, tbl_df: pd.DataFrame, cfg: Config) -> pd.DataFrame | None:
    """单股票：计算集中度(HHI)因子。"""
    if tbl_df.empty:
        return None

    tbl_df = tbl_df.sort_values(["time", "seq_num"]).reset_index(drop=True)
    out = tbl_df[["date", "code", "time", "seq_num"] + cfg.LACOLS].copy()
    n = len(tbl_df)
    idx = tbl_df.index
    hl = cfg.HL_HHI

    # ---------- 基本标志 ----------
    fc = tbl_df["functionCode"].astype(str)
    ok = tbl_df["orderKind"].astype(str)
    o_is_buy = fc == "B"
    o_is_sell = fc == "S"
    is_cxl = fc == "C"
    is_trade_arr = (ok == "T").to_numpy()
    next_is_trade = ok.shift(-1) == "T"

    order_price = tbl_df["orderPrice"].astype("float64")
    event_size = tbl_df["size"].astype("float64")

    # ====================================================================
    # 中价 mid 与价格波动率 prxstd
    # ====================================================================
    bp1_f = tbl_df["bp1"].astype("float64")
    sp1_f = tbl_df["sp1"].astype("float64")
    plob = tbl_df["price_lob"].astype("float64")

    # 修正交叉盘口（与 factor7 一致）
    BP01 = np.where(bp1_f > plob, plob, bp1_f)
    SP01 = np.where(sp1_f < plob, plob, sp1_f)
    mid = pd.Series((BP01 + SP01) / 2.0, index=idx)

    prxstd = plob.rolling(window=cfg.PRX_ROLL_WINDOW, min_periods=500).std()
    prxstd = prxstd.fillna(cfg.PRX_STD_FILL) + 100

    # ====================================================================
    # 连续交易时间 timesec（下午减午休 1.5h，拼成连续时间轴）
    # ====================================================================
    sec = time_to_sec(tbl_df["time"].to_numpy("int64"))
    is_pm = tbl_df["time"].to_numpy("int64") >= cfg.PM_START
    timesec_arr = sec - np.where(is_pm, 1.5 * 3600.0, 0.0)

    # ====================================================================
    # 事件定义
    # ====================================================================

    # --- add_eff: 有效被动挂单 ---
    #   side='B' & 非主动成交(下一行非T) & price > mid - prxstd * 1.0
    add_eff_B = o_is_buy & (~next_is_trade) & (order_price > mid - prxstd * cfg.PRX_STD_COEFF)
    add_eff_S = o_is_sell & (~next_is_trade) & (order_price < mid + prxstd * cfg.PRX_STD_COEFF)

    # --- add_atlevel1: 挂在一档的被动挂单 ---
    #   orderKind='B' & 非主动成交 & price >= bp1（盘口有效时）
    add_atlevel1_B = o_is_buy & (~next_is_trade) & (tbl_df["bp1"] > 0) & (order_price >= bp1_f)
    add_atlevel1_S = o_is_sell & (~next_is_trade) & (tbl_df["sp1"] > 0) & (order_price <= sp1_f)

    # --- acttrd: 主动成交委托（委托行且下一行是成交）---
    acttrd_B = o_is_buy & next_is_trade
    acttrd_S = o_is_sell & next_is_trade

    # --- 撤单方向：撤买 bidOrder>0；撤卖 askOrder>0 ---
    cxl_is_buy = is_cxl & (tbl_df["bidOrder"] > 0)
    cxl_is_sell = is_cxl & (tbl_df["askOrder"] > 0)

    # 盘口 before-event = shift(1)（盘口为 after-event 快照）
    bp1_b = tbl_df["bp1"].shift(1)
    bp2_b = tbl_df["bp2"].shift(1)
    sp1_b = tbl_df["sp1"].shift(1)
    sp2_b = tbl_df["sp2"].shift(1)
    bv2_b = tbl_df["bv2"].shift(1)
    sv2_b = tbl_df["sv2"].shift(1)

    # --- cxl_atlevel1: 撤一档 ---
    #   条件1: bp1不变 且 bp2变了（撤单影响了一档但价格未消失）
    #   条件2: bp1变了（一档价格直接消失）
    cxl_atlevel1_B = cxl_is_buy & (
        ((tbl_df["bp1"] == bp1_b) & (tbl_df["bp2"] != bp2_b)) |
        (tbl_df["bp1"] != bp1_b))
    cxl_atlevel1_S = cxl_is_sell & (
        ((tbl_df["sp1"] == sp1_b) & (tbl_df["sp2"] != sp2_b)) |
        (tbl_df["sp1"] != sp1_b))

    # --- cxl_atlevel2: 撤二档 ---
    #   条件1: bp2不变 且 bv2变了 -> 撤单减少了第二挡位原有量
    #   条件2: bp1不变 且 bp2变了 -> 撤单让第二挡位消失了
    cxl_atlevel2_B = cxl_is_buy & (
        ((tbl_df["bp2"] == bp2_b) & (tbl_df["bv2"] != bv2_b)) |
        ((tbl_df["bp1"] == bp1_b) & (tbl_df["bp2"] != bp2_b)))
    cxl_atlevel2_S = cxl_is_sell & (
        ((tbl_df["sp2"] == sp2_b) & (tbl_df["sv2"] != sv2_b)) |
        ((tbl_df["sp1"] == sp1_b) & (tbl_df["sp2"] != sp2_b)))

    # --- cxl_atlevel12: 撤一二档并集 ---
    cxl_atlevel12_B = cxl_atlevel1_B | cxl_atlevel2_B
    cxl_atlevel12_S = cxl_atlevel1_S | cxl_atlevel2_S

    # --- cxl_eff: 有效撤单（bv1~bv5 / sv1~sv5 至少一档量变化）---
    bv_cols = [c for c in [f"bv{i}" for i in range(1, 6)] if c in tbl_df.columns]
    sv_cols = [c for c in [f"sv{i}" for i in range(1, 6)] if c in tbl_df.columns]

    bv_changed = pd.Series(False, index=idx)
    for c in bv_cols:
        bv_changed = bv_changed | (tbl_df[c] != tbl_df[c].shift(1))
    sv_changed = pd.Series(False, index=idx)
    for c in sv_cols:
        sv_changed = sv_changed | (tbl_df[c] != tbl_df[c].shift(1))

    cxl_eff_B = cxl_is_buy & bv_changed
    cxl_eff_S = cxl_is_sell & sv_changed

    # ====================================================================
    # Gap 定义
    # ====================================================================

    def _compute_gap_inv(mask_arr: np.ndarray) -> np.ndarray:
        """对事件序列计算相邻事件的时间间隔倒数 1/(gap+0.01)。
        只在 mask 为 True 的位置（从第二个起）有值，其余 NaN。"""
        pos = np.where(mask_arr)[0]
        gap_inv = np.full(n, np.nan)
        if len(pos) >= 2:
            gap_inv[pos[1:]] = 1.0 / (np.diff(timesec_arr[pos]) + 0.01)
        return gap_inv

    # gap_invpure: 非成交行(type!='T')之间的时间间隔倒数
    gap_invpure_arr = _compute_gap_inv(~is_trade_arr)

    # 各事件类型的 gap_inv（B/S 各自独立）
    gap_inv_map = {
        "add_eff":      (_compute_gap_inv(add_eff_B.to_numpy()),
                         _compute_gap_inv(add_eff_S.to_numpy())),
        "add_atlevel1": (_compute_gap_inv(add_atlevel1_B.to_numpy()),
                         _compute_gap_inv(add_atlevel1_S.to_numpy())),
        "acttrd":       (_compute_gap_inv(acttrd_B.to_numpy()),
                         _compute_gap_inv(acttrd_S.to_numpy())),
        "cxl_eff":      (_compute_gap_inv(cxl_eff_B.to_numpy()),
                         _compute_gap_inv(cxl_eff_S.to_numpy())),
        "cxl_atlevel1": (_compute_gap_inv(cxl_atlevel1_B.to_numpy()),
                         _compute_gap_inv(cxl_atlevel1_S.to_numpy())),
    }

    # ====================================================================
    # HHI 计算：HHI = cum_ewm(x^2) / cum_ewm(x)^2
    # ====================================================================

    def _hhi_bsimb(val_B: np.ndarray, val_S: np.ndarray) -> pd.Series:
        """计算 HHI_B 和 HHI_S，返回 _imb(HHI_B, HHI_S)。
        val_B / val_S 仅在事件位置有值，其余 NaN。"""
        cum_sq_B = pd.Series(cumsum_minus_ewm(val_B ** 2, hl), index=idx)
        cum_v_B = pd.Series(cumsum_minus_ewm(val_B, hl), index=idx)
        hhi_B = _ratio(cum_sq_B, cum_v_B ** 2)

        cum_sq_S = pd.Series(cumsum_minus_ewm(val_S ** 2, hl), index=idx)
        cum_v_S = pd.Series(cumsum_minus_ewm(val_S, hl), index=idx)
        hhi_S = _ratio(cum_sq_S, cum_v_S ** 2)

        return _imb(hhi_B, hhi_S)

    def _filter_to_event(arr, mask: pd.Series) -> np.ndarray:
        """只保留 mask 为 True 位置的值，其余置 NaN。"""
        if isinstance(arr, pd.Series):
            return arr.where(mask, np.nan).to_numpy("float64")
        else:
            return np.where(mask.to_numpy(), arr, np.nan).astype("float64")

    # ====================================================================
    # 输出因子
    # ====================================================================

    # 所有事件的 mask 字典
    events_all = {
        "add_eff":       (add_eff_B, add_eff_S),
        "add_atlevel1":  (add_atlevel1_B, add_atlevel1_S),
        "acttrd":        (acttrd_B, acttrd_S),
        "cxl_eff":       (cxl_eff_B, cxl_eff_S),
        "cxl_atlevel1":  (cxl_atlevel1_B, cxl_atlevel1_S),
        "cxl_atlevel12": (cxl_atlevel12_B, cxl_atlevel12_S),
    }

    # ------ 1) size HHI（含 cxl_atlevel12）------
    for evt_name, (mB, mS) in events_all.items():
        sB = _filter_to_event(event_size, mB)
        sS = _filter_to_event(event_size, mS)
        out[f"size_{evt_name}_BSimb_HHI"] = _hhi_bsimb(sB, sS)

    # ------ 2) timesec / gap_invpure / gap_inv HHI（不含 cxl_atlevel12）------
    events_for_gap = ["add_eff", "add_atlevel1", "acttrd", "cxl_eff", "cxl_atlevel1"]
    for evt_name in events_for_gap:
        mB, mS = events_all[evt_name]

        # timesec_{i}_BSimb_HHI
        ts_B = _filter_to_event(timesec_arr, mB)
        ts_S = _filter_to_event(timesec_arr, mS)
        out[f"timesec_{evt_name}_BSimb_HHI"] = _hhi_bsimb(ts_B, ts_S)

        # gap_invpure_{i}_BSimb_HHI
        gp_B = _filter_to_event(gap_invpure_arr, mB)
        gp_S = _filter_to_event(gap_invpure_arr, mS)
        out[f"gap_invpure_{evt_name}_BSimb_HHI"] = _hhi_bsimb(gp_B, gp_S)

        # gap_inv_{i}_BSimb_HHI
        gi_B, gi_S = gap_inv_map[evt_name]
        out[f"gap_inv_{evt_name}_BSimb_HHI"] = _hhi_bsimb(gi_B, gi_S)

    # ====================================================================
    # 过去成交的位置中心（300s 分桶，wavg_price_acttrd_BSimb）
    # ====================================================================
    BIN_SEC = 300
    tbl_df["TIME_BIN"] = (np.ceil(sec / BIN_SEC) * BIN_SEC).astype("int64")
    tbl_df["_mid"] = mid.to_numpy()

    # 主动成交的 price*size 和 size（仅 acttrd 事件位置有值）
    tbl_df["_pv_acttrd_B"] = (order_price * event_size).where(acttrd_B, np.nan)
    tbl_df["_v_acttrd_B"] = event_size.where(acttrd_B, np.nan)
    tbl_df["_pv_acttrd_S"] = (order_price * event_size).where(acttrd_S, np.nan)
    tbl_df["_v_acttrd_S"] = event_size.where(acttrd_S, np.nan)

    # 按 TIME_BIN 聚合：桶内 VWAP 分子分母 + 桶末 mid
    grp = tbl_df.groupby("TIME_BIN", sort=True)
    bin_agg = grp.agg(
        pv_B=("_pv_acttrd_B", "sum"),
        v_B=("_v_acttrd_B", "sum"),
        pv_S=("_pv_acttrd_S", "sum"),
        v_S=("_v_acttrd_S", "sum"),
        mid_last=("_mid", "last"),
    )

    with np.errstate(invalid="ignore", divide="ignore"):
        wavg_B = bin_agg["pv_B"] / bin_agg["v_B"]   # 买方 size 加权平均价
        wavg_S = bin_agg["pv_S"] / bin_agg["v_S"]   # 卖方 size 加权平均价
        # 买方：加权价 / mid（>1 表示买在 mid 上方，越激进越大）
        ratio_B = wavg_B / bin_agg["mid_last"]
        # 卖方：mid / 加权价（>1 表示卖在 mid 下方，越激进越大）
        ratio_S = bin_agg["mid_last"] / wavg_S

    bin_agg["wavg_price_acttrd_BSimb"] = _imb(ratio_B, ratio_S)

    # 映射回 tick 级（每个 tick 取其所在 TIME_BIN 的值）
    bin_map = bin_agg["wavg_price_acttrd_BSimb"]
    out["wavg_price_acttrd_BSimb"] = tbl_df["TIME_BIN"].map(bin_map).values

    return out[::100]


# ======================================================================
# 数据读取
# ======================================================================

def _read_long_table(date: str, cfg: Config) -> pd.DataFrame:
    """读取沪深一体长表，在读取层(parquet filters)就只取连续竞价时段。
    自动检测 parquet schema，仅读取存在的列（兼容缺少 bv3~bv5 等情况）。"""
    time_filters = [
        [("time", ">=", cfg.AM_START), ("time", "<=", cfg.AM_END)],
        [("time", ">=", cfg.PM_START), ("time", "<=", cfg.PM_END)],
    ]
    frames = []
    for market in cfg.MARKETS:
        path = Path(cfg.RAW_DIR) / f"{market}_ordertranlob" / f"{date}.parquet"
        if not path.exists():
            continue
        # 仅读取在 parquet 文件中实际存在的列
        schema_names = set(pq.read_schema(path).names)
        use_cols = [c for c in cfg.USE_COLS if c in schema_names]
        df = pd.read_parquet(path, columns=use_cols, filters=time_filters)
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["code"] = df["code"].astype(str)
    df["time"] = df["time"].astype("int64")

    # ====================================================================
    # === schema 兼容层：新长表字段 → 旧因子代码使用的字段名 ===
    # 价格列统一 *10000 转回旧口径（无效=−10000）。
    # ====================================================================
    price_cols = ["price", "price_lob",
                  "bp1", "bp2", "bp3", "bp4", "bp5",
                  "sp1", "sp2", "sp3", "sp4", "sp5"]
    for c in price_cols:
        if c in df.columns:
            v = df[c].astype("float64").to_numpy()
            v = np.where(np.isnan(v) | (v <= 0), -10000.0, v * 10000.0)
            df[c] = v.astype("int64")

    type_s = df["type"].astype(str)
    side_s = df["side"].astype(str).where(df["side"].notna(), "")
    is_trade = (type_s == "T").to_numpy()
    is_cxl = (type_s == "D").to_numpy()
    fc = np.where(is_cxl, "C", np.where(~is_trade, side_s.to_numpy(), ""))
    df["functionCode"] = fc
    df["orderKind"] = type_s.to_numpy()
    df["orderPrice"] = df["price"]
    df["orderVolume"] = df["volume"]
    df["bidOrder"] = df["buyorder"]
    df["askOrder"] = df["sellorder"]
    df["order"] = df["number"]

    return df


# ======================================================================
# 并行调度
# ======================================================================

def _one_stock_worker(args):
    """进程池工作函数：解包参数后调用 _one_stock。"""
    date, code, sub_df, cfg = args
    return _one_stock(date, code, sub_df, cfg)


def build_one_day(date: str, cfg: Config) -> pd.DataFrame:
    """单日：读一体长表，对每只股票并行计算因子。"""
    table_df = _read_long_table(date, cfg)
    if table_df.empty:
        logger.warning("%s 无长表数据，跳过", date)
        return pd.DataFrame()

    groups = list(table_df.groupby("code", sort=False))
    logger.info("%s 股票数=%d，单日内并行 max_workers=%d", date, len(groups), cfg.MAX_WORKERS)

    frames = []
    max_workers = max(1, int(cfg.MAX_WORKERS))
    if max_workers == 1:
        for code, sub_df in tqdm(groups, desc=date):
            frame = _one_stock(date, str(code), sub_df, cfg)
            if frame is not None and not frame.empty:
                frames.append(frame)
    else:
        tasks = [(date, str(code), sub_df, cfg) for code, sub_df in groups]
        with ProcessPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(_one_stock_worker, t): t[1] for t in tasks}
            for fut in tqdm(as_completed(futures), total=len(futures), desc=date):
                code = futures[fut]
                try:
                    frame = fut.result()
                except Exception as exc:
                    logger.exception("%s %s 计算失败：%s", date, code, exc)
                    raise
                if frame is not None and not frame.empty:
                    frames.append(frame)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def process_day(date: str, cfg: Config) -> str:
    """处理单个交易日并保存；已存在则跳过(断点恢复)。"""
    by_date_dir = Path(cfg.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "")
    by_date_dir.mkdir(parents=True, exist_ok=True)
    out_path = by_date_dir / f"factor8_{date}.parquet"
    if out_path.exists():
        logger.info("skip %s（已存在）", date)
        return f"skip {date}"

    df = build_one_day(date, cfg)
    if df.empty:
        logger.warning("empty %s", date)
        return f"empty {date}"
    df.to_parquet(out_path, index=False)
    logger.info("ok %s rows=%d codes=%d -> %s", date, len(df), df["code"].nunique(), out_path)
    return f"ok {date} rows={len(df)} codes={df['code'].nunique()}"


def main():
    parser = argparse.ArgumentParser(
        description="集中度(HHI)因子（单日，股票级并行）")
    parser.add_argument("--date", type=str, default="20240430",
                        help="交易日 YYYYMMDD（只处理这一天）")
    parser.add_argument("--max-workers", type=int, default=40,
                        help="单日内对股票并行的进程数，默认 40")
    args = parser.parse_args()

    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")

    cfg = Config()
    cfg.MAX_WORKERS = args.max_workers
    logger.info("处理交易日 %s，股票级并行 max_workers=%d", args.date, cfg.MAX_WORKERS)
    process_day(args.date, cfg)


if __name__ == "__main__":
    import shutil, os, stat
    _src = Path(__file__).resolve()
    _dst = Path(Config.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "") / _src.name
    if not _dst.exists():
        _dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(_src, _dst)
        os.chmod(_dst, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    main()
