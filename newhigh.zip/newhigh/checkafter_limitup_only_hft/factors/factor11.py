#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
factor11.py (zz500 版) —— 基于 order+trans+lob 一体长表构造高频因子。

与 jk/hft/factors/factor11.py 的唯一区别：
- RAW_DIR    -> zz500 的 raw_long_table 目录
- OUTPUT_DIR -> zz500 的 factors 目录

业务逻辑完全相同，便于横向对比。
"""

from __future__ import annotations

import argparse
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("hft_zz500.factor11")


class Config:
    # ====== zz500 路径 ======
    RAW_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/raw_long_table"
    MARKETS = ("sz", "sh")
    OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/factors"

    HL_LEVEL1 = 2000         # allormorelevel1 / add_newlevel1 / trdact 计数与量
    HL_TRDACT_DIFF = 2500    # trdact_B_diff / trdact_BSimb_diff
    HL_GAP_SHORT = 200       # shrinkGap 分子
    HL_GAP_LONG = 2500      # shrinkGap 分母
    MAX_WORKERS = 60

    # 连续竞价时段（含端点），HHMMSSmmm
    AM_START, AM_END = 93000000, 113000000
    PM_START, PM_END = 130000000, 145700000

    LACOLS = ['LA10', 'LA3600', 'LA43200', 'LA60', 'LAEOD', 'LAEOD1', 'LAEOD2',
              'LAEOD5', 'LASVWAP1', 'LASVWAP2', 'LASVWAP5']
    USE_COLS = ["code", "time", "date", "type", "side",
                "volume", "sellorder", "buyorder",
                "price", "size", "seq_num", "number",
                "bp1", "sp1", "bv1", "sv1"] + LACOLS


def in_trading_session(t: np.ndarray, cfg: Config) -> np.ndarray:
    """是否在连续竞价时段内。"""
    return (((t >= cfg.AM_START) & (t <= cfg.AM_END)) |
            ((t >= cfg.PM_START) & (t <= cfg.PM_END)))


def time_to_sec(t: np.ndarray) -> np.ndarray:
    """逐笔 time(HHMMSSmmm) -> 当日秒数(float)。"""
    t = t.astype("int64")
    ms = t % 1000
    rest = t // 1000
    s = rest % 100
    rest = rest // 100
    m = rest % 100
    h = rest // 100
    return (h * 3600 + m * 60 + s + ms / 1000.0).astype("float64")


def cumsum_minus_ewm(values: np.ndarray, halflife: float) -> np.ndarray:
    """cumsumfromopen(x) - cumsumfromopen(x).ewm(halflife).mean()。"""
    s = pd.Series(values, dtype="float64")
    cum = s.fillna(0.0).cumsum()
    ewm = cum.ewm(halflife=halflife, adjust=False, ignore_na=True).mean()
    return (cum - ewm).to_numpy()


def _ratio(a: pd.Series, b: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / b


def _bsimb(b: pd.Series, s: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b - s) / (b + s)


def _one_stock(date: str, code: str, tbl_df: pd.DataFrame, cfg: Config) -> pd.DataFrame | None:
    """单股票：在一体长表（已按事件升序）上用 pandas 列运算做 cumsum-ewm，得到因子。"""
    if tbl_df.empty:
        return None

    tbl_df = tbl_df.sort_values(["time", "seq_num"]).reset_index(drop=True)
    out = tbl_df[["date", "code", "time","seq_num"] + cfg.LACOLS].copy()

    # ---------- 成交侧 trdact（仅成交行 orderKind=='T' 有值）----------
    is_trade = tbl_df["orderKind"].astype(str) == "T"
    is_buy = is_trade & (tbl_df["bidOrder"] > tbl_df["askOrder"])
    is_sell = is_trade & (tbl_df["askOrder"] > tbl_df["bidOrder"])
    # 吃档：买主动量 >= 卖一量 sv1；卖主动量 >= 买一量 bv1（一档量 >0 才有效）
    eat_buy = is_buy & (tbl_df["sv1"] > 0) & (tbl_df["volume"] >= tbl_df["sv1"])
    eat_sell = is_sell & (tbl_df["bv1"] > 0) & (tbl_df["volume"] >= tbl_df["bv1"])

    tbl_df["size_trdact_B"] = tbl_df["volume"].where(is_buy, np.nan)
    tbl_df["size_trdact_S"] = tbl_df["volume"].where(is_sell, np.nan)
    tbl_df["cnt_trdact_B"] = is_buy.astype("float64").where(is_buy, np.nan)
    tbl_df["cnt_trdact_S"] = is_sell.astype("float64").where(is_sell, np.nan)
    tbl_df["size_trdact_allormorelevel1_B"] = tbl_df["volume"].where(eat_buy, np.nan)
    tbl_df["size_trdact_allormorelevel1_S"] = tbl_df["volume"].where(eat_sell, np.nan)
    tbl_df["cnt_trdact_allormorelevel1_B"] = eat_buy.astype("float64").where(eat_buy, np.nan)
    tbl_df["cnt_trdact_allormorelevel1_S"] = eat_sell.astype("float64").where(eat_sell, np.nan)

    # ---------- 委托侧 add（仅委托行 functionCode∈{B,S} 有值）----------
    # fc = tbl_df["functionCode"].astype(str)
    # o_is_buy = fc == "B"
    # o_is_sell = fc == "S"
    # 新增更优一档：买价 > 买一价 bp1；卖价 < 卖一价 sp1（盘口价 >0 才有效）
    # new_buy = o_is_buy & (tbl_df["bp1"] > 0) & (tbl_df['bv1']==tbl_df['size']) & (tbl_df["orderPrice"] > tbl_df["bp1"].shift()) & (tbl_df['orderKind'].shift(-1)!='T')
    # new_sell = o_is_sell & (tbl_df["sp1"] > 0) & (tbl_df['sv1']==tbl_df['size']) & (tbl_df["orderPrice"] < tbl_df["sp1"].shift())  & (tbl_df['orderKind'].shift(-1)!='T')

    # tbl_df["add_size_B"] = tbl_df["orderVolume"].where(o_is_buy, np.nan)
    # tbl_df["add_size_S"] = tbl_df["orderVolume"].where(o_is_sell, np.nan)
    # tbl_df["add_cnt_B"] = o_is_buy.astype("float64").where(o_is_buy, np.nan)
    # tbl_df["add_cnt_S"] = o_is_sell.astype("float64").where(o_is_sell, np.nan)
    # tbl_df["add_size_newlevel1_B"] = tbl_df["orderVolume"].where(new_buy, np.nan)
    # tbl_df["add_size_newlevel1_S"] = tbl_df["orderVolume"].where(new_sell, np.nan)
    # tbl_df["add_cnt_newlevel1_B"] = new_buy.astype("float64").where(new_buy, np.nan)
    # tbl_df["add_cnt_newlevel1_S"] = new_sell.astype("float64").where(new_sell, np.nan)

    def cum_ewm(col: str, hl: float) -> pd.Series:
        """对长表的某列做 cumsum-ewm。"""
        return pd.Series(cumsum_minus_ewm(tbl_df[col].to_numpy("float64"), hl),
                            index=tbl_df.index)

    # ---------- 成交侧因子 ----------
    tbl_df['f_size_B'] = cum_ewm("size_trdact_B", cfg.HL_LEVEL1)
    tbl_df['f_size_S'] = cum_ewm("size_trdact_S", cfg.HL_LEVEL1)
    tbl_df['f_cnt_B'] = cum_ewm("cnt_trdact_B", cfg.HL_LEVEL1)
    tbl_df['f_cnt_S'] = cum_ewm("cnt_trdact_S", cfg.HL_LEVEL1)
    tbl_df['f_size_lvl1_B'] = cum_ewm("size_trdact_allormorelevel1_B", cfg.HL_LEVEL1)
    tbl_df['f_size_lvl1_S'] = cum_ewm("size_trdact_allormorelevel1_S", cfg.HL_LEVEL1)
    tbl_df['f_cnt_lvl1_B'] = cum_ewm("cnt_trdact_allormorelevel1_B", cfg.HL_LEVEL1)
    tbl_df['f_cnt_lvl1_S'] = cum_ewm("cnt_trdact_allormorelevel1_S", cfg.HL_LEVEL1)

    tbl_df["size_trdact_allormorelevel1_B_prob"] = _ratio(tbl_df['f_size_lvl1_B'], tbl_df['f_size_B'])
    tbl_df["size_trdact_allormorelevel1_S_prob"] = _ratio(tbl_df['f_size_lvl1_S'], tbl_df['f_size_S'])
    out["size_trdact_allormorelevel1_prob_BSimb"] = _bsimb(
        tbl_df["size_trdact_allormorelevel1_B_prob"],
        tbl_df["size_trdact_allormorelevel1_S_prob"])

    out["cnt_trdact_allormorelevel1_B_prob"] = _ratio(tbl_df['f_cnt_lvl1_B'], tbl_df['f_cnt_B'])
    out["cnt_trdact_allormorelevel1_S_prob"] = _ratio(tbl_df['f_cnt_lvl1_S'], tbl_df['f_cnt_S'])
    out["cnt_trdact_allormorelevel1_prob_BSimb"] = _bsimb(
        out["cnt_trdact_allormorelevel1_B_prob"],
        out["cnt_trdact_allormorelevel1_S_prob"])

    # trdact_B_diff / trdact_BSimb_diff（笔数口径，halflife=250）
    out["trdact_B_diff"] = cum_ewm("cnt_trdact_B", cfg.HL_TRDACT_DIFF)
    net = (tbl_df["cnt_trdact_B"].fillna(0.0) - tbl_df["cnt_trdact_S"].fillna(0.0))
    out["trdact_BSimb_diff"] = pd.Series(
        cumsum_minus_ewm(net.to_numpy("float64"), cfg.HL_TRDACT_DIFF),
        index=tbl_df.index)

    # shrinkGap_trdact_B：主动买成交相邻时间差(秒)的短/长 ewm 之比
    sec = time_to_sec(tbl_df["time"].to_numpy("int64"))
    gap = np.full(len(tbl_df), np.nan)
    sellgap = np.full(len(tbl_df), np.nan)

    buy_pos = np.where(tbl_df["cnt_trdact_B"].notnull())[0]
    sell_pos = np.where(tbl_df["cnt_trdact_S"].notnull())[0]

    if buy_pos.size >= 2:
        gap[buy_pos[1:]] = np.diff(sec[buy_pos])
    if sell_pos.size >= 2:
        sellgap[sell_pos[1:]] = np.diff(sec[sell_pos])


    tbl_df['gap'] = np.log(1/(gap + 0.01))
    out["shrinkGap_trdact_B"] = cum_ewm("gap", cfg.HL_GAP_LONG)

    tbl_df['sellgap'] = np.log(1/(sellgap+0.01))
    out["shrinkGap_trdact_S"] = cum_ewm("sellgap", cfg.HL_GAP_LONG)
    out["shrinkGap_trdact_BSimb"] = out.eval("(shrinkGap_trdact_B - shrinkGap_trdact_S) / (shrinkGap_trdact_S + shrinkGap_trdact_B + 0.1)")


    return out[::100]


def _read_long_table(date: str, cfg: Config) -> pd.DataFrame:
    """读取沪深一体长表，在读取层(parquet filters)就只取连续竞价时段。"""
    time_filters = [
        [("time", ">=", cfg.AM_START), ("time", "<=", cfg.AM_END)],
        [("time", ">=", cfg.PM_START), ("time", "<=", cfg.PM_END)],
    ]
    frames = []
    for market in cfg.MARKETS:
        path = Path(cfg.RAW_DIR) / f"{market}_ordertranlob" / f"{date}.parquet"
        if not path.exists():
            continue
        df = pd.read_parquet(path, columns=cfg.USE_COLS, filters=time_filters)
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["code"] = df["code"].astype(str)
    df["time"] = df["time"].astype("int64")

    # schema 兼容层：新长表字段 → 旧因子代码使用的字段名（与 jk/hft/factors/factor11.py 一致）
    price_cols = ["price", "price_lob",
                  "bp1", "bp2", "bp3", "bp4", "bp5",
                  "sp1", "sp2", "sp3", "sp4", "sp5"]
    for c in price_cols:
        if c in df.columns:
            v = df[c].astype("float64").to_numpy()
            v = np.where(np.isnan(v) | (v <= 0), -10000.0, v * 10000.0)
            df[c] = v.astype("int64")

    type_s = df["type"].astype(str)
    side_s = df["side"].astype(str).where(df["side"].notna(), "")
    is_trade = (type_s == "T").to_numpy()
    is_cxl = (type_s == "D").to_numpy()
    fc = np.where(is_cxl, "C", np.where(~is_trade, side_s.to_numpy(), ""))
    df["functionCode"] = fc
    df["orderKind"] = type_s.to_numpy()
    df["orderPrice"] = df["price"]
    df["orderVolume"] = df["volume"]
    df["bidOrder"] = df["buyorder"]
    df["askOrder"] = df["sellorder"]
    df["order"] = df["number"]

    return df


def _one_stock_worker(args):
    date, code, sub_df, cfg = args
    return _one_stock(date, code, sub_df, cfg)


def build_one_day(date: str, cfg: Config) -> pd.DataFrame:
    """单日：读一体长表，对每只股票并行计算因子。"""
    table_df = _read_long_table(date, cfg)
    if table_df.empty:
        logger.warning("%s 无长表数据，跳过", date)
        return pd.DataFrame()

    groups = list(table_df.groupby("code", sort=False))
    logger.info("%s 股票数=%d，单日内并行 max_workers=%d", date, len(groups), cfg.MAX_WORKERS)

    frames = []
    max_workers = max(1, int(cfg.MAX_WORKERS))
    if max_workers == 1:
        for code, sub_df in tqdm(groups, desc=date):
            frame = _one_stock(date, str(code), sub_df, cfg)
            if frame is not None and not frame.empty:
                frames.append(frame)
    else:
        tasks = [(date, str(code), sub_df, cfg) for code, sub_df in groups]
        with ProcessPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(_one_stock_worker, t): t[1] for t in tasks}
            for fut in tqdm(as_completed(futures), total=len(futures), desc=date):
                code = futures[fut]
                try:
                    frame = fut.result()
                except Exception as exc:
                    logger.exception("%s %s 计算失败：%s", date, code, exc)
                    raise
                if frame is not None and not frame.empty:
                    frames.append(frame)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def process_day(date: str, cfg: Config) -> str:
    """处理单个交易日并保存；已存在则跳过(断点恢复)。"""
    by_date_dir = Path(cfg.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "")
    by_date_dir.mkdir(parents=True, exist_ok=True)
    out_path = by_date_dir / f"factor11_{date}.parquet"
    if out_path.exists():
        logger.info("skip %s（已存在）", date)
        return f"skip {date}"

    df = build_one_day(date, cfg)
    if df.empty:
        logger.warning("empty %s", date)
        return f"empty {date}"
    df.to_parquet(out_path, index=False)
    logger.info("ok %s rows=%d codes=%d -> %s", date, len(df), df["code"].nunique(), out_path)
    return f"ok {date} rows={len(df)} codes={df['code'].nunique()}"


def main():
    parser = argparse.ArgumentParser(
        description="zz500: 基于 order+trans+lob 一体长表的高频因子（单日，股票级并行）")
    parser.add_argument("--date", type=str, default="20250822", help="交易日 YYYYMMDD（只处理这一天）")
    parser.add_argument("--max-workers", type=int, default=20,
                        help="单日内对股票并行的进程数")
    args = parser.parse_args()

    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")

    cfg = Config()
    cfg.MAX_WORKERS = args.max_workers
    logger.info("处理交易日 %s，股票级并行 max_workers=%d", args.date, cfg.MAX_WORKERS)
    process_day(args.date, cfg)


if __name__ == "__main__":
    import shutil
    import os
    import stat
    _src = Path(__file__).resolve()
    _dst = Path(Config.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "") / _src.name
    if not _dst.exists():
        _dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(_src, _dst)
        os.chmod(_dst, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    main()
