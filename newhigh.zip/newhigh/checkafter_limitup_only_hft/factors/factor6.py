#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
factor6.py —— DISTANCE：5min 新增委托加权价相对 mid 的距离不平衡。

基于 order+trans+lob 一体长表构造，复用 factor3 框架，但**输出粒度为每 5min 一行**
（与 factor1/3/5 的「每 tick 一行」不同）。

因子 9：DISTANCE（dis_out_BSimb）
---------------------------------
1. 时间分桶：TIME_BIN = ceil(time_sec / 300) * 300（每 5min 一个桶）。
2. 新增委托(add_order)：委托行 functionCode∈{B,S} 且下一行不是成交
   （orderKind.shift(-1) != 'T'），即真正挂进盘口的被动委托（与 factor1 口径一致）。
3. 分买/卖方，groupby TIME_BIN，求桶内 add_order 的成交量加权平均委托价：
   wavg_price_B = Σ(orderPrice·orderVolume) / Σ(orderVolume)  （仅买方 add_order）
   wavg_price_S 同理（仅卖方 add_order）。
4. mid 取每个 TIME_BIN 末尾那一刻的 (bp1 + sp1) / 2。
5. DISTANCE 因子（每 5min 一个值）：
   dis_out_BSimb = _imb(|wavg_price_B - mid|, |wavg_price_S - mid|)
   含义：买方挂单价离 mid 越远（相对卖方）→ 正值，反映买方挂单更「远离盘口」
   （试探性/远端堆单）；越接近 0 表示买卖挂单离 mid 距离对称。

写法说明（与原 _one_stock 的不同）
---------------------------------
- 原因子是「每个 tick 一个值」：所有中间量挂在 tbl_df 上，逐行计算后 [::100] 抽样。
- 本因子是「每 5min 一个值」：先把对方事件赋 NaN（买方价只在买 add_order 行有值，
  卖方同理），再 groupby TIME_BIN 聚合统计，最终每个桶一行。
"""

from __future__ import annotations

import argparse
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("hft.factor6")


class Config:
    # 一体长表目录（含 sz_ordertranlob / sh_ordertranlob 两个子目录）
    RAW_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/raw_long_table"
    MARKETS = ("sz", "sh")
    OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/factors"

    MAX_WORKERS = 100

    # 时间分桶长度（秒）：每 5min 一个桶
    BIN_SEC = 300

    # 连续竞价时段（含端点），HHMMSSmmm
    AM_START, AM_END = 93000000, 113000000
    PM_START, PM_END = 130000000, 145700000

    # LA 标签列，按 TIME_BIN 取 last 后拼接到输出
    LACOLS = ['LA10', 'LA3600', 'LA43200', 'LA60', 'LAEOD', 'LAEOD1', 'LAEOD2',
              'LAEOD5', 'LASVWAP1', 'LASVWAP2', 'LASVWAP5']

    # 读长表只取需要的列，省内存
    # 注：新长表 schema 与旧版差异较大，这里读入新字段，
    # 下方 _read_long_table 末尾会做兼容映射。
    USE_COLS = ["code", "time", "date", "type", "side",
                "volume", "sellorder", "buyorder",
                "price", "size", "seq_num", "number",
                "bp1", "sp1", "price_lob"] + LACOLS


def time_to_sec(t: np.ndarray) -> np.ndarray:
    """逐笔 time(HHMMSSmmm) -> 当日秒数(float)。"""
    t = t.astype("int64")
    ms = t % 1000
    rest = t // 1000
    s = rest % 100
    rest = rest // 100
    m = rest % 100
    h = rest // 100
    return (h * 3600 + m * 60 + s + ms / 1000.0).astype("float64")


def _imb(b: pd.Series, s: pd.Series) -> pd.Series:
    """不平衡度 (b - s) / (b + s)，分母为 0 时返回 NaN。"""
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b - s) / (b + s)


def _one_stock(date: str, code: str, tbl_df: pd.DataFrame, cfg: Config) -> pd.DataFrame | None:
    """单股票：计算 5min 粒度的 DISTANCE 因子。"""
    if tbl_df.empty:
        return None

    tbl_df = tbl_df.sort_values(["time", "seq_num"]).reset_index(drop=True)

    # ====================================================================
    # 前置清洗：修正无效盘口价 + 为市价单/本方最优价单填充合理的 orderPrice
    # （与 factor3 一致，确保 orderPrice / mid 在涨跌停、市价单场景下不失真）
    # ====================================================================
    tbl_df['sp1'] = np.where(tbl_df['sp1'] <= 0, tbl_df['bp1'] * 0.7, tbl_df['sp1'])
    tbl_df['bp1'] = np.where(tbl_df['bp1'] > 5 * tbl_df['sp1'], tbl_df['sp1'] * 1.3, tbl_df['bp1'])
    tbl_df['bp1'] = np.where(tbl_df['bp1'] <= 0, tbl_df['sp1'], tbl_df['bp1'])
    tbl_df['orderPrice'] = np.where(
        (tbl_df['orderKind'].astype(str) == '1') & (tbl_df['functionCode'] == 'B'),
        tbl_df['price_lob'] * 1.3,
        np.where(
            (tbl_df['orderKind'].astype(str) == '1') & (tbl_df['functionCode'] == 'S'),
            tbl_df['price_lob'] * 0.7, tbl_df['orderPrice']))
    tbl_df['orderPrice'] = np.where(
        (tbl_df['orderKind'].astype(str) == 'U') & (tbl_df['functionCode'] == 'B'),
        tbl_df['price_lob'],
        np.where(
            (tbl_df['orderKind'].astype(str) == 'U') & (tbl_df['functionCode'] == 'S'),
            tbl_df['price_lob'], tbl_df['orderPrice']))

    fc = tbl_df["functionCode"].astype(str)
    ok = tbl_df["orderKind"].astype(str)
    o_is_buy = fc == "B"
    o_is_sell = fc == "S"

    # ====================================================================
    # 新增委托(add_order)：委托行且下一行不是成交（真正挂进盘口的被动委托）
    # ====================================================================
    add_buy = o_is_buy & (ok.shift(-1) != "T")
    add_sell = o_is_sell & (ok.shift(-1) != "T")

    # 时间分桶：TIME_BIN = ceil(time_sec / 300) * 300
    time_sec = time_to_sec(tbl_df["time"].to_numpy())
    tbl_df["TIME_BIN"] = (np.ceil(time_sec / cfg.BIN_SEC) * cfg.BIN_SEC).astype("int64")

    # mid = (bp1 + sp1) / 2
    tbl_df["mid"] = (tbl_df["bp1"].astype("float64") + tbl_df["sp1"].astype("float64")) / 2.0

    # ====================================================================
    # 关键写法：先把对方事件赋 NaN，再 groupby TIME_BIN 聚合
    # 买方价/量只在买 add_order 行有值，卖方同理；其余行为 NaN，不计入桶内 VWAP
    # ====================================================================
    op = tbl_df["orderPrice"].astype("float64")
    ov = tbl_df["orderVolume"].astype("float64")

    # 桶内 VWAP 分子分母：买方
    tbl_df["pv_B"] = (op * ov).where(add_buy, np.nan)
    tbl_df["v_B"] = ov.where(add_buy, np.nan)
    # 卖方
    tbl_df["pv_S"] = (op * ov).where(add_sell, np.nan)
    tbl_df["v_S"] = ov.where(add_sell, np.nan)

    # 按 TIME_BIN 聚合
    grp = tbl_df.groupby("TIME_BIN", sort=True)
    agg = grp.agg(
        pv_B=("pv_B", "sum"),
        v_B=("v_B", "sum"),
        pv_S=("pv_S", "sum"),
        v_S=("v_S", "sum"),
        mid_last=("mid", "last"),   # 桶末尾那一刻的 mid
    ).reset_index()

    # 桶内成交量加权平均委托价（分母为 0 的桶 → NaN）
    with np.errstate(invalid="ignore", divide="ignore"):
        wavg_price_B = agg["pv_B"] / agg["v_B"]
        wavg_price_S = agg["pv_S"] / agg["v_S"]

    # DISTANCE：买/卖加权挂单价相对 mid 的距离不平衡度
    dist_B = (wavg_price_B - agg["mid_last"]).abs()
    dist_S = (wavg_price_S - agg["mid_last"]).abs()
    agg["dis_out_BSimb"] = _imb(dist_B, dist_S)

    out = pd.DataFrame({
        "date": date,
        "code": code,
        "TIME_BIN": agg["TIME_BIN"].astype("int64"),
        "dis_out_BSimb": agg["dis_out_BSimb"].astype("float64"),
    })

    # ====================================================================
    # 拼接 LACOLS：按 TIME_BIN groupby .last()，取每个桶末尾的 LA 标签值
    # ====================================================================
    la_cols_exist = [c for c in cfg.LACOLS if c in tbl_df.columns]
    if la_cols_exist:
        la_last = tbl_df.groupby("TIME_BIN", sort=True)[la_cols_exist].last().reset_index()
        out = out.merge(la_last, on="TIME_BIN", how="left")

    return out


def _read_long_table(date: str, cfg: Config) -> pd.DataFrame:
    """读取沪深一体长表，在读取层(parquet filters)就只取连续竞价时段。"""
    time_filters = [
        [("time", ">=", cfg.AM_START), ("time", "<=", cfg.AM_END)],
        [("time", ">=", cfg.PM_START), ("time", "<=", cfg.PM_END)],
    ]
    frames = []
    for market in cfg.MARKETS:
        path = Path(cfg.RAW_DIR) / f"{market}_ordertranlob" / f"{date}.parquet"
        if not path.exists():
            continue
        df = pd.read_parquet(path, columns=cfg.USE_COLS, filters=time_filters)
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["code"] = df["code"].astype(str)
    df["time"] = df["time"].astype("int64")

    # ====================================================================
    # === schema 兼容层：新长表字段 → 旧因子代码使用的字段名 ===
    # ====================================================================
    price_cols = ["price", "price_lob",
                  "bp1", "bp2", "bp3", "bp4", "bp5",
                  "sp1", "sp2", "sp3", "sp4", "sp5"]
    for c in price_cols:
        if c in df.columns:
            v = df[c].astype("float64").to_numpy()
            v = np.where(np.isnan(v) | (v <= 0), -10000.0, v * 10000.0)
            df[c] = v.astype("int64")

    type_s = df["type"].astype(str)
    side_s = df["side"].astype(str).where(df["side"].notna(), "")
    is_trade = (type_s == "T").to_numpy()
    is_cxl = (type_s == "D").to_numpy()
    fc = np.where(is_cxl, "C", np.where(~is_trade, side_s.to_numpy(), ""))
    df["functionCode"] = fc
    df["orderKind"] = type_s.to_numpy()
    df["orderPrice"] = df["price"]
    df["orderVolume"] = df["volume"]
    df["bidOrder"] = df["buyorder"]
    df["askOrder"] = df["sellorder"]
    df["order"] = df["number"]

    return df


def _one_stock_worker(args):
    """进程池工作函数：解包参数后调用 _one_stock。"""
    date, code, sub_df, cfg = args
    return _one_stock(date, code, sub_df, cfg)


def build_one_day(date: str, cfg: Config) -> pd.DataFrame:
    """单日：读一体长表，对每只股票并行计算因子。"""
    table_df = _read_long_table(date, cfg)
    if table_df.empty:
        logger.warning("%s 无长表数据，跳过", date)
        return pd.DataFrame()

    groups = list(table_df.groupby("code", sort=False))
    logger.info("%s 股票数=%d，单日内并行 max_workers=%d", date, len(groups), cfg.MAX_WORKERS)

    frames = []
    max_workers = max(1, int(cfg.MAX_WORKERS))
    if max_workers == 1:
        for code, sub_df in tqdm(groups, desc=date):
            frame = _one_stock(date, str(code), sub_df, cfg)
            if frame is not None and not frame.empty:
                frames.append(frame)
    else:
        tasks = [(date, str(code), sub_df, cfg) for code, sub_df in groups]
        with ProcessPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(_one_stock_worker, t): t[1] for t in tasks}
            for fut in tqdm(as_completed(futures), total=len(futures), desc=date):
                code = futures[fut]
                try:
                    frame = fut.result()
                except Exception as exc:
                    logger.exception("%s %s 计算失败：%s", date, code, exc)
                    raise
                if frame is not None and not frame.empty:
                    frames.append(frame)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def process_day(date: str, cfg: Config) -> str:
    """处理单个交易日并保存；已存在则跳过(断点恢复)。"""
    by_date_dir = Path(cfg.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "")
    by_date_dir.mkdir(parents=True, exist_ok=True)
    out_path = by_date_dir / f"factor6_{date}.parquet"
    if out_path.exists():
        logger.info("skip %s（已存在）", date)
        return f"skip {date}"

    df = build_one_day(date, cfg)
    if df.empty:
        logger.warning("empty %s", date)
        return f"empty {date}"
    df.to_parquet(out_path, index=False)
    logger.info("ok %s rows=%d codes=%d -> %s", date, len(df), df["code"].nunique(), out_path)
    return f"ok {date} rows={len(df)} codes={df['code'].nunique()}"


def main():
    parser = argparse.ArgumentParser(
        description="DISTANCE 5min 因子（单日，股票级并行）")
    parser.add_argument("--date", type=str, default="20240430",
                        help="交易日 YYYYMMDD（只处理这一天）")
    parser.add_argument("--max-workers", type=int, default=100,
                        help="单日内对股票并行的进程数，默认 100")
    args = parser.parse_args()

    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")

    cfg = Config()
    cfg.MAX_WORKERS = args.max_workers
    logger.info("处理交易日 %s，股票级并行 max_workers=%d", args.date, cfg.MAX_WORKERS)
    process_day(args.date, cfg)


if __name__ == "__main__":
    import shutil, os, stat
    _src = Path(__file__).resolve()
    _dst = Path(Config.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "") / _src.name
    if not _dst.exists():
        _dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(_src, _dst)
        os.chmod(_dst, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    main()
