#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
factor4.py —— 价格另类抬升比例 + CxlCxl_prob（连续撤一档概率）。

基于 order+trans+lob 一体长表构造，严格复用 factor1/factor2/factor3 框架。

因子 6：价格另类抬升比例（cxl_alllevel_ratio）
---------------------------------------------
撤单导致一档价格移动 vs 主动成交导致价格移动，谁更"另类地"推动价格。
- cxl_alllevel_B：撤单行(f='C') 且 bp1 相对上一行发生变化（撤买导致买一价变动）
- cxl_alllevel_S：撤单行(f='C') 且 sp1 相对上一行发生变化（撤卖导致卖一价变动）
- acttrd_B / acttrd_S：主动买/卖委托（委托行且下一行是成交），复用 factor3 口径
  含义：撤买打压买一价 占 「撤买打压 + 主动卖砸盘」的比例（B 侧的价格下移由撤单贡献多少）
- cxl_alllevel_S_upratio = cum_ewm(tbl_df['cxl_alllevel_S']) / (cum_ewm(tbl_df['cxl_alllevel_S']) + cum_ewm(acttrd_B))
  含义：撤卖抬升卖一价 占 「撤卖抬升 + 主动买拉升」的比例（S 侧的价格上移由撤单贡献多少）
- cxl_alllevel_ratio_BSimb = _bsimb(B_downratio, S_upratio)
前缀 size / cnt 各做一套。

因子 7：CxlCxl_prob（连续撤一档概率）
-------------------------------------
刻画"撤一档"行为是否成簇连续出现（连续撤单试探/操纵）。
- cxl_atlevel1_B：f='C' 且 bp1==bp1.shift() 且 bv1!=bv1.shift()（一档价不变但一档量变 -> 撤的是一档上的量）
- cxl_atlevel1_S：f='C' 且 sp1==sp1.shift() 且 sv1!=sv1.shift()
- conti_cxl_level1_B：当前 cxl_atlevel1_B 前面 20 个 event 中也出现过 cxl_atlevel1_B 时记为连续：
    cnt_conti = 前面20个event中 cxl_atlevel1_B 个数 + 1（含自己）
    size_conti = 含自己在内前面20个event中 cxl_atlevel1_B 的 size 之和
- cxl_eff_B：f='C' 且 bidOrder>0 且 bv1~bv5 至少有一个相对上一行变化（有效撤买，确实改变了买盘五档）
- cxl_eff_S：f='C' 且 askOrder>0 且 sv1~sv5 至少有一个相对上一行变化
- cxt_atlevel1_B_prob1 = cum_ewm(conti_cxl_level1_B) / cum_ewm(cxl_atlevel1_B)
- cxt_atlevel1_B_prob2 = cum_ewm(conti_cxl_level1_B) / cum_ewm(cxl_eff_B)
- 输出：cxt_atlevel1_prob1_BSimb, cxt_atlevel1_prob2_BSimb（size/cnt 各一套）
"""

from __future__ import annotations

import argparse
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("hft.factor4")


class Config:
    # 一体长表目录（含 sz_ordertranlob / sh_ordertranlob 两个子目录）
    RAW_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/raw_long_table"
    MARKETS = ("sz", "sh")
    OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/factors"

    HL_LEVEL1 = 5000         # 基础 halflife
    MAX_WORKERS = 100

    # 连续撤一档的回看 event 数
    CXLCXL_LOOKBACK = 20

    # 连续竞价时段（含端点），HHMMSSmmm
    AM_START, AM_END = 93000000, 113000000
    PM_START, PM_END = 130000000, 145700000

    # 读长表只取需要的列，省内存
    LACOLS = ['LA10', 'LA3600', 'LA43200', 'LA60', 'LAEOD', 'LAEOD1', 'LAEOD2',
       'LAEOD5', 'LASVWAP1', 'LASVWAP2', 'LASVWAP5']
    # 因子6需要 bp1/sp1（一档价变化）；因子7需要 bv1-5/sv1-5（五档量变化）
    # 注：新长表 schema 与旧版差异较大，这里读入新字段，
    # 下方 _read_long_table 末尾会做兼容映射。
    USE_COLS = ["code", "time", "date", "type", "side",
                "volume", "sellorder", "buyorder",
                "price", "size", "seq_num", "number",
                "bp1", "sp1", "price_lob",
                "bv1", "bv2", "bv3", "bv4", "bv5",
                "sv1", "sv2", "sv3", "sv4", "sv5"] + LACOLS


def cumsum_minus_ewm(values: np.ndarray, halflife: float) -> np.ndarray:
    """cumsumfromopen(x) - cumsumfromopen(x).ewm(halflife).mean()。

    NaN 表示该事件不计入（cumsum 按 0 处理）。返回与 values 等长数组。
    """
    s = pd.Series(values, dtype="float64")
    cum = s.fillna(0.0).cumsum()
    ewm = cum.ewm(halflife=halflife, adjust=False, ignore_na=True).mean()
    return (cum - ewm).to_numpy()


def _ratio(a: pd.Series, b: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / b


def _bsimb(b: pd.Series, s: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b - s) / (b + s)


def _rolling_back_sum(mask: pd.Series, values: np.ndarray, lookback: int) -> np.ndarray:
    """对每个 mask 为 True 的行，统计「含自己在内、向前 lookback+1 个 event 窗口」内
    target 的累计值。

    用 cumsum 前缀和实现：result[i] = cumvals[i] - cumvals[i-lookback-1]
    （窗口 = [i-lookback, i]，共 lookback+1 个 event，含自己）。
    仅在 mask 行有值，其余 NaN。
    values 已是「target 行才有值、其余 0」的数组。
    """
    n = len(values)
    cumvals = np.cumsum(np.nan_to_num(values, nan=0.0))
    result = np.full(n, np.nan, dtype="float64")

    pos = np.where(mask.values)[0]
    if pos.size == 0:
        return result

    # 窗口起点的前一个位置 = i - lookback - 1，越界则取 -1（即从头累计）
    start_prev = pos - lookback - 1
    base = np.where(start_prev >= 0, cumvals[np.clip(start_prev, 0, n - 1)], 0.0)
    result[pos] = cumvals[pos] - base
    return result


def _one_stock(date: str, code: str, tbl_df: pd.DataFrame, cfg: Config) -> pd.DataFrame | None:
    """单股票：计算价格另类抬升比例 + 连续撤一档概率因子。"""
    if tbl_df.empty:
        return None

    tbl_df = tbl_df.sort_values(["time", "seq_num"]).reset_index(drop=True)
    out = tbl_df[["date", "code", "time", "seq_num"] + cfg.LACOLS].copy()

    # ====================================================================
    # 前置清洗：修正无效盘口价 + 为市价单/本方最优价单填充合理的 orderPrice
    # ====================================================================
    tbl_df['sp1'] = np.where(tbl_df['sp1'] <= 0, tbl_df['bp1'] * 0.7, tbl_df['sp1'])
    tbl_df['bp1'] = np.where(tbl_df['bp1'] > 5 * tbl_df['sp1'], tbl_df['sp1'] * 1.3, tbl_df['bp1'])
    tbl_df['bp1'] = np.where(tbl_df['bp1'] <= 0, tbl_df['sp1'], tbl_df['bp1'])
    tbl_df['orderPrice'] = np.where(
        (tbl_df['orderKind'].astype(str) == '1') & (tbl_df['functionCode'] == 'B'),
        tbl_df['price_lob'] * 1.3,
        np.where(
            (tbl_df['orderKind'].astype(str) == '1') & (tbl_df['functionCode'] == 'S'),
            tbl_df['price_lob'] * 0.7, tbl_df['orderPrice']))
    tbl_df['orderPrice'] = np.where(
        (tbl_df['orderKind'].astype(str) == 'U') & (tbl_df['functionCode'] == 'B'),
        tbl_df['price_lob'],
        np.where(
            (tbl_df['orderKind'].astype(str) == 'U') & (tbl_df['functionCode'] == 'S'),
            tbl_df['price_lob'], tbl_df['orderPrice']))

    fc = tbl_df["functionCode"].astype(str)
    ok = tbl_df["orderKind"].astype(str)
    o_is_buy = fc == "B"
    o_is_sell = fc == "S"
    is_cxl = fc == "C"

    # 主动买/卖委托：委托行且下一行是成交（复用 factor3 口径）
    acttrd_B = o_is_buy & (ok.shift(-1) == "T")
    acttrd_S = o_is_sell & (ok.shift(-1) == "T")

    def cum_ewm(col: str, hl: float) -> pd.Series:
        """对长表的某列做 cumsum-ewm。"""
        return pd.Series(cumsum_minus_ewm(tbl_df[col].to_numpy("float64"), hl),
                         index=tbl_df.index)

    # 撤单方向：撤买 bidOrder>0；撤卖 askOrder>0
    cxl_is_buy = is_cxl & (tbl_df["bidOrder"] > 0)
    cxl_is_sell = is_cxl & (tbl_df["askOrder"] > 0)

    # 盘口是 after-event 快照，before = shift(1)
    bp1_before = tbl_df["bp1"].shift(1)
    sp1_before = tbl_df["sp1"].shift(1)

    # ==========================================================================
    # 因子6：价格另类抬升比例（cxl_alllevel_ratio）
    # ==========================================================================
    # cxl_alllevel_B：撤买且 bp1 相对上一行发生变化（撤单导致买一价移动）
    tbl_df['cxl_alllevel_B'] = cxl_is_buy & (tbl_df["bp1"] != bp1_before)
    # cxl_alllevel_S：撤卖且 sp1 相对上一行发生变化（撤单导致卖一价移动）
    tbl_df['cxl_alllevel_S'] = cxl_is_sell & (tbl_df["sp1"] != sp1_before)

    # ---- cnt / size 标记（仅对应事件行有值，其余 NaN）----
    tbl_df["cnt_cxl_alllevel_B"] = tbl_df['cxl_alllevel_B'].astype("float64").where(tbl_df['cxl_alllevel_B'], np.nan)
    tbl_df["cnt_cxl_alllevel_S"] = tbl_df['cxl_alllevel_S'].astype("float64").where(tbl_df['cxl_alllevel_S'], np.nan)
    tbl_df["size_cxl_alllevel_B"] = tbl_df["size"].where(tbl_df['cxl_alllevel_B'], np.nan)
    tbl_df["size_cxl_alllevel_S"] = tbl_df["size"].where(tbl_df['cxl_alllevel_S'], np.nan)

    # acttrd 的 cnt / size（作为分母组成项）
    tbl_df["cnt_acttrd_B"] = acttrd_B.astype("float64").where(acttrd_B, np.nan)
    tbl_df["cnt_acttrd_S"] = acttrd_S.astype("float64").where(acttrd_S, np.nan)
    tbl_df["size_acttrd_B"] = tbl_df["size"].where(acttrd_B, np.nan)
    tbl_df["size_acttrd_S"] = tbl_df["size"].where(acttrd_S, np.nan)

    # cum_ewm
    for col in ["cnt_cxl_alllevel_B", "cnt_cxl_alllevel_S",
                "size_cxl_alllevel_B", "size_cxl_alllevel_S",
                "cnt_acttrd_B", "cnt_acttrd_S",
                "size_acttrd_B", "size_acttrd_S"]:
        tbl_df["f_" + col] = cum_ewm(col, 5000)

    for pref in ("cnt", "size"):
        b_down = _ratio(
            tbl_df[f"f_{pref}_cxl_alllevel_B"],
            tbl_df[f"f_{pref}_cxl_alllevel_B"] + tbl_df[f"f_{pref}_acttrd_S"])
        # S_upratio = tbl_df['cxl_alllevel_S'] / (tbl_df['cxl_alllevel_S'] + acttrd_B)
        s_up = _ratio(
            tbl_df[f"f_{pref}_cxl_alllevel_S"],
            tbl_df[f"f_{pref}_cxl_alllevel_S"] + tbl_df[f"f_{pref}_acttrd_B"])
        out[f"{pref}_cxl_alllevel_ratio_BSimb"] = _bsimb(b_down, s_up)
        out[f"{pref}_cxl_alllevel_BSimb"] = _bsimb(tbl_df[f"f_{pref}_cxl_alllevel_B"],tbl_df[f"f_{pref}_cxl_alllevel_S"])
    # ==========================================================================
    # 因子7：CxlCxl_prob（连续撤一档概率）
    # ==========================================================================
    bv1_before = tbl_df["bv1"].shift(1)
    sv1_before = tbl_df["sv1"].shift(1)

    # cxl_atlevel1_B：撤买 且 bp1 不变 且 bv1 变化（撤的是一档上的量，价不变量减）
    cxl_atlevel1_B = cxl_is_buy & (tbl_df["bp1"] == bp1_before) & (tbl_df["bv1"] != bv1_before)
    cxl_atlevel1_S = cxl_is_sell & (tbl_df["sp1"] == sp1_before) & (tbl_df["sv1"] != sv1_before)

    # cxl_eff_B：撤买 且 bv1~bv5 至少有一个相对上一行变化（有效撤买，确实改变买盘五档）
    bv_cols = ["bv1", "bv2", "bv3", "bv4", "bv5"]
    sv_cols = ["sv1", "sv2", "sv3", "sv4", "sv5"]
    bv_changed = np.zeros(len(tbl_df), dtype=bool)
    for c in bv_cols:
        bv_changed |= (tbl_df[c] != tbl_df[c].shift(1)).to_numpy()
    sv_changed = np.zeros(len(tbl_df), dtype=bool)
    for c in sv_cols:
        sv_changed |= (tbl_df[c] != tbl_df[c].shift(1)).to_numpy()
    cxl_eff_B = cxl_is_buy & pd.Series(bv_changed, index=tbl_df.index)
    cxl_eff_S = cxl_is_sell & pd.Series(sv_changed, index=tbl_df.index)

    lb = cfg.CXLCXL_LOOKBACK

    # ---- 连续撤一档统计（含自己在内、向前 lb+1 窗口）----
    # cnt：窗口内 cxl_atlevel1 的个数（含自己）；只在 cxl_atlevel1 行有值
    cnt_atlvl1_B_vals = cxl_atlevel1_B.astype("float64").to_numpy()
    cnt_atlvl1_S_vals = cxl_atlevel1_S.astype("float64").to_numpy()
    size_atlvl1_B_vals = tbl_df["size"].where(cxl_atlevel1_B, np.nan).to_numpy()
    size_atlvl1_S_vals = tbl_df["size"].where(cxl_atlevel1_S, np.nan).to_numpy()

    tbl_df["cnt_conti_cxl_level1_B"] = _rolling_back_sum(cxl_atlevel1_B, cnt_atlvl1_B_vals, lb)
    tbl_df["cnt_conti_cxl_level1_S"] = _rolling_back_sum(cxl_atlevel1_S, cnt_atlvl1_S_vals, lb)
    tbl_df["size_conti_cxl_level1_B"] = _rolling_back_sum(cxl_atlevel1_B, size_atlvl1_B_vals, lb)
    tbl_df["size_conti_cxl_level1_S"] = _rolling_back_sum(cxl_atlevel1_S, size_atlvl1_S_vals, lb)

    # cxl_atlevel1 本身的 cnt/size（作为分母 prob1）
    tbl_df["cnt_cxl_atlevel1_B"] = cxl_atlevel1_B.astype("float64").where(cxl_atlevel1_B, np.nan)
    tbl_df["cnt_cxl_atlevel1_S"] = cxl_atlevel1_S.astype("float64").where(cxl_atlevel1_S, np.nan)
    tbl_df["size_cxl_atlevel1_B"] = tbl_df["size"].where(cxl_atlevel1_B, np.nan)
    tbl_df["size_cxl_atlevel1_S"] = tbl_df["size"].where(cxl_atlevel1_S, np.nan)

    # cxl_eff 的 cnt/size（作为分母 prob2）
    tbl_df["cnt_cxl_eff_B"] = cxl_eff_B.astype("float64").where(cxl_eff_B, np.nan)
    tbl_df["cnt_cxl_eff_S"] = cxl_eff_S.astype("float64").where(cxl_eff_S, np.nan)
    tbl_df["size_cxl_eff_B"] = tbl_df["size"].where(cxl_eff_B, np.nan)
    tbl_df["size_cxl_eff_S"] = tbl_df["size"].where(cxl_eff_S, np.nan)

    # cum_ewm
    for col in ["cnt_conti_cxl_level1_B", "cnt_conti_cxl_level1_S",
                "size_conti_cxl_level1_B", "size_conti_cxl_level1_S",
                "cnt_cxl_atlevel1_B", "cnt_cxl_atlevel1_S",
                "size_cxl_atlevel1_B", "size_cxl_atlevel1_S",
                "cnt_cxl_eff_B", "cnt_cxl_eff_S",
                "size_cxl_eff_B", "size_cxl_eff_S"]:
        tbl_df["f_" + col] = cum_ewm(col, cfg.HL_LEVEL1)

    for pref in ("cnt", "size"):
        # prob1 = conti / cxl_atlevel1
        b_prob1 = _ratio(tbl_df[f"f_{pref}_conti_cxl_level1_B"],
                         tbl_df[f"f_{pref}_cxl_atlevel1_B"])
        s_prob1 = _ratio(tbl_df[f"f_{pref}_conti_cxl_level1_S"],
                         tbl_df[f"f_{pref}_cxl_atlevel1_S"])
        out[f"{pref}_cxt_atlevel1_prob1_BSimb"] = _bsimb(b_prob1, s_prob1)

        # prob2 = conti / cxl_eff
        b_prob2 = _ratio(tbl_df[f"f_{pref}_conti_cxl_level1_B"],
                         tbl_df[f"f_{pref}_cxl_eff_B"])
        s_prob2 = _ratio(tbl_df[f"f_{pref}_conti_cxl_level1_S"],
                         tbl_df[f"f_{pref}_cxl_eff_S"])
        out[f"{pref}_cxt_atlevel1_prob2_BSimb"] = _bsimb(b_prob2, s_prob2)

    return out[::100]


def _read_long_table(date: str, cfg: Config) -> pd.DataFrame:
    """读取沪深一体长表，在读取层(parquet filters)就只取连续竞价时段。"""
    time_filters = [
        [("time", ">=", cfg.AM_START), ("time", "<=", cfg.AM_END)],
        [("time", ">=", cfg.PM_START), ("time", "<=", cfg.PM_END)],
    ]
    frames = []
    for market in cfg.MARKETS:
        path = Path(cfg.RAW_DIR) / f"{market}_ordertranlob" / f"{date}.parquet"
        if not path.exists():
            continue
        df = pd.read_parquet(path, columns=cfg.USE_COLS, filters=time_filters)
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["code"] = df["code"].astype(str)
    df["time"] = df["time"].astype("int64")

    # ====================================================================
    # === schema 兼容层：新长表字段 → 旧因子代码使用的字段名 ===
    # ====================================================================
    price_cols = ["price", "price_lob",
                  "bp1", "bp2", "bp3", "bp4", "bp5",
                  "sp1", "sp2", "sp3", "sp4", "sp5"]
    for c in price_cols:
        if c in df.columns:
            v = df[c].astype("float64").to_numpy()
            v = np.where(np.isnan(v) | (v <= 0), -10000.0, v * 10000.0)
            df[c] = v.astype("int64")

    type_s = df["type"].astype(str)
    side_s = df["side"].astype(str).where(df["side"].notna(), "")
    is_trade = (type_s == "T").to_numpy()
    is_cxl = (type_s == "D").to_numpy()
    fc = np.where(is_cxl, "C", np.where(~is_trade, side_s.to_numpy(), ""))
    df["functionCode"] = fc
    df["orderKind"] = type_s.to_numpy()
    df["orderPrice"] = df["price"]
    df["orderVolume"] = df["volume"]
    df["bidOrder"] = df["buyorder"]
    df["askOrder"] = df["sellorder"]
    df["order"] = df["number"]

    return df


def _one_stock_worker(args):
    """进程池工作函数：解包参数后调用 _one_stock。"""
    date, code, sub_df, cfg = args
    return _one_stock(date, code, sub_df, cfg)


def build_one_day(date: str, cfg: Config) -> pd.DataFrame:
    """单日：读一体长表，对每只股票并行计算因子。"""
    table_df = _read_long_table(date, cfg)
    if table_df.empty:
        logger.warning("%s 无长表数据，跳过", date)
        return pd.DataFrame()

    groups = list(table_df.groupby("code", sort=False))
    logger.info("%s 股票数=%d，单日内并行 max_workers=%d", date, len(groups), cfg.MAX_WORKERS)

    frames = []
    max_workers = max(1, int(cfg.MAX_WORKERS))
    if max_workers == 1:
        for code, sub_df in tqdm(groups, desc=date):
            frame = _one_stock(date, str(code), sub_df, cfg)
            if frame is not None and not frame.empty:
                frames.append(frame)
    else:
        tasks = [(date, str(code), sub_df, cfg) for code, sub_df in groups]
        with ProcessPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(_one_stock_worker, t): t[1] for t in tasks}
            for fut in tqdm(as_completed(futures), total=len(futures), desc=date):
                code = futures[fut]
                try:
                    frame = fut.result()
                except Exception as exc:
                    logger.exception("%s %s 计算失败：%s", date, code, exc)
                    raise
                if frame is not None and not frame.empty:
                    frames.append(frame)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def process_day(date: str, cfg: Config) -> str:
    """处理单个交易日并保存；已存在则跳过(断点恢复)。"""
    by_date_dir = Path(cfg.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "")
    by_date_dir.mkdir(parents=True, exist_ok=True)
    out_path = by_date_dir / f"factor4_{date}.parquet"
    if out_path.exists():
        logger.info("skip %s（已存在）", date)
        return f"skip {date}"

    df = build_one_day(date, cfg)
    if df.empty:
        logger.warning("empty %s", date)
        return f"empty {date}"
    df.to_parquet(out_path, index=False)
    logger.info("ok %s rows=%d codes=%d -> %s", date, len(df), df["code"].nunique(), out_path)
    return f"ok {date} rows={len(df)} codes={df['code'].nunique()}"


def main():
    parser = argparse.ArgumentParser(
        description="价格另类抬升比例 + 连续撤一档概率因子（单日，股票级并行）")
    parser.add_argument("--date", type=str, default="20250822",
                        help="交易日 YYYYMMDD（只处理这一天）")
    parser.add_argument("--max-workers", type=int, default=100,
                        help="单日内对股票并行的进程数，默认 100")
    args = parser.parse_args()

    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")

    cfg = Config()
    cfg.MAX_WORKERS = args.max_workers
    logger.info("处理交易日 %s，股票级并行 max_workers=%d", args.date, cfg.MAX_WORKERS)
    process_day(args.date, cfg)


if __name__ == "__main__":
    import shutil, os, stat
    _src = Path(__file__).resolve()
    _dst = Path(Config.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "") / _src.name
    if not _dst.exists():
        _dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(_src, _dst)
        os.chmod(_dst, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    main()
