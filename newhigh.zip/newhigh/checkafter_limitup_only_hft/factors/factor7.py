#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
factor7.py —— Cxl_accelerate（撤一/二档撤单加速度）+ new_order_wavg_dis（新单时间加权价距）。

数据源
------
一体长表：/home/datamake119/data1/user118/hft/raw_long_table/{sz,sh}_ordertranlob/<date>.parquet
  与 factor1/factor5 相同。每行一个事件（委托 / 成交 / 撤单），带当时五档盘口。
  读取层做谓词下推只取连续竞价时段；读取末尾做 schema 兼容层，把新字段映射回旧因子代码使用的
  字段名（functionCode / orderKind / orderPrice / orderVolume / askOrder / bidOrder / order），
  价格列统一 *10000 转回旧口径。

因子 11：Cxl_accelarate（撤单加速度）
-------------------------------------
分别在买卖订单簿上找到「在某挡位撤单」的事件，用同一序列的「短 halflife / 长 halflife」窗口和之比
刻画撤单强度的加速度（短期相对长期更强 -> 加速）。

撤一档事件（参考 factor4）：
  cxl_atlevel1_B = 撤买 且 bp1==bp1.shift() 且 bv1!=bv1.shift()（一档价不变、一档量变 -> 撤一档上的量）
  cxl_atlevel1_S = 撤卖 且 sp1==sp1.shift() 且 sv1!=sv1.shift()

撤二档事件（两种判定取并集）：
  1) bp2==bp2.shift() 且 bv2!=bv2.shift()  -> 撤单减少了第二挡位的原有量
  2) bp1==bp1.shift() 且 bp2!=bp2.shift()  -> 撤单让第二挡位消失了（一档未变，二档价变了）
  S 侧对称（sp2/sv2/sp1）。

撤一二档：atlevel12 = atlevel1 ∪ atlevel2。

因子（对 lvl ∈ {atlevel1, atlevel2, atlevel12}，unit ∈ {cnt, size}）：
  cxl_{lvl}_acc_BSimb       —— cnt 口径：每个撤单事件计 1（笔数）
  cxl_{lvl}_size_acc_BSimb  —— size 口径：每个撤单事件计其撤单量 size（成交量/撤单量）
  公式均为 _imb(
      _ratio(cum_ewm(cxl_{lvl}_{unit}_B, short), cum_ewm(cxl_{lvl}_{unit}_B, long)),
      _ratio(cum_ewm(cxl_{lvl}_{unit}_S, short), cum_ewm(cxl_{lvl}_{unit}_S, long)))
  short = HL_SHORT(4000)，long = HL_LONG(40000)。

因子 12：new_order_wavg_dis（新单时间加权价距）
----------------------------------------------
对「被动新增挂单」按其相对中价的价格、用其（连续）时间做加权平均，刻画新单挂单价距的趋势。
  time 为当日秒数，且下午时段减去午休 1.5*3600s（拼成连续交易时间）。
  add_lessprxstd 鉴别（B 侧）：side=='B' & 是新增委托 & 下一行不是成交 &
      orderPrice > mid - prxstd(rolling_window=5000)*1.2
  S 侧对称：side=='S' & 是新增委托 & 下一行不是成交 & orderPrice < mid + prxstd*1.2
  （type=='A' 为沪市限价新单；这里推广为「委托行且下一笔非成交」的被动新增单，兼容沪深两市。）

  wavgtime_pricedis_add_lessprxstd_B = cum_ewm(orderPrice*time) / cum_ewm(time) / mid （仅 B 侧合格事件）
  S 侧同理。
  输出：wavgtime_pricedis_add_level15_BSimb = _bsimb(B, S)。

因子 13：反映系数（reaction coefficient）
----------------------------------------
刻画主动成交后中价的「反映」幅度——主动买/卖发生后未来若干 event 内 mid 的涨跌幅。
  acttrd_B = 主动买委托（委托行 functionCode=='B' 且下一行是成交 orderKind.shift(-1)=='T'）。
  acttrd_S 对称（functionCode=='S'）。
  对每个 acttrd_B 事件（位于第 i 行），计算其后 REACT_LOOKBACK(=30) 个 event 的 mid 涨幅：
      pct = mid[i+30] / mid[i] - 1
  该值「显示在第 i+30 行」（即 acttrd_B 之后 30 个 event 的那一行）。acttrd_S 同理。
  输出：pct_acttrd_BSimb = _imb(cum_ewm(pct_acttrd_B), cum_ewm(pct_acttrd_S))。

对齐口径
--------
- 只保留连续竞价时段：time ∈ [93000000,113000000] ∪ [130000000,145700000]。
- 按 code 分组、组内按 (time,seq_num) 升序做 cumsum-ewm。
- 输出行与该日长表（时段过滤后）一致，最后 [::100] 抽稀。

输出
----
/home/datamake119/data1/user118/hft/factors/factor7/factor7_<date>.parquet，
列 = (date,code,time,seq_num)+LACOLS+因子。
"""

from __future__ import annotations

import argparse
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("hft.factor7")


class Config:
    # 一体长表目录（含 sz_ordertranlob / sh_ordertranlob 两个子目录）
    RAW_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/raw_long_table"
    MARKETS = ("sz", "sh")
    OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/factors"

    # 因子11：撤单加速度的短/长 halflife
    HL_SHORT = 100
    HL_LONG = 5000
    # 因子12：时间加权价距的 cum_ewm halflife
    HL_WAVG = 900

    # 因子12：prxstd 计算
    PRX_ROLL_WINDOW = 1500     # price_lob rolling std 窗口
    PRX_STD_FILL = 200         # rolling std 无效时的填充（与 factor5 一致）

    # 因子13：反映系数
    REACT_LOOKBACK = 75        # 主动成交后向前看的 event 数
    HL_REACT = 1200            # 反映系数 cum_ewm 的 halflife

    MAX_WORKERS = 40

    # 连续竞价时段（含端点），HHMMSSmmm
    AM_START, AM_END = 93000000, 113000000
    PM_START, PM_END = 130000000, 145700000

    # 读长表只取需要的列，省内存
    LACOLS = ['LA10', 'LA3600', 'LA43200', 'LA60', 'LAEOD', 'LAEOD1', 'LAEOD2',
              'LAEOD5', 'LASVWAP1', 'LASVWAP2', 'LASVWAP5']
    USE_COLS = ["code", "time", "date", "type", "side",
                "volume", "sellorder", "buyorder", "number",
                "price", "size", "seq_num", "price_lob",
                "bp1", "bp2", "bv1", "bv2",
                "sp1", "sp2", "sv1", "sv2"] + LACOLS


def time_to_sec(t: np.ndarray) -> np.ndarray:
    """逐笔 time(HHMMSSmmm) -> 当日秒数(float)。"""
    t = t.astype("int64")
    ms = t % 1000
    rest = t // 1000
    s = rest % 100
    rest = rest // 100
    m = rest % 100
    h = rest // 100
    return (h * 3600 + m * 60 + s + ms / 1000.0).astype("float64")


def cumsum_minus_ewm(values: np.ndarray, halflife: float) -> np.ndarray:
    """cumsumfromopen(x) - cumsumfromopen(x).ewm(halflife).mean()。

    NaN 表示该事件不计入（cumsum 按 0 处理）。返回与 values 等长数组。
    """
    s = pd.Series(values, dtype="float64")
    cum = s.fillna(0.0).cumsum()
    ewm = cum.ewm(halflife=halflife, adjust=False, ignore_na=True).mean()
    return (cum - ewm).to_numpy()


def _ratio(a: pd.Series, b: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / b


def _imb(b: pd.Series, s: pd.Series) -> pd.Series:
    """买卖不平衡 (b - s) / (b + s)。"""
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b - s) / (b + s)

def _imb2(b: pd.Series, s: pd.Series) -> pd.Series:
    """买卖不平衡 (b + s) / (b - s)。"""
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b + s) / (b - s)

# 兼容别名
_bsimb = _imb


def _one_stock(date: str, code: str, tbl_df: pd.DataFrame, cfg: Config) -> pd.DataFrame | None:
    """单股票：构造撤单加速度 + 新单时间加权价距因子。"""
    if tbl_df.empty:
        return None

    # tbl_df = tbl_df.sort_values(["time", "seq_num"]).reset_index(drop=True)
    out = tbl_df[["date", "code", "time", "seq_num"] + cfg.LACOLS].copy()

    fc = tbl_df["functionCode"].astype(str)
    ok = tbl_df["orderKind"].astype(str)
    o_is_buy = fc == "B"
    o_is_sell = fc == "S"
    is_cxl = fc == "C"

    def cum_ewm(col: str, hl: float) -> pd.Series:
        """对长表的某列做 cumsum-ewm。"""
        return pd.Series(cumsum_minus_ewm(tbl_df[col].to_numpy("float64"), hl),
                         index=tbl_df.index)

    # ==========================================================================
    # 因子 11：Cxl_accelarate（撤一/二档撤单加速度）
    # ==========================================================================
    # 撤单方向：撤买 bidOrder>0；撤卖 askOrder>0
    cxl_is_buy = is_cxl & (tbl_df["bidOrder"] > 0)
    cxl_is_sell = is_cxl & (tbl_df["askOrder"] > 0)

    # 盘口为 after-event 快照，before = shift(1)
    bp1_b = tbl_df["bp1"].shift(1)
    bp2_b = tbl_df["bp2"].shift(1)
    bv1_b = tbl_df["bv1"].shift(1)
    bv2_b = tbl_df["bv2"].shift(1)
    sp1_b = tbl_df["sp1"].shift(1)
    sp2_b = tbl_df["sp2"].shift(1)
    sv1_b = tbl_df["sv1"].shift(1)
    sv2_b = tbl_df["sv2"].shift(1)

    # ---- 撤一档：一档价不变、一档量变 ----
    cxl_atlevel1_B = cxl_is_buy & (((tbl_df["bp1"] == bp1_b) & (tbl_df["bv1"] != bv1_b))  | (tbl_df["bp1"] != bp1_b) )
    cxl_atlevel1_S = cxl_is_sell & (((tbl_df["sp1"] == sp1_b) & (tbl_df["sv1"] != sv1_b)) | (tbl_df["sp1"] != sp1_b) )

    # ---- 撤二档：两种判定取并集 ----
    # 1) bp2 不变、bv2 变 -> 撤单减少了第二挡位原有量
    # 2) bp1 不变、bp2 变 -> 撤单让第二挡位消失了
    cxl_atlevel2_B = cxl_is_buy & (
        ((tbl_df["bp2"] == bp2_b) & (tbl_df["bv2"] != bv2_b)) |
        ((tbl_df["bp1"] == bp1_b) & (tbl_df["bp2"] != bp2_b)))
    cxl_atlevel2_S = cxl_is_sell & (
        ((tbl_df["sp2"] == sp2_b) & (tbl_df["sv2"] != sv2_b)) |
        ((tbl_df["sp1"] == sp1_b) & (tbl_df["sp2"] != sp2_b)))

    # ---- 撤一二档：并集 ----
    cxl_atlevel12_B = cxl_atlevel1_B | cxl_atlevel2_B
    cxl_atlevel12_S = cxl_atlevel1_S | cxl_atlevel2_S

    # 撤单量（撤单行 size 即撤单量）
    cxl_size = tbl_df["size"].astype("float64")

    # 各档位标记（cnt 口径=1；size 口径=撤单量 size；仅对应事件行有值，其余 NaN）
    level_masks = {
        "atlevel1": (cxl_atlevel1_B, cxl_atlevel1_S),
        "atlevel2": (cxl_atlevel2_B, cxl_atlevel2_S),
        "atlevel12": (cxl_atlevel12_B, cxl_atlevel12_S),
    }
    for lvl, (mB, mS) in level_masks.items():
        # cnt 口径：每个撤单事件计 1
        tbl_df[f"cxl_{lvl}_cnt_B"] = mB.astype("float64").where(mB, np.nan)
        tbl_df[f"cxl_{lvl}_cnt_S"] = mS.astype("float64").where(mS, np.nan)
        # size 口径：每个撤单事件计其撤单量 size
        tbl_df[f"cxl_{lvl}_size_B"] = cxl_size.where(mB, np.nan)
        tbl_df[f"cxl_{lvl}_size_S"] = cxl_size.where(mS, np.nan)

        for unit, suffix in [("cnt", ""), ("size", "_size")]:
            b_short = cum_ewm(f"cxl_{lvl}_{unit}_B", cfg.HL_SHORT)
            b_long = cum_ewm(f"cxl_{lvl}_{unit}_B", cfg.HL_LONG)
            s_short = cum_ewm(f"cxl_{lvl}_{unit}_S", cfg.HL_SHORT)
            s_long = cum_ewm(f"cxl_{lvl}_{unit}_S", cfg.HL_LONG)

            # cnt 口径沿用原名 cxl_{lvl}_acc_BSimb；size 口径为 cxl_{lvl}_size_acc_BSimb
            out[f"cxl_{lvl}{suffix}_acc_BSimb"] = _imb(_ratio(b_short, b_long),
                                                       _ratio(s_short, s_long))
            out[f"cxl_{lvl}{suffix}_acc_BSimb_long"] = _imb(b_long,s_long)
            out[f"cxl_{lvl}{suffix}_acc_BSimb_short"] = _imb(b_short,s_short)

    # ==========================================================================
    # 因子 12：new_order_wavg_dis（新单时间加权价距）
    # ==========================================================================
    
    tbl_df['BP01'] = np.where(tbl_df['bp1']>tbl_df['price_lob'], tbl_df['price_lob'], tbl_df['bp1'])
    tbl_df['SP01'] = np.where(tbl_df['sp1']<tbl_df['price_lob'], tbl_df['price_lob'], tbl_df['sp1'])

    # ==========================================================================
    # price_nocross: BPnx1 / SPnx1
    # ==========================================================================
    # 对于 functionCode=='B'/'S' 且 type.shift(-1)=='T' 的条目（主动成交委托）：
    #   BPnx1 = 其后最后一个连续 T 的 bp1
    #   SPnx1 = 其后最后一个连续 T 的 sp1
    # 如果后面只有一个 T 则就为该 T 行的 bp1/sp1
    # 对于其他条目：BPnx1 = BP01, SPnx1 = SP01
    next_is_trade = ok.shift(-1) == "T"
    n = len(tbl_df)
    is_acttrd = (o_is_buy | o_is_sell) & next_is_trade
    ok_arr = ok.to_numpy()
    is_T = (ok_arr == "T")
    bp1_arr = tbl_df["bp1"].to_numpy("float64")
    sp1_arr = tbl_df["sp1"].to_numpy("float64")

    # 找到每个 T 所在连续 T 段的末尾索引（fully vectorized）
    is_t_run_end = np.zeros(n, dtype=bool)
    is_t_run_end[:-1] = is_T[:-1] & ~is_T[1:]
    if is_T[-1]:
        is_t_run_end[-1] = True
    t_end_positions = np.where(is_t_run_end)[0]

    t_positions = np.where(is_T)[0]
    run_end_map = np.full(n, -1, dtype="int64")
    if len(t_positions) > 0 and len(t_end_positions) > 0:
        idx = np.searchsorted(t_end_positions, t_positions, side="left")
        run_end_map[t_positions] = t_end_positions[idx]

    # 默认 BPnx1/SPnx1 = BP01/SP01
    BPnx1 = tbl_df["BP01"].to_numpy("float64").copy()
    SPnx1 = tbl_df["SP01"].to_numpy("float64").copy()

    # 对主动成交委托行：取其后连续 T 段末尾的 bp1/sp1
    acttrd_pos = np.where(is_acttrd.to_numpy())[0]
    valid = acttrd_pos[acttrd_pos + 1 < n]
    last_t = run_end_map[valid + 1]
    good = last_t >= 0
    BPnx1[valid[good]] = bp1_arr[last_t[good]]
    SPnx1[valid[good]] = sp1_arr[last_t[good]]

    tbl_df["BPnx1"] = BPnx1
    tbl_df["SPnx1"] = SPnx1




    mid = tbl_df.eval("(BPnx1+SPnx1) / 2") 

    prxstd = tbl_df["price_lob"].astype("float64").rolling(
        window=cfg.PRX_ROLL_WINDOW, min_periods=500).std()
    prxstd = prxstd.fillna(cfg.PRX_STD_FILL) + 100

    # 连续交易时间（秒）：下午减去午休 1.5*3600s，拼成连续时间轴
    sec = time_to_sec(tbl_df["time"].to_numpy("int64"))
    is_pm = (tbl_df["time"].to_numpy("int64") >= cfg.PM_START)
    time_cont = pd.Series(sec - np.where(is_pm, 1.5 * 3600.0, 0.0), index=tbl_df.index)

    order_price = tbl_df["orderPrice"].astype("float64")
    next_is_trade = ok.shift(-1) == "T"

    # 被动新增单：委托行(fc∈{B,S}) 且下一笔非成交（被动挂单）
    add_lessprxstd_B = o_is_buy & (~next_is_trade) & (order_price > mid - prxstd * 1.2)
    add_lessprxstd_S = o_is_sell & (~next_is_trade) & (order_price < mid + prxstd * 1.2)

    # 时间加权价：分子 = orderPrice*time，分母 = time（仅合格事件有值）
    tbl_df["pt_add_B"] = (order_price * time_cont).where(add_lessprxstd_B, np.nan)
    tbl_df["pt_add_S"] = (order_price * time_cont).where(add_lessprxstd_S, np.nan)
    tbl_df["t_add_B"] = time_cont.where(add_lessprxstd_B, np.nan)
    tbl_df["t_add_S"] = time_cont.where(add_lessprxstd_S, np.nan)

    wavg_B = _ratio(cum_ewm("pt_add_B", cfg.HL_WAVG),
                    cum_ewm("t_add_B", cfg.HL_WAVG))
    wavg_S = _ratio(cum_ewm("pt_add_S", cfg.HL_WAVG),
                    cum_ewm("t_add_S", cfg.HL_WAVG))
    wavgtime_pricedis_add_lessprxstd_B = _ratio(mid, wavg_B)
    wavgtime_pricedis_add_lessprxstd_S = _ratio(wavg_S, mid)

    out["wavgtime_pricedis_add_level15_BSimb"] = _bsimb(
        wavgtime_pricedis_add_lessprxstd_B,
        wavgtime_pricedis_add_lessprxstd_S)

    # out["wavgtime_pricedis_add_level15_BSimb2"] = _imb2(
    #     wavgtime_pricedis_add_lessprxstd_B,
    #     wavgtime_pricedis_add_lessprxstd_S)

    # ==========================================================================
    # 因子 13：反映系数（reaction coefficient）
    # ==========================================================================
    # 主动买/卖委托：委托行且下一行是成交（与 factor3/factor4 acttrd 口径一致）
    acttrd_B = o_is_buy & next_is_trade
    acttrd_S = o_is_sell & next_is_trade

    # mid 序列（price_lob），按位置取 i 与 i+REACT
    mid_arr = mid.to_numpy("float64")
    n = len(mid_arr)
    react = cfg.REACT_LOOKBACK

    def _react_pct(mask: pd.Series) -> np.ndarray:
        """对每个 mask 事件 i，计算 mid[i+react]/mid[i]-1，并把值放在第 i+react 行。"""
        vals = np.full(n, np.nan, dtype="float64")
        pos = np.where(mask.to_numpy())[0]
        pos = pos[pos + react < n]
        with np.errstate(invalid="ignore", divide="ignore"):
            pct = mid_arr[pos + react] / mid_arr[pos]
        vals[pos + react] = pct
        return vals

    tbl_df["pct_acttrd_B"] = _react_pct(acttrd_B)
    tbl_df["pct_acttrd_S"] = _react_pct(acttrd_S)

    out["pct_acttrd_BSimb"] = _imb(cum_ewm("pct_acttrd_B", cfg.HL_REACT),
                                   cum_ewm("pct_acttrd_S", cfg.HL_REACT))
    out["pct_acttrd_BSimb2"] = _imb2(cum_ewm("pct_acttrd_B", cfg.HL_REACT),
                                     cum_ewm("pct_acttrd_S", cfg.HL_REACT))



    return out[::100]


def _read_long_table(date: str, cfg: Config) -> pd.DataFrame:
    """读取沪深一体长表，在读取层(parquet filters)就只取连续竞价时段。"""
    time_filters = [
        [("time", ">=", cfg.AM_START), ("time", "<=", cfg.AM_END)],
        [("time", ">=", cfg.PM_START), ("time", "<=", cfg.PM_END)],
    ]
    frames = []
    for market in cfg.MARKETS:
        path = Path(cfg.RAW_DIR) / f"{market}_ordertranlob" / f"{date}.parquet"
        if not path.exists():
            continue
        df = pd.read_parquet(path, columns=cfg.USE_COLS, filters=time_filters)
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["code"] = df["code"].astype(str)
    df["time"] = df["time"].astype("int64")

    # ====================================================================
    # === schema 兼容层：新长表字段 → 旧因子代码使用的字段名 ===
    # 见 factor1/factor5 说明。价格列统一 *10000 转回旧口径(无效=−10000)。
    # ====================================================================
    price_cols = ["price", "price_lob",
                  "bp1", "bp2", "bp3", "bp4", "bp5",
                  "sp1", "sp2", "sp3", "sp4", "sp5"]
    for c in price_cols:
        if c in df.columns:
            v = df[c].astype("float64").to_numpy()
            v = np.where(np.isnan(v) | (v <= 0), -10000.0, v * 10000.0)
            df[c] = v.astype("int64")

    type_s = df["type"].astype(str)
    side_s = df["side"].astype(str).where(df["side"].notna(), "")
    is_trade = (type_s == "T").to_numpy()
    is_cxl = (type_s == "D").to_numpy()
    fc = np.where(is_cxl, "C", np.where(~is_trade, side_s.to_numpy(), ""))
    df["functionCode"] = fc
    df["orderKind"] = type_s.to_numpy()
    df["orderPrice"] = df["price"]
    df["orderVolume"] = df["volume"]
    df["bidOrder"] = df["buyorder"]
    df["askOrder"] = df["sellorder"]
    df["order"] = df["number"]

    return df


def _one_stock_worker(args):
    """进程池工作函数：解包参数后调用 _one_stock。"""
    date, code, sub_df, cfg = args
    return _one_stock(date, code, sub_df, cfg)


def build_one_day(date: str, cfg: Config) -> pd.DataFrame:
    """单日：读一体长表，对每只股票并行计算因子。"""
    table_df = _read_long_table(date, cfg)
    if table_df.empty:
        logger.warning("%s 无长表数据，跳过", date)
        return pd.DataFrame()

    groups = list(table_df.groupby("code", sort=False))
    logger.info("%s 股票数=%d，单日内并行 max_workers=%d", date, len(groups), cfg.MAX_WORKERS)

    frames = []
    max_workers = max(1, int(cfg.MAX_WORKERS))
    if max_workers == 1:
        for code, sub_df in tqdm(groups, desc=date):
            frame = _one_stock(date, str(code), sub_df, cfg)
            if frame is not None and not frame.empty:
                frames.append(frame)
    else:
        tasks = [(date, str(code), sub_df, cfg) for code, sub_df in groups]
        with ProcessPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(_one_stock_worker, t): t[1] for t in tasks}
            for fut in tqdm(as_completed(futures), total=len(futures), desc=date):
                code = futures[fut]
                try:
                    frame = fut.result()
                except Exception as exc:
                    logger.exception("%s %s 计算失败：%s", date, code, exc)
                    raise
                if frame is not None and not frame.empty:
                    frames.append(frame)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def process_day(date: str, cfg: Config) -> str:
    """处理单个交易日并保存；已存在则跳过(断点恢复)。"""
    by_date_dir = Path(cfg.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "")
    by_date_dir.mkdir(parents=True, exist_ok=True)
    out_path = by_date_dir / f"factor7_{date}.parquet"
    if out_path.exists():
        logger.info("skip %s（已存在）", date)
        return f"skip {date}"

    df = build_one_day(date, cfg)
    if df.empty:
        logger.warning("empty %s", date)
        return f"empty {date}"
    df.to_parquet(out_path, index=False)
    logger.info("ok %s rows=%d codes=%d -> %s", date, len(df), df["code"].nunique(), out_path)
    return f"ok {date} rows={len(df)} codes={df['code'].nunique()}"


def main():
    parser = argparse.ArgumentParser(
        description="Cxl_accelarate + new_order_wavg_dis 因子（单日，股票级并行）")
    parser.add_argument("--date", type=str, default="20240430",
                        help="交易日 YYYYMMDD（只处理这一天）")
    parser.add_argument("--max-workers", type=int, default=40,
                        help="单日内对股票并行的进程数，默认 40")
    args = parser.parse_args()

    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")

    cfg = Config()
    cfg.MAX_WORKERS = args.max_workers
    logger.info("处理交易日 %s，股票级并行 max_workers=%d", args.date, cfg.MAX_WORKERS)
    process_day(args.date, cfg)


if __name__ == "__main__":
    import shutil, os, stat
    _src = Path(__file__).resolve()
    _dst = Path(Config.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "") / _src.name
    if not _dst.exists():
        _dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(_src, _dst)
        os.chmod(_dst, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    main()
