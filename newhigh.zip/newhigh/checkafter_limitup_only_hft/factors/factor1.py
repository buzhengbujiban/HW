#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
factor1.py —— 基于 order+trans+lob 一体长表构造高频因子。

数据源
------
一体长表：/home/datamake119/data1/user118/hft/raw_long_table/{sz,sh}_ordertranlob/<date>.parquet
  每行是一个事件（逐笔委托 / 逐笔成交 / 撤单），并已带上当时的五档盘口。
  关键列：
    code,time(int64, HHMMSSmmm),date
    成交行: orderKind=='T'，volume/askOrder/bidOrder/tradePrice 有值
    委托行: functionCode∈{B,S}，orderVolume/orderPrice 有值
    撤单行: functionCode=='C'(orderKind=='D')，本因子不使用
    盘口一档: 买一价 bp1 / 买一量 bv1 ；卖一价 sp1 / 卖一量 sv1
  价格均为整数(= 真实价*10000)，无效价为 -10000；量为股数。

因子口径
--------
- 主动方向（成交行）：askOrder 与 bidOrder 谁“小”谁是主动方（taker）。
      bidOrder < askOrder -> 买方主动(B)；askOrder < bidOrder -> 卖方主动(S)。
- allormorelevel1（吃掉一档及以上）：单笔成交量 >= 当时对手盘一档量。
      买方主动：volume >= sv1（卖一量）；卖方主动：volume >= bv1（买一量）。
- add_newlevel1（新增挂单形成更优一档）：
      买方新增：orderPrice > 当时 bp1（买一价）；卖方新增：orderPrice < 当时 sp1（卖一价）。
      bp1/sp1 无效(<=0)时不计。
- 窗口求和用“从开盘累计和 - 其 ewm 均值”近似：
      factor = cumsum - cumsum.ewm(halflife=H, adjust=False, ignore_na=True).mean()
- gap 为相邻主动买成交的“时间差”。

对齐口径
--------
- 只保留连续竞价时段：time ∈ [93000000,113000000] ∪ [130000000,145700000]。
- 以长表每行为一个事件，按 code 分组、组内按 (time,seq_num) 升序做 cumsum-ewm。
- 成交因子仅在成交行有值、委托因子仅在委托行有值，其余为 NaN（cumsum 按 0 处理）。
- 输出行与该日长表（时段过滤后）一致。

输出
----
每个交易日单独保存 /home/datamake119/data1/user118/hft/factors/by_date/factor1_<date>.parquet。
列为 (date,code,time) + 各因子。

设计原则：代码简洁、命名清晰、日志明确、可按天断点恢复、先小样本再全量。
"""

from __future__ import annotations

import argparse
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("hft.factor1")


class Config:
    # 一体长表目录（含 sz_ordertranlob / sh_ordertranlob 两个子目录）
    RAW_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/raw_long_table"
    MARKETS = ("sz", "sh")
    OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/factors"

    HL_LEVEL1 = 500         # allormorelevel1 / add_newlevel1 / trdact 计数与量
    HL_TRDACT_DIFF = 250    # trdact_B_diff / trdact_BSimb_diff
    HL_GAP_SHORT = 50       # shrinkGap 分子
    HL_GAP_LONG = 500      # shrinkGap 分母
    MAX_WORKERS = 100

    # 连续竞价时段（含端点），HHMMSSmmm
    AM_START, AM_END = 93000000, 113000000
    PM_START, PM_END = 130000000, 145700000

    # 读长表只取需要的列，省内存
    # 注：新长表 schema 与旧版差异较大：functionCode -> side+type；orderKind -> type；
    # orderPrice/orderVolume/tradePrice/Volume 统一为 price/volume；
    # askOrder/bidOrder -> sellorder/buyorder；order -> number；
    # 价格列由"真实价*10000整数"改为"真实价浮点"。
    # 这里读入新字段，下方 _read_long_table 末尾会做兼容映射，
    # 让 _one_stock 内的旧逻辑/旧字段名继续可用。
    LACOLS = ['LA10', 'LA3600', 'LA43200', 'LA60', 'LAEOD', 'LAEOD1', 'LAEOD2',
       'LAEOD5', 'LASVWAP1', 'LASVWAP2', 'LASVWAP5']
    USE_COLS = ["code", "time", "date", "type", "side",
                "volume", "sellorder", "buyorder",
                "price", "size", "seq_num", "number",
                "bp1", "sp1", "bv1", "sv1"] + LACOLS



def in_trading_session(t: np.ndarray, cfg: Config) -> np.ndarray:
    """是否在连续竞价时段内。"""
    return (((t >= cfg.AM_START) & (t <= cfg.AM_END)) |
            ((t >= cfg.PM_START) & (t <= cfg.PM_END)))


def time_to_sec(t: np.ndarray) -> np.ndarray:
    """逐笔 time(HHMMSSmmm) -> 当日秒数(float)。"""
    t = t.astype("int64")
    ms = t % 1000
    rest = t // 1000
    s = rest % 100
    rest = rest // 100
    m = rest % 100
    h = rest // 100
    return (h * 3600 + m * 60 + s + ms / 1000.0).astype("float64")


def cumsum_minus_ewm(values: np.ndarray, halflife: float) -> np.ndarray:
    """cumsumfromopen(x) - cumsumfromopen(x).ewm(halflife).mean()。

    NaN 表示该事件不计入（cumsum 按 0 处理）。返回与 values 等长数组。
    """
    s = pd.Series(values, dtype="float64")
    cum = s.fillna(0.0).cumsum()
    ewm = cum.ewm(halflife=halflife, adjust=False, ignore_na=True).mean()
    return (cum - ewm).to_numpy()


def _ratio(a: pd.Series, b: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / b


def _bsimb(b: pd.Series, s: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b - s) / (b + s)


def _one_stock(date: str, code: str, tbl_df: pd.DataFrame, cfg: Config) -> pd.DataFrame | None:
    """单股票：在一体长表（已按事件升序）上用 pandas 列运算做 cumsum-ewm，得到因子。"""
    if tbl_df.empty:
        return None

    tbl_df = tbl_df.sort_values(["time", "seq_num"]).reset_index(drop=True)
    out = tbl_df[["date", "code", "time",'seq_num'] + cfg.LACOLS].copy()

    # ---------- 成交侧 trdact（仅成交行 orderKind=='T' 有值）----------
    # is_trade = tbl_df["orderKind"].astype(str) == "T"
    # is_buy = is_trade & (tbl_df["bidOrder"] > tbl_df["askOrder"])
    # is_sell = is_trade & (tbl_df["askOrder"] > tbl_df["bidOrder"])
    # 吃档：买主动量 >= 卖一量 sv1；卖主动量 >= 买一量 bv1（一档量 >0 才有效）
    # ---------- 委托侧 add（仅委托行 functionCode∈{B,S} 有值）----------
    fc = tbl_df["functionCode"].astype(str)
    o_is_buy = fc == "B"
    o_is_sell = fc == "S"


    eat_buy = o_is_buy &  (tbl_df['orderKind'].shift(-1)=='T')  & (tbl_df['orderPrice']>=tbl_df['sp1']) # &  (tbl_df["orderVolume"] >= tbl_df["sv1"])
    eat_sell = o_is_sell  &  (tbl_df['orderKind'].shift(-1)=='T')  &  (tbl_df['orderPrice']<=tbl_df['bp1']) #& (tbl_df["orderVolume"] >= tbl_df["bv1"])

    tbl_df["size_trdact_B"] = tbl_df["size"].where(eat_buy, np.nan)
    tbl_df["size_trdact_S"] = tbl_df["size"].where(eat_sell, np.nan)
    tbl_df["cnt_trdact_B"] = eat_buy * 1.0
    tbl_df["cnt_trdact_S"] = eat_sell * 1.0
    
    tbl_df["cnt_trdact_allormorelevel1_B"] = eat_buy & (tbl_df["orderVolume"] >= tbl_df["sv1"])
    tbl_df["cnt_trdact_allormorelevel1_S"] = eat_sell & (tbl_df["orderVolume"] >= tbl_df["bv1"])
    tbl_df["size_trdact_allormorelevel1_B"] = tbl_df["size"].where(tbl_df["cnt_trdact_allormorelevel1_B"], np.nan)
    tbl_df["size_trdact_allormorelevel1_S"] = tbl_df["size"].where(tbl_df["cnt_trdact_allormorelevel1_S"], np.nan)


    tbl_df["cnt_trdact_atlevel1_B"] = eat_buy & (tbl_df["orderVolume"] == tbl_df["sv1"])
    tbl_df["cnt_trdact_atlevel1_S"] = eat_sell & (tbl_df["orderVolume"] == tbl_df["bv1"])
    tbl_df["size_trdact_atlevel1_B"] = tbl_df["size"].where(tbl_df["cnt_trdact_atlevel1_B"], np.nan)
    tbl_df["size_trdact_atlevel1_S"] = tbl_df["size"].where(tbl_df["cnt_trdact_atlevel1_S"], np.nan)


    # 新增更优一档：买价 > 买一价 bp1；卖价 < 卖一价 sp1（盘口价 >0 才有效）
    new_buy = o_is_buy & (tbl_df["bp1"] > 0) & (tbl_df['bv1']==tbl_df['size']) & (tbl_df["orderPrice"] > tbl_df["bp1"].shift()) & (tbl_df['orderKind'].shift(-1)!='T')
    new_sell = o_is_sell & (tbl_df["sp1"] > 0) & (tbl_df['sv1']==tbl_df['size']) & (tbl_df["orderPrice"] < tbl_df["sp1"].shift())  & (tbl_df['orderKind'].shift(-1)!='T')

    tbl_df["add_size_B"] = tbl_df["orderVolume"].where(o_is_buy, np.nan)
    tbl_df["add_size_S"] = tbl_df["orderVolume"].where(o_is_sell, np.nan)
    tbl_df["add_cnt_B"] = o_is_buy.astype("float64").where(o_is_buy, np.nan)
    tbl_df["add_cnt_S"] = o_is_sell.astype("float64").where(o_is_sell, np.nan)
    tbl_df["add_size_newlevel1_B"] = tbl_df["orderVolume"].where(new_buy, np.nan)
    tbl_df["add_size_newlevel1_S"] = tbl_df["orderVolume"].where(new_sell, np.nan)
    tbl_df["add_cnt_newlevel1_B"] = new_buy.astype("float64").where(new_buy, np.nan)
    tbl_df["add_cnt_newlevel1_S"] = new_sell.astype("float64").where(new_sell, np.nan)

    def cum_ewm(col: str, hl: float) -> pd.Series:
        """对长表的某列做 cumsum-ewm。"""
        return pd.Series(cumsum_minus_ewm(tbl_df[col].to_numpy("float64"), hl),
                            index=tbl_df.index)

    # ---------- 成交侧因子 ----------
    tbl_df['f_size_B'] = cum_ewm("size_trdact_B", cfg.HL_LEVEL1)
    tbl_df['f_size_S'] = cum_ewm("size_trdact_S", cfg.HL_LEVEL1)
    tbl_df['f_cnt_B'] = cum_ewm("cnt_trdact_B", cfg.HL_LEVEL1)
    tbl_df['f_cnt_S'] = cum_ewm("cnt_trdact_S", cfg.HL_LEVEL1)
    tbl_df['f_size_lvl1_B'] = cum_ewm("size_trdact_allormorelevel1_B", cfg.HL_LEVEL1)
    tbl_df['f_size_lvl1_S'] = cum_ewm("size_trdact_allormorelevel1_S", cfg.HL_LEVEL1)
    tbl_df['f_cnt_lvl1_B'] = cum_ewm("cnt_trdact_allormorelevel1_B", cfg.HL_LEVEL1)
    tbl_df['f_cnt_lvl1_S'] = cum_ewm("cnt_trdact_allormorelevel1_S", cfg.HL_LEVEL1)
    tbl_df['f_size_atlvl1_B'] = cum_ewm("size_trdact_atlevel1_B", cfg.HL_LEVEL1)
    tbl_df['f_size_atlvl1_S'] = cum_ewm("size_trdact_atlevel1_S", cfg.HL_LEVEL1)
    tbl_df['f_cnt_atlvl1_B'] = cum_ewm("cnt_trdact_atlevel1_B", cfg.HL_LEVEL1)
    tbl_df['f_cnt_atlvl1_S'] = cum_ewm("cnt_trdact_atlevel1_S", cfg.HL_LEVEL1)

    tbl_df["size_trdact_allormorelevel1_B_prob"] = _ratio(tbl_df['f_size_lvl1_B'], tbl_df['f_size_B'])
    tbl_df["size_trdact_allormorelevel1_S_prob"] = _ratio(tbl_df['f_size_lvl1_S'], tbl_df['f_size_S'])
    out["size_trdact_allormorelevel1_prob_BSimb"] = _bsimb(
        tbl_df["size_trdact_allormorelevel1_B_prob"],
        tbl_df["size_trdact_allormorelevel1_S_prob"])


    out["cnt_trdact_allormorelevel1_B_prob"] = _ratio(tbl_df['f_cnt_lvl1_B'], tbl_df['f_cnt_B'])
    out["cnt_trdact_allormorelevel1_S_prob"] = _ratio(tbl_df['f_cnt_lvl1_S'], tbl_df['f_cnt_S'])
    out["cnt_trdact_allormorelevel1_prob_BSimb"] = _bsimb(
        out["cnt_trdact_allormorelevel1_B_prob"],
        out["cnt_trdact_allormorelevel1_S_prob"])
    
    tbl_df["size_trdact_atlevel1_B_prob"] = _ratio(tbl_df['f_size_atlvl1_B'], tbl_df['f_size_B'])
    tbl_df["size_trdact_atlevel1_S_prob"] = _ratio(tbl_df['f_size_atlvl1_S'], tbl_df['f_size_S'])
    out["size_trdact_atlevel1_prob_BSimb"] = _bsimb(
        tbl_df["size_trdact_atlevel1_B_prob"],
        tbl_df["size_trdact_atlevel1_S_prob"])

    
    tbl_df["cnt_trdact_atlevel1_B_prob"] = _ratio(tbl_df['f_cnt_atlvl1_B'], tbl_df['f_size_B'])
    tbl_df["cnt_trdact_atlevel1_S_prob"] = _ratio(tbl_df['f_cnt_atlvl1_S'], tbl_df['f_size_S'])
    out["cnt_trdact_atlevel1_prob_BSimb"] = _bsimb(
        tbl_df["cnt_trdact_atlevel1_B_prob"],
        tbl_df["cnt_trdact_atlevel1_S_prob"])


    # trdact_B_diff / trdact_BSimb_diff（笔数口径，halflife=250）
    out["trdact_B_diff"] = cum_ewm("cnt_trdact_B", cfg.HL_TRDACT_DIFF)
    net = (tbl_df["cnt_trdact_B"].fillna(0.0) - tbl_df["cnt_trdact_S"].fillna(0.0))
    out["trdact_BSimb_diff"] = pd.Series(
        cumsum_minus_ewm(net.to_numpy("float64"), cfg.HL_TRDACT_DIFF),
        index=tbl_df.index)

    # shrinkGap_trdact_B：主动买成交相邻时间差(秒)的短/长 ewm 之比
    sec = time_to_sec(tbl_df["time"].to_numpy("int64"))
    gap = np.full(len(tbl_df), np.nan)
    sellgap = np.full(len(tbl_df), np.nan)

    buy_pos = np.where(tbl_df["cnt_trdact_B"].notnull())[0]
    sell_pos = np.where(tbl_df["cnt_trdact_S"].notnull())[0]

    if buy_pos.size >= 2:
        gap[buy_pos[1:]] = np.diff(sec[buy_pos])
    if sell_pos.size >= 2:
        sellgap[sell_pos[1:]] = np.diff(sec[sell_pos])


    tbl_df['gap'] = np.log(1/(gap + 0.01))
    out["shrinkGap_trdact_B"] = cum_ewm("gap", cfg.HL_GAP_LONG)

    tbl_df['sellgap'] = np.log(1/(sellgap+0.01))
    out["shrinkGap_trdact_S"] = cum_ewm("sellgap", cfg.HL_GAP_LONG)
    out["shrinkGap_trdact_BSimb"] = out.eval("(shrinkGap_trdact_B - shrinkGap_trdact_S) / (shrinkGap_trdact_S + shrinkGap_trdact_B + 0.1)")

    # ---------- 委托侧因子 ----------
    tbl_df['f_add_size_B'] = cum_ewm("add_size_B", cfg.HL_LEVEL1)
    tbl_df['f_add_size_S'] = cum_ewm("add_size_S", cfg.HL_LEVEL1)
    tbl_df['f_add_cnt_B'] = cum_ewm("add_cnt_B", cfg.HL_LEVEL1)
    tbl_df['f_add_cnt_S'] = cum_ewm("add_cnt_S", cfg.HL_LEVEL1)
    tbl_df['f_add_size_new_B'] = cum_ewm("add_size_newlevel1_B", cfg.HL_LEVEL1)
    tbl_df['f_add_size_new_S'] = cum_ewm("add_size_newlevel1_S", cfg.HL_LEVEL1)
    tbl_df['f_add_cnt_new_B'] = cum_ewm("add_cnt_newlevel1_B", cfg.HL_LEVEL1)
    tbl_df['f_add_cnt_new_S'] = cum_ewm("add_cnt_newlevel1_S", cfg.HL_LEVEL1)

    tbl_df["size_add_newlevel1_B_prob"] = _ratio(tbl_df['f_add_size_new_B'], tbl_df['f_add_size_B'])
    tbl_df["size_add_newlevel1_S_prob"] = _ratio(tbl_df['f_add_size_new_S'], tbl_df['f_add_size_S'])
    out["size_add_newlevel1_prob_BSimb"] = _bsimb(
        tbl_df["size_add_newlevel1_B_prob"], tbl_df["size_add_newlevel1_S_prob"])

    out["cnt_add_newlevel1_B_prob"] = _ratio(tbl_df['f_add_cnt_new_B'], tbl_df['f_add_cnt_B'])
    out["cnt_add_newlevel1_S_prob"] = _ratio(tbl_df['f_add_cnt_new_S'], tbl_df['f_add_cnt_S'])
    out["cnt_add_newlevel1_prob_BSimb"] = _bsimb(
        out["cnt_add_newlevel1_B_prob"], out["cnt_add_newlevel1_S_prob"])



    return out[::100]


def _read_long_table(date: str, cfg: Config) -> pd.DataFrame:
    """读取沪深一体长表，在读取层(parquet filters)就只取连续竞价时段。

    连续竞价为两个时间区间的并集，用 OR 形式的 filters 做谓词下推，
    避免把非交易时段(开盘集合竞价、午休、尾盘集合竞价)的数据读进内存。
    """
    # filters: 外层 list 之间是 OR，内层 list 之间是 AND
    time_filters = [
        [("time", ">=", cfg.AM_START), ("time", "<=", cfg.AM_END)],
        [("time", ">=", cfg.PM_START), ("time", "<=", cfg.PM_END)],
    ]
    frames = []
    for market in cfg.MARKETS:
        path = Path(cfg.RAW_DIR) / f"{market}_ordertranlob" / f"{date}.parquet"
        if not path.exists():
            continue
        df = pd.read_parquet(path, columns=cfg.USE_COLS, filters=time_filters)
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["code"] = df["code"].astype(str)
    df["time"] = df["time"].astype("int64")

    # ====================================================================
    # === schema 兼容层：新长表字段 → 旧因子代码使用的字段名 ===
    # 新长表字段差异（vs 旧 schema）：
    #   1) 没有 functionCode；方向放在 side(B/S/N/NaN)，事件类型放在 type
    #      type 取值：深市 {'T','D','2','1','U'}，沪市 {'T','D','A'}
    #      推导规则：type=='D' → 撤单 'C'；type=='T' → 成交（不用 fc）；
    #                其他都视作委托，fc = side（B 或 S）
    #   2) type 替代了原来的 orderKind（取值含义一致：T 成交、D 撤单、
    #      限价单深 '2'/沪 'A'、'1' 市价买、'U' 本方最优）
    #   3) 价格 / 成交价 / 委托价统一为 price；成交量/委托量/撤单量统一为
    #      volume（size 仍保留原成交/撤单/委托量字段）
    #   4) askOrder/bidOrder → sellorder/buyorder；order → number
    #   5) 价格列旧版是"真实价*10000"的整数(无效=−10000)，新版是浮点真实价
    #      → 这里统一 *10000 转回旧口径，保证所有比较 / 阈值常量(如
    #        PRX_STD_FILL=200、+100、">0" 哨兵) 无需改动。
    # 这一层只在 _read_long_table 末尾做一次，所有 _one_stock 内部逻辑保持不变。
    # ====================================================================
    price_cols = ["price", "price_lob",
                  "bp1", "bp2", "bp3", "bp4", "bp5",
                  "sp1", "sp2", "sp3", "sp4", "sp5"]
    for c in price_cols:
        if c in df.columns:
            v = df[c].astype("float64").to_numpy()
            # NaN / <=0 视为缺失，统一用 -10000 哨兵
            v = np.where(np.isnan(v) | (v <= 0), -10000.0, v * 10000.0)
            df[c] = v.astype("int64")

    type_s = df["type"].astype(str)
    # side 是 categorical，NaN -> "nan"；这里转成空字符串避免误判
    side_s = df["side"].astype(str).where(df["side"].notna(), "")
    is_trade = (type_s == "T").to_numpy()
    is_cxl = (type_s == "D").to_numpy()
    # 撤单 -> 'C'；成交 -> ''(下游不会比较)；委托 -> side(B/S)
    fc = np.where(is_cxl, "C", np.where(~is_trade, side_s.to_numpy(), ""))
    df["functionCode"] = fc
    df["orderKind"] = type_s.to_numpy()
    df["orderPrice"] = df["price"]
    df["orderVolume"] = df["volume"]
    df["bidOrder"] = df["buyorder"]
    df["askOrder"] = df["sellorder"]
    df["order"] = df["number"]

    return df


def _one_stock_worker(args):
    """进程池工作函数：解包参数后调用 _one_stock。

    单独抽出顶层函数，便于被 ProcessPoolExecutor pickle 调用。
    """
    date, code, sub_df, cfg = args
    return _one_stock(date, code, sub_df, cfg)



def build_one_day(date: str, cfg: Config) -> pd.DataFrame:
    """单日：读一体长表，对每只股票并行计算因子。

    max_workers==1 时顺序计算(带 tqdm，便于调试)；
    max_workers>1 时把每只股票的子表提交进程池，**每只股票并行**。
    """
    table_df = _read_long_table(date, cfg)
    if table_df.empty:
        logger.warning("%s 无长表数据，跳过", date)
        return pd.DataFrame()

    groups = list(table_df.groupby("code", sort=False))
    logger.info("%s 股票数=%d，单日内并行 max_workers=%d", date, len(groups), cfg.MAX_WORKERS)

    frames = []
    max_workers = max(1, int(cfg.MAX_WORKERS))
    if max_workers == 1:
        for code, sub_df in tqdm(groups, desc=date):
            frame = _one_stock(date, str(code), sub_df, cfg)
            if frame is not None and not frame.empty:
                frames.append(frame)
    else:
        # 每只股票一个任务并行；必须消费 future.result()，异常向上抛出
        tasks = [(date, str(code), sub_df, cfg) for code, sub_df in groups]
        with ProcessPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(_one_stock_worker, t): t[1] for t in tasks}
            for fut in tqdm(as_completed(futures), total=len(futures), desc=date):
                code = futures[fut]
                try:
                    frame = fut.result()
                except Exception as exc:
                    logger.exception("%s %s 计算失败：%s", date, code, exc)
                    raise
                if frame is not None and not frame.empty:
                    frames.append(frame)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def process_day(date: str, cfg: Config) -> str:
    """处理单个交易日并保存；已存在则跳过(断点恢复)。"""
    by_date_dir = Path(cfg.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "")
    by_date_dir.mkdir(parents=True, exist_ok=True)
    out_path = by_date_dir / f"factor1_{date}.parquet"
    if out_path.exists():
        logger.info("skip %s（已存在）", date)
        return f"skip {date}"

    df = build_one_day(date, cfg)
    if df.empty:
        logger.warning("empty %s", date)
        return f"empty {date}"
    df.to_parquet(out_path, index=False)
    logger.info("ok %s rows=%d codes=%d -> %s", date, len(df), df["code"].nunique(), out_path)
    return f"ok {date} rows={len(df)} codes={df['code'].nunique()}"


def main():
    parser = argparse.ArgumentParser(description="基于 order+trans+lob 一体长表的高频因子（单日，股票级并行）")
    parser.add_argument("--date", type=str, default="20240430", help="交易日 YYYYMMDD（只处理这一天）")
    parser.add_argument("--max-workers", type=int, default=20,
                        help="单日内对股票并行的进程数，默认 100")
    args = parser.parse_args()

    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")

    cfg = Config()
    cfg.MAX_WORKERS = args.max_workers
    logger.info("处理交易日 %s，股票级并行 max_workers=%d", args.date, cfg.MAX_WORKERS)
    process_day(args.date, cfg)


if __name__ == "__main__":
    # 保存自身代码副本到 OUTPUT_DIR，权限仅自己可读(0o600)，已存在则跳过
    import shutil, os, stat
    _src = Path(__file__).resolve()
    _dst = Path(Config.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "") / _src.name
    # if not _dst.exists():
    #     shutil.copy2(_src, _dst)
    #     os.chmod(_dst, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    main()
