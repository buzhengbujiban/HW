#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
factor5.py —— Deepzone 因子：按"挂单价格相对中价的分层区间"刻画买卖挂单/撤单分布。

数据源
------
一体长表：/project/user214/hft/raw_long_table/{sz,sh}_ordertranlob/<date>.parquet
  与 factor1/factor3 相同。每行一个事件（委托 / 成交 / 撤单），带当时五档盘口。

因子口径（Deepzone）
--------------------
- 中价 mid = price_lob（最新成交价），prx_std = price_lob 的 rolling std（窗口 PRX_ROLL_WINDOW）。
- 价格分层：以 prx_std 为步长，把挂单价格相对 mid 的偏离切成若干区间。
  * 卖方(S)分子区间（k=-1..4）：orderPrice ∈ (mid + prx_std*k, mid + prx_std*(k+1)]
        命名 -1_0 / 0_1 / 1_2 / 2_3 / 3_4 / 4_5。
        -1_0 表示 cross-spread 主动卖（价格落在 mid 之下一个 std 内），仅 add 有，cxl 无。
  * 买方(B)对称（k=-1..4）：orderPrice ∈ [mid - prx_std*(k+1), mid - prx_std*k)
        命名 -1_0 / 0_1 / ... / 4_5；-1_0 为 cross-spread 主动买，仅 add 有。
  * 分母区间 0_5：
        S 侧 = orderPrice ≤ mid + prx_std*5 的所有卖方挂单（含 -1_0 那一段，即价格 ≤ 上界）。
        B 侧 = orderPrice ≥ mid - prx_std*5 的所有买方挂单。
- add（新增委托 functionCode∈{B,S}）：用委托行自带 orderPrice 判区间。
- cxl（撤单 functionCode=='C'）：撤单行 orderPrice 恒为 0，需要先建立 order 列(委托编号)→orderPrice
  的字典，再用撤单行的 askOrder/bidOrder 作为索引回填出原委托价，再判区间。
  撤买方向 bidOrder>0 → B 侧；撤卖方向 askOrder>0 → S 侧。cxl 无 -1_0 区间。
- 每个区间出 cnt（笔数）与 size（挂单量）两套。

输出因子（对每个区间 bi_bj ∈ {-1_0,0_1,1_2,2_3,3_4,4_5}，cxl 无 -1_0）：
  add_{cnt/size}_{bi_bj}_BSimb        = _bsimb(cum_ewm(B), cum_ewm(S))
  add_{cnt/size}_{bi_bj}_prob1_BSimb  = _bsimb(B/B_0_5, S/S_0_5)
  add_{cnt/size}_{bi_bj}_prob2_BSimb  = _bsimb(B/add_B_all, S/add_S_all)
  add_{cnt/size}_{bi_bj}_prob3_BSimb  = _bsimb(B/(add_0_5_B+cxl_0_5_B), S/(add_0_5_S+cxl_0_5_S))
  cxl 同理（前缀 cxl_，无 -1_0；prob3 分母对称用 cxl_0_5 + add_0_5）。

对齐口径
--------
- 只保留连续竞价时段：time ∈ [93000000,113000000] ∪ [130000000,145700000]。
- 按 code 分组、组内按 (time,seq_num) 升序做 cumsum-ewm。
- 输出行与该日长表（时段过滤后）一致，最后 [::100] 抽稀。

输出
----
/project/user214/hft/factors/factor5/factor5_<date>.parquet，列 = (date,code,time,seq_num)+LACOLS+因子。

设计原则：代码简洁、命名清晰、日志明确、可按天断点恢复、先小样本再全量。
"""

from __future__ import annotations

import argparse
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("hft.factor5")


class Config:
    # 一体长表目录（含 sz_ordertranlob / sh_ordertranlob 两个子目录）
    RAW_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/raw_long_table"
    MARKETS = ("sz", "sh")
    OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/factors"

    HL_LEVEL1 = 500          # cum_ewm 的 halflife
    MAX_WORKERS = 100

    # Deepzone 分层参数
    L_SCALE = 5              # 分子区间数（0_1..4_5），外加 -1_0(仅 add)
    PRX_ROLL_WINDOW = 20000    # price_lob rolling std 窗口
    PRX_STD_FILL = 200     # rolling std 无效时的填充（与 factor3 一致）

    # 连续竞价时段（含端点），HHMMSSmmm
    AM_START, AM_END = 93000000, 113000000
    PM_START, PM_END = 130000000, 145700000

    # 读长表只取需要的列，省内存
    # 注：新长表 schema 与旧版差异较大：functionCode -> side+type；orderKind -> type；
    # orderPrice/orderVolume/tradePrice/Volume 统一为 price/volume；
    # askOrder/bidOrder -> sellorder/buyorder；order(委托编号) -> number；
    # 价格列由"真实价*10000整数"改为"真实价浮点"。
    # 这里读入新字段，下方 _read_long_table 末尾会做兼容映射，
    # 让 _one_stock 内的旧逻辑/旧字段名继续可用。
    LACOLS = ['LA10', 'LA3600', 'LA43200', 'LA60', 'LAEOD', 'LAEOD1', 'LAEOD2',
              'LAEOD5', 'LASVWAP1', 'LASVWAP2', 'LASVWAP5']
    USE_COLS = ["code", "time", "date", "type", "side",
                "volume", "sellorder", "buyorder", "number",
                "price", "size", "seq_num",
                "bp1", "sp1", "bv1", "sv1", "price_lob"] + LACOLS



def time_to_sec(t: np.ndarray) -> np.ndarray:
    """逐笔 time(HHMMSSmmm) -> 当日秒数(float)。"""
    t = t.astype("int64")
    ms = t % 1000
    rest = t // 1000
    s = rest % 100
    rest = rest // 100
    m = rest % 100
    h = rest // 100
    return (h * 3600 + m * 60 + s + ms / 1000.0).astype("float64")


def cumsum_minus_ewm(values: np.ndarray, halflife: float) -> np.ndarray:
    """cumsumfromopen(x) - cumsumfromopen(x).ewm(halflife).mean()。

    NaN 表示该事件不计入（cumsum 按 0 处理）。返回与 values 等长数组。
    """
    s = pd.Series(values, dtype="float64")
    cum = s.fillna(0.0).cumsum()
    ewm = cum.ewm(halflife=halflife, adjust=False, ignore_na=True).mean()
    return (cum - ewm).to_numpy()


def _ratio(a: pd.Series, b: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / b


def _bsimb(b: pd.Series, s: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b - s) / (b + s)


# 区间命名：k 从 -1 到 L_SCALE-1，对应 "{k}_{k+1}"（负号会出现在 -1_0）
def _zone_name(k: int) -> str:
    return f"{k}_{k + 1}"


def _fill_cxl_orderprice(tbl_df: pd.DataFrame) -> pd.Series:
    """撤单行 orderPrice 恒为 0，用委托行的 order(委托编号)->orderPrice 字典回填。

    撤买行用 bidOrder 作索引、撤卖行用 askOrder 作索引，到字典中找原委托价。
    沪深均已验证：委托行的 order 列即委托编号，撤单 askOrder/bidOrder 与之对应（命中率 1.0）。
    返回与 tbl_df 等长的 Series：撤单行=回填价，其他行=NaN。
    """
    fc = tbl_df["functionCode"].astype(str)
    is_order = fc.isin(["B", "S"])

    # 委托编号 -> orderPrice 字典（用 order 列，沪深通用）
    order_rows = tbl_df.loc[is_order, ["order", "orderPrice"]].dropna(subset=["order"])
    price_map = dict(zip(order_rows["order"].astype("int64"),
                         order_rows["orderPrice"].astype("float64")))

    is_cxl = fc == "C"
    # 撤买用 bidOrder，撤卖用 askOrder，作为原委托编号索引
    bid = tbl_df["bidOrder"].fillna(0.0).to_numpy("float64")
    ask = tbl_df["askOrder"].fillna(0.0).to_numpy("float64")
    key = np.where(bid > 0, bid, ask).astype("int64")

    out = np.full(len(tbl_df), np.nan)
    cxl_idx = np.where(is_cxl.to_numpy())[0]
    for i in cxl_idx:
        out[i] = price_map.get(int(key[i]), np.nan)
    return pd.Series(out, index=tbl_df.index)


def _one_stock(date: str, code: str, tbl_df: pd.DataFrame, cfg: Config) -> pd.DataFrame | None:
    """单股票：在一体长表上构造 Deepzone 分层挂单/撤单因子。"""
    if tbl_df.empty:
        return None

    tbl_df = tbl_df.sort_values(["time", "seq_num"]).reset_index(drop=True)
    out = tbl_df[["date", "code", "time", "seq_num"] + cfg.LACOLS].copy()

    # ====================================================================
    # 前置清洗：修正无效盘口价 + 为市价单/本方最优价单填充合理的 orderPrice
    # （与 factor3 一致，避免涨跌停/市价单导致区间判定失真）
    # ====================================================================
    tbl_df['sp1'] = np.where(tbl_df['sp1'] <= 0, tbl_df['bp1'] * 0.7, tbl_df['sp1'])
    tbl_df['bp1'] = np.where(tbl_df['bp1'] > 5 * tbl_df['sp1'], tbl_df['sp1'] * 1.3, tbl_df['bp1'])
    tbl_df['bp1'] = np.where(tbl_df['bp1'] <= 0, tbl_df['sp1'], tbl_df['bp1'])
    tbl_df['orderPrice'] = np.where(
        (tbl_df['orderKind'].astype(str) == '1') & (tbl_df['functionCode'] == 'B'),
        tbl_df['price_lob'] * 1.3,
        np.where(
            (tbl_df['orderKind'].astype(str) == '1') & (tbl_df['functionCode'] == 'S'),
            tbl_df['price_lob'] * 0.7, tbl_df['orderPrice']))
    tbl_df['orderPrice'] = np.where(
        (tbl_df['orderKind'].astype(str) == 'U') & (tbl_df['functionCode'] == 'B'),
        tbl_df['price_lob'],
        np.where(
            (tbl_df['orderKind'].astype(str) == 'U') & (tbl_df['functionCode'] == 'S'),
            tbl_df['price_lob'], tbl_df['orderPrice']))

    fc = tbl_df["functionCode"].astype(str)
    o_is_buy = fc == "B"
    o_is_sell = fc == "S"
    is_cxl = fc == "C"

    # ---------- 中价 mid 与价格步长 prx_std ----------
    mid = tbl_df["price_lob"].astype("float64")
    prx_std = tbl_df["price_lob"].astype("float64").rolling(
        window=cfg.PRX_ROLL_WINDOW, min_periods=500).std()
    prx_std = prx_std.fillna(cfg.PRX_STD_FILL) + 100

    # ---------- 撤单价回填 ----------
    # 撤买 bidOrder>0 → B 侧；撤卖 askOrder>0 → S 侧
    cxl_price = _fill_cxl_orderprice(tbl_df)
    cxl_is_buy = is_cxl & (tbl_df["bidOrder"].fillna(0.0) > 0)
    cxl_is_sell = is_cxl & (tbl_df["askOrder"].fillna(0.0) > 0)

    order_price = tbl_df["orderPrice"].astype("float64")
    order_vol = tbl_df["orderVolume"].astype("float64")
    cxl_vol = tbl_df["size"].astype("float64")  # 撤单行 size 即撤单量

    # ---------- 分区间标记函数 ----------
    # S 侧（卖）：价格落在 (mid + prx_std*k, mid + prx_std*(k+1)]
    # B 侧（买）：价格落在 [mid - prx_std*(k+1), mid - prx_std*k)
    def zone_mask_S(price: pd.Series, k: int) -> pd.Series:
        lo = mid + prx_std * k
        hi = mid + prx_std * (k + 1)
        return (price > lo) & (price <= hi)

    def zone_mask_B(price: pd.Series, k: int) -> pd.Series:
        lo = mid - prx_std * (k + 1)
        hi = mid - prx_std * k
        return (price >= lo) & (price < hi)

    # 分母 0_5：价格 ≤ mid + prx_std*L 的卖方 / 价格 ≥ mid - prx_std*L 的买方
    den_hi_S = mid + prx_std * cfg.L_SCALE
    den_lo_B = mid - prx_std * cfg.L_SCALE

    def cum_ewm(col: str) -> pd.Series:
        return pd.Series(cumsum_minus_ewm(tbl_df[col].to_numpy("float64"), cfg.HL_LEVEL1),
                         index=tbl_df.index)

    # ====================================================================
    # 1) 构造每个区间的 cnt/size 计数列（add 与 cxl 各一套）
    # ====================================================================
    # k 从 -1 到 L_SCALE-1；cxl 没有 -1 区间
    k_list_add = list(range(-1, cfg.L_SCALE))     # [-1,0,1,2,3,4]
    k_list_cxl = list(range(0, cfg.L_SCALE))      # [0,1,2,3,4]

    # --- add 侧：用委托行 order_price / order_vol ---
    for k in k_list_add:
        z = _zone_name(k)
        mB = o_is_buy & zone_mask_B(order_price, k)
        mS = o_is_sell & zone_mask_S(order_price, k)
        tbl_df[f"add_cnt_{z}_B"] = mB.astype("float64").where(mB, np.nan)
        tbl_df[f"add_cnt_{z}_S"] = mS.astype("float64").where(mS, np.nan)
        tbl_df[f"add_size_{z}_B"] = order_vol.where(mB, np.nan)
        tbl_df[f"add_size_{z}_S"] = order_vol.where(mS, np.nan)

    # add 分母 0_5（区间内累计卖/买挂单）
    mB05 = o_is_buy & (order_price >= den_lo_B)
    mS05 = o_is_sell & (order_price <= den_hi_S)
    tbl_df["add_cnt_0_5_B"] = mB05.astype("float64").where(mB05, np.nan)
    tbl_df["add_cnt_0_5_S"] = mS05.astype("float64").where(mS05, np.nan)
    tbl_df["add_size_0_5_B"] = order_vol.where(mB05, np.nan)
    tbl_df["add_size_0_5_S"] = order_vol.where(mS05, np.nan)

    # add 全体（不限区间）做 prob2 分母
    tbl_df["add_cnt_all_B"] = o_is_buy.astype("float64").where(o_is_buy, np.nan)
    tbl_df["add_cnt_all_S"] = o_is_sell.astype("float64").where(o_is_sell, np.nan)
    tbl_df["add_size_all_B"] = order_vol.where(o_is_buy, np.nan)
    tbl_df["add_size_all_S"] = order_vol.where(o_is_sell, np.nan)

    # --- cxl 侧：用回填价 cxl_price / 撤单量 cxl_vol ---
    for k in k_list_cxl:
        z = _zone_name(k)
        mB = cxl_is_buy & zone_mask_B(cxl_price, k)
        mS = cxl_is_sell & zone_mask_S(cxl_price, k)
        tbl_df[f"cxl_cnt_{z}_B"] = mB.astype("float64").where(mB, np.nan)
        tbl_df[f"cxl_cnt_{z}_S"] = mS.astype("float64").where(mS, np.nan)
        tbl_df[f"cxl_size_{z}_B"] = cxl_vol.where(mB, np.nan)
        tbl_df[f"cxl_size_{z}_S"] = cxl_vol.where(mS, np.nan)

    cB05 = cxl_is_buy & (cxl_price >= den_lo_B)
    cS05 = cxl_is_sell & (cxl_price <= den_hi_S)
    tbl_df["cxl_cnt_0_5_B"] = cB05.astype("float64").where(cB05, np.nan)
    tbl_df["cxl_cnt_0_5_S"] = cS05.astype("float64").where(cS05, np.nan)
    tbl_df["cxl_size_0_5_B"] = cxl_vol.where(cB05, np.nan)
    tbl_df["cxl_size_0_5_S"] = cxl_vol.where(cS05, np.nan)

    # ====================================================================
    # 2) cum_ewm 累计（所有分母 / 分子）
    # ====================================================================
    # 分母（add/cxl 的 0_5 与 add 全体）
    f_add_05_B_cnt = cum_ewm("add_cnt_0_5_B")
    f_add_05_S_cnt = cum_ewm("add_cnt_0_5_S")
    f_add_05_B_size = cum_ewm("add_size_0_5_B")
    f_add_05_S_size = cum_ewm("add_size_0_5_S")
    f_add_all_B_cnt = cum_ewm("add_cnt_all_B")
    f_add_all_S_cnt = cum_ewm("add_cnt_all_S")
    f_add_all_B_size = cum_ewm("add_size_all_B")
    f_add_all_S_size = cum_ewm("add_size_all_S")
    f_cxl_05_B_cnt = cum_ewm("cxl_cnt_0_5_B")
    f_cxl_05_S_cnt = cum_ewm("cxl_cnt_0_5_S")
    f_cxl_05_B_size = cum_ewm("cxl_size_0_5_B")
    f_cxl_05_S_size = cum_ewm("cxl_size_0_5_S")

    # prob3 的合并分母（add_0_5 + cxl_0_5）
    den3_B_cnt = f_add_05_B_cnt + f_cxl_05_B_cnt
    den3_S_cnt = f_add_05_S_cnt + f_cxl_05_S_cnt
    den3_B_size = f_add_05_B_size + f_cxl_05_B_size
    den3_S_size = f_add_05_S_size + f_cxl_05_S_size

    # ---------- add 各区间因子 ----------
    for k in k_list_add:
        z = _zone_name(k)
        for unit, f05_B, f05_S, fall_B, fall_S in [
            ("cnt", f_add_05_B_cnt, f_add_05_S_cnt, f_add_all_B_cnt, f_add_all_S_cnt),
            ("size", f_add_05_B_size, f_add_05_S_size, f_add_all_B_size, f_add_all_S_size),
        ]:
            fB = cum_ewm(f"add_{unit}_{z}_B")
            fS = cum_ewm(f"add_{unit}_{z}_S")
            out[f"add_{unit}_{z}_BSimb"] = _bsimb(fB, fS)
            out[f"add_{unit}_{z}_prob1_BSimb"] = _bsimb(_ratio(fB, f05_B), _ratio(fS, f05_S))
            out[f"add_{unit}_{z}_prob2_BSimb"] = _bsimb(_ratio(fB, fall_B), _ratio(fS, fall_S))
            out[f"add_{unit}_{z}_prob3_BSimb"] = _bsimb(_ratio(fB, den3_B_cnt if unit == "cnt" else den3_B_size),
                                                        _ratio(fS, den3_S_cnt if unit == "cnt" else den3_S_size))

    # ---------- cxl 各区间因子（无 -1_0；prob2 用 cxl 全体，prob3 对称 cxl_0_5+add_0_5） ----------
    # cxl 全体（prob2 分母）
    tbl_df["cxl_cnt_all_B"] = cxl_is_buy.astype("float64").where(cxl_is_buy, np.nan)
    tbl_df["cxl_cnt_all_S"] = cxl_is_sell.astype("float64").where(cxl_is_sell, np.nan)
    tbl_df["cxl_size_all_B"] = cxl_vol.where(cxl_is_buy, np.nan)
    tbl_df["cxl_size_all_S"] = cxl_vol.where(cxl_is_sell, np.nan)
    f_cxl_all_B_cnt = cum_ewm("cxl_cnt_all_B")
    f_cxl_all_S_cnt = cum_ewm("cxl_cnt_all_S")
    f_cxl_all_B_size = cum_ewm("cxl_size_all_B")
    f_cxl_all_S_size = cum_ewm("cxl_size_all_S")

    for k in k_list_cxl:
        z = _zone_name(k)
        for unit, f05_B, f05_S, fall_B, fall_S in [
            ("cnt", f_cxl_05_B_cnt, f_cxl_05_S_cnt, f_cxl_all_B_cnt, f_cxl_all_S_cnt),
            ("size", f_cxl_05_B_size, f_cxl_05_S_size, f_cxl_all_B_size, f_cxl_all_S_size),
        ]:
            fB = cum_ewm(f"cxl_{unit}_{z}_B")
            fS = cum_ewm(f"cxl_{unit}_{z}_S")
            out[f"cxl_{unit}_{z}_BSimb"] = _bsimb(fB, fS)
            out[f"cxl_{unit}_{z}_prob1_BSimb"] = _bsimb(_ratio(fB, f05_B), _ratio(fS, f05_S))
            out[f"cxl_{unit}_{z}_prob2_BSimb"] = _bsimb(_ratio(fB, fall_B), _ratio(fS, fall_S))
            out[f"cxl_{unit}_{z}_prob3_BSimb"] = _bsimb(_ratio(fB, den3_B_cnt if unit == "cnt" else den3_B_size),
                                                        _ratio(fS, den3_S_cnt if unit == "cnt" else den3_S_size))

    return out[::100]


def _read_long_table(date: str, cfg: Config) -> pd.DataFrame:
    """读取沪深一体长表，在读取层(parquet filters)就只取连续竞价时段。"""
    time_filters = [
        [("time", ">=", cfg.AM_START), ("time", "<=", cfg.AM_END)],
        [("time", ">=", cfg.PM_START), ("time", "<=", cfg.PM_END)],
    ]
    frames = []
    for market in cfg.MARKETS:
        path = Path(cfg.RAW_DIR) / f"{market}_ordertranlob" / f"{date}.parquet"
        if not path.exists():
            continue
        df = pd.read_parquet(path, columns=cfg.USE_COLS, filters=time_filters)
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["code"] = df["code"].astype(str)
    df["time"] = df["time"].astype("int64")

    # ====================================================================
    # === schema 兼容层：新长表字段 → 旧因子代码使用的字段名 ===
    # 新长表字段差异（vs 旧 schema）：
    #   1) 没有 functionCode；方向放在 side(B/S/N/NaN)，事件类型放在 type
    #      type 取值：深市 {'T','D','2','1','U'}，沪市 {'T','D','A'}
    #      推导规则：type=='D' → 撤单 'C'；type=='T' → 成交（不用 fc）；
    #                其他都视作委托，fc = side（B 或 S）
    #   2) type 替代了原来的 orderKind（取值含义一致：T 成交、D 撤单、
    #      限价单深 '2'/沪 'A'、'1' 市价买、'U' 本方最优）
    #   3) 价格 / 成交价 / 委托价统一为 price；成交量/委托量/撤单量统一为
    #      volume（size 仍保留原成交/撤单/委托量字段）
    #   4) askOrder/bidOrder → sellorder/buyorder；order(委托编号) → number
    #   5) 价格列旧版是"真实价*10000"的整数(无效=−10000)，新版是浮点真实价
    #      → 这里统一 *10000 转回旧口径，保证所有比较 / 阈值常量(如
    #        PRX_STD_FILL=200、+100、">0" 哨兵) 无需改动。
    # 这一层只在 _read_long_table 末尾做一次，所有 _one_stock 内部逻辑保持不变。
    # ====================================================================
    price_cols = ["price", "price_lob",
                  "bp1", "bp2", "bp3", "bp4", "bp5",
                  "sp1", "sp2", "sp3", "sp4", "sp5"]
    for c in price_cols:
        if c in df.columns:
            v = df[c].astype("float64").to_numpy()
            v = np.where(np.isnan(v) | (v <= 0), -10000.0, v * 10000.0)
            df[c] = v.astype("int64")

    type_s = df["type"].astype(str)
    side_s = df["side"].astype(str).where(df["side"].notna(), "")
    is_trade = (type_s == "T").to_numpy()
    is_cxl = (type_s == "D").to_numpy()
    fc = np.where(is_cxl, "C", np.where(~is_trade, side_s.to_numpy(), ""))
    df["functionCode"] = fc
    df["orderKind"] = type_s.to_numpy()
    df["orderPrice"] = df["price"]
    df["orderVolume"] = df["volume"]
    df["bidOrder"] = df["buyorder"]
    df["askOrder"] = df["sellorder"]
    df["order"] = df["number"]

    return df


def _one_stock_worker(args):
    """进程池工作函数：解包参数后调用 _one_stock。"""
    date, code, sub_df, cfg = args
    return _one_stock(date, code, sub_df, cfg)



def build_one_day(date: str, cfg: Config) -> pd.DataFrame:
    """单日：读一体长表，对每只股票并行计算因子。"""
    table_df = _read_long_table(date, cfg)
    if table_df.empty:
        logger.warning("%s 无长表数据，跳过", date)
        return pd.DataFrame()

    groups = list(table_df.groupby("code", sort=False))
    logger.info("%s 股票数=%d，单日内并行 max_workers=%d", date, len(groups), cfg.MAX_WORKERS)

    frames = []
    max_workers = max(1, int(cfg.MAX_WORKERS))
    if max_workers == 1:
        for code, sub_df in tqdm(groups, desc=date):
            frame = _one_stock(date, str(code), sub_df, cfg)
            if frame is not None and not frame.empty:
                frames.append(frame)
    else:
        tasks = [(date, str(code), sub_df, cfg) for code, sub_df in groups]
        with ProcessPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(_one_stock_worker, t): t[1] for t in tasks}
            for fut in tqdm(as_completed(futures), total=len(futures), desc=date):
                code = futures[fut]
                try:
                    frame = fut.result()
                except Exception as exc:
                    logger.exception("%s %s 计算失败：%s", date, code, exc)
                    raise
                if frame is not None and not frame.empty:
                    frames.append(frame)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def process_day(date: str, cfg: Config) -> str:
    """处理单个交易日并保存；已存在则跳过(断点恢复)。"""
    by_date_dir = Path(cfg.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "")
    by_date_dir.mkdir(parents=True, exist_ok=True)
    out_path = by_date_dir / f"factor5_{date}.parquet"
    if out_path.exists():
        logger.info("skip %s（已存在）", date)
        return f"skip {date}"

    df = build_one_day(date, cfg)
    if df.empty:
        logger.warning("empty %s", date)
        return f"empty {date}"
    df.to_parquet(out_path, index=False)
    logger.info("ok %s rows=%d codes=%d -> %s", date, len(df), df["code"].nunique(), out_path)
    return f"ok {date} rows={len(df)} codes={df['code'].nunique()}"


def main():
    parser = argparse.ArgumentParser(
        description="Deepzone 分层挂单/撤单因子（单日，股票级并行）")
    parser.add_argument("--date", type=str, default="20250822",
                        help="交易日 YYYYMMDD（只处理这一天）")
    parser.add_argument("--max-workers", type=int, default=100,
                        help="单日内对股票并行的进程数，默认 100")
    args = parser.parse_args()

    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")

    cfg = Config()
    cfg.MAX_WORKERS = args.max_workers
    logger.info("处理交易日 %s，股票级并行 max_workers=%d", args.date, cfg.MAX_WORKERS)
    process_day(args.date, cfg)


if __name__ == "__main__":
    import shutil, os, stat
    _src = Path(__file__).resolve()
    _dst = Path(Config.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "") / _src.name
    if not _dst.exists():
        _dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(_src, _dst)
        os.chmod(_dst, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    main()
