#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
factor2.py —— 猛拉溢价率因子 + 撤单犹豫度因子。

基于 order+trans+lob 一体长表构造，严格复用 factor1.py 框架。

因子 1：猛拉溢价率（rushpct_acttrd）
-------------------------------------
- acttrd_B: 买委托(functionCode=='B') 且 下一行是成交(orderKind.shift(-1)=='T')
- rush_acttrd_B: acttrd_B 且 orderPrice > sp2（委托价超过卖二价，即猛拉）
- rushpct_acttrd_B: (orderPrice - sp2) / sp2，仅在 rush_acttrd_B 行有值
- 对称构造 S 方向：acttrd_S 且 orderPrice < bp2
- rushpct_acttrd_S: (bp2 - orderPrice) / bp2
- 输出：rushpct_acttrd_prob_BSimb, cntrush_acttrd_prob_BSimb

因子 2：撤单犹豫度（cxl1）
---------------------------
- 撤单行: functionCode=='C'
- 撤买方向: bidOrder > 0（askOrder==0）
- 撤卖方向: askOrder > 0（bidOrder==0）
- 撤1档判断：撤后盘口量减少了 size 且价格不变
  - 撤买1档: bv1(before) - bv1(after) == size 且 bp1 不变
  - 撤卖1档: sv1(before) - sv1(after) == size 且 sp1 不变
  （盘口是 after-event 快照，before = shift(1)）
- shrinkGap_cxl1_B/S: 撤1档事件相邻时间差的 log(1/(gap+0.01))，cum_ewm
- size_cxl1_prob: cxl1 的 size 占所有 cxl 的 size 的 cum_ewm 比值
- cnt_cxl1_prob: cxl1 的笔数占所有 cxl 笔数的 cum_ewm 比值
- 输出：shrinkGap_cxl1_BSimb, size_cxl1_prob_BSimb, cnt_cxl1_prob_BSimb
"""

from __future__ import annotations

import argparse
import logging
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("hft.factor2")


class Config:
    # 一体长表目录（含 sz_ordertranlob / sh_ordertranlob 两个子目录）
    RAW_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/raw_long_table"
    MARKETS = ("sz", "sh")
    OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft/factors"

    HL_LEVEL1 = 500         # 猛拉 / 撤单 计数与量
    HL_GAP_LONG = 500       # shrinkGap 分母
    MAX_WORKERS = 100

    # 连续竞价时段（含端点），HHMMSSmmm
    AM_START, AM_END = 93000000, 113000000
    PM_START, PM_END = 130000000, 145700000

    # 读长表只取需要的列，省内存
    LACOLS = ['LA10', 'LA3600', 'LA43200', 'LA60', 'LAEOD', 'LAEOD1', 'LAEOD2',
       'LAEOD5', 'LASVWAP1', 'LASVWAP2', 'LASVWAP5']
    # 新增 bp2/sp2 用于猛拉判断
    # 注：新长表 schema 与旧版差异较大，这里读入新字段，
    # 下方 _read_long_table 末尾会做兼容映射。
    USE_COLS = ["code", "time", "date", "type", "side",
                "volume", "sellorder", "buyorder",
                "price", "size", "seq_num", "number",
                "bp1", "sp1", "bv1", "sv1",
                "bp2", "sp2", "price_lob"] + LACOLS


def time_to_sec(t: np.ndarray) -> np.ndarray:
    """逐笔 time(HHMMSSmmm) -> 当日秒数(float)。"""
    t = t.astype("int64")
    ms = t % 1000
    rest = t // 1000
    s = rest % 100
    rest = rest // 100
    m = rest % 100
    h = rest // 100
    return (h * 3600 + m * 60 + s + ms / 1000.0).astype("float64")


def cumsum_minus_ewm(values: np.ndarray, halflife: float) -> np.ndarray:
    """cumsumfromopen(x) - cumsumfromopen(x).ewm(halflife).mean()。

    NaN 表示该事件不计入（cumsum 按 0 处理）。返回与 values 等长数组。
    """
    s = pd.Series(values, dtype="float64")
    cum = s.fillna(0.0).cumsum()
    ewm = cum.ewm(halflife=halflife, adjust=False, ignore_na=True).mean()
    return (cum - ewm).to_numpy()


def _ratio(a: pd.Series, b: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / b


def _bsimb(b: pd.Series, s: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b - s) / (b + s)


def _one_stock(date: str, code: str, tbl_df: pd.DataFrame, cfg: Config) -> pd.DataFrame | None:
    """单股票：在一体长表（已按事件升序）上计算猛拉溢价率 + 撤单犹豫度因子。"""
    if tbl_df.empty:
        return None

    tbl_df = tbl_df.sort_values(["time", "seq_num"]).reset_index(drop=True)
    out = tbl_df[["date", "code", "time", "seq_num"] + cfg.LACOLS].copy()

    tbl_df['sp1'] = np.where(tbl_df['sp1']<=0, tbl_df["bp1"]*0.7, tbl_df['sp1'])
    tbl_df['bp1'] = np.where(tbl_df['bp1']>5*tbl_df['sp1'], tbl_df['sp1']*1.3, tbl_df['sp1'])
    tbl_df['orderPrice'] = np.where((tbl_df['orderKind'].astype(str)=="1") & (tbl_df['functionCode']=='B'), tbl_df['price_lob']*1.3, 
                                        np.where((tbl_df['orderKind'].astype(str)=="1") & (tbl_df['functionCode']=='S'), tbl_df['price_lob'] * 0.7, tbl_df['orderPrice']))
    tbl_df['orderPrice'] = np.where((tbl_df['orderKind'].astype(str)=="U") & (tbl_df['functionCode']=='B'), tbl_df['price_lob'], 
                                        np.where((tbl_df['orderKind'].astype(str)=="U") & (tbl_df['functionCode']=='S'), tbl_df['price_lob'], tbl_df['orderPrice']))


    fc = tbl_df["functionCode"].astype(str)
    o_is_buy = fc == "B"
    o_is_sell = fc == "S"

    def cum_ewm(col: str, hl: float) -> pd.Series:
        """对长表的某列做 cumsum-ewm。"""
        return pd.Series(cumsum_minus_ewm(tbl_df[col].to_numpy("float64"), hl),
                         index=tbl_df.index)

    # ==========================================================================
    # 因子1：猛拉溢价率（rushpct_acttrd）
    # ==========================================================================
    # 主动买/卖委托：委托行且下一行是成交
    acttrd_B = o_is_buy & (tbl_df["orderKind"].shift(-1) == "T")
    acttrd_S = o_is_sell & (tbl_df["orderKind"].shift(-1) == "T")
    # 猛拉买：委托价超过卖二价 sp2（sp2>0 有效守卫）
    rush_acttrd_B = acttrd_B & (tbl_df["sp2"] > 0) & (tbl_df["orderPrice"] > tbl_df["sp2"])
    # 猛拉卖：委托价低于买二价 bp2（bp2>0 有效守卫）
    rush_acttrd_S = acttrd_S & (tbl_df["bp2"] > 0) & (tbl_df["orderPrice"] < tbl_df["bp2"])

    # 猛拉溢价率：买方 = (orderPrice - sp2) / sp2；卖方 = (bp2 - orderPrice) / bp2
    tbl_df["rushpct_acttrd_B"] = (
        (tbl_df["orderPrice"] - tbl_df["sp2"]) / tbl_df["sp2"]
    ).where(rush_acttrd_B, np.nan)
    tbl_df["rushpct_acttrd_S"] = (
        (tbl_df["bp2"] - tbl_df["orderPrice"]) / tbl_df["bp2"]
    ).where(rush_acttrd_S, np.nan)

    # 猛拉笔数
    tbl_df["cnt_rush_acttrd_B"] = rush_acttrd_B.astype("float64").where(rush_acttrd_B, np.nan)
    tbl_df["cnt_rush_acttrd_S"] = rush_acttrd_S.astype("float64").where(rush_acttrd_S, np.nan)

    # 主动委托笔数（作为分母）
    tbl_df["cnt_acttrd_B"] = acttrd_B.astype("float64").where(acttrd_B, np.nan)
    tbl_df["cnt_acttrd_S"] = acttrd_S.astype("float64").where(acttrd_S, np.nan)

    # cum_ewm
    tbl_df["f_rushpct_B"] = cum_ewm("rushpct_acttrd_B", cfg.HL_LEVEL1)
    tbl_df["f_rushpct_S"] = cum_ewm("rushpct_acttrd_S", cfg.HL_LEVEL1)
    tbl_df["f_cnt_rush_B"] = cum_ewm("cnt_rush_acttrd_B", cfg.HL_LEVEL1)
    tbl_df["f_cnt_rush_S"] = cum_ewm("cnt_rush_acttrd_S", cfg.HL_LEVEL1)
    tbl_df["f_cnt_acttrd_B"] = cum_ewm("cnt_acttrd_B", cfg.HL_LEVEL1)
    tbl_df["f_cnt_acttrd_S"] = cum_ewm("cnt_acttrd_S", cfg.HL_LEVEL1)

    # rushpct_acttrd_prob = 猛拉溢价率累计 / 猛拉笔数累计 （每笔平均溢价率）
    tbl_df["rushpct_acttrd_B_prob"] = _ratio(tbl_df["f_rushpct_B"], tbl_df["f_cnt_rush_B"])
    tbl_df["rushpct_acttrd_S_prob"] = _ratio(tbl_df["f_rushpct_S"], tbl_df["f_cnt_rush_S"])
    out["rushpct_acttrd_prob_BSimb"] = _bsimb(
        tbl_df["rushpct_acttrd_B_prob"],
        tbl_df["rushpct_acttrd_S_prob"])

    # cntrush_acttrd_prob = 猛拉笔数 / 全部主动委托笔数
    tbl_df["cntrush_acttrd_B_prob"] = _ratio(tbl_df["f_cnt_rush_B"], tbl_df["f_cnt_acttrd_B"])
    tbl_df["cntrush_acttrd_S_prob"] = _ratio(tbl_df["f_cnt_rush_S"], tbl_df["f_cnt_acttrd_S"])
    out["cntrush_acttrd_prob_BSimb"] = _bsimb(
        tbl_df["cntrush_acttrd_B_prob"],
        tbl_df["cntrush_acttrd_S_prob"])

    # sizerush_acttrd_prob = 猛拉 size / 全部主动委托 size
    tbl_df["size_rush_acttrd_B"] = tbl_df["size"].where(rush_acttrd_B, np.nan)
    tbl_df["size_rush_acttrd_S"] = tbl_df["size"].where(rush_acttrd_S, np.nan)
    tbl_df["size_acttrd_B"] = tbl_df["size"].where(acttrd_B, np.nan)
    tbl_df["size_acttrd_S"] = tbl_df["size"].where(acttrd_S, np.nan)
    tbl_df["f_size_rush_B"] = cum_ewm("size_rush_acttrd_B", cfg.HL_LEVEL1)
    tbl_df["f_size_rush_S"] = cum_ewm("size_rush_acttrd_S", cfg.HL_LEVEL1)
    tbl_df["f_size_acttrd_B"] = cum_ewm("size_acttrd_B", cfg.HL_LEVEL1)
    tbl_df["f_size_acttrd_S"] = cum_ewm("size_acttrd_S", cfg.HL_LEVEL1)
    tbl_df["sizerush_acttrd_B_prob"] = _ratio(tbl_df["f_size_rush_B"], tbl_df["f_size_acttrd_B"])
    tbl_df["sizerush_acttrd_S_prob"] = _ratio(tbl_df["f_size_rush_S"], tbl_df["f_size_acttrd_S"])
    out["sizerush_acttrd_prob_BSimb"] = _bsimb(
        tbl_df["sizerush_acttrd_B_prob"],
        tbl_df["sizerush_acttrd_S_prob"])

    # ==========================================================================
    # 因子2：撤单犹豫度（cxl1 = 只撤1档位的撤单）
    # ==========================================================================
    is_cxl = fc == "C"
    # 撤买方向：bidOrder>0 & askOrder==0
    cxl_is_buy = is_cxl & (tbl_df["bidOrder"] > 0)
    # 撤卖方向：askOrder>0 & bidOrder==0
    cxl_is_sell = is_cxl & (tbl_df["askOrder"] > 0)

    # 盘口是 after-event 快照，before = shift(1)
    bv1_before = tbl_df["bv1"].shift(1)
    sv1_before = tbl_df["sv1"].shift(1)
    bp1_before = tbl_df["bp1"].shift(1)
    sp1_before = tbl_df["sp1"].shift(1)

    # 撤买1档：bv1 减少(>0) 且 bp1 不变（撤的是一档上的量）
    bv1_drop = bv1_before - tbl_df["bv1"]
    sv1_drop = sv1_before - tbl_df["sv1"]
    cxl1_buy = cxl_is_buy & (bv1_drop > 0) & (tbl_df["bp1"] == bp1_before)
    # 撤买全档：撤单后 bp1 下降（一档被撤空导致换档）
    cxlall_buy = cxl_is_buy & (tbl_df["bp1"] < bp1_before)
    # 撤买1档或全档
    cxl1all_buy = cxl1_buy | cxlall_buy

    # 撤卖1档：sv1 减少(>0) 且 sp1 不变
    cxl1_sell = cxl_is_sell & (sv1_drop > 0) & (tbl_df["sp1"] == sp1_before)
    # 撤卖全档：撤单后 sp1 上升（一档被撤空导致换档）
    cxlall_sell = cxl_is_sell & (tbl_df["sp1"] > sp1_before)
    # 撤卖1档或全档
    cxl1all_sell = cxl1_sell | cxlall_sell

    # ---- 撤1档 size / cnt ----
    tbl_df["size_cxl1_B"] = tbl_df["size"].where(cxl1_buy, np.nan)
    tbl_df["size_cxl1_S"] = tbl_df["size"].where(cxl1_sell, np.nan)
    tbl_df["cnt_cxl1_B"] = cxl1_buy.astype("float64").where(cxl1_buy, np.nan)
    tbl_df["cnt_cxl1_S"] = cxl1_sell.astype("float64").where(cxl1_sell, np.nan)

    # ---- 撤全档 size / cnt ----
    tbl_df["size_cxlall_B"] = tbl_df["size"].where(cxlall_buy, np.nan)
    tbl_df["size_cxlall_S"] = tbl_df["size"].where(cxlall_sell, np.nan)
    tbl_df["cnt_cxlall_B"] = cxlall_buy.astype("float64").where(cxlall_buy, np.nan)
    tbl_df["cnt_cxlall_S"] = cxlall_sell.astype("float64").where(cxlall_sell, np.nan)

    # ---- 撤1档或全档 size / cnt ----
    tbl_df["size_cxl1all_B"] = tbl_df["size"].where(cxl1all_buy, np.nan)
    tbl_df["size_cxl1all_S"] = tbl_df["size"].where(cxl1all_sell, np.nan)
    tbl_df["cnt_cxl1all_B"] = cxl1all_buy.astype("float64").where(cxl1all_buy, np.nan)
    tbl_df["cnt_cxl1all_S"] = cxl1all_sell.astype("float64").where(cxl1all_sell, np.nan)

    # ---- 所有撤单 size / cnt（作为分母）----
    tbl_df["size_cxl_B"] = tbl_df["size"].where(cxl_is_buy, np.nan)
    tbl_df["size_cxl_S"] = tbl_df["size"].where(cxl_is_sell, np.nan)
    tbl_df["cnt_cxl_B"] = cxl_is_buy.astype("float64").where(cxl_is_buy, np.nan)
    tbl_df["cnt_cxl_S"] = cxl_is_sell.astype("float64").where(cxl_is_sell, np.nan)

    # cum_ewm：cxl1 / cxlall / cxl1all / cxl(全部)
    tbl_df["f_size_cxl1_B"] = cum_ewm("size_cxl1_B", cfg.HL_LEVEL1)
    tbl_df["f_size_cxl1_S"] = cum_ewm("size_cxl1_S", cfg.HL_LEVEL1)
    tbl_df["f_cnt_cxl1_B"] = cum_ewm("cnt_cxl1_B", cfg.HL_LEVEL1)
    tbl_df["f_cnt_cxl1_S"] = cum_ewm("cnt_cxl1_S", cfg.HL_LEVEL1)

    tbl_df["f_size_cxlall_B"] = cum_ewm("size_cxlall_B", cfg.HL_LEVEL1)
    tbl_df["f_size_cxlall_S"] = cum_ewm("size_cxlall_S", cfg.HL_LEVEL1)
    tbl_df["f_cnt_cxlall_B"] = cum_ewm("cnt_cxlall_B", cfg.HL_LEVEL1)
    tbl_df["f_cnt_cxlall_S"] = cum_ewm("cnt_cxlall_S", cfg.HL_LEVEL1)

    tbl_df["f_size_cxl1all_B"] = cum_ewm("size_cxl1all_B", cfg.HL_LEVEL1)
    tbl_df["f_size_cxl1all_S"] = cum_ewm("size_cxl1all_S", cfg.HL_LEVEL1)
    tbl_df["f_cnt_cxl1all_B"] = cum_ewm("cnt_cxl1all_B", cfg.HL_LEVEL1)
    tbl_df["f_cnt_cxl1all_S"] = cum_ewm("cnt_cxl1all_S", cfg.HL_LEVEL1)

    tbl_df["f_size_cxl_B"] = cum_ewm("size_cxl_B", cfg.HL_LEVEL1)
    tbl_df["f_size_cxl_S"] = cum_ewm("size_cxl_S", cfg.HL_LEVEL1)
    tbl_df["f_cnt_cxl_B"] = cum_ewm("cnt_cxl_B", cfg.HL_LEVEL1)
    tbl_df["f_cnt_cxl_S"] = cum_ewm("cnt_cxl_S", cfg.HL_LEVEL1)

    # ---- size_cxl1_prob = cxl1_size / cxl_size ----
    tbl_df["size_cxl1_B_prob"] = _ratio(tbl_df["f_size_cxl1_B"], tbl_df["f_size_cxl_B"])
    tbl_df["size_cxl1_S_prob"] = _ratio(tbl_df["f_size_cxl1_S"], tbl_df["f_size_cxl_S"])
    out["size_cxl1_prob_BSimb"] = _bsimb(
        tbl_df["size_cxl1_B_prob"],
        tbl_df["size_cxl1_S_prob"])

    # ---- cnt_cxl1_prob = cxl1_cnt / cxl_cnt ----
    tbl_df["cnt_cxl1_B_prob"] = _ratio(tbl_df["f_cnt_cxl1_B"], tbl_df["f_cnt_cxl_B"])
    tbl_df["cnt_cxl1_S_prob"] = _ratio(tbl_df["f_cnt_cxl1_S"], tbl_df["f_cnt_cxl_S"])
    out["cnt_cxl1_prob_BSimb"] = _bsimb(
        tbl_df["cnt_cxl1_B_prob"],
        tbl_df["cnt_cxl1_S_prob"])

    # ---- size_cxlall_prob = cxlall_size / cxl_size ----
    tbl_df["size_cxlall_B_prob"] = _ratio(tbl_df["f_size_cxlall_B"], tbl_df["f_size_cxl_B"])
    tbl_df["size_cxlall_S_prob"] = _ratio(tbl_df["f_size_cxlall_S"], tbl_df["f_size_cxl_S"])
    out["size_cxlall_prob_BSimb"] = _bsimb(
        tbl_df["size_cxlall_B_prob"],
        tbl_df["size_cxlall_S_prob"])

    # ---- cnt_cxlall_prob = cxlall_cnt / cxl_cnt ----
    tbl_df["cnt_cxlall_B_prob"] = _ratio(tbl_df["f_cnt_cxlall_B"], tbl_df["f_cnt_cxl_B"])
    tbl_df["cnt_cxlall_S_prob"] = _ratio(tbl_df["f_cnt_cxlall_S"], tbl_df["f_cnt_cxl_S"])
    out["cnt_cxlall_prob_BSimb"] = _bsimb(
        tbl_df["cnt_cxlall_B_prob"],
        tbl_df["cnt_cxlall_S_prob"])

    # ---- size_cxl1all_prob = cxl1all_size / cxl_size ----
    tbl_df["size_cxl1all_B_prob"] = _ratio(tbl_df["f_size_cxl1all_B"], tbl_df["f_size_cxl_B"])
    tbl_df["size_cxl1all_S_prob"] = _ratio(tbl_df["f_size_cxl1all_S"], tbl_df["f_size_cxl_S"])
    out["size_cxl1all_prob_BSimb"] = _bsimb(
        tbl_df["size_cxl1all_B_prob"],
        tbl_df["size_cxl1all_S_prob"])

    # ---- cnt_cxl1all_prob = cxl1all_cnt / cxl_cnt ----
    tbl_df["cnt_cxl1all_B_prob"] = _ratio(tbl_df["f_cnt_cxl1all_B"], tbl_df["f_cnt_cxl_B"])
    tbl_df["cnt_cxl1all_S_prob"] = _ratio(tbl_df["f_cnt_cxl1all_S"], tbl_df["f_cnt_cxl_S"])
    out["cnt_cxl1all_prob_BSimb"] = _bsimb(
        tbl_df["cnt_cxl1all_B_prob"],
        tbl_df["cnt_cxl1all_S_prob"])

    # shrinkGap_cxl1：撤1档事件相邻时间差的 log(1/(gap+0.01))，cum_ewm
    sec = time_to_sec(tbl_df["time"].to_numpy("int64"))

    cxl1_buy_gap = np.full(len(tbl_df), np.nan)
    cxl1_sell_gap = np.full(len(tbl_df), np.nan)

    buy_pos = np.where(cxl1_buy)[0]
    sell_pos = np.where(cxl1_sell)[0]

    if buy_pos.size >= 2:
        cxl1_buy_gap[buy_pos[1:]] = np.diff(sec[buy_pos])
    if sell_pos.size >= 2:
        cxl1_sell_gap[sell_pos[1:]] = np.diff(sec[sell_pos])

    tbl_df["gap_cxl1_B"] = np.log(1.0 / (cxl1_buy_gap + 0.01))
    tbl_df["gap_cxl1_S"] = np.log(1.0 / (cxl1_sell_gap + 0.01))

    out["shrinkGap_cxl1_B"] = cum_ewm("gap_cxl1_B", cfg.HL_GAP_LONG)
    out["shrinkGap_cxl1_S"] = cum_ewm("gap_cxl1_S", cfg.HL_GAP_LONG)
    # 仿照 factor1 的 shrinkGap_trdact_BSimb 写法，分母用 abs 之和加 0.1 防止除零极值
    out["shrinkGap_cxl1_BSimb"] = out.eval(
        "(shrinkGap_cxl1_B - shrinkGap_cxl1_S) / (abs(shrinkGap_cxl1_B) + abs(shrinkGap_cxl1_S) + 0.1)")

    return out[::100]


def _read_long_table(date: str, cfg: Config) -> pd.DataFrame:
    """读取沪深一体长表，在读取层(parquet filters)就只取连续竞价时段。"""
    time_filters = [
        [("time", ">=", cfg.AM_START), ("time", "<=", cfg.AM_END)],
        [("time", ">=", cfg.PM_START), ("time", "<=", cfg.PM_END)],
    ]
    frames = []
    for market in cfg.MARKETS:
        path = Path(cfg.RAW_DIR) / f"{market}_ordertranlob" / f"{date}.parquet"
        if not path.exists():
            continue
        df = pd.read_parquet(path, columns=cfg.USE_COLS, filters=time_filters)
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["code"] = df["code"].astype(str)
    df["time"] = df["time"].astype("int64")

    # ====================================================================
    # === schema 兼容层：新长表字段 → 旧因子代码使用的字段名 ===
    # ====================================================================
    price_cols = ["price", "price_lob",
                  "bp1", "bp2", "bp3", "bp4", "bp5",
                  "sp1", "sp2", "sp3", "sp4", "sp5"]
    for c in price_cols:
        if c in df.columns:
            v = df[c].astype("float64").to_numpy()
            v = np.where(np.isnan(v) | (v <= 0), -10000.0, v * 10000.0)
            df[c] = v.astype("int64")

    type_s = df["type"].astype(str)
    side_s = df["side"].astype(str).where(df["side"].notna(), "")
    is_trade = (type_s == "T").to_numpy()
    is_cxl = (type_s == "D").to_numpy()
    fc = np.where(is_cxl, "C", np.where(~is_trade, side_s.to_numpy(), ""))
    df["functionCode"] = fc
    df["orderKind"] = type_s.to_numpy()
    df["orderPrice"] = df["price"]
    df["orderVolume"] = df["volume"]
    df["bidOrder"] = df["buyorder"]
    df["askOrder"] = df["sellorder"]
    df["order"] = df["number"]

    return df


def _one_stock_worker(args):
    """进程池工作函数：解包参数后调用 _one_stock。"""
    date, code, sub_df, cfg = args
    return _one_stock(date, code, sub_df, cfg)


def build_one_day(date: str, cfg: Config) -> pd.DataFrame:
    """单日：读一体长表，对每只股票并行计算因子。"""
    table_df = _read_long_table(date, cfg)
    if table_df.empty:
        logger.warning("%s 无长表数据，跳过", date)
        return pd.DataFrame()

    groups = list(table_df.groupby("code", sort=False))
    logger.info("%s 股票数=%d，单日内并行 max_workers=%d", date, len(groups), cfg.MAX_WORKERS)

    frames = []
    max_workers = max(1, int(cfg.MAX_WORKERS))
    if max_workers == 1:
        for code, sub_df in tqdm(groups, desc=date):
            frame = _one_stock(date, str(code), sub_df, cfg)
            if frame is not None and not frame.empty:
                frames.append(frame)
    else:
        tasks = [(date, str(code), sub_df, cfg) for code, sub_df in groups]
        with ProcessPoolExecutor(max_workers=max_workers) as ex:
            futures = {ex.submit(_one_stock_worker, t): t[1] for t in tasks}
            for fut in tqdm(as_completed(futures), total=len(futures), desc=date):
                code = futures[fut]
                try:
                    frame = fut.result()
                except Exception as exc:
                    logger.exception("%s %s 计算失败：%s", date, code, exc)
                    raise
                if frame is not None and not frame.empty:
                    frames.append(frame)

    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def process_day(date: str, cfg: Config) -> str:
    """处理单个交易日并保存；已存在则跳过(断点恢复)。"""
    by_date_dir = Path(cfg.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "")
    by_date_dir.mkdir(parents=True, exist_ok=True)
    out_path = by_date_dir / f"factor2_{date}.parquet"
    if out_path.exists():
        logger.info("skip %s（已存在）", date)
        return f"skip {date}"

    df = build_one_day(date, cfg)
    if df.empty:
        logger.warning("empty %s", date)
        return f"empty {date}"
    df.to_parquet(out_path, index=False)
    logger.info("ok %s rows=%d codes=%d -> %s", date, len(df), df["code"].nunique(), out_path)
    return f"ok {date} rows={len(df)} codes={df['code'].nunique()}"


def main():
    parser = argparse.ArgumentParser(description="猛拉溢价率 + 撤单犹豫度因子（单日，股票级并行）")
    parser.add_argument("--date", type=str, default="20250822", help="交易日 YYYYMMDD（只处理这一天）")
    parser.add_argument("--max-workers", type=int, default=100,
                        help="单日内对股票并行的进程数，默认 100")
    args = parser.parse_args()

    if args.max_workers < 1:
        parser.error("--max-workers 必须 >= 1")

    cfg = Config()
    cfg.MAX_WORKERS = args.max_workers
    logger.info("处理交易日 %s，股票级并行 max_workers=%d", args.date, cfg.MAX_WORKERS)
    process_day(args.date, cfg)


if __name__ == "__main__":
    import shutil, os, stat
    _src = Path(__file__).resolve()
    _dst = Path(Config.OUTPUT_DIR) / __file__.split("/")[-1].replace(".py", "") / _src.name
    if not _dst.exists():
        _dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(_src, _dst)
        os.chmod(_dst, stat.S_IRUSR | stat.S_IWUSR)  # 0o600
    main()
