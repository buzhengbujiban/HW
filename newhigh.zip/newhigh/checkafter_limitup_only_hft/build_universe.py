"""
step0 —— 从 checkafterbase_limitup 选股池构造 universe pkl（供后续 extract 复用）。

为什么从 checkafterbase_limitup：
  checkafterbase_limitup 是最宽的"破前高+涨停回踩"基础池，checkafterbase56 /
  checkafterbase56_add5 等都是它的子集。在它上面 extract 出 lob/ordertrans 并算
  raw_long_table 后，后续所有子集策略都能直接复用同一份 raw_long_table，不必重复抽取。

输入：
  /home/datamake119/data1/user118/newhigh/checkafterbase_limitup/segments_daily/{date}.parquet
    （字段含 date, code(6位), limit_up_price, ...）

输出：
  {NEW_ROOT}/daily_results/{date}.pkl
    结构：{"date": date, "universe_codes": [6位纯代码, ...]}
    —— 与 build_up_7 的 daily_results 同构，使 extract_lob.py / extract_ordertrans.py
       能以同样的方式读取 universe。

用法：
  python build_universe.py --date 20250121      # 单日
  python build_universe.py --all                # 全部可用日
  # echo 并行：
  #   ls .../checkafterbase_limitup/segments_daily | sed 's/.parquet//' \
  #     | xargs -P 24 -I{} python build_universe.py --date {}
"""

from __future__ import annotations

import os
import glob
import pickle
import logging
import argparse

import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ========== 路径 ==========
POOL_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only/segments_daily"

# 本 hft 管线专用的数据根目录（lob/ordertrans/lags/raw_long_table 都放这里）
NEW_ROOT = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft"
DAILY_DIR = os.path.join(NEW_ROOT, "daily_results")


def build_one(date_int: str) -> int:
    pool_path = os.path.join(POOL_DIR, f"{date_int}.parquet")
    if not os.path.exists(pool_path):
        logger.info("日期 %s: 选股池 parquet 不存在", date_int)
        return 0
    df = pd.read_parquet(pool_path, columns=["date", "code"])
    if df.empty:
        logger.info("日期 %s: 选股池为空", date_int)
        codes = []
    else:
        codes = sorted(set(df["code"].astype(str).str.zfill(6).tolist()))

    os.makedirs(DAILY_DIR, exist_ok=True)
    out_path = os.path.join(DAILY_DIR, f"{date_int}.pkl")
    with open(out_path, "wb") as f:
        pickle.dump({"date": date_int, "universe_codes": codes}, f)
    logger.info("日期 %s: 写出 universe %d 只 -> %s", date_int, len(codes), out_path)
    return len(codes)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, default=None, help="交易日 YYYYMMDD")
    parser.add_argument("--all", action="store_true", help="处理 POOL_DIR 下全部日期")
    args = parser.parse_args()

    if args.all:
        files = sorted(glob.glob(os.path.join(POOL_DIR, "*.parquet")))
        dates = [os.path.basename(f).replace(".parquet", "") for f in files]
        logger.info("共 %d 个交易日待构造 universe", len(dates))
        for d in dates:
            build_one(d)
    elif args.date:
        build_one(args.date)
    else:
        parser.error("请提供 --date 或 --all")


if __name__ == "__main__":
    main()
