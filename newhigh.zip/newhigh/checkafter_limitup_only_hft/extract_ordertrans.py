"""
step1b —— 提取 checkbase universe 股票的 ordertrans 数据（沪深分开）。

ordertrans 原始数据路径：
  sh: /mnt/localdisk/sdb/lwyxyz/2.79/ftp/mdl_fea/order_trans_sh/{YYYYMMDD}.fea
  sz: /mnt/localdisk/sdb/lwyxyz/2.79/ftp/mdl_fea/order_trans_sz/{YYYYMMDD}.fea

输出（沪深分开）：
  sh: {NEW_ROOT}/ordertrans_sh/{YYYYMMDD}_ordertrans.fea
  sz: {NEW_ROOT}/ordertrans_sz/{YYYYMMDD}_ordertrans.fea

用法：
  python extract_ordertrans.py --date 20250121
  # echo 并行：
  #   ls {NEW_ROOT}/daily_results | sed 's/.pkl//' \
  #     | xargs -P 24 -I{} python extract_ordertrans.py --date {}

实现沿用 build_up_7/extract_ordertrans.py 的 pyarrow.feather + compute.is_in 过滤，
仅改动 universe 来源目录与输出目录。
"""

from __future__ import annotations

import os
import pickle
import logging
import argparse
import time
from concurrent.futures import ThreadPoolExecutor

import pandas as pd
import pyarrow as pa
import pyarrow.feather as feather
import pyarrow.compute as pc

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ========== 参数 ==========
NEW_ROOT = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft"
DAILY_DIR = os.path.join(NEW_ROOT, "daily_results")

ORDERTRANS_SH_DIR = "/mnt/localdisk/sdb/lwyxyz/2.79/ftp/mdl_fea/order_trans_sh"
ORDERTRANS_SZ_DIR = "/mnt/localdisk/sdb/lwyxyz/2.79/ftp/mdl_fea/order_trans_sz"

OUTPUT_ORDERTRANS_SH_DIR = os.path.join(NEW_ROOT, "ordertrans_sh")
OUTPUT_ORDERTRANS_SZ_DIR = os.path.join(NEW_ROOT, "ordertrans_sz")


def _read_and_save_ordertrans(src_path, codes_str, market_tag, out_path) -> int:
    """读取单市场 ordertrans feather，按 code 过滤后写盘。返回行数。"""
    if not os.path.exists(src_path):
        logger.info("  %s ordertrans 文件不存在: %s", market_tag, src_path)
        return 0
    if not codes_str:
        return 0

    t0 = time.time()
    table = None
    try:
        table_full = feather.read_table(src_path, memory_map=True)
        code_col = table_full["code"]
        code_type = code_col.type
        if pa.types.is_dictionary(code_type):
            value_type = code_type.value_type
            code_col = pc.cast(code_col, value_type)
        else:
            value_type = code_type
        code_arr = pa.array(codes_str, type=value_type)
        mask = pc.is_in(code_col, value_set=code_arr)
        table = table_full.filter(mask)
        logger.info("  %s ordertrans: %d 条 (arrow 过滤, %.2fs)",
                    market_tag, table.num_rows, time.time() - t0)
    except Exception as exc:
        logger.warning("  %s ordertrans arrow 过滤失败，回退 pandas: %s", market_tag, exc)
        table = None

    if table is None:
        df_full = pd.read_feather(src_path, use_threads=True)
        df = df_full[df_full["code"].isin(set(codes_str))]
        if df.empty:
            logger.info("  %s ordertrans: 无匹配记录", market_tag)
            return 0
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        df.reset_index(drop=True).to_feather(out_path)
        logger.info("  %s ordertrans: 已保存 %d 条到 %s (pandas)", market_tag, len(df), out_path)
        return len(df)

    if table.num_rows == 0:
        logger.info("  %s ordertrans: 无匹配记录", market_tag)
        return 0

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    feather.write_feather(table, out_path)
    logger.info("  %s ordertrans: 已保存 %d 条到 %s", market_tag, table.num_rows, out_path)
    return table.num_rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, required=True, help="交易日 YYYYMMDD")
    args = parser.parse_args()
    date_int = args.date

    result_path = os.path.join(DAILY_DIR, f"{date_int}.pkl")
    if not os.path.exists(result_path):
        logger.info("日期 %s: 无 universe 结果", date_int)
        return
    with open(result_path, "rb") as f:
        result = pickle.load(f)
    universe_codes = result.get("universe_codes", [])
    if not universe_codes:
        logger.info("日期 %s: universe 为空", date_int)
        return

    logger.info("日期 %s: %d 只股票需要提取 ordertrans", date_int, len(universe_codes))

    # ordertrans 的 code 列格式：'600000.SH' / '000001.SZ'
    sh_codes = [f"{c}.SH" for c in universe_codes if c.startswith("6")]
    sz_codes = [f"{c}.SZ" for c in universe_codes if not c.startswith("6")]

    tasks = []
    if sh_codes:
        tasks.append(("SH", os.path.join(ORDERTRANS_SH_DIR, f"{date_int}.fea"),
                      sh_codes, os.path.join(OUTPUT_ORDERTRANS_SH_DIR, f"{date_int}_ordertrans.fea")))
    if sz_codes:
        tasks.append(("SZ", os.path.join(ORDERTRANS_SZ_DIR, f"{date_int}.fea"),
                      sz_codes, os.path.join(OUTPUT_ORDERTRANS_SZ_DIR, f"{date_int}_ordertrans.fea")))

    if not tasks:
        logger.info("日期 %s: 无可处理股票", date_int)
        return

    total_rows = 0
    with ThreadPoolExecutor(max_workers=len(tasks)) as ex:
        futures = [ex.submit(_read_and_save_ordertrans, src, codes, tag, out)
                   for tag, src, codes, out in tasks]
        for fut in futures:
            total_rows += fut.result()

    logger.info("日期 %s 提取完成，总计 %d 条 ordertrans 记录", date_int, total_rows)


if __name__ == "__main__":
    main()
