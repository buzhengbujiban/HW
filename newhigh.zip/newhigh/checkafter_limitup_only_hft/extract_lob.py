"""
step1a —— 提取 checkbase universe 股票的 LOB 数据（沪深都开）。

LOB 原始数据路径：
  sh: /mount/datamake118/lob_data/lob_data_sh/{YYYYMMDD}.parquet
  sz: /mount/datamake118/lob_data/lob_data_sz/{YYYYMMDD}.parquet

输出（沪深分开，供 lags + create_long_table 复用）：
  sh: {NEW_ROOT}/lob_sh/{YYYYMMDD}_lob.parquet
  sz: {NEW_ROOT}/lob_sz/{YYYYMMDD}_lob.parquet

用法：
  python extract_lob.py --date 20250121
  # echo 并行：
  #   ls {NEW_ROOT}/daily_results | sed 's/.pkl//' \
  #     | xargs -P 24 -I{} python extract_lob.py --date {}

实现沿用 build_up_7/extract_lob.py 的 pyarrow 谓词下推优化（row-group 剪枝），
仅改动 universe 来源目录与输出目录，并同时开启沪深两市。
"""

from __future__ import annotations

import os
import pickle
import logging
import argparse
import time
from concurrent.futures import ThreadPoolExecutor

import pandas as pd
import pyarrow.parquet as pq

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ========== 参数 ==========
NEW_ROOT = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft"
DAILY_DIR = os.path.join(NEW_ROOT, "daily_results")

LOB_SH_DIR = "/mount/datamake118/lob_data/lob_data_sh"
LOB_SZ_DIR = "/mount/datamake118/lob_data/lob_data_sz"

OUTPUT_LOB_SH_DIR = os.path.join(NEW_ROOT, "lob_sh")
OUTPUT_LOB_SZ_DIR = os.path.join(NEW_ROOT, "lob_sz")


def _read_and_save_lob(src_path, codes_int, market_tag, out_path) -> int:
    """读取单市场 LOB parquet，按 code 谓词下推过滤后写盘。返回行数。"""
    if not os.path.exists(src_path):
        logger.info("  %s LOB 文件不存在: %s", market_tag, src_path)
        return 0
    if not codes_int:
        return 0

    t0 = time.time()
    try:
        code_set = set(codes_int)
        table = pq.read_table(src_path, filters=[("code", "in", code_set)], use_threads=True)
        df = table.to_pandas(self_destruct=True)
        logger.info("  %s LOB: %d 条 (谓词下推, %.2fs)", market_tag, len(df), time.time() - t0)
    except Exception as exc:
        logger.warning("  %s LOB 谓词下推失败，回退全表读: %s", market_tag, exc)
        df_full = pd.read_parquet(src_path)
        df = df_full[df_full["code"].isin(set(codes_int))]
        logger.info("  %s LOB: %d 条 (回退)", market_tag, len(df))

    if df is None or df.empty:
        logger.info("  %s LOB: 无匹配记录", market_tag)
        return 0

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    df.to_parquet(out_path, index=False)
    logger.info("  %s LOB: 已保存 %d 条到 %s", market_tag, len(df), out_path)
    return len(df)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, default="20250430", help="交易日 YYYYMMDD")
    args = parser.parse_args()
    date_int = args.date

    result_path = os.path.join(DAILY_DIR, f"{date_int}.pkl")
    if not os.path.exists(result_path):
        logger.info("日期 %s: 无 universe 结果", date_int)
        return
    with open(result_path, "rb") as f:
        result = pickle.load(f)
    universe_codes = result.get("universe_codes", [])
    if not universe_codes:
        logger.info("日期 %s: universe 为空", date_int)
        return

    logger.info("日期 %s: %d 只股票需要提取 LOB", date_int, len(universe_codes))

    # LOB 的 code 列是 int32 纯数字
    sh_codes_int = [int(c) for c in universe_codes if c.startswith("6")]
    sz_codes_int = [int(c) for c in universe_codes if not c.startswith("6")]

    tasks = []
    if sh_codes_int:
        tasks.append(("SH", os.path.join(LOB_SH_DIR, f"{date_int}.parquet"),
                      sh_codes_int, os.path.join(OUTPUT_LOB_SH_DIR, f"{date_int}_lob.parquet")))
    if sz_codes_int:
        tasks.append(("SZ", os.path.join(LOB_SZ_DIR, f"{date_int}.parquet"),
                      sz_codes_int, os.path.join(OUTPUT_LOB_SZ_DIR, f"{date_int}_lob.parquet")))

    if not tasks:
        logger.info("日期 %s: 无可处理股票", date_int)
        return

    total_rows = 0
    with ThreadPoolExecutor(max_workers=len(tasks)) as ex:
        futures = [ex.submit(_read_and_save_lob, src, codes, tag, out)
                   for tag, src, codes, out in tasks]
        for fut in futures:
            total_rows += fut.result()

    logger.info("日期 %s 提取完成，总计 %d 条 LOB 记录", date_int, total_rows)


if __name__ == "__main__":
    main()
