"""
stock_pool_3 选股池简单回测

逻辑：
- fea 里的 date 是【信号日】（前一日），真正买入日 = date 之后第1个交易日。
- 买入日(=date 的下一个交易日，记作第1天) 以开盘价等权买入当日选出的所有股票。
- 卖出方式（口径B：买入日算第1天，第N天 = 买入日之后第 N-1 个交易日）：
    开盘卖出 label: 第2/3/5天开盘价卖出  -> 买入日偏移 1 / 2 / 4 日 open
    收盘卖出 label: 第1/2/4天收盘价卖出  -> 买入日偏移 0 / 1 / 3 日 close
- 每个 label 计算每个买入日的等权组合收益。
- 绘制两种收益曲线：
    A 累乘净值：把每个买入日当作一笔全仓独立交易，按买入日顺序累乘 (1+ret)
    B 累计求和：每笔收益不复投，按买入日累加 ret（衡量信号质量，不受复利放大影响）
- 价格使用复权数据（OPEN_PRICE_2 / CLOSE_PRICE_2）。

输出：各 label 的收益曲线图，保存在本目录。
"""

import logging
import os

import matplotlib
matplotlib.use("Agg")  # 无显示环境保存图片
import matplotlib.pyplot as plt
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger(__name__)

# ============================================================
# 路径配置
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
POOL_PATH = os.path.join(BASE_DIR, "stock_pool_1.fea")
OHLC_PATH = "/mnt/tonglian_data/ohlc_fea"
OPEN_PKL = os.path.join(OHLC_PATH, "OPEN_PRICE_2.pkl")    # 复权开盘价
CLOSE_PKL = os.path.join(OHLC_PATH, "CLOSE_PRICE_2.pkl")  # 复权收盘价
OUTPUT_IMG = os.path.join(BASE_DIR, "backtest_stock_pool_1.png")

# ============================================================
# 卖出口径配置（口径B：买入日 date 算第1天）
# 第N天 -> date 之后第 (N-1) 个交易日的偏移量
# ============================================================
OPEN_SELL_DAYS = [2, 3, 5]   # 开盘卖出：第2/3/5天
CLOSE_SELL_DAYS = [1, 2, 4]  # 收盘卖出：第1/2/4天


def load_prices():
    """读取复权开盘价、收盘价，索引统一为 YYYYMMDD 字符串"""
    open_price = pd.read_pickle(OPEN_PKL)
    close_price = pd.read_pickle(CLOSE_PKL)
    open_price.index = pd.to_datetime(open_price.index).strftime("%Y%m%d")
    close_price.index = pd.to_datetime(close_price.index).strftime("%Y%m%d")
    open_price.sort_index(inplace=True)
    close_price.sort_index(inplace=True)
    return open_price, close_price


def load_pool():
    """读取选股池，date/code 统一为字符串"""
    pool = pd.read_feather(POOL_PATH)
    pool["date"] = pool["date"].astype(str)
    pool["code"] = pool["code"].astype(str).str.zfill(6)
    return pool


def daily_equal_weight_return(codes, buy_price_row, sell_price_row):
    """
    计算某买入日选出股票的等权组合收益。
    buy_price_row / sell_price_row 为对应交易日的价格 Series(index=code)。
    返回 (组合收益, 有效股票数)。价格缺失或为0的股票剔除。
    """
    codes = [c for c in codes if c in buy_price_row.index and c in sell_price_row.index]
    if not codes:
        return None, 0

    buy = buy_price_row[codes]
    sell = sell_price_row[codes]

    # 剔除价格无效（NaN 或 <=0）的股票
    valid = buy.notna() & sell.notna() & (buy > 0) & (sell > 0)
    buy = buy[valid]
    sell = sell[valid]
    if len(buy) == 0:
        return None, 0

    ret = (sell / buy - 1.0)
    return ret.mean(), len(buy)


def backtest_one_label(pool, open_price, close_price, offset, sell_type):
    """
    对单个 label 回测。
    fea 里的 date 是信号日，真正买入日 = date 之后第1个交易日。
    offset: 卖出日相对买入日的交易日偏移（口径B 已转成偏移量）。
    sell_type: 'open' 或 'close'。
    返回 DataFrame(index=信号日 date, columns=['ret','n','buy_date'])。
    """
    trade_dates = open_price.index  # 全市场交易日（升序）
    date_pos = {d: i for i, d in enumerate(trade_dates)}

    records = {}
    grouped = pool.groupby("date")["code"].apply(list)

    for signal_date, codes in grouped.items():
        if signal_date not in date_pos:
            logger.warning("信号日 %s 不在价格交易日中，跳过", signal_date)
            continue

        # 买入日 = 信号日的下一个交易日
        buy_idx = date_pos[signal_date] + 1
        if buy_idx >= len(trade_dates):
            # 没有下一个交易日（数据末尾），跳过
            continue
        buy_date = trade_dates[buy_idx]

        sell_idx = buy_idx + offset
        if sell_idx >= len(trade_dates):
            # 卖出日超出数据范围，跳过
            continue
        sell_date = trade_dates[sell_idx]

        # 买入价：买入日开盘价；卖出价：开盘或收盘
        buy_row = open_price.loc[buy_date]
        if sell_type == "open":
            sell_row = open_price.loc[sell_date]
        else:
            sell_row = close_price.loc[sell_date]

        ret, n = daily_equal_weight_return(codes, buy_row, sell_row)
        if ret is None:
            continue
        # 以信号日为索引，同时记录实际买入日
        records[signal_date] = {"ret": ret, "n": n, "buy_date": buy_date}

    result = pd.DataFrame.from_dict(records, orient="index").sort_index()
    return result


def main():
    logger.info("读取价格数据...")
    open_price, close_price = load_prices()
    logger.info("价格数据：open %s, close %s", open_price.shape, close_price.shape)

    logger.info("读取选股池...")
    pool = load_pool()
    logger.info("选股池：%d 行，买入日 %d 个，区间 %s ~ %s",
                len(pool), pool["date"].nunique(), pool["date"].min(), pool["date"].max())

    labels = {}  # label名 -> 每日收益DataFrame

    # 开盘卖出 label
    for day in OPEN_SELL_DAYS:
        offset = day - 1  # 口径B：第N天 -> 偏移 N-1
        name = f"open_day{day}"  # 第day天开盘卖出
        labels[name] = backtest_one_label(pool, open_price, close_price, offset, "open")
        logger.info("label %s 完成，有效买入日 %d", name, len(labels[name]))

    # 收盘卖出 label
    for day in CLOSE_SELL_DAYS:
        offset = day - 1
        name = f"close_day{day}"  # 第day天收盘卖出
        labels[name] = backtest_one_label(pool, open_price, close_price, offset, "close")
        logger.info("label %s 完成，有效买入日 %d", name, len(labels[name]))

    # 绘制两种收益曲线（A 累乘净值 / B 累计求和），用英文标签避免中文字体缺失告警
    logger.info("绘制收益曲线...")
    fig, (ax_a, ax_b) = plt.subplots(2, 1, figsize=(14, 11))

    for name, df in labels.items():
        if df.empty:
            logger.warning("label %s no data, skip", name)
            continue
        x = pd.to_datetime(df.index, format="%Y%m%d")
        # A 累乘净值
        nav = (1 + df["ret"]).cumprod()
        ax_a.plot(x, nav.values, label=f"{name} (nav={nav.iloc[-1]:.3f})")
        # B 累计求和
        cum_sum = df["ret"].cumsum()
        ax_b.plot(x, cum_sum.values * 100, label=f"{name} (sum={cum_sum.iloc[-1]*100:.1f}%)")

    ax_a.set_title("stock_pool_3 NAV (compounded, equal-weight open buy, adj price)")
    ax_a.set_xlabel("buy date")
    ax_a.set_ylabel("cumulative NAV")
    ax_a.legend()
    ax_a.grid(True, alpha=0.3)

    ax_b.set_title("stock_pool_3 cumulative sum of per-trade return (no compounding)")
    ax_b.set_xlabel("buy date")
    ax_b.set_ylabel("cumulative return (%)")
    ax_b.legend()
    ax_b.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(OUTPUT_IMG, dpi=120)
    logger.info("图片已保存：%s", OUTPUT_IMG)

    # 打印汇总
    print("\n===== 各 label 汇总 =====")
    for name, df in labels.items():
        if df.empty:
            continue
        nav = (1 + df["ret"]).cumprod()
        cum_sum = df["ret"].cumsum()
        print(f"{name}: 买入日数={len(df)}, 平均单次收益={df['ret'].mean()*100:.3f}%, "
              f"胜率={(df['ret']>0).mean()*100:.1f}%, "
              f"累乘净值={nav.iloc[-1]:.3f}, 累计求和={cum_sum.iloc[-1]*100:.1f}%")


if __name__ == "__main__":
    main()
