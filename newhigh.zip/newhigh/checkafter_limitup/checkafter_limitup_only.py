"""
checkafter_limitup_only —— 在「日内破前高」基础上，叠加共 12 个筛选条件，
每个条件都写成独立的 `passX`(bool) 形式，方便单独开关 / 调整阈值。

== 12 个条件（在代码中以 pass1 ~ pass12 显式标出）==
  pass1  日内（当天 D）存在 “破前高” 形态（沿用 README / find_segments 定义）
  pass2  当天 D 盘中 1min close 曾涨到 >= 78% * limit_up_price(D)
  pass3  破前高过程内 (t_start~t_end) corr(price, amt_lag) < 截面 35 分位
         —— 上涨时段的「价格」与「前一分钟成交量」的相关系数
  pass4  破前高过程内 (t_start~t_end) corr(pct,   amt_lag) < 截面 35 分位
         —— 上涨时段的「涨跌幅」与「前一分钟成交量」的相关系数
  pass5  昨日(D-1) 开盘价 <= 昨日(D-1) 前收盘
  pass6  昨日(D-1) 收盘价 <  limit_up_price(D-1) * 93%
  pass7  剔除「20 日内曾经冲高 >120% 后回调 >30%」的票（满足剔除条件 => pass7=False）
  pass8  今日(D) 涨停价 >= 10 元  且  昨日(D-1) 市值 >= 30 亿
  pass9  剔除「过去 4 天曾经跌停」的票（出现跌停 => pass9=False）
  pass10 昨日(D-1) 成交额 / 前 5 日均值  <  截面 95 分位
  pass11 昨日(D-1) 市值  <  截面 96 分位
  pass12 20 日涨幅（截至 D-1）  <  截面 85 分位

  最终入选 = pass1 & pass2 & ... & pass12

说明（阈值都集中在 CONFIG，可自行调整）：
  - “截面分位”说明：
      * pass3 / pass4 的截面 = 当天「通过 pass1&pass2 的破前高候选」集合（只有它们才有 corr）
      * pass10 / pass11 / pass12 的截面 = 当天「指数成分∩去 ST」的全体可用票（更具统计意义）
  - amt_lag = 前一分钟成交量 = min_data 的 vol.shift(1)（若想用成交额，把 AMT_LAG_COL 改成 "amount"）

数据读取（参考 DataLoader）：
  - 日频：DataLoader.read_daily / 直接 in-memory 缓存 panel
    LIMIT_UP_PRICE / LIMIT_DOWN_PRICE / OPEN_PRICE / CLOSE_PRICE / PRE_CLOSE_PRICE /
    HIGHEST_PRICE / LOWEST_PRICE / MARKET_VALUE / TURNOVER_VALUE
  - min_data：全市场原始 1min /mnt/.../min_data/{YYYYMMDD}.fea
  - 指数成分 + 去 ST：复用 build_up_7/build_universe.py 的 load_index_codes / load_st_set

输出（每天一个 parquet）：{OUTPUT_DIR}/segments_daily/{D}.parquet

用法：
  python checkafter_limitup_only.py --date 20250106
"""

from __future__ import annotations

import os
import sys
import datetime
import logging
import argparse
import time as _time

import pandas as pd
import numpy as np

# ---- 让本脚本能 import DataLoader / find_segments / build_universe ----
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_NEWHIGH_DIR = os.path.dirname(_THIS_DIR)                 # jk/newhigh
_JK_DIR = os.path.dirname(_NEWHIGH_DIR)                   # jk
sys.path.insert(0, _JK_DIR)                               # DataLoader 是 jk 下的包
sys.path.insert(0, _NEWHIGH_DIR)                          # find_segments
sys.path.insert(0, os.path.join(_JK_DIR, "build_up_7"))  # build_universe

from DataLoader import DataLoader                          # noqa: E402
from find_segments import find_segments_in_series          # noqa: E402  破前高区段核心算法
# 注意：不再复用 build_up_7/build_universe.py 的 load_index_codes/load_st_set，
# 因为它们用模块级 START_DT=2025-01-01 过滤并缓存，会导致 2024 年 universe 全为空。
# 这里自带一套可配置日期范围、独立缓存的指数成分 / ST 加载器（见下方 _load_index_codes / _load_st_set）。


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)


# ============================================================
# CONFIG —— 所有可调阈值集中在这里
# ============================================================
class CONFIG:
    # pass2：日内曾涨到 N% limit_up
    GAIN_THRESHOLD = 0.78

    # pass3 / pass4：corr 截面分位阈值
    CORR_PRICE_Q = 0.35           # corr(price, amt_lag) < 该分位
    CORR_PCT_Q = 0.35             # corr(pct,   amt_lag) < 该分位
    AMT_LAG_COL = "vol"           # 前一分钟“成交量”，可改 "amount"（成交额）

    # pass6：昨日收盘 < limit_up(D-1) * 该系数
    CLOSE_LT_LIMIT_UP_RATIO = 0.93

    # pass7：剔除 20 日内冲高>SPIKE 后回调>DRAWDOWN
    SPIKE_WINDOW = 20
    SPIKE_UP = 1.20               # 冲高 >120%（峰值/基准 - 1 > 1.20）
    SPIKE_DRAWDOWN = 0.30         # 回调 >30%

    # pass8：今日涨停价下限 & 昨日市值下限
    LIMIT_UP_MIN = 10.0           # 元
    MKTCAP_MIN = 30e8             # 30 亿元

    # pass9：剔除过去 N 天曾跌停
    LIMIT_DOWN_WINDOW = 4

    # pass10：昨日成交额 / 前 5 日均值 的截面分位上限
    AMT_RATIO_LOOKBACK = 5
    AMT_RATIO_Q = 0.95

    # pass11：昨日市值的截面分位上限
    MKTCAP_Q = 0.96

    # pass12：20 日涨幅的截面分位上限
    RET_WINDOW = 20
    RET20_Q = 0.85

    # 价格相等判定容差（涨停/跌停）
    PRICE_EPS = 1e-3

    # 破前高区段参数（与 find_segments 默认一致）
    CONT = 3
    SCALE = 1.0

    # 连续竞价时段
    TIME_LO = 930
    TIME_HI = 1457


# 数据路径
RAW_MIN_DATA_DIR = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/min_data"
DAILY_ROOT = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea"
LIMIT_UP_PRICE_PATH = os.path.join(DAILY_ROOT, "LIMIT_UP_PRICE.pkl")

OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only"
SEGMENTS_DAILY_DIR = os.path.join(OUTPUT_DIR, "segments_daily")

# ---- 指数成分 / ST 源（与 build_up_7/build_universe.py 同源，但日期范围独立可配，覆盖 2024）----
ST_STATUS_PATH = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/support_data/st_status2.pkl"
INDEX_PATHS = {
    "zz300": "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/support_data/沪深300成份_tl.pkl",
    "zz500": "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/support_data/中证500成份_tl.pkl",
    # "zz1000": "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/support_data/中证1000成份_tl.pkl",
    # "zz2000": "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/support_data/国证2000成份_ts.pkl",
}
# universe 覆盖日期范围（关键：起点设到 2024-01-01，避免 build_universe 的 2025 起点导致 2024 全空）
UNIVERSE_START_DT = datetime.date(2024, 1, 1)
UNIVERSE_END_DT = datetime.date(2026, 12, 31)
# 本脚本自有缓存目录（与 build_up_7 的 .cache 分开，避免读到 2025-only 的旧缓存）
UNIVERSE_CACHE_DIR = os.path.join(OUTPUT_DIR, ".cache")

# 缓存
_TRADING_CAL = None
_PANEL_CACHE: dict[str, pd.DataFrame] = {}
_INDEX_BY_DATE = None
_ST_SET = None


def _load_index_codes() -> dict:
    """加载 沪深300+中证500+中证1000+国证2000 成分股，返回 {date: set_of_stockid}。
    与 build_universe.load_index_codes 同源，但日期范围 UNIVERSE_START_DT~UNIVERSE_END_DT 可配，
    且使用本脚本独立缓存，确保覆盖 2024 年。"""
    global _INDEX_BY_DATE
    if _INDEX_BY_DATE is not None:
        return _INDEX_BY_DATE
    cache_path = os.path.join(UNIVERSE_CACHE_DIR, "index_by_date.pkl")
    if os.path.exists(cache_path):
        import pickle
        with open(cache_path, "rb") as f:
            _INDEX_BY_DATE = pickle.load(f)
        return _INDEX_BY_DATE

    logger.info("读取指数成分股（300+500+1000+2000），范围 %s ~ %s ...",
                UNIVERSE_START_DT, UNIVERSE_END_DT)
    all_by_date: dict = {}
    for idx_name, idx_path in INDEX_PATHS.items():
        df_idx = pd.read_pickle(idx_path)
        df_idx["date_obj"] = pd.to_datetime(df_idx["date"], format="%Y%m%d").dt.date
        m = (df_idx["date_obj"] >= UNIVERSE_START_DT) & (df_idx["date_obj"] <= UNIVERSE_END_DT)
        df_idx = df_idx[m]
        for d, grp in df_idx.groupby("date_obj"):
            all_by_date.setdefault(d, set()).update(grp["code"].tolist())
    logger.info("指数成分股覆盖 %d 个交易日", len(all_by_date))

    import pickle
    os.makedirs(UNIVERSE_CACHE_DIR, exist_ok=True)
    with open(cache_path, "wb") as f:
        pickle.dump(all_by_date, f)
    _INDEX_BY_DATE = all_by_date
    return _INDEX_BY_DATE


def _load_st_set() -> set:
    """加载 ST 状态，返回 {(date, pure_code)} 集合；日期范围与缓存与上同。"""
    global _ST_SET
    if _ST_SET is not None:
        return _ST_SET
    cache_path = os.path.join(UNIVERSE_CACHE_DIR, "st_set.pkl")
    if os.path.exists(cache_path):
        import pickle
        with open(cache_path, "rb") as f:
            _ST_SET = pickle.load(f)
        return _ST_SET

    logger.info("读取 ST 状态 ...")
    df_st_raw = pd.read_pickle(ST_STATUS_PATH)
    m = (df_st_raw.index >= UNIVERSE_START_DT) & (df_st_raw.index <= UNIVERSE_END_DT)
    df_st_raw = df_st_raw.loc[m]
    df_st = pd.DataFrame(df_st_raw.stack(), columns=["st"])
    df_st.index.names = ["date", "code"]
    df_st.reset_index(inplace=True)
    df_st["code"] = df_st["code"].astype(str).str.strip()
    st_set = set(zip(df_st.loc[df_st["st"] == 1, "date"],
                     df_st.loc[df_st["st"] == 1, "code"]))
    logger.info("ST 记录数: %d", len(st_set))

    import pickle
    os.makedirs(UNIVERSE_CACHE_DIR, exist_ok=True)
    with open(cache_path, "wb") as f:
        pickle.dump(st_set, f)
    _ST_SET = st_set
    return _ST_SET



# ---------------- 工具函数 ----------------
def _stockid_to_pure(stockid: str) -> str:
    return str(stockid)[2:]


def _pure_to_stockid(pure: str) -> str:
    return ("SH" if pure[0] in ("5", "6", "9") else "SZ") + pure


def _load_panel(field: str) -> pd.DataFrame:
    """加载并缓存一个日频 panel（index=date, columns=纯6位 code）。"""
    if field not in _PANEL_CACHE:
        df = pd.read_pickle(os.path.join(DAILY_ROOT, f"{field}.pkl")).sort_index()
        df.columns = df.columns.astype(str)
        _PANEL_CACHE[field] = df
    return _PANEL_CACHE[field]


def _load_trading_calendar() -> list[datetime.date]:
    global _TRADING_CAL
    if _TRADING_CAL is None:
        lu = pd.read_pickle(LIMIT_UP_PRICE_PATH)
        _TRADING_CAL = sorted(lu.index)
    return _TRADING_CAL


def _prev_trading_days(date_obj: datetime.date, n: int) -> list[datetime.date]:
    """返回 date_obj 之前（不含）最近 n 个交易日，按时间升序。"""
    cal = _load_trading_calendar()
    if date_obj not in cal:
        # 容错：取所有 < date_obj 的
        earlier = [d for d in cal if d < date_obj]
        return earlier[-n:]
    i = cal.index(date_obj)
    lo = max(0, i - n)
    return cal[lo:i]


def _row(field: str, date_obj: datetime.date) -> pd.Series:
    """取某 panel 在 date_obj 的整行（Series, index=code）；缺失返回空 Series。"""
    panel = _load_panel(field)
    if date_obj in panel.index:
        return panel.loc[date_obj]
    return pd.Series(dtype=float)


def _read_raw_min(date_obj: datetime.date, stockids: set[str] | None = None) -> pd.DataFrame:
    ymd = date_obj.strftime("%Y%m%d")
    path = os.path.join(RAW_MIN_DATA_DIR, f"{ymd}.fea")
    if not os.path.exists(path):
        return pd.DataFrame()
    df = pd.read_feather(path, use_threads=True)
    if stockids is not None:
        df = df[df["StockID"].isin(stockids)]
    return df


OUT_COLS = [
    "date", "code", "t_start", "t_end", "len1", "len2",
    "start_price1", "end_price1", "start_price2", "end_price2",
    "day_max_after_end", "next_open",
    "reach_pct_time", "reach_pct_price", "limit_up_price",
    "corr_price_amtlag", "corr_pct_amtlag",
    "prev1_date", "prev1_open", "prev1_pre_close", "prev1_close", "prev1_limit_up",
    "limit_up_D", "mktcap_prev1", "amt_ratio", "ret20",
] + [f"pass{i}" for i in range(1, 13)]


def _save_empty(date_int: str):
    os.makedirs(SEGMENTS_DAILY_DIR, exist_ok=True)
    out_path = os.path.join(SEGMENTS_DAILY_DIR, f"{date_int}.parquet")
    pd.DataFrame(columns=OUT_COLS).to_parquet(out_path, index=False)


def _xs_quantile(series: pd.Series, q: float) -> float:
    """截面分位数（自动去 NaN/inf）。"""
    v = series.replace([np.inf, -np.inf], np.nan).dropna()
    if v.empty:
        return np.nan
    return float(v.quantile(q))


# ============================================================
# 主流程
# ============================================================
def process_one_date(date_int: str, cfg: CONFIG) -> int:
    date_obj = datetime.datetime.strptime(date_int, "%Y%m%d").date()
    date_str = date_obj.strftime("%Y-%m-%d")

    cal = _load_trading_calendar()
    if date_obj not in cal:
        logger.info("日期 %s 非交易日", date_int)
        _save_empty(date_int)
        return 0

    # 昨日 D-1（pass5/6/8/10/11/12 都基于昨日）
    prevs = _prev_trading_days(date_obj, max(cfg.SPIKE_WINDOW, cfg.RET_WINDOW,
                                             cfg.AMT_RATIO_LOOKBACK, cfg.LIMIT_DOWN_WINDOW) + 5)
    if not prevs:
        logger.info("日期 %s 无历史交易日", date_int)
        _save_empty(date_int)
        return 0
    prev1 = prevs[-1]
    prev1_str = prev1.strftime("%Y-%m-%d")

    # ---- 基础 universe：指数成分∩去 ST（与原 universe 口径一致，但日期范围覆盖 2024）----
    index_by_date = _load_index_codes()
    st_set = _load_st_set()

    index_stockids = index_by_date.get(date_obj, set())
    universe = {_stockid_to_pure(sid) for sid in index_stockids}
    universe = {c for c in universe if (date_obj, c) not in st_set}
    if not universe:
        logger.info("日期 %s universe 为空", date_int)
        _save_empty(date_int)
        return 0
    logger.info("日期 %s: 基础 universe %d 只", date_int, len(universe))

    # 统一对齐索引：所有日频 Series 都 reindex 到该 universe，避免标签不一致比较报错
    uni_idx = pd.Index(sorted(universe))

    # ============================================================
    # 日频条件（pass5~pass12），全部向量化按 code 计算
    # ============================================================
    lu_D = _row("LIMIT_UP_PRICE", date_obj).reindex(uni_idx)        # 今日涨停价
    open_p1 = _row("OPEN_PRICE", prev1).reindex(uni_idx)            # 昨日开盘
    pre_close_p1 = _row("PRE_CLOSE_PRICE", prev1).reindex(uni_idx)  # 昨日前收盘
    close_p1 = _row("CLOSE_PRICE", prev1).reindex(uni_idx)          # 昨日收盘
    lu_p1 = _row("LIMIT_UP_PRICE", prev1).reindex(uni_idx)          # 昨日涨停价
    mktcap_p1 = _row("MARKET_VALUE", prev1).reindex(uni_idx)        # 昨日市值


    # ---- pass5：昨日开盘 <= 昨日前收盘 ----
    pass5 = (open_p1 <= pre_close_p1)

    # ---- pass6：昨日收盘 < 昨日涨停价 * 0.93 ----
    pass6 = (close_p1 < lu_p1 * cfg.CLOSE_LT_LIMIT_UP_RATIO)

    # ---- pass7：剔除 20 日内冲高>120% 后回调>30% ----
    win7 = prevs[-cfg.SPIKE_WINDOW:] if len(prevs) >= cfg.SPIKE_WINDOW else prevs
    high_panel = _load_panel("HIGHEST_PRICE")
    low_panel = _load_panel("LOWEST_PRICE")
    close_panel = _load_panel("CLOSE_PRICE")
    highs_win = high_panel.reindex(win7)           # rows=win days, cols=code
    lows_win = low_panel.reindex(win7)
    base_close = close_panel.reindex([win7[0]]).iloc[0]  # 窗口起点收盘作基准
    spike_excl = pd.Series(False, index=highs_win.columns)
    if len(win7) >= 3:
        # 峰值出现位置之后的最低价回撤
        peak = highs_win.max(axis=0)
        peak_pos = highs_win.values.argmax(axis=0)         # 每列峰值行号
        cols = highs_win.columns
        gain = peak / base_close - 1.0                     # 冲高幅度（相对窗口起点收盘）
        low_after = np.full(len(cols), np.nan)
        low_vals = lows_win.values
        for j in range(len(cols)):
            p = peak_pos[j]
            seg = low_vals[p:, j]
            seg = seg[~np.isnan(seg)]
            if seg.size:
                low_after[j] = seg.min()
        low_after = pd.Series(low_after, index=cols)
        drawdown = 1.0 - low_after / peak
        spike_excl = (gain > cfg.SPIKE_UP) & (drawdown > cfg.SPIKE_DRAWDOWN)
        spike_excl = spike_excl.reindex(highs_win.columns).fillna(False)
    pass7 = ~spike_excl                                    # 未触发剔除 => True

    # ---- pass8：今日涨停价>=10 且 昨日市值>=30 亿 ----
    pass8 = (lu_D >= cfg.LIMIT_UP_MIN) & (mktcap_p1 >= cfg.MKTCAP_MIN)

    # ---- pass9：过去 4 天曾跌停 => 剔除 ----
    win9 = prevs[-cfg.LIMIT_DOWN_WINDOW:] if len(prevs) >= cfg.LIMIT_DOWN_WINDOW else prevs
    ld_panel = _load_panel("LIMIT_DOWN_PRICE")
    close_win9 = close_panel.reindex(win9)
    ld_win9 = ld_panel.reindex(win9)
    limitdown_hit = ((close_win9 - ld_win9).abs() <= cfg.PRICE_EPS).any(axis=0)
    pass9 = ~limitdown_hit.reindex(lu_D.index).fillna(False)

    # ---- pass10：昨日成交额 / 前 5 日均值 < 截面 95 分位 ----
    turnover_panel = _load_panel("TURNOVER_VALUE")
    amt_prev1 = turnover_panel.reindex([prev1]).iloc[0]
    win_amt = prevs[-(cfg.AMT_RATIO_LOOKBACK + 1):-1]      # D-2..D-6（昨日之前 5 日）
    amt_mean5 = turnover_panel.reindex(win_amt).mean(axis=0)
    amt_ratio = amt_prev1 / amt_mean5
    # 截面在“基础 universe”上取分位
    uni_idx = pd.Index(sorted(universe))
    amt_ratio_thr = _xs_quantile(amt_ratio.reindex(uni_idx), cfg.AMT_RATIO_Q)
    pass10 = (amt_ratio < amt_ratio_thr)

    # ---- pass11：昨日市值 < 截面 96 分位 ----
    mktcap_thr = _xs_quantile(mktcap_p1.reindex(uni_idx), cfg.MKTCAP_Q)
    pass11 = (mktcap_p1 < mktcap_thr)

    # ---- pass12：20 日涨幅（截至昨日）< 截面 85 分位 ----
    ret_start = prevs[-(cfg.RET_WINDOW + 1)] if len(prevs) >= cfg.RET_WINDOW + 1 else prevs[0]
    close_start = _row("CLOSE_PRICE", ret_start)
    ret20 = close_p1 / close_start - 1.0
    ret20_thr = _xs_quantile(ret20.reindex(uni_idx), cfg.RET20_Q)
    pass12 = (ret20 < ret20_thr)

    # 把日频 passX 汇总成 DataFrame（index=code），便于按 code 查
    def _b(s: pd.Series) -> pd.Series:
        return s.reindex(uni_idx).fillna(False).astype(bool)

    daily = pd.DataFrame({
        "pass5": _b(pass5), "pass6": _b(pass6), "pass7": _b(pass7),
        "pass8": _b(pass8), "pass9": _b(pass9), "pass10": _b(pass10),
        "pass11": _b(pass11), "pass12": _b(pass12),
    })
    daily["mktcap_prev1"] = mktcap_p1.reindex(uni_idx)
    daily["amt_ratio"] = amt_ratio.reindex(uni_idx)
    daily["ret20"] = ret20.reindex(uni_idx)
    daily["prev1_open"] = open_p1.reindex(uni_idx)
    daily["prev1_pre_close"] = pre_close_p1.reindex(uni_idx)
    daily["prev1_close"] = close_p1.reindex(uni_idx)
    daily["prev1_limit_up"] = lu_p1.reindex(uni_idx)
    daily["limit_up_D"] = lu_D.reindex(uni_idx)

    # ============================================================
    # 当天 min_data：pass1（破前高）+ pass2（涨到 N% limit_up）+ corr 指标(用于 pass3/4)
    # ============================================================
    cand_stockids = {_pure_to_stockid(c) for c in universe}
    df_min = _read_raw_min(date_obj, stockids=cand_stockids)
    if df_min.empty:
        logger.info("日期 %s 当天 min_data 为空", date_int)
        _save_empty(date_int)
        return 0
    df_min["code"] = df_min["StockID"].map(_stockid_to_pure)
    df_min = df_min[(df_min["time"] >= cfg.TIME_LO) & (df_min["time"] <= cfg.TIME_HI)].copy()
    df_min = df_min.sort_values(["code", "time"]).reset_index(drop=True)

    try:
        next_open_series = _next_trading_open(date_obj)
    except Exception as exc:
        logger.warning("读取 next_open 失败: %s", exc)
        next_open_series = None

    cont_int = int(cfg.CONT)
    records = []

    for code, grp in df_min.groupby("code", sort=False):
        prices = grp["price"].to_numpy(dtype=np.float64)
        times = grp["time"].to_numpy(dtype=np.int64)
        highs = grp["high"].to_numpy(dtype=np.float64)
        # 前一分钟成交量（amt_lag）：在全日序列上做 shift(1)
        amt = grp[cfg.AMT_LAG_COL].to_numpy(dtype=np.float64)
        amt_lag = np.empty_like(amt)
        amt_lag[0] = np.nan
        amt_lag[1:] = amt[:-1]
        # 涨跌幅 pct（1min ret）
        pct = np.empty_like(prices)
        pct[0] = np.nan
        pct[1:] = prices[1:] / prices[:-1] - 1.0

        if len(prices) < 2 * cont_int + 1:
            continue

        lu_price = lu_D.get(code, np.nan)
        if pd.isna(lu_price) or lu_price <= 0:
            continue
        lu_price = float(lu_price)

        # -------- pass2：盘中 1min close 曾 >= N% limit_up --------
        thresh = lu_price * cfg.GAIN_THRESHOLD
        reach_mask = prices >= thresh
        pass2_stock = bool(reach_mask.any())
        if pass2_stock:
            reach_idx = int(np.argmax(reach_mask))
            reach_pct_time = int(times[reach_idx])
            reach_pct_price = float(prices[reach_idx])
        else:
            reach_pct_time, reach_pct_price = -1, float("nan")

        # -------- pass1：日内存在破前高（相邻上涨区段 S1->S2）--------
        segs = find_segments_in_series(prices, cont_int)
        if len(segs) < 2:
            continue

        for k in range(len(segs) - 1):
            s1_start, s1_end = segs[k]
            s2_start, s2_end = segs[k + 1]
            len1 = s1_end - s1_start + 1
            len2 = s2_end - s2_start + 1
            gap = s2_start - s1_end - 1

            start_price1 = float(prices[s1_start - 1])
            end_price1 = float(prices[s1_end])
            start_price2 = float(prices[s2_start - 1])
            end_price2 = float(prices[s2_end])

            # 破前高 4 子条件（README / find_segments 定义）
            if not (gap < len1 * cfg.SCALE):
                continue
            if not (start_price2 <= end_price1):
                continue
            if not (end_price2 > end_price1):       # 创 S1 新高 = 破前高
                continue
            if not (start_price2 > start_price1):
                continue

            pass1_stock = True  # 能走到这里即满足破前高

            t_start = int(times[s1_start - 1])
            seg2_prices = prices[s2_start:s2_end + 1]
            seg2_times = times[s2_start:s2_end + 1]
            mask = seg2_prices > end_price1
            t_end = int(seg2_times[-1]) if not mask.any() else int(seg2_times[int(np.argmax(mask))])

            after_mask = times > t_end
            day_max_after_end = float(highs[after_mask].max()) if after_mask.any() else float("nan")

            # -------- corr 指标（用于 pass3/pass4）：窗口 [t_start, t_end] --------
            wmask = (times >= t_start) & (times <= t_end)
            w_price = prices[wmask]
            w_pct = pct[wmask]
            w_amtlag = amt_lag[wmask]

            def _safe_corr(a: np.ndarray, b: np.ndarray) -> float:
                m = np.isfinite(a) & np.isfinite(b)
                if m.sum() < 3:
                    return np.nan
                aa, bb = a[m], b[m]
                if np.std(aa) == 0 or np.std(bb) == 0:
                    return np.nan
                return float(np.corrcoef(aa, bb)[0, 1])

            corr_price_amtlag = _safe_corr(w_price, w_amtlag)
            corr_pct_amtlag = _safe_corr(w_pct, w_amtlag)

            if next_open_series is not None and code in next_open_series.index:
                no_val = next_open_series[code]
                next_open = float(no_val) if pd.notna(no_val) else float("nan")
            else:
                next_open = float("nan")

            records.append({
                "date": date_str,
                "code": code,
                "prev1_date": prev1_str,
                "t_start": t_start,
                "t_end": t_end,

                "len1": int(len1),
                "len2": int(len2),
                "start_price1": start_price1,
                "end_price1": end_price1,
                "start_price2": start_price2,
                "end_price2": end_price2,
                "day_max_after_end": day_max_after_end,
                "next_open": next_open,
                # pass2 佐证
                "reach_pct_time": reach_pct_time,
                "reach_pct_price": reach_pct_price,
                "limit_up_price": lu_price,
                # pass3/4 指标
                "corr_price_amtlag": corr_price_amtlag,
                "corr_pct_amtlag": corr_pct_amtlag,
                # 逐 pass（先填 stock 级别的 1/2，截面级的 3/4 稍后填）
                "pass1": pass1_stock,
                "pass2": pass2_stock,
            })

    if not records:
        _save_empty(date_int)
        logger.info("日期 %s: 无破前高候选记录", date_int)
        return 0

    df = pd.DataFrame(records)

    # ============================================================
    # pass3 / pass4：corr 截面分位（截面 = 当前破前高候选集合）
    # ============================================================
    corr_price_thr = _xs_quantile(df["corr_price_amtlag"], cfg.CORR_PRICE_Q)
    corr_pct_thr = _xs_quantile(df["corr_pct_amtlag"], cfg.CORR_PCT_Q)
    df["pass3"] = df["corr_price_amtlag"] < corr_price_thr
    df["pass4"] = df["corr_pct_amtlag"] < corr_pct_thr

    # ============================================================
    # 合并日频 pass5~pass12 + 佐证字段
    # ============================================================
    df = df.merge(daily, left_on="code", right_index=True, how="left")
    for c in [f"pass{i}" for i in range(5, 13)]:
        df[c] = df[c].fillna(False).astype(bool)

    # ============================================================
    # 最终：pass1 & ... & pass12
    # ============================================================
    pass_cols = [f"pass{i}" for i in range(1, 13)]
    df["pass_all"] = df[pass_cols].all(axis=1)

    # 各 pass 命中统计（便于调参）
    stat = {c: int(df[c].sum()) for c in pass_cols}
    logger.info("日期 %s 各条件命中数(候选 %d 条): %s", date_int, len(df), stat)

    df_out = df[df["pass_all"]].copy()
    df_out = df_out[[c for c in OUT_COLS if c in df_out.columns]]

    os.makedirs(SEGMENTS_DAILY_DIR, exist_ok=True)
    out_path = os.path.join(SEGMENTS_DAILY_DIR, f"{date_int}.parquet")
    df_out.to_parquet(out_path, index=False)
    logger.info("日期 %s: 入选 %d 条（%d 只）-> %s",
                date_int, len(df_out), df_out["code"].nunique() if len(df_out) else 0, out_path)
    return len(df_out)


def _next_trading_open(date_obj: datetime.date) -> pd.Series | None:
    df_open = _load_panel("OPEN_PRICE")
    later = [d for d in df_open.index if d > date_obj]
    if not later:
        return None
    return df_open.loc[min(later)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, default="20240430", help="交易日 D，格式 YYYYMMDD")
    parser.add_argument("--cont", type=int, default=CONFIG.CONT)
    parser.add_argument("--scale", type=float, default=CONFIG.SCALE)
    args = parser.parse_args()

    cfg = CONFIG()
    cfg.CONT = args.cont
    cfg.SCALE = args.scale

    t0 = _time.time()
    n = process_one_date(args.date, cfg)
    logger.info("日期 %s 完成: %d 条记录, 耗时 %.1fs", args.date, n, _time.time() - t0)


if __name__ == "__main__":
    main()
