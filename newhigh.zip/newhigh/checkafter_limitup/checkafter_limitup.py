"""
checkafter_limitup —— 在「日内破前高 + 曾涨到 94% limit_up」基础上，叠加「两天前涨停封板」过滤。

背景：
  - find_segments.py 已经在 build_up_7 universe（曾涨到 *97%* limit_up）中找出了
    "日内存在破前高形态" 的 (date, code) 股票池。
  - 本脚本把阈值放宽到 *94%* limit_up（94% 是 97% 的超集，因此不能直接复用 97% 过滤后的
    min_data，需要回到全市场原始 min_data 读取），并新增「两天前涨停封板」两个条件。

四个筛选条件（在代码中以 “条件1/2/3/4” 显式标出）：
  条件1：日内（当天 D）存在 “破前高” 形态
         —— 完全沿用 README.md / find_segments.py 的定义：
            相邻两个连续上涨区段 S1 -> S2 满足
              (a) gap_bars < len(S1) * scale
              (b) start_price2 <= end_price1
              (c) end_price2  >  end_price1   （即第二段创出 S1 的新高 = 破前高）
              (d) start_price2 >  start_price1
  条件2：当天 D 盘中 1min close 曾涨到 >= 94% * limit_up_price(D)
  条件3：两天前（D-2）的「中午收盘价」== 当天（D-2）涨停价
         —— 中午收盘价取 D-2 上午收盘 1min bar（time==1130）的 close(price)
  条件4：两天前（D-2）的「结束收盘价」== 当天（D-2）涨停价
         —— 结束收盘价取日频 CLOSE_PRICE(D-2)
  （条件3 + 条件4 = 两天前 “中午封死涨停并一直封到收盘”）

数据读取（参考 DataLoader）：
  - 日频数据：DataLoader.read_daily —— LIMIT_UP_PRICE / CLOSE_PRICE / HIGHEST_PRICE
  - 交易日历：LIMIT_UP_PRICE.pkl 的 index（datetime.date，升序）
  - min_data：DataLoader 默认的 min 源是 97% universe 过滤后的数据，无法覆盖 94% 池，
              故这里直接读取全市场原始 min_data：
              /mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/min_data/{YYYYMMDD}.fea
  - 指数成分股 + 去 ST：复用 build_up_7/build_universe.py 的 load_index_codes / load_st_set，
              与原 universe 口径保持一致。

输出（每天一个 parquet）：
  {OUTPUT_DIR}/segments_daily/{D}.parquet
  字段：date, code, t_start, t_end, len1, len2,
        start_price1, end_price1, start_price2, end_price2,
        day_max_after_end, next_open,
        reach_94_time, reach_94_price, limit_up_price,           # 条件2 佐证
        prev2_date, prev2_midday_close, prev2_end_close, prev2_limit_up  # 条件3/4 佐证

用法：
  python checkafter_limitup.py --date 20250106
"""

from __future__ import annotations

import os
import sys
import pickle
import datetime
import logging
import argparse
import time as _time

import pandas as pd
import numpy as np

# ---- 让本脚本能 import DataLoader / find_segments / build_universe ----
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_NEWHIGH_DIR = os.path.dirname(_THIS_DIR)                 # jk/newhigh
_JK_DIR = os.path.dirname(_NEWHIGH_DIR)                   # jk
sys.path.insert(0, _JK_DIR)                               # DataLoader 是 jk 下的包
sys.path.insert(0, _NEWHIGH_DIR)                          # find_segments
sys.path.insert(0, os.path.join(_JK_DIR, "build_up_7"))  # build_universe

from DataLoader import DataLoader                         # noqa: E402
from find_segments import find_segments_in_series         # noqa: E402  破前高区段核心算法
import build_universe as bu                                # noqa: E402  复用指数/ST 口径

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ========== 配置 ==========
GAIN_THRESHOLD_94 = 0.78            # 条件2：94% limit_up
PRICE_EPS = 1e-3                    # 价格相等判定容差（约 0.1 分）

# 全市场原始 min_data（94% 池需要超出 97% universe，必须用原始 min_data）
RAW_MIN_DATA_DIR = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/min_data"

# 日频字段路径（与 DataLoader.daily_root 一致）
DAILY_ROOT = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea"
LIMIT_UP_PRICE_PATH = os.path.join(DAILY_ROOT, "LIMIT_UP_PRICE.pkl")

# 破前高区段参数（与 find_segments 默认一致）
DEFAULT_CONT = 3
DEFAULT_SCALE = 1.0

# 仅使用连续竞价时段（与 find_segments 一致）
TIME_LO = 930      # 含
TIME_HI = 1457     # 含
MIDDAY_BAR = 1130  # 条件3：上午收盘 1min bar 时间

OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup"
SEGMENTS_DAILY_DIR = os.path.join(OUTPUT_DIR, "segments_daily")

# 缓存交易日历
_TRADING_CAL = None


# ---------------- 工具函数 ----------------
def _stockid_to_pure(stockid: str) -> str:
    """'SZ000417' -> '000417'"""
    return str(stockid)[2:]


def _pure_to_stockid(pure: str) -> str:
    """'000417' -> 'SZ000417'；'600000' -> 'SH600000'（6/5/9 开头属沪市）"""
    return ("SH" if pure[0] in ("5", "6", "9") else "SZ") + pure


def _load_trading_calendar() -> list[datetime.date]:
    """交易日历（升序 datetime.date 列表），取自 LIMIT_UP_PRICE.pkl 的 index。"""
    global _TRADING_CAL
    if _TRADING_CAL is None:
        lu = pd.read_pickle(LIMIT_UP_PRICE_PATH)
        _TRADING_CAL = sorted(lu.index)
    return _TRADING_CAL


def _get_prev2_trading_day(date_obj: datetime.date) -> datetime.date | None:
    """返回 date_obj 往前数第 2 个交易日（D-2）。"""
    cal = _load_trading_calendar()
    if date_obj not in cal:
        return None
    i = cal.index(date_obj)
    if i < 2:
        return None
    return cal[i - 2]


def _read_raw_min(date_obj: datetime.date, stockids: set[str] | None = None) -> pd.DataFrame:
    """读取全市场原始 min_data（可按 StockID 过滤）。"""
    ymd = date_obj.strftime("%Y%m%d")
    path = os.path.join(RAW_MIN_DATA_DIR, f"{ymd}.fea")
    if not os.path.exists(path):
        return pd.DataFrame()
    df = pd.read_feather(path, use_threads=True)
    if stockids is not None:
        df = df[df["StockID"].isin(stockids)]
    return df


def _save_empty(date_int: str):
    os.makedirs(SEGMENTS_DAILY_DIR, exist_ok=True)
    out_path = os.path.join(SEGMENTS_DAILY_DIR, f"{date_int}.parquet")
    empty = pd.DataFrame(columns=[
        "date", "code", "t_start", "t_end", "len1", "len2",
        "start_price1", "end_price1", "start_price2", "end_price2",
        "day_max_after_end", "next_open",
        "reach_94_time", "reach_94_price", "limit_up_price",
        "prev2_date", "prev2_midday_close", "prev2_end_close", "prev2_limit_up",
    ])
    empty.to_parquet(out_path, index=False)


# ---------------- 主流程 ----------------
def process_one_date(date_int: str, cont: int, scale: float) -> int:
    date_obj = datetime.datetime.strptime(date_int, "%Y%m%d").date()
    date_str = date_obj.strftime("%Y-%m-%d")

    dl = DataLoader()

    # ============================================================
    # 第 0 步：定位两天前 D-2，并准备日频数据
    # ============================================================
    prev2_obj = _get_prev2_trading_day(date_obj)
    if prev2_obj is None:
        logger.info("日期 %s: 找不到两天前交易日（D-2）", date_int)
        _save_empty(date_int)
        return 0
    prev2_int = prev2_obj.strftime("%Y%m%d")
    prev2_str = prev2_obj.strftime("%Y-%m-%d")

    # 日频：当天 D 的 limit_up / 最高价；两天前 D-2 的 limit_up / 收盘价
    daily_D = dl.read_daily(date_int, fields=["LIMIT_UP_PRICE", "HIGHEST_PRICE"])
    daily_D2 = dl.read_daily(prev2_int, fields=["LIMIT_UP_PRICE", "CLOSE_PRICE"])

    lu_D = daily_D["LIMIT_UP_PRICE"]
    hp_D = daily_D["HIGHEST_PRICE"]
    lu_D2 = daily_D2["LIMIT_UP_PRICE"]
    cp_D2 = daily_D2["CLOSE_PRICE"]

    # ============================================================
    # 条件4：两天前（D-2）结束收盘价 == 当天（D-2）涨停价   （向量化，日频）
    #   —— D-2 封死涨停收盘
    # ============================================================
    valid4 = (lu_D2 > 0) & lu_D2.notna() & cp_D2.notna()
    cond4_mask = valid4 & ((lu_D2 - cp_D2).abs() <= PRICE_EPS)
    cond4_codes = set(cp_D2.index[cond4_mask].astype(str))
    logger.info("日期 %s: 【条件4】D-2(%s) 收盘=涨停 候选 %d 只", date_int, prev2_int, len(cond4_codes))
    if not cond4_codes:
        _save_empty(date_int)
        return 0

    # ---- 与原 universe 口径一致：限制在 指数成分股(沪深300+中证500+1000+2000) 且 去 ST ----
    index_by_date = bu.load_index_codes()
    st_set = bu.load_st_set()
    index_stockids = index_by_date.get(date_obj, set())
    index_pure = {_stockid_to_pure(sid) for sid in index_stockids}
    if index_pure:
        cond4_codes &= index_pure
    cond4_codes = {c for c in cond4_codes if (date_obj, c) not in st_set}
    logger.info("日期 %s: 【条件4】叠加指数成分+去ST 后候选 %d 只", date_int, len(cond4_codes))
    if not cond4_codes:
        _save_empty(date_int)
        return 0

    # ============================================================
    # 条件3：两天前（D-2）中午收盘价 == 当天（D-2）涨停价
    #   —— 读取 D-2 原始 min_data，取 time==1130 的 close(price)
    # ============================================================
    cand_stockids_D2 = {_pure_to_stockid(c) for c in cond4_codes}
    df_min_D2 = _read_raw_min(prev2_obj, stockids=cand_stockids_D2)
    if df_min_D2.empty:
        logger.info("日期 %s: D-2(%s) min_data 为空/缺失", date_int, prev2_int)
        _save_empty(date_int)
        return 0

    midday_D2 = df_min_D2[df_min_D2["time"] == MIDDAY_BAR][["StockID", "price"]].copy()
    midday_D2["code"] = midday_D2["StockID"].map(_stockid_to_pure)
    midday_close_map = dict(zip(midday_D2["code"], midday_D2["price"].astype(float)))

    cond3_codes = set()
    for code in cond4_codes:
        mc = midday_close_map.get(code)
        if mc is None:
            continue
        lu2 = lu_D2.get(code, np.nan)
        if pd.notna(lu2) and abs(mc - float(lu2)) <= PRICE_EPS:
            cond3_codes.add(code)
    logger.info("日期 %s: 【条件3】D-2 中午收盘=涨停 候选 %d 只", date_int, len(cond3_codes))
    if not cond3_codes:
        _save_empty(date_int)
        return 0

    # ============================================================
    # 条件1 + 条件2：在当天 D 的 min_data 上，对 cond3_codes 逐票判定
    # ============================================================
    cand_stockids_D = {_pure_to_stockid(c) for c in cond3_codes}
    df_min_D = _read_raw_min(date_obj, stockids=cand_stockids_D)
    if df_min_D.empty:
        logger.info("日期 %s: 当天 min_data 为空/缺失", date_int)
        _save_empty(date_int)
        return 0

    df_min_D["code"] = df_min_D["StockID"].map(_stockid_to_pure)
    # 限制连续竞价时段（与 find_segments 一致）
    df_min_D = df_min_D[(df_min_D["time"] >= TIME_LO) & (df_min_D["time"] <= TIME_HI)].copy()
    df_min_D = df_min_D.sort_values(["code", "time"]).reset_index(drop=True)

    # 第二天 open（与 find_segments 输出字段保持一致，便于后续分析）
    try:
        next_open_series = bu_next_open = _next_trading_open(date_obj)
    except Exception as exc:
        logger.warning("读取 next_open 失败: %s", exc)
        next_open_series = None

    cont_int = int(cont)
    records = []

    for code, grp in df_min_D.groupby("code", sort=False):
        prices = grp["price"].to_numpy(dtype=np.float64)
        times = grp["time"].to_numpy(dtype=np.int64)
        highs = grp["high"].to_numpy(dtype=np.float64)
        if len(prices) < 2 * cont_int + 1:
            continue

        lu_price = lu_D.get(code, np.nan)
        if pd.isna(lu_price) or lu_price <= 0:
            continue
        lu_price = float(lu_price)

        # -------- 条件2：当天盘中 1min close 曾 >= 94% limit_up --------
        thresh94 = lu_price * GAIN_THRESHOLD_94
        reach_mask = prices >= thresh94
        if not reach_mask.any():
            continue
        reach_idx = int(np.argmax(reach_mask))
        reach_94_time = int(times[reach_idx])
        reach_94_price = float(prices[reach_idx])

        # -------- 条件1：日内存在破前高（相邻上涨区段 S1->S2） --------
        segs = find_segments_in_series(prices, cont_int)
        if len(segs) < 2:
            continue

        for k in range(len(segs) - 1):
            s1_start, s1_end = segs[k]
            s2_start, s2_end = segs[k + 1]
            len1 = s1_end - s1_start + 1
            len2 = s2_end - s2_start + 1
            gap = s2_start - s1_end - 1  # 两段间 ret<0 的 bar 数

            start_price1 = float(prices[s1_start - 1])
            end_price1 = float(prices[s1_end])
            start_price2 = float(prices[s2_start - 1])
            end_price2 = float(prices[s2_end])

            # 破前高 4 子条件（README / find_segments 定义）
            if not (gap < len1 * scale):                 # (a)
                continue
            if not (start_price2 <= end_price1):          # (b)
                continue
            if not (end_price2 > end_price1):             # (c) 创 S1 新高 = 破前高
                continue
            if not (start_price2 > start_price1):         # (d)
                continue

            # t_start：第一段起始价格对应 bar 时间
            t_start = int(times[s1_start - 1])
            # t_end：第二段中首次 close > end_price1 的 bar 时间
            seg2_prices = prices[s2_start:s2_end + 1]
            seg2_times = times[s2_start:s2_end + 1]
            mask = seg2_prices > end_price1
            if not mask.any():
                t_end = int(seg2_times[-1])
            else:
                t_end = int(seg2_times[int(np.argmax(mask))])

            after_mask = times > t_end
            day_max_after_end = float(highs[after_mask].max()) if after_mask.any() else float("nan")

            if next_open_series is not None and code in next_open_series.index:
                no_val = next_open_series[code]
                next_open = float(no_val) if pd.notna(no_val) else float("nan")
            else:
                next_open = float("nan")

            records.append({
                "date": date_str,
                "code": code,
                "t_start": t_start,
                "t_end": t_end,
                "len1": int(len1),
                "len2": int(len2),
                "start_price1": start_price1,
                "end_price1": end_price1,
                "start_price2": start_price2,
                "end_price2": end_price2,
                "day_max_after_end": day_max_after_end,
                "next_open": next_open,
                # 条件2 佐证
                "reach_94_time": reach_94_time,
                "reach_94_price": reach_94_price,
                "limit_up_price": lu_price,
                # 条件3/4 佐证
                "prev2_date": prev2_str,
                "prev2_midday_close": float(midday_close_map.get(code, np.nan)),
                "prev2_end_close": float(cp_D2.get(code, np.nan)),
                "prev2_limit_up": float(lu_D2.get(code, np.nan)),
            })

    os.makedirs(SEGMENTS_DAILY_DIR, exist_ok=True)
    out_path = os.path.join(SEGMENTS_DAILY_DIR, f"{date_int}.parquet")
    if records:
        df_out = pd.DataFrame(records)
        df_out.to_parquet(out_path, index=False)
        logger.info("日期 %s: 满足四条件记录 %d 条（%d 只股票）-> %s",
                    date_int, len(df_out), df_out["code"].nunique(), out_path)
        return len(df_out)
    else:
        _save_empty(date_int)
        logger.info("日期 %s: 无满足四条件的记录", date_int)
        return 0


def _next_trading_open(date_obj: datetime.date) -> pd.Series | None:
    """下一交易日 open_price（Series，index=pure_code）。"""
    df_open = pd.read_pickle(os.path.join(DAILY_ROOT, "OPEN_PRICE.pkl"))
    later = [d for d in df_open.index if d > date_obj]
    if not later:
        return None
    return df_open.loc[min(later)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, default="20250106", help="交易日 D，格式 YYYYMMDD")
    parser.add_argument("--cont", type=int, default=DEFAULT_CONT)
    parser.add_argument("--scale", type=float, default=DEFAULT_SCALE)
    args = parser.parse_args()

    t0 = _time.time()
    n = process_one_date(args.date, args.cont, args.scale)
    logger.info("日期 %s 完成: %d 条记录, 耗时 %.1fs", args.date, n, _time.time() - t0)


if __name__ == "__main__":
    main()
