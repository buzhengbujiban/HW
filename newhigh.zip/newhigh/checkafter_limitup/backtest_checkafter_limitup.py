"""
checkafter_limitup 选股池简单回测

选股池：/home/datamake119/data1/user118/newhigh/checkafter_limitup/segments_daily/{date}.parquet
（满足四条件：日内破前高 + 曾涨到94%limit_up + 两天前中午收盘=涨停 + 两天前收盘=涨停）

回测逻辑（参考 backtest_stock_pool_3.py，但买点不同）：
- 买入：在【date 当天】以 “破前高的第一次拉高的终点价格” 等权买入当日选出的所有股票。
        “第一次拉高的终点价格” = 该股当天最早一个破前高形态(S1->S2)中第一段 S1 的终点
        价格 end_price1（同一 (date, code) 若有多条记录，取 t_start 最小的那条）。
- 卖出（口径：date 当天算第1天，第N天 = date 之后第 N-1 个交易日）：
    开盘卖出 label：第2/3/5天开盘价卖出  -> date 偏移 1 / 2 / 4 日 open
    收盘卖出 label：第1/2/4天收盘价卖出  -> date 偏移 0 / 1 / 3 日 close
- 每个 label 计算每个 date 的等权组合收益。
- 绘制两种收益曲线：
    A 累乘净值：每个 date 当作一笔全仓独立交易，按日期顺序累乘 (1+ret)
    B 累计求和：每笔收益不复投，按日期累加 ret
- 价格：买入价来自 min_data 原始价（end_price1），故卖出价统一使用【原始未复权】
        OPEN_PRICE / CLOSE_PRICE，保持口径一致（短持有期复权影响可忽略）。

输出：各 label 的收益曲线图 + 汇总，保存在本目录。

用法：
  python backtest_checkafter_limitup.py
"""

import os
import glob
import logging

import matplotlib
matplotlib.use("Agg")  # 无显示环境保存图片
import matplotlib.pyplot as plt
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger(__name__)

# ============================================================
# 路径配置
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
POOL_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only/segments_daily"
OHLC_PATH = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea"
OPEN_PKL = os.path.join(OHLC_PATH, "OPEN_PRICE.pkl")    # 原始开盘价（与买入价口径一致）
CLOSE_PKL = os.path.join(OHLC_PATH, "CLOSE_PRICE.pkl")  # 原始收盘价
OUTPUT_IMG = os.path.join(BASE_DIR, "backtest_checkafter_limitup_only.png")

# ============================================================
# 卖出口径（date 当天算第1天）：第N天 -> date 之后第 (N-1) 个交易日
# ============================================================
OPEN_SELL_DAYS = [2, 3, 5]   # 开盘卖出：第2/3/5天
CLOSE_SELL_DAYS = [1, 2, 4]  # 收盘卖出：第1/2/4天


def load_prices():
    """读取原始开盘价、收盘价，索引统一为 YYYYMMDD 字符串。"""
    open_price = pd.read_pickle(OPEN_PKL)
    close_price = pd.read_pickle(CLOSE_PKL)
    open_price.index = pd.to_datetime(open_price.index).strftime("%Y%m%d")
    close_price.index = pd.to_datetime(close_price.index).strftime("%Y%m%d")
    open_price.sort_index(inplace=True)
    close_price.sort_index(inplace=True)
    return open_price, close_price


def load_pool():
    """读取所有 segments_daily parquet，并对每个 (date, code) 取第一次拉高终点价 end_price1。

    返回 DataFrame，列：date(str), code(6位str), buy_price(end_price1)。
    """
    files = sorted(glob.glob(os.path.join(POOL_DIR, "*.parquet")))
    frames = []
    for f in files:
        df = pd.read_parquet(f, columns=["date", "code", "t_start", "end_price1"])
        if not df.empty:
            frames.append(df)
    if not frames:
        raise RuntimeError(f"{POOL_DIR} 下没有可用的选股池数据")
    pool = pd.concat(frames, ignore_index=True)

    # date 统一为 YYYYMMDD 字符串（fea 里是 'YYYY-MM-DD'）
    pool["date"] = pd.to_datetime(pool["date"]).dt.strftime("%Y%m%d")
    pool["code"] = pool["code"].astype(str).str.zfill(6)

    # “第一次拉高的终点价格”：同一 (date, code) 取 t_start 最小那条的 end_price1
    pool = pool.sort_values(["date", "code", "t_start"])
    pool = pool.groupby(["date", "code"], as_index=False).first()
    pool = pool.rename(columns={"end_price1": "buy_price"})
    return pool[["date", "code", "buy_price"]]


def daily_equal_weight_return(sub, sell_price_row):
    """
    计算某 date 选出股票的等权组合收益。
    sub: 该 date 的 DataFrame，含 code / buy_price（买入价=end_price1）。
    sell_price_row: 卖出日价格 Series(index=code)。
    返回 (组合收益, 有效股票数)。买入价或卖出价缺失/<=0 的股票剔除。
    """
    sub = sub[sub["code"].isin(sell_price_row.index)]
    if sub.empty:
        return None, 0

    buy = sub["buy_price"].to_numpy(dtype="float64")
    sell = sell_price_row.loc[sub["code"]].to_numpy(dtype="float64")

    valid = (pd.notna(buy)) & (pd.notna(sell)) & (buy > 0) & (sell > 0)
    buy = buy[valid]
    sell = sell[valid]
    if len(buy) == 0:
        return None, 0

    ret = sell / buy - 1.0
    return float(ret.mean()), int(len(buy))


def backtest_one_label(pool, open_price, close_price, offset, sell_type):
    """
    对单个 label 回测。买入日 = date 当天。
    offset: 卖出日相对 date 的交易日偏移（口径：第N天 -> 偏移 N-1）。
    sell_type: 'open' 或 'close'。
    返回 DataFrame(index=date, columns=['ret','n','sell_date'])。
    """
    trade_dates = open_price.index  # 全市场交易日（升序）
    date_pos = {d: i for i, d in enumerate(trade_dates)}

    records = {}
    for date, sub in pool.groupby("date"):
        if date not in date_pos:
            logger.warning("信号日 %s 不在价格交易日中，跳过", date)
            continue

        sell_idx = date_pos[date] + offset
        if sell_idx >= len(trade_dates):
            continue  # 卖出日超出数据范围
        sell_date = trade_dates[sell_idx]

        sell_row = open_price.loc[sell_date] if sell_type == "open" else close_price.loc[sell_date]

        ret, n = daily_equal_weight_return(sub, sell_row)
        if ret is None:
            continue
        records[date] = {"ret": ret, "n": n, "sell_date": sell_date}

    return pd.DataFrame.from_dict(records, orient="index").sort_index()


def main():
    logger.info("读取价格数据...")
    open_price, close_price = load_prices()
    logger.info("价格数据：open %s, close %s", open_price.shape, close_price.shape)

    logger.info("读取选股池...")
    pool = load_pool()
    logger.info("选股池：%d 行(date,code)，交易日 %d 个，区间 %s ~ %s",
                len(pool), pool["date"].nunique(), pool["date"].min(), pool["date"].max())

    labels = {}  # label名 -> 每日收益DataFrame

    # 开盘卖出 label：第2/3/5天 open
    for day in OPEN_SELL_DAYS:
        offset = day - 1  # date 当天算第1天
        name = f"open_day{day}"
        labels[name] = backtest_one_label(pool, open_price, close_price, offset, "open")
        logger.info("label %s 完成，有效交易日 %d", name, len(labels[name]))

    # 收盘卖出 label：第1/2/4天 close
    for day in CLOSE_SELL_DAYS:
        offset = day - 1
        name = f"close_day{day}"
        labels[name] = backtest_one_label(pool, open_price, close_price, offset, "close")
        logger.info("label %s 完成，有效交易日 %d", name, len(labels[name]))

    # 绘制两种收益曲线（A 累乘净值 / B 累计求和）
    logger.info("绘制收益曲线...")
    fig, (ax_a, ax_b) = plt.subplots(2, 1, figsize=(14, 11))

    for name, df in labels.items():
        if df.empty:
            logger.warning("label %s no data, skip", name)
            continue
        x = pd.to_datetime(df.index, format="%Y%m%d")
        nav = (1 + df["ret"]).cumprod()
        ax_a.plot(x, nav.values, label=f"{name} (nav={nav.iloc[-1]:.3f})")
        cum_sum = df["ret"].cumsum()
        ax_b.plot(x, cum_sum.values * 100, label=f"{name} (sum={cum_sum.iloc[-1]*100:.1f}%)")

    ax_a.set_title("checkafter_limitup NAV (compounded, equal-weight, buy at first push end price)")
    ax_a.set_xlabel("date")
    ax_a.set_ylabel("cumulative NAV")
    ax_a.legend()
    ax_a.grid(True, alpha=0.3)

    ax_b.set_title("checkafter_limitup cumulative sum of per-trade return (no compounding)")
    ax_b.set_xlabel("date")
    ax_b.set_ylabel("cumulative return (%)")
    ax_b.legend()
    ax_b.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(OUTPUT_IMG, dpi=120)
    logger.info("图片已保存：%s", OUTPUT_IMG)

    # 打印汇总
    print("\n===== 各 label 汇总 =====")
    for name, df in labels.items():
        if df.empty:
            continue
        nav = (1 + df["ret"]).cumprod()
        cum_sum = df["ret"].cumsum()
        print(f"{name}: 交易日数={len(df)}, 平均单次收益={df['ret'].mean()*100:.3f}%, "
              f"胜率={(df['ret']>0).mean()*100:.1f}%, "
              f"累乘净值={nav.iloc[-1]:.3f}, 累计求和={cum_sum.iloc[-1]*100:.1f}%")


if __name__ == "__main__":
    main()
