"""
在 build_up_7 universe 中根据 1min bar 找连续上涨区段，输出满足条件的 (date, code, ...) parquet df。

定义：
  - 1min ret[i] = price[i] / price[i-1] - 1，从第二根 bar 开始
  - "连续上涨区段" = 连续 cont (默认 3) 根及以上 ret >= 0 的 1min bar
    * 区段开始索引 i_start（ret>=0 的第一根 bar），结束索引 i_end（最后一根 ret>=0 bar）
    * 区段长度 = i_end - i_start + 1
    * 起始价格 start_price = price[i_start - 1]（上涨前的 close）
    * 终止价格 end_price   = price[i_end]
    * 起始时间 t_start_seg = time[i_start - 1]（即起始价格对应的 1min bar 时间）
    * 终止时间 t_end_seg   = time[i_end]

条件（对每两个相邻的连续上涨区段 S1 -> S2）：
  1. 中间 bar 数 (i2_start - i1_end - 1) < len(S1) * scale     (scale 默认 1)
  2. start_price2 <= end_price1
  3. end_price2 > end_price1
  4. start_price2 > start_price1

输出（每天一个 parquet 到 SEGMENTS_DAILY_DIR/{YYYYMMDD}.parquet）字段：
  date, code, t_start, t_end, len1, len2,
  start_price1, end_price1, start_price2, end_price2,
  day_max_after_end (t_end 之后当天到收盘的最高价 high),
  next_open (第二天 open)
其中：
  - t_start = 第一段起始价格对应的 1min bar 时间（HHMM 整数）
  - t_end   = 第二段中首次使 close > end_price1 的 1min bar 时间（HHMM 整数）

用法：
  python find_segments.py --date 20250102
"""

from __future__ import annotations

import os
import pickle
import datetime
import logging
import argparse
import time as _time

import pandas as pd
import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ========== 配置 ==========
UNIVERSE_DIR = "/home/datamake119/data1/user118/newhigh/limit_7_up"
DAILY_RESULTS_DIR = os.path.join(UNIVERSE_DIR, "daily_results")
MIN_DATA_DIR = os.path.join(UNIVERSE_DIR, "min_data")  # 已按 universe 过滤的 min_data

OPEN_PRICE_PATH = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea/OPEN_PRICE.pkl"

OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/newhigh_segments"
SEGMENTS_DAILY_DIR = os.path.join(OUTPUT_DIR, "segments_daily")

# 默认参数（可由命令行覆盖）
DEFAULT_CONT = 3
DEFAULT_SCALE = 1.0

# 仅使用连续竞价时段，避免开盘集合竞价 / 收盘 3 分钟干扰
TIME_LO = 930  # 含
TIME_HI = 1457  # 含

# 缓存 next_open，避免重复读取
_NEXT_OPEN_CACHE = {"date_obj": None, "series": None}


def _load_open_price():
    """返回 OPEN_PRICE DataFrame（index: date, columns: pure_code）"""
    return pd.read_pickle(OPEN_PRICE_PATH)


def _get_next_trading_open(date_obj: datetime.date) -> pd.Series | None:
    """返回 date_obj 的下一交易日的 open_price，Series 索引为 pure_code。"""
    df_open = _load_open_price()
    idx = df_open.index
    later = [d for d in idx if d > date_obj]
    if not later:
        return None
    next_day = min(later)
    return df_open.loc[next_day]


def find_segments_in_series(prices: np.ndarray, cont: int) -> list[tuple[int, int]]:
    """
    在一个一维价格序列（已按时间排序）中，找出所有连续上涨区段。
    返回 [(i_start, i_end), ...] 其中 ret_idx = i_start..i_end 对应的 ret>=0 (ret[i]=price[i]-price[i-1])。
    要求区段长度 = i_end - i_start + 1 >= cont。
    """
    n = len(prices)
    if n < 2:
        return []
    diffs = np.diff(prices)  # length n-1; diffs[k] = price[k+1] - price[k]
    up = diffs >= 0  # 注意：等价于 ret>=0
    segs = []
    i = 0
    L = len(up)
    while i < L:
        if up[i]:
            j = i
            while j < L and up[j]:
                j += 1
            # ret>=0 的 bar 索引为 i+1 .. j（对应 price 索引），共 j - i 个
            seg_start_price_idx = i + 1
            seg_end_price_idx = j
            seg_len = seg_end_price_idx - seg_start_price_idx + 1
            if seg_len >= cont:
                segs.append((seg_start_price_idx, seg_end_price_idx))
            i = j
        else:
            i += 1
    return segs


def _save_empty(date_int: str):
    os.makedirs(SEGMENTS_DAILY_DIR, exist_ok=True)
    out_path = os.path.join(SEGMENTS_DAILY_DIR, f"{date_int}.parquet")
    empty = pd.DataFrame(columns=[
        "date", "code", "t_start", "t_end", "len1", "len2",
        "start_price1", "end_price1", "start_price2", "end_price2",
        "day_max_after_end", "next_open",
    ])
    empty.to_parquet(out_path, index=False)


def process_one_date(date_int: str, cont: int, scale: float) -> int:
    date_obj = datetime.datetime.strptime(date_int, "%Y%m%d").date()

    # ---- 读取该日 universe ----
    result_path = os.path.join(DAILY_RESULTS_DIR, f"{date_int}.pkl")
    if not os.path.exists(result_path):
        logger.info("日期 %s: 无 universe pkl", date_int)
        _save_empty(date_int)
        return 0
    with open(result_path, "rb") as f:
        result = pickle.load(f)
    universe_codes = set(result.get("universe_codes", []))
    if not universe_codes:
        logger.info("日期 %s: universe 为空", date_int)
        _save_empty(date_int)
        return 0

    # ---- 读取该日 min_data ----
    min_file = os.path.join(MIN_DATA_DIR, f"{date_int}_min.fea")
    if not os.path.exists(min_file):
        logger.info("日期 %s: min_data 文件不存在 %s", date_int, min_file)
        _save_empty(date_int)
        return 0
    df_min = pd.read_feather(min_file)

    # StockID -> pure code
    df_min["code"] = df_min["StockID"].astype(str).str[2:]
    df_min = df_min[df_min["code"].isin(universe_codes)]
    # 限制在连续竞价时段
    df_min = df_min[(df_min["time"] >= TIME_LO) & (df_min["time"] <= TIME_HI)].copy()
    if df_min.empty:
        logger.info("日期 %s: min_data 过滤后为空", date_int)
        _save_empty(date_int)
        return 0
    df_min = df_min.sort_values(["code", "time"]).reset_index(drop=True)

    # ---- 第二天 open ----
    try:
        next_open_series = _get_next_trading_open(date_obj)
    except Exception as exc:
        logger.warning("读取 next_open 失败: %s", exc)
        next_open_series = None

    cont_int = int(cont)

    records = []
    for code, grp in df_min.groupby("code", sort=False):
        prices = grp["price"].to_numpy(dtype=np.float64)
        times = grp["time"].to_numpy(dtype=np.int64)
        highs = grp["high"].to_numpy(dtype=np.float64)
        if len(prices) < 2 * cont_int + 1:
            continue
        segs = find_segments_in_series(prices, cont_int)
        if len(segs) < 2:
            continue

        for k in range(len(segs) - 1):
            s1_start, s1_end = segs[k]
            s2_start, s2_end = segs[k + 1]
            len1 = s1_end - s1_start + 1
            len2 = s2_end - s2_start + 1
            gap = s2_start - s1_end - 1  # 两段间 ret<0 的 bar 数

            start_price1 = float(prices[s1_start - 1])
            end_price1 = float(prices[s1_end])
            start_price2 = float(prices[s2_start - 1])
            end_price2 = float(prices[s2_end])

            # 条件 1: gap < len1 * scale
            if not (gap < len1 * scale):
                continue
            # 条件 2: start_price2 <= end_price1
            if not (start_price2 <= end_price1):
                continue
            # 条件 3: end_price2 > end_price1
            if not (end_price2 > end_price1):
                continue
            # 条件 4: start_price2 > start_price1
            if not (start_price2 > start_price1):
                continue

            # t_start：第一段起始价格对应的 bar 时间（s1_start - 1）
            t_start = int(times[s1_start - 1])
            # t_end：第二段中 close > end_price1 的首个 bar 时间
            seg2_prices = prices[s2_start:s2_end + 1]
            seg2_times = times[s2_start:s2_end + 1]
            mask = seg2_prices > end_price1
            if not mask.any():
                # 理论上不会发生（end_price2 > end_price1 保证有），但兜底
                t_end = int(seg2_times[-1])
            else:
                t_end_idx = int(np.argmax(mask))
                t_end = int(seg2_times[t_end_idx])

            # 后续当天最高价：t_end 之后到收盘
            after_mask = times > t_end
            day_max_after_end = float(highs[after_mask].max()) if after_mask.any() else float("nan")

            # 第二天 open
            if next_open_series is not None and code in next_open_series.index:
                no_val = next_open_series[code]
                next_open = float(no_val) if pd.notna(no_val) else float("nan")
            else:
                next_open = float("nan")

            records.append({
                "date": date_int,
                "code": code,
                "t_start": t_start,
                "t_end": t_end,
                "len1": int(len1),
                "len2": int(len2),
                "start_price1": start_price1,
                "end_price1": end_price1,
                "start_price2": start_price2,
                "end_price2": end_price2,
                "day_max_after_end": day_max_after_end,
                "next_open": next_open,
            })

    os.makedirs(SEGMENTS_DAILY_DIR, exist_ok=True)
    out_path = os.path.join(SEGMENTS_DAILY_DIR, f"{date_int}.parquet")
    if records:
        df_out = pd.DataFrame(records)
        df_out.to_parquet(out_path, index=False)
        logger.info("日期 %s: 找到 %d 条记录 -> %s", date_int, len(df_out), out_path)
        return len(df_out)
    else:
        _save_empty(date_int)
        logger.info("日期 %s: 无满足条件的记录", date_int)
        return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, required=True, help="交易日 YYYYMMDD")
    parser.add_argument("--cont", type=int, default=DEFAULT_CONT)
    parser.add_argument("--scale", type=float, default=DEFAULT_SCALE)
    args = parser.parse_args()

    t0 = _time.time()
    n = process_one_date(args.date, args.cont, args.scale)
    logger.info("日期 %s 完成: %d 条记录, 耗时 %.1fs", args.date, n, _time.time() - t0)


if __name__ == "__main__":
    main()
