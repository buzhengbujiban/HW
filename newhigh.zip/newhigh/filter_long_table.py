"""
根据 find_segments.py 输出的 (date, code, t_start, t_end)，过滤原 raw_long_table
（沪/深两市分开存放），并按 day 合并到 /home/datamake119/data1/user118/hft/raw_long_table_newhigh/{date}.parquet。

每条 (date, code) 可能对应多个区段（同一只股票一天可能多次满足条件）。
我们取该股该日所有 (t_start, t_end) 区间的并集，落到 raw_long_table 的 time 字段（HHMMSSmmm 格式）。

raw_long_table 中 time 是 HHMMSSmmm 整数（例如 93000000 = 9:30:00.000）。
而 t_start / t_end 是 1min bar 的 HHMM 整数（例如 930 表示 9:30:00 的 bar）。
本脚本将 [t_start, t_end] 闭区间的 1min bar 范围扩展到 raw_time 区间：
  raw_time_lo = t_start * 100000               # HH:MM:00.000
  raw_time_hi = (t_end + 1) * 100000 - 1       # HH:MM:59.999 (即下一分钟前 1ms)
其中 (t_end+1) 需正确处理 MM=59 -> MM=0, HH+=1 的进位。

用法：
  python filter_long_table.py --date 20250102
"""

from __future__ import annotations

import os
import logging
import argparse
import time as _time

import pandas as pd
import numpy as np

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ========== 配置 ==========
SEGMENTS_DAILY_DIR = "/home/datamake119/data1/user118/newhigh/newhigh_segments/segments_daily"

RAW_SH_DIR = "/home/datamake119/data1/user118/hft/raw_long_table/sh_ordertranlob"
RAW_SZ_DIR = "/home/datamake119/data1/user118/hft/raw_long_table/sz_ordertranlob"

OUTPUT_DIR = "/home/datamake119/data1/user118/hft/raw_long_table_newhigh"


def _bar_to_raw_start(bar_hhmm: int) -> int:
    """HHMM -> HHMMSSmmm 起始（HH:MM:00.000）"""
    return int(bar_hhmm) * 100000


def _next_minute(bar_hhmm: int) -> int:
    hh, mm = divmod(int(bar_hhmm), 100)
    mm += 1
    if mm >= 60:
        mm = 0
        hh += 1
    return hh * 100 + mm


def _bar_to_raw_end_inclusive(bar_hhmm: int) -> int:
    """HHMM -> raw_time 闭区间右端 = (HHMM+1)*100000 - 1（即 HH:MM:59.999）"""
    return _next_minute(bar_hhmm) * 100000 - 1


def _merge_intervals(intervals: list[tuple[int, int]]) -> list[tuple[int, int]]:
    """合并重叠 / 相邻区间。"""
    if not intervals:
        return []
    intervals = sorted(intervals)
    merged = [list(intervals[0])]
    for s, e in intervals[1:]:
        if s <= merged[-1][1] + 1:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    return [(s, e) for s, e in merged]


def _mask_in_intervals(times: np.ndarray, intervals: list[tuple[int, int]]) -> np.ndarray:
    """检查每个 time 是否落入任一区间。intervals 已按起点排序且互不重叠。"""
    if len(intervals) == 0:
        return np.zeros(len(times), dtype=bool)
    if len(intervals) == 1:
        lo, hi = intervals[0]
        return (times >= lo) & (times <= hi)
    starts = np.array([iv[0] for iv in intervals], dtype=times.dtype)
    ends = np.array([iv[1] for iv in intervals], dtype=times.dtype)
    # 对每个 time，找到 starts 中 <= time 的最大索引
    idx = np.searchsorted(starts, times, side="right") - 1
    mask = idx >= 0
    valid_idx = idx.copy()
    valid_idx[~mask] = 0
    in_range = (times <= ends[valid_idx]) & mask
    return in_range


def process_one_date(date_int: str) -> int:
    t0 = _time.time()
    seg_file = os.path.join(SEGMENTS_DAILY_DIR, f"{date_int}.parquet")
    if not os.path.exists(seg_file):
        logger.info("日期 %s: segments 文件不存在 %s", date_int, seg_file)
        return 0
    df_seg = pd.read_parquet(seg_file)
    if df_seg.empty:
        logger.info("日期 %s: segments 为空", date_int)
        return 0

    # 按 code 合并区间
    code_to_intervals: dict[str, list[tuple[int, int]]] = {}
    for code, grp in df_seg.groupby("code"):
        intervals = []
        for _, row in grp.iterrows():
            lo = _bar_to_raw_start(int(row["t_start"]))
            hi = _bar_to_raw_end_inclusive(int(row["t_end"]))
            intervals.append((lo, hi))
        code_to_intervals[code] = _merge_intervals(intervals)

    # 拆分沪/深 code 集合
    sh_codes = {c for c in code_to_intervals if c.startswith("6")}
    sz_codes = set(code_to_intervals.keys()) - sh_codes

    # 原 raw_long_table 中 code 字段格式是 'xxxxxx.SH' / 'xxxxxx.SZ'
    sh_full = {f"{c}.SH" for c in sh_codes}
    sz_full = {f"{c}.SZ" for c in sz_codes}

    parts = []

    # ---- 沪市 ----
    sh_file = os.path.join(RAW_SH_DIR, f"{date_int}.parquet")
    if sh_codes and os.path.exists(sh_file):
        t1 = _time.time()
        df_sh = pd.read_parquet(sh_file)
        df_sh = df_sh[df_sh["code"].isin(sh_full)]
        if not df_sh.empty:
            keep_masks = []
            for code_full, sub in df_sh.groupby("code", sort=False):
                pure = code_full.split(".")[0]
                intervals = code_to_intervals.get(pure, [])
                if not intervals:
                    continue
                times = sub["time"].to_numpy()
                m = _mask_in_intervals(times, intervals)
                if m.any():
                    keep_masks.append(sub.loc[m])
            if keep_masks:
                parts.append(pd.concat(keep_masks, ignore_index=False))
        logger.info("  SH: 读 %d 条 -> 过滤后 %d 条 (%.1fs)",
                    len(df_sh), len(parts[-1]) if parts else 0, _time.time() - t1)
    elif sh_codes:
        logger.info("  SH: 文件不存在 %s", sh_file)

    # ---- 深市 ----
    sz_file = os.path.join(RAW_SZ_DIR, f"{date_int}.parquet")
    if sz_codes and os.path.exists(sz_file):
        t1 = _time.time()
        df_sz = pd.read_parquet(sz_file)
        df_sz = df_sz[df_sz["code"].isin(sz_full)]
        added = 0
        if not df_sz.empty:
            keep_masks = []
            for code_full, sub in df_sz.groupby("code", sort=False):
                pure = code_full.split(".")[0]
                intervals = code_to_intervals.get(pure, [])
                if not intervals:
                    continue
                times = sub["time"].to_numpy()
                m = _mask_in_intervals(times, intervals)
                if m.any():
                    keep_masks.append(sub.loc[m])
            if keep_masks:
                tmp = pd.concat(keep_masks, ignore_index=False)
                parts.append(tmp)
                added = len(tmp)
        logger.info("  SZ: 读 %d 条 -> 过滤后 %d 条 (%.1fs)",
                    len(df_sz), added, _time.time() - t1)
    elif sz_codes:
        logger.info("  SZ: 文件不存在 %s", sz_file)

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out_path = os.path.join(OUTPUT_DIR, f"{date_int}.parquet")
    if parts:
        df_out = pd.concat(parts, ignore_index=True)
        df_out = df_out.sort_values(["code", "time"]).reset_index(drop=True)
        df_out.to_parquet(out_path, index=False)
        logger.info("日期 %s: 写入 %d 条 -> %s (总耗时 %.1fs)",
                    date_int, len(df_out), out_path, _time.time() - t0)
        return len(df_out)
    else:
        # 写空文件（保留 schema 不易，所以直接写空 DataFrame）
        pd.DataFrame().to_parquet(out_path, index=False)
        logger.info("日期 %s: 无数据可写出 (%.1fs)", date_int, _time.time() - t0)
        return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, required=True, help="交易日 YYYYMMDD")
    args = parser.parse_args()
    process_one_date(args.date)


if __name__ == "__main__":
    main()
