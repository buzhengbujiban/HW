#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
backtest_checkafterbase56_add5_limitup —— 基于 factor1 高频因子的"择时买入价"回测。

== 思路 ==
checkafterbase56_add5_limitup.py 每天选出一个股票池（date）。本回测在【date 的下一个
交易日 D+1】对池内每只票，用 factor1 的逐笔因子（在 D+1 当天的 order+trans+lob 长表上
重新计算），按"因子值（超过/小于）某固定阈值"的规则确定一个【买入时刻】，并以该时刻
【下一个 tick 的价格】作为买入价。每个因子对应一条规则 ruls_{因子名}。

== 复用 factor1 的因子构造（逐笔，cumsum-ewm）==
本回测计算并使用以下 5 个因子（前 4 个来自 factor1，最后 1 个为按相同 BSimb 思路推广）：
  1. trdact_BSimb_diff                    （主动买-卖 笔数净额的 cumsum-ewm）
  2. size_add_newlevel1_prob_BSimb        （新增更优一档挂单 量占比 的买卖不平衡）
  3. size_trdact_allormorelevel1_prob_BSimb（吃掉一档及以上 成交量占比 的买卖不平衡）
  4. size_trdact_atlevel1_prob_BSimb      （恰好吃掉一档 成交量占比 的买卖不平衡）
  5. size_add_newlevel1_BSimb  ← 推广构造：新增更优一档挂单"量"本身的买卖不平衡
        = (f_add_size_new_B - f_add_size_new_S) / (f_add_size_new_B + f_add_size_new_S)

== 买入价规则 ruls_{因子名} ==
对每个因子设定 (方向, 阈值)：当因子值首次满足"(超过 / 小于) 阈值"时，
记录【下一个 tick 的成交/事件价格】为该票在 D+1 的买入价。
（这些 BSimb / diff 因子为正代表买方占优，故默认规则为"超过 0 即视为买入信号"。）
若全天都没触发，则该票在该规则下不买入。

== 卖出 label ==
以买入日（D+1）为第 1 天：
  开盘卖出：第 2/3/5 天 open      （买入日偏移 1/2/4）
  收盘卖出：第 2/3/5 天 close
共 6 个 label。每条规则、每个 label 计算每个 date 的等权组合收益。

== 输出 ==
  - 每条规则一张收益曲线图（含 6 个 label 的累计求和收益 + 每日买入股票数）。
  - 一张所有规则对比图（取 close_day2 label 的累计收益对比）。
  保存在本目录下。

用法：
  python backtest_checkafterbase56_add5_limitup.py
  python backtest_checkafterbase56_add5_limitup.py --max-days 20   # 仅跑前 N 个可用买入日（调试）
"""

from __future__ import annotations

import os
import glob
import argparse
import logging
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("backtest.base56_add5")

# ============================================================
# 路径配置
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
POOL_DIR = "/home/datamake119/data1/user118/newhigh/checkafterbase56_add5_limitup/segments_daily"

# factor1 用的原始一体长表（沪深分目录），买入日在此重算逐笔因子
RAW_LT_DIR = "/home/datamake119/data1/user118/hft/raw_long_table"
RAW_LT_MARKETS = ("sz", "sh")

OHLC_PATH = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea"
OPEN_PKL = os.path.join(OHLC_PATH, "OPEN_PRICE.pkl")
CLOSE_PKL = os.path.join(OHLC_PATH, "CLOSE_PRICE.pkl")

# ============================================================
# factor1 参数（与 factor1.py 保持一致）
# ============================================================
HL_LEVEL1 = 500
HL_TRDACT_DIFF = 250
AM_START, AM_END = 93000000, 113000000
PM_START, PM_END = 130000000, 145700000

# ============================================================
# 买入价规则：因子名 -> (方向, 阈值)
#   方向 ">"：因子首次 > 阈值时触发；"<"：因子首次 < 阈值时触发。
#   触发后取【下一个 tick 价格】为买入价。
# 这些 BSimb/diff 因子为正代表买方占优，默认"超过 0 即买入"。
# ============================================================
RULES = {
    "trdact_BSimb_diff":                     (">", 0.0),
    "size_add_newlevel1_prob_BSimb":         (">", 0.0),
    "size_trdact_allormorelevel1_prob_BSimb": (">", 0.0),
    "size_trdact_atlevel1_prob_BSimb":       (">", 0.0),
    "size_add_newlevel1_BSimb":              (">", 0.0),  # 推广构造
}

SELL_DAYS = [2, 3, 5]  # 第 2/3/5 天卖出（买入日为第 1 天）


# ============================================================
# 因子计算（逐笔，cumsum-ewm；保留全部 tick，附带 price）
# ============================================================
def cumsum_minus_ewm(values: np.ndarray, halflife: float) -> np.ndarray:
    s = pd.Series(values, dtype="float64")
    cum = s.fillna(0.0).cumsum()
    ewm = cum.ewm(halflife=halflife, adjust=False, ignore_na=True).mean()
    return (cum - ewm).to_numpy()


def _ratio(a: pd.Series, b: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return a / b


def _bsimb(b: pd.Series, s: pd.Series) -> pd.Series:
    with np.errstate(invalid="ignore", divide="ignore"):
        return (b - s) / (b + s)


def _read_buyday_long_table(buy_date: str, codes_pure: set[str]) -> pd.DataFrame:
    """读取买入日沪深一体长表，仅取连续竞价时段 + 目标股票，并做 schema 兼容映射。

    返回带列：code(纯6位), time, type, side, price(真实价), size, volume,
              sellorder, buyorder, bp1, sp1, bv1, sv1, seq_num,
              functionCode, orderKind, orderPrice, orderVolume。
    """
    time_filters = [
        [("time", ">=", AM_START), ("time", "<=", AM_END)],
        [("time", ">=", PM_START), ("time", "<=", PM_END)],
    ]
    use_cols = ["code", "time", "type", "side", "volume", "sellorder", "buyorder",
                "price", "size", "seq_num", "number", "bp1", "sp1", "bv1", "sv1"]
    frames = []
    for market in RAW_LT_MARKETS:
        path = Path(RAW_LT_DIR) / f"{market}_ordertranlob" / f"{buy_date}.parquet"
        if not path.exists():
            continue
        df = pd.read_parquet(path, columns=use_cols, filters=time_filters)
        if df.empty:
            continue
        df["code_pure"] = df["code"].astype(str).str[:6]
        df = df[df["code_pure"].isin(codes_pure)]
        if not df.empty:
            frames.append(df)
    if not frames:
        return pd.DataFrame()
    df = pd.concat(frames, ignore_index=True)
    df["time"] = df["time"].astype("int64")

    # 价格保留真实价（float），单独留一份用于"买入价"
    df["px_real"] = df["price"].astype("float64")

    # schema 兼容：价格列 *10000 转回旧整数口径，供因子触发逻辑里的盘口比较使用
    for c in ["price", "bp1", "sp1"]:
        v = df[c].astype("float64").to_numpy()
        v = np.where(np.isnan(v) | (v <= 0), -10000.0, v * 10000.0)
        df[c] = v.astype("int64")

    type_s = df["type"].astype(str)
    side_s = df["side"].astype(str).where(df["side"].notna(), "")
    is_trade = (type_s == "T").to_numpy()
    is_cxl = (type_s == "D").to_numpy()
    df["functionCode"] = np.where(is_cxl, "C", np.where(~is_trade, side_s.to_numpy(), ""))
    df["orderKind"] = type_s.to_numpy()
    df["orderPrice"] = df["price"]
    df["orderVolume"] = df["volume"]
    df["bidOrder"] = df["buyorder"]
    df["askOrder"] = df["sellorder"]
    return df


def compute_factors_one_stock(tbl_df: pd.DataFrame) -> pd.DataFrame | None:
    """单股票逐笔因子（factor1 口径 + 推广的 size_add_newlevel1_BSimb），保留所有 tick。

    返回列：time, px_real, 以及 RULES 中的 5 个因子。
    """
    if tbl_df.empty:
        return None
    tbl_df = tbl_df.sort_values(["time", "seq_num"]).reset_index(drop=True)
    out = tbl_df[["time", "px_real"]].copy()

    fc = tbl_df["functionCode"].astype(str)
    o_is_buy = fc == "B"
    o_is_sell = fc == "S"

    eat_buy = o_is_buy & (tbl_df["orderKind"].shift(-1) == "T") & (tbl_df["orderPrice"] >= tbl_df["sp1"])
    eat_sell = o_is_sell & (tbl_df["orderKind"].shift(-1) == "T") & (tbl_df["orderPrice"] <= tbl_df["bp1"])

    tbl_df["size_trdact_B"] = tbl_df["size"].where(eat_buy, np.nan)
    tbl_df["size_trdact_S"] = tbl_df["size"].where(eat_sell, np.nan)
    tbl_df["cnt_trdact_B"] = eat_buy * 1.0
    tbl_df["cnt_trdact_S"] = eat_sell * 1.0

    tbl_df["cnt_trdact_allormorelevel1_B"] = eat_buy & (tbl_df["orderVolume"] >= tbl_df["sv1"])
    tbl_df["cnt_trdact_allormorelevel1_S"] = eat_sell & (tbl_df["orderVolume"] >= tbl_df["bv1"])
    tbl_df["size_trdact_allormorelevel1_B"] = tbl_df["size"].where(tbl_df["cnt_trdact_allormorelevel1_B"], np.nan)
    tbl_df["size_trdact_allormorelevel1_S"] = tbl_df["size"].where(tbl_df["cnt_trdact_allormorelevel1_S"], np.nan)

    tbl_df["cnt_trdact_atlevel1_B"] = eat_buy & (tbl_df["orderVolume"] == tbl_df["sv1"])
    tbl_df["cnt_trdact_atlevel1_S"] = eat_sell & (tbl_df["orderVolume"] == tbl_df["bv1"])
    tbl_df["size_trdact_atlevel1_B"] = tbl_df["size"].where(tbl_df["cnt_trdact_atlevel1_B"], np.nan)
    tbl_df["size_trdact_atlevel1_S"] = tbl_df["size"].where(tbl_df["cnt_trdact_atlevel1_S"], np.nan)

    new_buy = o_is_buy & (tbl_df["bp1"] > 0) & (tbl_df["bv1"] == tbl_df["size"]) & (tbl_df["orderPrice"] > tbl_df["bp1"].shift()) & (tbl_df["orderKind"].shift(-1) != "T")
    new_sell = o_is_sell & (tbl_df["sp1"] > 0) & (tbl_df["sv1"] == tbl_df["size"]) & (tbl_df["orderPrice"] < tbl_df["sp1"].shift()) & (tbl_df["orderKind"].shift(-1) != "T")

    tbl_df["add_size_B"] = tbl_df["orderVolume"].where(o_is_buy, np.nan)
    tbl_df["add_size_S"] = tbl_df["orderVolume"].where(o_is_sell, np.nan)
    tbl_df["add_size_newlevel1_B"] = tbl_df["orderVolume"].where(new_buy, np.nan)
    tbl_df["add_size_newlevel1_S"] = tbl_df["orderVolume"].where(new_sell, np.nan)

    def cum_ewm(col: str, hl: float) -> pd.Series:
        return pd.Series(cumsum_minus_ewm(tbl_df[col].to_numpy("float64"), hl), index=tbl_df.index)

    # ---- 成交侧累计 ----
    f_size_B = cum_ewm("size_trdact_B", HL_LEVEL1)
    f_size_S = cum_ewm("size_trdact_S", HL_LEVEL1)
    f_size_lvl1_B = cum_ewm("size_trdact_allormorelevel1_B", HL_LEVEL1)
    f_size_lvl1_S = cum_ewm("size_trdact_allormorelevel1_S", HL_LEVEL1)
    f_size_atlvl1_B = cum_ewm("size_trdact_atlevel1_B", HL_LEVEL1)
    f_size_atlvl1_S = cum_ewm("size_trdact_atlevel1_S", HL_LEVEL1)

    # 因子3：size_trdact_allormorelevel1_prob_BSimb
    out["size_trdact_allormorelevel1_prob_BSimb"] = _bsimb(
        _ratio(f_size_lvl1_B, f_size_B), _ratio(f_size_lvl1_S, f_size_S))
    # 因子4：size_trdact_atlevel1_prob_BSimb
    out["size_trdact_atlevel1_prob_BSimb"] = _bsimb(
        _ratio(f_size_atlvl1_B, f_size_B), _ratio(f_size_atlvl1_S, f_size_S))

    # 因子1：trdact_BSimb_diff（笔数净额，halflife=250）
    net = (tbl_df["cnt_trdact_B"].fillna(0.0) - tbl_df["cnt_trdact_S"].fillna(0.0))
    out["trdact_BSimb_diff"] = pd.Series(
        cumsum_minus_ewm(net.to_numpy("float64"), HL_TRDACT_DIFF), index=tbl_df.index)

    # ---- 委托侧累计 ----
    f_add_size_B = cum_ewm("add_size_B", HL_LEVEL1)
    f_add_size_S = cum_ewm("add_size_S", HL_LEVEL1)
    f_add_size_new_B = cum_ewm("add_size_newlevel1_B", HL_LEVEL1)
    f_add_size_new_S = cum_ewm("add_size_newlevel1_S", HL_LEVEL1)

    # 因子2：size_add_newlevel1_prob_BSimb（占比的 BSimb）
    out["size_add_newlevel1_prob_BSimb"] = _bsimb(
        _ratio(f_add_size_new_B, f_add_size_B), _ratio(f_add_size_new_S, f_add_size_S))

    # 因子5（推广）：size_add_newlevel1_BSimb（新增更优一档"量"本身的 BSimb）
    out["size_add_newlevel1_BSimb"] = _bsimb(f_add_size_new_B, f_add_size_new_S)

    return out


def apply_rule(fac_df: pd.DataFrame, factor_name: str, direction: str, thresh: float) -> float | None:
    """对单股票因子序列应用买入规则：因子首次满足方向/阈值时，取下一个 tick 的价格为买入价。

    返回买入价（真实价 float），无触发返回 None。
    """
    vals = fac_df[factor_name].to_numpy("float64")
    px = fac_df["px_real"].to_numpy("float64")
    if direction == ">":
        hit = vals > thresh
    else:
        hit = vals < thresh
    hit = hit & np.isfinite(vals)
    idx = np.argmax(hit) if hit.any() else -1
    if idx < 0 or not hit[idx]:
        return None
    nxt = idx + 1  # 下一个 tick
    if nxt >= len(px):
        return None
    p = px[nxt]
    if not np.isfinite(p) or p <= 0:
        # 往后找第一个有效价
        for j in range(nxt, len(px)):
            if np.isfinite(px[j]) and px[j] > 0:
                return float(px[j])
        return None
    return float(p)


# ============================================================
# 选股池 + 价格
# ============================================================
def load_pool() -> pd.DataFrame:
    files = sorted(glob.glob(os.path.join(POOL_DIR, "*.parquet")))
    frames = []
    for f in files:
        df = pd.read_parquet(f, columns=["date", "code"])
        if not df.empty:
            frames.append(df)
    if not frames:
        raise RuntimeError(f"{POOL_DIR} 下没有可用的选股池数据")
    pool = pd.concat(frames, ignore_index=True)
    pool["date"] = pd.to_datetime(pool["date"]).dt.strftime("%Y%m%d")
    pool["code"] = pool["code"].astype(str).str.zfill(6)
    pool = pool.drop_duplicates(["date", "code"]).reset_index(drop=True)
    return pool


def load_prices():
    open_price = pd.read_pickle(OPEN_PKL)
    close_price = pd.read_pickle(CLOSE_PKL)
    open_price.index = pd.to_datetime(open_price.index).strftime("%Y%m%d")
    close_price.index = pd.to_datetime(close_price.index).strftime("%Y%m%d")
    open_price.columns = open_price.columns.astype(str).str.zfill(6)
    close_price.columns = close_price.columns.astype(str).str.zfill(6)
    open_price.sort_index(inplace=True)
    close_price.sort_index(inplace=True)
    return open_price, close_price


def available_buyday_set() -> set[str]:
    """买入日必须存在长表（沪或深任一）。"""
    s = set()
    for market in RAW_LT_MARKETS:
        d = Path(RAW_LT_DIR) / f"{market}_ordertranlob"
        if d.exists():
            for p in d.glob("*.parquet"):
                s.add(p.stem)
    return s


# ============================================================
# 主流程：逐 (信号日 -> 买入日 D+1) 计算因子 + 买入价
# ============================================================
def build_buy_prices(pool, trade_dates, date_pos, buyday_avail, max_days=None):
    """返回 buy_records：dict[rule] -> list of {date, buy_date, code, buy_price}。"""
    buy_records = {r: [] for r in RULES}

    grouped = pool.groupby("date")["code"].apply(list)
    signal_dates = [d for d in grouped.index if d in date_pos]

    # 仅保留：买入日 = 信号日下一交易日，且该买入日有长表
    work = []
    for sig in signal_dates:
        bi = date_pos[sig] + 1
        if bi >= len(trade_dates):
            continue
        buy_date = trade_dates[bi]
        if buy_date in buyday_avail:
            work.append((sig, buy_date))
    work.sort()
    if max_days is not None:
        work = work[:max_days]
    logger.info("可回测 (信号日->买入日) 组合数：%d", len(work))

    for n, (sig, buy_date) in enumerate(work, 1):
        codes = set(str(c).zfill(6) for c in grouped[sig])
        lt = _read_buyday_long_table(buy_date, codes)
        if lt.empty:
            logger.info("[%d/%d] 信号日 %s 买入日 %s：长表无目标票", n, len(work), sig, buy_date)
            continue
        n_hit = {r: 0 for r in RULES}
        for code_pure, sub in lt.groupby("code_pure", sort=False):
            fac = compute_factors_one_stock(sub)
            if fac is None or fac.empty:
                continue
            for rule, (direction, thresh) in RULES.items():
                bp = apply_rule(fac, rule, direction, thresh)
                if bp is not None:
                    buy_records[rule].append({
                        "date": sig, "buy_date": buy_date,
                        "code": str(code_pure).zfill(6), "buy_price": bp,
                    })
                    n_hit[rule] += 1
        logger.info("[%d/%d] 信号日 %s 买入日 %s：池 %d 只，触发 %s",
                    n, len(work), sig, buy_date, len(codes),
                    {r: n_hit[r] for r in RULES})

    return {r: pd.DataFrame(v) for r, v in buy_records.items()}


def backtest_rule(buy_df, open_price, close_price, trade_dates, date_pos):
    """对单条规则的买入记录，跑 6 个 label，返回 dict[label] -> DataFrame(index=buy_date, ret,n)。"""
    labels = {f"{t}_day{d}": {} for t in ("open", "close") for d in SELL_DAYS}
    if buy_df is None or buy_df.empty:
        return {k: pd.DataFrame() for k in labels}

    for buy_date, grp in buy_df.groupby("buy_date"):
        if buy_date not in date_pos:
            continue
        bi = date_pos[buy_date]
        codes = grp["code"].tolist()
        buy_px = pd.Series(grp["buy_price"].values, index=grp["code"].values)
        buy_px = buy_px[buy_px > 0]
        if buy_px.empty:
            continue
        for sell_type in ("open", "close"):
            for day in SELL_DAYS:
                si = bi + (day - 1)
                if si >= len(trade_dates):
                    continue
                sell_date = trade_dates[si]
                sell_row = open_price.loc[sell_date] if sell_type == "open" else close_price.loc[sell_date]
                use = [c for c in buy_px.index if c in sell_row.index]
                if not use:
                    continue
                b = buy_px[use]
                s = sell_row[use]
                valid = b.notna() & s.notna() & (b > 0) & (s > 0)
                b, s = b[valid], s[valid]
                if len(b) == 0:
                    continue
                ret = float((s / b - 1.0).mean())
                labels[f"{sell_type}_day{day}"][buy_date] = {"ret": ret, "n": int(len(b))}

    return {k: pd.DataFrame.from_dict(v, orient="index").sort_index() for k, v in labels.items()}


def plot_rule(rule, labels, out_img):
    fig, (ax_a, ax_b) = plt.subplots(2, 1, figsize=(14, 10))
    any_data = False
    for name, df in labels.items():
        if df is None or df.empty:
            continue
        any_data = True
        x = pd.to_datetime(df.index, format="%Y%m%d")
        cum = df["ret"].cumsum() * 100
        ax_a.plot(x, cum.values, marker=".", label=f"{name} (sum={cum.iloc[-1]:.1f}%, win={(df['ret']>0).mean()*100:.0f}%)")
    ax_a.set_title(f"ruls_{rule} —— 各 label 累计收益（求和，等权）")
    ax_a.set_xlabel("buy_date"); ax_a.set_ylabel("cumulative return (%)")
    ax_a.legend(); ax_a.grid(True, alpha=0.3)

    # 每日买入股票数（用任一 label 的 n）
    base = None
    for df in labels.values():
        if df is not None and not df.empty:
            base = df
            break
    if base is not None:
        xc = pd.to_datetime(base.index, format="%Y%m%d")
        ax_b.bar(xc, base["n"].values, width=1.0, color="tab:blue", alpha=0.7,
                 label=f"daily #bought (avg={base['n'].mean():.1f})")
    ax_b.set_title(f"ruls_{rule} —— 每个买入日触发买入的股票数")
    ax_b.set_xlabel("buy_date"); ax_b.set_ylabel("#stocks")
    ax_b.legend(); ax_b.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(out_img, dpi=120)
    plt.close(fig)
    logger.info("规则 %s 图片已保存：%s（有数据=%s）", rule, out_img, any_data)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-days", type=int, default=None, help="只跑前 N 个可用买入日（调试）")
    args = parser.parse_args()

    logger.info("读取价格数据...")
    open_price, close_price = load_prices()
    trade_dates = list(open_price.index)
    date_pos = {d: i for i, d in enumerate(trade_dates)}

    logger.info("读取选股池...")
    pool = load_pool()
    logger.info("选股池：%d 行(date,code)，交易日 %d 个，区间 %s ~ %s",
                len(pool), pool["date"].nunique(), pool["date"].min(), pool["date"].max())

    buyday_avail = available_buyday_set()
    logger.info("可用长表买入日 %d 个", len(buyday_avail))

    logger.info("逐日计算因子 + 应用买入规则...")
    buy_dfs = build_buy_prices(pool, trade_dates, date_pos, buyday_avail, max_days=args.max_days)

    summary_rows = []
    rule_label_cum = {}  # 用于跨规则对比（close_day2）
    for rule in RULES:
        buy_df = buy_dfs[rule]
        # 保存买入记录
        if buy_df is not None and not buy_df.empty:
            buy_df.to_parquet(os.path.join(BASE_DIR, f"buyprice_{rule}.parquet"), index=False)
        labels = backtest_rule(buy_df, open_price, close_price, trade_dates, date_pos)
        plot_rule(rule, labels, os.path.join(BASE_DIR, f"backtest_ruls_{rule}.png"))

        print(f"\n===== ruls_{rule} 各 label 汇总 =====")
        for name, df in labels.items():
            if df is None or df.empty:
                print(f"{name}: 无数据")
                continue
            cum = df["ret"].cumsum()
            print(f"{name}: 买入日数={len(df)}, 平均单次={df['ret'].mean()*100:.3f}%, "
                  f"胜率={(df['ret']>0).mean()*100:.1f}%, 累计求和={cum.iloc[-1]*100:.1f}%")
            summary_rows.append({"rule": rule, "label": name, "n_days": len(df),
                                 "avg_ret_pct": df["ret"].mean()*100,
                                 "winrate_pct": (df["ret"]>0).mean()*100,
                                 "cumsum_pct": cum.iloc[-1]*100})
            if name == "close_day2":
                rule_label_cum[rule] = (pd.to_datetime(df.index, format="%Y%m%d"), df["ret"].cumsum()*100)

    # 跨规则对比图（close_day2）
    if rule_label_cum:
        fig, ax = plt.subplots(figsize=(14, 7))
        for rule, (x, y) in rule_label_cum.items():
            ax.plot(x, y.values, marker=".", label=f"ruls_{rule} (sum={y.iloc[-1]:.1f}%)")
        ax.set_title("各规则对比 —— label=close_day2 累计收益（求和，等权）")
        ax.set_xlabel("buy_date"); ax.set_ylabel("cumulative return (%)")
        ax.legend(); ax.grid(True, alpha=0.3)
        plt.tight_layout()
        out = os.path.join(BASE_DIR, "backtest_rules_compare_close_day2.png")
        plt.savefig(out, dpi=120)
        plt.close(fig)
        logger.info("规则对比图已保存：%s", out)

    if summary_rows:
        pd.DataFrame(summary_rows).to_csv(os.path.join(BASE_DIR, "backtest_summary.csv"), index=False)
        logger.info("汇总已保存：%s", os.path.join(BASE_DIR, "backtest_summary.csv"))


if __name__ == "__main__":
    main()
