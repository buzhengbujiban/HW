"""
checkafterbase_limitup —— 基准股票池（仅保留 checkafter3 的条件 3~10）。

相对 checkafter3_limitup，去掉了对“今日破前高形态/涨到78%”的要求（即原条件1、2），
作为对照基准，用于衡量条件1+2（破前高+78%拉升）相比单纯“昨日涨停+今日K线形态”
是否带来额外的选股价值。

== 8 个筛选条件（代码中以 “条件N” 显式标出，编号沿用 checkafter3）==
  条件3：昨天（D-1）中午收盘价(1130 bar close) == D-1 涨停价
  条件4：昨天（D-1）结束收盘价(日频 CLOSE) == D-1 涨停价
  --- 以下条件 5~10 全部由 “今天的 K 线”（含必要的历史日线）得到 ---
  条件5：今天开盘价 <= 前收盘价（低开/平开）
  条件6：今天收盘价 < limit_up_price * 94%
  条件7：今天 ATR 未放大（含今日的 ATR(N日均值) <= 昨日 ATR，即 ATR 均值未上升，N=ATR_PERIOD）
  条件8：今天 ATR>6% 时，上影线/实体 < 1.5 且 下影线 < 实体；
         今天 ATR<=6% 时，上影线/实体 < 2 或 (上影线+下影线) > 实体
  条件9：今天收盘价 > MA5/MA20/MA60，且 MA5、MA20 斜率 > 0（今日均线 > 昨日均线）
  条件10：DIF 和 MACD 柱线（hist）均向上（今日 > 昨日）

  注：不再要求“今日破前高”(原条件1) 和“今日涨到78% limit_up 且未涨停”(原条件2)。

== 数据 ==
  - 日频：DataLoader.read_daily（LIMIT_UP_PRICE/CLOSE_PRICE/OPEN_PRICE/PRE_CLOSE_PRICE/HIGHEST/LOWEST）
  - 多日技术指标（MA/MACD/ATR）：复权面板 CLOSE_PRICE_2/HIGHEST_PRICE_2/LOWEST_PRICE_2
  - D-1 中午收盘：全市场原始 min_data /mnt/.../min_data/{YYYYMMDD}.fea 的 1130 bar
  - 指数成分 + 去ST：复用 build_up_7/build_universe.py

== 输出 ==
  {OUTPUT_DIR}/segments_daily/{D}.parquet（每只满足条件 3~10 的股票一行）

用法：
  python checkafterbase_limitup.py --date 20250106
"""

from __future__ import annotations

import os
import sys
import datetime
import logging
import argparse
import time as _time

import pandas as pd
import numpy as np

# ---- import DataLoader / build_universe ----
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_NEWHIGH_DIR = os.path.dirname(_THIS_DIR)
_JK_DIR = os.path.dirname(_NEWHIGH_DIR)
sys.path.insert(0, _JK_DIR)
sys.path.insert(0, _NEWHIGH_DIR)
sys.path.insert(0, os.path.join(_JK_DIR, "build_up_7"))

from DataLoader import DataLoader                         # noqa: E402
import build_universe as bu                                # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ========== 配置 ==========
CLOSE_CAP_94 = 0.94              # 条件6：收盘 < 94% 涨停价
PRICE_EPS = 1e-3

RAW_MIN_DATA_DIR = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/min_data"
DAILY_ROOT = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea"
LIMIT_UP_PRICE_PATH = os.path.join(DAILY_ROOT, "LIMIT_UP_PRICE.pkl")

MIDDAY_BAR = 1130

# 技术指标参数
ATR_PERIOD = 14
ATR_BIG_THRESHOLD = 6.0         # 条件8：ATR% 阈值 6%
MA_WINDOWS = (5, 20, 60)
MACD_FAST, MACD_SLOW, MACD_SIGNAL = 12, 26, 9
HIST_DAYS = 90

OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafterbase_limitup"
SEGMENTS_DAILY_DIR = os.path.join(OUTPUT_DIR, "segments_daily")

_TRADING_CAL = None
_ADJ_PANELS = {"close": None, "high": None, "low": None}


# ---------------- 工具函数 ----------------
def _stockid_to_pure(stockid: str) -> str:
    return str(stockid)[2:]


def _pure_to_stockid(pure: str) -> str:
    return ("SH" if pure[0] in ("5", "6", "9") else "SZ") + pure


def _load_trading_calendar() -> list[datetime.date]:
    global _TRADING_CAL
    if _TRADING_CAL is None:
        lu = pd.read_pickle(LIMIT_UP_PRICE_PATH)
        _TRADING_CAL = sorted(lu.index)
    return _TRADING_CAL


def _get_prev1_trading_day(date_obj: datetime.date) -> datetime.date | None:
    cal = _load_trading_calendar()
    if date_obj not in cal:
        return None
    i = cal.index(date_obj)
    return cal[i - 1] if i >= 1 else None


def _read_raw_min(date_obj: datetime.date, stockids: set[str] | None = None) -> pd.DataFrame:
    ymd = date_obj.strftime("%Y%m%d")
    path = os.path.join(RAW_MIN_DATA_DIR, f"{ymd}.fea")
    if not os.path.exists(path):
        return pd.DataFrame()
    df = pd.read_feather(path, use_threads=True)
    if stockids is not None:
        df = df[df["StockID"].isin(stockids)]
    return df


def _load_adj_panels():
    if _ADJ_PANELS["close"] is None:
        for key, fname in (("close", "CLOSE_PRICE_2.pkl"),
                           ("high", "HIGHEST_PRICE_2.pkl"),
                           ("low", "LOWEST_PRICE_2.pkl")):
            df = pd.read_pickle(os.path.join(DAILY_ROOT, fname))
            df = df.sort_index()
            df.columns = df.columns.astype(str)
            _ADJ_PANELS[key] = df
    return _ADJ_PANELS["close"], _ADJ_PANELS["high"], _ADJ_PANELS["low"]


def _next_trading_open(date_obj: datetime.date) -> pd.Series | None:
    df_open = pd.read_pickle(os.path.join(DAILY_ROOT, "OPEN_PRICE.pkl"))
    later = [d for d in df_open.index if d > date_obj]
    if not later:
        return None
    return df_open.loc[min(later)]


_OUT_COLUMNS = [
    "date", "code", "limit_up_price", "next_open",
    "prev1_date", "prev1_midday_close", "prev1_end_close", "prev1_limit_up",
    # 技术指标佐证
    "open", "pre_close", "close", "atr_pct", "atr_ref", "today_tr",
    "ma5", "ma20", "ma60", "dif", "macd_hist",
]


def _save_empty(date_int: str):
    os.makedirs(SEGMENTS_DAILY_DIR, exist_ok=True)
    pd.DataFrame(columns=_OUT_COLUMNS).to_parquet(
        os.path.join(SEGMENTS_DAILY_DIR, f"{date_int}.parquet"), index=False)


# ---------------- 条件 5~10：今日 K 线技术指标 ----------------
def compute_tech_features(date_obj: datetime.date, codes: set[str]) -> dict[str, dict]:
    """对候选 codes 计算 条件5~10，返回 {code: {feature.., pass5..pass10}}。"""
    close2, high2, low2 = _load_adj_panels()
    cal_idx = list(close2.index)
    if date_obj not in close2.index:
        return {}
    pos = cal_idx.index(date_obj)
    lo = max(0, pos - HIST_DAYS + 1)
    win_dates = cal_idx[lo:pos + 1]
    if len(win_dates) < 2:
        return {}

    dl = DataLoader()
    date_int = date_obj.strftime("%Y%m%d")
    daily_raw = dl.read_daily(date_int, fields=[
        "OPEN_PRICE", "PRE_CLOSE_PRICE", "CLOSE_PRICE",
        "HIGHEST_PRICE", "LOWEST_PRICE", "LIMIT_UP_PRICE"])

    out: dict[str, dict] = {}
    avail = [c for c in codes if c in close2.columns]

    for code in avail:
        c_ser = close2[code].loc[win_dates].astype(float)
        h_ser = high2[code].loc[win_dates].astype(float)
        l_ser = low2[code].loc[win_dates].astype(float)
        if c_ser.isna().iloc[-1] or c_ser.notna().sum() < max(MA_WINDOWS) + 1:
            continue

        try:
            o_raw = float(daily_raw.loc[code, "OPEN_PRICE"])
            pc_raw = float(daily_raw.loc[code, "PRE_CLOSE_PRICE"])
            c_raw = float(daily_raw.loc[code, "CLOSE_PRICE"])
            h_raw = float(daily_raw.loc[code, "HIGHEST_PRICE"])
            l_raw = float(daily_raw.loc[code, "LOWEST_PRICE"])
            lu_raw = float(daily_raw.loc[code, "LIMIT_UP_PRICE"])
        except (KeyError, TypeError, ValueError):
            continue
        if any(pd.isna(x) for x in (o_raw, pc_raw, c_raw, h_raw, l_raw, lu_raw)) or lu_raw <= 0:
            continue

        # ===== 条件5：今开 <= 前收 =====
        pass5 = o_raw <= pc_raw + PRICE_EPS

        # ===== 条件6：今收 < 94% 涨停价 =====
        pass6 = c_raw < lu_raw * CLOSE_CAP_94 - PRICE_EPS

        # ---- ATR ----
        prev_c = c_ser.shift(1)
        tr = pd.concat([
            (h_ser - l_ser),
            (h_ser - prev_c).abs(),
            (l_ser - prev_c).abs(),
        ], axis=1).max(axis=1)
        atr = tr.rolling(ATR_PERIOD).mean()
        today_tr = float(tr.iloc[-1])
        atr_ref = float(atr.shift(1).iloc[-1]) if not pd.isna(atr.shift(1).iloc[-1]) else np.nan
        atr_today = float(atr.iloc[-1]) if not pd.isna(atr.iloc[-1]) else np.nan
        atr_pct = (atr_today / float(c_ser.iloc[-1]) * 100.0) if (atr_today and c_ser.iloc[-1]) else np.nan

        # ===== 条件7：今天 ATR 未放大（含今日 ATR <= 昨日 ATR）=====
        if pd.isna(atr_ref) or pd.isna(atr_today):
            continue
        pass7 = atr_today <= atr_ref + PRICE_EPS

        # ===== 条件8：影线/ATR 形态 =====
        body = abs(c_raw - o_raw)
        upper = h_raw - max(o_raw, c_raw)
        lower = min(o_raw, c_raw) - l_raw
        upper_ratio = (upper / body) if body > PRICE_EPS else np.inf
        if pd.isna(atr_pct):
            continue
        if atr_pct > ATR_BIG_THRESHOLD:
            pass8 = (upper_ratio < 1.5) and (lower < body)
        else:
            pass8 = (upper_ratio < 2.0) or ((upper + lower) > body)

        # ===== 条件9：收盘 > MA5/20/60，且 MA5、MA20 斜率 > 0 =====
        ma_vals = {}
        ma_slope_ok = True
        close_above_ok = True
        for w in MA_WINDOWS:
            ma = c_ser.rolling(w).mean()
            ma_today = ma.iloc[-1]
            ma_vals[w] = float(ma_today) if not pd.isna(ma_today) else np.nan
            if pd.isna(ma_today) or c_ser.iloc[-1] <= ma_today:
                close_above_ok = False
            if w in (5, 20):
                ma_prev = ma.iloc[-2]
                if pd.isna(ma_prev) or not (ma_today > ma_prev):
                    ma_slope_ok = False
        pass9 = close_above_ok and ma_slope_ok

        # ===== 条件10：DIF 和 MACD 柱线向上 =====
        ema_fast = c_ser.ewm(span=MACD_FAST, adjust=False).mean()
        ema_slow = c_ser.ewm(span=MACD_SLOW, adjust=False).mean()
        dif = ema_fast - ema_slow
        dea = dif.ewm(span=MACD_SIGNAL, adjust=False).mean()
        hist = 2.0 * (dif - dea)
        dif_up = dif.iloc[-1] > dif.iloc[-2]
        hist_up = hist.iloc[-1] > hist.iloc[-2]
        pass10 = bool(dif_up and hist_up)

        out[code] = {
            "pass5": bool(pass5), "pass6": bool(pass6), "pass7": bool(pass7),
            "pass8": bool(pass8), "pass9": bool(pass9), "pass10": bool(pass10),
            "open": o_raw, "pre_close": pc_raw, "close": c_raw,
            "limit_up_price": lu_raw,
            "atr_pct": float(atr_pct), "atr_ref": float(atr_ref), "today_tr": today_tr,
            "ma5": ma_vals.get(5, np.nan), "ma20": ma_vals.get(20, np.nan),
            "ma60": ma_vals.get(60, np.nan),
            "dif": float(dif.iloc[-1]), "macd_hist": float(hist.iloc[-1]),
        }
    return out


# ---------------- 主流程 ----------------
def process_one_date(date_int: str) -> int:
    date_obj = datetime.datetime.strptime(date_int, "%Y%m%d").date()
    date_str = date_obj.strftime("%Y-%m-%d")

    dl = DataLoader()

    prev1_obj = _get_prev1_trading_day(date_obj)
    if prev1_obj is None:
        logger.info("日期 %s: 找不到昨天交易日（D-1）", date_int)
        _save_empty(date_int)
        return 0
    prev1_int = prev1_obj.strftime("%Y%m%d")
    prev1_str = prev1_obj.strftime("%Y-%m-%d")

    daily_D1 = dl.read_daily(prev1_int, fields=["LIMIT_UP_PRICE", "CLOSE_PRICE"])
    lu_D1 = daily_D1["LIMIT_UP_PRICE"]
    cp_D1 = daily_D1["CLOSE_PRICE"]

    # ===== 条件4：昨天（D-1）收盘 == 涨停（日频，向量化）=====
    valid4 = (lu_D1 > 0) & lu_D1.notna() & cp_D1.notna()
    cond4_mask = valid4 & ((lu_D1 - cp_D1).abs() <= PRICE_EPS)
    cond4_codes = set(cp_D1.index[cond4_mask].astype(str))
    logger.info("日期 %s: 【条件4】D-1(%s) 收盘=涨停 候选 %d 只", date_int, prev1_int, len(cond4_codes))
    if not cond4_codes:
        _save_empty(date_int)
        return 0

    # 指数成分 + 去 ST
    index_by_date = bu.load_index_codes()
    st_set = bu.load_st_set()
    index_pure = {_stockid_to_pure(sid) for sid in index_by_date.get(date_obj, set())}
    if index_pure:
        cond4_codes &= index_pure
    cond4_codes = {c for c in cond4_codes if (date_obj, c) not in st_set}
    logger.info("日期 %s: 【条件4】叠加指数成分+去ST 后候选 %d 只", date_int, len(cond4_codes))
    if not cond4_codes:
        _save_empty(date_int)
        return 0

    # ===== 条件3：昨天（D-1）中午收盘 == 涨停 =====
    df_min_D1 = _read_raw_min(prev1_obj, stockids={_pure_to_stockid(c) for c in cond4_codes})
    if df_min_D1.empty:
        logger.info("日期 %s: D-1(%s) min_data 为空/缺失", date_int, prev1_int)
        _save_empty(date_int)
        return 0
    midday_D1 = df_min_D1[df_min_D1["time"] == MIDDAY_BAR][["StockID", "price"]].copy()
    midday_D1["code"] = midday_D1["StockID"].map(_stockid_to_pure)
    midday_close_map = dict(zip(midday_D1["code"], midday_D1["price"].astype(float)))

    cond3_codes = set()
    for code in cond4_codes:
        mc = midday_close_map.get(code)
        if mc is None:
            continue
        lu1 = lu_D1.get(code, np.nan)
        if pd.notna(lu1) and abs(mc - float(lu1)) <= PRICE_EPS:
            cond3_codes.add(code)
    logger.info("日期 %s: 【条件3】D-1 中午收盘=涨停 候选 %d 只", date_int, len(cond3_codes))
    if not cond3_codes:
        _save_empty(date_int)
        return 0

    # ===== 条件5~10：今日 K 线技术过滤 =====
    tech = compute_tech_features(date_obj, cond3_codes)
    pass_codes = {
        code for code, f in tech.items()
        if f["pass5"] or not f["pass6"] #and f["pass7"] and f["pass8"] and f["pass9"] and f["pass10"]
    }
    logger.info("日期 %s: 【条件5-10】今日K线技术过滤后候选 %d 只", date_int, len(pass_codes))
    if not pass_codes:
        _save_empty(date_int)
        return 0

    # ---- 第二天 open（回测备用）----
    try:
        next_open_series = _next_trading_open(date_obj)
    except Exception as exc:
        logger.warning("读取 next_open 失败: %s", exc)
        next_open_series = None

    records = []
    for code in sorted(pass_codes):
        tf = tech[code]
        if next_open_series is not None and code in next_open_series.index:
            no_val = next_open_series[code]
            next_open = float(no_val) if pd.notna(no_val) else float("nan")
        else:
            next_open = float("nan")
        records.append({
            "date": date_str, "code": code,
            "limit_up_price": tf["limit_up_price"], "next_open": next_open,
            "prev1_date": prev1_str,
            "prev1_midday_close": float(midday_close_map.get(code, np.nan)),
            "prev1_end_close": float(cp_D1.get(code, np.nan)),
            "prev1_limit_up": float(lu_D1.get(code, np.nan)),
            "open": tf["open"], "pre_close": tf["pre_close"], "close": tf["close"],
            "atr_pct": tf["atr_pct"], "atr_ref": tf["atr_ref"], "today_tr": tf["today_tr"],
            "ma5": tf["ma5"], "ma20": tf["ma20"], "ma60": tf["ma60"],
            "dif": tf["dif"], "macd_hist": tf["macd_hist"],
        })

    os.makedirs(SEGMENTS_DAILY_DIR, exist_ok=True)
    out_path = os.path.join(SEGMENTS_DAILY_DIR, f"{date_int}.parquet")
    if records:
        df_out = pd.DataFrame(records)
        df_out.to_parquet(out_path, index=False)
        logger.info("日期 %s: 满足条件3~10 记录 %d 条（%d 只股票）-> %s",
                    date_int, len(df_out), df_out["code"].nunique(), out_path)
        return len(df_out)
    _save_empty(date_int)
    logger.info("日期 %s: 无满足条件3~10的记录", date_int)
    return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, default="20250106", help="交易日 D，格式 YYYYMMDD")
    args = parser.parse_args()

    t0 = _time.time()
    n = process_one_date(args.date)
    logger.info("日期 %s 完成: %d 条记录, 耗时 %.1fs", args.date, n, _time.time() - t0)


if __name__ == "__main__":
    main()
