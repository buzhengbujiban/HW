"""
checkafter2_limitup 选股池简单回测（两种买入方案）

选股池：/home/datamake119/data1/user118/newhigh/checkafter2_limitup/segments_daily/{date}.parquet
（满足四条件：日内破前高 + 今天涨到78%但没涨停 + 昨天中午收盘=涨停 + 昨天收盘=涨停）

回测逻辑：
- 买入方案 A（buyD_close）：在【date 当天】以【收盘价】等权买入当日选出的所有股票。
- 买入方案 B（buyD1_open）：在【date 的下一个交易日】以【开盘价】等权买入。
- 卖出口径（统一以“买入日”为基准，第N天 = 买入日之后第 N-1 个交易日）：
    开盘卖出 label：第2/3/5天开盘价卖出 -> 买入日偏移 1 / 2 / 4 日 open
    收盘卖出 label：第2/3/5天收盘价卖出 -> 买入日偏移 1 / 2 / 4 日 close
  => 每种买入方案各 6 个 label（open_day{2,3,5} + close_day{2,3,5}），共 12 个 label。
- 每个 label 计算每个 date 的等权组合收益。
- 绘制两种收益曲线：A 累乘净值（复利）、B 累计求和（不复投）。
- 价格使用原始未复权 OPEN_PRICE / CLOSE_PRICE（买卖均日频价，口径一致）。

输出：两张收益曲线图（每种买入方案一张）+ 汇总，保存在本目录。

用法：
  python backtest_checkafter2_limitup.py
"""

import os
import glob
import logging

import matplotlib
matplotlib.use("Agg")  # 无显示环境保存图片
import matplotlib.pyplot as plt
import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger(__name__)

# ============================================================
# 路径配置
# ============================================================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
POOL_DIR = "/home/datamake119/data1/user118/newhigh/checkafterbase56_limitup/segments_daily"
OHLC_PATH = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea"
OPEN_PKL = os.path.join(OHLC_PATH, "OPEN_PRICE.pkl")    # 原始开盘价
CLOSE_PKL = os.path.join(OHLC_PATH, "CLOSE_PRICE.pkl")  # 原始收盘价

# ============================================================
# 卖出口径（以买入日为基准，第N天 -> 偏移 N-1）
# ============================================================
SELL_DAYS = [1, 2, 3, 5]  # 开盘/收盘均在第2/3/5天卖出


def load_prices():
    """读取原始开盘价、收盘价，索引统一为 YYYYMMDD 字符串。"""
    open_price = pd.read_pickle(OPEN_PKL)
    close_price = pd.read_pickle(CLOSE_PKL)
    open_price.index = pd.to_datetime(open_price.index).strftime("%Y%m%d")
    close_price.index = pd.to_datetime(close_price.index).strftime("%Y%m%d")
    open_price.sort_index(inplace=True)
    close_price.sort_index(inplace=True)
    return open_price, close_price


def load_pool():
    """读取所有 segments_daily parquet，按 (date, code) 去重（取首条）。

    返回 DataFrame，列：date(YYYYMMDD str), code(6位str)。
    （本回测买入价来自日频 open/close，不需要 end_price1）
    """
    files = sorted(glob.glob(os.path.join(POOL_DIR, "*.parquet")))
    frames = []
    for f in files:
        df = pd.read_parquet(f, columns=["date", "code"])
        if not df.empty:
            frames.append(df)
    if not frames:
        raise RuntimeError(f"{POOL_DIR} 下没有可用的选股池数据")
    pool = pd.concat(frames, ignore_index=True)
    pool["date"] = pd.to_datetime(pool["date"]).dt.strftime("%Y%m%d")
    pool["code"] = pool["code"].astype(str).str.zfill(6)
    pool = pool.drop_duplicates(["date", "code"]).reset_index(drop=True)
    return pool


def daily_equal_weight_return(codes, buy_price_row, sell_price_row):
    """某买入日选出股票的等权组合收益。价格缺失或<=0 的股票剔除。"""
    codes = [c for c in codes if c in buy_price_row.index and c in sell_price_row.index]
    if not codes:
        return None, 0
    buy = buy_price_row[codes]
    sell = sell_price_row[codes]
    valid = buy.notna() & sell.notna() & (buy > 0) & (sell > 0)
    buy = buy[valid]
    sell = sell[valid]
    if len(buy) == 0:
        return None, 0
    ret = sell / buy - 1.0
    return float(ret.mean()), int(len(buy))


def backtest_one_label(pool, open_price, close_price, buy_offset, buy_type,
                       sell_offset, sell_type):
    """
    对单个 label 回测。
    buy_offset/buy_type : 买入日相对 date 的偏移 + 'open'/'close'。
    sell_offset/sell_type: 卖出日相对【买入日】的偏移 + 'open'/'close'。
    返回 DataFrame(index=date, columns=['ret','n','buy_date','sell_date'])。
    """
    trade_dates = open_price.index
    date_pos = {d: i for i, d in enumerate(trade_dates)}

    records = {}
    grouped = pool.groupby("date")["code"].apply(list)

    for date, codes in grouped.items():
        if date not in date_pos:
            logger.warning("信号日 %s 不在价格交易日中，跳过", date)
            continue

        buy_idx = date_pos[date] + buy_offset
        if buy_idx >= len(trade_dates):
            continue
        buy_date = trade_dates[buy_idx]

        sell_idx = buy_idx + sell_offset
        if sell_idx >= len(trade_dates):
            continue
        sell_date = trade_dates[sell_idx]

        buy_row = open_price.loc[buy_date] if buy_type == "open" else close_price.loc[buy_date]
        sell_row = open_price.loc[sell_date] if sell_type == "open" else close_price.loc[sell_date]

        ret, n = daily_equal_weight_return(codes, buy_row, sell_row)
        if ret is None:
            continue
        records[date] = {"ret": ret, "n": n, "buy_date": buy_date, "sell_date": sell_date}

    return pd.DataFrame.from_dict(records, orient="index").sort_index()


def daily_pool_counts(pool):
    """每天股票池中的股票数量（时序），返回 Series(index=date 升序, value=count)。"""
    counts = pool.groupby("date")["code"].nunique().sort_index()
    return counts


def run_scheme(pool, open_price, close_price, buy_offset, buy_type, scheme_name, out_img):
    """对一种买入方案，跑 open/close × 第2/3/5天 共 6 个 label，并绘图 + 汇总。"""
    labels = {}
    for sell_type in ("open", "close"):
        for day in SELL_DAYS:
            sell_offset = day - 1  # 以买入日为第1天
            name = f"{sell_type}_day{day}"
            labels[name] = backtest_one_label(
                pool, open_price, close_price,
                buy_offset, buy_type, sell_offset, sell_type,
            )
            logger.info("[%s] label %s 完成，有效交易日 %d", scheme_name, name, len(labels[name]))

    # 绘图：3 行子图（净值 / 累计求和 / 每日股票池数量）
    fig, (ax_a, ax_b, ax_c) = plt.subplots(3, 1, figsize=(14, 15))
    for name, df in labels.items():
        if df.empty:
            logger.warning("[%s] label %s no data, skip", scheme_name, name)
            continue
        x = pd.to_datetime(df.index, format="%Y%m%d")
        nav = (1 + df["ret"]).cumprod()
        ax_a.plot(x, nav.values, label=f"{name} (nav={nav.iloc[-1]:.3f})")
        cum_sum = df["ret"].cumsum()
        ax_b.plot(x, cum_sum.values * 100, label=f"{name} (sum={cum_sum.iloc[-1]*100:.1f}%)")

    ax_a.set_title(f"checkafter2 [{scheme_name}] NAV (compounded, equal-weight)")
    ax_a.set_xlabel("date"); ax_a.set_ylabel("cumulative NAV")
    ax_a.legend(); ax_a.grid(True, alpha=0.3)
    ax_b.set_title(f"checkafter2 [{scheme_name}] cumulative sum of per-trade return (no compounding)")
    ax_b.set_xlabel("date"); ax_b.set_ylabel("cumulative return (%)")
    ax_b.legend(); ax_b.grid(True, alpha=0.3)

    # ===== 底部新增：时序上每天股票池中股票数量 =====
    counts = daily_pool_counts(pool)
    xc = pd.to_datetime(counts.index, format="%Y%m%d")
    ax_c.bar(xc, counts.values, width=1.0, color="tab:blue", alpha=0.7,
             label=f"daily pool size (avg={counts.mean():.1f}, max={counts.max()}, total_days={len(counts)})")
    ax_c.set_title(f"checkafter2 [{scheme_name}] daily stock count in pool")
    ax_c.set_xlabel("date"); ax_c.set_ylabel("#stocks")
    ax_c.legend(); ax_c.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(out_img, dpi=120)
    plt.close(fig)
    logger.info("[%s] 图片已保存：%s", scheme_name, out_img)
    logger.info("[%s] 每日股票池数量：均值 %.2f，最大 %d，最小 %d，有股票交易日 %d",
                scheme_name, counts.mean(), counts.max(), counts.min(), len(counts))


    # 汇总
    print(f"\n===== [{scheme_name}] 各 label 汇总 =====")
    for name, df in labels.items():
        if df.empty:
            continue
        nav = (1 + df["ret"]).cumprod()
        cum_sum = df["ret"].cumsum()
        print(f"{name}: 交易日数={len(df)}, 平均单次收益={df['ret'].mean()*100:.3f}%, "
              f"胜率={(df['ret']>0).mean()*100:.1f}%, "
              f"累乘净值={nav.iloc[-1]:.3f}, 累计求和={cum_sum.iloc[-1]*100:.1f}%")
    return labels


def main():
    logger.info("读取价格数据...")
    open_price, close_price = load_prices()
    logger.info("价格数据：open %s, close %s", open_price.shape, close_price.shape)

    logger.info("读取选股池...")
    pool = load_pool()
    logger.info("选股池：%d 行(date,code)，交易日 %d 个，区间 %s ~ %s",
                len(pool), pool["date"].nunique(), pool["date"].min(), pool["date"].max())

    # 买入方案 A：date 当天收盘价买入（buy_offset=0, close）
    run_scheme(pool, open_price, close_price,
               buy_offset=0, buy_type="close",
               scheme_name="buyD_close",
               out_img=os.path.join(BASE_DIR, "backtest_buyDbase56_close.png"))

    # 买入方案 B：date 下一交易日开盘价买入（buy_offset=1, open）
    run_scheme(pool, open_price, close_price,
               buy_offset=1, buy_type="open",
               scheme_name="buyD1_open",
               out_img=os.path.join(BASE_DIR, "backtest_buyD1base56_open.png"))


if __name__ == "__main__":
    main()
