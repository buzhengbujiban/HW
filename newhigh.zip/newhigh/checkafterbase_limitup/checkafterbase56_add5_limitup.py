"""
checkafterbase56_add5_limitup —— 在 checkafterbase56 的基础上，叠加 checkafter5 的全部条件。

== 条件编号方案 ==
  条件3、4：昨日涨停（D-1 中午收盘=涨停、D-1 结束收盘=涨停）
  --- 以下为 base56 的 6 个 K 线条件（编号 5~10，原样保留，以 passN 标志形式）---
  条件5 ：今天开盘价 <= 前收盘价（低开/平开）
  条件6 ：今天收盘价 < limit_up_price * 94%
  条件7 ：今天 ATR 未放大（含今日的 ATR(N日均值) <= 昨日 ATR）
  条件8 ：影线/实体形态约束（ATR>6% 与 <=6% 两种口径）
  条件9 ：今收 > MA5/MA20/MA60，且 MA5、MA20 斜率 > 0
  条件10：DIF 和 MACD 柱线（hist）均向上
  --- 以下为 checkafter5 的 8 个条件，顺序续编为 11~18（同样以 passN 标志形式）---
  条件11：剔除 C5_WINDOW 日内曾经 “冲高>RALLY 后回调>PULLBACK” 的票     （原 after5 条件5）
  条件12：今日涨停价 >= C6_MIN_LIMIT_UP 且 昨日市值 >= C6_MIN_MKTCAP    （原 after5 条件6）
  条件13：剔除过去 C7_DOWN_DAYS 天曾经跌停的票                          （原 after5 条件7）
  条件14：昨日成交额 / 前 5 日成交额均值，低于截面 95% 分位数            （原 after5 条件8）
  条件15：昨日市值 小于截面 96% 分位数                                  （原 after5 条件9）
  条件16：20 日涨幅 处于截面 99% 分位数以下                             （原 after5 条件10）
  条件17：昨日 1min_pct 最大值 和 1min_turnoverratio 最大值 均 < 截面 99.2% 分位数（原 after5 条件11）
  条件18：今日筹码分布： 获利盘 <= 50% 且 concentration_90 <= 0.6       （原 after5 条件12）

== 截面口径 ==
  条件 14/15/16/17 的 “截面分位数” 在 “当日全市场有效股票（含 D-1 数据完整）” 上计算，
  然后用作阈值过滤候选股票（见 CROSS_SECTION_UNIVERSE）。

== 数据 ==
  - 日频：DataLoader.read_daily（LIMIT_UP_PRICE/CLOSE_PRICE/OPEN_PRICE/PRE_CLOSE_PRICE/HIGHEST/LOWEST）
  - 多日技术指标/截面：复权面板 CLOSE_PRICE_2/HIGHEST_PRICE_2/LOWEST_PRICE_2 及
                       MARKET_VALUE/NEG_MARKET_VALUE/TURNOVER_VALUE/TURNOVER_RATE/LIMIT_DOWN_PRICE
  - D-1 中午收盘 / 全天 1min：原始 min_data /mnt/.../min_data/{YYYYMMDD}.fea
  - 指数成分 + 去ST：复用 build_up_7/build_universe.py

== 输出 ==
  {OUTPUT_DIR}/segments_daily/{D}.parquet（每只满足全部启用条件的股票一行）

用法：
  python checkafterbase56_add5_limitup.py --date 20250106
"""

from __future__ import annotations

import os
import sys
import datetime
import logging
import argparse
import time as _time

import pandas as pd
import numpy as np

# ---- import DataLoader / build_universe ----
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_NEWHIGH_DIR = os.path.dirname(_THIS_DIR)
_JK_DIR = os.path.dirname(_NEWHIGH_DIR)
sys.path.insert(0, _JK_DIR)
sys.path.insert(0, _NEWHIGH_DIR)
sys.path.insert(0, os.path.join(_JK_DIR, "build_up_7"))

from DataLoader import DataLoader                         # noqa: E402
import build_universe as bu                                # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ========== 配置 ==========
PRICE_EPS = 1e-3
MIDDAY_BAR = 1130
TIME_LO = 930
TIME_HI = 1500

RAW_MIN_DATA_DIR = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/min_data"
DAILY_ROOT = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea"
LIMIT_UP_PRICE_PATH = os.path.join(DAILY_ROOT, "LIMIT_UP_PRICE.pkl")

# ---- base56 条件 5~10 参数 ----
CLOSE_CAP_94 = 0.94              # 条件6：收盘 < 94% 涨停价
ATR_PERIOD = 14
ATR_BIG_THRESHOLD = 6.0          # 条件8：ATR% 阈值 6%
MA_WINDOWS = (5, 20, 60)
MACD_FAST, MACD_SLOW, MACD_SIGNAL = 12, 26, 9
HIST_DAYS = 90

# ---- after5 条件 11~18 参数（沿用 checkafter5 设置）----
C11_WINDOW = 25                  # 条件11：回看窗口
C11_RALLY = 1.9                  # 条件11：冲高阈值
C11_PULLBACK = 0.55              # 条件11：回调阈值
C12_MIN_LIMIT_UP = 9.6           # 条件12：今日涨停价下限
C12_MIN_MKTCAP = 10e8            # 条件12：昨日市值下限（元）
C13_DOWN_DAYS = 3                # 条件13：过去 N 天是否跌停
C14_AMT_LOOKBACK = 5             # 条件14：前 5 日成交额均值
C14_QUANTILE = 0.95              # 条件14：低于截面 95% 分位数
C15_QUANTILE = 0.96              # 条件15：小于截面 96% 分位数
C16_WINDOW = 20                  # 条件16：20 日涨幅
C16_QUANTILE = 0.99              # 条件16：截面 99% 分位数以下
C17_QUANTILE = 0.992             # 条件17：截面 99.2% 分位数
C18_CHIP_DAYS = 120              # 条件18：筹码分布回看天数
C18_PROFIT_MAX = 0.50            # 条件18：获利盘 <= 50%
C18_CONC90_MAX = 0.60            # 条件18：concentration_90 <= 0.6
C18_GRID = 300                   # 条件18：筹码价格网格数

# 截面口径："index"=指数成分去ST后截面；"market"=全市场有效票截面
CROSS_SECTION_UNIVERSE = "market"

OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafterbase56_add5_limitup"
SEGMENTS_DAILY_DIR = os.path.join(OUTPUT_DIR, "segments_daily")

# 面板缓存
_PANELS: dict[str, pd.DataFrame] = {}
_TRADING_CAL = None
_ADJ_PANELS = {"close": None, "high": None, "low": None}


# ---------------- 工具函数 ----------------
def _stockid_to_pure(stockid: str) -> str:
    return str(stockid)[2:]


def _pure_to_stockid(pure: str) -> str:
    return ("SH" if pure[0] in ("5", "6", "9") else "SZ") + pure


def _load_panel(field: str) -> pd.DataFrame:
    if field not in _PANELS:
        df = pd.read_pickle(os.path.join(DAILY_ROOT, f"{field}.pkl"))
        df = df.sort_index()
        df.columns = df.columns.astype(str)
        _PANELS[field] = df
    return _PANELS[field]


def _load_trading_calendar() -> list[datetime.date]:
    global _TRADING_CAL
    if _TRADING_CAL is None:
        _TRADING_CAL = sorted(_load_panel("LIMIT_UP_PRICE").index)
    return _TRADING_CAL


def _get_prev1_trading_day(date_obj: datetime.date) -> datetime.date | None:
    cal = _load_trading_calendar()
    if date_obj not in cal:
        return None
    i = cal.index(date_obj)
    return cal[i - 1] if i >= 1 else None


def _load_adj_panels():
    if _ADJ_PANELS["close"] is None:
        _ADJ_PANELS["close"] = _load_panel("CLOSE_PRICE_2")
        _ADJ_PANELS["high"] = _load_panel("HIGHEST_PRICE_2")
        _ADJ_PANELS["low"] = _load_panel("LOWEST_PRICE_2")
    return _ADJ_PANELS["close"], _ADJ_PANELS["high"], _ADJ_PANELS["low"]


def _read_raw_min(date_obj: datetime.date, stockids: set[str] | None = None) -> pd.DataFrame:
    ymd = date_obj.strftime("%Y%m%d")
    path = os.path.join(RAW_MIN_DATA_DIR, f"{ymd}.fea")
    if not os.path.exists(path):
        return pd.DataFrame()
    df = pd.read_feather(path, use_threads=True)
    if stockids is not None:
        df = df[df["StockID"].isin(stockids)]
    return df


def _next_trading_open(date_obj: datetime.date) -> pd.Series | None:
    df_open = _load_panel("OPEN_PRICE")
    later = [d for d in df_open.index if d > date_obj]
    if not later:
        return None
    return df_open.loc[min(later)]


_OUT_COLUMNS = [
    "date", "code", "limit_up_price", "next_open",
    "prev1_date", "prev1_midday_close", "prev1_end_close", "prev1_limit_up",
    # base56 条件 5~10 佐证
    "open", "pre_close", "close", "atr_pct", "atr_ref", "today_tr",
    "ma5", "ma20", "ma60", "dif", "macd_hist",
    # after5 条件 11~18 佐证
    "mktcap_prev1", "amt_ratio", "ret20",
    "max_1min_pct", "max_1min_turnover", "profit_ratio", "concentration_90",
]


def _save_empty(date_int: str):
    os.makedirs(SEGMENTS_DAILY_DIR, exist_ok=True)
    pd.DataFrame(columns=_OUT_COLUMNS).to_parquet(
        os.path.join(SEGMENTS_DAILY_DIR, f"{date_int}.parquet"), index=False)


# ===================================================================
# 条件 5~10：今日 K 线技术指标（来自 base56，原样保留，输出 pass5~pass10）
# ===================================================================
def compute_tech_features(date_obj: datetime.date, codes: set[str]) -> dict[str, dict]:
    """对候选 codes 计算 条件5~10，返回 {code: {feature.., pass5..pass10}}。"""
    close2, high2, low2 = _load_adj_panels()
    cal_idx = list(close2.index)
    if date_obj not in close2.index:
        return {}
    pos = cal_idx.index(date_obj)
    lo = max(0, pos - HIST_DAYS + 1)
    win_dates = cal_idx[lo:pos + 1]
    if len(win_dates) < 2:
        return {}

    dl = DataLoader()
    date_int = date_obj.strftime("%Y%m%d")
    daily_raw = dl.read_daily(date_int, fields=[
        "OPEN_PRICE", "PRE_CLOSE_PRICE", "CLOSE_PRICE",
        "HIGHEST_PRICE", "LOWEST_PRICE", "LIMIT_UP_PRICE"])

    out: dict[str, dict] = {}
    avail = [c for c in codes if c in close2.columns]

    for code in avail:
        c_ser = close2[code].loc[win_dates].astype(float)
        h_ser = high2[code].loc[win_dates].astype(float)
        l_ser = low2[code].loc[win_dates].astype(float)
        if c_ser.isna().iloc[-1] or c_ser.notna().sum() < max(MA_WINDOWS) + 1:
            continue

        try:
            o_raw = float(daily_raw.loc[code, "OPEN_PRICE"])
            pc_raw = float(daily_raw.loc[code, "PRE_CLOSE_PRICE"])
            c_raw = float(daily_raw.loc[code, "CLOSE_PRICE"])
            h_raw = float(daily_raw.loc[code, "HIGHEST_PRICE"])
            l_raw = float(daily_raw.loc[code, "LOWEST_PRICE"])
            lu_raw = float(daily_raw.loc[code, "LIMIT_UP_PRICE"])
        except (KeyError, TypeError, ValueError):
            continue
        if any(pd.isna(x) for x in (o_raw, pc_raw, c_raw, h_raw, l_raw, lu_raw)) or lu_raw <= 0:
            continue

        # ===== 条件5：今开 <= 前收 =====
        pass5 = o_raw <= pc_raw * 1.01 + PRICE_EPS 

        # ===== 条件6：今收 < 94% 涨停价 =====
        pass6 = c_raw < lu_raw * CLOSE_CAP_94 - PRICE_EPS

        # # ---- ATR ----
        # prev_c = c_ser.shift(1)
        # tr = pd.concat([
        #     (h_ser - l_ser),
        #     (h_ser - prev_c).abs(),
        #     (l_ser - prev_c).abs(),
        # ], axis=1).max(axis=1)
        # atr = tr.rolling(ATR_PERIOD).mean()
        # today_tr = float(tr.iloc[-1])
        # atr_ref = float(atr.shift(1).iloc[-1]) if not pd.isna(atr.shift(1).iloc[-1]) else np.nan
        # atr_today = float(atr.iloc[-1]) if not pd.isna(atr.iloc[-1]) else np.nan
        # atr_pct = (atr_today / float(c_ser.iloc[-1]) * 100.0) if (atr_today and c_ser.iloc[-1]) else np.nan

        # # ===== 条件7：今天 ATR 未放大（含今日 ATR <= 昨日 ATR）=====
        # if pd.isna(atr_ref) or pd.isna(atr_today):
        #     continue
        # pass7 = atr_today <= atr_ref + PRICE_EPS

        # # ===== 条件8：影线/ATR 形态 =====
        # body = abs(c_raw - o_raw)
        # upper = h_raw - max(o_raw, c_raw)
        # lower = min(o_raw, c_raw) - l_raw
        # upper_ratio = (upper / body) if body > PRICE_EPS else np.inf
        # if pd.isna(atr_pct):
        #     continue
        # if atr_pct > ATR_BIG_THRESHOLD:
        #     pass8 = (upper_ratio < 1.5) and (lower < body)
        # else:
        #     pass8 = (upper_ratio < 2.0) or ((upper + lower) > body)

        # # ===== 条件9：收盘 > MA5/20/60，且 MA5、MA20 斜率 > 0 =====
        # ma_vals = {}
        # ma_slope_ok = True
        # close_above_ok = True
        # for w in MA_WINDOWS:
        #     ma = c_ser.rolling(w).mean()
        #     ma_today = ma.iloc[-1]
        #     ma_vals[w] = float(ma_today) if not pd.isna(ma_today) else np.nan
        #     if pd.isna(ma_today) or c_ser.iloc[-1] <= ma_today:
        #         close_above_ok = False
        #     if w in (5, 20):
        #         ma_prev = ma.iloc[-2]
        #         if pd.isna(ma_prev) or not (ma_today > ma_prev):
        #             ma_slope_ok = False
        # pass9 = close_above_ok and ma_slope_ok

        # # ===== 条件10：DIF 和 MACD 柱线向上 =====
        # ema_fast = c_ser.ewm(span=MACD_FAST, adjust=False).mean()
        # ema_slow = c_ser.ewm(span=MACD_SLOW, adjust=False).mean()
        # dif = ema_fast - ema_slow
        # dea = dif.ewm(span=MACD_SIGNAL, adjust=False).mean()
        # hist = 2.0 * (dif - dea)
        # dif_up = dif.iloc[-1] > dif.iloc[-2]
        # hist_up = hist.iloc[-1] > hist.iloc[-2]
        # pass10 = bool(dif_up and hist_up)

        out[code] = {
            "pass5": bool(pass5), "pass6": bool(pass6), #"pass7": bool(pass7),
            # "pass8": bool(pass8), "pass9": bool(pass9), "pass10": bool(pass10),
            "open": o_raw, "pre_close": pc_raw, "close": c_raw,
            # "limit_up_price": lu_raw,
            # "atr_pct": float(atr_pct), "atr_ref": float(atr_ref), "today_tr": today_tr,
            # "ma5": ma_vals.get(5, np.nan), "ma20": ma_vals.get(20, np.nan),
            # "ma60": ma_vals.get(60, np.nan),
            # "dif": float(dif.iloc[-1]), "macd_hist": float(hist.iloc[-1]),
        }
    return out


# ===================================================================
# 条件 11~18：来自 checkafter5，顺序续编号，输出 pass11~pass18
# ===================================================================
def compute_conditions_11_18(date_obj: datetime.date, candidate_codes: set[str]) -> dict[str, dict]:
    """对候选 codes 计算 条件11~18，返回 {code: {feature.., pass11..pass18}}。"""
    date_int = date_obj.strftime("%Y%m%d")
    cal = _load_trading_calendar()
    if date_obj not in cal:
        return {}
    i_today = cal.index(date_obj)
    if i_today < max(C11_WINDOW, C16_WINDOW + 1, C14_AMT_LOOKBACK + 1, C18_CHIP_DAYS) + 1:
        logger.warning("日期 %s: 历史交易日不足，跳过 条件11~18", date_int)
        return {}
    prev1 = cal[i_today - 1]

    # ---- 面板 ----
    close = _load_panel("CLOSE_PRICE")
    close2 = _load_panel("CLOSE_PRICE_2")
    high2 = _load_panel("HIGHEST_PRICE_2")
    low2 = _load_panel("LOWEST_PRICE_2")
    mktcap = _load_panel("MARKET_VALUE")
    negcap = _load_panel("NEG_MARKET_VALUE")
    turnval = _load_panel("TURNOVER_VALUE")
    turnrate = _load_panel("TURNOVER_RATE")
    lu = _load_panel("LIMIT_UP_PRICE")
    ld = _load_panel("LIMIT_DOWN_PRICE")

    today_lu = lu.loc[date_obj] if date_obj in lu.index else pd.Series(dtype=float)
    today_close = close.loc[date_obj] if date_obj in close.index else pd.Series(dtype=float)

    # ---- 截面口径全集（用于条件 14/15/16/17 计算分位数）----
    market_codes = set(close.loc[prev1].dropna().index.astype(str))
    if CROSS_SECTION_UNIVERSE == "index":
        idx_by_date = bu.load_index_codes()
        idx_pure = {_stockid_to_pure(sid) for sid in idx_by_date.get(date_obj, set())}
        if idx_pure:
            market_codes &= idx_pure
    market_codes = sorted(market_codes)

    # ======= 条件14：昨日成交额 / 前5日均值，低于截面95%分位数 =======
    prev_days_amt = cal[i_today - 1 - C14_AMT_LOOKBACK:i_today - 1]  # D-6..D-2（5 天）
    amt_prev1 = turnval.loc[prev1].reindex(market_codes)
    amt_mean5 = turnval.loc[prev_days_amt].reindex(columns=market_codes).mean(axis=0)
    amt_ratio_all = amt_prev1 / amt_mean5.replace(0, np.nan)
    c14_thresh = amt_ratio_all.quantile(C14_QUANTILE)

    # ======= 条件15：昨日市值 小于截面96%分位数 =======
    mktcap_prev1_all = mktcap.loc[prev1].reindex(market_codes)
    c15_thresh = mktcap_prev1_all.quantile(C15_QUANTILE)

    # ======= 条件16：20日涨幅 处于截面99%分位数以下 =======
    d_20 = cal[i_today - 1 - C16_WINDOW]  # D-21
    ret20_all = close2.loc[prev1].reindex(market_codes) / close2.loc[d_20].reindex(market_codes) - 1.0
    c16_thresh = ret20_all.quantile(C16_QUANTILE)

    # ======= 条件17：昨日 1min_pct & 1min_turnoverratio 最大值 < 截面99.2%分位数 =======
    max_pct_all, max_tr_all = _compute_1min_max(prev1, market_codes, negcap, close)
    c17_pct_thresh = max_pct_all.quantile(C17_QUANTILE)
    c17_tr_thresh = max_tr_all.quantile(C17_QUANTILE)

    # ---- 条件11/13 需要的历史窗口 ----
    win_c11 = cal[i_today - C11_WINDOW:i_today]      # D-WINDOW..D-1
    down_days = cal[i_today - C13_DOWN_DAYS:i_today]  # D-4..D-1

    out: dict[str, dict] = {}

    for code in candidate_codes:
        if code not in close2.columns:
            continue

        lu_today = today_lu.get(code, np.nan)
        mc_prev1 = mktcap_prev1_all.get(code, np.nan)

        # ===== 条件11：窗口内 冲高>RALLY 后回调>PULLBACK 则不通过 =====
        # c_win = close2[code].reindex(win_c11).astype(float).to_numpy()
        # if np.isnan(c_win).all() or pd.isna(c_win[-1]):
        #     pass11 = False
        # else:
        #     pass11 = not _has_rally_then_pullback(c_win, C11_RALLY, C11_PULLBACK)

        # ===== 条件12：今日涨停价>=下限 且 昨日市值>=下限 =====
        pass12 = (pd.notna(lu_today) and lu_today >= C12_MIN_LIMIT_UP and
                  pd.notna(mc_prev1) and mc_prev1 >= C12_MIN_MKTCAP)

        # ===== 条件13：过去 N 天曾经跌停 则不通过 =====
        c_dn = close[code].reindex(down_days).astype(float)
        ld_dn = ld[code].reindex(down_days).astype(float)
        pass13 = not bool(((c_dn <= ld_dn + PRICE_EPS) & c_dn.notna() & ld_dn.notna()).any())

        # # ===== 条件14：昨日成交额/前5日均值 < 截面95%分位 =====
        # ar = amt_ratio_all.get(code, np.nan)
        # pass14 = bool(pd.notna(ar) and ar < c14_thresh)

        # # ===== 条件15：昨日市值 < 截面96%分位 =====
        # pass15 = bool(pd.notna(mc_prev1) and mc_prev1 < c15_thresh)

        # # ===== 条件16：20日涨幅 < 截面99%分位 =====
        # r20 = ret20_all.get(code, np.nan)
        # pass16 = bool(pd.notna(r20) and r20 < c16_thresh)

        # # ===== 条件17：昨日 1min_pct & 1min_turnoverratio 最大值 均 < 截面99.2%分位 =====
        # mp = max_pct_all.get(code, np.nan)
        # mt = max_tr_all.get(code, np.nan)
        # pass17 = bool(pd.notna(mp) and pd.notna(mt) and mp < c17_pct_thresh and mt < c17_tr_thresh)

        # # ===== 条件18：今日筹码分布 获利盘<=50% 且 concentration_90<=0.6 =====
        # px_today = today_close.get(code, np.nan)
        # if pd.isna(px_today):
        #     profit, conc90 = None, None
        # else:
        #     profit, conc90 = _compute_chip(code, cal, i_today, close2, high2, low2, turnrate, float(px_today))
        # if profit is None or conc90 is None:
        #     pass18 = False
        # else:
        #     pass18 = bool(profit <= C18_PROFIT_MAX and conc90 <= C18_CONC90_MAX)

        out[code] = {
             "pass12": bool(pass12), "pass13": bool(pass13),#"pass11": bool(pass11),
            # "pass14": bool(pass14), "pass15": bool(pass15), "pass16": bool(pass16),
            # "pass17": bool(pass17), "pass18": bool(pass18),
            # "mktcap_prev1": float(mc_prev1) if pd.notna(mc_prev1) else float("nan"),
            # "amt_ratio": float(ar) if pd.notna(ar) else float("nan"),
            # "ret20": float(r20) if pd.notna(r20) else float("nan"),
            # "max_1min_pct": float(mp) if pd.notna(mp) else float("nan"),
            # "max_1min_turnover": float(mt) if pd.notna(mt) else float("nan"),
            # "profit_ratio": float(profit) if profit is not None else float("nan"),
            # "concentration_90": float(conc90) if conc90 is not None else float("nan"),
        }
    return out


def _has_rally_then_pullback(c: np.ndarray, rally: float, pullback: float) -> bool:
    """序列 c 中是否存在某高点 i：从 i 之前最低点冲高>rally，且 i 之后回落>pullback。"""
    n = len(c)
    if n < 3:
        return False
    # 前缀最小（含 i）
    prefix_min = np.full(n, np.nan)
    cur = np.inf
    for k in range(n):
        if not np.isnan(c[k]):
            cur = min(cur, c[k])
        prefix_min[k] = cur
    # 后缀最小（i 之后）
    suffix_min = np.full(n, np.nan)
    cur = np.inf
    for k in range(n - 1, -1, -1):
        suffix_min[k] = cur
        if not np.isnan(c[k]):
            cur = min(cur, c[k])
    for i in range(1, n - 1):
        ci = c[i]
        if np.isnan(ci) or ci <= 0:
            continue
        pm = prefix_min[i - 1] if i >= 1 else np.nan
        sm = suffix_min[i]
        if np.isnan(pm) or pm <= 0 or np.isinf(pm):
            continue
        if np.isinf(sm):
            continue
        if (ci / pm - 1.0) > rally and (sm / ci - 1.0) < -pullback:
            return True
    return False


def _compute_1min_max(date_obj: datetime.date, market_codes: list[str],
                      negcap: pd.DataFrame, close: pd.DataFrame) -> tuple[pd.Series, pd.Series]:
    """计算某日全市场每只股票的 1min_pct 最大值 与 1min_turnoverratio 最大值。

    1min_pct          = 分钟 price 的环比涨跌幅，取当日最大值
    1min_turnoverratio= 分钟 vol / 流通股本，取当日最大值
                        流通股本 = NEG_MARKET_VALUE / CLOSE （该日）
    返回两个 Series（index=纯代码）。
    """
    df = _read_raw_min(date_obj)
    if df.empty:
        return pd.Series(dtype=float), pd.Series(dtype=float)
    df = df[(df["time"] >= TIME_LO) & (df["time"] <= TIME_HI)].copy()
    df["code"] = df["StockID"].astype(str).str[2:]
    df = df.sort_values(["code", "time"])
    # 1min_pct
    grp = df.groupby("code", sort=False)
    df["pct"] = grp["price"].pct_change()
    max_pct = df.groupby("code")["pct"].max()
    # 1min_turnoverratio：最大分钟 vol / 流通股本
    max_vol = df.groupby("code")["vol"].max()
    neg = negcap.loc[date_obj] if date_obj in negcap.index else pd.Series(dtype=float)
    cl = close.loc[date_obj] if date_obj in close.index else pd.Series(dtype=float)
    ff_shares = (neg / cl).reindex(max_vol.index)
    max_tr = max_vol / ff_shares.replace(0, np.nan)
    return max_pct.reindex(market_codes), max_tr.reindex(market_codes)


def _compute_chip(code: str, cal: list, i_today: int,
                  close2: pd.DataFrame, high2: pd.DataFrame, low2: pd.DataFrame,
                  turnrate: pd.DataFrame, px_today: float) -> tuple[float | None, float | None]:
    """三角/均匀衰减筹码分布。返回 (获利盘比例, concentration_90)。

    - 用 D-CHIP_DAYS .. D-1 的复权 high/low/换手率 累积筹码（按换手率衰减）。
    - 获利盘 = 成本 <= 今日收盘价 的筹码占比。
    - concentration_90 = (P95 - P5) / (P95 + P5)，P5/P95 为筹码成本的 5%/95% 分位价。
    """
    days = cal[i_today - C18_CHIP_DAYS:i_today]
    h = high2[code].reindex(days).astype(float).to_numpy()
    l = low2[code].reindex(days).astype(float).to_numpy()
    tr = turnrate[code].reindex(days).astype(float).to_numpy()
    # 换手率单位：TURNOVER_RATE 为百分比(%)；转成比例
    tr = tr / 100.0
    valid = ~(np.isnan(h) | np.isnan(l) | np.isnan(tr))
    if valid.sum() < 20:
        return None, None
    h = h[valid]; l = l[valid]; tr = tr[valid]
    pmin = float(np.nanmin(l)); pmax = float(np.nanmax(h))
    if not (pmax > pmin > 0):
        return None, None
    grid = np.linspace(pmin, pmax, C18_GRID)
    chips = np.zeros(C18_GRID)
    width = (pmax - pmin) / (C18_GRID - 1)
    for k in range(len(h)):
        lo_k, hi_k, t_k = l[k], h[k], tr[k]
        if np.isnan(t_k) or t_k <= 0:
            continue
        t_k = min(t_k, 1.0)
        # 当日筹码均匀分布在 [lo_k, hi_k]
        mask = (grid >= lo_k - width) & (grid <= hi_k + width)
        m = mask.sum()
        if m == 0:
            idx = int(np.clip(round((((lo_k + hi_k) / 2) - pmin) / width), 0, C18_GRID - 1))
            chips *= (1 - t_k)
            chips[idx] += t_k
            continue
        chips *= (1 - t_k)
        chips[mask] += t_k / m
    total = chips.sum()
    if total <= 0:
        return None, None
    chips /= total
    # 获利盘
    profit = float(chips[grid <= px_today].sum())
    # concentration_90
    cum = np.cumsum(chips)
    p5 = float(np.interp(0.05, cum, grid))
    p95 = float(np.interp(0.95, cum, grid))
    conc90 = (p95 - p5) / (p95 + p5) if (p95 + p5) > 0 else np.nan
    return profit, float(conc90)


# ===================================================================
# 主流程
# ===================================================================
def process_one_date(date_int: str) -> int:
    date_obj = datetime.datetime.strptime(date_int, "%Y%m%d").date()
    date_str = date_obj.strftime("%Y-%m-%d")

    dl = DataLoader()

    prev1_obj = _get_prev1_trading_day(date_obj)
    if prev1_obj is None:
        logger.info("日期 %s: 找不到昨天交易日（D-1）", date_int)
        _save_empty(date_int)
        return 0
    prev1_int = prev1_obj.strftime("%Y%m%d")
    prev1_str = prev1_obj.strftime("%Y-%m-%d")

    daily_D1 = dl.read_daily(prev1_int, fields=["LIMIT_UP_PRICE", "CLOSE_PRICE"])
    lu_D1 = daily_D1["LIMIT_UP_PRICE"]
    cp_D1 = daily_D1["CLOSE_PRICE"]

    # ===== 条件4：昨天（D-1）收盘 == 涨停（日频，向量化）=====
    valid4 = (lu_D1 > 0) & lu_D1.notna() & cp_D1.notna()
    cond4_mask = valid4 & ((lu_D1 - cp_D1).abs() <= PRICE_EPS)
    cond4_codes = set(cp_D1.index[cond4_mask].astype(str))
    logger.info("日期 %s: 【条件4】D-1(%s) 收盘=涨停 候选 %d 只", date_int, prev1_int, len(cond4_codes))
    if not cond4_codes:
        _save_empty(date_int)
        return 0

    # 指数成分 + 去 ST
    index_by_date = bu.load_index_codes()
    st_set = bu.load_st_set()
    index_pure = {_stockid_to_pure(sid) for sid in index_by_date.get(date_obj, set())}
    if index_pure:
        cond4_codes &= index_pure
    cond4_codes = {c for c in cond4_codes if (date_obj, c) not in st_set}
    logger.info("日期 %s: 【条件4】叠加指数成分+去ST 后候选 %d 只", date_int, len(cond4_codes))
    if not cond4_codes:
        _save_empty(date_int)
        return 0

    # ===== 条件3：昨天（D-1）中午收盘 == 涨停 =====
    df_min_D1 = _read_raw_min(prev1_obj, stockids={_pure_to_stockid(c) for c in cond4_codes})
    if df_min_D1.empty:
        logger.info("日期 %s: D-1(%s) min_data 为空/缺失", date_int, prev1_int)
        _save_empty(date_int)
        return 0
    midday_D1 = df_min_D1[df_min_D1["time"] == MIDDAY_BAR][["StockID", "price"]].copy()
    midday_D1["code"] = midday_D1["StockID"].map(_stockid_to_pure)
    midday_close_map = dict(zip(midday_D1["code"], midday_D1["price"].astype(float)))

    cond3_codes = set()
    for code in cond4_codes:
        mc = midday_close_map.get(code)
        if mc is None:
            continue
        lu1 = lu_D1.get(code, np.nan)
        if pd.notna(lu1) and abs(mc - float(lu1)) <= PRICE_EPS:
            cond3_codes.add(code)
    logger.info("日期 %s: 【条件3】D-1 中午收盘=涨停 候选 %d 只", date_int, len(cond3_codes))
    if not cond3_codes:
        _save_empty(date_int)
        return 0

    # ===== 条件5~10：今日 K 线技术过滤（base56）=====
    tech = compute_tech_features(date_obj, cond3_codes)
    pass_5_10 = {
        code for code, f in tech.items()
        if f["pass5"] and f["pass6"]  # and f["pass7"] and f["pass8"] and f["pass9"] and f["pass10"]
    }
    logger.info("日期 %s: 【条件5-10】今日K线技术过滤后候选 %d 只", date_int, len(pass_5_10))
    if not pass_5_10:
        _save_empty(date_int)
        return 0

    # ===== 条件11~18：checkafter5 续编条件 =====
    add5 = compute_conditions_11_18(date_obj, pass_5_10)
    pass_codes = {
        code for code, f in add5.items()
        if f["pass12"] and f["pass13"] # and f["pass12"] 
        # and f["pass14"] and f["pass15"] and f["pass16"] and f["pass17"] and f["pass18"]
    }
    logger.info("日期 %s: 【条件11-18】过滤后候选 %d 只", date_int, len(pass_codes))
    if not pass_codes:
        _save_empty(date_int)
        return 0

    # ---- 第二天 open（回测备用）----
    try:
        next_open_series = _next_trading_open(date_obj)
    except Exception as exc:
        logger.warning("读取 next_open 失败: %s", exc)
        next_open_series = None

    records = []
    for code in sorted(pass_codes):
        tf = tech[code]
        af = add5[code]
        if next_open_series is not None and code in next_open_series.index:
            no_val = next_open_series[code]
            next_open = float(no_val) if pd.notna(no_val) else float("nan")
        else:
            next_open = float("nan")
        records.append({
            "date": date_str, "code": code,
            "limit_up_price": tf["limit_up_price"], "next_open": next_open,
            "prev1_date": prev1_str,
            "prev1_midday_close": float(midday_close_map.get(code, np.nan)),
            "prev1_end_close": float(cp_D1.get(code, np.nan)),
            "prev1_limit_up": float(lu_D1.get(code, np.nan)),
            # base56 佐证
            "open": tf["open"], "pre_close": tf["pre_close"], "close": tf["close"],
            "atr_pct": tf["atr_pct"], "atr_ref": tf["atr_ref"], "today_tr": tf["today_tr"],
            "ma5": tf["ma5"], "ma20": tf["ma20"], "ma60": tf["ma60"],
            "dif": tf["dif"], "macd_hist": tf["macd_hist"],
            # after5 佐证
            "mktcap_prev1": af["mktcap_prev1"], "amt_ratio": af["amt_ratio"],
            "ret20": af["ret20"], "max_1min_pct": af["max_1min_pct"],
            "max_1min_turnover": af["max_1min_turnover"],
            "profit_ratio": af["profit_ratio"], "concentration_90": af["concentration_90"],
        })

    os.makedirs(SEGMENTS_DAILY_DIR, exist_ok=True)
    out_path = os.path.join(SEGMENTS_DAILY_DIR, f"{date_int}.parquet")
    if records:
        df_out = pd.DataFrame(records)
        df_out.to_parquet(out_path, index=False)
        logger.info("日期 %s: 满足条件3~18 记录 %d 条（%d 只股票）-> %s",
                    date_int, len(df_out), df_out["code"].nunique(), out_path)
        return len(df_out)
    _save_empty(date_int)
    logger.info("日期 %s: 无满足条件3~18的记录", date_int)
    return 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, default="20250106", help="交易日 D，格式 YYYYMMDD")
    args = parser.parse_args()

    t0 = _time.time()
    n = process_one_date(args.date)
    logger.info("日期 %s 完成: %d 条记录, 耗时 %.1fs", args.date, n, _time.time() - t0)


if __name__ == "__main__":
    main()
