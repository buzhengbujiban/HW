"""
create_signal_pool.py —— 基于 checkafter_limitup_only 选股池 + 高频因子信号筛选。

只需要操控 SIGNAL_DEFS 列表即可选择启用哪些信号条件：
  - 注释/删除某行 = 不启用该信号
  - 取消注释 = 启用该信号
所有启用的信号条件取 AND（同时满足才入池）。

输出目录会自动根据启用的信号生成子目录名，例如：
  启用 sig1 + sig3          -> signal_pool_sig1_sig3/
  启用全部 sig1~sig4        -> signal_pool_sig1_sig2_sig3_sig4/
  只启用 sig2               -> signal_pool_sig2/

四个可选信号条件（_l2 = 因子原始值）：
  sig1: trdact_BSimb_diff       > 80     超过 2 次   (factor1)
  sig2: pctcxltrd_BSimb         > 0.004  超过 2 次   (factor3)
  sig3: add_size_1_2_prob1_BSimb < -0.75  超过 2 次   (factor5)
  sig4: size_cxl1all_prob_BSimb > 0.75   超过 2 次   (factor2)

用法：
  python create_signal_pool.py --date 20240430
  python create_signal_pool.py --all
"""

from __future__ import annotations

import os
import sys
import glob
import logging
import argparse
import time as _time

import numpy as np
import pandas as pd
from joblib import Parallel, delayed

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ========== 路径 ==========
HFT_ROOT = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only_hft"
FACTOR_ROOT = os.path.join(HFT_ROOT, "factors")
POOL_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only/segments_daily"

OUTPUT_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_signal"

# ==========================================================================
# 信号条件配置 —— 只需操控这里即可选择启用哪些信号
# 格式: (信号名, 因子目录名, 因子列名, 方向('>','<'), 阈值, 最少触发次数)
# 注释掉 = 不启用，取消注释 = 启用；所有启用的信号取 AND。
# ==========================================================================
SIGNAL_DEFS = [
    # ("sig1", "factor1", "trdact_BSimb_diff",        "<",  -80.0,    1),
    # ("sig2", "factor3", "pctcxltrd_BSimb",          "<",  -0.005,   1),
    # ("sig3", "factor5", "add_size_1_2_prob1_BSimb", ">", 0.95,   3),
    ("sig4", "factor2", "size_cxl1all_prob_BSimb",  "<",  -0.96,    2),
]

# ---- 根据启用的信号自动生成输出子目录名 ----
_ACTIVE_SIG_NAMES = [s[0] for s in SIGNAL_DEFS]
_POOL_SUBDIR = "signal_pool_" + "_".join(_ACTIVE_SIG_NAMES) if _ACTIVE_SIG_NAMES else "signal_pool_none"
SIGNAL_POOL_DIR = os.path.join(OUTPUT_DIR, _POOL_SUBDIR)


def _read_factor(date: str, factor_dir: str, col: str) -> pd.DataFrame:
    """读取单个因子文件，只保留 (date, code, time, seq_num, col)。"""
    path = os.path.join(FACTOR_ROOT, factor_dir, f"{factor_dir}_{date}.parquet")
    if not os.path.exists(path):
        return pd.DataFrame()
    need = ["date", "code", "time", "seq_num", col]
    df = pd.read_parquet(path, columns=need)
    return df


def _read_lob_mid(date: str) -> pd.DataFrame:
    """读取沪深 LOB，提取 (code_str, time, seq_num, mid)。"""
    frames = []
    for market, suffix in [("sh", ".SH"), ("sz", ".SZ")]:
        path = os.path.join(HFT_ROOT, f"lob_{market}", f"{date}_lob.parquet")
        if not os.path.exists(path):
            continue
        df = pd.read_parquet(path, columns=["code", "time", "seq_num", "bp1", "sp1"])
        df["code"] = df["code"].astype("int64").astype(str).str.zfill(6) + suffix
        df["bp1_f"] = df["bp1"].astype("float64")
        df["sp1_f"] = df["sp1"].astype("float64")
        df["bp1_f"] = df["bp1_f"].where(df["bp1_f"] > 0, np.nan)
        df["sp1_f"] = df["sp1_f"].where(df["sp1_f"] > 0, np.nan)
        df["mid"] = (df["bp1_f"] + df["sp1_f"]) / 2.0
        df["mid"] = df["mid"].where(df["mid"].notna(), df["bp1_f"])
        df["mid"] = df["mid"].where(df["mid"].notna(), df["sp1_f"])
        frames.append(df[["code", "time", "seq_num", "mid"]])
    if not frames:
        return pd.DataFrame()
    return pd.concat(frames, ignore_index=True)


def _load_pool_codes(date: str) -> set[str]:
    """加载原始选股池当日股票代码（返回 '000048.SZ' 格式的 set）。"""
    path = os.path.join(POOL_DIR, f"{date}.parquet")
    if not os.path.exists(path):
        return set()
    df = pd.read_parquet(path, columns=["code"])
    if df.empty:
        return set()
    codes_raw = df["code"].astype(str).str.zfill(6).unique()
    result = set()
    for c in codes_raw:
        suffix = ".SH" if c[0] in ("5", "6", "9") else ".SZ"
        result.add(c + suffix)
    return result


def _output_cols() -> list[str]:
    """根据启用的信号动态生成输出列名。"""
    cols = ["date", "code", "signal_price", "signal_time"]
    for sig_name, *_ in SIGNAL_DEFS:
        cols.append(f"{sig_name}_cnt")
    return cols


def process_one_date(date: str) -> int:
    t0 = _time.time()

    if not SIGNAL_DEFS:
        logger.warning("SIGNAL_DEFS 为空，无启用的信号条件")
        _save_empty(date)
        return 0

    # 限定 universe
    pool_codes = _load_pool_codes(date)
    if not pool_codes:
        logger.info("%s: 原始选股池为空，跳过", date)
        _save_empty(date)
        return 0

    # 读取启用的因子
    factor_dfs = {}
    for sig_name, fdir, fcol, _, _, _ in SIGNAL_DEFS:
        df = _read_factor(date, fdir, fcol)
        if df.empty:
            logger.info("%s: %s (%s) 因子文件缺失，跳过", date, sig_name, fdir)
            _save_empty(date)
            return 0
        df = df[df["code"].isin(pool_codes)]
        factor_dfs[fcol] = df[["code", "time", "seq_num", fcol]]

    # 读 LOB 获取 mid price
    lob_mid = _read_lob_mid(date)
    if lob_mid.empty:
        logger.info("%s: LOB 数据缺失，跳过", date)
        _save_empty(date)
        return 0
    lob_mid = lob_mid[lob_mid["code"].isin(pool_codes)]

    # 合并所有因子到同一张表 (code, time, seq_num) outer merge
    merged = None
    for fcol, fdf in factor_dfs.items():
        if merged is None:
            merged = fdf
        else:
            merged = merged.merge(fdf, on=["code", "time", "seq_num"], how="outer")

    # merge mid price
    merged = merged.merge(lob_mid, on=["code", "time", "seq_num"], how="left")
    merged = merged.sort_values(["code", "time", "seq_num"]).reset_index(drop=True)
    merged["mid"] = merged.groupby("code")["mid"].ffill()

    # 逐票扫描
    records = []
    n_sigs = len(SIGNAL_DEFS)

    for code, grp in merged.groupby("code", sort=False):
        grp = grp.sort_values(["time", "seq_num"]).reset_index(drop=True)
        n = len(grp)

        # 对每个启用的信号条件计算 cumulative hit count
        cum_hits_int = []
        for i, (sig_name, fdir, fcol, direction, threshold, min_cnt) in enumerate(SIGNAL_DEFS):
            vals = grp[fcol].to_numpy(dtype="float64")
            if direction == ">":
                hit = vals > threshold
            else:
                hit = vals < threshold
            hit[np.isnan(vals)] = False
            cum_hits_int.append(np.cumsum(hit.astype(int)))

        # 最早所有启用条件都 >= min_cnt 的 tick
        all_pass = np.ones(n, dtype=bool)
        for i, (sig_name, fdir, fcol, direction, threshold, min_cnt) in enumerate(SIGNAL_DEFS):
            all_pass &= (cum_hits_int[i] >= min_cnt)

        if not all_pass.any():
            continue

        first_pass_idx = int(np.argmax(all_pass))
        signal_time = int(grp.iloc[first_pass_idx]["time"])
        signal_mid = grp.iloc[first_pass_idx]["mid"]
        if pd.isna(signal_mid) or signal_mid <= 0:
            for j in range(first_pass_idx, n):
                m = grp.iloc[j]["mid"]
                if pd.notna(m) and m > 0:
                    signal_mid = m
                    signal_time = int(grp.iloc[j]["time"])
                    break

        pure_code = code.split(".")[0]
        rec = {
            "date": date,
            "code": pure_code,
            "signal_price": float(signal_mid) if pd.notna(signal_mid) else np.nan,
            "signal_time": signal_time,
        }
        # 动态添加每个启用信号的 count
        for i, (sig_name, *_rest) in enumerate(SIGNAL_DEFS):
            rec[f"{sig_name}_cnt"] = int(cum_hits_int[i][-1])
        records.append(rec)

    os.makedirs(SIGNAL_POOL_DIR, exist_ok=True)
    out_path = os.path.join(SIGNAL_POOL_DIR, f"{date}.parquet")
    if records:
        df_out = pd.DataFrame(records)
        df_out.to_parquet(out_path, index=False)
        logger.info("%s: 信号池 %d 只 (启用: %s) -> %s (%.1fs)",
                    date, len(df_out), "+".join(_ACTIVE_SIG_NAMES),
                    out_path, _time.time() - t0)
        return len(df_out)
    else:
        _save_empty(date)
        logger.info("%s: 无满足信号条件的票 (%.1fs)", date, _time.time() - t0)
        return 0


def _save_empty(date: str):
    os.makedirs(SIGNAL_POOL_DIR, exist_ok=True)
    out_path = os.path.join(SIGNAL_POOL_DIR, f"{date}.parquet")
    pd.DataFrame(columns=_output_cols()).to_parquet(out_path, index=False)


# 默认并行进程数
DEFAULT_N_JOBS = 40


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", type=str, default=None, help="交易日 YYYYMMDD")
    parser.add_argument("--all", action="store_true", help="处理全部可用日期（并行）")
    parser.add_argument("--n-jobs", type=int, default=DEFAULT_N_JOBS,
                        help=f"--all 模式下的并行进程数（默认 {DEFAULT_N_JOBS}）")
    args = parser.parse_args()

    logger.info("启用的信号条件: %s", _ACTIVE_SIG_NAMES)
    logger.info("输出目录: %s", SIGNAL_POOL_DIR)

    if args.all:
        # 以第一个启用信号的因子文件存在的日期为准
        first_fdir = SIGNAL_DEFS[0][1]
        pattern = os.path.join(FACTOR_ROOT, first_fdir, f"{first_fdir}_*.parquet")
        files = sorted(glob.glob(pattern))
        dates = [os.path.basename(f).replace(f"{first_fdir}_", "").replace(".parquet", "") for f in files]
        n_jobs = min(args.n_jobs, len(dates))
        logger.info("共 %d 个交易日待处理，并行进程数 %d", len(dates), n_jobs)
        results = Parallel(n_jobs=n_jobs, backend="loky")(
            delayed(process_one_date)(d) for d in dates
        )
        total = sum(results)
        logger.info("全部完成，总计 %d 条信号记录", total)
    elif args.date:
        process_one_date(args.date)
    else:
        parser.error("请提供 --date 或 --all")


if __name__ == "__main__":
    main()
