"""
backtest_limitup_only_signal0.py —— 信号池回测（收盘/开盘买入方案）

选股池：{SIGNAL_POOL_DIR}/{date}.parquet（create_signal_pool.py 输出）

回测逻辑（两种买入方案）：
- 买入方案 A（buyD_close）：
    在 date 当天以【收盘价】等权买入选出的所有股票。
    卖出：第 2/3/5 天以开盘价卖出；第 2/3/5 天以收盘价卖出。
- 买入方案 B（buyD1_open）：
    在 date 的下一个交易日以【开盘价】等权买入。
    卖出：第 2/3/5 天以开盘价卖出；第 2/3/5 天以收盘价卖出。
- "第N天"以买入日为第1天。
- 价格使用原始未复权 OPEN_PRICE / CLOSE_PRICE。

输出：各 label 的收益曲线图 + 汇总。

用法：
  python backtest_limitup_only_signal0.py
"""

import os
import glob
import logging

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger(__name__)

# ============================================================
# 路径配置
# ============================================================
POOLS = "sig4"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SIGNAL_POOL_DIR = f"/home/datamake119/data1/user118/newhigh/checkafter_limitup_signal/signal_pool_{POOLS}"
# SIGNAL_POOL_DIR = "/home/datamake119/data1/user118/newhigh/checkafter_limitup_only/segments_daily"
OHLC_PATH = "/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea"
OPEN_PKL = os.path.join(OHLC_PATH, "OPEN_PRICE.pkl")
CLOSE_PKL = os.path.join(OHLC_PATH, "CLOSE_PRICE.pkl")

SELL_DAYS = [1, 2, 3]


def load_prices():
    open_price = pd.read_pickle(OPEN_PKL)
    close_price = pd.read_pickle(CLOSE_PKL)
    open_price.index = pd.to_datetime(open_price.index).strftime("%Y%m%d")
    close_price.index = pd.to_datetime(close_price.index).strftime("%Y%m%d")
    open_price.sort_index(inplace=True)
    close_price.sort_index(inplace=True)
    return open_price, close_price


def load_pool():
    files = sorted(glob.glob(os.path.join(SIGNAL_POOL_DIR, "*.parquet")))
    frames = []
    for f in files:
        df = pd.read_parquet(f)
        if not df.empty:
            frames.append(df)
    if not frames:
        raise RuntimeError(f"{SIGNAL_POOL_DIR} 下没有可用的信号池数据")
    pool = pd.concat(frames, ignore_index=True)
    pool["date"] = pool["date"].astype(str).str.replace("-", "")
    pool["code"] = pool["code"].astype(str).str.zfill(6)
    return pool


def equal_weight_return(codes, buy_row, sell_row):
    codes = [c for c in codes if c in buy_row.index and c in sell_row.index]
    if not codes:
        return None, 0
    buy = buy_row[codes]; sell = sell_row[codes]
    valid = buy.notna() & sell.notna() & (buy > 0) & (sell > 0)
    buy = buy[valid]; sell = sell[valid]
    if len(buy) == 0:
        return None, 0
    ret = sell / buy - 1.0
    return float(ret.mean()), int(len(buy))


def backtest_panel(pool, open_price, close_price, buy_offset, buy_type, sell_offset, sell_type):
    trade_dates = open_price.index
    date_pos = {d: i for i, d in enumerate(trade_dates)}
    records = {}
    grouped = pool.groupby("date")["code"].apply(list)
    for date, codes in grouped.items():
        if date not in date_pos:
            continue
        buy_idx = date_pos[date] + buy_offset
        if buy_idx >= len(trade_dates):
            continue
        buy_date = trade_dates[buy_idx]
        sell_idx = buy_idx + sell_offset
        if sell_idx >= len(trade_dates):
            continue
        sell_date = trade_dates[sell_idx]
        buy_row = open_price.loc[buy_date] if buy_type == "open" else close_price.loc[buy_date]
        sell_row = open_price.loc[sell_date] if sell_type == "open" else close_price.loc[sell_date]
        ret, n = equal_weight_return(codes, buy_row, sell_row)
        if ret is None:
            continue
        records[date] = {"ret": ret, "n": n, "buy_date": buy_date, "sell_date": sell_date}
    return pd.DataFrame.from_dict(records, orient="index").sort_index()


def plot_and_summary(labels, scheme_name, out_img):
    fig, (ax_a, ax_b) = plt.subplots(2, 1, figsize=(14, 11))
    for name, df in labels.items():
        if df.empty:
            continue
        x = pd.to_datetime(df.index, format="%Y%m%d")
        nav = (1 + df["ret"]).cumprod()
        ax_a.plot(x, nav.values, label=f"{name} (nav={nav.iloc[-1]:.3f})")
        cum_sum = df["ret"].cumsum()
        ax_b.plot(x, cum_sum.values * 100, label=f"{name} (sum={cum_sum.iloc[-1]*100:.1f}%)")

    ax_a.set_title(f"signal_pool [{scheme_name}] NAV (compounded, equal-weight)")
    ax_a.set_xlabel("date"); ax_a.set_ylabel("cumulative NAV")
    ax_a.legend(); ax_a.grid(True, alpha=0.3)
    ax_b.set_title(f"signal_pool [{scheme_name}] cumulative sum (no compounding)")
    ax_b.set_xlabel("date"); ax_b.set_ylabel("cumulative return (%)")
    ax_b.legend(); ax_b.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_img, dpi=120)
    plt.close(fig)
    logger.info("[%s] 图片已保存：%s", scheme_name, out_img)

    print(f"\n===== [{scheme_name}] 各 label 汇总 =====")
    for name, df in labels.items():
        if df.empty:
            continue
        nav = (1 + df["ret"]).cumprod()
        cum_sum = df["ret"].cumsum()
        print(f"{name}: 交易日数={len(df)}, 平均收益={df['ret'].mean()*100:.3f}%, "
              f"胜率={(df['ret']>0).mean()*100:.1f}%, "
              f"累乘净值={nav.iloc[-1]:.3f}, 累计求和={cum_sum.iloc[-1]*100:.1f}%")


def main():
    logger.info("读取价格数据...")
    open_price, close_price = load_prices()

    logger.info("读取信号池...")
    pool = load_pool()
    logger.info("信号池：%d 行, %d 个交易日, 区间 %s ~ %s",
                len(pool), pool["date"].nunique(), pool["date"].min(), pool["date"].max())

    # ===== 方案 A：date 当天收盘价买入 =====
    labels_a = {}
    for sell_type in ("open", "close"):
        for day in SELL_DAYS:
            sell_offset = day - 1  # 买入日=date 为第1天
            name = f"{sell_type}_day{day}"
            labels_a[name] = backtest_panel(
                pool, open_price, close_price,
                buy_offset=0, buy_type="close",
                sell_offset=sell_offset, sell_type=sell_type)
            logger.info("[buyD_close] label %s: %d 个有效交易日", name, len(labels_a[name]))
    plot_and_summary(labels_a, "buyD_close",
                     os.path.join(BASE_DIR, f"bt_limituponly_buyD_close_{POOLS}.png"))

    # ===== 方案 B：date 下一交易日开盘价买入 =====
    labels_b = {}
    for sell_type in ("open", "close"):
        for day in SELL_DAYS:
            sell_offset = day - 1  # 买入日(D+1) 为第1天
            name = f"{sell_type}_day{day}"
            labels_b[name] = backtest_panel(
                pool, open_price, close_price,
                buy_offset=1, buy_type="open",
                sell_offset=sell_offset, sell_type=sell_type)
            logger.info("[buyD1_open] label %s: %d 个有效交易日", name, len(labels_b[name]))
    plot_and_summary(labels_b, "buyD1_open",
                     os.path.join(BASE_DIR, f"bt_limituponly_buyD1_open_{POOLS}.png"))


if __name__ == "__main__":
    main()
