
build_up_7 （日内曾涨到7% 的 zz300+zz500+zz1000+zz2000 股票池）下的各个数据路径如下：
tick_lob data:
新路径: /mount/datamake118/lob_data/lob_data_sh(sz)

逐笔委托逐笔成交撤单 order/trans/min_data:
新：/home/datamake119/data1/user118/newhigh/limit_7_up/order(trans)(min_data)

daily_data:
新：/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/ohlc_fea

support_data:
新：/mnt/localdisk/sdb/lwyxyz/2.79/tonglian_data/support_data


请你在build_up_7 构造的universe中 读取 1min bar data 标出连续上涨区段 （连续cont(default=3)个及以上1min ret>=0, ） 构造如下条件，找出满足如下条件的(date, code)：
- 条件1：两个连续上涨区段中间1min bar 个数，少于 前一个连续上涨区段的1min bar个数 * scale(default=1)
- 条件2：后一个连续上涨区段的开始价格小于或等于前一个连续上涨区段的最终价格
- 条件3：后一个连续上涨区段的最终价格高于前一个连续上涨区段的最终价格
- 条件4：后一个连续上涨区段的开始价格高于前一个连续上涨区段的开始价格

计算满足上述三个条件的股票的 第一个连续上涨区间开始时间(t_start), 第二个上涨区段涨到超过第一个上涨区段的价格的时候的时间(t_end)，以及两个连续上涨区段的长度(多少个1min bar)，以及两个上涨区段各自的开始/结束价格；后续当天的最高价，第二天的open，形成 parquet df


请你将 原来的/home/datamake119/data1/user118/hft/raw_long_table/sh(sh)_ordertranlob 里面的数据，仅仅只保留 (date, code, t_start~t_end) 分每天一个保存在/home/datamake119/data1/user118/hft/raw_long_table_newhigh/中