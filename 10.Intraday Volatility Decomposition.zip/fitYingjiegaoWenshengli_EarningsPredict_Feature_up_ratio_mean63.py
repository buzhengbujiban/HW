import numpy as np
import operators as op
import pandas as pd
from sklearn.ensemble import GradientBoostingRegressor
import pickle
import time
from xgboost import XGBRegressor

def get_earnings_mask(data):
    tdays = data['load_simvar_hhmm']('trading_days_til_next_ann')
    valid_mask = 1*(tdays == 1) + 2*(op.ts_delay(tdays,1) == 1)
    fs_next_ann_time = data['load_simvar_hhmm']('fs_next_ann_time')
    fs_next_ann_time_delay = op.ts_delay(1.0*fs_next_ann_time, 1)

    # based on trading_days_til_next_ann and fs_next_ann_time
    # delay one day if earnings is announced after we trade
    valid_effect_mask = np.zeros_like(valid_mask, dtype=np.float32)
    for si, di in zip(*np.where((valid_mask >= 1) & (data['valids']))):
        if di + data['delay'] >= data['numdates']:
            continue

        time = fs_next_ann_time[si, di]
        time_delay = fs_next_ann_time_delay[si, di]
        
        if time <= 1500 and (valid_mask[si,di]==1):
            valid_effect_mask[si, di] = 1  
            
        elif time_delay > 1500  and (valid_mask[si,di]==2):
            valid_effect_mask[si, di] = 1                      
            
    bet_days_mask = valid_effect_mask==1
    bet_days_mask = op.at_nan2zero(bet_days_mask*1.0)
    flatten_mask = (bet_days_mask==1.0)

    ret_excess = data['load_simvar_hhmm']('ret1_excess')
    fwd_ret = op.ts_delay((ret_excess),-1)
    
    x_axis = np.where(flatten_mask[:,-1] == True)[0]
    flatten_mask[np.isnan(fwd_ret)] = False
    if len(x_axis)>0:
        flatten_mask[x_axis,-1] = True  
    
    return flatten_mask

def get_basic_df(data, flatten_mask):
    ret1 = data['ret1'].copy()
    ret_excess = data['load_simvar']('ret1_excess')
    fwd_ret = op.ts_delay((ret_excess),-1)
    
    target = fwd_ret[flatten_mask]

    df = pd.DataFrame()
    df['target'] = (target)
    si_list = [list(np.arange(ret1.shape[0]))]*ret1.shape[1]
    si_list = np.array(si_list).transpose()
    di_list = [list(np.arange(ret1.shape[1]))]*ret1.shape[0]
    di_list = np.array(di_list)
    df['si'] = si_list[flatten_mask]
    df['di'] = di_list[flatten_mask]
    dates_mat = np.tile(data['dates'],(np.shape(ret1)[0],1))
    df['dates'] = dates_mat[flatten_mask]

    return df

############################################# FEATURE CHANGES - make your changes in this function #############################################
def get_df_feat(data, flatten_mask):
    load_simvar_hhmm = data['load_simvar_hhmm']
    load_simvar      = data['load_simvar']
    df = pd.DataFrame()

    ####### feature 1: tsz_ret1
    ret1 = load_simvar_hhmm('ret1')
    tsz_ret1 = op.at_nan2zero(op.ts_zscore(ret1, 21))
    df['tsz_ret1'] = tsz_ret1[flatten_mask]

    ####### feature 2: tsz_ret1_delay1
    tsz_ret1_d1 = op.at_nan2zero(op.ts_zscore(op.ts_delay(ret1,1), 21))       
    df['tsz_ret1_d1'] = tsz_ret1_d1[flatten_mask] 

    ####### feature 3: linkup_job_active_count
    linkup_job_active_count = op.at_zero2nan(load_simvar_hhmm('linkup_job_active_count'))
    linkup_job_active_count = op.at_nan2zero(op.ts_zscore(op.ts_fill(linkup_job_active_count), 21))
    df['linkup_job_active_count'] = linkup_job_active_count[flatten_mask]

    #######
    price_std_allday = data['load_simvar_hhmm']('price_std_allday')
    upret_price_std_allday = data['load_simvar_hhmm']('upret_price_std_allday')
    df['upret_price_std_allday_ratio_mean63'] = (((op.ts_mean(upret_price_std_allday / price_std_allday, 63))))[flatten_mask]

    ########## final df #############
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    df = df.fillna(0) #here we fill the missing values with zeros, you may change this if required

    return df


############################################## MODEL CHANGES - make your changes in this function ###############################################
def fit_model(feat_X, Y):
    # XGB as a new benchmark
    model = XGBRegressor(n_estimators=400, learning_rate=0.1, max_depth=1, random_state=42)
    model.fit(feat_X, Y)

    return model
############################################################ END DOING YOUR CHANGES #############################################################



old_settings = np.seterr(divide='ignore')
lookback = 252 * 12

class fit_function:
    def __init__(self):
        self.prod_alpha_postA_length = 10  ## Either 1 or 10

    def fit(self, data, filter_matrix):
        assert (np.all(np.isfinite(filter_matrix)))

        alpha_list = data['alpha_list']
        dates = data['dates']
        delay = data['delay']
        rebalance_dates_mask = data['rebalance_dates_mask']
        fixed_di = np.where(dates>=20131210)[0][0]

        flatten_mask = get_earnings_mask(data)
        basic_df = get_basic_df(data, flatten_mask)
        feat_df = get_df_feat(data, flatten_mask)

        model_dict = {}
        for di, date in enumerate(dates):
            if di <= fixed_di: continue
            if rebalance_dates_mask[di]:
                print(f'⏩⏩ Fitting on: {dates[di]}')
                
                selected_idx_di = np.where(filter_matrix[:, di - delay] == True)[0]
                aid=alpha_list[selected_idx_di][0]

                train_enddate = dates[di]
                if di-lookback<0:
                    train_startdate = dates[0]
                else:    
                    train_startdate = dates[di-lookback]

                basic_df_IS = basic_df[(basic_df['dates']<=train_enddate)&(basic_df['dates']>=train_startdate)]
                feat_df_IS = feat_df[(basic_df['dates']<=train_enddate)&(basic_df['dates']>=train_startdate)]

                feat_X = op.at_nan2zero(feat_df_IS.to_numpy())
                Y = op.at_nan2zero(basic_df_IS['target'].to_numpy())

                model = fit_model(feat_X, Y)

                m_dict = {'alpha': aid, 'model': model}
                model_dict[date] = pickle.dumps(m_dict)

        alpha_attribution_weights = np.copy(filter_matrix)
        
        return model_dict, alpha_attribution_weights

    def construct_preA(self, data, model_dict, mode):
        print(f'contruct_preA mode: {mode}')
        for k in model_dict: 
            model_dict[k] = pickle.loads(model_dict[k])

        numdates = data['numdates']
        numstocks = data['numstocks']
        delay = data['delay']
        dates = data['dates']
        region = data['region']

        flatten_mask = get_earnings_mask(data)
        basic_df = get_basic_df(data, flatten_mask)
        feat_df = get_df_feat(data, flatten_mask)

        if mode == 'last':
            preA_ld = np.zeros(shape=numstocks, dtype=np.float32, order='F')

            date = dates[-1]
            
            basic_df_OS = basic_df[(basic_df['dates']==date)]
            feat_df_OS = feat_df[(basic_df['dates']==date)]
            feat_X = feat_df_OS.to_numpy()
            
            fitted_model_dict = (list(model_dict.values())[0])
            alpha_load = data['load_alpha'](fitted_model_dict['alpha'])
            alpha_load = op.at_nan2zero(alpha_load)

            si_, di_ = basic_df_OS['si'].values, basic_df_OS['di'].values
            if len(si_)==0: return preA_ld

            model = fitted_model_dict['model']
            y_pred = model.predict(feat_X)

            preA_ld[si_] = y_pred
            
            return preA_ld

        if mode == 'full':
            refit_dates = np.array(sorted(model_dict.keys()))
            preA = np.zeros(shape=(numstocks, numdates), dtype=np.float32, order='F')

            for di, date in enumerate(dates):
                if date in model_dict:
                    print('refit day = ', date)
                    
                    refit_idx = np.where(refit_dates == date)[0][0]
                    if refit_idx == refit_dates.size - 1:
                        idx_start, idx_end = di, numdates
                    else:
                        idx_start, idx_end = di, np.where(dates == refit_dates[refit_idx + 1])[0][0]
                    
                    test_enddate = dates[idx_end-1]
                    test_startdate = dates[idx_start]

                    basic_df_OS = basic_df[(basic_df['dates']<=test_enddate)&(basic_df['dates']>=test_startdate)]
                    feat_df_OS = feat_df[(basic_df['dates']<=test_enddate)&(basic_df['dates']>=test_startdate)]
                    feat_X = feat_df_OS.to_numpy()

                    si_, di_ = basic_df_OS['si'].values, basic_df_OS['di'].values

                    model = model_dict[date]['model']
                    y_pred = model.predict(feat_X)

                    alpha_load = data['load_alpha'](model_dict[date]['alpha'])
                    alpha_load = op.at_nan2zero(alpha_load)

                    preA[si_, di_] = y_pred

            return preA
        else:
            raise Exception('Unrecognized mode: %s' % mode)
