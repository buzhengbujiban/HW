import modelstate as ms

  
def add_profitmargin_growth(model:ms.ModelState): 
    # EBITDA yoy
    EBITDAmargin_l1y = model.parse_expr("DIV(EBITDA_lagq4,PosTor_lagq4)")
    model.add_feature(ms.Feature(model, name="_EBITDAmargin_lagq4", calculator=EBITDAmargin_l1y))
    EBITDAmarginyoy = model.parse_expr(f"EGrowth(f_pm-EBITDA, WINSOR(_EBITDAmargin_lagq4,-1,1))")
    model.add_feature(ms.Feature(model, name="f_pmg-EBITDA-y", calculator=EBITDAmarginyoy))

    # NPexeal 
    NPexlmarginyoy = model.parse_expr(f"EGrowth( DIV(np_exeal_lagq0, PosTor_lagq0) , DIV(np_exeal_lagq4, PosTor_lagq4) )")
    model.add_feature(ms.Feature(model, name=f"f_pmg-NPl-y", calculator=NPexlmarginyoy))
    # qoq Irank
    NPexlmarginqoq = model.parse_expr(f"EGrowth( DIV(np_exeal_lagq0, PosTor_lagq0) , DIV(np_exeal_lagq1, PosTor_lagq1) )")
    model.add_feature(ms.Feature(model, name=f"f_pmg-NPl-q", calculator=NPexlmarginqoq))
                

    # NP yoy
    # NPmargin =  model.parse_expr("DIV(np_lagq0, PosTor_lagq0)")
    # model.add_feature(ms.Feature(model, name="NPmargin_lagq0", calculator=NPmargin))
    # NPmargin =  model.parse_expr("DIV(np_lagq4, PosTor_lagq4)")
    # model.add_feature(ms.Feature(model, name="NPmargin_lagq4", calculator=NPmargin))
    NPmarginyoy = model.parse_expr(f"EGrowth(npmargin_lagq0,npmargin_lagq4)")
    model.add_feature(ms.Feature(model, name="f_pmg-NP-y", calculator=NPmarginyoy))

    # GP 
    # qoq
    marginqoq = model.parse_expr("EGrowth( DIV(raw_gp_lagq0, raw_PosTor_lagq0) , DIV(raw_gp_lagq1, raw_PosTor_lagq1) )")
    model.add_feature(ms.Feature(model, name=f"f_pmg-gp-r-q", calculator=marginqoq))
    for q in [0,1]:
        suffix=f'lagq{q}'
        GPmarginraw = model.parse_expr(f"DIV(SUB(raw_tor_{suffix},SUB(raw_toc_{suffix}, FILLNA(raw_toc13_{suffix}, 0))), FILTER(raw_PosTor_{suffix}, GREATER(SUB(raw_toc_{suffix}, FILLNA(raw_toc13_{suffix}, 0)),0)) )")
        model.add_feature(ms.Feature(model, name=f"raw_GPmargin_{suffix}", calculator=GPmarginraw))
    marginqoq = model.parse_expr("EGrowth(raw_GPmargin_lagq0, raw_GPmargin_lagq1 )")
    model.add_feature(ms.Feature(model, name=f"f_pmg-GP-r-q", calculator=marginqoq))
    
    # yoy: Irank
    # GPmargin_l1y = model.parse_expr(f"DIV(SUB(tor_lagq1,SUB(toc_lagq4, AstDevol_lagq4)), FILTER(PosTor_lagq4, GREATER(SUB(toc_lagq4, AstDevol_lagq4),0)) )")
    # model.add_feature(ms.Feature(model, name="_GPmargin_lagq4", calculator=GPmargin_l1y))
    GPmarginyoy = model.parse_expr(f"EGrowth(GPmargin_lagq0, GPmargin_lagq4)")
    model.add_feature(ms.Feature(model, name="f_pmg-GP-y", calculator=GPmarginyoy))
    
def add_sale_growth(model:ms.ModelState):
    # toryoy
    Salesyoy = model.parse_expr(f"EGrowth(tor_lagq0, tor_lagq4)")
    model.add_feature(ms.Feature(model, name=f"f_gs-y", calculator=Salesyoy))
    # tor1qoq
    Salesyoy = model.parse_expr(f"EGrowth(tor1_lagq0, tor1_lagq1)")
    model.add_feature(ms.Feature(model, name=f"f_gs1-q", calculator=Salesyoy))

    #tor1qoq_prc
    PrcAdjSaleChg1Y = model.parse_expr(f"DIV(SUB(DIV(tor1_lagq0, fdmtlshare_lagq0), DIV(tor1_lagq1, fdmtlshare_lagq1)),da_close_locf)")
    model.add_feature(ms.Feature(model, name=f"f_gs1p-q", calculator=PrcAdjSaleChg1Y))

    #raw_tor1yoy_prc
    PrcAdjSaleChg1Y = model.parse_expr(f"DIV(SUB(DIV(raw_tor1_lagq0, fdmtlshare_lagq0), DIV(raw_tor1_lagq4, fdmtlshare_lagq1)),da_close_locf)")
    model.add_feature(ms.Feature(model, name=f"f_gs1p-r-y", calculator=PrcAdjSaleChg1Y))

    #toryoy ch1q
    Sales0yoy_ch1Q = model.parse_expr(f"SUB(EGrowth(tor_lagq0,tor_lagq4), EGrowth(tor_lagq1,tor_lagq5) )")
    model.add_feature(ms.Feature(model, name=f"f_gs-y-q", calculator=Sales0yoy_ch1Q))
            
def add_earning_growth(model:ms.ModelState):
    # tpqoq Irank
    TPqoq = model.parse_expr(f"EGrowth(tp_lagq0, tp_lagq1)")
    model.add_feature(ms.Feature(model, name=f"f_ge-tp-q", calculator=TPqoq))
    
    NPqoq = model.parse_expr(f"EGrowth(np_lagq0, np_lagq1)")
    model.add_feature(ms.Feature(model, name=f"f_ge-np-q", calculator=NPqoq))

    AstAdjtp3Y = model.parse_expr(f"DIV( SUB(tp_lagq0 , tp_lagq12 ), FMEAN('ta',0,12))")
    model.add_feature(ms.Feature(model, name=f"f_ge-tp-at-3y", calculator=AstAdjtp3Y))
                  
def add_asset_growth(model:ms.ModelState):
    # ta growth qoq
    AstGrowth = model.parse_expr(f"EGrowth(ta_lagq0, ta_lagq1)") # 怕季报不播出
    model.add_feature(ms.Feature(model, name=f"f_ga-q", calculator=AstGrowth))

    # f_wcTurnGrowth3y_D_Izscore
    WCTurnoverChg3Y = model.parse_expr(f"EGrowth(DIV(tor_lagq0, FMEAN('wc',0,4)), DIV(tor_lagq12, FMEAN('wc',12,4)))")
    model.add_feature(ms.Feature(model, name=f"f_ga-wctn-3y", calculator=WCTurnoverChg3Y))

    # 'f_INVGrowth3y_D_Izscore'
    INVTurnoverChg3Y = model.parse_expr(f"EGrowth(DIV(tor_lagq0, FMEAN('INV',0,4)), DIV(tor_lagq12, FMEAN('INV',12,4)))")
    model.add_feature(ms.Feature(model, name=f"f_ga-invtn-3y", calculator=INVTurnoverChg3Y))

    # 'f_CAPEXTurnGrowthy'
    CAPEXTurnoverChg1Y = model.parse_expr(f"EGrowth(DIV(tor_lagq0, FMEAN('CAPEX',0,4)), DIV(tor_lagq4, FMEAN('CAPEX',4,4)))")
    model.add_feature(ms.Feature(model, name=f"f_ga-CAPEXtn-y", calculator=CAPEXTurnoverChg1Y))

    # 'f_CAPEXGrowth3y'
    CAPEXGrowth3y = model.parse_expr(f"EGrowth(FMEAN('CAPEX',0,4), FMEAN('CAPEX',12,4))") # 怕季报不播出
    model.add_feature(ms.Feature(model, name=f"f_ga-CAPEX-3y", calculator=CAPEXGrowth3y))
    
    CapexGrowth = model.parse_expr("DIV( CAPEX_lagq0 ,FILTER(CAPEX_lagq4,GREATER(CAPEX_lagq4,0)))")
    model.add_feature(ms.Feature(model, name="f_ga-CAPEX-y", calculator=CapexGrowth))

def add_cashflow_growth(model:ms.ModelState):
    # raw price adjusted FCFcf yoy
    raw_PrcAdjFCFcfy = model.parse_expr(f"DIV(SUB(DIV(raw_FCFcf_lagq0, fdmtlshare_lagq0), DIV(raw_FCFcf_lagq4, fdmtlshare_lagq4)), da_close_locf)")
    model.add_feature(ms.Feature(model, name=f"f_gcfp-FCFcf-r-y", calculator=raw_PrcAdjFCFcfy))

    # price adjusted FCFcf qoq    
    PrcAdjFCFcfq = model.parse_expr(f"DIV(SUB(DIV(FCFcf_lagq0, fdmtlshare_lagq0), DIV(FCFcf_lagq1, fdmtlshare_lagq1)), da_close_locf)")
    model.add_feature(ms.Feature(model, name=f"f_gcfp-FCFcf-q", calculator=PrcAdjFCFcfq))

    # raw Ast adjusted ncf_oa 3y
    AstAdjOCFChg3Y = model.parse_expr(f"DIV( SUB( raw_ncf_oa_lagq0, raw_ncf_oa_lagq12), FMEAN('ta',0,12))")
    model.add_feature(ms.Feature(model, name=f"f_gcfa-OCF-r-3y", calculator=AstAdjOCFChg3Y))

    # CF3y 
    CFyoy = model.parse_expr(f"EGrowth( CF_lagq0, CF_lagq12)")
    model.add_feature(ms.Feature(model, name=f"f_gcf-CF-3y", calculator=CFyoy))
    
    # 'f_AstAdjFCFicy_D_Izscore'
    AstAdjFCFicy = model.parse_expr(f"DIV( SUB( FCFic_lagq0, FCFic_lagq4), FMEAN('ta',0,4))")
    model.add_feature(ms.Feature(model, name=f"f_gcfa-FCFic-y", calculator=AstAdjFCFicy))

    # f_AstAdjncf_fa22y_D_Irank    
    AstAdjncf_fa22y = model.parse_expr(f"DIV( SUB( ncf_fa22_lagq0, ncf_fa22_lagq4), FMEAN('ta',0,4))")
    model.add_feature(ms.Feature(model, name=f"f_gcfa-DVD-y", calculator=AstAdjncf_fa22y))


def add_growth(model:ms.ModelState):
    """
    gt: Trend = FTBeta / Mean
    gdct: FDecCnt
    """    
    # share change
    ShareChg = model.parse_expr("DIV(fdmtlshare_lagq0,FILTER(fdmtlshare_lagq4,GREATER(fdmtlshare_lagq4,0)))")
    model.add_feature(ms.Feature(model, name="f_g-shr-y", calculator=ShareChg))

    tlchg2tachg = model.parse_expr("DIV(SUB(tl_lagq0, tl_lagq4), FILTER( SUB(ta_lagq0, ta_lagq4), GREATER(ABS(SUB(ta_lagq0,ta_lagq4)),0) )  )")
    model.add_feature(ms.Feature(model, name="f_g-tl2ta-y", calculator=tlchg2tachg))

    # ------- 一次的增速：盈利，营收，现金流，总资本 ------------ #
    q=20
    NPlTrend = model.parse_expr(f"DIV(FTBeta('np_exeal',0,{q}), FMEAN('np_exeal',0,{q}))")
    model.add_feature(ms.Feature(model, name=f"f_gt-NPl-{q}q", calculator=NPlTrend))
    
    q=8
    EPSTrend = model.parse_expr(f"DIV(FTBeta('dil_eps',0,{q}), FMEAN('dil_eps',0,{q}))")
    model.add_feature(ms.Feature(model, name=f"f_gt-dileps-{q}q", calculator=EPSTrend))

    # ----------- 营收增速的变化---------------------- #
    SaleTrend12Q = model.parse_expr(f"DIV(FTBeta('tor',0,12), FMEAN('tor',0,12) )")
    model.add_feature(ms.Feature(model, name=f"_SaleTrend12Q", calculator=SaleTrend12Q))
    SaleTrend12Q_l1y = model.parse_expr(f"DIV(FTBeta('tor',4,12), FMEAN('tor',4,12) )")
    model.add_feature(ms.Feature(model, name=f"_SaleTrend12Q_l1y", calculator=SaleTrend12Q_l1y))
    SaleTrend12QChg1Y = model.parse_expr(f"SUB(_SaleTrend12Q,_SaleTrend12Q_l1y)")
    model.add_feature(ms.Feature(model, name=f"f_gt-tor-ch1y", calculator=SaleTrend12QChg1Y))
            
    # ----------- 利润率的增速 -------------------#
    # gp margin Trend
    q = 16
    for i in range(q):
        margin = model.parse_expr(f"WINSOR(DIV(gp_lagq{i},PosTor_lagq{i}), -1,1)")
        model.add_feature(ms.Feature(model, name=f"_gpmargin_lagq{i}", calculator=margin))
    gpmarginTrend = model.parse_expr(f"DIV(FTBeta('_gpmargin',0,{q}), FMEAN('_gpmargin',0,{q}))")
    model.add_feature(ms.Feature(model, name=f"f_gt-gpm-{q}q", calculator=gpmarginTrend))

    # GPmargin DecCnt
    q=20
    GPmarginDCnt = model.parse_expr(f"DIV(FDecCnt('GPmargin',0,{q}),{q})")
    model.add_feature(ms.Feature(model, name=f"f_gdct-GPm-{q}q", calculator=GPmarginDCnt))

    # NPmargin
    q = 16
    npmarginTrend = model.parse_expr(f"DIV(FTBeta('npmargin',0,{q}), FMEAN('npmargin',0,{q}))")
    model.add_feature(ms.Feature(model, name=f"f_gt-npm-{q}q", calculator=npmarginTrend))

    # -----------------ROA, ROE的增速 ----------------- #
    # # ROE增速要求有一点高了。。
    # for i in range(16):
    #     # f_tci_parent2tse_parentTTM
    #     tci2tse = model.parse_expr(f"DIV(TTM('tci_parent',{i}), FMEAN('tse_parent',{i},4))")
    #     model.add_feature(ms.Feature(model, name=f"ROE-tciprt-TTM_lagq{i}", calculator=tci2tse))
    
    # CashTrend = model.parse_expr(f"DIV(FTBeta('ROE-tciprt-TTM',0,12), FMEAN('ROE-tciprt-TTM',0,12))")
    # model.add_feature(ms.Feature(model, name=f"f_gt-ROE-12q", calculator=CashTrend))

    # OHSaleDecCnt20Q = model.parse_expr(f"DIV(FDecCnt('ROE-tciprt-TTM',0,16),16)")
    # model.add_feature(ms.Feature(model, name=f"f_gdct-ROE-12q", calculator=OHSaleDecCnt20Q))

    # for i in range(12):
    #     # f_FCFcf2ta
    #     FCFcf2ta = model.parse_expr(f"DIV(FCFcf_lagq{i}, ta_lagq{i})")
    #     model.add_feature(ms.Feature(model, name=f"ROA-FCFcf_lagq{i}", calculator=FCFcf2ta))
    # CashTrend = model.parse_expr(f"DIV(FTBeta('ROA-FCFcf',0,12), FMEAN('ROA-FCFcf',0,12))")
    # model.add_feature(ms.Feature(model, name=f"f_gt-ROA-12q", calculator=CashTrend))

    # for i in range(16):        
    #     # f_tci_parent2ICTTM
    #     tci2ic = model.parse_expr(f"DIV(TTM('tci_parent',{i}), FMEAN('IC',{i},4))")
    #     model.add_feature(ms.Feature(model, name=f"ROIC-TTM_lagq{i}", calculator=tci2ic))
    # CashTrend = model.parse_expr(f"DIV(FTBeta('ROIC-TTM',0,16), FMEAN('ROIC-TTM',0,16))")
    # model.add_feature(ms.Feature(model, name=f"f_gt-ROIC-16q", calculator=CashTrend))


    

    for i in range(12):
        ncfoaQ = model.parse_expr(f"FMEAN('ncf_oa',{i},4)")
        model.add_feature(ms.Feature(model, name=f"_ocf1Q_lagq{i}", calculator=ncfoaQ))
    OCFTrend12Q = model.parse_expr(f"DIV(FTBeta('_ocf1Q',0,12), FMEAN('_ocf1Q',0,12) )")
    model.add_feature(ms.Feature(model, name=f"f_OCFTrend12Q", calculator=OCFTrend12Q))

    for i in range(12):
        epsQ = model.parse_expr(f"FMEAN('dil_eps',{i},4)")
        model.add_feature(ms.Feature(model, name=f"_dil_eps_lagq{i}", calculator=epsQ))
    EPSTrend12Q = model.parse_expr(f"MUL(FTBeta('_dil_eps',0,12), FMEAN('_dil_eps',0,12) )")
    model.add_feature(ms.Feature(model, name=f"f_EPSTrend12Q", calculator=EPSTrend12Q))

    for i in range(8):
        saleQ = model.parse_expr(f"FMEAN('tor1',{i},4)")
        model.add_feature(ms.Feature(model, name=f"_saleQ_lagq{i}", calculator=saleQ))
    SaleTrend12Q = model.parse_expr(f"DIV(FTBeta('_saleQ',0,4), FMEAN('_saleQ',0,4) )")
    model.add_feature(ms.Feature(model, name=f"f_SaleTrend12Q", calculator=SaleTrend12Q))

    SaleTrend12Q_l1y = model.parse_expr(f"DIV(FTBeta('_saleQ',4,4), FMEAN('_saleQ',4,4) )")
    model.add_feature(ms.Feature(model, name=f"SaleTrend12Q_l1y", calculator=SaleTrend12Q_l1y))
    SaleTrend12QChg1Y = model.parse_expr(f"SUB(f_SaleTrend12Q,SaleTrend12Q_l1y)")
    model.add_feature(ms.Feature(model, name=f"f_SaleTrend12QChg1Y", calculator=SaleTrend12QChg1Y))
    
    for i in range(20):
        OHSale = model.parse_expr(f"DIV(SUB(SUB(tor1_lagq{i}, toc1_lagq{i}),np_exeal_lagq{i}),ABS(tor1_lagq{i}))")
        model.add_feature(ms.Feature(model, name=f"OHSale_lagq{i}", calculator=OHSale))
    OHSaleDecCnt20Q = model.parse_expr(f"FDecCnt('OHSale',0,20)")
    model.add_feature(ms.Feature(model, name=f"f_OHSaleDecCnt20Q", calculator=OHSaleDecCnt20Q))
    model.add_feature(ms.Feature(model, name=f"f_OHSale", calculator=model.parse_expr(f"FILTER(OHSale_lagq0, GREATER(tor1_lagq0, 0))")))
    
    for i in range(20):
        NegOCFTTM = model.parse_expr(f"NEG(ncf_oa_lagq{i})")
        model.add_feature(ms.Feature(model, name=f"NegOCFTTM_lagq{i}", calculator=NegOCFTTM))
    OCFIncCnt20Q = model.parse_expr(f"FDecCnt('NegOCFTTM',0,20)")
    model.add_feature(ms.Feature(model, name=f"f_OCFIncCnt20Q", calculator=OCFIncCnt20Q))
  
    for i in range(20):
        NegEPSTTM = model.parse_expr(f"NEG(dil_eps_lagq{i})")
        model.add_feature(ms.Feature(model, name=f"NegEPSTTM_lagq{i}", calculator=NegEPSTTM))
    EPSIncCnt20Q = model.parse_expr(f"FDecCnt('NegEPSTTM',0,20)")
    model.add_feature(ms.Feature(model, name=f"f_EPSIncCnt20Q", calculator=EPSIncCnt20Q))
  
    for i in range(20):
        NegOCFMarginTTM = model.parse_expr(f"NEG(DIV(ncf_oa_lagq{i},PosTor_lagq{i}))")
        model.add_feature(ms.Feature(model, name=f"NegOCFMarginTTM_lagq{i}", calculator=NegOCFMarginTTM))
    OCFMarginIncCnt20Q = model.parse_expr(f"FDecCnt('NegOCFMarginTTM',0,20)")
    model.add_feature(ms.Feature(model, name=f"f_OCFMarginIncCnt20Q", calculator=OCFMarginIncCnt20Q))
  
    for i in range(20):
        RecInv2Sale = model.parse_expr(f"DIV(ADD( FMEAN('REC',{i},4), FMEAN('INV',{i},4))  ,TTM('tor',{i}))")
        model.add_feature(ms.Feature(model, name=f"_RecInv2Sale_lagq{i}", calculator=RecInv2Sale))
        filterpostor = model.parse_expr(f"FILTER(_RecInv2Sale_lagq{i}, GREATER(TTM('tor',{i}),0)")
        model.add_feature(ms.Feature(model, name=f"RecInv2Sale_lagq{i}", calculator=filterpostor))
    model.add_feature(ms.Feature(model, name=f"f_RecInv2Sale", calculator=model.parse_expr(f"COPY(RecInv2Sale_lagq0)")))
    RecInv2SaleDecCnt20Q = model.parse_expr(f"FDecCnt('RecInv2Sale',0,20)")
    model.add_feature(ms.Feature(model, name=f"f_RecInv2SaleDecCnt20Q", calculator=RecInv2SaleDecCnt20Q))
    
    SustainGrwrate = model.parse_expr(f"MUL(SUB(1, DIV(ncf_fa22_lagq0, np_exeal_lagq0)), DIV( np_exeal_lagq0 , CEQ_lagq0))")
    model.add_feature(ms.Feature(model, name=f"f_SustainGrwrate", calculator=SustainGrwrate))
    