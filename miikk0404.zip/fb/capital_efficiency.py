import modelstate as ms

def add_operation_ability(model:ms.ModelState):
    #固定资产周转率
    PPETurnover = model.parse_expr("WINSOR(DIV(PosTor_lagq0, FMEAN('ta_nca6',0,2)),0,100)")
    model.add_feature(ms.Feature(model, name="f_op-PPEtn", calculator=PPETurnover))
    
    # 存货周转率 reversed
    InvTurnover =  model.parse_expr("WINSOR(DIV( FMEAN('INV',0,2), PosToc_lagq0),0,50)")
    model.add_feature(ms.Feature(model, name="f_op-INVtn-v", calculator=InvTurnover))
    
    # 应收账款周转率
    RecTurnover = model.parse_expr("WINSOR(DIV(PosTor_lagq0, FMEAN('REC',0,2)),0,200)")
    model.add_feature(ms.Feature(model, name="f_op-RECtn", calculator=RecTurnover))

    # 应付账款周转率
    PayTurnover =  model.parse_expr("WINSOR(DIV(PosToc_lagq0, FMEAN('PAY',0,2)),0,100)")
    model.add_feature(ms.Feature(model, name="f_op-PAYtn", calculator=PayTurnover))

    # working capital 周转率
    WCTurnover = model.parse_expr("WINSOR(DIV(PosTor_lagq0, FMEAN('wc',0,2) ),-50,50)")
    model.add_feature(ms.Feature(model, name="f_op-WCtn", calculator=WCTurnover))

    # asset turnover
    AsstTurnover =  model.parse_expr("DIV( PosTor_lagq0, FMEAN('ta',0,2))")
    model.add_feature(ms.Feature(model, name="f_op-ATtn", calculator=AsstTurnover))

    # cash turnover
    Cash2Sale = model.parse_expr("WINSOR(DIV( cash_lagq0, PosTor_lagq0),0,50) ")
    model.add_feature(ms.Feature(model, name="f_op-CASHtn-v", calculator=Cash2Sale))
    
    # ---------    
    InvTurnover1 =  model.parse_expr("WINSOR(DIV(FMEAN('INV',0, 4), PosSale1y),0,5)")
    model.add_feature(ms.Feature(model, name="f_op-INV2Sale-v", calculator=InvTurnover1))

    # Capex2Sale = model.parse_expr("DIV( CAPEX_lagq0, PosTor_lagq0)")
    # model.add_feature(ms.Feature(model, name="f_Capex2Sale", calculator=Capex2Sale))
    
    # EqtyTurnover =  model.parse_expr("DIV( tor_lagq0, CEQ_lagq0)")
    # model.add_feature(ms.Feature(model, name="f_EqtyTurnover", calculator=EqtyTurnover))
        
def add_capital_structure(model:ms.ModelState):
    
    Cash2CEQ = model.parse_expr("WINSOR(DIV(cash_lagq0, CEQ_lagq0),0,50)")
    model.add_feature(ms.Feature(model, name=f"f_Cash2CEQ", calculator=Cash2CEQ))

    # 资产负债率    
    WC2Ast = model.parse_expr("DIV(wc_lagq0, ta_lagq0)")
    model.add_feature(ms.Feature(model, name="f_WC2AT", calculator=WC2Ast))

    # 权益乘数
    equMul = model.parse_expr("WINSOR(DIV(ta_lagq0, CEQ_lagq0),0,200)")
    model.add_feature(ms.Feature(model, name="f_equMul", calculator=equMul))

    Debt2Ast = model.parse_expr("DIV(debt_lagq0 , ta_lagq0)")
    model.add_feature(ms.Feature(model, name="f_Debt2AT", calculator=Debt2Ast))

    TobinQ = model.parse_expr("WINSOR(DIV(ADD(circMV, tl_lagq0 ), ta_lagq0),0,10)")
    model.add_feature(ms.Feature(model, name="f_TobinQ", calculator=TobinQ))

    Inv2Ast =  model.parse_expr("DIV( INV_lagq0, ta_lagq0)")
    model.add_feature(ms.Feature(model, name="f_Inv2AT", calculator=Inv2Ast))
    
    # tl2Ast = model.parse_expr("DIV(tl_lagq0, ta_lagq0)")
    # model.add_feature(ms.Feature(model, name="f_tl2Ast", calculator=tl2Ast))

    
    # LTDA = model.parse_expr("DIV(ltdebt_lagq0, ta_lagq0)")
    # model.add_feature(ms.Feature(model, name="f_LTDA", calculator=LTDA))
    
    # LTDE = model.parse_expr("DIV(ltdebt_lagq0 , CEQ_lagq0)")
    # model.add_feature(ms.Feature(model, name="f_LTDE", calculator=LTDE))
    
    # 长期资产负债率
    # ncl2ast = model.parse_expr("DIV(tl_ncl_lagq0, ADD(ta_nca_lagq0,tse_parent_lagq0))")
    # model.add_feature(ms.Feature(model, name="f_tnl2Ast", calculator=ncl2ast))
        
    RE2Ast = model.parse_expr("DIV(ADD(FILLNA(tse_pa8_lagq0,0), FILLNA(tse_pa7_lagq0,0)), ta_lagq0)")
    model.add_feature(ms.Feature(model, name="f_RE2AT", calculator=RE2Ast))

    # total invested capital = share holders & debt holders
    # Sale2IC = model.parse_expr("DIV(sale1y, TTM('IC',0))")
    # model.add_feature(ms.Feature(model, name="f_Sale2IC", calculator=Sale2IC))

    DebtChg2Ast = model.parse_expr("DIV(SUB(debt_lagq0,debt_lagq4) , AT1yAvg)")
    model.add_feature(ms.Feature(model, name="f_chDebt2AT", calculator=DebtChg2Ast))
    
    
    
    # 002 TODO:BuyBackChg = quarterly net purchase of CSE PRSTKCQ

    
    # (ncf_oa-cash div)/CAPEX
    # CapAcqRatio = model.parse_expr("DIV( SUB(ncf_oa_lagq0, ncf_fa22_lagq0)   ,FILTER(CAPEX_lagq0,GREATER(CAPEX_lagq0,0)))")
    # model.add_feature(ms.Feature(model, name="f_CapAcqRatio", calculator=CapAcqRatio))




    # interest / pretax income
    # FinLev = model.parse_expr("DIV(toc14_1_lagq0  , tp_lagq0)")
    # model.add_feature(ms.Feature(model, name="f_FinLev", calculator=FinLev))

    #  TODO: 021 PayoutRatio = Div per share/ Basic EPS - exclude extraordinary items

    # DebtChg1y = model.parse_expr("SUB(DIV(FMEAN('debt',0,4), AT1yAvg), DIV(FMEAN('debt',4,4), AT1yAvg_l1y))")
    # model.add_feature(ms.Feature(model, name="f_DebtChg1y", calculator=DebtChg1y))

     

    # DvD2CF = model.parse_expr("DIV(ncf_fa22_lagq0, CF_lagq0)")
    # model.add_feature(ms.Feature(model, name=f"f_DvD2CF", calculator=DvD2CF))
    
    # net tangible asset
    # NPexl2NTA = model.parse_expr("DIV(np_exeal_lagq0, ADD(wc_lagq0,ta_nca6_lagq0))")
    # model.add_feature(ms.Feature(model, name=f"f_NPexl2NTA", calculator=NPexl2NTA))
    
def add_capital_efficiency(model:ms.ModelState):
    # ROA = FCFic/ta
    FCFic2ta = model.parse_expr(f"DIV(TTM('FCFic',0), AT1yAvg)")
    model.add_feature(ms.Feature(model, name=f"f_ROA-FCFic-TTM", calculator=FCFic2ta))
    
    # f_FCFcf2ta
    FCFcf2ta = model.parse_expr(f"DIV(FCFcf_lagq0, ta_lagq0)")
    model.add_feature(ms.Feature(model, name=f"f_ROA-FCFcf", calculator=FCFcf2ta))

    # f_tci_parent2ICTTM
    tci2ic = model.parse_expr(f"DIV(TTM('tci_parent',0), FMEAN('IC',0,4))")
    model.add_feature(ms.Feature(model, name=f"f_ROIC-TTM", calculator=tci2ic))

    # f_tci_parent2tse_parentTTM
    tci2tse = model.parse_expr(f"DIV(TTM('tci_parent',0), FMEAN('tse_parent',0,4))")
    model.add_feature(ms.Feature(model, name=f"f_ROE-tciprt-TTM", calculator=tci2tse))
    
    # ROE
    tci2tse = model.parse_expr(f"DIV(TTM('np_exeal',0), CE1yAvg)")
    model.add_feature(ms.Feature(model, name=f"f_ROE-NPl-TTM", calculator=tci2tse))

    
    # ROA = model.parse_expr("DIV( nopat_lagq0 , ta_lagq0)")
    # model.add_feature(ms.Feature(model, name="f_ROA", calculator=ROA))
    
    # ROIC = model.parse_expr("DIV( TTM('nopat',0) , InvCap1yAvg)")
    # model.add_feature(ms.Feature(model, name="f_ROIC", calculator=ROIC))
    
def add_debt_paying_ability(model:ms.ModelState):
    
    # 流动比例
    CurrentRatio = model.parse_expr("DIV( ta_ca_lagq0, tl_cl_lagq0) ")
    model.add_feature(ms.Feature(model, name="f_dp-Cur", calculator=CurrentRatio))

    # QuickRatio = model.parse_expr("DIV( ADD(CEQ_lagq0, REC_lagq0), tl_cl_lagq0) ")
    # model.add_feature(ms.Feature(model, name="f_QuickRatio", calculator=QuickRatio))

    # QuickRatio1 = model.parse_expr("DIV( SUB(ta_ca_lagq0, INV_lagq0), tl_cl_lagq0) ")
    # model.add_feature(ms.Feature(model, name="f_QuickRatio1", calculator=QuickRatio1))

    QuickRatio2 = model.parse_expr("DIV(ADD(ADD(cash_lagq0,REC_lagq0),ADD(FILLNA(ta_ca6_lagq0,0),FILLNA(ta_ca7_lagq0,0))), tl_cl_lagq0) ")
    model.add_feature(ms.Feature(model, name="f_dp-Qik", calculator=QuickRatio2))

    # CashRatio = model.parse_expr("DIV( cash_lagq0, tl_cl_lagq0) ")
    # model.add_feature(ms.Feature(model, name="f_CashRatio", calculator=CashRatio))
    
    CashRatio1 = model.parse_expr("DIV( ADD(cash_lagq0,FILLNA(ta_ca3_lagq0,0)), tl_cl_lagq0) ")
    model.add_feature(ms.Feature(model, name="f_dp-Cash", calculator=CashRatio1))

    OCFratio = model.parse_expr("DIV(ncf_oa_lagq0 , tl_cl_lagq0)")
    model.add_feature(ms.Feature(model, name="f_dp-ocf", calculator=OCFratio))

    # 已获利息倍数：EBIT/利息费用toc14_1（一三季报无披露）如果财务报告中公布了财务费用明细，则“利息费用=利息支出-利息收入”；如果财务报告中未公布财务费用明细，则以“利润表.财务费用”替代。一般而言，中期报告和年度报告中会公布财务费用明细。当利息费用为零或负时，该指标无意义，不计算返回为空
    IntCovRatio =  model.parse_expr("DIV(ebit_lagq0 , FILTER(toc14_1_lagq0,GREATER(toc14_1_lagq0,0)))")
    model.add_feature(ms.Feature(model, name="f_IntCovRatio", calculator=IntCovRatio))

    AdjIntCov = model.parse_expr("DIV(EBITDA_lagq0, FILTER(toc14_1_lagq0,GREATER(toc14_1_lagq0,0)))")
    model.add_feature(ms.Feature(model, name="f_AdjIntCov", calculator=AdjIntCov))


    # OCFratio = model.parse_expr("DIV(ncf_oa_lagq0 , FILTER(toc14_1_lagq0,GREATER(toc14_1_lagq0,0)))")
    # model.add_feature(ms.Feature(model, name="f_OCFratio1", calculator=OCFratio))


    CashCycle = model.parse_expr("ADD(  DIV(FMEAN('REC',0,4),PosSale1y) ,   DIV( SUB(  FMEAN('INV',0,4),  FMEAN('PAY',0,4) ), FILTER(TTM('toc1',0),GREATER(TTM('toc1',0),0)) )")
    model.add_feature(ms.Feature(model, name="f_CashCycle", calculator=CashCycle))

    SolvencyRatio = model.parse_expr("DIV(CF_lagq0,tl_lagq0)")
    model.add_feature(ms.Feature(model, name=f"f_SolvencyRatio", calculator=SolvencyRatio))

    CashBurn = model.parse_expr("DIV( ADD(ncf_oa_lagq0, ncf_ia_lagq0), FILTER(cash_lagq0,GREATER(cash_lagq0,0)))")
    model.add_feature(ms.Feature(model, name="f_CashBurn", calculator=CashBurn))


    # TODO: ncfoa / stdebt + 一年到期的非流动负债 + 应付票据

    # TODO: EBITDA/负债
     # TODO: 长期负债/运营资金； 非流动负债/运营资金


    # TODO: 无息债务。 

