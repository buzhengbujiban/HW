import modelstate as ms

def add_profit_margin(model:ms.ModelState):
    # 毛利率，剔除资产减值损失带来的影响
    GPmargin = model.parse_expr("COPY(GPmargin_lagq0)")
    model.add_feature(ms.Feature(model, name="f_pm-GP", calculator=GPmargin))
    
    # npexeal，扣非净利润
    NPexlmargin = model.parse_expr("WINSOR(DIV(np_exeal_lagq0,PosTor_lagq0),-1,1)")
    model.add_feature(ms.Feature(model, name="f_pm-NPl", calculator=NPexlmargin))
    
    # EBITDAmargin，剔除非经营影响的利润率
    EBITDAmargin = model.parse_expr("WINSOR(DIV(EBITDA_lagq0,PosTor_lagq0),-1,1)")
    model.add_feature(ms.Feature(model, name="f_pm-EBITDA", calculator=EBITDAmargin))
    
    OPmargin =  model.parse_expr("WINSOR(DIV(op_lagq0, PosTor_lagq0),-1,1)")
    model.add_feature(ms.Feature(model, name="f_pm-OP", calculator=OPmargin))

    # EBITmargin = model.parse_expr("DIV(ebit_lagq0, PosTor_lagq0)")
    # model.add_feature(ms.Feature(model, name="f_EBITmargin", calculator=EBITmargin))
    
    # NPmargin =  model.parse_expr("DIV(np_lagq0, PosTor_lagq0)")
    # model.add_feature(ms.Feature(model, name="f_NPmargin", calculator=NPmargin))
        
    # TP2NOA = model.parse_expr("DIV( tp_lagq0, noa_lagq0 )")  # TODO: handle noa<0, it means very bad fdmtl
    # model.add_feature(ms.Feature(model, name="f_TP2NOA", calculator=TP2NOA))

    # TPmargin = model.parse_expr("DIV( tp_lagq0, PosTor_lagq0)")  # TODO: handle noa<0, it means very bad fdmtl
    # model.add_feature(ms.Feature(model, name="f_TPmargin", calculator=TPmargin))

    # Sale2EPS = model.parse_expr("EGrowth(DIV(tor1_lagq0,fdmtlshare_lagq0), dil_eps_lagq0 )")
    # model.add_feature(ms.Feature(model, name="f_Sale2EPS", calculator=Sale2EPS))
    
    # EPS2OCF = model.parse_expr("DIV(dil_eps_lagq0, DIV(FILTER(ncf_oa_lagq0,GREATER(ncf_oa_lagq0,0)),fdmtlshare_lagq0) )")
    # model.add_feature(ms.Feature(model, name="f_EPS2OCF", calculator=EPS2OCF))
       
    OHSale = model.parse_expr(f"DIV(SUB(gp_lagq0,np_exeal_lagq0),ABS(tor1_lagq0))")
    model.add_feature(ms.Feature(model, name=f"f_pm-OH", calculator=OHSale))
    

def add_accrual(model:ms.ModelState):
    # chg_(ta_ca3+ta_ca4+ta_ca5+=ta_ca10+ta_ca13) - chg(tl_cl4+tl_cl5+tl_cl6+tl_cl16), normalize by asset
    # AccrualBSast = model.parse_expr("ADD(ADD(ADD(ADD(FILLNA(SUB(ta_ca3_lagq0, ta_ca3_lagq1),0) , FILLNA(SUB(ta_ca4_lagq0, ta_ca4_lagq1),0)),FILLNA(SUB(ta_ca5_lagq0, ta_ca5_lagq1),0)),FILLNA(SUB(INV_lagq0, INV_lagq1),0)),FILLNA(SUB(ta_ca13_lagq0, ta_ca13_lagq1),0))")  
    # model.add_feature(ms.Feature(model, name="_AccrualBSast", calculator=AccrualBSast))
    # AccrualBSlt = model.parse_expr("ADD(ADD(ADD(FILLNA(SUB(tl_cl4_lagq0, tl_cl4_lagq1),0) , FILLNA(SUB(tl_cl5_lagq0, tl_cl5_lagq1),0)),FILLNA(SUB(tl_cl6_lagq0, tl_cl6_lagq1),0)),FILLNA(SUB(tl_cl16_lagq0, tl_cl16_lagq1),0))")  
    # model.add_feature(ms.Feature(model, name="_AccrualBSlt", calculator=AccrualBSlt))
    # AccrualBS = model.parse_expr("DIV(SUB(_AccrualBSast, _AccrualBSlt),ta_lagq0)")  
    # model.add_feature(ms.Feature(model, name="f_AccrualBS", calculator=AccrualBS))

    # # tp - ncfoa - ncfia   
    # AccrualCF = model.parse_expr("SUB(tp_lagq0,ADD(ncf_oa_lagq0, ncf_ia_lagq0))")  
    # model.add_feature(ms.Feature(model, name="f_AccrualCF", calculator=AccrualCF))

    
    # AccrualBS = (NOA - last year NOA) / (NOA+last year NOA)/2
    AccrualBS = model.parse_expr("DIV(  SUB(noa_lagq0, noa_lagq4) ,  NOA2yAvg)")
    model.add_feature(ms.Feature(model, name="f_AccrualBS", calculator=AccrualBS))
    
    # AccrualCF = (Income before extraordinary items - OCF - ICF) / (NOA2yAvg)
    AccrualCF = model.parse_expr("DIV(  SUB( tp_lagq0, ADD(ncf_oa_lagq0, ncf_ia_lagq0) ) ,  NOA2yAvg)")
    model.add_feature(ms.Feature(model, name="f_AccrualCF", calculator=AccrualCF))
    # TODO: check why cor(AccrualCF,AccrualBS)=-8%

    # AdjAccruals = (np-ocf)/|np|
    AdjAccrual = model.parse_expr("DIV(  SUB(np_lagq0, ncf_oa_lagq0 ), ADD(ABS(np_lagq0),100)  )")
    model.add_feature(ms.Feature(model, name="f_AdjAccrual", calculator=AdjAccrual))

    # balance sheet accruals = (RECTQ+INVTQ+ACOQ-APQ-LCOQ)/SALEQ # TODO: check correctability
    AccrualAT = model.parse_expr("ADD(ADD( REC_lagq0, FILLNA(ta_ca5_lagq0,0)), FILLNA(ta_ca13_lagq0,0))")
    model.add_feature(ms.Feature(model, name="AccrualAT", calculator=AccrualAT))
    AccrualLT = model.parse_expr("ADD(ADD( PAY_lagq0, FILLNA(tl_cl6_lagq0,0)), FILLNA(tl_cl16_lagq0,0))")
    model.add_feature(ms.Feature(model, name="AccrualLT", calculator=AccrualLT))
    AccrualBS2 = model.parse_expr("DIV(SUB(AccrualAT, AccrualLT), PosTor_lagq0)")
    model.add_feature(ms.Feature(model, name="f_AccrualBS2", calculator=AccrualBS2))
 
    # working capital accruals = (chg1y(Accrual AT)-chg1y(Accrual AL) - TTM(DP))/AT1yAvg # TODO: check correctability
    AccrualAT_l1y = model.parse_expr("ADD(ADD( REC_lagq4, FILLNA(ta_ca5_lagq4,0)), FILLNA(ta_ca13_lagq4,0))")
    model.add_feature(ms.Feature(model, name="AccrualAT_l1y", calculator=AccrualAT_l1y))
    AccrualLT_l1y = model.parse_expr("ADD(ADD( PAY_lagq4, FILLNA(tl_cl6_lagq4,0)), FILLNA(tl_cl16_lagq4,0))")
    model.add_feature(ms.Feature(model, name="AccrualLT_l1y", calculator=AccrualLT_l1y))
    WCAccrual = model.parse_expr("DIV(SUB( SUB( SUB(AccrualAT, AccrualAT_l1y),  SUB(AccrualLT,AccrualLT_l1y) )  ,TTM('DA',0)), AT1yAvg)")
    model.add_feature(ms.Feature(model, name="f_WCAccrual", calculator=WCAccrual))

def add_earning_manipulation(model:ms.ModelState):
    """
    feature_lists=["Dep2Capex","RDIntensity","SGA2Sales","UnexpInvChg","UnexpRecChg"]
    """
    # Capex2Dep = model.parse_expr("WINSOR(DIV(SUB(CAPEX_lagq0,ncf_ia13_lagq0),DA1_lagq0),-30,30)")  
    # model.add_feature(ms.Feature(model, name="f_Capex2Dep", calculator=Capex2Dep))

    RDIntensity = model.parse_expr("DIV(toc14_lagq0,PosTor_lagq0)")
    model.add_feature(ms.Feature(model, name="f_em-RD", calculator=RDIntensity))
    
    SGA2Sales = model.parse_expr("DIV(SGA_lagq0,PosTor_lagq0)")
    model.add_feature(ms.Feature(model, name="f_em-SGA", calculator=SGA2Sales))

    UnexpInvChg = model.parse_expr("DIV(SUB(INV_lagq0,  MUL(INV_lagq4, DIV(raw_PosTor_lagq0,raw_PosTor_lagq4)) ),ta_lagq4)")
    model.add_feature(ms.Feature(model, name="f_em-ucINV", calculator=UnexpInvChg))
    
    UnexpRecChg = model.parse_expr("DIV(SUB(REC_lagq0,  MUL(REC_lagq4, DIV(raw_PosTor_lagq0,raw_PosTor_lagq4)) ),ta_lagq4)")
    model.add_feature(ms.Feature(model, name="f_em-ucREC", calculator=UnexpRecChg))
   
    #OPdeviation = |op/tp-1|, 值越大，非营收占比越高，质量越差
    OPdev = model.parse_expr("WINSOR(ABS(SUB(DIV(op_lagq0, tp_lagq0),1)),0,10)")
    model.add_feature(ms.Feature(model, name="f_em-NOP", calculator=OPdev))

    AstDevolCV = model.parse_expr("WINSOR(DIV(FSTD('AstDevol',0,4),FMEAN('AstDevol',0,4)),-30,30)")
    model.add_feature(ms.Feature(model, name="f_em-AstDvl", calculator=AstDevolCV))
    

def add_change(model:ms.ModelState):
    """
    增速不匹配:eg yoyA - yoyB
    增速变缓:egr yoy - yoy lag1
    """
    # 营收增速-利润增速 不匹配：利润增速过快，可能是控制成本或盈余操纵带来的。    
    chSale2chOCF = model.parse_expr(f"SUB( EGrowth(raw_tor_lagq0, raw_tor_lagq4), EGrowth(raw_ncf_oa_lagq0, raw_ncf_oa_lagq4))") 
    model.add_feature(ms.Feature(model, name=f"f_eg-OCF-r", calculator=chSale2chOCF))
    
    chSale2chNPl = model.parse_expr(f"SUB( EGrowth(tor_lagq0, tor_lagq4), EGrowth(np_exeal_lagq0, np_exeal_lagq4))") 
    model.add_feature(ms.Feature(model, name=f"f_eg-NPl", calculator=chSale2chNPl))

    chSale12GP = model.parse_expr(f"SUB( EGrowth(tor1_lagq0, tor1_lagq4), EGrowth(gp_lagq0, gp_lagq4))") 
    model.add_feature(ms.Feature(model, name=f"f_eg-gp", calculator=chSale12GP))

    # 现金流增速-利润增速不匹配：accrual带来的增速占比过多，质量不高。
    EPSbas2NCFChg = model.parse_expr(f"SUB( EGrowth(DIV(ncf_lagq0,fdmtlshare_lagq0), DIV(ncf_lagq4,fdmtlshare_lagq4)), EGrowth(dil_eps_lagq0, dil_eps_lagq4))") 
    model.add_feature(ms.Feature(model, name=f"f_eg-ncf2dileps", calculator=EPSbas2NCFChg))
    
    GP2OCFChg = model.parse_expr(f"SUB( EGrowth(raw_ncf_oa_lagq0, raw_ncf_oa_lagq4), EGrowth(raw_gp_lagq0, raw_gp_lagq4))") 
    model.add_feature(ms.Feature(model, name=f"f_eg-OCF2gp", calculator=GP2OCFChg))
    
    NP2OCFChg = model.parse_expr(f"SUB( EGrowth(raw_ncf_lagq0, raw_ncf_lagq4), EGrowth(raw_np_lagq0, raw_np_lagq4))") 
    model.add_feature(ms.Feature(model, name=f"f_eg-NCF2np", calculator=NP2OCFChg))
   
    # 营收增速变缓：
    OCFrateqoq = model.parse_expr(f"EGrowth(DIV(ncf_oa_lagq0,ncf_oa_lagq4),DIV(ncf_oa_lagq1,ncf_oa_lagq5))") 
    model.add_feature(ms.Feature(model, name=f"f_egr-OCF", calculator=OCFrateqoq))
    
    OPrateqoq = model.parse_expr(f"EGrowth(DIV(raw_op_lagq0,raw_op_lagq4),DIV(raw_op_lagq1,raw_op_lagq5))") 
    model.add_feature(ms.Feature(model, name=f"f_egr-op-r", calculator=OPrateqoq))
    
    epsrateqoq = model.parse_expr(f"EGrowth(DIV(raw_bas_eps_lagq0,raw_bas_eps_lagq4),DIV(raw_bas_eps_lagq1,raw_bas_eps_lagq5))") 
    model.add_feature(ms.Feature(model, name=f"f_egr-baseps-r", calculator=epsrateqoq))


    # # |折旧增速-CAPEX增速|
    # ChgDep2ChgCapex = model.parse_expr("ABS( SUB( EGrowth( DA1_lagq0, DA1_lagq4) , EGrowth(raw_CAPEX_lagq0, raw_CAPEX_lagq4)  ) )")
    # model.add_feature(ms.Feature(model, name="f_ChgDep2ChgCapex", calculator=ChgDep2ChgCapex))
    
    # # ChgDep2ChgCapex = model.parse_expr("SUB( EGrowth( DA1_lagq0, DA1_lagq4) , EGrowth(SUB(raw_CAPEX_lagq0,raw_ncf_ia13_lagq0), SUB(raw_CAPEX_lagq4,raw_ncf_ia13_lagq4)) ) ")
    # # model.add_feature(ms.Feature(model, name="f_ChgDep2ChgCapex2", calculator=ChgDep2ChgCapex))
        

    # Inv2AstChg1Y = model.parse_expr("SUB( DIV( FMEAN('INV',0,4),AT1yAvg)  ,  DIV( FMEAN('INV',4,4),AT1yAvg_l1y) )")
    # model.add_feature(ms.Feature(model, name="f_Inv2AstChg1Y", calculator=Inv2AstChg1Y))
   

def add_stability(model:ms.ModelState):
    """
    estab: x / std(x)
    estab1: x/ SumAbsDiff 
    """
    # # ROE stability
    # cols = []
    # for col in ['ROA-FCFic-TTM','ROA-FCFcf','ROIC-TTM','ROE-tciprt-TTM','ROE-NPl-TTM']:
    #     for q in [8,12,16,20]:
    #         FCFStab = model.parse_expr(f"DIV({col}_lagq0, FSTD('{col}',0, {q}))")
    #         model.add_feature(ms.Feature(model, name=f"f_stab{col}-{q}q", calculator=FCFStab))
    #         cols.append(f"f_stab{col}-{q}q")

    #         FCFStab1 = model.parse_expr(f"DIV({col}_lagq0, FSumAbsDiff('{col}',0, {q}))")
    #         model.add_feature(ms.Feature(model, name=f"f_stab1{col}-{q}q", calculator=FCFStab))
    #         cols.append(f"f_stab1{col}-{q}q")

    # ROEchange 

    for i in range(8):
        FCFChg1Y = model.parse_expr(f"SUB( DIV(FCFic_lagq{i}, fdmtlshare_lagq{i}) ,DIV(FCFic_lagq{i+4}, fdmtlshare_lagq{i+4}) )")
        model.add_feature(ms.Feature(model, name=f"FCFChg1Y_lagq{i}", calculator=FCFChg1Y))
    FCFstd = model.parse_expr(f"FSTD('FCFChg1Y',0, 8) ")
    model.add_feature(ms.Feature(model, name="_FCFstd", calculator=FCFstd))
    FCFStab = model.parse_expr(f"DIV(FCFChg1Y_lagq0, FILTER(_FCFstd,GREATER(_FCFstd, 0.01)) )")
    model.add_feature(ms.Feature(model, name="f_FCFStab", calculator=FCFStab))

    for i in range(8):
        EPSChg1Y = model.parse_expr(f"SUB(raw_dil_eps_lagq{i}, raw_dil_eps_lagq{i+4})")
        model.add_feature(ms.Feature(model, name=f"EPSChg1Y_lagq{i}", calculator=EPSChg1Y))
    EPSstd = model.parse_expr(f"FSTD('EPSChg1Y',0, 8)")
    model.add_feature(ms.Feature(model, name="_EPSstd", calculator=EPSstd))
    EPSStab = model.parse_expr(f"DIV(EPSChg1Y_lagq0, FILTER(_EPSstd,GREATER(_EPSstd, 0.005)) )")
    model.add_feature(ms.Feature(model, name=f"f_EPSStab", calculator=EPSStab))
    
    for i in range(8):
        OCFChg1Y = model.parse_expr(f"SUB( DIV(raw_ncf_oa_lagq{i}, fdmtlshare_lagq{i}) ,DIV(raw_ncf_oa_lagq{i+4}, fdmtlshare_lagq{i+4}) )")
        model.add_feature(ms.Feature(model, name=f"OCFChg1Y_lagq{i}", calculator=OCFChg1Y))
    OCFstd = model.parse_expr(f"FSTD('OCFChg1Y',0, 8)")
    model.add_feature(ms.Feature(model, name="_OCFstd", calculator=OCFstd))
    OCFStab = model.parse_expr(f"DIV(OCFChg1Y_lagq0, FILTER(_OCFstd,GREATER(_OCFstd, 0.02)) )")
    model.add_feature(ms.Feature(model, name=f"f_OCFStab", calculator=OCFStab))

    
    for i in range(16): 
        NIChg1Y = model.parse_expr(f"DIV( SUB(raw_ebit_lagq{i}, raw_ebit_lagq{i+4}), ABS(raw_ebit_lagq{i+4}))")
        model.add_feature(ms.Feature(model, name=f"NIChg1Y_lagq{i}", calculator=NIChg1Y))    
    NIstd = model.parse_expr(f"FSumAbsDiff('NIChg1Y',0, 16)")
    model.add_feature(ms.Feature(model, name="_NIstd", calculator=NIstd))
    NIStab = model.parse_expr(f"DIV(FMEAN('NIChg1Y',0,16), FILTER(_NIstd,GREATER(_NIstd, 0.7)) )")
    model.add_feature(ms.Feature(model, name=f"f_NIStab", calculator=NIStab))

    
    for i in range(16): 
        NPexlChg1Y = model.parse_expr(f"DIV( SUB(raw_np_exeal_lagq{i}, raw_np_exeal_lagq{i+4}), MAX(ABS(raw_np_exeal_lagq{i+4}),100)  )")
        model.add_feature(ms.Feature(model, name=f"NPexlChg1Y_lagq{i}", calculator=NPexlChg1Y))    
    NPexlstd = model.parse_expr(f"FSumAbsDiff('NPexlChg1Y',0, 16)")
    model.add_feature(ms.Feature(model, name="_NPexlChg1Ystd", calculator=NPexlstd))
    NPexlStab = model.parse_expr(f"DIV(FMEAN('NPexlChg1Y',0,16), FILTER(_NPexlChg1Ystd,GREATER(_NPexlChg1Ystd, 0.01)) )")
    model.add_feature(ms.Feature(model, name=f"f_NPexlStab", calculator=NPexlStab))
    
    
    for i in range(16): 
        GPChg1Y = model.parse_expr(f"DIV( SUB(raw_gp_lagq{i}, raw_gp_lagq{i+4}), MAX(ABS(raw_gp_lagq{i+4}),100))")
        model.add_feature(ms.Feature(model, name=f"GPChg1Y_lagq{i}", calculator=GPChg1Y))    
    GPChg1Ystd = model.parse_expr(f"FSumAbsDiff('GPChg1Y',0, 16)")
    model.add_feature(ms.Feature(model, name="_GPChg1Ystd", calculator=GPChg1Ystd))
    GPStab = model.parse_expr(f"DIV(FMEAN('GPChg1Y',0,16), FILTER(_GPChg1Ystd,GREATER(_GPChg1Ystd, 0.01)) )")
    model.add_feature(ms.Feature(model, name=f"f_GPStab", calculator=GPStab))
    

    for i in range(12):
        ROA = model.parse_expr(f"DIV(raw_nopat_lagq{i},ta_lagq{i})") # 因为是ROAchg，所以可以用raw
        model.add_feature(ms.Feature(model, name=f"ROA_lagq{i}", calculator=ROA))
    for i in range(8):
        ROAchg = model.parse_expr(f"SUB(ROA_lagq{i}, ROA_lagq{i+4})")
        model.add_feature(ms.Feature(model, name=f"ROAchg_lagq{i}", calculator=ROAchg))
    ROAcgstd = model.parse_expr(f"FSTD('ROAchg',0, 8) ")
    model.add_feature(ms.Feature(model, name="_ROAcgstd", calculator=ROAcgstd))
    ROAchg1YStab = model.parse_expr(f"DIV(ROAchg_lagq0, FILTER(_ROAcgstd,GREATER(_ROAcgstd, 0.001)) )")
    model.add_feature(ms.Feature(model, name=f"f_ROAchg1YStab", calculator=ROAchg1YStab))


    for i in range(12):
        ROE = model.parse_expr(f"DIV(raw_np_exeal_lagq{i},CEQ_lagq{i})")# 因为是ROAchg，所以可以用raw
        model.add_feature(ms.Feature(model, name=f"ROE_lagq{i}", calculator=ROE))
    for i in range(8):
        ROEchg = model.parse_expr(f"SUB(ROE_lagq{i}, ROE_lagq{i+4})")
        model.add_feature(ms.Feature(model, name=f"ROEchg_lagq{i}", calculator=ROEchg))
    ROEcgstd = model.parse_expr(f"FSTD('ROEchg',0, 8)")
    model.add_feature(ms.Feature(model, name="_ROEcgstd", calculator=ROEcgstd))
    ROEchg1YStab = model.parse_expr(f"DIV(ROEchg_lagq0, FILTER(_ROEcgstd,GREATER(_ROEcgstd, 0.01)) )")
    model.add_feature(ms.Feature(model, name=f"f_ROEchg1YStab", calculator=ROEchg1YStab))


    for i in range(12):
        earnwc = model.parse_expr(f"DIV(ADD(SUB(EBITDA_lagq{i}, FILLNA(ite_lagq{i},0)),FILLNA(wc_lagq{i},0)),CEQ_lagq{i})")
        model.add_feature(ms.Feature(model, name=f"_earnwc_lagq{i}", calculator=earnwc))
    for i in range(8):
        chg1Y = model.parse_expr(f"SUB(_earnwc_lagq{i}, _earnwc_lagq{i+4})")
        model.add_feature(ms.Feature(model, name=f"_earnwc_chg1Y_lagq{i}", calculator=chg1Y))
    earnwc_chg1Y_std = model.parse_expr(f"FSTD('_earnwc_chg1Y',0, 8) ")
    model.add_feature(ms.Feature(model, name="_earnwc_chg1Y_std", calculator=earnwc_chg1Y_std))
    earnwc_chg1YStab = model.parse_expr(f"DIV(_earnwc_lagq0, FILTER(_earnwc_chg1Y_std,GREATER(_earnwc_chg1Y_std, 0.001)) )")
    model.add_feature(ms.Feature(model, name=f"f_earnwc_chg1YStab", calculator=earnwc_chg1YStab))



    
    
