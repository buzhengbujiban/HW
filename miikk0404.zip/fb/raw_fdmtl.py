import modelstate as ms
import numpy as np


def add_fin_basic_feats(model: ms.ModelState, report_type='consolidate', maxlagq = 8):
    assert report_type in ['consolidate', 'shareholder']
    report_type = 'consolidated' if report_type == 'consolidate' else 'parent_com'
    
    root='/data/nas2Data/chinaEquityData/statarb/staging/fdmtl' # single terms
    used_fields_single = {
        'fin_balance_sheet_gen': ['report_period','lagq',
            'ta_ca1', 'ta_ca2', 'ta_ca3', 'ta_ca4', 'ta_ca5', 'ta_ca6', 'ta_ca7',  'ta_ca10', 'ta_ca13', 'ta_ca', 'ta_nca1', 'ta_nca3', 'ta_nca4',  
            'ta_nca5', 'ta_nca6', 'ta_nca7', 'ta_nca12', 'ta_nca13', 'ta_nca14',  'ta_nca15', 'ta_nca16', 'ta_nca17', 'ta_nca', 'ta', 'tl_cl1', 
            'tl_cl4',  'tl_cl5', 'tl_cl6', 'tl_cl9', 'tl_cl10', 'tl_cl11', 'tl_cl12',  'tl_cl13', 'tl_cl15', 'tl_cl16', 'tl_cl', 'tl_ncl1', 'tl_ncl2',  
            'tl_ncl5', 'tl_ncl8', 'tl_ncl9', 'tl_ncl10', 'tl_ncl', 'tl', 'tse_pa1','tse_pa3',  'tse_pa5', 'tse_pa6', 'tse_pa7', 'tse_pa8', 'tse_pa9', 'tse_pa11',  
            'tse_parent', 'tse_monority', 'tse', 'tlse', 'ta_ca14', 'tl_cl17',  'tl_cl18'],
        'fin_income_gen': [  
            'bas_eps', 'dil_eps', 'gain_fv', 'gain_other', 'gain_ta', 'inve_income',  'inve_income_joint', 'ite', 'loss_ta', 'non_oe', 'non_op', 'np',  
            'np_continuous', 'np_minority', 'np_shareholder', 'op', 'other_np',  'other_np1', 'other_np12', 'other_np125', 'tci', 'tci_monority',  'tci_parent', 
            'toc', 'toc1', 'toc10', 'toc11', 'toc12', 'toc13',  'toc14', 'toc14_1', 'toc14_2', 'toc9', 'tor', 'tor1', 'tp'],
        'fin_cash_flow_gen': ['begin_cf', 'end_cf', 'gain_exch', 'ncf',  'ncf_fa', 'ncf_fa1', 'ncf_fa13', 'ncf_fa15', 'ncf_fa2', 'ncf_fa21',  
            'ncf_fa22', 'ncf_fa24', 'ncf_ia', 'ncf_ia1', 'ncf_ia11', 'ncf_ia12',  'ncf_ia13', 'ncf_ia15', 'ncf_ia2', 'ncf_ia21', 'ncf_ia22', 
            'ncf_ia25',  'ncf_oa', 'ncf_oa1', 'ncf_oa11', 'ncf_oa12', 'ncf_oa13', 'ncf_oa2',  'ncf_oa21', 'ncf_oa22', 'ncf_oa23', 'ncf_oa24'],
        'fin_main_indicator': ['np_exeal', 'ebit', 'ebitda','wc','eps_exeal','na_ps','udp_ps','cr_ps','ncf_ps','ncf_oa_ps']
    }
    
    field_maps_single = {
        'fin_balance_sheet_gen': [('tse_pa1', 'CEQ'),('ta_ca10','INV')],
        'fin_income_gen': [],
        'fin_cash_flow_gen': [('ncf_ia21', 'CAPEX')]
    }


    # raw
    root_raw='/data/nas2Data/chinaEquityData/statarb/staging/fdmtl_raw'
    used_fields_raw = {
        'fin_main_indicator': ['ebit', 'ebitda','ncf_ps',"np_exeal"],
        "fin_cash_flow_gen": ["ncf","ncf_oa","ncf_ia21","ncf_fa22",'ncf_ia13'],
        'fin_income_gen': [ "tor","tor1","toc","toc13","toc1","toc10","toc11","toc12","dil_eps","bas_eps","np","tp","op"]
    }
    field_maps_raw = {
        'fin_cash_flow_gen': [('ncf_ia21', 'CAPEX')]
    }

    all_suffix = np.arange(maxlagq,-1,-1)
    for q in all_suffix:
        suffix = f'lagq{q:.0f}'
        # load single terms
        for table, fields in used_fields_single.items():
            field_map = {}
            if table in field_maps_single:
                for item in field_maps_single[table]:
                    field_map[f'{item[0]}.{suffix}'] = f'{item[1]}.{suffix}'
            model.add_sdiv_features(f'{root}/{table}/{report_type}/YYYYMMDD.sdiv',
                fields=[f'{field}.{suffix}' for field in fields],
                field_map=field_map,
                name_prefix="",
                ival_replace={"09:20:00": "16:00:00"},
                dval_replace=-1)

        # load raw terms
        for table, fields in used_fields_raw.items():
            field_map = {}
            if table in field_maps_raw:
                for item in field_maps_raw[table]:
                    field_map[f'{item[0]}.{suffix}'] = f'{item[1]}.{suffix}'
            model.add_sdiv_features(f'{root_raw}/{table}/{report_type}/YYYYMMDD.sdiv',
                fields=[f'{field}.{suffix}' for field in fields],
                field_map=field_map,
                name_prefix="raw_",
                ival_replace={"09:20:00": "16:00:00"},
                dval_replace=-1)

    for q in all_suffix:
        suffix = f'lagq{q:.0f}'
        # PosTor = tor if tor>0
        PosTor = model.parse_expr(f'FILTER(tor_{suffix}, GREATER(tor_{suffix},0))')
        model.add_feature(ms.Feature(model, name=f"PosTor_{suffix}", calculator=PosTor))
        
        margin = model.parse_expr(f"WINSOR(DIV(np_{suffix},PosTor_{suffix}), -1,1)")
        model.add_feature(ms.Feature(model, name=f"npmargin_{suffix}", calculator=margin))
        
        PosTorraw = model.parse_expr(f'FILTER(raw_tor_{suffix}, GREATER(raw_tor_{suffix},0))')
        model.add_feature(ms.Feature(model, name=f"raw_PosTor_{suffix}", calculator=PosTorraw))
        
        PosToc = model.parse_expr(f'FILTER(toc_{suffix}, GREATER(toc_{suffix},0))')
        model.add_feature(ms.Feature(model, name=f"PosToc_{suffix}", calculator=PosToc))

        # 资产减值损失有的公司不会列出，建议fillna
        AstDevol = model.parse_expr(f'FILLNA(toc13_{suffix}, 0)')
        model.add_feature(ms.Feature(model, name=f"AstDevol_{suffix}", calculator=AstDevol))
        
        GPmargin = model.parse_expr(f"WINSOR(DIV(SUB(tor_{suffix},SUB(toc_{suffix}, AstDevol_{suffix})), FILTER(PosTor_{suffix}, GREATER(SUB(toc_{suffix}, AstDevol_{suffix}),0)) ), -1,1)")
        model.add_feature(ms.Feature(model, name=f"GPmargin_{suffix}", calculator=GPmargin))

        REC = model.parse_expr(f"ADD(FILLNA(ta_ca3_{suffix},0), FILLNA(ta_ca4_{suffix},0))")
        model.add_feature(ms.Feature(model, name=f"REC_{suffix}", calculator=REC))
        
        PAY = model.parse_expr(f"ADD(FILLNA(tl_cl4_{suffix},0), FILLNA(tl_cl5_{suffix},0))")
        model.add_feature(ms.Feature(model, name=f"PAY_{suffix}", calculator=PAY))

        ltdebt = model.parse_expr(f"ADD(FILLNA(tl_ncl1_{suffix},0), FILLNA(tl_ncl2_{suffix},0))")
        model.add_feature(ms.Feature(model, name=f"ltdebt_{suffix}", calculator=ltdebt))

        debt = model.parse_expr(f"ADD(FILLNA(tl_cl1_{suffix},0), ltdebt_{suffix})")
        model.add_feature(ms.Feature(model, name=f"debt_{suffix}", calculator=debt))

        # # 无息流动负债
        # nonitSTdebt = model.parse_expr(f"ADD(PAY_{suffix}, FILLNA(tl_cl6_{suffix},0)) , ADD(ADD(FILLNA(tl_cl9_{suffix},0),FILLNA(tl_cl10_{suffix},0)), FILLNA(tl_cl13_{suffix},0))")
        # model.add_feature(ms.Feature(model, name=f'STDnoit_{suffix}',calculator=nonitSTdebt))

        # # 无息非流动负债
        # nonitLTdebt = model.parse_expr(f"SUB(tl_ncl_{suffix}, ltdebt_{suffix})")
        # model.add_feature(ms.Feature(model, name=f'LTDnoit_{suffix}',calculator=nonitLTdebt))

        # TODO:有形资产=tse_parent - 无形资产ta_nca12 - 开发支出ta_nca13 - 商誉ta_nca14 - 长期待摊费用ta_nca15 - 递延所得税资产ta_nca16
        
        # INVCapital
        InvCapital = model.parse_expr(f"ADD(CEQ_{suffix}, debt_{suffix})")
        model.add_feature(ms.Feature(model, name=f'IC_{suffix}',calculator=InvCapital))


        SGA = model.parse_expr(f"ADD(ADD(FILLNA(toc10_{suffix},0),FILLNA(toc11_{suffix},0)), FILLNA(toc12_{suffix},0))")
        model.add_feature(ms.Feature(model, name=f"SGA_{suffix}", calculator=SGA))
        
        SGAraw = model.parse_expr(f"ADD(ADD(FILLNA(raw_toc10_{suffix},0),FILLNA(raw_toc11_{suffix},0)), FILLNA(raw_toc12_{suffix},0))")
        model.add_feature(ms.Feature(model, name=f"raw_SGA_{suffix}", calculator=SGAraw))
        
        cash = model.parse_expr(f'ADD(FILLNA(ta_ca1_{suffix},0), FILLNA(ta_ca2_{suffix},0))')
        model.add_feature(ms.Feature(model, name=f"cash_{suffix}", calculator=cash))

        noa = model.parse_expr(f"SUB(SUB(ta_{suffix},cash_{suffix}), SUB(tl_{suffix},debt_{suffix}))")
        model.add_feature(ms.Feature(model, name=f"noa_{suffix}", calculator=noa))

        nopat = model.parse_expr(f"MUL(ebit_{suffix}, DIV(np_{suffix},tp_{suffix}) )")
        model.add_feature(ms.Feature(model, name=f"nopat_{suffix}", calculator=nopat))
        
        nopatraw = model.parse_expr(f"MUL(raw_ebit_{suffix}, DIV(raw_np_{suffix},raw_tp_{suffix}) )")
        model.add_feature(ms.Feature(model, name=f"raw_nopat_{suffix}", calculator=nopatraw))

        gp = model.parse_expr(f"SUB(tor1_{suffix},toc1_{suffix})")
        model.add_feature(ms.Feature(model, name=f"gp_{suffix}", calculator=gp))

        gpraw = model.parse_expr(f"SUB(raw_tor1_{suffix},raw_toc1_{suffix})")
        model.add_feature(ms.Feature(model, name=f"raw_gp_{suffix}", calculator=gpraw))
        
        # DA
        rawDA = model.parse_expr(f"FILTER(SUB(raw_ebitda_{suffix}, raw_ebit_{suffix}),NOTEQUAL(raw_ebitda_{suffix},raw_ebit_{suffix}))")
        model.add_feature(ms.Feature(model, name=f"raw_DA_{suffix}", calculator=rawDA))

        DA = model.parse_expr(f"FSINGLE('raw_DA', {q})")
        model.add_feature(ms.Feature(model, name=f"DA_{suffix}", calculator=DA))  

        DA1 = model.parse_expr(f"FILLNA(FILLNA(DA_{suffix}, FMEAN('DA',{q},4)),0)") # fill na of DA with latest 1y mean
        model.add_feature(ms.Feature(model, name=f"DA1_{suffix}", calculator=DA1)) 

        EBITDA = model.parse_expr(f"ADD(ebit_{suffix},DA1_{suffix})") 
        model.add_feature(ms.Feature(model, name=f"EBITDA_{suffix}", calculator=EBITDA))

        # Cash Flow
        FCFcf = model.parse_expr(f"SUB(SUB(ncf_oa_{suffix}, CAPEX_{suffix}),FILLNA(ncf_fa22_{suffix},0))")
        model.add_feature(ms.Feature(model, name=f"FCFcf_{suffix}", calculator=FCFcf))
        
        FCFcfraw = model.parse_expr(f"SUB(SUB(raw_ncf_oa_{suffix}, raw_CAPEX_{suffix}),FILLNA(raw_ncf_fa22_{suffix},0))")
        model.add_feature(ms.Feature(model, name=f"raw_FCFcf_{suffix}", calculator=FCFcfraw))
        
        FCFic = model.parse_expr(f"ADD(SUB(np_{suffix}, CAPEX_{suffix}),DA1_{suffix})")
        model.add_feature(ms.Feature(model, name=f"FCFic_{suffix}", calculator=FCFic))

        CF = model.parse_expr(f"ADD(np_exeal_{suffix},DA1_{suffix})")
        model.add_feature(ms.Feature(model, name=f"CF_{suffix}", calculator=CF))
        
        fdmtlshare = model.parse_expr(f'DIV(tse_pa5_{suffix}, FILTER(cr_ps_{suffix},GREATER(cr_ps_{suffix},0)))')
        model.add_feature(ms.Feature(model, name=f"fdmtlshare1_{suffix}", calculator=fdmtlshare))
        
        fdmtlshare = model.parse_expr(f'FILLNA(fdmtlshare1_{suffix}, DIV(raw_ncf_{suffix}, raw_ncf_ps_{suffix}))')
        model.add_feature(ms.Feature(model, name=f"fdmtlshare_{suffix}", calculator=fdmtlshare))

        GF = model.parse_expr(f"ADD(np_exeal_{suffix},ADD(FILLNA(ta_nca13_{suffix},0),FILLNA(toc14_{suffix},0)))")
        model.add_feature(ms.Feature(model, name=f"GF_{suffix}", calculator=GF))


    circMV = model.parse_expr(f"MUL(da_circ_share, da_close)")
    model.add_feature(ms.Feature(model, name="circMV", calculator=circMV))
    
    totMV = model.parse_expr("MUL(da_tot_share, da_close)")
    model.add_feature(ms.Feature(model, name="totMV", calculator=totMV))
    
    EV1 = model.parse_expr(f"SUB(ADD(ADD(debt_lagq0,MAX(tse_pa3_lagq0,0)),MAX(tse_monority_lagq0,0)),cash_lagq0)")
    model.add_feature(ms.Feature(model, name=f"EV1", calculator=EV1))

    EV2 = model.parse_expr(f"ADD(FILLNA(tl_ncl1_lagq0,0),FILLNA(tl_ncl2_lagq0,0))")
    model.add_feature(ms.Feature(model, name=f"EV2", calculator=EV2))
    # 760h      银行,   760i    非银金融
    EV = model.parse_expr(f"FILLNA(FILTER(EV2, EQUAL(ADD(sw2021_760h,sw2021_760i), 1)), EV1)")
    model.add_feature(ms.Feature(model, name=f"EV0", calculator=EV))
    
    EVc = model.parse_expr(f"ADD(circMV,EV0)")
    model.add_feature(ms.Feature(model, name=f"EVc", calculator=EVc))

    EVc = model.parse_expr(f"ADD(totMV,EV0)")
    model.add_feature(ms.Feature(model, name=f"EV", calculator=EVc))


    # normalizer
    NOA2yAvg = model.parse_expr(f"FMEAN('noa',0,8)")
    model.add_feature(ms.Feature(model, name=f"NOA2yAvg", calculator=NOA2yAvg))

    AT1yAvg = model.parse_expr(f"FMEAN('ta',0,4)")
    model.add_feature(ms.Feature(model, name=f"AT1yAvg", calculator=AT1yAvg))
    
    AT1yAvg_l1y = model.parse_expr(f"FMEAN('ta',4,4)")
    model.add_feature(ms.Feature(model, name=f"AT1yAvg_l1y", calculator=AT1yAvg_l1y))
    
    sale1y = model.parse_expr(f"TTM('tor',0)")
    model.add_feature(ms.Feature(model, name=f"sale1y", calculator=sale1y))

    PosSale1y = model.parse_expr(f"FILTER(TTM('tor',0), GREATER(TTM('tor',0),0)) ")
    model.add_feature(ms.Feature(model, name=f"PosSale1y", calculator=PosSale1y))
    
    PosSale1y_l1y = model.parse_expr(f"FILTER(TTM('tor',4), GREATER(TTM('tor',4),0)) ")
    model.add_feature(ms.Feature(model, name=f"PosSale1y_l1y", calculator=PosSale1y_l1y))


    CE1yAvg = model.parse_expr(f"FMEAN('CEQ',0,4)")
    model.add_feature(ms.Feature(model, name=f"CE1yAvg", calculator=CE1yAvg))
    
    CE1yAvg_l1y = model.parse_expr(f"FMEAN('CEQ',4,4)")
    model.add_feature(ms.Feature(model, name=f"CE1yAvg_l1y", calculator=CE1yAvg_l1y))

    debt1yAvg = model.parse_expr(f"FMEAN('debt',4,4)")
    model.add_feature(ms.Feature(model, name=f"debt1yAvg", calculator=debt1yAvg))

    # InvCap1yAvg = model.parse_expr(f"ADD(debt1yAvg, CE1yAvg)")
    # model.add_feature(ms.Feature(model, name=f"InvCap1yAvg", calculator=InvCap1yAvg))
    
def add_fin_rept_nlag(model):
    model.add_sdiv_features(f'/data/nas2Data/chinaEquityData/yuting/data/FB/staging/fin_rpts_nlag/YYYYMMDD.sdiv')

