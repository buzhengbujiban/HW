# import os

# for f in [i for i in os.listdir(os.path.dirname(__file__))]:
#     if "__" not in f and f.endswith("py"):
#         exec(f"import alpha.closures.{f[:-3]}")

import alpha_ca.closures.tec
import alpha_ca.closures.bop
import alpha_ca.closures.grp
import alpha_ca.closures.mms
import alpha_ca.closures.pvc
import alpha_ca.closures.atc
import alpha_ca.closures.liq
import alpha_ca.closures.std
import alpha_ca.closures.tss
import alpha_ca.closures.xss
import alpha_ca.closures.reg
import alpha_ca.closures.mpv
import alpha_ca.closures.upd
import alpha_ca.closures.piv
import alpha_ca.closures.ovn
