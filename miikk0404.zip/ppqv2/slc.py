from canopus_py.ca_expr import ca
from pqsum_py.utils import *
# from alpha_pq.pq_label import PQLabel
from alpha_pq.utils import *
import alpha_ca.closures

class TERMS:
    @staticmethod
    def pq_sum(ctx, pattern, short_terms=False):
        result = {}
        p1_labels = get_labels_by_pow(pattern, "p1")
        for p1_label in p1_labels:
            pq_label_b = PQLabel.from_label(p1_label)
            pq_label_s = pq_label_b.new_s_label("S")

            pq_label_b_all = pq_label_b.new_ft_label("all")
            pq_label_s_all = pq_label_s.new_ft_label("all")

            assert pq_label_b.s in "BS"
            if pq_label_b.s != "B":
                continue
            b_sum_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1d"], rpii=1)
            b_sum_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"], rpii=1)
            # b_sum_5d = ca.TsSum(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1d"]*5, rpii=5)

            s_sum_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1d"], rpii=1)
            s_sum_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"], rpii=1)
            # s_sum_5d = ca.TsSum(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1d"]*5, rpii=5)

            b_all_sum_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_all.to_str())), ctx["TIME.1d"], rpii=1)
            b_all_sum_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_all.to_str())), ctx["TIME.1h"], rpii=1)
            b_all_sum_5d = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_all.to_str())), ctx["TIME.1d"]*5, rpii=5)

            s_all_sum_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_all.to_str())), ctx["TIME.1d"], rpii=1)
            s_all_sum_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_all.to_str())), ctx["TIME.1h"], rpii=1)
            s_all_sum_5d = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_all.to_str())), ctx["TIME.1d"]*5, rpii=5)

            # bs_sum_5d = b_sum_5d + s_sum_5d
            bs_all_sum_1d = b_all_sum_1d + s_all_sum_1d
            bs_all_sum_5d = b_all_sum_5d + s_all_sum_5d
            
            bs_ratio_1h = (b_sum_1h - s_sum_1h)/(b_sum_1h + s_sum_1h)
            bs_ratio_1d = (b_sum_1d - s_sum_1d)/(b_sum_1d + s_sum_1d)

            bs_ratio_all_1h = (b_all_sum_1h - s_all_sum_1h)/(b_all_sum_1h + s_all_sum_1h)
            bs_ratio_all_1d = (b_all_sum_1d - s_all_sum_1d)/(b_all_sum_1d + s_all_sum_1d)
            if not short_terms:
                result["bsrt_1h."+pq_label_b.to_short_str()] = ca.RegRes(bs_ratio_1h, bs_ratio_all_1h, w=ctx["xs_reg_wgt"])
                result["bsrt_1d."+pq_label_b.to_short_str()] = ca.RegRes(bs_ratio_1d, bs_ratio_all_1d, w=ctx["xs_reg_wgt"])

                result["bsdf_1h."+pq_label_b.to_short_str()] = b_sum_1h - s_sum_1h
                result["bsdf_1d."+pq_label_b.to_short_str()] = b_sum_1d - s_sum_1d

                result["bsdfir_1h."+pq_label_b.to_short_str()] = (b_sum_1h - s_sum_1h)/ca.C(ctx["TIME.1h"])/ca.TsStd(ca.Na20(pq_label_b.to_str())-ca.Na20(pq_label_s.to_str()), ctx["TIME.1h"], rpii=1)
                result["bsdfir_1d."+pq_label_b.to_short_str()] = (b_sum_1d - s_sum_1d)/ca.C(ctx["TIME.1d"]*5)/ca.TsStd(ca.Na20(pq_label_b.to_str())-ca.Na20(pq_label_s.to_str()), ctx["TIME.1d"], rpii=1)

                result["bsdfn_1h."+pq_label_b.to_short_str()] = (b_sum_1h - s_sum_1h)/bs_all_sum_5d
                result["bsdfn_1d."+pq_label_b.to_short_str()] = (b_sum_1d - s_sum_1d)/bs_all_sum_5d

                result["bssmn_1h."+pq_label_b.to_short_str()] = (b_sum_1h + s_sum_1h)/bs_all_sum_5d
                result["bssmn_1d."+pq_label_b.to_short_str()] = (b_sum_1d + s_sum_1d)/bs_all_sum_5d

                result["bsreg_1h."+pq_label_b.to_short_str()] = ca.RegRes((b_sum_1h/bs_all_sum_5d), (s_sum_1h/bs_all_sum_5d), w=ctx["xs_reg_wgt"])
                result["bsreg_1d."+pq_label_b.to_short_str()] = ca.RegRes((b_sum_1d/bs_all_sum_5d), (s_sum_1d/bs_all_sum_5d), w=ctx["xs_reg_wgt"])

                result["sbreg_1h."+pq_label_b.to_short_str()] = ca.RegRes((s_sum_1h/bs_all_sum_5d), (b_sum_1h/bs_all_sum_5d), w=ctx["xs_reg_wgt"])
                result["sbreg_1d."+pq_label_b.to_short_str()] = ca.RegRes((s_sum_1d/bs_all_sum_5d), (b_sum_1d/bs_all_sum_5d), w=ctx["xs_reg_wgt"])
            else:
                result["bsrt_1h."+pq_label_b.to_short_str()] = ca.RegRes(bs_ratio_1h, bs_ratio_all_1h, w=ctx["xs_reg_wgt"])
                result["bsdf_1h."+pq_label_b.to_short_str()] = b_sum_1h - s_sum_1h
                result["bsdfir_1h."+pq_label_b.to_short_str()] = (b_sum_1h - s_sum_1h)/ca.C(ctx["TIME.1h"])/ca.TsStd(ca.Na20(pq_label_b.to_str())-ca.Na20(pq_label_s.to_str()), ctx["TIME.1h"], rpii=1)
                result["bsdfn_1h."+pq_label_b.to_short_str()] = (b_sum_1h - s_sum_1h)/bs_all_sum_1d
                result["bssmn_1h."+pq_label_b.to_short_str()] = (b_sum_1h + s_sum_1h)/bs_all_sum_1d
                result["bsreg_1h."+pq_label_b.to_short_str()] = ca.RegRes((b_sum_1h/bs_all_sum_1d), (s_sum_1h/bs_all_sum_1d), w=ctx["xs_reg_wgt"])
                result["sbreg_1h."+pq_label_b.to_short_str()] = ca.RegRes((s_sum_1h/bs_all_sum_1d), (b_sum_1h/bs_all_sum_1d), w=ctx["xs_reg_wgt"])

        return result

    @staticmethod
    def pq_mean(ctx, pattern, short_terms=False):
        result = {}
        p1_labels = get_labels_by_pow(pattern, "p1")
        def get_mean_stats(pq_label_b):
            # pq_label_b = PQLabel.from_label(p1_label)
            pq_label_s = pq_label_b.new_s_label("S")

            pq_label_b_cnt = pq_label_b.new_pq_label("c")
            pq_label_s_cnt = pq_label_s.new_pq_label("c")

            assert pq_label_b.s in "BS"


            b_mean = ca.Diff(pq_label_b.to_str())/ca.Diff(pq_label_b_cnt.to_str())
            s_mean = ca.Diff(pq_label_s.to_str())/ca.Diff(pq_label_s_cnt.to_str())

            b_sum_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1d"], rpii=1)
            b_sum_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"], rpii=1)
            b_cnt_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_cnt.to_str())), ctx["TIME.1d"], rpii=1)
            b_cnt_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_cnt.to_str())), ctx["TIME.1h"], rpii=1)

            s_sum_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1d"], rpii=1)
            s_sum_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"], rpii=1)
            s_cnt_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_cnt.to_str())), ctx["TIME.1d"], rpii=1)
            s_cnt_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_cnt.to_str())), ctx["TIME.1h"], rpii=1)

            bs_imba = ca.Na20(b_mean - s_mean)
            b_mean_1d = b_sum_1d / b_cnt_1d
            b_mean_1h = b_sum_1h / b_cnt_1h
            s_mean_1d = s_sum_1d / s_cnt_1d
            s_mean_1h = s_sum_1h / s_cnt_1h
            a_mean_1d = (b_sum_1d+s_sum_1d) / (b_cnt_1d+s_cnt_1d)
            a_mean_1h = (b_sum_1h+s_sum_1h) / (b_cnt_1h+s_cnt_1h)

            return bs_imba,b_mean_1d,b_mean_1h,s_mean_1d,s_mean_1h,a_mean_1d,a_mean_1h

        for p1_label in p1_labels:
            pq_label_b = PQLabel.from_label(p1_label)
            if pq_label_b.s != "B":
                continue
            bs_imba,b_mean_1d,b_mean_1h,\
                s_mean_1d,s_mean_1h,a_mean_1d,a_mean_1h = get_mean_stats(PQLabel.from_label(p1_label))
            _,b_mean_1d_all,b_mean_1h_all,\
                s_mean_1d_all,s_mean_1h_all,a_mean_1d_all,a_mean_1h_all = get_mean_stats(PQLabel.from_label(p1_label).new_ft_label("all"))

            b_1h_res = ca.RegRes(b_mean_1h, b_mean_1h_all, w=ctx["xs_reg_wgt"])
            b_1d_res = ca.RegRes(b_mean_1d, b_mean_1d_all, w=ctx["xs_reg_wgt"])
            s_1h_res = ca.RegRes(s_mean_1h, s_mean_1h_all, w=ctx["xs_reg_wgt"])
            s_1d_res = ca.RegRes(s_mean_1d, s_mean_1d_all, w=ctx["xs_reg_wgt"])
            a_1h_res = ca.RegRes(a_mean_1h, a_mean_1h_all, w=ctx["xs_reg_wgt"])
            a_1d_res = ca.RegRes(a_mean_1d, a_mean_1d_all, w=ctx["xs_reg_wgt"])

            result["mn_a_tsd_1h1d."+pq_label_b.to_short_str()] = a_mean_1h-a_mean_1d

            result["mn_bsreg_1h."+pq_label_b.to_short_str()] = ca.RegRes(b_mean_1h, s_mean_1h, w=ctx["xs_reg_wgt"])
            result["mn_sbreg_1h."+pq_label_b.to_short_str()] = ca.RegRes(s_mean_1h, b_mean_1h, w=ctx["xs_reg_wgt"])
            result["mn_ib_zs_1h."+pq_label_b.to_short_str()] = (bs_imba - ca.TsMean(bs_imba, ctx["TIME.1h"], rpii=1)) / ca.TsStd(bs_imba, ctx["TIME.1h"], rpii=1)
            result["mn_ib_ir_1h."+pq_label_b.to_short_str()] = (ca.TsMean(bs_imba, ctx["TIME.1h"], rpii=1)) / ca.TsStd(bs_imba, ctx["TIME.1h"], rpii=1)
            result["mn_a_1h_res."+pq_label_b.to_short_str()] = a_1h_res
            result["mn_ib_1h_res."+pq_label_b.to_short_str()] = b_1h_res-s_1h_res

            if not short_terms:
                result["mn_bsreg_1d."+pq_label_b.to_short_str()] = ca.RegRes(s_mean_1d, b_mean_1d, w=ctx["xs_reg_wgt"])
                result["mn_sbreg_1d."+pq_label_b.to_short_str()] = ca.RegRes(s_mean_1d, b_mean_1d, w=ctx["xs_reg_wgt"])
                result["mn_ib_zs_1d."+pq_label_b.to_short_str()] = (bs_imba - ca.TsMean(bs_imba, ctx["TIME.1d"], rpii=1)) / ca.TsStd(bs_imba, ctx["TIME.1d"], rpii=1)
                result["mn_ib_ir_1d."+pq_label_b.to_short_str()] = (ca.TsMean(bs_imba, ctx["TIME.1d"], rpii=1)) / ca.TsStd(bs_imba, ctx["TIME.1d"], rpii=1)
                result["mn_a_1d_res."+pq_label_b.to_short_str()] = a_1d_res
                result["mn_ib_1d_res."+pq_label_b.to_short_str()] = b_1d_res-s_1d_res

        return result

    @staticmethod
    def pq_std(ctx, pattern, short_terms=False):
        result = {}
        p2_labels = get_labels_by_pow(pattern, "p2")
        def get_std_stats(pq_label_b):
            assert pq_label_b.s in "BS"
            # pq_label_b = PQLabel.from_label(p1_label)
            pq_label_s = pq_label_b.new_s_label("S")

            pq_label_b_cnt = pq_label_b.new_pq_label("c").new_p_label("p1")
            pq_label_s_cnt = pq_label_s.new_pq_label("c").new_p_label("p1")

            pq_label_b_sum = pq_label_b.new_p_label("p1")
            pq_label_s_sum = pq_label_s.new_p_label("p1")

            pq_label_b_ssq = pq_label_b
            pq_label_s_ssq = pq_label_s

            b_cnt_5m = ca.Na20(ca.Diff(pq_label_b_cnt))
            s_cnt_5m = ca.Na20(ca.Diff(pq_label_s_cnt))
            a_cnt_5m = b_cnt_5m + s_cnt_5m

            b_sum_5m = ca.Na20(ca.Diff(pq_label_b_sum))
            s_sum_5m = ca.Na20(ca.Diff(pq_label_s_sum))
            a_sum_5m = b_sum_5m + s_sum_5m

            b_ssq_5m = ca.Na20(ca.Diff(pq_label_b_ssq))
            s_ssq_5m = ca.Na20(ca.Diff(pq_label_s_ssq))
            a_ssq_5m = b_ssq_5m + s_ssq_5m

            b_cnt_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_cnt)), ctx["TIME.1h"], rpii=1)
            s_cnt_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_cnt)), ctx["TIME.1h"], rpii=1)
            a_cnt_1h = b_cnt_1h + s_cnt_1h

            b_sum_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_sum)), ctx["TIME.1h"], rpii=1)
            s_sum_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_sum)), ctx["TIME.1h"], rpii=1)
            a_sum_1h = b_sum_1h + s_sum_1h

            b_ssq_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_ssq)), ctx["TIME.1h"], rpii=1)
            s_ssq_1h = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_ssq)), ctx["TIME.1h"], rpii=1)
            a_ssq_1h = b_ssq_1h + s_ssq_1h

            b_cnt_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_cnt)), ctx["TIME.1d"], rpii=1)
            s_cnt_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_cnt)), ctx["TIME.1d"], rpii=1)
            a_cnt_1d = b_cnt_1d + s_cnt_1d

            b_sum_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_sum)), ctx["TIME.1d"], rpii=1)
            s_sum_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_sum)), ctx["TIME.1d"], rpii=1)
            a_sum_1d = b_sum_1d + s_sum_1d

            b_ssq_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_ssq)), ctx["TIME.1d"], rpii=1)
            s_ssq_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_ssq)), ctx["TIME.1d"], rpii=1)
            a_ssq_1d = b_ssq_1d + s_ssq_1d

            std_a_1h = ca.NumPow(a_ssq_1h/a_cnt_1h - (a_sum_1h/a_cnt_1h)*(a_sum_1h/a_cnt_1h), 0.5)
            std_a_1d = ca.NumPow(a_ssq_1d/a_cnt_1d - (a_sum_1d/a_cnt_1d)*(a_sum_1d/a_cnt_1d), 0.5)
            std_b_1h = ca.NumPow(b_ssq_1h/b_cnt_1h - (b_sum_1h/b_cnt_1h)*(b_sum_1h/b_cnt_1h), 0.5)
            std_b_1d = ca.NumPow(b_ssq_1d/b_cnt_1d - (b_sum_1d/b_cnt_1d)*(b_sum_1d/b_cnt_1d), 0.5)
            std_s_1h = ca.NumPow(s_ssq_1h/s_cnt_1h - (s_sum_1h/s_cnt_1h)*(s_sum_1h/s_cnt_1h), 0.5)
            std_s_1d = ca.NumPow(s_ssq_1d/s_cnt_1d - (s_sum_1d/s_cnt_1d)*(s_sum_1d/s_cnt_1d), 0.5)
            std_b_5m = ca.NumPow(b_ssq_5m/b_cnt_5m - (b_sum_5m/b_cnt_5m)*(b_sum_5m/b_cnt_5m), 0.5)
            std_s_5m = ca.NumPow(s_ssq_5m/s_cnt_5m - (s_sum_5m/s_cnt_5m)*(s_sum_5m/s_cnt_5m), 0.5)

            return std_a_1h,std_a_1d,std_b_1h,std_b_1d,std_s_1h,std_s_1d,std_b_5m,std_s_5m
        for p2_label in p2_labels:
            pq_label_b = PQLabel.from_label(p2_label)
            std_a_1h,std_a_1d,std_b_1h,std_b_1d,std_s_1h,std_s_1d,std_b_5m,std_s_5m = get_std_stats(PQLabel.from_label(p2_label))
            std_a_1h_all,std_a_1d_all,std_b_1h_all,std_b_1d_all,std_s_1h_all,std_s_1d_all,std_b_5m_all,std_s_5m_all = get_std_stats(PQLabel.from_label(p2_label).new_ft_label("all"))

            b_1h_res = ca.RegRes(std_b_1h, std_b_1h_all, w=ctx["xs_reg_wgt"])
            b_1d_res = ca.RegRes(std_b_1d, std_b_1d_all, w=ctx["xs_reg_wgt"])
            s_1h_res = ca.RegRes(std_s_1h, std_s_1h_all, w=ctx["xs_reg_wgt"])
            s_1d_res = ca.RegRes(std_s_1d, std_s_1d_all, w=ctx["xs_reg_wgt"])
            a_1h_res = ca.RegRes(std_a_1h, std_a_1h_all, w=ctx["xs_reg_wgt"])
            a_1d_res = ca.RegRes(std_a_1d, std_a_1d_all, w=ctx["xs_reg_wgt"])

            result["std_a_1h1d."+pq_label_b.to_short_str()] = std_a_1h-std_a_1d
            result["std_a_1h."+pq_label_b.to_short_str()] = std_a_1h
            result["std_ib_1h."+pq_label_b.to_short_str()] = std_b_1h - std_s_1h
            result["std_ib_zs_1h."+pq_label_b.to_short_str()] = ((std_b_5m-std_s_5m) - ca.TsMean((std_b_5m-std_s_5m), ctx["TIME.1h"], rpii=1)) / ca.TsStd((std_b_5m-std_s_5m), ctx["TIME.1h"], rpii=1)
            result["std_bsreg_1h."+pq_label_b.to_short_str()] = ca.RegRes(std_b_1h, std_s_1h, w=ctx["xs_reg_wgt"])
            result["std_sbreg_1h."+pq_label_b.to_short_str()] = ca.RegRes(std_s_1h, std_b_1h, w=ctx["xs_reg_wgt"])
            result["std_a_1h_res."+pq_label_b.to_short_str()] = a_1h_res
            result["std_ib_1h_res."+pq_label_b.to_short_str()] = b_1h_res-s_1h_res

            if not short_terms:
                result["std_a_1d."+pq_label_b.to_short_str()] = std_a_1d
                result["std_ib_1d."+pq_label_b.to_short_str()] = std_b_1d - std_s_1d
                result["std_ib_zs_1d."+pq_label_b.to_short_str()] = ((std_b_5m-std_s_5m) - ca.TsMean((std_b_5m-std_s_5m), ctx["TIME.1d"], rpii=1)) / ca.TsStd((std_b_5m-std_s_5m), ctx["TIME.1d"], rpii=1)
                result["std_bsreg_1d."+pq_label_b.to_short_str()] = ca.RegRes(std_b_1d, std_s_1d, w=ctx["xs_reg_wgt"])
                result["std_sbreg_1d."+pq_label_b.to_short_str()] = ca.RegRes(std_s_1d, std_b_1d, w=ctx["xs_reg_wgt"])
                result["std_a_1d_res."+pq_label_b.to_short_str()] = a_1d_res
                result["std_ib_1d_res."+pq_label_b.to_short_str()] = b_1d_res-s_1d_res
        return result

    @staticmethod
    def pq_ema_tp(ctx, pattern, tproxy_label=None):
        result = {}
        p1_labels = get_labels_by_pow(pattern, "p1")
        for p1_label in p1_labels:
            # if not str(p1_label).endswith("MTS.c.p1"):
            #     continue
            pq_label_b = PQLabel.from_label(p1_label)
            pq_label_s = pq_label_b.new_s_label("S")

            pq_label_b_all = pq_label_b.new_ft_label("all")
            pq_label_s_all = pq_label_s.new_ft_label("all")

            assert pq_label_b.s in "BS"
            if pq_label_b.s != "B":
                continue
            
            day_tp = ca.C(48)
            tproxy = ca.DayAccum(ca.Na20(ca.C(1)/day_tp) , -1)

            b_ema_30m = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            # b_ema_1h = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            b_ema_2h = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]*2/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            s_ema_30m = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            # s_ema_1h = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            s_ema_2h = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]*2/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)

            
            # b_ems_30m = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            b_ems_1h = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            # b_ems_2h = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]*2/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            # s_ems_30m = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            s_ems_1h = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            # s_ems_2h = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]*2/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)

            b_all = ca.Na20(ca.Diff(pq_label_b_all.to_str()))
            s_all = ca.Na20(ca.Diff(pq_label_s_all.to_str()))
            bs_all_ema_1d = ca.Ema(b_all+s_all, ctx["TIME.1d"], rpii=1)

            if tproxy_label is not None:
                day_tp = ca.TsMean(ca.Na20(tproxy_label.replace(".5m.", ".eod.")), 5, d_mode=True)
                tproxy = ca.DayAccum(ca.Na20(ca.Diff(tproxy_label)/day_tp) , -1)

                b_ema_30m = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                # b_ema_1h = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                b_ema_2h = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), 1, time_proxy=tproxy, rpii=1)
                s_ema_30m = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                # s_ema_1h = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                s_ema_2h = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), 1, time_proxy=tproxy, rpii=1)

                # b_ems_30m = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                b_ems_1h = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                # b_ems_2h = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), 1, time_proxy=tproxy, rpii=1)
                # s_ems_30m = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                s_ems_1h = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                # s_ems_2h = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), 1, time_proxy=tproxy, rpii=1)
            
                bs_all_ema_1d = ca.Ema(b_all+s_all, 1, time_proxy=tproxy, rpii=1)

            # tp_1d = tproxy / day_tp
            
            b_ead = ca.Na20(b_ema_30m)-ca.Na20(b_ema_2h)
            s_ead = ca.Na20(s_ema_30m)-ca.Na20(s_ema_2h)
            b_ems = ca.Na20(b_ems_1h)
            s_ems = ca.Na20(s_ems_1h)

            bs_ead_diff = b_ead - s_ead
            bs_ems_diff = b_ems - s_ems

            bs_ead_ratio = (b_ead - s_ead)/bs_all_ema_1d
            bs_ems_ratio = (b_ems - s_ems)/bs_all_ema_1d

            tproxy_label_short = "t"
            if tproxy_label is not None:
                tproxy_label_short = tproxy_label.replace("tproxy.5m.", "").replace(".p1", "")

            result[f"eadd.{tproxy_label_short}."+pq_label_b.to_short_str()] = bs_ead_diff
            result[f"emsd.{tproxy_label_short}."+pq_label_b.to_short_str()] = bs_ems_diff

            result[f"eadr.{tproxy_label_short}."+pq_label_b.to_short_str()] = bs_ead_ratio
            result[f"emsr.{tproxy_label_short}."+pq_label_b.to_short_str()] = bs_ems_ratio

            result[f"bsreg_ea.{tproxy_label_short}."+pq_label_b.to_short_str()] = ca.RegRes(b_ead, s_ead, w=ctx["xs_reg_wgt"])
            result[f"bsreg_es.{tproxy_label_short}."+pq_label_b.to_short_str()] = ca.RegRes(b_ems, s_ems, w=ctx["xs_reg_wgt"])

            result[f"sbreg_ea.{tproxy_label_short}."+pq_label_b.to_short_str()] = ca.RegRes(s_ead, b_ead, w=ctx["xs_reg_wgt"])
            result[f"sbreg_es.{tproxy_label_short}."+pq_label_b.to_short_str()] = ca.RegRes(s_ems, b_ems, w=ctx["xs_reg_wgt"])

            result[f"b_ead.{tproxy_label_short}."+pq_label_b.to_short_str()] = b_ead
            result[f"s_ead.{tproxy_label_short}."+pq_label_b.to_short_str()] = s_ead
            result[f"b_ems.{tproxy_label_short}."+pq_label_b.to_short_str()] = b_ems
            result[f"s_ems.{tproxy_label_short}."+pq_label_b.to_short_str()] = s_ems
            # result[f"b_ems_old.{tproxy_label_short}."+pq_label_b.to_short_str()] = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"], rpii=1)
            # result["tproxy"] = tproxy

        result = alpha_ca.closures.bop.rdcp(result, lite=True, reg_wgt=ctx["xs_reg_wgt"])
        return result

    @staticmethod
    def pq_ema_tp(ctx, pattern, tproxy_label=None):
        result = {}
        p1_labels = get_labels_by_pow(pattern, "p1")
        for p1_label in p1_labels:
            # if not str(p1_label).endswith("MTS.c.p1"):
            #     continue
            pq_label_b = PQLabel.from_label(p1_label)
            pq_label_s = pq_label_b.new_s_label("S")

            pq_label_b_all = pq_label_b.new_ft_label("all")
            pq_label_s_all = pq_label_s.new_ft_label("all")

            assert pq_label_b.s in "BS"
            if pq_label_b.s != "B":
                continue
            
            day_tp = ca.C(48)
            tproxy = ca.DayAccum(ca.Na20(ca.C(1)/day_tp) , -1)

            b_ema_30m = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            # b_ema_1h = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            b_ema_2h = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]*2/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            s_ema_30m = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            # s_ema_1h = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            s_ema_2h = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]*2/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)

            
            # b_ems_30m = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            b_ems_1h = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            # b_ems_2h = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]*2/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            # s_ems_30m = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            s_ems_1h = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
            # s_ems_2h = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]*2/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)

            b_all = ca.Na20(ca.Diff(pq_label_b_all.to_str()))
            s_all = ca.Na20(ca.Diff(pq_label_s_all.to_str()))
            bs_all_ema_1d = ca.Ema(b_all+s_all, ctx["TIME.1d"], rpii=1)

            if tproxy_label is not None:
                day_tp = ca.TsMean(ca.Na20(tproxy_label.replace(".5m.", ".eod.").replace(".1m.", ".eod.")), 5, d_mode=True)
                tproxy = ca.DayAccum(ca.Na20(ca.Diff(tproxy_label)/day_tp) , -1)

                b_ema_30m = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                # b_ema_1h = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                b_ema_2h = ca.Ema(ca.Na20(ca.Diff(pq_label_b.to_str())), 1, time_proxy=tproxy, rpii=1)
                s_ema_30m = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                # s_ema_1h = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                s_ema_2h = ca.Ema(ca.Na20(ca.Diff(pq_label_s.to_str())), 1, time_proxy=tproxy, rpii=1)

                # b_ems_30m = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                b_ems_1h = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                # b_ems_2h = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), 1, time_proxy=tproxy, rpii=1)
                # s_ems_30m = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.hh"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                s_ems_1h = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), ctx["TIME.1h"]/ctx["TIME.1d"], time_proxy=tproxy, rpii=1)
                # s_ems_2h = ca.Ems(ca.Na20(ca.Diff(pq_label_s.to_str())), 1, time_proxy=tproxy, rpii=1)
            
                bs_all_ema_1d = ca.Ema(b_all+s_all, 1, time_proxy=tproxy, rpii=1)

            # tp_1d = tproxy / day_tp
            
            b_ead = ca.Na20(b_ema_30m)-ca.Na20(b_ema_2h)
            s_ead = ca.Na20(s_ema_30m)-ca.Na20(s_ema_2h)
            b_ems = ca.Na20(b_ems_1h)
            s_ems = ca.Na20(s_ems_1h)

            bs_ead_diff = b_ead - s_ead
            bs_ems_diff = b_ems - s_ems

            bs_ead_ratio = (b_ead - s_ead)/bs_all_ema_1d
            bs_ems_ratio = (b_ems - s_ems)/bs_all_ema_1d

            tproxy_label_short = "t"
            if tproxy_label is not None:
                tproxy_label_short = tproxy_label.replace("tproxy.5m.", "").replace("tproxy.1m.", "").replace(".p1", "")

            result[f"eadd.{tproxy_label_short}."+pq_label_b.to_short_str()] = bs_ead_diff
            result[f"emsd.{tproxy_label_short}."+pq_label_b.to_short_str()] = bs_ems_diff

            result[f"eadr.{tproxy_label_short}."+pq_label_b.to_short_str()] = bs_ead_ratio
            result[f"emsr.{tproxy_label_short}."+pq_label_b.to_short_str()] = bs_ems_ratio

            result[f"bsreg_ea.{tproxy_label_short}."+pq_label_b.to_short_str()] = ca.RegRes(b_ead, s_ead, w=ctx["xs_reg_wgt"])
            result[f"bsreg_es.{tproxy_label_short}."+pq_label_b.to_short_str()] = ca.RegRes(b_ems, s_ems, w=ctx["xs_reg_wgt"])

            result[f"sbreg_ea.{tproxy_label_short}."+pq_label_b.to_short_str()] = ca.RegRes(s_ead, b_ead, w=ctx["xs_reg_wgt"])
            result[f"sbreg_es.{tproxy_label_short}."+pq_label_b.to_short_str()] = ca.RegRes(s_ems, b_ems, w=ctx["xs_reg_wgt"])

            result[f"b_ead.{tproxy_label_short}."+pq_label_b.to_short_str()] = b_ead
            result[f"s_ead.{tproxy_label_short}."+pq_label_b.to_short_str()] = s_ead
            result[f"b_ems.{tproxy_label_short}."+pq_label_b.to_short_str()] = b_ems
            result[f"s_ems.{tproxy_label_short}."+pq_label_b.to_short_str()] = s_ems
            # result[f"b_ems_old.{tproxy_label_short}."+pq_label_b.to_short_str()] = ca.Ems(ca.Na20(ca.Diff(pq_label_b.to_str())), ctx["TIME.1h"], rpii=1)
            # result["tproxy"] = tproxy

        result = alpha_ca.closures.bop.rdcp(result, lite=True, reg_wgt=ctx["xs_reg_wgt"])
        return result


    @staticmethod
    def pq_snap(ctx, pattern, short_terms=False):
        result = {}
        p1_labels = get_labels_by_pow(pattern, "p1")
        for p1_label in p1_labels:
            pq_label_b = PQLabel.from_label(p1_label)
            pq_label_s = pq_label_b.new_s_label("S")

            pq_label_b_all = pq_label_b.new_ft_label("all")
            pq_label_s_all = pq_label_s.new_ft_label("all")

            assert pq_label_b.s in "BS"
            if pq_label_b.s != "B":
                continue
            b_snap = ca.Na20(ca.Diff(pq_label_b.to_str()))
            s_snap = ca.Na20(ca.Diff(pq_label_s.to_str()))
            b_all_sum_5d = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_all.to_str())), ctx["TIME.1d"]*5, rpii=5)
            s_all_sum_5d = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_all.to_str())), ctx["TIME.1d"]*5, rpii=5)
            bs_all_sum_5d = b_all_sum_5d + s_all_sum_5d

            b_all_sum_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_b_all.to_str())), ctx["TIME.1d"], rpii=1)
            s_all_sum_1d = ca.TsSum(ca.Na20(ca.Diff(pq_label_s_all.to_str())), ctx["TIME.1d"], rpii=1)
            bs_all_sum_1d = b_all_sum_1d + s_all_sum_1d
            
            bs_ratio_snap = (b_snap - s_snap)/(b_snap + s_snap)
            result["bsr_sn."+pq_label_b.to_short_str()] = bs_ratio_snap
            result["bsdf_sn."+pq_label_b.to_short_str()] = b_snap - s_snap
            if not short_terms:
                result["bsdfn_sn."+pq_label_b.to_short_str()] = (b_snap - s_snap)/bs_all_sum_5d
                result["bssmn_sn."+pq_label_b.to_short_str()] = (b_snap + s_snap)/bs_all_sum_5d
            else:
                result["bsdfn_sn."+pq_label_b.to_short_str()] = (b_snap - s_snap)/bs_all_sum_1d
                result["bssmn_sn."+pq_label_b.to_short_str()] = (b_snap + s_snap)/bs_all_sum_1d
        
        result = alpha_ca.closures.bop.rdcp(result, lite=True, reg_wgt=ctx["xs_reg_wgt"])
        return result