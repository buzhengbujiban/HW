import json
import random
from pathlib import Path
from canopus_py.alpha_context import AlphaContext
import alpha_pq.closures.v2 as alpha_pq_clos
import alpha_ca.closures.v2 as alpha_ca_clos
from canopus_py.rnodes.ca_node import CANode, parallel_slurm_run, handle_inclusive
from canopus_py.rnodes.stats_node_cpp import StatsNodeCPP
from canopus_py.ca_expr import ca
from canopus_py.ca_utils import static_funcs, read_non_empty_lines
from jobs.rnodes.rnode import RNode
from pattern_helper import read_columns_from_pattern
from pqsum_py.utils import PQLabel

VDEPS_PATH_5M = "/data/beer2/data/CA.LTS/CNEQ/Meta/vdeps_5m.json"
VDEPS_PATH_1M = "/data/beer2/data/CA.LTS/CNEQ/Meta/vdeps_1m.json"
SELECTED_PQ5M = "/home/mike/git/alpha_ca/alpha_ca/closures/v2/selected/PQ5m_selected.csv"
SELECTED_PQ1M = "/home/mike/git/alpha_ca/alpha_ca/closures/v2/selected/PQ1m_selected.csv"
SELECTED_PQ1M = "/data/beef3/mike/rroot/alpha_pq_v2plus_main_1m/selected.txt"

PQ_MSG_PATTERNS_5M = {
    "act":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/act.YYYYMMDD.sdiv",
    "actl":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/actl.YYYYMMDD.sdiv",
    "actm":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/actm.YYYYMMDD.sdiv",
    "add":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/add.YYYYMMDD.sdiv",
    "cxl":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/cxl.YYYYMMDD.sdiv",
    "pas":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/pas.YYYYMMDD.sdiv",
}

PQ_BK_PATTERNS_5M = {
    "bk2":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/bk2.YYYYMMDD.sdiv",
    "bk3":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/bk3.YYYYMMDD.sdiv",
}

PQ_TP_PATTERNS_5M = {
    "tproxy_D_eod":"/data/beer3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/D/eod/tproxy/YYYYMMDD.sdiv",
    "tproxy_I_fq5m":"/data/beer3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/I/fq5m/tproxy/YYYYMMDD.sdiv",
}

PQ_TP_PATTERNS_1M = {
    "tproxy_D_eod":"/data/beer3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/D/eod/tproxy/YYYYMMDD.sdiv",
    "tproxy_I_fq1m":"/data/beer3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/I/fq1m/tproxy/YYYYMMDD.sdiv",
}

def pq_msg_daily_stats(ctx, msg_patterns):
    result = {}

    all_columns = []
    for k, msg_pattern in msg_patterns.items():
        print(f"Reading columns from {msg_pattern}")
        columns = read_columns_from_pattern(msg_pattern)
        all_columns += columns
    
    print(f"Found {len(all_columns)} total columns")
    
    # Process each pair once, comparing labels
    for i, col in enumerate(all_columns[:10]):
        # pq_label1_B = PQLabel.from_label(col1)
        # pq_label2_B = PQLabel.from_label(col2)
        # pq_label1_S = PQLabel.from_label(col1.replace(".B.", ".S."))
        # pq_label2_S = PQLabel.from_label(col2.replace(".B.", ".S."))
            

        result["etc."+str(col)] = ca.TsSum(col, ctx["TIME.1d"])
    return result


class PQDailyNuggs5m(AlphaContext):

    def setup(self):
        self.ctx = {
            "TIME.hh": 6,
            "TIME.1h": 12,
            "TIME.1d": 48,

            "xs_reg_wgt": ca.Sign("EstU")*ca("dv_0.33_1.8_63"),
        }

        self.vdeps = json.load(open(VDEPS_PATH_5M))
        self.vdeps = {**PQ_MSG_PATTERNS_5M, **self.vdeps}
        self.vdeps = {**PQ_BK_PATTERNS_5M, **self.vdeps}
        self.base_config = CANode.base_config()
        self.base_config["EVENTS.busdate_pattern"] = self.vdeps["I_fq5m_BB"]
        self.base_config["OUTPUT.eod_terms"] = True
        self.base_config["CA.TsOps.auto_update_rpii"] = False

        self.term_groups = []
        self.term_group_names = []

        pq_daily_stats_terms = pq_msg_daily_stats(self.ctx, PQ_MSG_PATTERNS_5M)

        self.term_groups.append(pq_daily_stats_terms)
        self.term_group_names.append("pq_daily_stats_v2p")

if __name__ == "__main__":
    RNode.RNODE_ROOT = "/data/beef3/mike/rroot"
    CANode.DEFAULT_CA_BINARY = "/data/beef2/bin/unstable/canopus"

    RNode.GLOBAL_TASKNAME = Path(__file__).stem+"_5m"

        # ca_node.run(para_spec="120")
        # ca_node.run_periods = [i for i in ca_node.run_periods if 20231101 < i < 20231201]
        # ca_node.run_date(20231113)
    # parallel_slurm_run(ca_nodes, set_dates=False)
    # exit(0)
    alpha = PQDailyNuggs5m()
    ca_nodes = alpha.get_ca_nodes(clean_dir_name=True)
    # alpha.check_selected_terms(ca_nodes)
    # exit(0)
    mem_dict = {
        # "msg_ia":25000,
        # "bk_all_v2p":15000,
        # "act_all":16000,
        # "cxl_all":20000,
        # "pas_all":5000,
        # "bk_all":20000,
    }
    for ca_node in ca_nodes:
        ca_node.slurm_cfg = {"smem":mem_dict.get(ca_node.label, 8000)}
        ca_node.set_run_dates()
        ca_node.node_config["CA.univ"] = "1,1988"
        ca_node.node_config["CA.univ"] = json.load(open(VDEPS_PATH_1M))["D_bod_univ"]
        # ca_node.set_parent_output_dir("/data/beer3/mike/pshared/full_u_terms_1m_pq")
        # ca_node.set_parent_output_dir("/data/beer3/mike/pshared/full_u_terms_1m_pq_fix_bk")

        # ca_node.set_parent_output_dir("/data/beer4/mike/pshared/pq_terms_1m_v2p")
        # ca_node.set_parent_output_dir("/data/beer4/mike/pshared/pq_terms_1m_v2p_RegQ")
        ca_node.run_periods = [i for i in ca_node.run_periods if 20171101 <= i]
        ca_node.run_date(20231113)
        exit(0)

        handle_inclusive(ca_node.node_config)
        # ca_node._set_host_and_port()
        # stats_node = StatsNodeCPP(
        #     ca_node, 
        #     # sample_split={"is_start": 20240101, "vd_start": 20240501, "os_start": 20241101, "end_date": 20250331}
        #     sample_split={"is_start": 20180101, "vd_start": 20220101, "os_start": 20230101, "end_date": 20250331}
        # )
        # stats_node.start_cpp_server()
        ca_node.run(set_dates=False)
        # stats_node.terminate_cpp_server()

    
    # parallel_slurm_run(ca_nodes, set_dates=False)
    # parallel_slurm_run(ca_nodes, set_dates=False)