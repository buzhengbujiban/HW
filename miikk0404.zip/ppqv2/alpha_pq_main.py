import json
from pathlib import Path
from canopus_py.alpha_context import AlphaContext
import alpha_pq.closures.v2 as alpha_pq_clos
import alpha_ca.closures.v2 as alpha_ca_clos
from canopus_py.rnodes.ca_node import CANode, parallel_slurm_run, handle_inclusive
from canopus_py.rnodes.stats_node_cpp import StatsNodeCPP
from canopus_py.ca_expr import ca
from canopus_py.ca_utils import static_funcs, read_non_empty_lines
from jobs.rnodes.rnode import RNode

VDEPS_PATH_5M = "/data/beer2/data/CA.LTS/CNEQ/Meta/vdeps_5m.json"
VDEPS_PATH_1M = "/data/beer2/data/CA.LTS/CNEQ/Meta/vdeps_1m.json"
SELECTED_PQ5M = "/home/mike/git/alpha_ca/alpha_ca/closures/v2/selected/PQ5m_selected.csv"
SELECTED_PQ1M = "/home/mike/git/alpha_ca/alpha_ca/closures/v2/selected/PQ1m_selected.csv"

PQ_MSG_PATTERNS_5M = {
    "act":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/act.YYYYMMDD.sdiv",
    "actl":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/actl.YYYYMMDD.sdiv",
    "actm":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/actm.YYYYMMDD.sdiv",
    "add":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/add.YYYYMMDD.sdiv",
    "cxl":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/cxl.YYYYMMDD.sdiv",
    "pas":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/pas.YYYYMMDD.sdiv",
}

PQ_MSG_PATTERNS_1M = {
    "add": "/data/beer3/mike/rroot/filtered_1m_stats_full_univ_all/000.pq.all/add.YYYYMMDD.sdiv",
    "act": "/data/beer3/mike/rroot/filtered_1m_stats_full_univ_all/000.pq.all/act.YYYYMMDD.sdiv",
    "cxl": "/data/beer3/mike/rroot/filtered_1m_stats_full_univ_all/000.pq.all/cxl.YYYYMMDD.sdiv",
    "pas": "/data/beer3/mike/rroot/filtered_1m_stats_full_univ_all/000.pq.all/pas.YYYYMMDD.sdiv",
}
PQ_BK_PATTERNS_1M = {
    "bk2":"/data/beer3/mike/rroot/filtered_1m_stats_full_univ_all/000.pq.all/bk2.YYYYMMDD.sdiv",
    "bk3":"/data/beer3/mike/rroot/filtered_1m_stats_full_univ_all/000.pq.all/bk3.YYYYMMDD.sdiv",
}

PQ_BK_PATTERNS_5M = {
    "bk2":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/bk2.YYYYMMDD.sdiv",
    "bk3":"/data/beer2/mike/rroot/merged_msgs_stats_full_univ_all/000.pq.all/bk3.YYYYMMDD.sdiv",
}

PQ_TP_PATTERNS_5M = {
    "tproxy_D_eod":"/data/beer3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/D/eod/tproxy/YYYYMMDD.sdiv",
    "tproxy_I_fq5m":"/data/beer3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/I/fq5m/tproxy/YYYYMMDD.sdiv",
}

PQ_TP_PATTERNS_1M = {
    "tproxy_D_eod":"/data/beer3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/D/eod/tproxy/YYYYMMDD.sdiv",
    "tproxy_I_fq1m":"/data/beer3/data/CAPQ.v24.1220.test_release/CNEQ/Panels/I/fq1m/tproxy/YYYYMMDD.sdiv",
}

class AlphaPQ5m(AlphaContext):

    def setup(self):
        self.ctx = {
            "TIME.hh": 6,
            "TIME.1h": 12,
            "TIME.1d": 48,

            "xs_reg_wgt": ca.Sign("EstU")*ca("dv_0.33_1.8_63"),
        }

        self.vdeps = json.load(open(VDEPS_PATH_5M))
        self.vdeps.update(PQ_MSG_PATTERNS_5M)
        self.vdeps.update(PQ_BK_PATTERNS_5M)
        self.vdeps.update(PQ_TP_PATTERNS_5M)
        self.base_config = CANode.base_config()
        self.base_config["EVENTS.busdate_pattern"] = self.vdeps["I_fq5m_BB"]

        self.term_groups = []
        self.term_group_names = []

        for pq_k, pq_pattern in PQ_MSG_PATTERNS_5M.items():
            for clos in [
                alpha_pq_clos.slc.TERMS.pq_snap,
            ]:
                pattern_terms = {}
                clos_terms = clos(self.ctx, pq_pattern)
                print(len(clos_terms), clos.__name__, pq_pattern)
                pattern_terms.update(alpha_ca_clos.bop.rkzs(clos_terms))

                # self.term_groups.append(alpha_ca_clos.bop.rkzs(clos_terms))
                # self.term_group_names.append(pq_k+"_"+clos.__name__)

            for clos in [
                alpha_pq_clos.slc.TERMS.pq_sum,
                alpha_pq_clos.slc.TERMS.pq_mean,
                alpha_pq_clos.slc.TERMS.pq_std,
            ]:
                clos_terms = clos(self.ctx, pq_pattern)
                print(len(clos_terms), clos.__name__, pq_pattern)
                pattern_terms.update(alpha_ca_clos.bop.rdcp(alpha_ca_clos.bop.rkzs(clos_terms),lite=True, reg_wgt=self.ctx["xs_reg_wgt"]))

            for clos in [
                alpha_pq_clos.slc.TERMS.pq_sum,
                alpha_pq_clos.slc.TERMS.pq_mean,
                alpha_pq_clos.slc.TERMS.pq_std,
            ]:
                for tp in [
                    None, 
                    "tproxy.5m.bboc3.p1",
                ]:
                    clos_terms = alpha_ca_clos.bop.rkzs(alpha_pq_clos.slc.TERMS.pq_ema_tp(self.ctx, pq_pattern, tp))
                    print(len(clos_terms), alpha_pq_clos.slc.TERMS.pq_ema_tp.__name__, pq_pattern, tp)
                    pattern_terms.update(clos_terms)
            self.term_groups.append(pattern_terms)
            self.term_group_names.append(pq_k+"_all")

        bk_terms = {}
        for bk_func in [
            alpha_pq_clos.bk2.TERMS.bk_ib,
            alpha_pq_clos.bk2.TERMS.bk_ms,
            alpha_pq_clos.bk2.TERMS.bk_fit,
        ]:
            clos_terms = bk_func(self.ctx)
            print(len(bk_func(self.ctx)), bk_func.__name__)
            bk_terms.update(alpha_ca_clos.bop.rkzs(clos_terms))
            # self.term_groups.append(alpha_ca_clos.bop.rkzs(clos_terms))
            # self.term_group_names.append(bk_func.__name__)
            bk3_kwargs = {
                "key":"bk3",
                "lvs":alpha_pq_clos.bk2.bk3_lvs,
                "lv_stats":alpha_pq_clos.bk2.bk3_lv_stats,
                "ratio_lvQs":alpha_pq_clos.bk2.bk3_ratio_lvQs,
            }

            clos_bk3_terms = bk_func(self.ctx, **bk3_kwargs)
            bk_terms.update(alpha_ca_clos.bop.rkzs(clos_bk3_terms))
            print(len(bk_func(self.ctx)), bk_func.__name__)
            # self.term_groups.append(alpha_ca_clos.bop.rkzs(clos_bk3_terms))
        self.term_groups.append(bk_terms)
        self.term_group_names.append("bk_all")
        self.selected = read_non_empty_lines(SELECTED_PQ5M)
        # exit(0)

class AlphaPQ1m(AlphaContext):

    def setup(self):
        self.ctx = {
            "TIME.hh": 30,
            "TIME.1h": 60,
            "TIME.1d": 240,

            "xs_reg_wgt": ca.Sign("EstU")*ca("dv_0.33_1.8_63"),
        }

        self.vdeps = json.load(open(VDEPS_PATH_1M))
        self.vdeps.update(PQ_MSG_PATTERNS_1M)
        self.vdeps.update(PQ_BK_PATTERNS_1M)
        self.vdeps.update(PQ_TP_PATTERNS_1M)
        self.base_config = CANode.base_config()
        self.base_config["CA.freq_m"] = 1
        self.base_config["EVENTS.busdate_pattern"] = self.vdeps["I_fq1m_BB"]

        self.term_groups = []
        self.term_group_names = []

        for pq_k, pq_pattern in PQ_MSG_PATTERNS_1M.items():
            for clos in [
                alpha_pq_clos.slc.TERMS.pq_snap,
            ]:
                pattern_terms = {}
                clos_terms = clos(self.ctx, pq_pattern, short_terms=True)
                print(len(clos_terms), clos.__name__, pq_pattern)
                pattern_terms.update(clos_terms)

                # self.term_groups.append(alpha_ca_clos.bop.rkzs(clos_terms))
                # self.term_group_names.append(pq_k+"_"+clos.__name__)

            for clos in [
                alpha_pq_clos.slc.TERMS.pq_sum,
                alpha_pq_clos.slc.TERMS.pq_mean,
                alpha_pq_clos.slc.TERMS.pq_std,
            ]:
                clos_terms = clos(self.ctx, pq_pattern, short_terms=True)
                print(len(clos_terms), clos.__name__, pq_pattern)
                pattern_terms.update(clos_terms)
                clos_terms = clos(self.ctx, pq_pattern, short_terms=True)
                print(len(clos_terms), clos.__name__, pq_pattern)
                pattern_terms.update(alpha_ca_clos.bop.rdcp(clos_terms, lite=True, reg_wgt=self.ctx["xs_reg_wgt"],))

            for clos in [
                alpha_pq_clos.slc.TERMS.pq_sum,
                alpha_pq_clos.slc.TERMS.pq_mean,
                alpha_pq_clos.slc.TERMS.pq_std,
            ]:
                for tp in [
                    None, 
                    "tproxy.1m.bboc3.p1",
                ]:
                    clos_terms = alpha_pq_clos.slc.TERMS.pq_ema_tp(self.ctx, pq_pattern, tp)
                    print(len(clos_terms), alpha_pq_clos.slc.TERMS.pq_ema_tp.__name__, pq_pattern, tp)
                    pattern_terms.update(clos_terms)
            self.term_groups.append(pattern_terms)
            self.term_group_names.append(pq_k+"_all")

        bk_terms = {}
        for bk_func in [
            alpha_pq_clos.bk2.TERMS.bk_ib,
            alpha_pq_clos.bk2.TERMS.bk_ms,
            alpha_pq_clos.bk2.TERMS.bk_fit,
        ]:
            clos_terms = bk_func(self.ctx)
            print(len(bk_func(self.ctx)), bk_func.__name__)
            bk_terms.update(clos_terms)
            # self.term_groups.append(alpha_ca_clos.bop.rkzs(clos_terms))
            # self.term_group_names.append(bk_func.__name__)
            bk3_kwargs = {
                "key":"bk3",
                "lvs":alpha_pq_clos.bk2.bk3_lvs,
                "lv_stats":alpha_pq_clos.bk2.bk3_lv_stats,
                "ratio_lvQs":alpha_pq_clos.bk2.bk3_ratio_lvQs,
            }

            clos_bk3_terms = bk_func(self.ctx, **bk3_kwargs)
            bk_terms.update(clos_bk3_terms)
            print(len(bk_func(self.ctx)), bk_func.__name__)
            # self.term_groups.append(alpha_ca_clos.bop.rkzs(clos_bk3_terms))
        self.term_groups.append(bk_terms)
        self.term_group_names.append("bk_all")
        self.selected = read_non_empty_lines(SELECTED_PQ1M)
        # exit(0)

if __name__ == "__main__":
    RNode.RNODE_ROOT = "/data/beef3/mike/rroot"

    RNode.GLOBAL_TASKNAME = Path(__file__).stem+"_5m"
    alpha = AlphaPQ5m()
    ca_nodes = []
    ca_nodes = alpha.get_ca_nodes(clean_dir_name=True)
    ca_nodes = [i for i in ca_nodes if i.label.startswith("bk")]
    # alpha.check_selected_terms(ca_nodes)
    # exit(0)

    # print(sum([len(i.node_config["CA.terms"]) for i in ca_nodes]))
    # for term in alpha.selected:
    #     if term not in sum([list(i.node_config["CA.terms"].keys()) for i in ca_nodes], []):
    #         print(term)
    for ca_node in ca_nodes:
        ca_node.set_run_dates()
        ca_node.node_config["CA.univ"] = "1,1988"
        ca_node.node_config["CA.univ"] = json.load(open(VDEPS_PATH_5M))["I_fq5m_BB"]
        ca_node.set_parent_output_dir("/data/beer3/mike/pshared/full_u_terms_5m_pq")
        ca_node.set_parent_output_dir("/data/beer3/mike/pshared/full_u_terms_5m_pq_fix_bk")
        ca_node.run_periods = [i for i in ca_node.run_periods if 20171101 <= i]
        ca_node.node_config["OUTPUT.terms"] = True


        # ca_node.node_config["OUTPUT.stats"] = True
        # ca_node.node_config["STATS.y_terms"] = {
        #     "mret0e":ca.Na20("mret0e")
        # }
        # ca_node.parse_vdeps(VDEPS_PATH_5M)


        # handle_inclusive(ca_node.node_config)
        # ca_node.node_config["STATS.async"] = True
        # ca_node.node_config["STATS.msgpack"] = True
        # ca_node._set_host_and_port()
        # stats_node = StatsNodeCPP(ca_node, {"is_start": "20180101", "vd_start": "20220101", "os_start": "20230101", "end_date": "20250331"})
        # stats_node.start_cpp_server()
        # ca_node.run(set_dates=False)
        # stats_node.terminate_cpp_server()

    # exit(0)
    
    parallel_slurm_run(ca_nodes, set_dates=False)
    

        # ca_node.run(para_spec="120")
        # ca_node.run_periods = [i for i in ca_node.run_periods if 20231101 < i < 20231201]
        # ca_node.run_date(20231113)
    # parallel_slurm_run(ca_nodes, set_dates=False)
    # exit(0)
    RNode.GLOBAL_TASKNAME = Path(__file__).stem+"_1m"
    alpha = AlphaPQ1m()
    ca_nodes = alpha.get_ca_nodes(clean_dir_name=True)
    ca_nodes = [i for i in ca_nodes if i.label.startswith("bk")]
    # alpha.check_selected_terms(ca_nodes)
    # exit(0)
    mem_dict = {
        "add_all":20000,
        "act_all":16000,
        "cxl_all":20000,
        "pas_all":5000,
        "bk_all":20000,
    }
    for ca_node in ca_nodes:
        ca_node.slurm_cfg = {"smem":mem_dict[ca_node.label]}
        ca_node.set_run_dates()
        ca_node.node_config["CA.univ"] = "1,1988"
        ca_node.node_config["CA.univ"] = json.load(open(VDEPS_PATH_1M))["I_fq1m_BB"]
        ca_node.set_parent_output_dir("/data/beer3/mike/pshared/full_u_terms_1m_pq")
        ca_node.set_parent_output_dir("/data/beer3/mike/pshared/full_u_terms_1m_pq_fix_bk")
        ca_node.node_config["OUTPUT.terms"] = True
        ca_node.node_config["OUTPUT.terms.output_ii"] = list(range(1, 16))+list(range(20, 245, 5))
        ca_node.run_periods = [i for i in ca_node.run_periods if 20171101 <= i]
        # ca_node.run_date(20231113)
    
    parallel_slurm_run(ca_nodes, set_dates=False)
    # parallel_slurm_run(ca_nodes, set_dates=False)