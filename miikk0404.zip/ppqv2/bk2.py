from canopus_py.ca_expr import ca
# from alpha_pq.pq_label import PQLabel
from alpha_pq.utils import *

import alpha_ca

bk2_ratio_lvQs = ["MaxQ", "QBig0", "QMed0", "QSml0", "QL", "QS"]
bk2_lv_stats = [
    "P", "Q", "N", "T",
    "TStd", "TSkew",
    "QAvg", "QStd", "QSkew",
    # "MaxT",
    *bk2_ratio_lvQs
]
bk2_lvs = [5, 10, 20]


bk3_ratio_lvQs = ["QBig0", "QMed0", "QSml0", "QL", "QS"]
bk3_lv_stats = [
	"Q", "N", "T",
	"QAvg",
    *bk3_ratio_lvQs
]
bk3_lvs = [10]

bk3_kwargs = {
    "key":"bk3",
    "lvs":bk3_lvs,
    "lv_stats":bk3_lv_stats,
    "ratio_lvQs":bk3_ratio_lvQs,
}


class TERMS:
    @staticmethod
    def bk_ib(ctx, key="bk2", lvs=bk2_lvs, lv_stats=bk2_lv_stats, ratio_lvQs=bk2_ratio_lvQs):
        result = {}
        for lv in lvs:
            for stat in lv_stats:
                if stat == "P":
                    continue
                B_sum = ca.C(0)
                A_sum = ca.C(0)
                for i in range(lv):
                    B_val = ca(f"all.{key}.B_{stat}_lv{i}.p1")
                    A_val = ca(f"all.{key}.A_{stat}_lv{i}.p1")
                    if stat in ratio_lvQs:
                        B_val /= ca(f"all.{key}.B_Q_lv{i}.p1")
                        A_val /= ca(f"all.{key}.A_Q_lv{i}.p1")
                    B_sum += B_val
                    A_sum += A_val

                result[f"{key}.ib.{stat}_lv{lv}.B"] = B_sum
                result[f"{key}.ib.{stat}_lv{lv}.A"] = A_sum
                result[f"{key}.ib.{stat}_lv{lv}.AB"] = B_sum+A_sum
                result[f"{key}.ib.{stat}_lv{lv}.IB"] = (B_sum-A_sum)/(B_sum+A_sum)

                result[f"{key}.ib.{stat}_lv{lv}.ABc"] = ca.ETsCorr([A_sum, B_sum], ctx["TIME.1m"]*10)
                result[f"{key}.ib.{stat}_lv{lv}.ABrr"] = ca.ETsReg([A_sum, B_sum], ctx["TIME.1m"]*10)["res"]
                result[f"{key}.ib.{stat}_lv{lv}.ABrb"] = ca.ETsReg([A_sum, B_sum], ctx["TIME.1m"]*10)["beta_0"]
                result[f"{key}.ib.{stat}_lv{lv}.ABryh"] = ca.ETsReg([A_sum, B_sum], ctx["TIME.1m"]*10)["yhat"]
                result[f"{key}.ib.{stat}_lv{lv}.BArr"] = ca.ETsReg([B_sum, A_sum], ctx["TIME.1m"]*10)["res"]
                result[f"{key}.ib.{stat}_lv{lv}.BArb"] = ca.ETsReg([B_sum, A_sum], ctx["TIME.1m"]*10)["beta_0"]
                result[f"{key}.ib.{stat}_lv{lv}.BAryh"] = ca.ETsReg([B_sum, A_sum], ctx["TIME.1m"]*10)["yhat"]

                # result[f"bk2.ib.{stat}_lv{lv}.B.1h"] = ca.TsMean(B_sum, ctx["TIME.1h"])
                # result[f"bk2.ib.{stat}_lv{lv}.A.1h"] = ca.TsMean(A_sum, ctx["TIME.1h"])
                # result[f"bk2.ib.{stat}_lv{lv}.AB.1h"] = ca.TsMean(B_sum+A_sum, ctx["TIME.1h"])
                # result[f"bk2.ib.{stat}_lv{lv}.IB.1h"] = ca.TsMean((B_sum-A_sum)/(B_sum+A_sum), ctx["TIME.1h"])

        terms = list(result.keys())
        for term in terms:
            result[term+".1h"] = ca.TsMean(result[term], ctx["TIME.1h"])
        result = alpha_ca.closures.bop.rdcp(result, lite=True, reg_wgt=ctx["xs_reg_wgt"])
        return result

    @staticmethod
    def bk_ms(ctx, key="bk2", lvs=bk2_lvs, lv_stats=bk2_lv_stats, ratio_lvQs=bk2_ratio_lvQs):
        result = {}
        for lv in lvs:
            for stat in lv_stats:
                if stat == "P":
                    continue
                B_sum = ca.C(0)
                A_sum = ca.C(0)
                B_dist_sum = ca.C(0)
                A_dist_sum = ca.C(0)
                for i in range(lv):
                    B_val = ca(f"all.{key}.B_{stat}_lv{i}.p1")
                    A_val = ca(f"all.{key}.A_{stat}_lv{i}.p1")
                    if stat in ratio_lvQs:
                        B_val /= ca(f"all.{key}.B_Q_lv{i}.p1")
                        A_val /= ca(f"all.{key}.A_Q_lv{i}.p1")
                    B_sum += B_val
                    A_sum += A_val
                    B_dist_sum += B_val*ca.C(i)
                    A_dist_sum += A_val*ca.C(i)
                B_dist = B_dist_sum/B_sum
                A_dist = A_dist_sum/A_sum
                result[f"{key}.ms.{stat}_lv{lv}.B"]  = B_dist
                result[f"{key}.ms.{stat}_lv{lv}.A"]  = A_dist
                result[f"{key}.ms.{stat}_lv{lv}.AB"] = B_dist+A_dist
                result[f"{key}.ms.{stat}_lv{lv}.IB"] = (B_dist-A_dist)/(B_dist+A_dist)

                result[f"{key}.ib.{stat}_lv{lv}.ABc"] = ca.ETsCorr([A_dist, B_dist], ctx["TIME.1m"]*10)
                result[f"{key}.ib.{stat}_lv{lv}.ABrr"] = ca.ETsReg([A_dist, B_dist], ctx["TIME.1m"]*10)["res"]
                result[f"{key}.ib.{stat}_lv{lv}.ABrb"] = ca.ETsReg([A_dist, B_dist], ctx["TIME.1m"]*10)["beta_0"]
                result[f"{key}.ib.{stat}_lv{lv}.ABryh"] = ca.ETsReg([A_dist, B_dist], ctx["TIME.1m"]*10)["yhat"]
                result[f"{key}.ib.{stat}_lv{lv}.BArr"] = ca.ETsReg([B_dist, A_dist], ctx["TIME.1m"]*10)["res"]
                result[f"{key}.ib.{stat}_lv{lv}.BArb"] = ca.ETsReg([B_dist, A_dist], ctx["TIME.1m"]*10)["beta_0"]
                result[f"{key}.ib.{stat}_lv{lv}.BAryh"] = ca.ETsReg([B_dist, A_dist], ctx["TIME.1m"]*10)["yhat"]


        terms = list(result.keys())
        for term in terms:
            result[term+".1h"] = ca.TsMean(result[term], ctx["TIME.1h"])
        result = alpha_ca.closures.bop.rdcp(result, lite=True, reg_wgt=ctx["xs_reg_wgt"])
        return result

    @staticmethod
    def bk_fit(ctx, key="bk2", lvs=bk2_lvs, lv_stats=bk2_lv_stats, ratio_lvQs=bk2_ratio_lvQs):
        result = {}
        for lv in lvs:
            for stat in lv_stats:
                if stat == "P":
                    continue
                B_vals = []
                A_vals = []
                for i in range(lv):
                    B_val = ca(f"all.{key}.B_{stat}_lv{i}.p1")
                    A_val = ca(f"all.{key}.A_{stat}_lv{i}.p1")
                    if stat in ratio_lvQs:
                        B_val /= ca(f"all.{key}.B_Q_lv{i}.p1")
                        A_val /= ca(f"all.{key}.A_Q_lv{i}.p1")
                    B_vals += [B_val]
                    A_vals += [A_val]

                result[f"{key}.fit.{stat}_lv{lv}.std"]  = ca.MVStd(B_vals + A_vals)/ca.MVMean(B_vals + A_vals)
                result[f"{key}.fit.{stat}_lv{lv}.std.ib"]  = (ca.MVStd(B_vals)-ca.MVStd(A_vals))/(ca.MVStd(B_vals)+ca.MVStd(A_vals))
                result[f"{key}.fit.{stat}_lv{lv}.RegL.a.ib"] = (ca.MVRegL(B_vals)["a"]-ca.MVRegL(A_vals)["a"])/ca.MVMean(B_vals + A_vals)
                result[f"{key}.fit.{stat}_lv{lv}.RegL.b.ib"] = (ca.MVRegL(B_vals)["b"]-ca.MVRegL(A_vals)["b"])/ca.MVMean(B_vals + A_vals)
                result[f"{key}.fit.{stat}_lv{lv}.RegL.b0.ib"] = (ca.MVRegL(B_vals)["b0"]-ca.MVRegL(A_vals)["b0"])/ca.MVMean(B_vals + A_vals)
                result[f"{key}.fit.{stat}_lv{lv}.RegL.r2.ib"] = (ca.MVRegL(B_vals)["r2"]-ca.MVRegL(A_vals)["r2"])/ca.MVMean(B_vals + A_vals)
                result[f"{key}.fit.{stat}_lv{lv}.RegQ.a.ib"] = (ca.MVRegL(B_vals)["a"]-ca.MVRegL(A_vals)["a"])/ca.MVMean(B_vals + A_vals)
                regQ_b2a_B = ca.MVRegL(B_vals)["b"]/ca.MVRegL(B_vals)["a"]*ca.C(-0.5)
                regQ_b2a_A = ca.MVRegL(A_vals)["b"]/ca.MVRegL(A_vals)["a"]*ca.C(-0.5)
                result[f"{key}.fit.{stat}_lv{lv}.RegQ.b2a.ib"] = regQ_b2a_B-regQ_b2a_A

                result[f"{key}.fit.{stat}_lv{lv}.RegQfix.a.ib"] = (ca.MVRegQ(B_vals)["a"]-ca.MVRegQ(A_vals)["a"])/ca.MVMean(B_vals + A_vals)
                regQ_b2a_B = ca.MVRegQ(B_vals)["b"]/ca.MVRegQ(B_vals)["a"]*ca.C(-0.5)
                regQ_b2a_A = ca.MVRegQ(A_vals)["b"]/ca.MVRegQ(A_vals)["a"]*ca.C(-0.5)
                result[f"{key}.fit.{stat}_lv{lv}.RegQfix.b2a.ib"] = regQ_b2a_B-regQ_b2a_A

                result[f"{key}.fit.{stat}_lv{lv}.RegQfix.a.cb"] = (ca.MVRegQ(B_vals[::-1]+A_vals)["a"])/ca.MVMean(B_vals[::-1]+A_vals)
                regQ_b2a_cb = ca.MVRegQ(B_vals[::-1]+A_vals)["b"]/ca.MVRegQ(B_vals[::-1]+A_vals)["a"]*ca.C(-0.5)
                result[f"{key}.fit.{stat}_lv{lv}.RegQfix.b2a.cb"] = regQ_b2a_cb
        for lv in [10, 20]:
            if not lv in lvs:
                continue
            for stat in lv_stats:
                if stat == "P":
                    continue
                B_vals = []
                A_vals = []
                for i in range(lv):
                    B_val = ca(f"all.{key}.B_{stat}_lv{i}.p1")
                    A_val = ca(f"all.{key}.A_{stat}_lv{i}.p1")
                    if stat in ratio_lvQs:
                        B_val /= ca(f"all.{key}.B_Q_lv{i}.p1")
                        A_val /= ca(f"all.{key}.A_Q_lv{i}.p1")
                    if len(B_vals) == 0:
                        B_vals += [B_val]
                        A_vals += [A_val]
                    else:
                        B_vals += [B_vals[-1]+B_val]
                        A_vals += [B_vals[-1]+A_val]

                result[f"{key}.fit.{stat}_lv{lv}.agg.RegL.a.ib"] = (ca.MVRegL(B_vals)["a"]-ca.MVRegL(A_vals)["a"])/ca.MVMean(B_vals + A_vals)
                result[f"{key}.fit.{stat}_lv{lv}.agg.RegL.b.ib"] = (ca.MVRegL(B_vals)["b"]-ca.MVRegL(A_vals)["b"])/ca.MVMean(B_vals + A_vals)
                result[f"{key}.fit.{stat}_lv{lv}.agg.RegL.b0.ib"] = (ca.MVRegL(B_vals)["b0"]-ca.MVRegL(A_vals)["b0"])/ca.MVMean(B_vals + A_vals)
                result[f"{key}.fit.{stat}_lv{lv}.agg.RegL.r2.ib"] = (ca.MVRegL(B_vals)["r2"]-ca.MVRegL(A_vals)["r2"])/ca.MVMean(B_vals + A_vals)

        terms = list(result.keys())
        for term in terms:
            result[term+".1h"] = ca.TsMean(result[term], ctx["TIME.1h"])
        result = alpha_ca.closures.bop.rdcp(result, lite=True, reg_wgt=ctx["xs_reg_wgt"])
        return result
