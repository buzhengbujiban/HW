import copy
import sys
from jobs.rnodes.rnode import RNode, SlurmCfg
from canopus_py.rnodes.ca_node import CANode

from canopus_py.ca_expr import *
from canopus_py.ca_stats import *
from canopus_py.rnodes.stats_node import StatsNode, basic_selection
from terms_open import *


y_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/Y/Y_V5/terms.YYYYMMDD.sdiv"
min5_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/I/fq5m/BB/terms.YYYYMMDD.sdiv"
st_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/D/eod/sid_st/st_YYYYMMDD.sdiv"

rdcp_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/I/fq5m/ResRet/rdcp/terms.YYYYMMDD.sdiv"
rs_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/D/eod/D1RS/daily-rollstats-YYYYMMDD.sdiv"
sv_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/I/fq5m/ResV/sv0/terms.YYYYMMDD.sdiv"
cap_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/D/eod/cap/cap-YYYYMMDD.sdiv"
pq_pattern = "/data/beef2/mike/shared/ppq_bms/ppq_slurm_test_G2548_fix/000.pq/YYYYMMDD.sdiv"
dailyadj_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/D/bod/daily-adjust-2007/daily-adjusted-YYYYMMDD.sdiv"
univ_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/D/eod/univ/univ-YYYYMMDD.sdiv"
risk_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/D/eod/barra/exp-YYYYMMDD.sdiv"


open_pattern = "/data/beef2/mike/shared/auc_stats/open_new/YYYYMMDD.sdiv"
auceod_pattern = "/data/beef2/mike/shared/auc_stats/eod_new/eod.YYYYMMDD.sdiv"

def init(task_name):
    RNode.RNODE_ROOT = "/data/beef2/guopeng/auction"
    RNode.GLOBAL_TASKNAME = task_name
    CANode.DEFAULT_CA_BINARY = "/data/beef2/bin/unstable/canopus"

    base_config = CANode.base_config(market="CNEQ_OPEN")

    base_config["EVENTS.busdate_pattern"] = y_pattern
    base_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    
    # base_config["CA.univ"] = "/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv:topx"
    base_config["EVENTS.gf_weeks"] = 1
    
    base_config["DATA.panels"] += ["open"]
    base_config["DATA.open.pattern"] = open_pattern
    base_config["DATA.open.lb_days"] = 5
    base_config["DATA.open.inclusive"] = True

    base_config["DATA.panels"] += ["auceod"]
    base_config["DATA.auceod.pattern"] = auceod_pattern
    base_config["DATA.auceod.lb_days"] = 5
    base_config["DATA.auceod.columns"] = read_columns_from_pattern(auceod_pattern)
    base_config["DATA.auceod.column_masks"] = [".".join(["auc_eod"]+c.split(".")[1:]) for c in base_config["DATA.auceod.columns"]]
    base_config["DATA.auceod.inclusive"] = False 

    base_config["DATA.panels"] += ["5min"]
    base_config["DATA.5min.pattern"] = min5_pattern
    # base_config["DATA.5min.pattern"] = "/data/beef2/guopeng/labels/5min/000.ca.5min/terms.YYYYMMDD.sdiv"
    base_config["DATA.5min.lb_days"] = 5

    base_config["DATA.panels"] += ["univ"]
    base_config["DATA.univ.pattern"] = "/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv"
    # base_config["DATA.univ.columns"] = ["topx"]
    base_config["DATA.univ.inclusive"] = True


    base_config["DATA.panels"] += ["Y"]
    base_config["DATA.Y.pattern"] = y_pattern
    base_config["DATA.Y.columns"] = ["mret24h", "bret24h", "mret1h"]

    # base_config["DATA.panels"] += ["Y1"]
    # base_config["DATA.Y1.pattern"] = "/data/beef2/data/CA/CNEQ/Panels/Y/Y_V5_res/terms.YYYYMMDD.sdiv"
    # base_config["DATA.Y1.columns"] = ["mret24h.res"]

    # base_config["DATA.panels"] += ['baseline']
    # base_config["DATA.baseline.pattern"] = baseline_pattern
    # base_config["DATA.baseline.columns"] = ['m3_br.0']
    
    base_config["DATA.panels"] += ["st"]
    base_config["DATA.st.pattern"] = st_pattern
    base_config["DATA.st.inclusive"] = False

    base_config["DATA.panels"] += ['adj']
    base_config["DATA.adj.pattern"] = dailyadj_pattern
    base_config["DATA.adj.columns"] = ['adj.factor.locf']
    base_config["DATA.adj.lb_days"] = 5 
    base_config["DATA.adj.inclusive"] = True 

    base_config["DATA.panels"] += ["rdcp"]
    base_config["DATA.rdcp.pattern"] = rdcp_pattern
    base_config["DATA.rdcp.columns"] = read_columns_from_pattern(rdcp_pattern)
    base_config["DATA.rdcp.lb_days"] = 5

    base_config["DATA.panels"] += ["sv"]
    base_config["DATA.sv.pattern"] = sv_pattern
    base_config["DATA.sv.columns"] = read_columns_from_pattern(sv_pattern)
    base_config["DATA.sv.lb_days"] = 5

    base_config["DATA.panels"] += ["rs"]
    base_config["DATA.rs.pattern"] = rs_pattern
    base_config["DATA.rs.columns"] = read_columns_from_pattern(rs_pattern)
    base_config["DATA.rs.inclusive"] = False
    base_config["DATA.rs.lb_days"] = 5

    base_config["DATA.panels"] += ["cap"]
    base_config["DATA.cap.pattern"] = cap_pattern
    base_config["DATA.cap.columns"] = read_columns_from_pattern(cap_pattern)
    base_config["DATA.cap.inclusive"] = False
    base_config["DATA.cap.lb_days"] = 5

    base_config["DATA.panels"] += ["pq"]
    base_config["DATA.pq.pattern"] = pq_pattern
    base_config["DATA.pq.lb_days"] = 5
    # base_config["DATA.pq.columns"] = read_columns_from_pattern(pq_pattern)

    base_config["OUTPUT.stats"] = True
    base_config["STATS.y_terms"] = {
        # "mret10m": "mret10m", 
        "mret1h": "mret1h", "mret24h": "mret24h", 
        # "mret24h.res": "mret24h.res", 
        "bret24h": "bret24h", 
        # "marginal": ca.RegRes(ca("mret24h"), ca("m3_br.0"), w=ca("is.active"))
        }
    base_config["DATA.panels"] += ["barra"]
    base_config["DATA.barra.pattern"] = "/data/nfs0/chinaEquityData/panel/barra/exp-YYYYMMDD.sdiv"
    base_config["DATA.barra.columns"] = inds_CNE5 + stls_CNE5
    base_config["DATA.barra.inclusive"] = False
    base_config["DATA.barra.lb_days"] = 3
    # 给不同数据样本不一样的数据权重
    base_config["STATS.w_terms"] = {
        # "w_c1": ca.C(1), 
        "w_c1": ca("topx")*(ca.C(1)-ca("st")),
        # "w_c1": ca.C(1)-ca("st"),
        # "w_op": ca.IIndex() <= ca.C(6),
        # "w_mh": (ca.IIndex() > ca.C(6)) & (ca.IIndex() <= ca.C(42)),
        # "w_ed": (ca.IIndex() > ca.C(42)),
        }
    return CANode(copy.deepcopy(base_config), label=task_name)


def genr_auc1():
    node = init("auc1")
    res = {}
    ## 第一个timer的不平衡
    bpq = ca("buyQty")*ca("buyNotl")
    spq = ca("sellQty")*ca("sellNotl")
    res.update(auc1(bpq, spq, "pq_imb"))
    res.update(auc1(ca("buyQty"), ca("sellQty"), "q_imb"))
    res.update(auc1(ca("buyNotl"), ca("sellNotl"), "c_imb"))
    ## AM1的不平衡
    # qty
    for pq, bench in zip(['pq', 'q', 'c'], ["dollarVolumeTotal", "volumeTotal", "tradesTotal"]):
        for smb in ["Sml0", "Med0", "Big0"]:
            b_rm = (ca(f"auc.B.add_AM1_{smb}.{pq}.p1") - ca(f"auc.B.cxl_AM1_{smb}.{pq}.p1")) 
            s_rm = ca(f"auc.S.add_AM1_{smb}.{pq}.p1") - ca(f"auc.S.cxl_AM1_{smb}.{pq}.p1") 
            b_rm = ca.RegYHat(b_rm, bench, w=ca("is.active"))
            s_rm = ca.RegYHat(s_rm, bench, w=ca("is.active"))
            res.update(auc1(b_rm, s_rm, f"auc1.{pq}.{smb}.am1.rm"))
        b_add_am1 = ca(f"auc.B.add_AM1_Sml0.{pq}.p1") + ca(f"auc.B.add_AM1_Med0.{pq}.p1") + ca(f"auc.B.add_AM1_Big0.{pq}.p1")
        b_cxl_am1 = ca(f"auc.B.cxl_AM1_Sml0.{pq}.p1") + ca(f"auc.B.cxl_AM1_Med0.{pq}.p1") + ca(f"auc.B.cxl_AM1_Big0.{pq}.p1")
        s_add_am1 = ca(f"auc.S.add_AM1_Sml0.{pq}.p1") + ca(f"auc.S.add_AM1_Med0.{pq}.p1") + ca(f"auc.S.add_AM1_Big0.{pq}.p1")
        s_cxl_am1 = ca(f"auc.S.cxl_AM1_Sml0.{pq}.p1") + ca(f"auc.S.cxl_AM1_Med0.{pq}.p1") + ca(f"auc.S.cxl_AM1_Big0.{pq}.p1")
        b_rm = ca.RegYHat(b_add_am1 - b_cxl_am1, bench, w=ca("is.active"))
        s_rm = ca.RegYHat(s_add_am1 - s_cxl_am1, bench, w=ca("is.active"))
        res.update(auc1(b_rm, s_rm, f"auc1.{pq}.am1.rm"))

    # p
    for smb in ["Sml0", "Med0", "Big0"]:
        bp_rm = (ca(f"auc.B.add_AM1_{smb}.pq.p1") - ca(f"auc.B.cxl_AM1_{smb}.pq.p1")) / (ca(f"auc.B.add_AM1_{smb}.q.p1") - ca(f"auc.B.cxl_AM1_{smb}.q.p1") + ca.C(0.01))
        sp_rm = (ca(f"auc.S.add_AM1_{smb}.pq.p1") - ca(f"auc.S.cxl_AM1_{smb}.pq.p1")) / (ca(f"auc.S.add_AM1_{smb}.q.p1") - ca(f"auc.S.cxl_AM1_{smb}.q.p1") + ca.C(0.01))
        res.update(auc1(bp_rm, sp_rm, f"auc1.p.{smb}.am1"))
    b_add_am1_pq = ca("auc.B.add_AM1_Sml0.pq.p1") + ca("auc.B.add_AM1_Med0.pq.p1") + ca("auc.B.add_AM1_Big0.pq.p1")
    s_add_am1_pq = ca("auc.S.add_AM1_Sml0.pq.p1") + ca("auc.S.add_AM1_Med0.pq.p1") + ca("auc.S.add_AM1_Big0.pq.p1")
    b_add_am1_q = ca("auc.B.add_AM1_Sml0.q.p1") + ca("auc.B.add_AM1_Med0.q.p1") + ca("auc.B.add_AM1_Big0.q.p1")
    s_add_am1_q = ca("auc.S.add_AM1_Sml0.q.p1") + ca("auc.S.add_AM1_Med0.q.p1") + ca("auc.S.add_AM1_Big0.q.p1")
    b_cxl_am1_pq = ca("auc.B.cxl_AM1_Sml0.pq.p1") + ca("auc.B.cxl_AM1_Med0.pq.p1") + ca("auc.B.cxl_AM1_Big0.pq.p1")
    s_cxl_am1_pq = ca("auc.S.cxl_AM1_Sml0.pq.p1") + ca("auc.S.cxl_AM1_Med0.pq.p1") + ca("auc.S.cxl_AM1_Big0.pq.p1")
    b_cxl_am1_q = ca("auc.B.cxl_AM1_Sml0.q.p1") + ca("auc.B.cxl_AM1_Med0.q.p1") + ca("auc.B.cxl_AM1_Big0.q.p1")
    s_cxl_am1_q = ca("auc.S.cxl_AM1_Sml0.q.p1") + ca("auc.S.cxl_AM1_Med0.q.p1") + ca("auc.S.cxl_AM1_Big0.q.p1")
    bp_rm = (b_add_am1_pq - b_cxl_am1_pq) / (b_add_am1_q - b_cxl_am1_q + ca.C(1))
    sp_rm = (s_add_am1_pq - s_cxl_am1_pq) / (s_add_am1_q - s_cxl_am1_q + ca.C(1))
    res.update(auc1(bp_rm, sp_rm, f"auc1.p.am1"))
    ## AM2 的不平衡
    # trd 的不平衡
    for pq, bench in zip(['q', 'c'], ["volumeTotal", "tradesTotal"]):
        for smb in ["Sml0", "Med0", "Big0"]:
            b_trd = ca(f"auc.B.trd_AM2_{smb}.{pq}.p1")
            s_trd = ca(f"auc.S.trd_AM2_{smb}.{pq}.p1")
            b_trd = ca.RegYHat(b_trd, bench, w=ca("is.active"))
            s_trd = ca.RegYHat(s_trd, bench, w=ca("is.active"))
            res.update(auc1(b_trd, s_trd, f"auc1.{pq}.{smb}.am2.trd"))
        b_trd = ca(f"auc.B.trd_AM2_Big0.{pq}.p1") + ca(f"auc.B.trd_AM2_Med0.{pq}.p1") + ca(f"auc.B.trd_AM2_Sml0.{pq}.p1")
        s_trd = ca(f"auc.S.trd_AM2_Big0.{pq}.p1") + ca(f"auc.S.trd_AM2_Med0.{pq}.p1") + ca(f"auc.S.trd_AM2_Sml0.{pq}.p1")
        b_trd = ca.RegYHat(b_trd, bench, w=ca("is.active"))
        s_trd = ca.RegYHat(s_trd, bench, w=ca("is.active"))
        res.update(auc1(b_trd, s_trd, f"auc1.{pq}.am2.trd"))
    # remain 的不平衡
    for pq, bench in zip(['q', 'c'], ["volumeTotal", "tradesTotal"]):
        b_trd = ca(f"auc.B.trd_AM2_Big0.{pq}.p1") + ca(f"auc.B.trd_AM2_Med0.{pq}.p1") + ca(f"auc.B.trd_AM2_Sml0.{pq}.p1")
        b_add = ca(f"auc.B.add_AM2_Big0.{pq}.p1") + ca(f"auc.B.add_AM2_Med0.{pq}.p1") + ca(f"auc.B.add_AM2_Sml0.{pq}.p1")
        b_rm = (b_add - b_trd) #/ (ca(bench) + ca.C(1))
        s_trd = ca(f"auc.S.trd_AM2_Big0.{pq}.p1") + ca(f"auc.S.trd_AM2_Med0.{pq}.p1") + ca(f"auc.S.trd_AM2_Sml0.{pq}.p1")
        s_add = ca(f"auc.S.add_AM2_Big0.{pq}.p1") + ca(f"auc.S.add_AM2_Med0.{pq}.p1") + ca(f"auc.S.add_AM2_Sml0.{pq}.p1")
        s_rm = (s_add - s_trd) #/ (ca(bench) + ca.C(1))
        b_rm = ca.RegYHat(b_rm, bench, w=ca("is.active"))
        s_rm = ca.RegYHat(s_rm, bench, w=ca("is.active"))
        res.update(auc1(b_rm, s_rm, f"auc1.{pq}.am2.rm"))
    res0 = {k:ca.XsZScore(v) for k, v in rdcp(res).items()}
    res1 = {k:ca.XsZScore(v) for k, v in rdcp1(res).items()}
    node.node_config["CA.terms"].update(res0)
    node.node_config["CA.terms"].update(res1)
    return node, res 


def genr_auc2():
    node = init("auc2")
    node.node_config["DATA.panels"] += ["retstd"]
    node.node_config["DATA.retstd.pattern"] = "/data/beef2/guopeng/auction/eod_stats/ret_stats/000.ca.ret_stats/eod.YYYYMMDD.sdiv"
    node.node_config["DATA.retstd.lb_days"] = 5 
    node.node_config["DATA.retstd.inclusive"] = False 
    # 隔夜收益率波动率和日内收益率波动率的比率
    name = "auc2"
    terms = {}
    for r in read_columns_from_pattern(rdcp_pattern):
        terms[f"{name}.{r}.stdratio"] = ca.TsStd(ca(f"{r}.over"), 5) / (ca(f"{r}.std.intra") + ca.C(0.001))
        terms[f"{name}.{r}.stdres"] = ca.RegRes(ca.TsStd(ca(f"{r}.over"), 5), ca(f"{r}.std.intra"), w=ca("is.active"))
        terms[f"{name}.{r}.stdresbw"] = ca.RegRes(ca.TsStd(ca(f"{r}.over"), 5), ca.TsMean(f"{r}.std.intra", 5), w=ca("is.active"))
    # 早盘集合竞价振幅和昨天隔夜收益率的比率
    p_max_am1 = ca.RegYHat(ca("auc.BS.all.iep_max_AM1.p1"), ca("high"), w=ca("is.active"))
    p_max_am2 = ca.RegYHat(ca("auc.BS.all.iep_max_AM2.p1"), ca("high"), w=ca("is.active"))
    # p_max_all = ca.Max(p_max_am1, p_max_am2)
    p_max_spr = ca.Abs(ca("auc.BS.all.iep_max_AM1.p1") - ca("auc.BS.all.iep_max_AM2.p1"))
    p_min_am1 = ca.RegYHat(ca("auc.BS.all.iep_min_AM1.p1"), ca("low"), w=ca("is.active"))
    p_min_am2 = ca.RegYHat(ca("auc.BS.all.iep_min_AM2.p1"), ca("low"), w=ca("is.active"))
    # p_min_all = ca.Min(p_min_am1, p_min_am2)
    p_min_spr = ca.Abs(ca("auc.BS.all.iep_min_AM1.p1") - ca("auc.BS.all.iep_min_AM2.p1"))
    vol_am1 = (p_max_am1 - p_min_am1) / (p_max_am1+p_min_am1+ca.C(1))
    vol_am2 = (p_max_am2 - p_min_am2) / (p_max_am2+p_min_am2+ca.C(1))
    vol_spr = (p_max_spr - p_min_spr) # / (p_max_spr+p_min_spr+ca.C(1))
    terms[f"{name}.vol_am1"] = vol_am1
    terms[f"{name}.vol_am2"] = vol_am2
    # terms[f"{name}.vol_all"] = vol_all 
    for r in read_columns_from_pattern(rdcp_pattern):
        terms[f"{name}.{r}.intra.am1"] = vol_am1 / (ca(f"{r}.std.intra") + ca.C(0.001))
        terms[f"{name}.{r}.intra.am2"] = vol_am2 / (ca(f"{r}.std.intra") + ca.C(0.001))
        terms[f"{name}.{r}.intra.spr"] = vol_spr/ (ca(f"{r}.std.intra") + ca.C(0.001))
        terms[f"{name}.{r}.over.am1"] = vol_am1 / (ca.TsStd(ca(f"{r}.over"), 5)+ca.C(0.001))
        terms[f"{name}.{r}.over.am2"] = vol_am2 / (ca.TsStd(ca(f"{r}.over"), 5)+ca.C(0.001))
        terms[f"{name}.{r}.over.spr"] = vol_spr / (ca.TsStd(ca(f"{r}.over"), 5)+ca.C(0.001))
        terms[f"{name}.{r}.intra.am1.res"] = ca.RegRes(vol_am1, ca(f"{r}.std.intra"), w=ca("is.active"))
        terms[f"{name}.{r}.intra.am2.res"] = ca.RegRes(vol_am2, ca(f"{r}.std.intra"), w=ca("is.active"))
        terms[f"{name}.{r}.intra.spr.res"] = ca.RegRes(vol_spr, ca(f"{r}.std.intra"), w=ca("is.active"))
        terms[f"{name}.{r}.over.am1.res"] = ca.RegRes(vol_am1, ca.TsStd(ca(f"{r}.over"), 5), w=ca("is.active"))
        terms[f"{name}.{r}.over.am2.res"] = ca.RegRes(vol_am2, ca.TsStd(ca(f"{r}.over"), 5), w=ca("is.active"))
        terms[f"{name}.{r}.over.spr.res"] = ca.RegRes(vol_spr, ca.TsStd(ca(f"{r}.over"), 5), w=ca("is.active"))
    
    # 尾盘集合竞价的振幅与隔夜收益率、日内收益率波动率的比率

    res0 = {k:ca.XsZScore(v) for k, v in rdcp(terms).items()}
    res1 = {k:ca.XsZScore(v) for k, v in rdcp1(terms).items()}
    node.node_config["CA.terms"].update(res0)
    node.node_config["CA.terms"].update(res1)
    return node, 0

def genr_auc3():
    node = init("auc3")
    res = {}
    # 开盘集合竞价大中小单占比
    ## AM1 
    for atc in ["add", "cxl"]:
        for bs in ["B", "S"]:
            for pq in ["pq", "q", "c"]:
                t = ca(f"auc.{bs}.{atc}_AM1_Sml0.{pq}.p1") + ca(f"auc.{bs}.{atc}_AM1_Med0.{pq}.p1") + ca(f"auc.{bs}.{atc}_AM1_Big0.{pq}.p1")
                for smb in ["Sml0", "Med0", "Big0"]:
                    x = ca(f"auc.{bs}.{atc}_AM1_{smb}.{pq}.p1")
                    res.update(auc3(x, t, f"auc3.{atc}.{bs}.{smb}.am1"))
    ## AM2
    for atc in ["add", "trd"]:
        for bs in ["B", "S"]:
            for pq in ["pq", "q", "c"]:
                t = ca(f"auc.{bs}.{atc}_AM2_Sml0.{pq}.p1") + ca(f"auc.{bs}.{atc}_AM2_Med0.{pq}.p1") + ca(f"auc.{bs}.{atc}_AM2_Big0.{pq}.p1")
                for smb in ["Sml0", "Med0", "Big0"]:
                    x = ca(f"auc.{bs}.{atc}_AM2_{smb}.{pq}.p1")
                    res.update(auc3(x, t, f"auc3.{atc}.{bs}.{smb}.am2"))
                    x = ca.RegRes(ca(f"auc.{bs}.{atc}_AM2_{smb}.{pq}.p1"), ca(f"auc_eod.{bs}.{atc}_PM_{smb}.{pq}.p1"), w=ca("is.active"))
                    res.update(auc3(x, t, f"auc3.{atc}.{bs}.{smb}.am2.res"))
    ## 收盘集合竞价大中小单占比
    for atc in ["add", "trd"]:
        for bs in ["B", "S"]:
            for pq in ["pq", "q", "c"]:
                t = ca(f"auc_eod.{bs}.{atc}_PM_Sml0.{pq}.p1") + ca(f"auc_eod.{bs}.{atc}_PM_Med0.{pq}.p1") + ca(f"auc_eod.{bs}.{atc}_PM_Big0.{pq}.p1")
                for smb in ["Sml0", "Med0", "Big0"]:
                    x = ca(f"auc_eod.{bs}.{atc}_PM_{smb}.{pq}.p1")
                    res.update(auc3(x, t, f"auc3.{atc}.{bs}.{smb}.pm"))
                    x = ca.RegRes(ca(f"auc_eod.{bs}.{atc}_PM_{smb}.{pq}.p1"), ca(f"auc.{bs}.{atc}_AM2_{smb}.{pq}.p1"), w=ca("is.active"))
                    res.update(auc3(x, t, f"auc3.{atc}.{bs}.{smb}.pm.res"))
                    
    res0 = {k:ca.XsZScore(v) for k, v in rdcp(res).items()}
    res1 = {k:ca.XsZScore(v) for k, v in rdcp1(res).items()}
    node.node_config["CA.terms"].update(res0)
    node.node_config["CA.terms"].update(res1)
    return node, 0


def genr_auc4():
    node = init("auc4")
    node.node_config["DATA.panels"] += ["ppqeod"]
    node.node_config["DATA.ppqeod.pattern"] = "/data/beef2/guopeng/auction/eod_stats/ppq_stats/000.ca.ppq_stats/eod.YYYYMMDD.sdiv"
    node.node_config["DATA.ppqeod.inclusive"] = False 
    node.node_config["DATA.ppqeod.lb_days"] = 5 
    
    res = {}
    # AM1 和 ppq 第一个timer的大中小单比率
    for atc in ["add", "cxl"]:
        for bs in ["B", "S"]:
            for pq in ["pq", "q", "c"]:
                t_auc = ca(f"auc.{bs}.{atc}_AM1_Sml0.{pq}.p1") + ca(f"auc.{bs}.{atc}_AM1_Med0.{pq}.p1") + ca(f"auc.{bs}.{atc}_AM1_Big0.{pq}.p1")
                t_ppq = ca(f"ppq_eod.{bs}.{atc}_sml0.{pq}.p1") + ca(f"ppq_eod.{bs}.{atc}_med0.{pq}.p1") + ca(f"ppq_eod.{bs}.{atc}_big0.{pq}.p1")
                auc_res = ca.RegRes(t_auc, t_ppq, w=ca("is.active"))
                for smb in ["Sml0", "Med0", "Big0"]:
                    smb1 = smb.lower()
                    auc = ca(f"auc.{bs}.{atc}_AM1_{smb}.{pq}.p1")
                    auc = ca.RegYHat(auc, ca(f"ppq.{bs}.{atc}_{smb1}.{pq}.p1"), w=ca("is.active"))
                    ppq = ca(f"ppq_eod.{bs}.{atc}_{smb1}.{pq}.p1")
                    res.update(auc4(auc, ppq, f"auc4.{atc}.{bs}.{pq}.{smb}.am1"))
                res.update(auc4(t_auc, t_ppq, f"auc4.{atc}.{bs}.{pq}.am1"))
                res.update(auc4(auc_res, t_ppq, f"auc4.{atc}.{bs}.{pq}.am1res"))
    ## AM2与ppq的大中小单比率
    for atc in ["add"]:
        for bs in ["B", "S"]:
            for pq in ["q", "c"]:
                t_auc = ca(f"auc.{bs}.{atc}_AM2_Sml0.{pq}.p1") + ca(f"auc.{bs}.{atc}_AM2_Med0.{pq}.p1") + ca(f"auc.{bs}.{atc}_AM2_Big0.{pq}.p1")
                t_ppq = ca(f"ppq_eod.{bs}.{atc}_sml0.{pq}.p1") + ca(f"ppq_eod.{bs}.{atc}_med0.{pq}.p1") + ca(f"ppq_eod.{bs}.{atc}_big0.{pq}.p1")
                auc_res = ca.RegRes(t_auc, t_ppq, w=ca("is.active"))
                for smb in ["Sml0", "Med0", "Big0"]:
                    smb1 = smb.lower()
                    auc = ca(f"auc.{bs}.{atc}_AM2_{smb}.{pq}.p1")
                    auc = ca.RegYHat(auc, ca(f"ppq.{bs}.{atc}_{smb1}.{pq}.p1"), w=ca("is.active"))
                    ppq = ca(f"ppq_eod.{bs}.{atc}_{smb1}.{pq}.p1")
                    res.update(auc4(auc, ppq, f"auc4.{atc}.{bs}.{pq}.{smb}.am2"))
                res.update(auc4(t_auc, t_ppq, f"auc4.{atc}.{bs}.{pq}.am2"))
                res.update(auc4(auc_res, t_ppq, f"auc4.{atc}.{bs}.{pq}.am2res"))
    ## trd不分买卖单
    for atc in ["trd"]:
        for pq in ["q", "c"]:
            t_auc_B = ca(f"auc.B.{atc}_AM2_Sml0.{pq}.p1") + ca(f"auc.B.{atc}_AM2_Med0.{pq}.p1") + ca(f"auc.B.{atc}_AM2_Big0.{pq}.p1")
            t_ppq_B = ca(f"ppq_eod.B.{atc}_sml0.{pq}.p1") + ca(f"ppq_eod.B.{atc}_med0.{pq}.p1") + ca(f"ppq_eod.B.{atc}_big0.{pq}.p1")
            t_auc_S = ca(f"auc.S.{atc}_AM2_Sml0.{pq}.p1") + ca(f"auc.S.{atc}_AM2_Med0.{pq}.p1") + ca(f"auc.S.{atc}_AM2_Big0.{pq}.p1")
            t_ppq_S = ca(f"ppq_eod.S.{atc}_sml0.{pq}.p1") + ca(f"ppq_eod.S.{atc}_med0.{pq}.p1") + ca(f"ppq_eod.S.{atc}_big0.{pq}.p1")
            t_auc = t_auc_B + t_auc_S
            t_ppq = t_ppq_B + t_ppq_S
            auc_res = ca.RegRes(t_auc, t_ppq, w=ca("is.active"))
            for smb in ["Sml0", "Med0", "Big0"]:
                smb1 = smb.lower()
                auc_B = ca.RegYHat(ca(f"auc.B.{atc}_AM2_{smb}.{pq}.p1"), ca(f"ppq.B.{atc}_{smb1}.{pq}.p1"), w=ca("is.active"))
                auc_S = ca.RegYHat(ca(f"auc.S.{atc}_AM2_{smb}.{pq}.p1"), ca(f"ppq.S.{atc}_{smb1}.{pq}.p1"), w=ca("is.active"))
                auc = auc_B + auc_S 
                ppq_B = ca(f"ppq_eod.B.{atc}_{smb1}.{pq}.p1")
                ppq_S = ca(f"ppq_eod.S.{atc}_{smb1}.{pq}.p1")
                ppq = ppq_B + ppq_S
                res.update(auc4(auc, ppq, f"auc4.{atc}.{pq}.{smb}.am2"))
            res.update(auc4(t_auc, t_ppq, f"auc4.{atc}.{pq}.am2"))
            res.update(auc4(auc_res, t_ppq, f"auc4.{atc}.{pq}.am2res"))
    res0 = {k:ca.XsZScore(v) for k, v in rdcp(res).items()}
    res1 = {k:ca.XsZScore(v) for k, v in rdcp1(res).items()}
    node.node_config["CA.terms"].update(res0)
    node.node_config["CA.terms"].update(res1)
    return node, 0


def genr_auc5():
    node = init("auc5")
    res = {}
    ## AM1 Add 和 Cxl的比值
    for bs in ["B", "S"]:
        for pq in ["pq", "q", "c"]:
            for smb in ["Sml0", "Med0", "Big0"]:
                add = ca(f"auc.{bs}.add_AM1_{smb}.{pq}.p1")
                cxl = ca(f"auc.{bs}.cxl_AM1_{smb}.{pq}.p1")
                res.update(auc5(cxl, add, f"auc5.{bs}.{pq}.{smb}.am1"))
            t_add = ca(f"auc.{bs}.add_AM1_Sml0.{pq}.p1") + ca(f"auc.{bs}.add_AM1_Med0.{pq}.p1") + ca(f"auc.{bs}.add_AM1_Big0.{pq}.p1")
            t_cxl = ca(f"auc.{bs}.cxl_AM1_Sml0.{pq}.p1") + ca(f"auc.{bs}.cxl_AM1_Med0.{pq}.p1") + ca(f"auc.{bs}.cxl_AM1_Big0.{pq}.p1")
            res.update(auc5(t_cxl, t_add, f"auc5.{bs}.{pq}.am1"))
    res0 = {k:ca.XsZScore(v) for k, v in rdcp(res).items()}
    res1 = {k:ca.XsZScore(v) for k, v in rdcp1(res).items()}
    node.node_config["CA.terms"].update(res0)
    node.node_config["CA.terms"].update(res1)
    return node, 0


def genr_auc6():
    node = init("auc6")
    res = {}
    # AM1 单子的平均大小
    for atc in ["add", "cxl"]:
        for bs in ["B", "S"]:
            t_auc_pq = ca(f"auc.{bs}.{atc}_AM1_Sml0.pq.p1") + ca(f"auc.{bs}.{atc}_AM1_Med0.pq.p1") + ca(f"auc.{bs}.{atc}_AM1_Big0.pq.p1")
            t_auc_c  = ca(f"auc.{bs}.{atc}_AM1_Sml0.c.p1") + ca(f"auc.{bs}.{atc}_AM1_Med0.c.p1") + ca(f"auc.{bs}.{atc}_AM1_Big0.c.p1")
            for smb in ["Sml0", "Med0", "Big0"]:
                auc_pq = ca(f"auc.{bs}.{atc}_AM1_{smb}.pq.p1")
                auc_c = ca(f"auc.{bs}.{atc}_AM1_{smb}.c.p1")
                res.update(auc6(auc_pq, auc_c, f"auc6.{atc}.{bs}.{smb}.am1"))
            res.update(auc6(t_auc_pq, t_auc_c, f"auc6.{atc}.{bs}.am1"))
    # AM2单子的平均大小
    for atc in ["add"]:
        for bs in ["B", "S"]:
            t_auc_pq = ca(f"auc.{bs}.{atc}_AM2_Sml0.pq.p1") + ca(f"auc.{bs}.{atc}_AM2_Med0.pq.p1") + ca(f"auc.{bs}.{atc}_AM2_Big0.pq.p1")
            t_auc_c  = ca(f"auc.{bs}.{atc}_AM2_Sml0.c.p1") + ca(f"auc.{bs}.{atc}_AM2_Med0.c.p1") + ca(f"auc.{bs}.{atc}_AM2_Big0.c.p1")
            for smb in ["Sml0", "Med0", "Big0"]:
                auc_pq = ca(f"auc.{bs}.{atc}_AM2_{smb}.pq.p1")
                auc_c = ca(f"auc.{bs}.{atc}_AM2_{smb}.c.p1")
                res.update(auc6(auc_pq, auc_c, f"auc6.{atc}.{bs}.{smb}.am2"))
            res.update(auc6(t_auc_pq, t_auc_c, f"auc6.{atc}.{bs}.am2"))
    for atc in ["trd"]:
        for bs in ["B", "S"]:
            t_auc_q = ca(f"auc.{bs}.{atc}_AM2_Sml0.q.p1") + ca(f"auc.{bs}.{atc}_AM2_Med0.q.p1") + ca(f"auc.{bs}.{atc}_AM2_Big0.q.p1")
            t_auc_c  = ca(f"auc.{bs}.{atc}_AM2_Sml0.c.p1") + ca(f"auc.{bs}.{atc}_AM2_Med0.c.p1") + ca(f"auc.{bs}.{atc}_AM2_Big0.c.p1")
            for smb in ["Sml0", "Med0", "Big0"]:
                auc_q = ca(f"auc.{bs}.{atc}_AM2_{smb}.q.p1")
                auc_c = ca(f"auc.{bs}.{atc}_AM2_{smb}.c.p1")
                res.update(auc6(auc_q*ca("auc.BS.all.iep_AM2.p1"), auc_c, f"auc6.{atc}.{bs}.{smb}.am2"))
            res.update(auc6(t_auc_q*ca("auc.BS.all.iep_AM2.p1"), t_auc_c, f"auc6.{atc}.{bs}.am2"))
    res0 = {k:ca.XsZScore(v) for k, v in rdcp(res).items()}
    res1 = {k:ca.XsZScore(v) for k, v in rdcp1(res).items()}
    node.node_config["CA.terms"].update(res0)
    node.node_config["CA.terms"].update(res1)
    return node, 0


def genr_auc7():
    node = init("auc7")
    res = {}
    # AM1的价格是否触及涨跌停
    res["auc7.hl.am1"] = ca("auc.BS.all.iep_max_AM1.p1") > ca.C(0.995) * ca("high.limit")
    res["auc7.ll.am1"] = ca("auc.BS.all.iep_min_AM1.p1") < ca.C(0.995) * ca("low.limit")
    ## 过去5天的日均触及次数
    res["auc7.hl.am1.5"] = ca.TsMean(res["auc7.hl.am1"], 5)
    res["auc7.ll.am1.5"] = ca.TsMean(res["auc7.ll.am1"], 5)
    # AM2的价格是否触及涨跌停
    # AM1的价格是否触及涨跌停
    res["auc7.hl.am2"] = ca("auc.BS.all.iep_max_AM2.p1") > ca.C(0.995) * ca("high.limit")
    res["auc7.ll.am2"] = ca("auc.BS.all.iep_min_AM2.p1") < ca.C(0.995) * ca("low.limit")
    ## 过去5天的日均触及次数
    res["auc7.hl.am2.5"] = ca.TsMean(res["auc7.hl.am2"], 5)
    res["auc7.ll.am2.5"] = ca.TsMean(res["auc7.ll.am2"], 5)

    # AM1的最高价离涨停的距离、最低价离跌停的距离
    res["auc7.h2hl.am1"] = (ca("high.limit") - ca("auc.BS.all.iep_max_AM1.p1")) / ca("high.limit")
    res["auc7.l2ll.am1"] = (ca("auc.BS.all.iep_min_AM1.p1") - ca("low.limit")) / ca("low.limit")
    ## 过去5天的日均
    res["auc7.h2hl.am1.5"] = ca.TsMean(res["auc7.h2hl.am1"], 5)
    res["auc7.l2ll.am1.5"] = ca.TsMean(res["auc7.l2ll.am1"], 5)
    # AM2同理
    res["auc7.h2hl.am2"] = (ca("high.limit") - ca("auc.BS.all.iep_max_AM2.p1")) / ca("high.limit")
    res["auc7.l2ll.am2"] = (ca("auc.BS.all.iep_min_AM2.p1") - ca("low.limit")) / ca("low.limit")
    ## 过去5天的日均
    res["auc7.h2hl.am2.5"] = ca.TsMean(res["auc7.h2hl.am2"], 5)
    res["auc7.l2ll.am2.5"] = ca.TsMean(res["auc7.l2ll.am2"], 5)

    # AM1、2最高价之差、最低价之差
    res["auc7.h12s"] = (ca("auc.BS.all.iep_max_AM1.p1") - ca("auc.BS.all.iep_max_AM2.p1")) / ca("auc.BS.all.iep_AM2.p1")
    res["auc7.l12s"] = (ca("auc.BS.all.iep_min_AM1.p1") - ca("auc.BS.all.iep_min_AM2.p1")) / ca("auc.BS.all.iep_AM2.p1")
    ## 五日平均
    res["auc7.h12s.5"] = ca.TsMean(res["auc7.h12s"], 5)
    res["auc7.l12s.5"] = ca.TsMean(res["auc7.l12s"], 5)
    res0 = {k:ca.XsZScore(v) for k, v in rdcp(res).items()}
    res1 = {k:ca.XsZScore(v) for k, v in rdcp1(res).items()}
    node.node_config["CA.terms"].update(res0)
    node.node_config["CA.terms"].update(res1)
    return node, 0


def genr_auc8():
    node = init("auc8")
    res = {}
    res["auc8.qty1.ratio"] = ca("auc.BS.all.qty_AM1.p1") / (ca("auc.BS.all.qty_AM1.p1") + ca("auc.BS.all.qty_AM2.p1") + ca.C(1))
    res["auc8.qty2.ratio"] = ca("auc.BS.all.qty_AM2.p1") / (ca("auc.BS.all.qty_AM1.p1") + ca("auc.BS.all.qty_AM2.p1") + ca.C(1))
    res["auc8.qty1.ratio"] = ca.RegYHat(res["auc8.qty1.ratio"], ca("volumeTotal"), w=ca("is.active"))
    res["auc8.qty2.ratio"] = ca.RegYHat(res["auc8.qty2.ratio"], ca("volumeTotal"), w=ca("is.active"))
    res["auc8.qty12.res"] = ca.RegRes(res["auc8.qty1.ratio"], res["auc8.qty2.ratio"], w=ca("is.active"))
    res["auc8.qty21.res"] = ca.RegRes(res["auc8.qty2.ratio"], res["auc8.qty1.ratio"], w=ca("is.active"))
    res["auc8.qty1.ratio.5"] = ca.TsMean(res["auc8.qty1.ratio"], 5)
    res["auc8.qty2.ratio.5"] = ca.TsMean(res["auc8.qty2.ratio"], 5)
    res["auc8.qty12.res.5"] = ca.TsMean(res["auc8.qty12.res"], 5)
    res["auc8.qty21.res.5"] = ca.TsMean(res["auc8.qty21.res"], 5)
    res["auc8.ratio.corr"] = ca.TsCorr([res["auc8.qty1.ratio"], res["auc8.qty2.ratio"]], 5)
    res["auc8.res.corr"] = ca.TsCorr([res["auc8.qty12.res"], res["auc8.qty21.res"]], 5)
    res0 = {k:ca.XsZScore(v) for k, v in rdcp(res).items()}
    res1 = {k:ca.XsZScore(v) for k, v in rdcp1(res).items()}
    node.node_config["CA.terms"].update(res0)
    node.node_config["CA.terms"].update(res1)
    return node, 0


def genr_auc9():
    node = init("auc9")
    res = {}

    node.node_config["DATA.panels"] += ["ppqeod"]
    node.node_config["DATA.ppqeod.pattern"] = "/data/beef2/guopeng/auction/eod_stats/ppq_stats/000.ca.ppq_stats/eod.YYYYMMDD.sdiv"
    node.node_config["DATA.ppqeod.inclusive"] = False 
    node.node_config["DATA.ppqeod.lb_days"] = 5 

    t_intra = ca.C(0)
    for _t in read_columns_from_pattern(node.node_config["DATA.ppqeod.pattern"]):
        if 'trd' in _t:
            t_intra += ca(_t)
    ## 开盘集合竞价和日内交易量的对比
    ## AM1、AM2与日内交易量的比率
    res["auc9.qty_AM1"] = ca("auc.BS.all.qty_AM1.p1") / t_intra
    res["auc9.qty_AM2"] = ca("auc.BS.all.qty_AM2.p1") / t_intra

    res["auc9.qty_AM1.yhat"] = ca.RegYHat(ca("auc.BS.all.qty_AM1.p1"), ca("volumeTotal"), w=ca("is.active")) / t_intra
    res["auc9.qty_AM2.yhat"] = ca.RegYHat(ca("auc.BS.all.qty_AM2.p1"), ca("volumeTotal"), w=ca("is.active")) / t_intra
    ## PM与日内交易量的比率
    res["auc9.qty_PM"] = ca('auc_eod.BS.all.qty_PM.p1') / t_intra
    res["auc9.qty_PM.yhat"] = ca.RegYHat(ca('auc_eod.BS.all.qty_PM.p1'), ca("volumeTotal"), w=ca("is.active")) / t_intra
    res0 = {k+".5":ca.TsMean(v, 5) for k, v in res.items()}
    res1 = {k+".tsr":ca.TsRank(v, 5) for k, v in res.items()}
    res2 = {k+".cor":ca.TsCorr([v, ca.XsRank("volumeTotal")], 5) for k, v in res.items()}
    res.update(res0)
    res.update(res1)
    res.update(res2)
    res0 = {k:ca.XsZScore(v) for k, v in rdcp(res).items()}
    res1 = {k:ca.XsZScore(v) for k, v in rdcp1(res).items()}
    node.node_config["CA.terms"].update(res0)
    node.node_config["CA.terms"].update(res1)
    return node, 0


genr_open_func = [
    # genr_auc1, 
    # genr_auc2, 
    # genr_auc3 
    # genr_auc4
    # genr_auc5
    # genr_auc6
    # genr_auc7
    # genr_auc8
    genr_auc9
]

if __name__ == '__main__':
    for func in genr_open_func:
        min5_node, res = func()
        min5_node.seq_id = 0
        test_run = False
        dump_all = False
        y = "mret24h"

        min5_node.set_run_dates()

        if not test_run:
            if not os.path.isdir(min5_node.stage_dir() / "000.stats"):
                min5_node.run_periods = [date for date in min5_node.run_periods if date>= 20180101]
                min5_node.node_config["OUTPUT.terms"] = False
                min5_node.node_config["OUTPUT.stats"] = True
                # min5_node.run(para_spec="ps1:16,ps2:96,ps3:16,ps4:16,ps7:64,ps8:64")
                # min5_node.run(para_spec="ps1:8,ps2:16,ps3:8,ps4:8,ps7:8,ps8:8")
                min5_node.run("128")
                stats_node = StatsNode({
                    "wgts":["w_c1"],
                    # "wgts":["w_c1"],
                    "is_start":20180101,
                    "vd_start":20210101,
                    "os_start":20230101,
                    "end_date":20241231,
                }, xy_pattern=min5_node).run(
                    print_df=True, refresh_data=True, verbose_ys=[y], y_label=y, 
                    corr_threshold=0.9, threshold_dict={
                        y: {
                            "FR":2,
                            "SR":2,
                        },
                    })
                df, ss, selected = StatsNode.read_stats(stats_node.stage_dir())
                def reverse_filtering(df, ss):
                    idx = df.dropna().index.get_level_values(2)
                    filtered_old = read_non_empty_lines(stats_node.stage_dir()/"filtered.txt")
                    return [i for i in list(ss.keys()) if i not in filtered_old and i in idx]
                def new_selection(ss, filtered):
                    result = basic_selection(ss, filtered, y_label=y, wgt="w_c1", corr_threshold=0.3, threshold_dict={y: {"FR":0.5,"SR":0.5},})
                    return result
                filtered, selected = stats_node.term_selection(
                    df, ss, 
                    filtering_func=reverse_filtering, filtering_label="filtered2",
                    selection_func=new_selection, selection_label="selected2",
                )
                stats_node.print_selected_df(df, ss, filtered, selected, verbose_ys=[y])
                print("selection done!")
            else:
                if dump_all:
                    min5_node.node_config["OUTPUT.terms"] = True
                    min5_node.node_config["OUTPUT.stats"] = False
                    min5_node.run("128")
                    sys.exit(0)
                min5_node.run_periods = [date for date in min5_node.run_periods if date>= 20180101]
                min5_node.node_config["OUTPUT.terms"] = True
                min5_node.node_config["OUTPUT.stats"] = False
                min5_node.node_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
                selected1 = read_non_empty_lines(os.path.join(ca_find(min5_node.stage_dir(), "stats_dir"), "selected.txt"))
                selected2 = read_non_empty_lines(os.path.join(ca_find(min5_node.stage_dir(), "stats_dir"), "selected2.txt"))
                # run selected1
                min5_node.keep_selected(selected=selected1)
                min5_node.node_config["OUTPUT.terms.file_prefix"] = "selected1."
                min5_node.conf_name = "config1.json"
                min5_node.run(para_spec="156")
                
        else:
            min5_node.node_config["OUTPUT.terms"] = True
            min5_node.node_config["OUTPUT.stats"] = True
            min5_node.run_date(20230724)