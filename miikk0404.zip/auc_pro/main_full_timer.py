import copy
import sys
from jobs.rnodes.rnode import RNode, SlurmCfg
from canopus_py.rnodes.ca_node import CANode

from canopus_py.ca_expr import *
from canopus_py.ca_stats import *
from canopus_py.rnodes.stats_node import StatsNode, basic_selection
from terms_open import *

y_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/Y/Y_V5/terms.YYYYMMDD.sdiv"
min5_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/I/fq5m/BB/terms.YYYYMMDD.sdiv"
st_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/D/eod/sid_st/st_YYYYMMDD.sdiv"

baseline_pattern = "/data/beef2/junming/croll_alpha/subalpha20240710/terms.YYYYMMDD.sdiv"
con_pattern = "/data/beef2/guopeng/concept_project/con2/con.YYYYMMDD.sdiv"
rdcp_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/I/fq5m/ResRet/rdcp/terms.YYYYMMDD.sdiv"
rs_pattern = "/data/nfs0/chinaEquityData/panel/daily-rollstats/daily-rollstats-YYYYMMDD.sdiv"
sv_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/I/fq5m/ResV/sv0/terms.YYYYMMDD.sdiv"
cap_pattern = "/data/nfs0/chinaEquityData/panel/cap/cap-YYYYMMDD.sdiv"
pq_pattern = "/data/beef2/mike/shared/ppq_bms/ppq_slurm_test_G2548_fix/000.pq/YYYYMMDD.sdiv"
dailyadj_pattern = "/data/nfs0/chinaEquityData/panel/daily-adjusted-2007/morning/daily-adjusted-YYYYMMDD.sdiv"

open_pattern = "/data/beef2/mike/shared/auc_stats/open_new/YYYYMMDD.sdiv"


def init(task_name):
    RNode.RNODE_ROOT = "/data/beef2/guopeng/auction/full_timer"
    RNode.GLOBAL_TASKNAME = task_name
    CANode.DEFAULT_CA_BINARY = "/data/beef2/bin/unstable/canopus"

    base_config = CANode.base_config()

    base_config["EVENTS.busdate_pattern"] = y_pattern
    base_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    base_config["EVENTS.gf_weeks"] = 1
    
    base_config["DATA.panels"] += ["open"]
    base_config["DATA.open.pattern"] = f"/data/beef2/guopeng/auction/{task_name}/000.ca.{task_name}/selected1.YYYYMMDD.sdiv"
    base_config["DATA.open.inclusive"] = True

    base_config["DATA.panels"] += ["5min"]
    base_config["DATA.5min.pattern"] = min5_pattern
    
    base_config["DATA.panels"] += ["st"]
    base_config["DATA.st.pattern"] = st_pattern
    base_config["DATA.st.inclusive"] = False

    base_config["DATA.panels"] += ["univ"]
    base_config["DATA.univ.pattern"] = "/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv"
    # base_config["DATA.univ.columns"] = ["topx"]
    base_config["DATA.univ.inclusive"] = True

    base_config["DATA.panels"] += ["Y"]
    base_config["DATA.Y.pattern"] = y_pattern
    base_config["DATA.Y.columns"] = ["mret24h", "bret24h", "mret1h"]

    base_config["OUTPUT.stats"] = True
    base_config["STATS.y_terms"] = {
        "mret1h": "mret1h", "mret24h": "mret24h", 
        "bret24h": "bret24h", 
        }

    base_config["STATS.w_terms"] = {
        # "w_c1": ca.C(1), 
        # "w_c1": ca("topx")*(ca.C(1)-ca("st")),
        "w_c1": ca.C(1)-ca("st"),
        }
    res = {k+".1":ca(k) for k in read_columns_from_pattern(base_config["DATA.open.pattern"])}
    return CANode(copy.deepcopy(base_config), label=task_name), res

if __name__ == '__main__':
    min5_node, res = init("auc9")
    min5_node.node_config["CA.terms"].update(res)
    test_run = False
    dump_all = False
    y = "mret24h"

    min5_node.set_run_dates()

    if not test_run:
        if not os.path.isdir(min5_node.stage_dir() / "000.stats"):
            min5_node.run_periods = [date for date in min5_node.run_periods if date>= 20180101]
            min5_node.node_config["OUTPUT.terms"] = False
            min5_node.node_config["OUTPUT.stats"] = True

            # min5_node.run(para_spec="ps1:16,ps2:96,ps3:16,ps4:16,ps7:64,ps8:64")
            # min5_node.run(para_spec="ps1:8,ps2:16,ps3:8,ps4:8,ps7:8,ps8:8")
            min5_node.run("32")
            stats_node = StatsNode({
                "wgts":["w_c1"],
                # "wgts":["w_c1"],
                "is_start":20180101,
                "vd_start":20210101,
                "os_start":20230101,
                "end_date":20241231,
            }, xy_pattern=min5_node).run(
                print_df=True, refresh_data=True, verbose_ys=[y], y_label=y, 
                corr_threshold=0.8, threshold_dict={
                    y: {
                        "FR":2,
                        "SR":2,
                    },
                })
            df, ss, selected = StatsNode.read_stats(stats_node.stage_dir())
            def reverse_filtering(df, ss):
                idx = df.dropna().index.get_level_values(2)
                filtered_old = read_non_empty_lines(stats_node.stage_dir()/"filtered.txt")
                return [i for i in list(ss.keys()) if i not in filtered_old and i in idx]
            def new_selection(ss, filtered):
                result = basic_selection(ss, filtered, y_label=y, wgt="w_c1", corr_threshold=0.3, threshold_dict={y: {"FR":0.5,"SR":0.5},})
                return result
            filtered, selected = stats_node.term_selection(
                df, ss, 
                filtering_func=reverse_filtering, filtering_label="filtered2",
                selection_func=new_selection, selection_label="selected2",
            )
            stats_node.print_selected_df(df, ss, filtered, selected, verbose_ys=[y])
            print("selection done!")
        else:
            if dump_all:
                min5_node.node_config["OUTPUT.terms"] = True
                min5_node.node_config["OUTPUT.stats"] = False
                min5_node.run("128")
                sys.exit(0)
            min5_node.run_periods = [date for date in min5_node.run_periods if date>= 20180101]
            min5_node.node_config["OUTPUT.terms"] = True
            min5_node.node_config["OUTPUT.stats"] = False
            min5_node.node_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
            selected1 = read_non_empty_lines(os.path.join(ca_find(min5_node.stage_dir(), "stats_dir"), "selected.txt"))
            selected2 = read_non_empty_lines(os.path.join(ca_find(min5_node.stage_dir(), "stats_dir"), "selected2.txt"))
            # run selected1
            min5_node.keep_selected(selected=selected1)
            min5_node.node_config["OUTPUT.terms.file_prefix"] = "selected1."
            min5_node.conf_name = "config1.json"
            min5_node.run(para_spec="156")
            
    else:
        min5_node.node_config["OUTPUT.terms"] = True
        min5_node.node_config["OUTPUT.stats"] = True
        min5_node.run_date(20230724)