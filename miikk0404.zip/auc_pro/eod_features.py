import copy
import sys
from jobs.rnodes.rnode import RNode, SlurmCfg
from canopus_py.rnodes.ca_node import CANode

from canopus_py.ca_expr import *
from canopus_py.ca_stats import *
from canopus_py.rnodes.stats_node import StatsNode, basic_selection
from terms_open import *

y_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/Y/Y_V5/terms.YYYYMMDD.sdiv"
min5_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/I/fq5m/BB/terms.YYYYMMDD.sdiv"
st_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/D/eod/sid_st/st_YYYYMMDD.sdiv"

baseline_pattern = "/data/beef2/junming/croll_alpha/subalpha20240710/terms.YYYYMMDD.sdiv"
con_pattern = "/data/beef2/guopeng/concept_project/con2/con.YYYYMMDD.sdiv"
rdcp_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/I/fq5m/ResRet/rdcp/terms.YYYYMMDD.sdiv"
rs_pattern = "/data/nfs0/chinaEquityData/panel/daily-rollstats/daily-rollstats-YYYYMMDD.sdiv"
sv_pattern = "/data/beef3/data/CA.v24.1001.new_active/CNEQ/Panels/I/fq5m/ResV/sv0/terms.YYYYMMDD.sdiv"
cap_pattern = "/data/nfs0/chinaEquityData/panel/cap/cap-YYYYMMDD.sdiv"
pq_pattern = "/data/beef2/mike/shared/ppq_bms/ppq_slurm_test_G2548_fix/000.pq/YYYYMMDD.sdiv"
dailyadj_pattern = "/data/nfs0/chinaEquityData/panel/daily-adjusted-2007/morning/daily-adjusted-YYYYMMDD.sdiv"

open_pattern = "/data/beef2/mike/shared/auc_stats/open_new/YYYYMMDD.sdiv"
auceod_pattern = "/data/beef2/mike/shared/auc_stats/eod_new/eod.YYYYMMDD.sdiv"

def init(task_name):
    RNode.RNODE_ROOT = "/data/beef2/guopeng/auction/eod_stats"
    RNode.GLOBAL_TASKNAME = task_name
    CANode.DEFAULT_CA_BINARY = "/data/beef2/bin/unstable/canopus"

    base_config = CANode.base_config(market="CNEQ")

    base_config["EVENTS.busdate_pattern"] = y_pattern
    base_config["CA.univ"] = "/data/beef2/data/CA/CNEQ/Univs/G2548_220731.csv"
    base_config["OUTPUT.eod_terms"] = True
    # base_config["CA.univ"] = "/data/nasData/chinaEquityData/panel/univ/univ-YYYYMMDD.sdiv:topx"
    base_config["EVENTS.gf_weeks"] = 1
    

    base_config["DATA.panels"] += ["5min"]
    base_config["DATA.5min.pattern"] = min5_pattern
    base_config["DATA.5min.lb_days"] = 5
    
    base_config["DATA.panels"] += ["st"]
    base_config["DATA.st.pattern"] = st_pattern
    base_config["DATA.st.inclusive"] = False

    base_config["DATA.panels"] += ['adj']
    base_config["DATA.adj.pattern"] = dailyadj_pattern
    base_config["DATA.adj.columns"] = ['adj.factor.locf']
    base_config["DATA.adj.lb_days"] = 5 
    base_config["DATA.adj.inclusive"] = True 

    base_config["DATA.panels"] += ["rdcp"]
    base_config["DATA.rdcp.pattern"] = rdcp_pattern
    base_config["DATA.rdcp.columns"] = read_columns_from_pattern(rdcp_pattern)
    base_config["DATA.rdcp.lb_days"] = 5

    base_config["DATA.panels"] += ["sv"]
    base_config["DATA.sv.pattern"] = sv_pattern
    base_config["DATA.sv.columns"] = read_columns_from_pattern(sv_pattern)
    base_config["DATA.sv.lb_days"] = 5

    base_config["DATA.panels"] += ["rs"]
    base_config["DATA.rs.pattern"] = rs_pattern
    base_config["DATA.rs.columns"] = read_columns_from_pattern(rs_pattern)
    base_config["DATA.rs.inclusive"] = False
    base_config["DATA.rs.lb_days"] = 5

    base_config["DATA.panels"] += ["cap"]
    base_config["DATA.cap.pattern"] = cap_pattern
    base_config["DATA.cap.columns"] = read_columns_from_pattern(cap_pattern)
    base_config["DATA.cap.inclusive"] = False
    base_config["DATA.cap.lb_days"] = 5

    base_config["DATA.panels"] += ["pq"]
    base_config["DATA.pq.pattern"] = pq_pattern
    base_config["DATA.pq.lb_days"] = 5


    base_config["DATA.panels"] += ["barra"]
    base_config["DATA.barra.pattern"] = "/data/nfs0/chinaEquityData/panel/barra/exp-YYYYMMDD.sdiv"
    base_config["DATA.barra.columns"] = inds_CNE5 + stls_CNE5
    base_config["DATA.barra.inclusive"] = False
    base_config["DATA.barra.lb_days"] = 3

    return CANode(copy.deepcopy(base_config), label=task_name)


def ret_stats():
    min5_node = init("ret_stats")
    stats = {}
    # stats["rret.std.intra"] = ca.TsStd(ca.IfElse(ca.IIndex()==ca.C(1), ca.C(0), ca("backward.ret5m")), 48)
    for r in read_columns_from_pattern(rdcp_pattern):
        stats[f"{r}.std.intra"] = ca.TsStd(ca.IfElse(ca.IIndex()==ca.C(1), ca.C(0), ca(r)), 48)
        stats[f"{r}.over"] = ca.UpdateOn(r, ca.IIndex()==ca.C(1))
        stats[f"{r}.mean"] = ca.TsMean(r, 48)
    min5_node.node_config["CA.terms"].update(stats)
    return min5_node

def ppq_stats():
    min5_node = init("ppq_stats")
    stats = {}
    for pq_col in read_columns_from_pattern(pq_pattern):
        stats[pq_col.replace("ppq", "ppq_eod")] = ca(pq_col)
    min5_node.node_config["CA.terms"].update(stats)
    return min5_node


if __name__ == "__main__":
    # min5_node = ret_stats()
    min5_node = ppq_stats()
    min5_node.set_run_dates()
    min5_node.run("16")

