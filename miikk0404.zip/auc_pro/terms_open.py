from canopus_py.ca_expr import *
from canopus_py.ca_stats import *

### barra
inds_CNE5 = [
    'AEROSPCE', 'AIRLINES', 'APPAREL', 'AUTOCOMP',
    'BANKS', 'BEVTOB', 'BLDPROD', 'COMMSVCS', 'CHEMICAL', 'CONGTRD',
    'CNSTENG', 'CONMAT', 'CONSDUR', 'CONSRV', 'DIVFINAN', 'ELECEQP',
    'ENERGY', 'FOODPROD', 'FSTAPHPP', 'HDWRSE', 'HEALTH', 'MACHINRY',
    'MARINE', 'MEDIA', 'MTLMIN', 'OTHRCHEM', 'PACKGFP', 'REALEST', 'RETAIL',
    'RDRLTRAN', 'SOFTWARE', 'UTILITY',
]


stls_CNE5 = [
    'ANLYSTSN', 'BETA', 'BTOP', 'DIVYILD', 'EARNQLTY', 'EARNVAR',
    'EARNYILD', 'GROWTH', 'INDMOM', 'INVSQLTY', 'LEVERAGE', 'LIQUIDTY',
    'LTREVRSL', 'MIDCAP', 'MOMENTUM', 'PROFIT', 'RESVOL', 'SEASON',
    'STREVRSL', 'SIZE'
]

rdcp_pattern = "/data/beef2/data/CA/CNEQ/Panels/I/freq_5m/ResRet/rdcp/terms.YYYYMMDD.sdiv"

def rdcp(terms_dict, include_original=True, lite=False, types=None):
    factors_ind = inds_CNE5
    factors_stl = stls_CNE5
    factors_CNE5D = factors_ind+factors_stl  # exclude "COUNTRY"
    factors_all = [ca.Na20(i) for i in factors_CNE5D]
    result = {}
    for k, v in terms_dict.items():
        if include_original:
            result[f"{k}.o"] = v
        result[f"{k}.b"]   = ca.RegRes(ca.Na20(v), factors_all, w=ca("is.active"))
        result[f"{k}.bp"]  = ca.RegYHat(ca.Na20(v), factors_all, w=ca("is.active"))
    if types is not None:
        result = {k:v for k,v in result.items() if k.split(".")[-1] in types}
    return result


def rdcp1(terms_dict, include_original=True, lite=False, types=None):
    factors_ind = inds_CNE5
    factors_stl = stls_CNE5
    # factors_CNE5D = factors_ind+factors_stl  # exclude "COUNTRY"
    factors_CNE5D = factors_ind+factors_stl  # exclude "COUNTRY"
    factors_all = [ca.Na20(i) for i in factors_CNE5D]
    result = {}
    for k, v in terms_dict.items():
        if include_original:
            result[f"{k}.o"] = v
        result[f"{k}.b1"] = ca.C(0)
        result[f"{k}.bp1"] = ca.C(0)
        for univ in factors_ind:
            result[f"{k}.b1"]  += ca.RegRes(ca.Na20(v), factors_stl, w=ca(univ))*ca(univ)
            result[f"{k}.bp1"] += ca.RegYHat(ca.Na20(v), factors_stl, w=ca(univ))*ca(univ)
    if types is not None:
        result = {k:v for k,v in result.items() if k.split(".")[-1] in types}
    return result


def auc1(b, s, name):
    """[] 买卖add order match以后 剩余的qty和price  做imbalance （可能只剩qty了）"""
    terms = {}
    terms[f"{name}.imb0"] = (ca.Log(b+ca.C(1)) - ca.Log(s+ca.C(1)))*ca.Log(b+s+ca.C(1))
    terms[f"{name}.imb1"] = (ca(s) - ca(b)) / (ca(b) + ca(s) + ca.C(1))
    return terms 


def auc2(over, intra, name):
    """
    [] 隔夜日内 波动比例，以及按天的变化
    """
    return 

def auc3(x, t, name):
    """
    [] 开盘集合竞价 大中小单占比 以及按天的变化
    [] 收盘集合竞价 大中小单占比 以及按天的变化
    """
    terms = {}
    p = x / t
    terms[f"{name}.p"] = p
    terms[f"{name}.tsrp"] = ca.TsRank(p, 5)
    terms[f"{name}.chg"] = ca.TsDelta(p, 1) / ca.TsSum(p, 5)
    return terms  


def auc4(x, t, name):
    """
    [] 集合竞价和 日内交易 大中小单情况的对比
    """
    terms = {}
    p = x / t
    terms[f"{name}.p"] = p
    terms[f"{name}.tsrp"] = ca.TsRank(p, 5)
    terms[f"{name}.chg"] = ca.TsDelta(p, 1) / ca.TsSum(p, 5)
    return terms  


def auc5(x, t, name):
    """
    [] add/cxl的对比比值，以及各个阶段平均单的大小，尤其是注意cxl带来的影响
    """
    terms = {}
    p = x / t
    terms[f"{name}.p"] = p
    terms[f"{name}.tsrp"] = ca.TsRank(p, 5)
    terms[f"{name}.chg"] = ca.TsDelta(p, 1) / ca.TsSum(p, 5)
    return terms  


def auc6(pq, c, name):
    """
    平均单的大小
    """
    terms = {}
    terms[name] = ca(pq) / (ca(c) + ca.C(1))
    return terms 


def auc7(iep, lim, name):
    """看iep是否触及涨停"""
    return 
