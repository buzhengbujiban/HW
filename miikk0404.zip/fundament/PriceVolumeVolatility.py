import acalc as ac
import xarray as xr
import numpy as np
from alpha_f.src.calc_alpha_new import VirtualCalcAlphaCore
from alpha_f.src import opt


@ac.node
class PriceVolumeVolatility(VirtualCalcAlphaCore):
    def __init__(self, config: dict):
        super().__init__(config)
    

    def customize_process_data(self):
        # 严格大于0的行情：ffill停牌的值，但凡listed都有值。
        for col in ['circ_share']:
            self.data[col] = self.data[col].where(self.data[col]>0).ffill(dim='D').where(self.meta_data['listed'])
        # close_locf: 只有trade_stat>0时才正确
        trade_mask = self.data['trade_stat']>0
        self.data['adj_close_locf'] = self.data['adj_close_locf'].where((self.data['adj_close_locf']>0)  & (trade_mask)).ffill(dim='D').where(self.meta_data['listed'])

        
        # trade_mask有值时才正确的值
        cap_col = ['close','turnover','volume']
        for col in cap_col:
            self.data[col] = self.data[col].where( (self.data[col]>0) & trade_mask)

    def cal_factor_volume(self):
        
        volume = self.data['volume']
        volume = volume.where(volume>100)
        turnover = self.data['turnover']
        turnover = turnover.where(turnover>100)
        close = self.data['adj_close_locf'] # 停牌会没有价格。
        circshare = self.data['circ_share']

        
        factor = {}
        n_window = len(close.D.values)
        factor['1D_VolumeSignal_ind0'] = -volume/ volume.rolling(D=min(120,n_window), min_periods=min(30, n_window)).mean() # negative
        factor['40D_VolumeSignal_ind0'] = -volume.rolling(D=min(40, n_window), min_periods=min(30, n_window)).mean()/ volume.rolling(D=min(120,n_window), min_periods=min(90, n_window)).mean()
        factor['50D_VolumeSignal'] = -volume.rolling(D=min(50, n_window), min_periods=min(40, n_window)).mean()/ volume.rolling(D=min(266,n_window), min_periods=min(240, n_window)).mean()
        
        # 30Day_GCV_Turn2Prc.ind0
        n=30
        GCV_price = opt.coefficient_of_variation(close, n=n, min_periods=20, method='lognormal')
        GCV_turnover = opt.coefficient_of_variation(turnover, n=n, min_periods=20, method='lognormal')
        factor[f'{n}Day_GCV_Turn2Prc_ind0'] = -GCV_turnover/GCV_price
        
        # 60Day_CV_Turn2Prc.indrank0
        n=60
        CV_price = opt.coefficient_of_variation(close, n=n, min_periods=20)
        CV_turnover = opt.coefficient_of_variation(turnover, n=n, min_periods=20)
        factor[f'{n}Day_CV_Turn2Prc_indrank0'] = -CV_turnover/CV_price
        
        # 20Day_GCV_Turn2Prc
        n=20
        GCV_price = opt.coefficient_of_variation(close, n=n, min_periods=20, method='lognormal')
        GCV_turnover = opt.coefficient_of_variation(turnover, n=n, min_periods=20, method='lognormal')
        factor[f'20Day_GCV_Turn2Prc'] = -GCV_turnover/GCV_price
        # 120Day_GCV_Turn2Prc_indrank0
        n=120
        GCV_price = opt.coefficient_of_variation(close, n=n, min_periods=20, method='lognormal')
        GCV_turnover = opt.coefficient_of_variation(turnover, n=n, min_periods=20, method='lognormal')
        factor[f'{n}Day_GCV_Turn2Prc_indrank0'] = -GCV_turnover/GCV_price

        # 250Day_CV_Turn2Prc_ind0
        n=250
        CV_price = opt.coefficient_of_variation(close, n=n, min_periods=20)
        CV_turnover = opt.coefficient_of_variation(turnover, n=n, min_periods=20)
        factor[f'{n}Day_CV_Turn2Prc_ind0'] = -CV_turnover/CV_price


        # money_flow_volume
        ret = self.data['ret'].where(self.data['trade_stat']>0)
        factor[f'3Day_MoneyFlowTurnover_ind0'] = -money_flow_turnover(ret=ret, turnover=turnover, n=3)
        factor[f'20Day_MoneyFlowTurnover_ind0'] = -money_flow_turnover(ret=ret, turnover=turnover, n=20)
        factor[f'10Day_MoneyFlowTurnover'] = -money_flow_turnover(ret=ret, turnover=turnover, n=10)

        factor['20D_WVP_indrank0'] = -ret_weighted_volume_of_circshare(n=20, ret=ret, volume=volume, circshare=circshare, min_periods=15)
        factor['40D_WVP_ind0'] = -ret_weighted_volume_of_circshare(n=40, ret=ret, volume=volume, circshare=circshare, min_periods=30)
        factor['60D_WVP_winsor'] =  -ret_weighted_volume_of_circshare(n=60, ret=ret, volume=volume, circshare=circshare, min_periods=40)
        factor['5D_WVP_indrank0'] = -ret_weighted_volume_of_circshare(n=5, ret=ret, volume=volume, circshare=circshare, min_periods=5)

        indrank0_col = [x for x in factor.keys() if x.endswith('indrank0')]
        ind0_WVP_col = ['40D_WVP_ind0'] 


        cols_MFvolume = ['3Day_MoneyFlowTurnover_ind0','20Day_MoneyFlowTurnover_ind0']

        ind_volsignal = ['1D_VolumeSignal_ind0','40D_VolumeSignal_ind0']
        ind_CV = ['30Day_GCV_Turn2Prc_ind0','250Day_CV_Turn2Prc_ind0']
        factor = xr.Dataset(factor)

        
        method_list = [["ind0", ind_volsignal, {'prewinsor':(-5,5),
                                                'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                                                'postwinsor':(-5,5)}, ind_volsignal],
                        ["ind0",ind_CV, {'prewinsor':(-50,50),
                                        'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                                        'postwinsor':(-5,5)}, ind_CV],
                        ["ind0",cols_MFvolume, {'prewinsor':(-0.1,0.1),
                                        'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                                        'postwinsor':(-5,5)}, cols_MFvolume],
                        ["ind0", ind0_WVP_col, {'prewinsor':(-0.08,0.08),
                                                'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                                                'postwinsor':(-4,4)}, ind0_WVP_col],
                        ["indrank",indrank0_col,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':1,'n_start':self.params['n_start']}, indrank0_col],
                        ["softwinsor",['60D_WVP_winsor'],{'maxk':0.05},['60D_WVP_winsor']],
                        ['softwinsor',['10Day_MoneyFlowTurnover'],{'maxk':0.1},['10Day_MoneyFlowTurnover']],
                        ['softwinsor',['20Day_GCV_Turn2Prc'],{'maxk':50},['20Day_GCV_Turn2Prc']],
                        ['winsor',['50D_VolumeSignal'],{'high':-0.1, 'low':-0.3},['50D_VolumeSignal']]          
                        
                        ]
        factor = self.do_operator(factor, method_list=method_list)
        factor = self.format_factor(factor,isfund=False)
        factor = factor.rename({
        '1D_VolumeSignal_ind0':'v1.1-n1','40D_VolumeSignal_ind0':'v1.40-n1','50D_VolumeSignal':'v1.50',
        '30Day_GCV_Turn2Prc_ind0':'v2.30-n1','20Day_GCV_Turn2Prc':'v2.20','120Day_GCV_Turn2Prc_indrank0':'v2.120-r2',
        '60Day_CV_Turn2Prc_indrank0':'v3.60-r2','250Day_CV_Turn2Prc_ind0':'v3.250-n1',
        '3Day_MoneyFlowTurnover_ind0':'v4.3-n1','20Day_MoneyFlowTurnover_ind0':'v4.20-n1','10Day_MoneyFlowTurnover':'v4.10',
        '20D_WVP_indrank0':'v5.20-r2','40D_WVP_ind0':'v5.40-n1','60D_WVP_winsor':'v5.60','5D_WVP_indrank0':'v5.5-r2'
        })
        factor = factor.rename({x:'T_'+x for x in list(factor.keys())})
        return factor

    def cal_factor_volatility(self):
        
        factor = {}

        close = self.data['adj_close_locf'] 

        factor[f'10D_RealizedVol_std_ind0'] = -realized_price_volatility(close=close, n=10, diff_n=1, c=252, use_std=True)
        
        factor[f'12M_RealizedVol_std'] = realized_price_volatility(close=close, n=252, diff_n=21, c=12, use_std=True)

        factor[f'2M_RealizedVol_indrank0'] = realized_price_volatility(close=close, n=40, diff_n=21, c=12, use_std=False)

        factor[f'60Day_CV_indrank0'] = opt.coefficient_of_variation(a=close, n=60, min_periods=40)
        factor[f'120Day_CV_ind0'] = opt.coefficient_of_variation(a=close, n=120, min_periods=100)
        factor[f'90Day_CV'] = opt.coefficient_of_variation(a=close, n=90, min_periods=70)


        cols_indrank0 =  [x for x in factor.keys() if x.endswith('indrank0')]
        method_list = [["ind0", ['10D_RealizedVol_std_ind0'], {'prewinsor':(-1.1,1.1),
                                                'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                                                'postwinsor':(-5,5)}, ['10D_RealizedVol_std_ind0']],
                        ["ind0", ['120Day_CV_ind0'], {'prewinsor':(0,0.5),
                                                'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                                                'postwinsor':(-5,5)}, ['120Day_CV_ind0']],
                        ["softwinsor",['12M_RealizedVol_std'], {'maxk':1.5}, ['12M_RealizedVol_std']],
                        ["winsor",['90Day_CV'], {'low':0, 'high':0.5}, ['90Day_CV']],
                        ["indrank",cols_indrank0,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':1,'n_start':self.params['n_start']}, 
                                    cols_indrank0],
                        ]
        factor = self.do_operator(factor, method_list=method_list)
        factor = self.format_factor(factor,isfund=False)
        factor = factor.rename({'10D_RealizedVol_std_ind0':'va1.10-n1', '12M_RealizedVol_std':'va1.12m','2M_RealizedVol_indrank0':'va1.2m-r2',
        '60Day_CV_indrank0':'va2.60-r2','120Day_CV_ind0':'va2.120-n1','90Day_CV':'va2.90'})
        factor = factor.rename({x:'T_'+x for x in list(factor.keys())})
        return factor
        
    def cal_factor_price(self):
        
        close = self.data['adj_close_locf']
        factor = {}

        factor[f'74_179_PriceRatio'] = Avg_Price_Ratio(close=close, n1=74, n2=179, min_n1=60, min_n2=150)
        factor[f'30_200_PriceRatio_indrank0'] = Avg_Price_Ratio(close=close, n1=30, n2=200, min_n1=20, min_n2=150)
        
        factor[f'52_400_Price_Oscillator_PR1250'] = -Price_Oscillator(close=close, n1=52, n2=400, min_n1=30, min_n2=350)
    
        ans = MACD_trend(close=close, n1=20, n2=90, n_trend=30)-1
        factor[f'20_90_MACD30Trend_indrank0'] = factor[f'20_90_MACD30Trend_PR1250'] = factor[f'20_90_MACD30Trend'] = ans

        # RSI
        factor[f'5Day_RSI_ind0'] = factor[f'5Day_RSI']= -(RSI(close=close, n=5, min_periods=5)-0.5)
        factor[f'252Day_RSI'] = RSI(close=close, n=252, min_periods=200)-0.5

        cols_indrank0 = [x for x in factor.keys() if x.endswith('indrank0')]
        cols_PR1250 = [x for x in factor.keys() if x.endswith('PR1250')]
        cols_ind0_RSI = ['5Day_RSI_ind0']

        method_list = [["indrank",cols_indrank0,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':1,'n_start':self.params['n_start']}, 
                                    cols_indrank0],
                        ["PR", cols_PR1250, {'last_only':self.params['last_only'],'n':1250},cols_PR1250],
                        ["ind0", cols_ind0_RSI, {
                                                'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                                                'postwinsor':(-3,3)}, cols_ind0_RSI],
                        ["softwinsor",[f'20_90_MACD30Trend'],{'maxk':0.4},[f'20_90_MACD30Trend'] ]
                        ]
        factor = self.do_operator(factor, method_list=method_list)
        factor = self.format_factor(factor,isfund=False)
        factor = factor.rename({'74_179_PriceRatio':'p1.74.179','30_200_PriceRatio_indrank0':'p1.30.200-r2',
        '52_400_Price_Oscillator_PR1250':'p2.52.400-r1.1250','20_90_MACD30Trend_indrank0':'p3.20.90-r2',"5Day_RSI":"p4.5",
        '5Day_RSI_ind0':'p4.5-n1','252Day_RSI':'p4.252',"20_90_MACD30Trend_PR1250":"p3.20.90-r1.1250","20_90_MACD30Trend":"p3.20.90"})
        factor = factor.rename({x:'T_'+x for x in list(factor.keys())})
        return factor

    def cal_factor_ret(self):
        close = self.data['adj_close_locf']
        factor = {}

        # ST Reversal and LT Momentum
        factor['1DayRet_reversal'] = -np.log(close/close.shift(D=1))
        factor['3DayRet_ind0'] = -np.log(close/close.shift(D=3))
        factor['5DayRet_PR1250'] = - np.log(close/close.shift(D=5))
        factor['14DayRet_indrank0'] = -np.log(close/close.shift(D=14))

        # LT Momentum
        factor['180DayRet_indrank252'] = np.log(close/close.shift(D=180))

        cols_PR1250 = [x for x in factor.keys() if 'PR1250' in x]
        cols_indrank0 = [x for x in factor.keys() if 'indrank0' in x]
        cols_indrank252 = [x for x in factor.keys() if 'indrank252' in x]
        
        method_list = [["softwinsor", ['1DayRet_reversal'],{'maxk':0.1}, ['1DayRet_reversal']],
            ["indrank",cols_indrank0,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':1,'n_start':self.params['n_start']}, 
                                    cols_indrank0],
            ["indrank",cols_indrank252,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':252,'n_start':self.params['n_start']}, 
                                    cols_indrank252],
                        ["PR", cols_PR1250, {'last_only':self.params['last_only'],'n':1250},cols_PR1250],
                        ["ind0", ['3DayRet_ind0'], {'prewinsor':(-0.15,0.15),
                                                'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                                                'postwinsor':(-3,3)}, ['3DayRet_ind0']],
                        ]
        factor = self.do_operator(factor, method_list=method_list)
        factor = self.format_factor(factor,isfund=False)
        factor = factor.rename({
            '1DayRet_reversal':'r1n.1','3DayRet_ind0':'r1n.3-n1','5DayRet_PR1250':'r1n.5-r1.1250','14DayRet_indrank0':'r1n.14-r2',
            '180DayRet_indrank252':'r1.180-r3.252'
        })
        factor = factor.rename({x:'T_'+x for x in list(factor.keys())})
        return factor

        
# ------------------ operator -------------------- #
def money_flow_turnover(ret, turnover,n, min_periods=None):
    # rolling has to smaller then windows
    window = len(ret.D.values)
    n = min(n, window)
    min_periods = min(window, min_periods) if  min_periods is not None else None
    
    nday_turnover = turnover.rolling(D=n, min_periods=min_periods).mean()
    nday_money_turnover = (turnover*ret).rolling(D=n, min_periods=min_periods).mean()
    return nday_money_turnover/nday_turnover

def realized_price_volatility(close, n, diff_n=1, c=1, use_std=False, min_periods=None):
    # rolling has to smaller then windows
    window = len(close.D.values)
    n = min(n, window)
    min_periods = min(window, min_periods) if  min_periods is not None else None

    log_prc = np.log(close)
    ret = log_prc - log_prc.shift(D=diff_n) # monthly/daily ret
    if use_std:
        std = np.sqrt(c)*ret.rolling(D=n, min_periods=min_periods).std()
    else:
        ret2 = ret**2
        std = np.sqrt(c)*np.sqrt(ret2.rolling(D=n, min_periods=min_periods).mean())
    return std


def ret_weighted_volume_of_circshare(n, ret, volume, circshare, min_periods=None):
    n_window = len(ret.D.values)
    n = min(n, n_window)
    min_periods = min(min_periods, n_window) if min_periods is not None else None

    ret_volume = (ret*volume).rolling(D=n, min_periods=min_periods).sum()
    ret_volume /= circshare.rolling(D=n, min_periods=min_periods).mean()
    return ret_volume

def Avg_Price_Ratio(close: xr.Dataset, n1: int=74, n2: int=179,
            min_n1=None, min_n2=None) -> xr.Dataset:
    
    window = len(close.D.values)
    n1 = min(n1, window)
    n2 = min(n2, window)
    min_n1 = min(window, min_n1) if  min_n1 is not None else None
    min_n2 = min(window, min_n2) if  min_n2 is not None else None
    
    mean1 = close.rolling(D=n1, min_periods=min_n1).mean()
    mean2 = close.rolling(D=n2, min_periods=min_n2).mean()
    ans = mean1/mean2
    return ans


def Price_Oscillator(close, n1, n2, min_n1=None, min_n2=None):
    # ewa(n2) / ewa(n1)

    window = len(close.D.values)
    n1 = min(n1, window)
    n2 = min(n2, window)
    min_n1 = min(window, min_n1) if  min_n1 is not None else None
    min_n2 = min(window, min_n2) if  min_n2 is not None else None
    
    mean1 = close.rolling_exp(D=n1, window_type="span", min_periods=min_n1).mean()
    mean2 = close.rolling_exp(D=n2, window_type="span", min_periods=min_n2).mean()
    ans = mean2/mean1
    return ans

def MACD_trend(close, n1, n2, n_trend):
    
    window = len(close.D.values)
    n1 = min(n1, window)
    n2 = min(n2, window)
    n_trend = min(n_trend, window)

    mean1 = close.rolling_exp(D=n1, window_type="span").mean()
    mean2 = close.rolling_exp(D=n2, window_type="span").mean()
    trend = (mean1/mean2).rolling_exp(D=n_trend, window_type="span").mean()
    return trend


def RSI(close, n, min_periods=None):
    window = len(close.D.values)
    n = min(n, window)
    min_periods = min(window, min_periods) if  min_periods is not None else None
    

    diff_prc = close-close.shift(D=1)
    mask = ~np.isnan(diff_prc)
    up = diff_prc.where(diff_prc>0,0).where(mask)
    down = -diff_prc.where(diff_prc<0,0).where(mask) 

    up_EMA = up.rolling_exp(D=n, min_periods=min_periods).mean()
    down_EMA = down.rolling_exp(D=n, min_periods=min_periods).mean()
    ans = up_EMA/(up_EMA+down_EMA)
    return ans