import acalc as ac
import xarray as xr
import numpy as np
from alpha_f.src import opt,utils
from alpha_f.src.calc_alpha_new import VirtualCalcAlphaCore

import qr_utils

@ac.node
class Core_Feature(VirtualCalcAlphaCore):
    def __init__(self, config: dict):
        super().__init__(config)

    def customize_process_data(self):
        # 严格大于0的行情：ffill停牌的值，但凡listed都有值。
        cap_col = ['tot_share','close_locf','free_share','circ_share']
        for col in cap_col:
            self.data[col] = self.data[col].where(self.data[col]>0).ffill(dim='D').where(self.meta_data['listed'])
        
        self.data['tot_mv'] = self.data['tot_share']*self.data['close_locf']
        self.data['free_mv'] = self.data['free_share']*self.data['close_locf']
        self.data['circ_mv'] = self.data['circ_share']*self.data['close_locf']

    # @profile
    def cal_factor_valuation(self):
        args=[
            {
                'key':'main_indicator',
                'vcol':['ebit','np_exeal','bas_eps'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['Single_cum','TTM_cum']
            },{
                'key':'balance_sheet',
                'vcol':['ta_nca13'],
                'need_raw':False,
                'rep_type': 'level',
                'change':['TTM_cum','Single_cum']
            },
            {
                'key':'income',
                'vcol':['toc11','op','np','tp'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['TTM_cum','Single_cum']
            }
        ]
        df = self.get_fund_data(args)
        cap_col = ['tot_mv','tot_share']
        cap_data = opt.chg_D_dims(self.data[cap_col], self.fund_data['report_date'])
        last_period = self.get_latest_marker(latest_finperiod=df.D.values[-1]).values
        cap_new_data = cap_data.where(~last_period, self.data.isel(D=-1)[cap_col])
        df = xr.combine_by_coords([df, cap_new_data], join='exact')

        
        # GrowFlow_TTM_cum/mv_winsor
        np_exeal_fill_TTM = df['op_TTM_cum']*df['np_TTM_cum']/df['tp_TTM_cum'] 
        GrowFlow_TTM = df['ta_nca13_TTM_cum'].fillna(0) +  df['toc11_TTM_cum'].fillna(0)+ df['np_exeal_TTM_cum'].fillna(np_exeal_fill_TTM)
        df['GrowFlow_TTM_mv_PR20'] = GrowFlow_TTM/df['tot_mv']

        # ch4q_earn16_totshare2prc_Single_indrank1250
        np_exeal_fill = df['op_Single_cum']*df['np_Single_cum']/df['tp_Single_cum'] 
        earn16 = df['np_exeal_Single_cum'].fillna(np_exeal_fill) + df['toc11_Single_cum'].fillna(0)
        earn_ps = earn16/df['tot_share']
        df['YoY_earnps'] = (earn_ps - earn_ps.shift(D=4))


        colneed = ['ebit_Single_cum','ta_nca13_Single_cum','toc11_Single_cum','np_exeal_Single_cum',
                    'op_Single_cum','np_Single_cum','tp_Single_cum',
                    'bas_eps_Single_cum','GrowFlow_TTM_mv_PR20','YoY_earnps']

        PR = [x for x in colneed if 'PR20' in x]

        method_list = [ ["PR", PR, {'last_only':False,'n':20}, PR]]
        df = self.do_operator(df[colneed], method_list=method_list)
        fund_data = self.format_factor(df, isfund=True)
        cap_data = self.format_factor(self.data[['tot_mv','close_locf']],isfund=False)
        
        factor = {}
        factor['GrowFlow_TTM_mv_PR20'] = fund_data['GrowFlow_TTM_mv_PR20']


        # ebit_Single_cum/mv_PR
        factor['ebit_Single_mv_PR1250'] = fund_data['ebit_Single_cum']/cap_data['tot_mv']
        
        # ch4q_earn16_totshare2prc_Single_indrank1250
        factor['ch4q_earn16_totshare2prc_Single_indrank1250'] = fund_data['YoY_earnps']/ cap_data['close_locf']

        # x_GrowFlow_Single_mv_indrank1250
        np_exeal_fill_Single = fund_data['op_Single_cum']*fund_data['np_Single_cum']/fund_data['tp_Single_cum'] 
        GrowFlow_Single = fund_data['ta_nca13_Single_cum'].fillna(0) +  fund_data['toc11_Single_cum'].fillna(0)+ fund_data['np_exeal_Single_cum'].fillna(np_exeal_fill_Single)
        factor['GrowFlow_Single_mv_indrank1250'] = GrowFlow_Single/cap_data['tot_mv']
        
        # 'x_bas_eps_Single_close.winsor.ind0'
        factor['bas_eps_Single_close_ind0'] = fund_data['bas_eps_Single_cum']/cap_data['close_locf']
        
        PR = [x for x in factor.keys() if '_PR1250' in x]
        indrank1250 = [x for x in factor.keys() if '_indrank1250' in x]
        method_list = [ ["PR", PR, {'last_only':self.params['last_only'],'n':1250}, PR],
            ["indrank",indrank1250,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':1250,'n_start':self.params['n_start']}, 
                                    indrank1250],
            ["ind0", ['bas_eps_Single_close_ind0'], {'prewinsor':(-0.2,0.2),
                        'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                        'postwinsor':(-5,5)}, ['bas_eps_Single_close_ind0']]]
        factor = self.do_operator(factor, method_list=method_list)

        # anonymous
        factor = factor.rename({"GrowFlow_TTM_mv_PR20":"v1-r1.20q",
                                "ebit_Single_mv_PR1250":"v2-r1.1250",
                                "ch4q_earn16_totshare2prc_Single_indrank1250":"v3-r3.1250",
                                "GrowFlow_Single_mv_indrank1250":"v4-r3.1250",
                                "bas_eps_Single_close_ind0":"v5-n1"
                                })

        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor

    # @profile
    def cal_factor_ROA(self):
        args =  [
                {
                    'key':'balance_sheet',
                    'vcol':['ta','tse_pa1'],
                    'need_raw':False,
                    'rep_type': 'level',
                    'change':['TTM_avg','Single_avg']
                },
                {
                    'key':'income',
                    'vcol':['tci','op','np','tp'],
                    'need_raw':False,
                    'rep_type': 'period',
                    'change':['Single_cum']
                },
                {
                    'key':'main_indicator',
                    'vcol':['ebit','np_exeal'],
                    'need_raw':False,
                    'rep_type': 'period',
                    'change':['TTM_cum','Single_cum']
                }]
        df = self.get_fund_data(args)
        factor = {}
        # x_EarnCEQ12_Single_cum.indrank20
        np_exeal_fill_Single = df['op_Single_cum']*df['np_Single_cum']/df['tp_Single_cum'] 
        EarnCEQ12_Single_cum_ind0 = df['np_exeal_Single_cum'].fillna(np_exeal_fill_Single)/df['tse_pa1_Single_avg']   
        valid = df['tse_pa1_Single_avg'] >0   
        factor['EarnCEQ12_Single_cum_indrank20'] = EarnCEQ12_Single_cum_ind0.where(valid)
        
        # 'x_EarnAst_Single_cum.PR20'
        EarnAst_Single_cum_ind0 = df['tci_Single_cum']/df['ta_Single_avg']
        valid = df['ta_Single_avg']>0
        factor['EarnAst_Single_cum_PR20'] = EarnAst_Single_cum_ind0.where(valid)
   
        # 'x_ROA.winsor.ind0.winsor
        ROA = df['ebit_TTM_cum'] / df['ta_TTM_avg']
        valid = df['ta_TTM_avg']>0
        factor['ROA_ind0'] = ROA.where(valid)


        # indrank20
        indrank20 =[x for x in factor.keys() if 'indrank20' in x]
        PR = [x for x in factor.keys() if 'PR20' in x]

        method_list = [ 
            ["PR", PR, {'last_only':False,'n':20}, PR],
            ["indrank",indrank20,{'industry':self.params['industry_fund'],'train_mask':self.params['train_fund'],'n':20,'n_start':0}, 
                                    indrank20]]
        factor = self.do_operator(factor, method_list=method_list)
        factor = self.format_factor(factor, isfund=True)

        # in0
        colneed_ind0 = ['ROA_ind0']
        method_list = [["ind0", colneed_ind0, {'prewinsor':(-0.5,0.5),'method':'standardize',
                                    'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                                    'postwinsor':(-5,5)}, colneed_ind0]]
        factor = self.do_operator(factor, method_list=method_list)

        factor = factor.rename({
            'EarnCEQ12_Single_cum_indrank20':'ra3-r3.20q',
            'EarnAst_Single_cum_PR20':'ra2-r1.20q',
            'ROA_ind0':'ra1-n1'
        })

        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor

    # @profile
    def cal_factor_margin_earn_growth(self):
        args = [
            {
                'key':'balance_sheet',
                'vcol':['ta'],
                'need_raw':False,
                'rep_type': 'level',
                'change':['TTM_avg']
            },
            {
                'key':'income',
                'vcol':['op','tor1','toc1','tp','tor','np'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['Single_cum','TTM_cum']
            },
            {
                'key':'cash_flow',
                'vcol':['ncf_oa'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['Single_cum']
            },
            {
                'key':'main_indicator',
                'vcol':['ebit','np_exeal'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['Single_cum']
            }
        ]
        df = self.get_fund_data(args)
        
        
        tor_Single = df['tor1_Single_cum'].where(df['tor1_Single_cum']>0)
        tor_Single = tor_Single.fillna(df['tor_Single_cum'])
        tor_Single = tor_Single.where(tor_Single>0)
        
        colneed = []
        # perc_ch4Q_marginearn3_Single_cum
        margin_earn3 = df['op_Single_cum']/tor_Single
        lag_fac = margin_earn3.shift(D=4)
        perc_ch4Q_marginearn3_Single_cum = (margin_earn3-lag_fac)/lag_fac
        df['perc_ch4Q_marginearn3_Single_cum_indrank1'] = perc_ch4Q_marginearn3_Single_cum.where((lag_fac!=0))
        colneed.append('perc_ch4Q_marginearn3_Single_cum_indrank1')

        # perc_ch4Q_marginearn0_Single_cum
        margin_earn0 = (tor_Single - df['toc1_Single_cum'])/tor_Single
        lag_fac = margin_earn0.shift(D=4)
        perc_ch4Q_marginearn0_Single_cum = (margin_earn0-lag_fac)/lag_fac
        df['perc_ch4Q_marginearn0_Single_cum'] = xr.apply_ufunc(lambda x: opt.softwinsor(x, maxk=2), 
                                        perc_ch4Q_marginearn0_Single_cum.where((lag_fac!=0)))
        colneed.append('perc_ch4Q_marginearn0_Single_cum')    

        # perc_ch12Q_marginearn13_Single_cum
        margin_earn13 = df['ebit_Single_cum']/tor_Single
        lag_fac = margin_earn13.shift(D=12)
        perc_ch12Q_marginearn13_Single_cum = (margin_earn13-lag_fac)/lag_fac
        df['perc_ch12Q_marginearn13_Single_cum_indrank1'] = perc_ch12Q_marginearn13_Single_cum.where((lag_fac!=0))
        colneed.append('perc_ch12Q_marginearn13_Single_cum_indrank1')
        
        # ch4Q_earn5_div_ta_TTM_avg_ind0
        ch4Q_earn5_div_ta_TTM_avg_ind0 = (df['tp_TTM_cum'] - df['tp_TTM_cum'].shift(D=4))/df['ta_TTM_avg']
        valid = df['ta_TTM_avg']>0
        df['ch4Q_earn5_div_ta_TTM_avg_indrank20'] = ch4Q_earn5_div_ta_TTM_avg_ind0.where(valid)
        colneed.append('ch4Q_earn5_div_ta_TTM_avg_indrank20')
        # perc4Q_OCF_Single_cum_ind0
        OCF = df['ncf_oa_Single_cum'].where(abs(df['ncf_oa_Single_cum'])>1e-3)
        OCF_L1Y = OCF.shift(D=4)
        percch_4Q_OCF_Single_cum = (OCF-OCF_L1Y)/abs(OCF_L1Y)
        # df['percch_4Q_OCF_Single_cum_ind0'] = percch_4Q_OCF_Single_cum.where(abs(percch_4Q_OCF_Single_cum)<=10)
        df['percch_4Q_OCF_Single_cum_indrank20'] = xr.apply_ufunc(lambda x: opt.softwinsor(x, maxk=10), percch_4Q_OCF_Single_cum)
        colneed.append('percch_4Q_OCF_Single_cum_indrank20')
    

        # profitmargin12_Single_cum_ind0
        np_exeal_fill = df['op_Single_cum']*df['np_Single_cum']/df['tp_Single_cum'] 
        earn12_divtor = df['np_exeal_Single_cum'].fillna(np_exeal_fill)/tor_Single
        df['profitmargin12_Single_cum_PR20'] = earn12_divtor
        colneed.append('profitmargin12_Single_cum_PR20')

        # profitmargin0_Single_cum_ind0
        profitmargin0_Single_cum = (df['tor1_Single_cum'] - df['toc1_Single_cum'])/tor_Single
        df['profitmargin0_Single_cum_PR20'] = profitmargin0_Single_cum
        colneed.append('profitmargin0_Single_cum_PR20')

        # profitmargin_Chg1Y_Single_cum_ind0
        profitmargin0_chg1Y_Single_cum_ind0 = profitmargin0_Single_cum - profitmargin0_Single_cum.shift(D=4)
        df['profitmargin0_chg1Y_Single_cum_indrank1'] = profitmargin0_chg1Y_Single_cum_ind0
        colneed.append('profitmargin0_chg1Y_Single_cum_indrank1')

        
        # indrank20
        indrank20 =[x for x in colneed if 'indrank20' in x]
        PR = [x for x in colneed if 'PR20' in x]

        method_list = [ 
            ["PR", PR, {'last_only':False,'n':20}, PR],
            ["indrank",indrank20,{'industry':self.params['industry_fund'],'train_mask':self.params['train_fund'],'n':20,'n_start':0}, 
                                    indrank20]]
        df = self.do_operator(df, method_list=method_list)

        factor = self.format_factor(xr.Dataset(data_vars=df[colneed]), isfund=True)

        # indrank1
        colneed_indrank0 = [x for x in colneed if 'indrank1' in x]

        method_list = [
            ["indrank",colneed_indrank0,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':1,'n_start':self.params['n_start']}, 
                                    colneed_indrank0]]
        factor = self.do_operator(factor, method_list=method_list)
        factor = factor.rename({
            'perc_ch4Q_marginearn3_Single_cum_indrank1':'eg1-r2',
            'perc_ch4Q_marginearn0_Single_cum':'eg2',
            'perc_ch12Q_marginearn13_Single_cum_indrank1':'eg3-r2',
            'ch4Q_earn5_div_ta_TTM_avg_indrank20':'eg4-r3.20q',
            'percch_4Q_OCF_Single_cum_indrank20':'eg5-r3.20q',
            'profitmargin12_Single_cum_PR20':'eg6-r1.20q',
            'profitmargin0_Single_cum_PR20':'eg7-r1.20q',
            'profitmargin0_chg1Y_Single_cum_indrank1':'eg8-r2'
        })
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor
        

    @qr_utils.clock
    def cal_factor_sale_growth(self):
        args = [
            {
                'key':'income',
                'vcol':['tor1','tor'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['Single_cum','TTM_cum']
            }]
            
        df = self.get_fund_data(args)
        
        tor_Single = df['tor1_Single_cum'].where(df['tor1_Single_cum']>0)
        tor_Single = tor_Single.fillna(df['tor_Single_cum'])
        tor_Single = tor_Single.where(tor_Single>0)
        tor_TTM = df['tor1_TTM_cum'].where(df['tor1_TTM_cum']>0)
        tor_TTM = tor_TTM.fillna(df['tor_TTM_cum'])
        tor_TTM = tor_TTM.where(tor_TTM>0)

        colneed = []
        # perc_ch4Q_sale_Single_cum, perc_ch4Q_sale_Single_cum_ind0
        lag_tor = tor_Single.shift(D=4)
        yoy = (tor_Single - lag_tor)/ lag_tor
        df['perc_ch4Q_sale_Single_cum_indrank20'] = yoy
        colneed.append('perc_ch4Q_sale_Single_cum_indrank20')

        # ch1Q_yoy(sale)_ind0_ED60
        lag_tor_TTM = tor_TTM.shift(D=4)
        yoy_sale = (tor_TTM-lag_tor_TTM)/lag_tor_TTM
        yoy_sale = yoy_sale.where(abs(yoy_sale)<=10)
        ans = yoy_sale-yoy_sale.shift(D=1)
        df['ch1Q_yoy(sale)_indrank1'] = ans 
        colneed.append('ch1Q_yoy(sale)_indrank1')

        # indrank20
        indrank20 =[x for x in colneed if 'indrank20' in x]

        method_list = [
            ["indrank",indrank20,{'industry':self.params['industry_fund'],'train_mask':self.params['train_fund'],'n':20,'n_start':0}, 
                                    indrank20]]
        df = self.do_operator(df, method_list=method_list)
        factor = self.format_factor(xr.Dataset(data_vars=df[colneed]), isfund=True)

        # indrank1
        colneed_indrank0 = [x for x in colneed if 'indrank1' in x]

        method_list = [
            ["indrank",colneed_indrank0,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':1,'n_start':self.params['n_start']}, 
                                    colneed_indrank0]]
        factor = self.do_operator(factor, method_list=method_list)
        factor = factor.rename({
            "perc_ch4Q_sale_Single_cum_indrank20":"sg1-r3.20q",
            "ch1Q_yoy(sale)_indrank1":"sg2-r2"
        })
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor

    @qr_utils.clock
    def cal_factor_asset_growth(self):
        args = [
            {
                'key':'balance_sheet',
                'vcol':['ta','ta_ca'],
                'need_raw':False,
                'rep_type': 'level',
                'change':['Single_avg','Single_cum','TTM_cum','TTM_avg']
            }]
        df = self.get_fund_data(args)
        factor = {}

        # AstGrowth_cum_ta_Single_ind0
        factor['AstGrowth_cum_ta_Single_indrank1'] = df['ta_Single_cum']/ df['ta_Single_avg'].where(df['ta_Single_avg']>0)

        # AstGrowth_cum_ta_ca_TTM_ind0
        factor['AstGrowth_cum_ta_ca_TTM_ind0'] =df['ta_ca_TTM_cum']/ df['ta_ca_TTM_avg'].where(df['ta_ca_TTM_avg']>0)
        

        factor = self.format_factor(xr.Dataset(data_vars=factor), isfund=True)
        colneed_ind0 = [x for x in factor.keys() if 'ind0' in x]
        colneed_indrank0 = [x for x in factor.keys() if 'indrank1' in x]

        method_list = [
            ["indrank",colneed_indrank0,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':1,'n_start':self.params['n_start']}, 
                                    colneed_indrank0],
            ["ind0", colneed_ind0, {'prewinsor':(-2,2),'method':'standardize',
                                    'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                                    'postwinsor':(-2,2)}, colneed_ind0],
            ]
        factor = self.do_operator(factor, method_list=method_list)
        factor = factor.rename({
            'AstGrowth_cum_ta_Single_indrank1':'ag1-r2',
            'AstGrowth_cum_ta_ca_TTM_ind0':'ag2-n1'
        })
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor

    @qr_utils.clock
    def cal_factor_PB(self):
        args = [
            {
                'key':'balance_sheet',
                'vcol':['ta','tse_pa1','tl_ncl1','tl_ncl2','tl_cl1','tse_pa3','tse_pa2','tse_monority','ta_ca1','ta_ca2','tl_cl'],
                'need_raw':True,
                'rep_type': 'level'
            }
        ]
        df = self.get_fund_data(args)
        fund_data = self.format_factor(xr.Dataset(df), isfund=True)
        cap_data = self.format_factor(self.data[['tot_mv']], isfund=False)
        
        factor = {}

        # tse2mv_total
        factor['tse2mv_total_PR1250']=fund_data['tse_pa1']/cap_data['tot_mv']

        # ceqEV0_tot
        fund_data['tot_mv'] = cap_data['tot_mv']
        EV = self.cal_EV(fund_data, suffix='', mv_n='tot_mv',industry=self.industry) 
        EV = EV.where(EV>0)
        factor['ceqEV_tot'] = fund_data['tse_pa1']/EV

        # ta2mv_tot
        factor['ta2mv_tot_indrank1'] = fund_data['ta']/cap_data['tot_mv']

        # tl_cl
        factor['tcl2mv_total_PR1250'] = fund_data['tl_cl']/cap_data['tot_mv']



        # indrank1
        cols_indrank0=[x for x in factor.keys() if x.endswith('indrank1')]
        colneed_PR=[x for x in factor.keys() if 'PR1250' in x]


        method_list = [
            ['softwinsor',['ceqEV_tot'],{'maxk':1},['ceqEV_tot']],
            ["PR", colneed_PR, {'last_only':self.params['last_only'],'n':1250},colneed_PR],
            ["indrank",cols_indrank0,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':1,'n_start':self.params['n_start']}, 
                        cols_indrank0]]
        factor = self.do_operator(factor, method_list=method_list)
        factor = factor.rename({
            'tse2mv_total_PR1250':"vb1-r1.1250",
            'ceqEV_tot':"vb2",
            'ta2mv_tot_indrank1':"vb3-r2",
            'tcl2mv_total_PR1250':"vb4-r1.1250"
        })
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor


    @qr_utils.clock
    def cal_factor_DA(self):
        args = [
            {
                'key':'balance_sheet',
                'vcol':['ta','ta_ca1','tl','tl_cl1','tl_ncl1','tl_ncl2'],
                'need_raw':True,
                'rep_type': 'level',
                'change':['TTM_cum','TTM_avg']
            }]
        df = self.get_fund_data(args)
        factor = {}

        # da2_pos_TTM_cum_ind0
        debt_cum = df['tl_cl1_TTM_cum'].fillna(0)+ df['tl_ncl1_TTM_cum'].fillna(0)+df['tl_ncl2_TTM_cum'].fillna(0)
        da2_pos_TTM_cum = debt_cum/ abs(df['ta_TTM_cum'])
        factor['da2_abs_TTM_cum_ind0'] = da2_pos_TTM_cum.where(df['ta_TTM_cum']!=0)

   
        # da2_TTM_avg_ind0
        debt = df['tl_cl1_TTM_avg'].fillna(0)+df['tl_ncl1_TTM_avg'].fillna(0)+df['tl_ncl2_TTM_avg'].fillna(0)
        factor['da2_TTM_avg_ind0'] = debt/df['ta_TTM_avg'].where(df['ta_TTM_avg']>0)

        # fln4_TTM_avg
        factor['fln4_TTM_avg'] = df['ta_ca1_TTM_avg']/df['tl_TTM_avg'].where(df['tl_TTM_avg']>0)
        
        # fln1_TTM_cum
        factor['fln1_TTM_cum_ind0'] = df['tl_TTM_cum']/ abs(df['ta_TTM_cum']).where(df['ta_TTM_cum']!=0)


        factor = self.format_factor(xr.Dataset(factor), isfund=True)
        
        winsor2 = ['fln1_TTM_cum_ind0','fln4_TTM_avg','da2_abs_TTM_cum_ind0']
        winsor1 = ['da2_TTM_avg_ind0']
        colneed_ind0 = [x for x in factor.keys() if 'ind0' in x]
        method_list = [
            ["softwinsor",winsor2, {'maxk':2},winsor2],
            ["softwinsor",winsor1, {'maxk':1},winsor1],
            ["ind0", colneed_ind0, {
                    'industry':self.params['industry'],'train_mask':self.params['train_mask'], 'method':'standardize',
                                'postwinsor':(-1.5,1.5)}, colneed_ind0]]
        factor = self.do_operator(factor, method_list=method_list)
        factor = factor.rename({
            'da2_abs_TTM_cum_ind0':'da1-n1',
            'da2_TTM_avg_ind0':'da2-n1',
            'fln4_TTM_avg':'da3',
            'fln1_TTM_cum_ind0':'da4-n1',

        })
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor


    @qr_utils.clock
    def cal_factor_chgmv(self):
        factor={}
        
        capdata = self.data[['circ_mv','free_mv','circ_share','free_share','tot_share']]
        
        # circ_mv_chg_300_pos_ind0
        circ_mv = capdata['circ_mv']
        ch_mv1_ind0 = (circ_mv/(circ_mv.shift(D=300))-1)
        factor['circ_mv_chg_300'] =  ch_mv1_ind0.where(~(np.isinf(ch_mv1_ind0)))

        # free_mv_chg_ema_60_PR1250
        # free_mv = capdata['free_mv']
        ch_mv3_ind0 = (circ_mv/(circ_mv.shift(D=60))-1)
        ch_mv3_ind0 = ch_mv3_ind0.where(~(np.isinf(ch_mv3_ind0) ))
        factor['circ_mv_chg_ema_60_indrank1250'] = ch_mv3_ind0.rolling_exp(D=60, window_type='halflife').mean()

        # circ_share_chg_250_ED60
        circ_share = capdata['circ_share']
        ch_share1 = (circ_share/circ_share.shift(D=250)-1)
        factor['circ_share_chg_250_indrank1'] = ch_share1.where(~(np.isinf(ch_share1)))

        # sqrt mv ema
        sqrt_mv = np.sqrt(capdata['circ_mv'])
        factor['sqrt_circ_mv_ema_60_PR1250'] = sqrt_mv.rolling_exp(D=60, window_type='halflife').mean()

        # freeshare
        factor['circshare'] = capdata['circ_share']/capdata['tot_share']

        # PR
        colneed_PR=[x for x in factor.keys() if 'PR1250' in x]
        colneed_indrank1=[x for x in factor.keys() if x.endswith('indrank1')]
        colneed_indrank1250=[x for x in factor.keys() if x.endswith('indrank1250')]

        method_list = [
            ['softwinsor',['circ_mv_chg_300'],{'maxk':5},['circ_mv_chg_300']],
            ["indrank",colneed_indrank1,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':1,'n_start':self.params['n_start']}, 
                                    colneed_indrank1],
            ["indrank",colneed_indrank1250,{'industry':self.params['industry'],'train_mask':self.params['train_mask'],'n':1250,'n_start':self.params['n_start']}, 
                                    colneed_indrank1250],
            ["PR", colneed_PR, {'last_only':self.params['last_only'],'n':1250},colneed_PR],
            ]
        factor = self.do_operator(factor, method_list=method_list)
        factor = self.format_factor(factor,isfund=False)
        factor = factor.rename(
        {"circ_mv_chg_300":'mg1',
        "circ_mv_chg_ema_60_indrank1250":"mg2-r3.1250",
        "circ_share_chg_250_indrank1":'mg3-r2',
        'sqrt_circ_mv_ema_60_PR1250':'mg4-r1.1250',
        'circshare':'cs1'
        })
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor

    @qr_utils.clock
    def cal_factor_eps_chg(self):
        args = [
            {
                'key':'income',
                'vcol':['tor','tor1'],
                'need_raw':True,
                'rep_type': 'period'
            },
            {
                'key':'main_indicator',
                'vcol':['bas_eps'],
                'need_raw':True,
                'rep_type': 'period'
            }
        ]
        df = self.get_fund_data(args)   
        fund_data = self.format_factor(df, isfund=True)
        cap_data = self.format_factor(self.data[['circ_share']],isfund=False)

        tor =  fund_data['tor1'].fillna(fund_data['tor'])
        eps_bas = fund_data['bas_eps'].where(fund_data['bas_eps']!=0)
        sale_ps_div_eps = tor/cap_data['circ_share']/eps_bas

        factor = {}
        factor[f'sale2epsChg_eps_ind0'] = sale_ps_div_eps-sale_ps_div_eps.shift(D=250)

        # ind0        
        method_list = [["ind0", ['sale2epsChg_eps_ind0'], {'prewinsor':(-40,40),
                                'industry':self.params['industry'],'train_mask':self.params['train_mask'], 'method':'standardize',
                                'postwinsor':(-3,3)}, ['sale2epsChg_eps_ind0']]]
        factor = self.do_operator(factor, method_list=method_list)
        factor = factor.rename({'sale2epsChg_eps_ind0':'epg1-n1'})
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor


    @qr_utils.clock    
    def cal_factor_AdjAccrual(self):
        """
        AdjAccrual = (earn - ncfoa) / |earn|  
        """

        args = [
            {
                'key':'cash_flow',
                'vcol':['ncf_ia','ncf_oa'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['Single_cum']
            },
            {
                'key':'income',
                'vcol':['np','op','tp'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['Single_cum']
            },
            {
                'key':'main_indicator',
                'vcol': ['np_exeal'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['Single_cum']
            }
        ]
        df = self.get_fund_data(args)  
        factor = {}

        # AdjAccrual_12_ind0
        np_exeal_fill_single = df['op_Single_cum']*df['np_Single_cum']/df['tp_Single_cum'] 
        earn = df['np_exeal_Single_cum'].fillna(np_exeal_fill_single)
        earn_abs = abs(earn)
        earn_abs = earn_abs.where(earn_abs>1000)
        ans = (earn- df['ncf_oa_Single_cum']) / earn_abs
        factor['AdjAccrual12'] = ans
        factor['AdjAccrual12_sqr_neg'] = -ans**2

        method_list = [
            ["softwinsor", ['AdjAccrual12'],{'maxk':30}, ['AdjAccrual12']],
            ["softwinsor", ['AdjAccrual12_sqr_neg'],{'maxk':60}, ['AdjAccrual12_sqr_neg']],
                        ]
        factor = self.do_operator(factor, method_list=method_list)
        factor = self.format_factor(factor,isfund=True)
        factor = factor.rename({"AdjAccrual12":"ac1","AdjAccrual12_sqr_neg":"ac1-o4no5.2"})
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor

    @qr_utils.clock
    def cal_factor_FCF2Sale(self):
        args = [
            {
                'key':'cash_flow',
                'vcol':['ncf_oa','ncf_fa22','ncf_ia21'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['TTM_cum']
            },        
            {
                'key':'income',
                'vcol':['tor','tor1'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['TTM_cum']
            }
        ]
        df = self.get_fund_data(args)

        factor = {}
        # FCF2sale_TTM_cum_ind0
        FCF = df['ncf_oa_TTM_cum']   - df['ncf_ia21_TTM_cum'].fillna(0) - df['ncf_fa22_TTM_cum'].fillna(0)
        tor = df['tor1_TTM_cum'].where(df['tor1_TTM_cum']>0)
        tor = tor.fillna(df['tor_TTM_cum'])
        tor = tor.where(tor>0)

        factor['FCF2sale_TTM_cum_PR20'] = (FCF/tor)

        # PR
        colneed_PR=[x for x in factor.keys() if 'PR20' in x]
        method_list = [["PR", colneed_PR, {'last_only':False,'n':20},colneed_PR]]
        factor = self.do_operator(factor, method_list=method_list)
        factor = self.format_factor(factor,isfund=True)

        factor = factor.rename({'FCF2sale_TTM_cum_PR20':'cfs1-r1.20q'})
        
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor


    # @profile
    def cal_factor_Sale2EV(self):
        args = [
            {
                'key':'balance_sheet',
                'vcol':['tl_cl1','tl_ncl1','tl_ncl2','tse_pa3','tse_monority','ta_ca1','ta_ca2'],
                'need_raw':True,
                'rep_type': 'level'
            },
            {
                'key':'income',
                'vcol':['tor1'],
                'need_raw':True,
                'rep_type': 'period',
                'change':['TTM_cum']
            }
        ]
        df = self.get_fund_data(args)
        cap_col = ['tot_mv']
        cap_data = opt.chg_D_dims(self.data[cap_col], self.fund_data['report_date'])
        last_period = self.get_latest_marker(latest_finperiod=df.D.values[-1]).values
        cap_new_data = cap_data.where(~last_period, self.data.isel(D=-1)[cap_col])
        df = xr.combine_by_coords([df, cap_new_data], join='exact')
        factor = {}

        # saleEV_TTM_cum_avg_tot_ind0
        EV = self.cal_EV(df, suffix='', mv_n='tot_mv',industry=self.industry_fund)
        EV_TTM = EV.rolling(D=5, min_periods=1).mean()  
        EV_TTM = EV_TTM.where(EV_TTM>0)
        factor['saleEV_TTM_cum_PR20'] = df['tor1_TTM_cum']/EV_TTM
        
        # PR
        colneed_PR = [x for x in factor.keys() if 'PR20' in x]
        method_list = [["PR", colneed_PR, {'last_only':False,'n':20},colneed_PR]]
        factor = self.do_operator(factor, method_list=method_list)
        factor = self.format_factor(factor,isfund=True)

        # -------------- daily ------------------ #
        fund_data = self.format_factor(df, isfund=True)
        cap_data = self.format_factor(self.data[['tot_share','close_locf']],isfund=False)

        nD = len(cap_data.D.values)
        # sale_mv_TTM_price_ind0
        mv_TTM_price = cap_data['close_locf']*cap_data['tot_share'].rolling(D=min(250,nD), min_periods=1).mean()
        mv_TTM_price = mv_TTM_price.where(mv_TTM_price>0)
        factor['saleMV_TTM_ind0'] = fund_data['tor1_TTM_cum']/mv_TTM_price

        # ind0        
        method_list = [["ind0", ['saleMV_TTM_ind0'], {'prewinsor':(-2,2),
                                                'industry':self.params['industry'],'train_mask':self.params['train_mask'], 'method':'standardize',
                                                'postwinsor':(-3,3)}, ['saleMV_TTM_ind0']]]
        factor = self.do_operator(factor, method_list=method_list)
        factor = factor.rename({'saleEV_TTM_cum_PR20':'vs1-r1.20q','saleMV_TTM_ind0':'vs1-n1'})
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor


    @qr_utils.clock 
    def cal_factor_Inv2Ast(self):
        args=[{
                'key':'balance_sheet',
                'vcol':['ta','ta_ca10'],
                'need_raw':False,
                'rep_type': 'level',
                'change':['Single_avg']
        }]
        df = self.get_fund_data(args)
        factor = {}

        # Inv2Ast_Single_avg
        factor['Inv2Ast_Single_avg_ind0'] =df['ta_ca10_Single_avg'] / df['ta_Single_avg'].where(df['ta_Single_avg']>0)
        factor = self.format_factor(xr.Dataset(factor), isfund=True)
    
        
        method_list = [
            ["ind0", ['Inv2Ast_Single_avg_ind0'], {'prewinsor':(-1,1),
                            'industry':self.params['industry'],'train_mask':self.params['train_mask'], 'method':'standardize',
                                        'postwinsor':(-2,2)}, ['Inv2Ast_Single_avg_ind0']],
                        ]
        factor = self.do_operator(factor, method_list=method_list)
        factor = factor.rename({"Inv2Ast_Single_avg_ind0":"ia1-n1"})
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor


    @qr_utils.clock   
    def cal_factor_invgrowth(self):
        args = [
            {
                'key':'balance_sheet',
                'vcol':['ta','ta_ca10'],
                'need_raw':True,
                'rep_type': 'level',
                'change':['TTM_cum']
            },
            {
                'key':'income',
                'vcol':['tor1','tor'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['TTM_cum']

            }
            ]
        df = self.get_fund_data(args)    
        tor = df['tor1_TTM_cum'].where(df['tor1_TTM_cum']>0).fillna(df['tor_TTM_cum'])
        tor = tor.where(tor>0)
        factor = {}

        # Inv2AstChg1Y_TTM_cum_ind0 
        inv = df['ta_ca10_TTM_cum'].where(df['ta_ca10_TTM_cum']>0)
        ta = df['ta_TTM_cum'].where(df['ta_TTM_cum']>0)
        ans = inv/ta
        factor['Inv2AstChg1Y_TTM_cum'] =  ans-ans.shift(D=4)

        # UnexpInvChg_TTM_cum_ind0
        inv = df['ta_ca10'].where(df['ta_ca10']>0)
        ta_raw = df['ta'].where(df['ta']>0)
        L1_ta = ta_raw.shift(D=4)
        tor_growth_L1Y = tor.shift(D=4)/tor.shift(D=8)
        factor['UnexpInvChg_TTM_cum'] = (inv - inv.shift(D=4)*tor_growth_L1Y) / L1_ta


        method_list = [
            ["softwinsor", ['Inv2AstChg1Y_TTM_cum'],{'maxk':1}, ['Inv2AstChg1Y_TTM_cum']],
            ["softwinsor", ['UnexpInvChg_TTM_cum'],{'maxk':0.5}, ['UnexpInvChg_TTM_cum']],
                        ]
        factor = self.do_operator(factor, method_list=method_list)
        factor = self.format_factor(factor,isfund=True)
        factor = factor.rename({'Inv2AstChg1Y_TTM_cum':'ig1','UnexpInvChg_TTM_cum':'ig2'})
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor



    @qr_utils.clock
    def cal_factor_earn_stable(self):
        args = [
            {
                'key':'balance_sheet',
                'vcol':['ta_nca6'],
                'need_raw':True,
                'rep_type': 'level'
            },
            {
                'key':'income',
                'vcol':['tor','toc1','ite','np','op','tp'],
                'need_raw':True,
                'rep_type': 'period',
                'change':['Single_cum']
            },
            {
                'key':'main_indicator',
                'vcol':['ebitda','np_exeal'],
                'need_raw':True,
                'rep_type': 'period',
                'change':['Single_cum']

            },
            {
                'key':'main_indicator',
                'vcol':['wc'],
                'need_raw':True,
                'rep_type': 'level'
            }
        ]
        df = self.get_fund_data(args)    
        cap_col = ['tot_share']    
        cap_data = opt.chg_D_dims(self.data[cap_col], self.fund_data['report_date'])
        last_period = self.get_latest_marker(latest_finperiod=df.D.values[-1]).values
        cap_new_data = cap_data.where(~last_period, self.data.isel(D=-1)[cap_col])
        df = xr.combine_by_coords([df, cap_new_data], join='exact')
        factor = {}

        # NIStab_earn1_Single_cum_4Q_ind0
        earn1 = df['tor_Single_cum'] - df['toc1_Single_cum']
        L1Y_earn = earn1.shift(D=4)
        yoy = (earn1-L1Y_earn)/abs(L1Y_earn)
        yoy = yoy.where(~((abs(earn1)<1) | (abs(L1Y_earn)<1)))
        n = min(4, len(df.D.values))
        rol_mean = yoy.rolling(D=n, min_periods=1).mean()
        sum_absdiff = abs(yoy-rol_mean).rolling(D=n, min_periods=1).mean()  # min_period=1有点不可比，因为是sum
        NIStab_earn1_Single_cum_4Q_ind0 = rol_mean/sum_absdiff.where( abs(sum_absdiff)>1e-3)
        factor['NIStab_earn1_Single_cum_4Q_indrank1'] = NIStab_earn1_Single_cum_4Q_ind0
        
        # NIStab_earn12_Single_cum_4Q_ind0_PR20
        np_exeal_fill_single = df['op_Single_cum']*df['np_Single_cum']/df['tp_Single_cum'] 
        earn12 = df['np_exeal_Single_cum'].fillna(np_exeal_fill_single)
        L1Y_earn12 = earn12.shift(D=4)
        yoy12 = (earn12-L1Y_earn12)/ abs(L1Y_earn12)
        yoy12 = yoy12.where(~((abs(earn12)<1) | (abs(L1Y_earn12)<1))) # 去掉收入绝对值小于1的，即接近0的收入。
        n = min(4, len(df.D.values))
        rol_mean =  yoy12.rolling(D=n, min_periods=1).mean() 
        sum_absdiff = abs(yoy12-rol_mean).rolling(D=n, min_periods=1).mean() # 不可比 sum
        factor['NIStab_earn12_Single_cum_4Q'] = rol_mean/sum_absdiff.where(abs(sum_absdiff)>1e-3)

        # earnwcStab_tot_share_8Q_ind0: earnps / std( earps_ch1Y)
        earn_wc = df['ebitda'] - df['ite'].fillna(0) + df['wc'].fillna(0)
        earn_ps = earn_wc/df['tot_share']
        chg_1Y = earn_ps - earn_ps.shift(D=4)
        std =  chg_1Y.rolling(D=min(8, len(df.D.values)), min_periods=3).std()
        std = std.where(abs(std)>1e-3)
        factor['earnwcStab_tot_share_8Q_indrank20'] = (earn_ps/std)
        
        
        # FCFStab_tot_share_income_12Q_ind0
        FCF_ps = self.cal_FCFF(df, suffix='', method='income') / df['tot_share']
        FCFps_cg1Y = FCF_ps - FCF_ps.shift(D=4) 
        std =FCFps_cg1Y.rolling(D=12, min_periods=3).std() 
        std = std.where(abs(std)>1e-3)
        factor['FCFStab_tot_share_income_12Q_PR20'] = (FCF_ps/std)
            

        
        # operator
        colneed_indrank1 = [x for x in factor.keys() if 'indrank1' in x]
        colneed_indrank20 = [x for x in factor.keys() if 'indrank20' in x]
        colneed_PR = [x for x in factor.keys() if 'PR20' in x]


        method_list = [["PR", colneed_PR, {'last_only':False,'n':20},colneed_PR],
            ["indrank",colneed_indrank20,{'industry':self.params['industry_fund'],'train_mask':self.params['train_fund'],'n':20,'n_start':0}, 
                                    colneed_indrank20],
            ["indrank",colneed_indrank1,{'industry':self.params['industry_fund'],'train_mask':self.params['train_fund'],'n':1,'n_start':0}, 
                                    colneed_indrank1],
            ["softwinsor", ['NIStab_earn12_Single_cum_4Q'],{'maxk':2}, ['NIStab_earn12_Single_cum_4Q']],
                        ]
        factor = self.do_operator(factor, method_list=method_list)
        factor = self.format_factor(factor,isfund=True)
        factor = factor.rename({
        'NIStab_earn1_Single_cum_4Q_indrank1':'es1-r2',
        'NIStab_earn12_Single_cum_4Q':'es2',
        'earnwcStab_tot_share_8Q_indrank20':'es3-r3.20q',
        'FCFStab_tot_share_income_12Q_PR20':'es4-r1.20q'
        })
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor


    @qr_utils.clock
    def cal_factor_turnover_growth(self):
        args = [
            {
                'key':'balance_sheet',
                'vcol':['ta'],
                'need_raw':False,
                'rep_type': 'level',
                'change':['TTM_avg','Single_avg']
            },
            {
                'key':'income',
                'vcol':['tor1'],
                'need_raw':False,
                'rep_type': 'period',
                'change':['TTM_cum','Single_cum']
            }]
        df = self.get_fund_data(args)
        factor={}
        # ch(sale/ta)1Q_TTM
        ta_single = df['ta_Single_avg'].where(df['ta_Single_avg']>0)
        tor_single = df['tor1_Single_cum'].where(df['tor1_Single_cum']>0)
        fac1raw = tor_single/ta_single
        factor['ch(sale/ta)4Q_Single'] = fac1raw - fac1raw.shift(D=4)#ch_sale_ta_1Q_TTM
            
        # perc(sale/ta)1Q_TTM
        
        tor=df['tor1_TTM_cum'].where(df['tor1_TTM_cum']>0)
        ta = df['ta_TTM_avg'].where(df['ta_TTM_avg']>0)
        fac = tor/ta
        fac_lag1Q = fac.shift(D=1)
        ch_sale_ta_1Q_TTM = fac - fac_lag1Q
        factor['perc(sale/ta)1Q_TTM_ind0'] = ch_sale_ta_1Q_TTM/fac_lag1Q
        
        factor = self.format_factor(xr.Dataset(factor), isfund=True)
    
        # ind0        
        colneed_ind0 = [x for x in factor.keys() if 'ind0' in x]


        method_list = [
            ['softwinsor',['ch(sale/ta)4Q_Single'],{'maxk':0.5},['ch(sale/ta)4Q_Single']],
            ["ind0", colneed_ind0, {'prewinsor':(-0.5,0.5),'method':'standardize',
                                                'industry':self.params['industry'],'train_mask':self.params['train_mask'],
                                                'postwinsor':(-3,3)}, colneed_ind0],
                        ]
        factor = self.do_operator(factor, method_list=method_list)
        factor = factor.rename({'ch(sale/ta)4Q_Single':'tg1', 'perc(sale/ta)1Q_TTM_ind0':'tg2-n1'})
        factor = factor.rename({x:'F_'+x for x in list(factor.keys())})
        return factor

