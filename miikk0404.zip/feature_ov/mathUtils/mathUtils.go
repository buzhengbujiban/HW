package mathUtils

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"math"
)

/*
 * constants
 */
var LOG2 = math.Log(2.0)

/*
 * helpful functions for math utils
 */

func Sqr(v float64) float64 {
	return v * v
}

func Bound(v float64, low float64, high float64) float64 {
	if v < low {
		return low
	} else if v > high {
		return high
	} else {
		return v
	}
}

func simpleL1Mean(vec []float64, mean float64, firstN int) float64 {
	l1Sum := 0.0
	for i := 0; i < firstN; i++ {
		l1Sum += math.Abs(vec[i] - mean)
	}
	return l1Sum / float64(firstN)
}

/*
 *  MA in math_utils.py
 */

type MA struct {
	numObs     int
	dim        int
	data       [][]float64 // circular buffer for each horizon
	currIdxes  []int       // current index to fill a number
	sums       []float64
	sqrSums    []float64
	l1Sums     []float64
	horizons   []int
	maxHorizon int
}

// MA (Moving Average) constructor
func NewMA(horizons []int) *MA {
	// rewrite using literals
	ma := MA{}
	ma.dim = len(horizons)
	ma.horizons = horizons
	ma.maxHorizon = MaxInIntSlice(horizons)

	// make 2d slice
	ma.data = make([][]float64, ma.dim)
	for i := range ma.data {
		ma.data[i] = make([]float64, ma.horizons[i])
	}

	ma.currIdxes = make([]int, ma.dim)
	ma.sums = make([]float64, ma.dim)
	ma.sqrSums = make([]float64, ma.dim)
	ma.l1Sums = make([]float64, ma.dim)
	ma.numObs = 0

	return &ma
}

// Add a new value
func (ma *MA) Add(value float64) {
	for i, h := range ma.horizons {
		oldValue := ma.data[i][ma.currIdxes[i]]
		ma.sums[i] = ma.sums[i] - oldValue + value
		ma.sqrSums[i] = ma.sqrSums[i] - oldValue*oldValue + value*value
		ma.l1Sums[i] = ma.l1Sums[i] - math.Abs(oldValue) + math.Abs(value)
		ma.data[i][ma.currIdxes[i]] = value
		ma.currIdxes[i] = (ma.currIdxes[i] + 1) % h
	}
	ma.numObs += 1
}

// Mean for i-th horizon
func (ma *MA) GetMeanIdx(index int) float64 {
	if ma.numObs == 0 {
		return 0
	} else {
		n := math.Min(float64(ma.numObs), float64(ma.horizons[index]))
		return ma.sums[index] / n
	}
}

// Variance for i-th horzion
func (ma *MA) GetVarianceIdx(i int) float64 {
	if ma.numObs <= 1 {
		return 0
	} else {
		n := math.Min(float64(ma.numObs), float64(ma.horizons[i]))
		v := (ma.sqrSums[i] - ma.sums[i]*ma.sums[i]/n) / n
		if v < 0 {
			v = 0
		}
		return v
	}
}

// L1 standard deviation for i-th horizon
func (ma *MA) GetL1StdDevIdx(i int) float64 {
	if ma.numObs == 0 {
		return 0
	} else {
		n := math.Min(float64(ma.numObs), float64(ma.horizons[i]))
		mean := ma.sums[i] / n
		return simpleL1Mean(ma.data[i], mean, int(n))
	}
}

// outresult API

func (ma *MA) GetMean(outresult []float64) {
	for i := 0; i < ma.dim; i++ {
		outresult[i] = ma.GetMeanIdx(i)
	}
}

func (ma *MA) GetVariance(outresult []float64) {
	for i := 0; i < ma.dim; i++ {
		outresult[i] = ma.GetVarianceIdx(i)
	}
}

func (ma *MA) GetL1StdDev(outresult []float64) {
	for i := 0; i < ma.dim; i++ {
		outresult[i] = ma.GetL1StdDevIdx(i)
	}
}

/*
 * EMAV2 in math_utils.py
 */
type EMA struct {
	halfLifes    []int
	dim          int
	numObs       int
	sums         []float64
	sqrSums      []float64
	weights      []float64
	lastSecEpoch float64
}

func NewEMA(halfLives []int) *EMA {
	n := len(halfLives)
	ema := EMA{
		halfLifes:    halfLives,
		dim:          n,
		numObs:       0,
		sums:         make([]float64, n),
		sqrSums:      make([]float64, n),
		weights:      make([]float64, n),
		lastSecEpoch: 0,
	}
	return &ema
}

func (ema *EMA) NumObs() int {
	return ema.numObs
}

// Clear observation history, but decay rate remains the same
func (ema *EMA) Reset() {
	ema.numObs = 0
	ema.lastSecEpoch = 0
	for i := 0; i < ema.dim; i++ {
		ema.sums[i] = 0
		ema.sqrSums[i] = 0
		ema.weights[i] = 0
	}
}

func (ema *EMA) Add(value float64, secEpoch float64) {
	if math.IsNaN(value) {
		return
	}

	if secEpoch < ema.lastSecEpoch {
		secEpoch = ema.lastSecEpoch
	}
	secSinceLast := secEpoch - ema.lastSecEpoch
	ema.lastSecEpoch = secEpoch

	for i, h := range ema.halfLifes {
		nHalfs := secSinceLast / float64(h)
		decay := 0.0
		if nHalfs <= 20 {
			decay = math.Exp(-nHalfs * LOG2)
		}

		ema.sums[i] = ema.sums[i]*decay + value
		if math.Abs(ema.sums[i]) < 1e-10 {
			ema.sums[i] = 0
		}

		ema.sqrSums[i] = ema.sqrSums[i]*decay + value*value
		if math.Abs(ema.sqrSums[i]) < 1e-10 {
			ema.sqrSums[i] = 0
		}

		ema.weights[i] = ema.weights[i]*decay + 1

		ema.numObs += 1
	}
}

func (ema *EMA) GetMeanIdx(i int) float64 {
	if ema.weights[i] != 0 {
		return ema.sums[i] / ema.weights[i]
	} else {
		return 0
	}
}

func (ema *EMA) GetVarianceIdx(i int) float64 {
	if ema.weights[i] != 0 {
		v := ema.sqrSums[i]/ema.weights[i] - Sqr(ema.sums[i]/ema.weights[i])
		if v < 0 {
			v = 0
		}
		return v
	} else {
		return 0
	}
}

func (ema *EMA) GetStdDevIdx(i int) float64 {
	return math.Sqrt(ema.GetVarianceIdx(i))
}

func (ema *EMA) GetImpulseMeanIdx(i int, secEpoch float64) float64 {
	secSinceLast := 0.0
	if secEpoch > ema.lastSecEpoch {
		secSinceLast = secEpoch - ema.lastSecEpoch
	}

	h := ema.halfLifes[i]
	nHalfs := secSinceLast / float64(h)
	decay := 0.0
	if nHalfs <= 20 {
		decay = math.Exp(-nHalfs * LOG2)
	}

	return ema.sums[i] * decay
}

func (ema *EMA) GetImpulseVarianceIdx(i int) float64 {
	v := ema.sqrSums[i] - Sqr(ema.sums[i])
	if v < 0 {
		v = 0
	}
	return v
}

func (ema *EMA) GetImpulseTstatIdx(i int, x float64) float64 {
	variance := ema.sqrSums[i] - Sqr(ema.sums[i])
	if variance <= 0 {
		return 0
	} else {
		t := (x - ema.sums[i]) / math.Sqrt(variance)
		return Bound(t, -100, 100)
	}
}

// outresult API
func (ema *EMA) GetMean(outresult []float64) {
	for i := 0; i < ema.dim; i++ {
		outresult[i] = ema.GetMeanIdx(i)
	}
}

func (ema *EMA) GetVariance(outresult []float64) {
	for i := 0; i < ema.dim; i++ {
		outresult[i] = ema.GetVarianceIdx(i)
	}
}

func (ema *EMA) GetStdDev(outresult []float64) {
	for i := 0; i < ema.dim; i++ {
		outresult[i] = ema.GetStdDevIdx(i)
	}
}

func (ema *EMA) GetImpulseMean(secEpoch float64, outresult []float64) {
	for i := 0; i < ema.dim; i++ {
		outresult[i] = ema.GetImpulseMeanIdx(i, secEpoch)
	}
	/*
		secSinceLast := 0.0
		if secEpoch > ema.lastSecEpoch {
			secSinceLast = secEpoch - ema.lastSecEpoch
		}

		h := ema.halfLifes[i]
		nHalfs := secSinceLast / float64(h)
		decay := 0.0
		if nHalfs <= 20 {
			decay = math.Exp(-nHalfs * LOG2)
		}
	*/
}

func (ema *EMA) GetImpulseVariance(outresult []float64) {
	for i := 0; i < ema.dim; i++ {
		outresult[i] = ema.GetImpulseVarianceIdx(i)
	}
}

func (ema *EMA) GetImpulseTstat(x float64, outresult []float64) {
	for i := 0; i < ema.dim; i++ {
		outresult[i] = ema.GetImpulseTstatIdx(i, x)
	}
}

//TODO: implement O(1) version of MATime
type MATime struct {
	dim      int
	horizons []int
	data     []*tu.Deque

	sum    []float64
	max    []float64
	min    []float64
	cnt    []int
	numObs int
}

type SecValue struct {
	SecEpoch float64
	Value    float64
}

func NewMATime(horizons []int) *MATime {
	mat := new(MATime)
	mat.horizons = horizons
	mat.dim = len(horizons)
	mat.data = make([]*tu.Deque, mat.dim)
	mat.sum = make([]float64, mat.dim)
	mat.max = make([]float64, mat.dim)
	mat.min = make([]float64, mat.dim)
	mat.cnt = make([]int, mat.dim)

	for h := 0; h < mat.dim; h++ {
		mat.data[h] = tu.NewDeque()
		mat.sum[h] = 0.0
		mat.max[h] = -1e8
		mat.min[h] = 1e8
		mat.cnt[h] = 0
	}

	mat.numObs = 0

	return mat
}

func (mat *MATime) NumObs() int {
	return mat.numObs
}

func (mat *MATime) Add(value float64, secSinceEpoch float64) {
	for h := 0; h < mat.dim; h++ {
		hor := float64(mat.horizons[h])
		mat.data[h].PushBack(SecValue{secSinceEpoch + hor, value})
		mat.sum[h] += value
		if value > mat.max[h] {
			mat.max[h] = value
		}
		if value < mat.min[h] {
			mat.min[h] = value
		}
		mat.cnt[h]++
	}
	mat.numObs++
}

func (mat *MATime) Remove(secSinceEpoch float64) {
	if mat.numObs > 0 {
		for h := 0; h < mat.dim; h++ {
			maxFullCalc, minFullCalc := false, false
			for mat.data[h].Size() >= 2 &&
				mat.data[h].Items[1].(SecValue).SecEpoch <= secSinceEpoch {
				outValue := mat.data[h].PopFront().(SecValue).Value
				mat.sum[h] -= outValue
				mat.cnt[h]--
				if outValue >= mat.max[h] {
					maxFullCalc = true
				}
				if outValue <= mat.min[h] {
					minFullCalc = true
				}
			}
			if maxFullCalc {
				mat.max[h] = mat.data[h].Items[0].(SecValue).Value
				for i := 1; i < len(mat.data[h].Items); i++ {
					if mat.max[h] < mat.data[h].Items[i].(SecValue).Value {
						mat.max[h] = mat.data[h].Items[i].(SecValue).Value
					}
				}
			}
			if minFullCalc {
				mat.min[h] = mat.data[h].Items[0].(SecValue).Value
				for i := 1; i < len(mat.data[h].Items); i++ {
					if mat.min[h] > mat.data[h].Items[i].(SecValue).Value {
						mat.min[h] = mat.data[h].Items[i].(SecValue).Value
					}
				}
			}
		}
	}
}

func (mat *MATime) GetMeanIdx(i int, secSinceEpoch float64) float64 {
	if mat.numObs == 0 {
		return 0
	} else {
		mat.Remove(secSinceEpoch)
		return mat.sum[i] / float64(mat.cnt[i])
	}
}

func (mat *MATime) GetMaxIdx(i int, secSinceEpoch float64) float64 {
	if mat.numObs == 0 {
		return 0
	} else {
		mat.Remove(secSinceEpoch)
		return mat.max[i]
	}
}

func (mat *MATime) GetMinIdx(i int, secSinceEpoch float64) float64 {
	if mat.numObs == 0 {
		return 0
	} else {
		mat.Remove(secSinceEpoch)
		return mat.min[i]
	}
}

func (mat *MATime) GetMean(secSinceEpoch float64, outresult []float64) {
	if len(outresult) != mat.dim {
		panic("MATime.GetMean outresult length not match")
	}
	for h := 0; h < mat.dim; h++ {
		outresult[h] = mat.GetMeanIdx(h, secSinceEpoch)
	}
}

func (mat *MATime) GetMax(secSinceEpoch float64, outresult []float64) {
	if len(outresult) != mat.dim {
		panic("MATime.GetMax outresult length not match")
	}

	for h := 0; h < mat.dim; h++ {
		outresult[h] = mat.GetMaxIdx(h, secSinceEpoch)
	}
}

func (mat *MATime) GetMin(secSinceEpoch float64, outresult []float64) {
	if len(outresult) != mat.dim {
		panic("MATime.GetMin outresult length not match")
	}

	for h := 0; h < mat.dim; h++ {
		outresult[h] = mat.GetMinIdx(h, secSinceEpoch)
	}
}

type GroupMean struct {
	nValues    int
	lastValues map[int][]float64 //sid -> feature vector
	colSums    []float64
}

func NewGroupMean(nValues int) *GroupMean {
	return &GroupMean{
		nValues:    nValues,
		lastValues: make(map[int][]float64),
		colSums:    make([]float64, nValues),
	}
}

func (g *GroupMean) Update(sid int, values []float64) {
	if len(values) != g.nValues {
		panic("len(values) != g.nValues!")
	}
	if oldValues, ok := g.lastValues[sid]; ok {
		for i, v := range values {
			g.colSums[i] = g.colSums[i] - oldValues[i] + v
		}
	} else {
		g.lastValues[sid] = make([]float64, g.nValues)
		for i, v := range values {
			g.colSums[i] += v
		}
	}
	for i, v := range values {
		g.lastValues[sid][i] = v
	}
}

func (g *GroupMean) GetValueIdx(sid int, i int) (demean float64, mean float64) {
	// get mean of i-th value
	nSids := len(g.lastValues)

	if nSids > 0 {
		mean = g.colSums[i] / float64(nSids)
	} else {
		mean = 0.0
	}

	// get demean of i-th value for sid
	if values, ok := g.lastValues[sid]; ok {
		demean = values[i] - mean
	} else {
		demean = 0
	}

	return
}

// outresult API
func (g *GroupMean) GetValue(sid int, outresult []float64) {
	if len(outresult) < 2*g.nValues {
		panic(fmt.Sprintf("GetValue: len of outresult array must >= 2*nValues; %d %d", g.nValues, len(outresult)))
	}
	for i := 0; i < g.nValues; i++ {
		demean, mean := g.GetValueIdx(sid, i)
		outresult[i] = demean
		outresult[i+g.nValues] = mean
	}
}

type SimpleRandGen struct {
	a,
	c,
	m,
	seed int64
}

func NewSimpleRandGen(seed int64) *SimpleRandGen {
	return &SimpleRandGen{
		a:    2,
		c:    37,
		m:    99,
		seed: seed,
	}
}

func (r *SimpleRandGen) Rand() int64 {
	r.seed = (r.a*r.seed + r.c) % r.m
	return r.seed
}

func (r *SimpleRandGen) M() int64 {
	return r.m
}

// a simple Vector method
type Vector []float64

func NewVector(size int) Vector {
	return make(Vector, size)
}

func NewVectorWithValues(values []float64) Vector {
	v := make(Vector, len(values))
	copy(v, values)
	return v
}

// Clone this vector, returning a new Vector.
func (vec Vector) Clone() Vector {
	return NewVectorWithValues(vec)
}

// Sets the values of this vector.
func (vec Vector) Set(values []float64) {
	copy(vec, values)
}

func (vec Vector) AddInplace(vec2 Vector) {
	if len(vec) != len(vec2) {
		panic("vector length not match")
	}
	for i := 0; i < len(vec); i++ {
		vec[i] += vec2[i]
	}
}
func (vec Vector) SetZero() {
	for i := 0; i < len(vec); i++ {
		vec[i] = 0
	}
}

/*
WeightedNestedGroupMean
*/

type WeightedNestedGroupMean struct {
	len            int
	wgt_dict       map[int]float64
	g1_dict        map[int]int   // sid -> grp id
	g2_dict        map[int][]int // sid -> grp ids
	col_sum        []float64
	wgt_sum        float64
	active_sid_set map[int]bool
	global_mean    []float64
	data           map[int][]float64
	resi_value     map[int][]float64
	g2_data        map[int][]float64

	g1_col_sum        map[int][]float64
	g1_wgt_sum        map[int]float64
	g1_active_sid_set map[int]map[int]bool // grp -> (sid set)

	g2_col_sum        map[int][]float64
	g2_wgt_sum        map[int]float64
	g2_active_sid_set map[int]map[int]bool // grp -> (sid set)

	// interal temp vars
	temp_resi_value []float64

	// result variable
	res []float64
}

func NewWeightedNestedGroupMean(len int, wgt_dict map[int]float64,
	g1_dict map[int]int, g2_dict map[int][]int) *WeightedNestedGroupMean {
	g := &WeightedNestedGroupMean{}
	g.len = len
	g.wgt_dict = wgt_dict
	g.g1_dict = g1_dict
	g.g2_dict = g2_dict
	g.col_sum = make([]float64, len)
	g.wgt_sum = 0.0
	g.active_sid_set = make(map[int]bool)
	g.global_mean = make([]float64, len)
	g.data = make(map[int][]float64)
	g.resi_value = make(map[int][]float64)
	g.g2_data = make(map[int][]float64)

	for sid := range wgt_dict {
		g.data[sid] = make([]float64, len)
		g.resi_value[sid] = make([]float64, len)
	}

	g.g1_col_sum = make(map[int][]float64)
	g.g1_wgt_sum = make(map[int]float64)
	g.g1_active_sid_set = make(map[int]map[int]bool)
	for _, grp := range g1_dict {
		g.g1_col_sum[grp] = make([]float64, len)
		g.g1_wgt_sum[grp] = 0.0
		g.g1_active_sid_set[grp] = make(map[int]bool)
	}
	// add group 0 (for a symbol with no industry assignment)
	g.g1_col_sum[0] = make([]float64, len)
	g.g1_wgt_sum[0] = 0.0
	g.g1_active_sid_set[0] = make(map[int]bool)

	g.g2_col_sum = make(map[int][]float64)
	g.g2_wgt_sum = make(map[int]float64)
	g.g2_active_sid_set = make(map[int]map[int]bool)

	g2_name_set := make(map[int]bool)
	for _, grps := range g2_dict {
		for _, grp := range grps {
			g2_name_set[grp] = true
		}
	}

	for grp := range g2_name_set {
		g.g2_col_sum[grp] = make([]float64, len)
		g.g2_wgt_sum[grp] = 0.0
		g.g2_active_sid_set[grp] = make(map[int]bool)
	}

	g.temp_resi_value = make([]float64, len)

	g.res = make([]float64, len*5)

	return g
}

func (g *WeightedNestedGroupMean) Update(sid int, values []float64) {
	if len(values) != g.len {
		panic(fmt.Sprintf("len(values) != g.len %d %d", len(values), g.len))
	}
	g1 := g.g1_dict[sid]
	g2_list := g.g2_dict[sid]

	//# update global mean
	for i := 0; i < g.len; i++ {
		g.col_sum[i] = g.col_sum[i] + (values[i]-g.data[sid][i])*g.wgt_dict[sid]
	}
	copy(g.data[sid], values)
	if !g.active_sid_set[sid] {
		g.active_sid_set[sid] = true
		g.wgt_sum = g.wgt_sum + g.wgt_dict[sid]
	}
	for i := 0; i < g.len; i++ {
		g.global_mean[i] = g.col_sum[i] / g.wgt_sum
	}

	//# residual to global mean
	for i := 0; i < g.len; i++ {
		g.temp_resi_value[i] = values[i] - g.global_mean[i]
	}

	//# update g1 mean
	g1_col_sum := g.g1_col_sum[g1]
	resi_value := g.resi_value[sid]
	wgt := g.wgt_dict[sid]
	for i := 0; i < g.len; i++ {
		g1_col_sum[i] = g1_col_sum[i] + (g.temp_resi_value[i]-resi_value[i])*wgt
	}
	if !g.g1_active_sid_set[g1][sid] {
		g.g1_active_sid_set[g1][sid] = true
		g.g1_wgt_sum[g1] = g.g1_wgt_sum[g1] + wgt
	}

	//# update g2 mean
	if len(g2_list) > 0 {
		for _, g2 := range g2_list {
			g2_col_sum := g.g2_col_sum[g2]
			for i := 0; i < g.len; i++ {
				g2_col_sum[i] = g2_col_sum[i] + (g.temp_resi_value[i]-resi_value[i])*wgt
			}
			if !g.g2_active_sid_set[g2][sid] {
				g.g2_active_sid_set[g2][sid] = true
				g.g2_wgt_sum[g2] = g.g2_wgt_sum[g2] + wgt
			}
		}
	}

	copy(g.resi_value[sid], g.temp_resi_value)
}

func (g *WeightedNestedGroupMean) GetValue(sid int, outresult []float64) {
	g1 := g.g1_dict[sid]
	g2_list := g.g2_dict[sid]

	// 0. global_mean
	copy(outresult, g.global_mean)
	// 1. g1_mean
	g1_wgt_sum := g.g1_wgt_sum[g1]
	g1_col_sum := g.g1_col_sum[g1]
	if g1_wgt_sum > 0 {
		for i := 0; i < g.len; i++ {
			outresult[g.len+i] = g1_col_sum[i] / g1_wgt_sum
		}
	} else {
		for i := 0; i < g.len; i++ {
			outresult[g.len+i] = 0
		}
	}

	// 2. g2_mean
	if len(g2_list) > 0 {
		for i := 0; i < g.len; i++ {
			sum := 0.0
			for _, g2 := range g2_list {
				if g.g2_wgt_sum[g2] > 0 {
					sum += g.g2_col_sum[g2][i] / g.g2_wgt_sum[g2]
				}
			}
			outresult[2*g.len+i] = sum / float64(len(g2_list))
		}

	} else {
		for i := 0; i < g.len; i++ {
			outresult[2*g.len+i] = 0
		}
	}

	// 3&4. g1_residual, g2_residual
	if d, ok := g.data[sid]; ok {
		for i := 0; i < g.len; i++ {
			//self.data[sid][idx] - g_m[idx] - g1_m[idx]
			outresult[3*g.len+i] = d[i] - outresult[i] - outresult[g.len+i]
			//self.data[sid][idx] - g_m[idx] - g2_m[idx]
			outresult[4*g.len+i] = d[i] - outresult[i] - outresult[2*g.len+i]
		}
	} else {
		for i := 0; i < g.len; i++ {
			outresult[3*g.len+i] = 0
			outresult[4*g.len+i] = 0
		}
	}
}

type WeightedNestedGroupMeanFast struct {
	nHors   int         // num of horizons
	nSids   int         // num of sids
	sids    []int       // full sid list
	sid2idx map[int]int // sid -> sidIdx

	wgts   []float64 // sidIdx -> wgt
	g1     []int     // sidIdx -> grpIdx
	g2     [][]int   // sidIdx -> grpIdx array
	g1Size int
	g2Size int

	col_sum        []float64
	wgt_sum        float64
	active_sid_set []bool
	global_mean    []float64

	data       [][]float64 // sid x hors
	resi_value [][]float64 // sid x hors

	g1_col_sum        [][]float64 // grp -> sum of each hor
	g1_wgt_sum        []float64   // wgt sum of each hor
	g1_active_sid_set [][]bool    // grp -> (sid set)

	g2_col_sum        [][]float64
	g2_wgt_sum        []float64
	g2_active_sid_set [][]bool // grp -> (sid set)

	// interal temp vars
	temp_resi_value []float64

	// result variable
	res []float64
}

func NewWeightedNestedGroupMeanFast(
	sids []int,
	nHors int,
	wgt_dict map[int]float64,
	g1_dict map[int]int,
	g2_dict map[int][]int) *WeightedNestedGroupMeanFast {

	g := &WeightedNestedGroupMeanFast{}

	g.nHors = nHors
	g.nSids = len(sids)
	g.sids = sids
	g.sid2idx = make(map[int]int, g.nSids)
	for i, sid := range sids {
		g.sid2idx[sid] = i
	}

	// assign wgts
	g.wgts = make([]float64, g.nSids)
	for sid, wgt := range wgt_dict {
		if idx, ok := g.sid2idx[sid]; ok {
			g.wgts[idx] = wgt
		}
	}

	// assign g1 (industry) group
	g.g1 = make([]int, g.nSids)
	for sid, grpId := range g1_dict {
		if grpId+1 > g.g1Size {
			g.g1Size = grpId + 1
		}
		if idx, ok := g.sid2idx[sid]; ok {
			g.g1[idx] = grpId
		}
	}

	// assign g2 (concept) group
	g.g2 = make([][]int, g.nSids)
	for sid, grpIds := range g2_dict {
		if idx, ok := g.sid2idx[sid]; ok {
			g.g2[idx] = grpIds
			for _, grpId := range grpIds {
				if grpId+1 > g.g2Size {
					g.g2Size = grpId + 1
				}
			}
		}
	}

	g.col_sum = make([]float64, nHors)
	g.wgt_sum = 0.0
	g.active_sid_set = make([]bool, g.nSids)
	g.global_mean = make([]float64, nHors)

	g.data = make([][]float64, g.nSids)
	g.resi_value = make([][]float64, g.nSids)
	for idx := 0; idx < g.nSids; idx++ {
		g.data[idx] = make([]float64, g.nHors)
		g.resi_value[idx] = make([]float64, g.nHors)
	}

	g.g1_col_sum = make([][]float64, g.g1Size)
	g.g1_wgt_sum = make([]float64, g.g1Size)
	g.g1_active_sid_set = make([][]bool, g.g1Size)
	for grp := 0; grp < g.g1Size; grp++ {
		// group 0 is for a symbol with no industry assignment
		g.g1_col_sum[grp] = make([]float64, g.nHors)
		g.g1_wgt_sum[grp] = 0.0
		g.g1_active_sid_set[grp] = make([]bool, g.nSids)
	}

	g.g2_col_sum = make([][]float64, g.g2Size)
	g.g2_wgt_sum = make([]float64, g.g2Size)
	g.g2_active_sid_set = make([][]bool, g.g2Size)
	for grp := 0; grp < g.g2Size; grp++ {
		g.g2_col_sum[grp] = make([]float64, nHors)
		g.g2_wgt_sum[grp] = 0.0
		g.g2_active_sid_set[grp] = make([]bool, g.nSids)
	}

	g.temp_resi_value = make([]float64, nHors)

	g.res = make([]float64, nHors*5)

	return g
}

func (g *WeightedNestedGroupMeanFast) Update(sid int, values []float64) {
	if len(values) != g.nHors {
		panic(fmt.Sprintf("len(values) != g.nHors %d %d", len(values), g.nHors))
	}

	idx, ok := g.sid2idx[sid]
	if !ok {
		panic(fmt.Sprintf("WeightedNestedGroupMeanFast: Trying to feed in sid that is not registered: %d", sid))
	}

	g1 := g.g1[idx]
	g2_list := g.g2[idx]

	//# update global mean
	for i := 0; i < g.nHors; i++ {
		g.col_sum[i] = g.col_sum[i] + (values[i]-g.data[idx][i])*g.wgts[idx]
	}
	copy(g.data[idx], values)
	if !g.active_sid_set[idx] {
		g.active_sid_set[idx] = true
		g.wgt_sum = g.wgt_sum + g.wgts[idx]
	}
	for i := 0; i < g.nHors; i++ {
		g.global_mean[i] = g.col_sum[i] / g.wgt_sum
	}

	//# residual to global mean
	for i := 0; i < g.nHors; i++ {
		g.temp_resi_value[i] = values[i] - g.global_mean[i]
	}

	//# update g1 mean
	g1_col_sum := g.g1_col_sum[g1]
	resi_value := g.resi_value[idx]
	wgt := g.wgts[idx]
	for i := 0; i < g.nHors; i++ {
		g1_col_sum[i] = g1_col_sum[i] + (g.temp_resi_value[i]-resi_value[i])*wgt
	}
	if !g.g1_active_sid_set[g1][idx] {
		g.g1_active_sid_set[g1][idx] = true
		g.g1_wgt_sum[g1] = g.g1_wgt_sum[g1] + wgt
	}

	//# update g2 mean
	if len(g2_list) > 0 {
		for _, g2 := range g2_list {
			g2_col_sum := g.g2_col_sum[g2]
			for i := 0; i < g.nHors; i++ {
				g2_col_sum[i] = g2_col_sum[i] + (g.temp_resi_value[i]-resi_value[i])*wgt
			}
			if !g.g2_active_sid_set[g2][idx] {
				g.g2_active_sid_set[g2][idx] = true
				g.g2_wgt_sum[g2] = g.g2_wgt_sum[g2] + wgt
			}
		}
	}

	copy(g.resi_value[idx], g.temp_resi_value)
}

func (g *WeightedNestedGroupMeanFast) GetValue(sid int, outresult []float64) {

	idx, ok := g.sid2idx[sid]
	if !ok {
		panic(fmt.Sprintf("WeightedNestedGroupMeanFast: Trying to feed in sid that is not registered: %d", sid))
	}

	g1 := g.g1[idx]
	g2_list := g.g2[idx]

	// 0. global_mean
	copy(outresult, g.global_mean)
	// 1. g1_mean
	g1_wgt_sum := g.g1_wgt_sum[g1]
	g1_col_sum := g.g1_col_sum[g1]
	if g1_wgt_sum > 0 {
		for i := 0; i < g.nHors; i++ {
			outresult[g.nHors+i] = g1_col_sum[i] / g1_wgt_sum
		}
	} else {
		for i := 0; i < g.nHors; i++ {
			outresult[g.nHors+i] = 0
		}
	}

	// 2. g2_mean
	if len(g2_list) > 0 {
		for i := 0; i < g.nHors; i++ {
			sum := 0.0
			for _, g2 := range g2_list {
				if g.g2_wgt_sum[g2] > 0 {
					sum += g.g2_col_sum[g2][i] / g.g2_wgt_sum[g2]
				}
			}
			outresult[2*g.nHors+i] = sum / float64(len(g2_list))
		}

	} else {
		for i := 0; i < g.nHors; i++ {
			outresult[2*g.nHors+i] = 0
		}
	}

	// 3&4. g1_residual, g2_residual
	d := g.data[idx]
	for i := 0; i < g.nHors; i++ {
		//self.data[sid][idx] - g_m[idx] - g1_m[idx]
		outresult[3*g.nHors+i] = d[i] - outresult[i] - outresult[g.nHors+i]
		//self.data[sid][idx] - g_m[idx] - g2_m[idx]
		outresult[4*g.nHors+i] = d[i] - outresult[i] - outresult[2*g.nHors+i]
	}
}
