/**
 * Ported from math_utils_cy.pyx
 *
 * Author: Yingfa, Yin
 * Date: 18-5-21
 */
package mathUtils

import (
	"math"
)

func MaxInt64(x int64, y int64) (max int64) {
	if x > y {
		max = x
	} else {
		max = y
	}
	return
}

func MinInt64(x int64, y int64) (min int64) {
	if x < y {
		min = x
	} else {
		min = y
	}
	return
}

func MaxInFloatSlice(v []float64) float64 {
	max := v[0]
	for _, value := range v {
		if value > max {
			max = value
		}
	}
	return max
}

func MinInFloatSlice(v []float64) float64 {
	min := v[0]
	for _, value := range v {
		if value < min {
			min = value
		}
	}
	return min
}

func MaxInIntSlice(v []int) int {
	max := v[0]
	for _, value := range v {
		if value > max {
			max = value
		}
	}
	return max
}

func MinInIntSlice(v []int) int {
	min := v[0]
	for _, value := range v {
		if value < min {
			min = value
		}
	}
	return min
}


func SumFloatSlice(arr []float64) float64 {
	var s float64
	for i:=0; i<len(arr);i++{
		s+= arr[i]
	}
	return s
}

func SumAbsFloatSlice(arr []float64) float64 {
	var s float64
	for i:=0; i<len(arr);i++{
		s+= math.Abs(arr[i])
	}
	return s
}

// ClipFloatSlice; Clip every value in slice `arr`;
// NOTE that this method will change the value in `arr`.
func ClipFloatSlice(arr []float64, low, high float64){
	for i:=0; i<len(arr);i++{
		if arr[i] < low{
			arr[i] = low
		}else if arr[i] > high{
			arr[i] = high
		}
	}
	// arr itself will be changed by above logic. ** NOTE again **
}

// ClipFloat; Clip value to fit into (low, high);
func ClipFloat(v, low, high float64) float64{
	if v < low{
		return low
	}else if v > high{
		return high
	}
	return v
}

//SignOfFloat: return 1/0/-1
func SignOfFloat(d float64)float64{
	if d>0{
		return 1
	}else if d==0{
		return 0
	}else{
		return -1
	}
}

//IsFinite: Is finity.
func IsFinite(f float64) bool{
	return !math.IsNaN(f) && !math.IsInf(f, 0) //0 means check if it's positive inf or negative inf either way.
}

//CalcMeanFloatSlice: ported from array_calc_mean in py
func CalcMeanFloatSlice(pa, sa [] float64) float64{
	if len(pa) != len(sa){return 0.0}
	var sas, vs float64
	for i:=0;i<len(pa);i++{
		sas += sa[i]
		vs += pa[i]*sa[i]
	}
	if sas==0.0{return 0.0}
	return vs/sas
}

func ArrAbs(fa []float64)[]float64{
	for i := range fa{
		fa[i] = math.Abs(fa[i])
	}
	return fa
}

//ArrMultiArrAndSum; ported from array_multi_array_and_sum and abs_array_multi_abs_array_and_sum
func ArrMultiplyArrAndSum(a1, a2 []float64, absBoth bool)float64{
	if len(a1)!=len(a2){
		return 0.0
	}
	var s float64 = 0.0
	if absBoth{
		for i:=0;i<len(a1);i++{
			s+=math.Abs(a1[i])*math.Abs(a2[i])
		}
	}else{
		for i:=0;i<len(a1);i++{

			s+=a1[i]*a2[i]
		}
	}

	return s
}

//ArrMultiArrAndSum; Array `arr` multiple `arr2BeAbs`'s abs value, and then sum.
func ArrMultiplyAbsArrAndSum(arr, arr2BeAbs []float64)float64{
	if len(arr)!=len(arr2BeAbs){
		return 0.0
	}
	var s float64 = 0.0
	for i:=0;i<len(arr);i++{
		s+=(arr[i])*math.Abs(arr2BeAbs[i])
	}
	return s
}

//ArrMultiFloat; Each item in `arr` will be multiplied by `m` and store back to `arr`
// NOTE that arr's value would be changed by this call.
func ArrMultiplyFloat(arr []float64, m float64){
	for i:=0;i<len(arr);i++{
		arr[i] = arr[i]*m
	}
}

//Epanechnikov
func Epanechnikov(t, result []float64){
	if len(t) > len(result){
		panic("Length of output should equals or larget than input's.")
	}
	for i:=0;i<len(t);i++{
		if t[i] > 1 || t[i] < -1{
			result[i] = 0
		}else{
			result[i] = 0.75 * (1-t[i]*t[i])
		}
	}
}

//EpanechnikovFloat
func EpanechnikovFloat(t float64)float64{

	if t > 1 || t < -1{
		return 0
	}else{
		return 0.75 * (1-t*t)
	}

}

//TriCube
func TriCube(t, result []float64){
	for i:=0;i<len(t);i++{
		if t[i] > 1 || t[i] < -1{
			result[i] = 0
		}else{
			result[i] = math.Pow(1- math.Pow(t[i],3),3)
		}
	}
}

//TriCubeFloat
func TriCubeFloat(f float64) float64{
	if f > 1 || f < -1{
		return 0
	}else{
		return math.Pow(1- math.Pow(f,3),3)
	}
}