package mathUtils

import "fmt"

type BiGraphCrosser struct {
	nHors   int         // num of horizons
	nSids   int         // num of sids
	sids    []int       // full sid list
	sid2idx map[int]int // sid -> sidIdx

	wgts   []float64 // sidIdx -> wgt
	g2     [][]int   // sidIdx -> grpIdx array
	g2Size int

	col_sum        []float64
	wgt_sum        float64
	active_sid_set []bool
	global_mean    []float64

	data       [][]float64 // sid x hors
	resi_value [][]float64 // sid x hors

	g2_col_sum        [][]float64
	g2_wgt_sum        []float64
	g2_active_sid_set [][]bool // grp -> (sid set)

	// interal temp vars
	temp_resi_value []float64

	// result variable
	res []float64
}

func NewBiGraphCrosser(
	sids []int,
	nHors int,
	wgt_dict map[int]float64,
	g2_dict map[int][]int) *BiGraphCrosser {

	g := &BiGraphCrosser{}

	g.nHors = nHors
	g.nSids = len(sids)
	g.sids = sids
	g.sid2idx = make(map[int]int, g.nSids)
	for i, sid := range sids {
		g.sid2idx[sid] = i
	}

	// assign wgts
	g.wgts = make([]float64, g.nSids)
	for sid, wgt := range wgt_dict {
		if idx, ok := g.sid2idx[sid]; ok {
			g.wgts[idx] = wgt
		}
	}

	// assign g2 (concept) group
	g.g2 = make([][]int, g.nSids)
	for sid, grpIds := range g2_dict {
		if idx, ok := g.sid2idx[sid]; ok {
			g.g2[idx] = grpIds
			for _, grpId := range grpIds {
				if grpId+1 > g.g2Size {
					g.g2Size = grpId + 1
				}
			}
		}
	}

	g.col_sum = make([]float64, nHors)
	g.wgt_sum = 0.0
	g.active_sid_set = make([]bool, g.nSids)
	g.global_mean = make([]float64, nHors)

	g.data = make([][]float64, g.nSids)
	g.resi_value = make([][]float64, g.nSids)
	for idx := 0; idx < g.nSids; idx++ {
		g.data[idx] = make([]float64, g.nHors)
		g.resi_value[idx] = make([]float64, g.nHors)
	}

	g.g2_col_sum = make([][]float64, g.g2Size)
	g.g2_wgt_sum = make([]float64, g.g2Size)
	g.g2_active_sid_set = make([][]bool, g.g2Size)
	for grp := 0; grp < g.g2Size; grp++ {
		g.g2_col_sum[grp] = make([]float64, nHors)
		g.g2_wgt_sum[grp] = 0.0
		g.g2_active_sid_set[grp] = make([]bool, g.nSids)
	}

	g.temp_resi_value = make([]float64, nHors)

	g.res = make([]float64, nHors*3)

	return g
}

func (g *BiGraphCrosser) Update(sid int, values []float64) {
	if len(values) != g.nHors {
		panic(fmt.Sprintf("len(values) != g.nHors %d %d", len(values), g.nHors))
	}

	idx, ok := g.sid2idx[sid]
	if !ok {
		panic(fmt.Sprintf("BiGraphCrosser: Trying to feed in sid that is not registered: %d", sid))
	}

	g2_list := g.g2[idx]

	//# update global mean
	for i := 0; i < g.nHors; i++ {
		g.col_sum[i] = g.col_sum[i] + (values[i]-g.data[idx][i])*g.wgts[idx]
	}
	copy(g.data[idx], values)
	if !g.active_sid_set[idx] {
		g.active_sid_set[idx] = true
		g.wgt_sum = g.wgt_sum + g.wgts[idx]
	}
	for i := 0; i < g.nHors; i++ {
		g.global_mean[i] = g.col_sum[i] / g.wgt_sum
	}

	//# residual to global mean
	for i := 0; i < g.nHors; i++ {
		g.temp_resi_value[i] = values[i] - g.global_mean[i]
	}
	resi_value := g.resi_value[idx]
	wgt := g.wgts[idx]

	//# update g2 mean
	if len(g2_list) > 0 {
		for _, g2 := range g2_list {
			g2_col_sum := g.g2_col_sum[g2]
			for i := 0; i < g.nHors; i++ {
				g2_col_sum[i] = g2_col_sum[i] + (g.temp_resi_value[i]-resi_value[i])*wgt
			}
			if !g.g2_active_sid_set[g2][idx] {
				g.g2_active_sid_set[g2][idx] = true
				g.g2_wgt_sum[g2] = g.g2_wgt_sum[g2] + wgt
			}
		}
	}

	copy(g.resi_value[idx], g.temp_resi_value)
}

func (g *BiGraphCrosser) GetValue(sid int, outresult []float64) {

	idx, ok := g.sid2idx[sid]
	if !ok {
		panic(fmt.Sprintf("BiGraphCrosser: Trying to feed in sid that is not registered: %d", sid))
	}

	g2_list := g.g2[idx]

	// 0. global_mean
	copy(outresult, g.global_mean)

	// 1. g2_mean
	if len(g2_list) > 0 {
		for i := 0; i < g.nHors; i++ {
			sum := 0.0
			for _, g2 := range g2_list {
				if g.g2_wgt_sum[g2] > 0 {
					sum += g.g2_col_sum[g2][i] / g.g2_wgt_sum[g2]
				}
			}
			outresult[g.nHors+i] = sum / float64(len(g2_list))
		}
	} else {
		for i := 0; i < g.nHors; i++ {
			outresult[g.nHors+i] = 0
		}
	}

	// 3. g2_residual
	d := g.data[idx]
	for i := 0; i < g.nHors; i++ {
		//                     = origVal - global mean - group mean
		outresult[2*g.nHors+i] = d[i] - outresult[i] - outresult[g.nHors+i]
	}
}
