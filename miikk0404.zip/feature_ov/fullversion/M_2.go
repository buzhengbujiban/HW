package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
)

/*
var i2nM2 = map[string]int{
	"net":      0,
	"sum":      1, //下面引用的时候用的Sum
	"bigNet":   2,
	"bigSum":   3,
	"smallNet": 4,
	"smallBuy": 5, //下面引用的时候用的smallSum
}
*/

const (
	i2nM2Net      int = 0
	i2nM2Sum      int = 0 //to fixed as 1
	i2nM2BigNet   int = 2
	i2nM2BigSum   int = 3
	i2nM2SmallNet int = 4
	i2nM2SmallSum int = 0 //to fixed as 5
)

//一定保留(前提是互相关较小)M-2-2-2400s
//TODO 截面ir特征

type M_2 struct {
	FeatureBase
	hlList []float64 //1200-2400
	pLen   int

	start map[int]bool

	midPriceMap map[int]float64

	//return
	ret     []float64
	volumes map[int][]float64 //buy, bigbuy, smallbuy
	emaNet  map[int][][]*MXEMA
	emaSum  map[int][][]*MXEMA
}

func (seb *M_2) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.pLen = len(seb.hlList)
	return nil
}

//setFeatureNames: set column names.
func (seb *M_2) setFeatureNames() {
	seb.colNames = make([]string, seb.pLen*3)
	for i := 0; i < seb.pLen; i++ {
		for j := 0; j < 3; j++ {
			seb.colNames[i+j*seb.pLen] = fmt.Sprintf("%s-%d-%ds", seb.featureName, j, int(seb.hlList[i]))
		}
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *M_2) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.midPriceMap = make(map[int]float64)
	seb.start = make(map[int]bool)
	seb.volumes = make(map[int][]float64)
	seb.emaNet = make(map[int][][]*MXEMA)
	seb.emaSum = make(map[int][][]*MXEMA)

	for sid := range seb.sidUniverse {
		seb.volumes[sid] = make([]float64, 6)
		seb.emaNet[sid] = make([][]*MXEMA, 3)
		seb.emaSum[sid] = make([][]*MXEMA, 3)
		for j := 0; j < 3; j++ {
			seb.emaNet[sid][j] = make([]*MXEMA, seb.pLen)
			seb.emaSum[sid][j] = make([]*MXEMA, seb.pLen)
			for i := 0; i < seb.pLen; i++ {
				seb.emaNet[sid][j][i] = NewMXEMA(seb.hlList[i], 3)
				seb.emaSum[sid][j][i] = NewMXEMA(seb.hlList[i], 3)
			}
		}
	}
}

//Update
func (seb *M_2) UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}

	for i := 0; i < len(seb.volumes[sid]); i++ {
		seb.volumes[sid][i] = 0.
	}

	amt := 0.

	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.volumes[sid][i2nM2SmallNet] -= amt
			seb.volumes[sid][i2nM2SmallSum] -= amt
		} else {
			seb.volumes[sid][i2nM2BigNet] += amt
			seb.volumes[sid][i2nM2BigSum] += amt
		}
		seb.volumes[sid][i2nM2Net] += math.Abs(amt)
		seb.volumes[sid][i2nM2Sum] += math.Abs(amt)
	}
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.volumes[sid][i2nM2SmallNet] += amt
			seb.volumes[sid][i2nM2SmallSum] -= amt
		} else {
			seb.volumes[sid][i2nM2BigNet] -= amt
			seb.volumes[sid][i2nM2BigSum] += amt
		}
		seb.volumes[sid][i2nM2Net] -= math.Abs(amt)
		seb.volumes[sid][i2nM2Sum] += math.Abs(amt)
	}

	//seb.midPriceMap[sid] = E_midPrc(snapData[0], snapData[20])
	seb.midPriceMap[sid] = E_microPrc(snapData[0], snapData[20], snapData[1], snapData[21], 0.3)

	if snapDataLast == nil {
		return true
	}

	//midPriceLast := E_midPrc(snapDataLast[0], snapDataLast[20])
	midPriceLast := E_microPrc(snapDataLast[0], snapDataLast[20], snapDataLast[1], snapDataLast[21], 0.3)

	seb.start[sid] = true

	ratio := IgNa2Zero(5. * (seb.midPriceMap[sid]/midPriceLast - 1.0))
	for i := 0; i < seb.pLen; i++ {
		seb.emaNet[sid][0][i].Update(secSinceEpoch, ratio*seb.volumes[sid][i2nM2Net])
		seb.emaSum[sid][0][i].Update(secSinceEpoch, seb.volumes[sid][i2nM2Sum])
		seb.emaNet[sid][1][i].Update(secSinceEpoch, ratio*seb.volumes[sid][i2nM2BigNet])
		seb.emaSum[sid][1][i].Update(secSinceEpoch, seb.volumes[sid][i2nM2BigSum])
		seb.emaNet[sid][2][i].Update(secSinceEpoch, ratio*seb.volumes[sid][i2nM2SmallNet])
		seb.emaSum[sid][2][i].Update(secSinceEpoch, seb.volumes[sid][i2nM2SmallSum])
	}

	return true
}

//GetValues
func (seb *M_2) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else {
		a := 0.
		b := 0.
		for j := 0; j < 3; j++ {
			for i := 0; i < seb.pLen; i++ {
				a = seb.emaNet[sid][j][i].GetEms(secEpoch)
				b = seb.emaSum[sid][j][i].GetEms(secEpoch)
				seb.ret[i+j*seb.pLen] = DivIgNa(a, b)
			}
		}
	}
	return seb.ret, nil
}
