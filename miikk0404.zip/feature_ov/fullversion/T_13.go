package feature

//bookstructFeatures.go/MidPriceBookFeature
