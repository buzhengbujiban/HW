package feature

import (
	"TES/QR/alpha_ov/data"
	MU "TES/QR/alpha_ov/mathUtils"
	"fmt"
	"math"
)

//const ticksizeT10 = 0.01
// 5个特征， 倒数4个肯定要用2个, 其它正数的特征和T_8.go 类似

/*
var i2nT10 = map[string]int{
	"big":       0,
	"bigSell":   1,
	"bigBuy":    2,
	"small":     3,
	"smallSell": 4,
	"smallBuy":  5,
}
*/

const (
	i2nT10Big       int = 0
	i2nT10BigSell   int = 1
	i2nT10BigBuy    int = 2
	i2nT10Small     int = 3
	i2nT10SmallSell int = 4
	i2nT10SmallBuy  int = 5
)

//
type T_10 struct {
	FeatureBase
	hlList []float64
	pLen   int
	pow    float64

	doCross  bool
	crossers []*MU.WeightedNestedGroupMeanFast

	emaBuyLoc  map[int][]*MXEMA
	emaSellLoc map[int][]*MXEMA

	emaBuyPress       map[int][]*MXEMA
	emaSellPress      map[int][]*MXEMA
	emaBuyMeanPress1  map[int][]*MXEMA
	emaSellMeanPress1 map[int][]*MXEMA
	emaBuyMeanPress2  map[int][]*MXEMA
	emaSellMeanPress2 map[int][]*MXEMA

	amtSquare      map[int][]float64
	amtSquareGroup map[int][]float64

	start map[int]bool

	tempBidPrice []float64
	tempAskPrice []float64
	tempVals     []float64
	tempVals2    []float64

	groupData map[int]int

	lenPercent map[int]float64

	//return
	ret []float64
}

func (seb *T_10) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.doCross = seb.prefs.GetBoolPref(seb.featureName + "_do_cross")
	seb.pLen = len(seb.hlList)
	seb.pow = seb.prefs.GetFloat64Pref(seb.featureName + "_power")
	return nil
}

//setFeatureNames: set column names.
func (seb *T_10) setFeatureNames() {
	seb.colNames = make([]string, 5*3+4*seb.pLen+4*5*seb.pLen)
	for i := 0; i < 5; i++ {
		seb.colNames[i] = fmt.Sprintf("%s-%draw", seb.featureName, i)
		seb.colNames[5+i] = fmt.Sprintf("%s-%dg", seb.featureName, i)
		seb.colNames[10+i] = fmt.Sprintf("%s-%dres", seb.featureName, i)
	}
	for i := 0; i < seb.pLen; i++ {
		for j := 0; j < 4; j++ {
			seb.colNames[15+i+j*seb.pLen] = fmt.Sprintf("%s-%draw-%ds", seb.featureName, j, int(seb.hlList[i]))
		}
	}
	bias := 5*3 + 4*seb.pLen
	for i := 0; i < 4; i++ {
		for j := 0; j < seb.pLen; j++ {
			seb.colNames[bias+j] = fmt.Sprintf("%s-%dm-%ds", seb.featureName, i, int(seb.hlList[j]))
			seb.colNames[bias+1*seb.pLen+j] = fmt.Sprintf("%s-%dim-%ds", seb.featureName, i, int(seb.hlList[j]))
			seb.colNames[bias+2*seb.pLen+j] = fmt.Sprintf("%s-%dcm-%ds", seb.featureName, i, int(seb.hlList[j]))
			seb.colNames[bias+3*seb.pLen+j] = fmt.Sprintf("%s-%dir-%ds", seb.featureName, i, int(seb.hlList[j]))
			seb.colNames[bias+4*seb.pLen+j] = fmt.Sprintf("%s-%dcr-%ds", seb.featureName, i, int(seb.hlList[j]))
		}
		bias += seb.pLen * 5
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_10) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.crossers = make([]*MU.WeightedNestedGroupMeanFast, 4)
	for i := 0; i < 4; i++ {
		seb.crossers[i] = MU.NewWeightedNestedGroupMeanFast(seb.sidUniverseList, seb.pLen, seb.baseSidWgts, seb.industryCode, seb.conceptCodes)
	}

	seb.start = make(map[int]bool)

	seb.tempBidPrice = make([]float64, 0, 10)
	seb.tempAskPrice = make([]float64, 0, 10)
	seb.emaSellLoc = make(map[int][]*MXEMA)
	seb.emaBuyLoc = make(map[int][]*MXEMA)
	seb.emaSellPress = make(map[int][]*MXEMA)
	seb.emaBuyPress = make(map[int][]*MXEMA)
	seb.emaSellMeanPress1 = make(map[int][]*MXEMA)
	seb.emaBuyMeanPress1 = make(map[int][]*MXEMA)
	seb.emaSellMeanPress2 = make(map[int][]*MXEMA)
	seb.emaBuyMeanPress2 = make(map[int][]*MXEMA)

	seb.amtSquare = make(map[int][]float64)
	seb.amtSquareGroup = make(map[int][]float64)

	seb.groupData = make(map[int]int)
	seb.tempVals = make([]float64, seb.pLen)
	seb.tempVals2 = make([]float64, seb.pLen*5)

	seb.lenPercent = make(map[int]float64)

	for sid := range seb.sidUniverse {
		seb.start[sid] = false

		seb.emaSellLoc[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBuyLoc[sid] = make([]*MXEMA, seb.pLen)
		seb.emaSellPress[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBuyPress[sid] = make([]*MXEMA, seb.pLen)
		seb.emaSellMeanPress1[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBuyMeanPress1[sid] = make([]*MXEMA, seb.pLen)
		seb.emaSellMeanPress2[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBuyMeanPress2[sid] = make([]*MXEMA, seb.pLen)

		seb.amtSquare[sid] = make([]float64, 6)

		for j := 0; j < seb.pLen; j++ {
			seb.emaSellLoc[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaBuyLoc[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaSellPress[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaBuyPress[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaSellMeanPress1[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaBuyMeanPress1[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaSellMeanPress2[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaBuyMeanPress2[sid][j] = NewMXEMA(seb.hlList[j], 3)
		}
	}
}

func (seb *T_10) initializeGroup(gid int) {
	if _, ok := seb.amtSquareGroup[gid]; !ok {
		seb.amtSquareGroup[gid] = make([]float64, 6)
	}
}

//Update
func (seb *T_10) UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	amt := 0.

	priceSellMax := -1.
	priceBuyMax := -1.

	priceSellMean := -1.
	priceBuyMean := -1.

	amtAll := 0.
	qtyAll := 0.

	if len(seb.groupData) == 0 {
		for sid, gid := range groupData {
			seb.groupData[sid] = gid
		}
	}
	gid := seb.groupData[sid]

	seb.initializeGroup(gid)

	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		amtAll += math.Abs(amt)
		qtyAll += psp.Qty

		amt = powerTransform(amt, seb.pow)
		priceBuyMax = math.Max(priceBuyMax, psp.Price)

		if amt < 0 {
			seb.amtSquare[sid][i2nT10SmallBuy] += amt * amt
			seb.amtSquare[sid][i2nT10Small] += amt * amt
			seb.amtSquareGroup[gid][i2nT10SmallBuy] += amt * amt
			seb.amtSquareGroup[gid][i2nT10Small] += amt * amt

		} else {
			for j := 0; j < seb.pLen; j++ {
				seb.amtSquare[sid][i2nT10BigBuy] += amt * amt
				seb.amtSquare[sid][i2nT10Big] += amt * amt
				seb.amtSquareGroup[gid][i2nT10BigBuy] += amt * amt
				seb.amtSquareGroup[gid][i2nT10Big] += amt * amt
			}
		}
	}
	if qtyAll > E_EPS {
		priceBuyMean = amtAll / qtyAll
	}

	amtAll = 0.
	qtyAll = 0.
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		amtAll += math.Abs(amt)
		qtyAll += psp.Qty

		amt = powerTransform(amt, seb.pow)
		priceSellMax = math.Max(priceSellMax, psp.Price)

		if amt < 0 {
			for j := 0; j < seb.pLen; j++ {
				seb.amtSquare[sid][i2nT10SmallSell] += amt * amt
				seb.amtSquare[sid][i2nT10Small] += amt * amt
				seb.amtSquareGroup[gid][i2nT10SmallSell] += amt * amt
				seb.amtSquareGroup[gid][i2nT10Small] += amt * amt
			}
		} else {
			for j := 0; j < seb.pLen; j++ {
				seb.amtSquare[sid][i2nT10BigSell] += amt * amt
				seb.amtSquare[sid][i2nT10Big] += amt * amt
				seb.amtSquareGroup[gid][i2nT10BigSell] += amt * amt
				seb.amtSquareGroup[gid][i2nT10Big] += amt * amt
			}
		}
	}
	if qtyAll > E_EPS {
		priceSellMean = amtAll / qtyAll
	}

	if snapDataLast == nil {
		return true
	}

	loc := 0

	seb.tempBidPrice = seb.tempBidPrice[:0]
	seb.tempAskPrice = seb.tempAskPrice[:0]
	for i := 0; i < 10; i++ {
		seb.tempAskPrice = append(seb.tempAskPrice, snapDataLast[i*2])
		seb.tempBidPrice = append(seb.tempBidPrice, snapDataLast[i*2])
	}
	//很可能两个snap之间只有3s，效果不好
	//股票2581两个snap 191.9 190.8， 有100个ticksize差别，正常我看是20个， 茅台差不多是150个
	//所以这里截断的很多，有点问题, 后面可能换上价格
	priceUnit := math.Max(0.5*math.Abs(snapDataLast[8]-snapDataLast[0])/4.+0.5*math.Abs(snapDataLast[20]-snapDataLast[28])/4., snapDataLast[0]-snapDataLast[20])
	priceOpen := snapDataLast[40]
	lenPercent := priceOpen * 0.001 / priceUnit
	seb.lenPercent[sid] = lenPercent

	lenPercent = math.Max(1., lenPercent)

	if priceBuyMax > 0 {
		loc = SearchNearLoc(seb.tempAskPrice, priceBuyMax)
		//loc, _ = SearchSameLoc(seb.tempAskPrice, priceBuyMax)
		for j := 0; j < seb.pLen; j++ {
			if loc > -2 {
				seb.emaBuyLoc[sid][j].Update(secSinceEpoch, (float64(loc+1)/lenPercent)*(float64(loc+1)/lenPercent)/36.0) //越大越买
			}
		}
	}
	if priceSellMax > 0 {
		loc = SearchNearLoc(seb.tempBidPrice, priceSellMax)
		//loc, _ = SearchSameLoc(seb.tempBidPrice, priceSellMax)
		for j := 0; j < seb.pLen; j++ {
			if loc > -2 {
				seb.emaSellLoc[sid][j].Update(secSinceEpoch, (float64(loc+1)/lenPercent)*(float64(loc+1)/lenPercent)/36.0) //越大越卖
			}
		}
	}

	//股票2581两个snap 191.9 190.8， 有100个ticksize差别，正常我看是20个， 茅台差不多是150个, 如果是开盘的时候，价差应该更大，发现2581有3元
	//ticksizeT10 不用0.01而是下面
	ticksizeT10 := (snapData[18] - snapData[38]) / 19.
	if priceBuyMax > 0 {
		value := math.Max(priceBuyMax-snapData[0], 0.) / ticksizeT10
		/*
			if sid == 2016 {
				fmt.Println(sid, value)
			}
		*/
		value = math.Min(value*value/100., 5.)
		for j := 0; j < seb.pLen; j++ {
			seb.emaSellPress[sid][j].Update(secSinceEpoch, value) //越大越卖
		}
	}
	if priceSellMax > 0 {
		value := math.Max(snapData[20]-priceSellMax, 0.) / ticksizeT10
		value = math.Min(value*value/100., 5.)
		for j := 0; j < seb.pLen; j++ {
			seb.emaBuyPress[sid][j].Update(secSinceEpoch, value) //越大越买
		}
	}

	if priceBuyMean > 0 {
		value := ClipIgNa((priceBuyMean-snapData[0])/ticksizeT10, 10.) / 10.
		for j := 0; j < seb.pLen; j++ {
			seb.emaSellMeanPress1[sid][j].Update(secSinceEpoch, value) //越大越卖
		}
		snapQty := 0.
		snapAmt := 0.
		for i := 0; i < 5; i++ {
			snapQty += snapData[i*2+1]
			snapAmt += snapData[i*2] * snapData[i*2+1]
		}
		snapAskMean := snapAmt / snapQty
		value = ClipIgNa((priceBuyMean-snapAskMean)/ticksizeT10, 10.) / 10.
		for j := 0; j < seb.pLen; j++ {
			seb.emaSellMeanPress2[sid][j].Update(secSinceEpoch, value) //越大越卖
		}
	}
	if priceSellMean > 0 {
		value := ClipIgNa((snapData[20]-priceSellMean)/ticksizeT10, 10.) / 10.
		for j := 0; j < seb.pLen; j++ {
			seb.emaBuyMeanPress1[sid][j].Update(secSinceEpoch, value) //越大越买
		}
		snapQty := 0.
		snapAmt := 0.
		for i := 0; i < 5; i++ {
			snapQty += snapData[20+i*2+1]
			snapAmt += snapData[20+i*2] * snapData[20+i*2+1]
		}
		snapBidMean := snapAmt / snapQty
		value = ClipIgNa((snapBidMean-priceSellMean)/ticksizeT10, 10.) / 10.
		for j := 0; j < seb.pLen; j++ {
			seb.emaBuyMeanPress2[sid][j].Update(secSinceEpoch, value) //越大越买
		}
	}

	seb.start[sid] = true

	return true
}

//GetValues
func (seb *T_10) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else {

		a := 0.
		b := 0.
		c := 0.
		d := 0.

		c = seb.amtSquare[sid][i2nT10Small]
		d = seb.amtSquare[sid][i2nT10Big]

		a = seb.amtSquare[sid][i2nT10BigBuy]
		b = seb.amtSquare[sid][i2nT10BigSell]
		seb.ret[0] = DivIgNa(a-b, c+d)
		seb.ret[1] = DivIgNa(a+b, c+d)

		a = seb.amtSquare[sid][i2nT10SmallBuy]
		b = seb.amtSquare[sid][i2nT10SmallSell]
		seb.ret[2] = DivIgNa(a-b, c+d)
		seb.ret[3] = DivIgNa(a+b, c+d)

		seb.ret[4] = DivIgNa(c-d, c+d)

		gid := seb.groupData[sid]
		c = seb.amtSquareGroup[gid][i2nT10Small]
		d = seb.amtSquareGroup[gid][i2nT10Big]

		a = seb.amtSquareGroup[gid][i2nT10BigBuy]
		b = seb.amtSquareGroup[gid][i2nT10BigSell]
		seb.ret[5] = DivIgNa(a-b, c+d)
		seb.ret[6] = DivIgNa(a+b, c+d)

		a = seb.amtSquareGroup[gid][i2nT10SmallBuy]
		b = seb.amtSquareGroup[gid][i2nT10SmallSell]
		seb.ret[7] = DivIgNa(a-b, c+d)
		seb.ret[8] = DivIgNa(a+b, c+d)

		seb.ret[9] = DivIgNa(c-d, c+d)

		for i := 0; i < 5; i++ {
			seb.ret[10+i] = seb.ret[i] - seb.ret[5+i]
		}

		for j := 0; j < seb.pLen; j++ {

			a = seb.emaBuyLoc[sid][j].GetEma()
			b = seb.emaSellLoc[sid][j].GetEma()
			seb.ret[15+j+0*seb.pLen] = DivIgNa(a-b, a+b) // a-b

			a = seb.emaBuyPress[sid][j].GetEma()
			b = seb.emaSellPress[sid][j].GetEma()
			seb.ret[15+j+1*seb.pLen] = DivIgNa(a-b, a+b)

			a = seb.emaBuyMeanPress1[sid][j].GetEma()
			b = seb.emaSellMeanPress1[sid][j].GetEma()
			seb.ret[15+j+2*seb.pLen] = a - b

			a = seb.emaBuyMeanPress2[sid][j].GetEma()
			b = seb.emaSellMeanPress2[sid][j].GetEma()
			seb.ret[15+j+3*seb.pLen] = a - b

			/*
				if sid == 2016 {
					fmt.Println(sid, seb.emaBuyPress[sid][j].GetEma(), seb.emaSellPress[sid][j].GetEma(), j)
				}
			*/
		}

		bias := 5*3 + 4*seb.pLen

		for i := 0; i < 4; i++ {
			for j := 0; j < seb.pLen; j++ {
				seb.tempVals[j] = naInf2Zero(seb.ret[j+(10+i)*seb.pLen])
			}
			seb.crossers[i].Update(sid, seb.tempVals)
			seb.crossers[i].GetValue(sid, seb.tempVals2)
			for j := 0; j < seb.pLen; j++ {
				for k := 0; k < 5; k++ {
					seb.ret[bias+seb.pLen*k+j] = seb.tempVals2[seb.pLen*k+j]
				}
			}
			bias += seb.pLen * 5
		}
		/*
			if sid == 2016 {
				fmt.Println(sid, seb.ret[0+4*seb.pLen], seb.ret[1+4*seb.pLen], seb.ret[2+4*seb.pLen])
			}
		*/
	}
	return seb.ret, nil
}
