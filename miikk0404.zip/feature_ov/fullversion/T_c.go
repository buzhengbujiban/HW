package feature

import (
	"TES/QR/alpha_ov/data"
	"autosupply/util"
	"fmt"
	"math"
	"strings"
	"table"
)

type T_c struct {
	FeatureBase
	emaData map[int][]*MXEMA
	ringBuf map[int][]*floatRingBuf
	tempBuf []float64

	pLen     int
	hlList   []float64
	sizeList []int

	ret       []float64
	epochLast float64

	count int

	bigAmt       float64
	bigSellAmt   float64
	bigBuyAmt    float64
	smallAmt     float64
	smallSellAmt float64
	smallBuyAmt  float64

	dt   *table.DataTable
	dump int

	sellPrice float64
	ask1      float64
}

func (seb *T_c) loadFeaturePrefs() error {
	seb.hlList = []float64{100}
	seb.pLen = len(seb.hlList)
	seb.sizeList = []int{30}
	return nil
}

//setFeatureNames: set column names.
func (seb *T_c) setFeatureNames() {
	seb.colNames = make([]string, seb.pLen)
	for i := 0; i < seb.pLen; i++ {
		seb.colNames[i] = fmt.Sprintf("%s-acc%ds", seb.featureName, int(seb.hlList[i]))
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_c) initInternalVars() {
	seb.FeatureBase.initInternalVars()
	seb.emaData = make(map[int][]*MXEMA)
	seb.ringBuf = make(map[int][]*floatRingBuf)
	//seb.dt = tblNew([]string{"sid", "epoch", "bigAmt", "bigSellAmt", "bigBuyAmt", "smallAmt", "smallSellAmt", "smallBuyAmt"})
	//seb.dt = tblNew([]string{"sid", "epoch", "bigAmtQ95", "bigSellAmtQ95", "bigBuyAmtQ95", "bigAmtQ90", "bigSellAmtQ90", "bigBuyAmtQ90", "smallAmtQ50", "smallSellAmtQ50",
	//	"smallBuyAmtQ50", "smallAmtQ0", "smallSellAmtQ0", "smallBuyAmtQ0"})
	seb.dt = tblNew([]string{"sid", "epoch", "price", "qty", "oid", "tag"})
	for sid := range seb.sidUniverse {
		seb.emaData[sid] = make([]*MXEMA, seb.pLen)
		seb.ringBuf[sid] = make([]*floatRingBuf, seb.pLen)
		for i := 0; i < seb.pLen; i++ {
			seb.emaData[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.ringBuf[sid][i] = newFloatRingBuf(seb.sizeList[i])
		}
	}
	seb.tempBuf = make([]float64, 10)
}

func (seb *T_c) UpdateDoubleSecPrcQtyTagSliceSnapCheck(sid int, secSinceEpoch float64, buyObs []data.PriceQtyTag, sellObs []data.PriceQtyTag, snapData []float64, epochOri float64) bool {
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	amt := 0.
	bigAmtQ95 := 0.
	bigSellAmtQ95 := 0.
	bigBuyAmtQ95 := 0.
	bigAmtQ90 := 0.
	bigSellAmtQ90 := 0.
	bigBuyAmtQ90 := 0.
	smallAmtQ50 := 0.
	smallSellAmtQ50 := 0.
	smallBuyAmtQ50 := 0.
	smallAmtQ0 := 0.
	smallSellAmtQ0 := 0.
	smallBuyAmtQ0 := 0.
	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if psp.Tag == 3 {
			bigAmtQ95 += amt
			bigBuyAmtQ95 += amt
		} else if psp.Tag == 2 {
			bigAmtQ90 += amt
			bigBuyAmtQ90 += amt
		} else if psp.Tag == 1 {
			smallAmtQ50 += amt
			smallBuyAmtQ50 += amt
		} else if psp.Tag == 0 {
			smallAmtQ0 += amt
			smallBuyAmtQ0 += amt
		} else {
		}
	}
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if psp.Tag == 3 {
			bigAmtQ95 += amt
			bigSellAmtQ95 += amt
		} else if psp.Tag == 2 {
			bigAmtQ90 += amt
			bigSellAmtQ90 += amt
		} else if psp.Tag == 1 {
			smallAmtQ50 += amt
			smallSellAmtQ50 += amt
		} else if psp.Tag == 0 {
			smallAmtQ0 += amt
			smallSellAmtQ0 += amt
		} else {
		}
	}

	//sidList := []int{1219, 1013, 2212, 2916, 9489, 558, 1101, 226, 2406, 399}

	//if ContainInt(sidList, sid) {
	seb.dt.AddRow([]float64{float64(sid), epochOri, bigAmtQ95, bigSellAmtQ95, bigBuyAmtQ95, bigAmtQ90, bigSellAmtQ90, bigBuyAmtQ90, smallAmtQ50, smallSellAmtQ50, smallBuyAmtQ50, smallAmtQ0, smallSellAmtQ0, smallBuyAmtQ0})
	if strings.Compare(util.EpochToHMS(epochOri), "14:56:00") == 1 && seb.dump == 0 {
		tblWrite(seb.dt, fmt.Sprintf("/data/nas2Data/chinaEquityData/xixian/feature_OV6/dumpAllDifferSize/%d.tbl", util.EpochToDateInt(epochOri)))
		seb.dump = 1
	}
	//}
	return true

}

//Update
func (seb *T_c) UpdateDoubleSecPrcQtySliceSnapCheck(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, epochOri float64) bool {
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	amt := 0.
	bigAmt := 0.
	bigSellAmt := 0.
	bigBuyAmt := 0.
	smallAmt := 0.
	smallSellAmt := 0.
	smallBuyAmt := 0.
	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			smallAmt += math.Abs(amt)
			smallBuyAmt += math.Abs(amt)
		} else {
			bigAmt += amt
			bigBuyAmt += amt
		}
	}
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			smallAmt += math.Abs(amt)
			smallSellAmt += math.Abs(amt)
		} else {
			bigAmt += amt
			bigSellAmt += amt
		}
	}

	//ratio := DivIgNa(bigAmt-smallAmt, bigAmt+smallAmt)
	//ratioSell := DivIgNa(bigSellAmt-smallSellAmt, bigSellAmt+smallSellAmt)
	//ratioBuy := DivIgNa(bigBuyAmt-smallBuyAmt, bigBuyAmt+smallBuyAmt)

	/*
		if sid == 2212 {
			fmt.Println(secSinceEpoch, secSinceEpoch-seb.epochLast, epochOri, util.EpochToHMS(epochOri))
			fmt.Printf("ratio:%.2f, sellratio:%.2f, buyratio:%.2f\n", ratio, ratioSell, ratioBuy)
			fmt.Printf("bigAmt:%.2f, bigSellAmt:%.2f, bigBuyAmt:%.2f, smallAmt:%.2f, smallSellAmt:%.2f, smallBuyAmt:%.2f\n", bigAmt, bigSellAmt, bigBuyAmt, smallAmt, smallSellAmt, smallBuyAmt)
			if seb.epochLast > 1 && secSinceEpoch-seb.epochLast > 20 {
				panic("***")
			}
			seb.epochLast = secSinceEpoch
			seb.count += 1
		}
	*/

	if sid == 2212 {
		if strings.Compare(util.EpochToHMS(epochOri), "09:35:00") == 1 && strings.Compare(util.EpochToHMS(epochOri), "09:55:00") == -1 {
			seb.bigAmt += bigAmt
			seb.bigSellAmt += bigSellAmt
			seb.bigBuyAmt += bigBuyAmt
			seb.smallAmt += smallAmt
			seb.smallSellAmt += smallSellAmt
			seb.smallBuyAmt += smallBuyAmt
			fmt.Printf("cum - bigAmt:%.2f, bigSellAmt:%.2f, bigBuyAmt:%.2f, smallAmt:%.2f, smallSellAmt:%.2f, smallBuyAmt:%.2f, time:%s\n", seb.bigAmt, seb.bigSellAmt, seb.bigBuyAmt, seb.smallAmt, seb.smallSellAmt, seb.smallBuyAmt, util.EpochToHMS(epochOri))
		}

	}

	//sidList := []int{1219, 1013, 2212, 2916, 9489, 558, 1101, 226, 2406, 399}

	seb.dt.AddRow([]float64{float64(sid), epochOri, bigAmt, bigSellAmt, bigBuyAmt, smallAmt, smallSellAmt, smallBuyAmt})
	if strings.Compare(util.EpochToHMS(epochOri), "14:56:00") == 1 && seb.dump == 0 {
		tblWrite(seb.dt, fmt.Sprintf("/data/nas2Data/chinaEquityData/xixian/feature_OV6/dumpAll/%d.tbl", util.EpochToDateInt(epochOri)))
		seb.dump = 1
	}
	return true
}

//Update
func (seb *T_c) UpdateSecPrcQtyOidTagSliceSnapCheck(sid int, secSinceEpoch float64, Obs []data.PriceQtyOidTag, snapData []float64, epochOri float64) bool {
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}

	sidList := []int{1219, 1013, 2212, 2916, 9489, 558, 1101, 226, 2406, 399}

	if ContainInt(sidList, sid) {
		for _, psp := range Obs {
			seb.dt.AddRow([]float64{float64(sid), epochOri, psp.Price, psp.Qty, float64(psp.Oid), float64(psp.Tag)})
			if sid == 2212 {
				seb.sellPrice = psp.Price
				seb.ask1 = snapData[0]
			}
		}

		if strings.Compare(util.EpochToHMS(epochOri), "14:56:00") == 1 && seb.dump == 0 {
			tblWrite(seb.dt, fmt.Sprintf("/data/nas2Data/chinaEquityData/xixian/feature_OV6/dumpAllWithOid/%d.tbl", util.EpochToDateInt(epochOri)))
			seb.dump = 1
		}
	}

	return true
}

//GetValues
func (seb *T_c) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	if sid == 2212 {
		fmt.Println("*******************count:", seb.count, seb.sellPrice, seb.ask1)
		seb.count = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		for i := 0; i < len(seb.ret); i++ {
			seb.ret[i] = -2.3
		}
		return seb.ret, nil
	} else {
		for i := 0; i < len(seb.ret); i++ {
			seb.ret[i] = 2.3
		}
	}
	return seb.ret, nil
}
