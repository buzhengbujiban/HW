package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"math"
	"sort"
	"strconv"
	"strings"
)

//类似 bookFeatures.go/SignedEMABookV2(没有实际使用)，返回4种特征，修改其中一个，引进了qty power
//TODO: qty使用/data/nas2Data/chinaEquityData/panel/minute-rollstats 截断, EMAmean改成EMA_impulse_mean
//TODO: 引入 equityFeatures.go/EquityDetrendSignedEMABook
//TODO: 只统计price/asksize, price/bidsize, midprice/asksize+bidsize

//改进：框架允许隔天， 返回了更多的统计量， 除了price/ask-bid 还有price/buy-sell
//偏离太多的price不参与统计
type E_7Item struct {
	ema           map[float64]*MXEMA
	emaAsk        map[float64]*MXEMA
	emaBid        map[float64]*MXEMA
	prices        []float64
	updateNum     int
	midPrice      float64
	priceNumLimit int
	nearSize      int
}

//const E_7CPNAME = "E_7" //这种写法只支持feature只有一种参数配置

var E_7CPnames = []string{}

func (item *E_7Item) ToCP() []interface{} {
	return []interface{}{}
}

func (item *E_7Item) FromCP(v []interface{}) {
}

func (item *E_7Item) String() string {
	return fmt.Sprintf("%T", item)
}

func (item *E_7Item) OVRoll(ca, emaTime float64) bool {
	r := false
	return r
}

var _ OVIterm = (*E_7Item)(nil)

type E_7 struct {
	OVBase

	items              []*E_7Item
	hl                 float64
	power              float64
	levels             []int   // 1_2_3_4_5_6_7_8_9_10, 1_2_3_4_5,  6_7_8_9_10
	priceNumLimitRatio float64 //50/100 可能要使用历史的信息，比如茅台的可能比较大，每天1000-2000个tick
	nearSizeRatio      float64 //2/100 可能要使用历史的信息，比如茅台的可能比较大，每天1000-2000个tick
	tag                string
	debug              bool
	E_7CPNAME          string
}

var (
	E_7TermnamesDebug = []string{"ratio", "spread", "tStats", "ret", "ratioLoc", "ratioLoc2", "Pres", "Resis", "Pres2", "Resis2"}
	E_7Termnames      = []string{"ratio", "spread", "tStats", "ret", "ratioLoc", "ratioLoc2", "Pres", "Resis", "Pres2", "Resis2"}
)

// prefs_name, feature_name, log_dir, datestr
func (t *E_7) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *E_7) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	//t.tag = t.prefs.GetStringPref(t.featureName + ".tag")
	//t.E_7CPNAME = strings.Join([]string{"E_7", t.tag}, "")
	t.E_7CPNAME = t.featureName
	t.UpdateCPInfo(t, t.E_7CPNAME, E_7CPnames)
	return nil
}

func (t *E_7) TermName() string {
	return "E_7"
}

func (t *E_7) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *E_7) names() []string {
	if t.debug {
		names := make([]string, len(E_7TermnamesDebug))
		for i := range E_7TermnamesDebug {
			names[i] = E_7TermnamesDebug[i]
		}
		return names
	}
	names := make([]string, len(E_7Termnames))
	for i := range E_7Termnames {
		names[i] = E_7Termnames[i]
	}
	return names
}

func (t *E_7) inputs() []int {
	return []int{INPUT_MSG_TOB, INPUT_MSG_TRADE}
}

func (t *E_7) loadFeaturePrefs() error {
	levels := strings.Split(t.prefs.GetStringPref(t.featureName+".levels"), "_")
	t.levels = make([]int, len(levels))
	for i, level := range levels {
		num, _ := strconv.Atoi(level)
		t.levels[i] = num - 1
	}
	t.priceNumLimitRatio = t.prefs.GetFloat64Pref(t.featureName + ".priceNumLimitRatio")
	t.nearSizeRatio = t.prefs.GetFloat64Pref(t.featureName + ".nearSizeRatio")
	t.power = t.prefs.GetFloat64Pref(t.featureName + ".power")
	t.hl = t.prefs.GetFloat64Pref(t.featureName + ".hl")
	t.debug = t.prefs.GetBoolPref(t.featureName + ".debug")
	t.tag = t.prefs.GetStringPref(t.featureName + ".tag")
	return nil
}

func (t *E_7) loadDailyStats() {
}

//setFeatureNames: set column names.
func (t *E_7) setFeatureNames() {
	t.colNames = t.names()
	for i, n := range t.colNames {
		t.colNames[i] = fmt.Sprintf("%s.%s.%s", t.featureName, n, t.tag)
	}
	fmt.Println(t.colNames, len(t.colNames), len(RemoveDuplicateStr(t.colNames)))
}

//initialize internal variables
func (t *E_7) initInternalVars() {
	t.OVInit()
	t.items = make([]*E_7Item, t.nSids)
	for idx, _ := range t.items {
		item := new(E_7Item)
		item.ema = make(map[float64]*MXEMA)
		item.emaAsk = make(map[float64]*MXEMA)
		item.emaBid = make(map[float64]*MXEMA)
		item.prices = make([]float64, 0, 100) // 事先分配cap，加快速度
		t.items[idx] = item
	}
}

func (t *E_7) updateItem(item *E_7Item, secs float64, price float64, qty float64, tag string) {
	if _, ok := item.ema[price]; !ok {
		item.prices = append(item.prices, price)
		item.ema[price] = NewMXEMA(t.hl, 3)
		item.emaAsk[price] = NewMXEMA(t.hl, 3)
		item.emaBid[price] = NewMXEMA(t.hl, 3)
	}
	item.ema[price].Update(secs, powerTransform(qty, t.power))
	if tag == "ask" {
		item.emaAsk[price].Update(secs, -powerTransform(qty, t.power))
	} else if tag == "bid" {
		item.emaBid[price].Update(secs, powerTransform(qty, t.power))
	} else {
	}
}

func (t *E_7) TermUpdateTOB(sid int, secs float64, it OVIterm, tob *MsgTOB) {
	item := it.(*E_7Item)
	item.updateNum += 1

	askSizeBook := tob.askSizeBook
	askPriceBook := tob.askPriceBook
	bidSizeBook := tob.bidSizeBook
	bidPriceBook := tob.bidPriceBook

	tickNums := tob.open * 0.02 / 0.01
	item.priceNumLimit = int(tickNums * t.priceNumLimitRatio)
	item.nearSize = int(tickNums * t.nearSizeRatio)
	if item.priceNumLimit < 50 {
		item.priceNumLimit = 50
	}
	if item.nearSize < 2 {
		item.nearSize = 2
	}

	for _, level := range t.levels {
		//这里假设了ask bid的价格肯定不一样，否则同一个价格同时Update，会有bug
		t.updateItem(item, secs, askPriceBook[level], -askSizeBook[level], "ask")
		t.updateItem(item, secs, bidPriceBook[level], bidSizeBook[level], "bid")
	}
	//item.midPrice = tob.mid
	item.midPrice = tob.robust
}

func (t *E_7) TermUpdateTrade(sid int, secs float64, it OVIterm, trade *MsgTrade) {
	panic("E_7 not for TermUpdateTrade currently!")
}

func (t *E_7) TermUpdateAny(sid int, secs float64, it OVIterm) {
	// common logic for TermUpdateTOB & TermUpdateTrade
}

func (t *E_7) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*E_7Item)

	if len(item.prices) == 0 { // TOB接受到第一个股票时候，便会开始snap所有的sid
		return
	}

	sort.Float64s(item.prices) //用于后面sort.SearchFloat64s
	qtys := make([]float64, len(item.prices))
	qtysAsk := make([]float64, len(item.prices))
	qtysBid := make([]float64, len(item.prices))
	for i, price := range item.prices {
		qtys[i] = item.ema[price].GetEma()
		qtysAsk[i] = item.emaAsk[price].GetEma()
		qtysBid[i] = item.emaBid[price].GetEma()
	}

	locMid := SearchNearLocSimilarAsOldDeleted(item.prices, item.midPrice) // 如果找不到就返回最相邻的位置
	locLeft := int(math.Max(0., float64(locMid-item.priceNumLimit)))
	locRight := int(math.Min(float64(locMid+item.priceNumLimit), float64(len(item.prices))-1.))

	if len(qtys[locLeft:locRight+1]) <= 0 {
		return
	}

	res[0] = BuySellRatioIgNa(qtys[locLeft : locRight+1])
	res[1] = BuySellSpreadIgNa(item.prices[locLeft:locRight+1], qtys[locLeft:locRight+1], item.midPrice)
	//qtysAbs := MU.ArrAbs(qtys) // 这是inplace
	qtysAbs := E_ArrAbs(qtys)
	res[2] = CalcTstatIgNa(item.prices[locLeft:locRight+1], qtysAbs[locLeft:locRight+1], item.midPrice)
	res[3] = CalcDevIgNa(item.prices[locLeft:locRight+1], qtysAbs[locLeft:locRight+1], item.midPrice)

	//和当前价格最近的几个
	tickPrice := 0.01
	locs := make([]int, 0, 2*item.nearSize+1)
	for i := 1; i <= item.nearSize; i++ {
		if locMid-i >= 0 && locMid < len(item.prices) && item.prices[locMid]-item.prices[locMid-i] <= float64(item.nearSize)*tickPrice+E_EPS {
			locs = append(locs, locMid-i)
		}
		if locMid+i < len(item.prices) && locMid >= 0 && item.prices[locMid+i]-item.prices[locMid] <= float64(item.nearSize)*tickPrice+E_EPS {
			locs = append(locs, locMid+i)
		}
	}
	if locMid >= 0 && locMid < len(item.prices) {
		locs = append(locs, locMid)
	}
	locs = RemoveDuplicateInt(locs)

	if len(locs) <= 0 {
		return
	}

	res[4] = BuySellRatioLocsIgNa(qtys, locs)
	res[5] = BuySellRatioLocs2IgNaSimilarAsOldDeleted(qtysAsk, qtysBid, locs)

	//
	res[6], res[7] = GetPresResisSimilarAsOldDeleted(VecAddVec(qtysAsk, qtysBid), item.prices, item.midPrice, item.nearSize)
	res[8], res[9] = GetPresResisSimilarAsOldDeleted(qtys, item.prices, item.midPrice, item.nearSize)
}

var _ OVInterface = (*E_7)(nil)

//没什么用，注册这步被换到了featureBase.go了
func init() {
	TermFactoryInstance().Register("E-7", func() ITerm { return &E_7{} })
	TermFactoryInstance().Register("E-7L1", func() ITerm { return &E_7{} })
	TermFactoryInstance().Register("E-7L2", func() ITerm { return &E_7{} })
}
