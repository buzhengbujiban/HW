package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
)

/*
var i2nM1 = map[string]int{
	"sell":      0,
	"buy":       1,
	"bigSell":   2,
	"bigBuy":    3,
	"smallSell": 4,
	"smallBuy":  5,
}
*/

const (
	i2nM1Sell      int = 0
	i2nM1Buy       int = 1
	i2nM1BigSell   int = 2
	i2nM1BigBuy    int = 3
	i2nM1SmallSell int = 4
	i2nM1SmallBuy  int = 5
)

//交易量=主动买+主动卖，不是主动买，需要搞对

//一定保留(前提是互相关较小)M-1-1-2400s, M-1-5-2400s到M-1-9-2400s(选两个，是做空)  M-1-13-2400s（做多)
//TODO 截面ir特征
// ['M-1-1-2400s', 'M-1-5-2400s', 'M-1-8-2400s', 'M-1-13-2400s', 'M-2-2-2400s', 'M-2-0-2400s', 'T-12-0s']

type M_1 struct {
	FeatureBase
	hlList []float64 //1200-2400
	pLen   int

	start map[int]bool

	midPriceMap map[int]float64

	//return
	ret     []float64
	volumes map[int][]float64 //sell, buy, bigbuy, smallbuy, bigsell, smallsell, ask1, ask:3, ask:5, ask:10, bid1, bid:3, bid:5, bid:10
	emaPos  map[int][][]*MXEMA
	emaNeg  map[int][][]*MXEMA
}

func (seb *M_1) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.pLen = len(seb.hlList)
	return nil
}

//setFeatureNames: set column names.
func (seb *M_1) setFeatureNames() {
	seb.colNames = make([]string, seb.pLen*14)
	for i := 0; i < seb.pLen; i++ {
		for j := 0; j < len(seb.colNames); j++ {
			seb.colNames[i+j*seb.pLen] = fmt.Sprintf("%s-%d-%ds", seb.featureName, j, int(seb.hlList[i]))
		}
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *M_1) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.midPriceMap = make(map[int]float64)
	seb.start = make(map[int]bool)
	seb.volumes = make(map[int][]float64)
	seb.emaPos = make(map[int][][]*MXEMA)
	seb.emaNeg = make(map[int][][]*MXEMA)

	for sid := range seb.sidUniverse {
		seb.volumes[sid] = make([]float64, 14)
		seb.emaPos[sid] = make([][]*MXEMA, len(seb.volumes[sid]))
		seb.emaNeg[sid] = make([][]*MXEMA, len(seb.volumes[sid]))
		for j := 0; j < len(seb.volumes[sid]); j++ {
			seb.emaPos[sid][j] = make([]*MXEMA, seb.pLen)
			seb.emaNeg[sid][j] = make([]*MXEMA, seb.pLen)
			for i := 0; i < seb.pLen; i++ {
				seb.emaPos[sid][j][i] = NewMXEMA(seb.hlList[i], 3)
				seb.emaNeg[sid][j][i] = NewMXEMA(seb.hlList[i], 3)
			}
		}
	}
}

//Update
func (seb *M_1) UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}

	for i := 0; i < len(seb.volumes[sid]); i++ {
		seb.volumes[sid][i] = 0.
	}

	amt := 0.

	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.volumes[sid][i2nM1SmallBuy] -= amt
		} else {
			seb.volumes[sid][i2nM1BigBuy] += amt
		}
		seb.volumes[sid][i2nM1Buy] += math.Abs(amt)
	}
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.volumes[sid][i2nM1SmallSell] -= amt
		} else {
			seb.volumes[sid][i2nM1BigSell] += amt
		}
		seb.volumes[sid][i2nM1Sell] += math.Abs(amt)
	}

	//seb.midPriceMap[sid] = E_midPrc(snapData[0], snapData[20])
	seb.midPriceMap[sid] = E_microPrc(snapData[0], snapData[20], snapData[1], snapData[21], 0.3)

	if snapDataLast == nil {
		return true
	}

	//midPriceLast := E_midPrc(snapDataLast[0], snapDataLast[20])
	midPriceLast := E_microPrc(snapDataLast[0], snapDataLast[20], snapDataLast[1], snapDataLast[21], 0.3)

	seb.start[sid] = true

	for i := 0; i < 10; i++ {
		if i == 0 {
			seb.volumes[sid][6] += snapDataLast[i*2+1]
			seb.volumes[sid][10] += snapDataLast[i*2+21]
		}

		if i < 3 {
			seb.volumes[sid][7] += snapDataLast[i*2+1]
			seb.volumes[sid][11] += snapDataLast[i*2+21]
		}

		if i < 5 {
			seb.volumes[sid][8] += snapDataLast[i*2+1]
			seb.volumes[sid][12] += snapDataLast[i*2+21]
		}
		seb.volumes[sid][9] += snapDataLast[i*2+1]
		seb.volumes[sid][13] += snapDataLast[i*2+21]
	}
	vP := 0.
	vN := 0.
	if seb.midPriceMap[sid] > midPriceLast {
		vP = 1.
	} else if seb.midPriceMap[sid] < midPriceLast {
		vN = 1.
	} else {
	}
	for j := 0; j < len(seb.volumes[sid]); j++ {
		for i := 0; i < seb.pLen; i++ {
			seb.emaPos[sid][j][i].Update(secSinceEpoch, vP*seb.volumes[sid][j])
			seb.emaNeg[sid][j][i].Update(secSinceEpoch, vN*seb.volumes[sid][j])
		}
	}
	return true
}

//GetValues
func (seb *M_1) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else {
		a := 0.
		b := 0.
		for j := 0; j < len(seb.volumes[sid]); j++ {
			for i := 0; i < seb.pLen; i++ {
				a = seb.emaPos[sid][j][i].GetEms(secEpoch)
				b = seb.emaNeg[sid][j][i].GetEms(secEpoch)
				seb.ret[i+j*seb.pLen] = DivIgNa(a-b, a+b)
			}
		}
	}
	return seb.ret, nil
}
