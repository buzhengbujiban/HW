package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
)

// 选4个特征， raw 2个 demean 1个，mean 1个
type T_8 struct {
	FeatureBase

	pLen int
	pow  float64

	absAmt       map[int]float64
	bigAmt       map[int]float64
	bigSellAmt   map[int]float64
	bigBuyAmt    map[int]float64
	smallAmt     map[int]float64
	smallSellAmt map[int]float64
	smallBuyAmt  map[int]float64

	absAmtGroup       map[int]float64
	bigAmtGroup       map[int]float64
	bigSellAmtGroup   map[int]float64
	bigBuyAmtGroup    map[int]float64
	smallAmtGroup     map[int]float64
	smallSellAmtGroup map[int]float64
	smallBuyAmtGroup  map[int]float64

	groupData map[int]int

	//return
	ret []float64
}

func (seb *T_8) loadFeaturePrefs() error {
	seb.pLen = 1
	seb.pow = seb.prefs.GetFloat64Pref(seb.featureName + "_power")
	return nil
}

//setFeatureNames: set column names.
func (seb *T_8) setFeatureNames() {
	seb.colNames = make([]string, 11*seb.pLen*3)
	for i := 0; i < 11; i++ {
		seb.colNames[i] = fmt.Sprintf("%s-s%d", seb.featureName, i)
	}
	for i := 0; i < 11; i++ {
		seb.colNames[i+11] = fmt.Sprintf("%s-m%d", seb.featureName, i)
	}
	for i := 0; i < 11; i++ {
		seb.colNames[i+11+11] = fmt.Sprintf("%s-r%d", seb.featureName, i)
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_8) initInternalVars() {
	seb.FeatureBase.initInternalVars()
	seb.absAmt = make(map[int]float64)
	seb.bigAmt = make(map[int]float64)
	seb.bigSellAmt = make(map[int]float64)
	seb.bigBuyAmt = make(map[int]float64)
	seb.smallAmt = make(map[int]float64)
	seb.smallSellAmt = make(map[int]float64)
	seb.smallBuyAmt = make(map[int]float64)

	seb.absAmtGroup = make(map[int]float64)
	seb.bigAmtGroup = make(map[int]float64)
	seb.bigSellAmtGroup = make(map[int]float64)
	seb.bigBuyAmtGroup = make(map[int]float64)
	seb.smallAmtGroup = make(map[int]float64)
	seb.smallSellAmtGroup = make(map[int]float64)
	seb.smallBuyAmtGroup = make(map[int]float64)

	seb.groupData = make(map[int]int)

}

func (seb *T_8) initializeGroup(gid int) {
	if _, ok := seb.bigAmtGroup[gid]; !ok {
		seb.absAmtGroup[gid] = 0.
		seb.bigAmtGroup[gid] = 0.
		seb.bigSellAmtGroup[gid] = 0.
		seb.bigBuyAmtGroup[gid] = 0.
		seb.smallAmtGroup[gid] = 0.
		seb.smallSellAmtGroup[gid] = 0.
		seb.smallBuyAmtGroup[gid] = 0.
	}
}

//Update
//func (seb *T_8) UpdateDoubleSecPrcQtySliceSnapGroup(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, groupData map[int]int) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
func (seb *T_8) UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int) bool {

	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}

	if snapDataLast == nil {
		return true
	}

	amt := 0.
	ret := 0.

	if len(seb.groupData) == 0 {
		for sid, gid := range groupData {
			seb.groupData[sid] = gid
		}
	}

	//20170124  group缺失2023
	gid := seb.groupData[sid]
	/*
		if sid == 2023 {
			fmt.Println(gid)
		}
	*/
	seb.initializeGroup(gid)

	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		amt = powerTransform(amt, seb.pow)

		//ret = psp.Price/snapData[43] - 1.0
		ret = psp.Price/E_midPrc(snapDataLast[0], snapDataLast[20]) - 1.0

		if amt < 0 {
			seb.smallAmt[sid] -= amt * ret
			seb.smallBuyAmt[sid] -= amt * ret
			seb.smallAmtGroup[gid] -= amt * powerTransform(ret, seb.pow)
			seb.smallBuyAmtGroup[gid] -= amt * powerTransform(ret, seb.pow)
		} else {
			seb.bigAmt[sid] += amt * ret
			seb.bigBuyAmt[sid] += amt * ret
			seb.bigAmtGroup[gid] += amt * powerTransform(ret, seb.pow)
			seb.bigBuyAmtGroup[gid] += amt * powerTransform(ret, seb.pow)
		}
		seb.absAmt[sid] += math.Abs(amt)
		seb.absAmtGroup[gid] += math.Abs(amt)
	}
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		amt = powerTransform(amt, seb.pow)

		//ret = psp.Price/snapData[43] - 1.0
		ret = psp.Price/E_midPrc(snapDataLast[0], snapDataLast[20]) - 1.0

		if amt < 0 {
			seb.smallAmt[sid] -= amt * ret
			seb.smallSellAmt[sid] -= amt * ret
			seb.smallAmtGroup[gid] -= amt * powerTransform(ret, seb.pow)
			seb.smallSellAmtGroup[gid] -= amt * powerTransform(ret, seb.pow)

		} else {
			seb.bigAmt[sid] += amt * ret
			seb.bigSellAmt[sid] += amt * ret
			seb.bigAmtGroup[gid] += amt * powerTransform(ret, seb.pow)
			seb.bigSellAmtGroup[gid] += amt * powerTransform(ret, seb.pow)
		}
		seb.absAmt[sid] += math.Abs(amt)
		seb.absAmtGroup[gid] += math.Abs(amt)
	}

	return true
}

//GetValues
func (seb *T_8) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	gid := seb.groupData[sid]

	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if len(seb.groupData) == 0 {
		return seb.ret, nil
	} else {
		seb.ret[0] = DivIgNa(math.Abs(seb.bigAmt[sid])-math.Abs(seb.smallAmt[sid]), math.Abs(seb.bigAmt[sid])+math.Abs(seb.smallAmt[sid]))
		seb.ret[1] = DivIgNa(math.Abs(seb.bigSellAmt[sid])-math.Abs(seb.smallSellAmt[sid]), math.Abs(seb.bigSellAmt[sid])+math.Abs(seb.smallSellAmt[sid]))
		seb.ret[2] = DivIgNa(math.Abs(seb.bigBuyAmt[sid])-math.Abs(seb.smallBuyAmt[sid]), math.Abs(seb.bigBuyAmt[sid])+math.Abs(seb.smallBuyAmt[sid]))
		seb.ret[3] = DivIgNa(math.Abs(seb.bigBuyAmt[sid])-math.Abs(seb.bigSellAmt[sid]), math.Abs(seb.bigBuyAmt[sid])+math.Abs(seb.bigSellAmt[sid]))
		seb.ret[4] = DivIgNa(math.Abs(seb.smallBuyAmt[sid])-math.Abs(seb.smallSellAmt[sid]), math.Abs(seb.smallBuyAmt[sid])+math.Abs(seb.smallSellAmt[sid]))
		seb.ret[5] = DivIgNa(seb.bigAmt[sid], seb.absAmt[sid])
		seb.ret[6] = DivIgNa(seb.smallAmt[sid], seb.absAmt[sid])
		seb.ret[7] = DivIgNa(seb.bigBuyAmt[sid], seb.absAmt[sid])
		seb.ret[8] = DivIgNa(seb.smallBuyAmt[sid], seb.absAmt[sid])
		seb.ret[9] = DivIgNa(seb.bigSellAmt[sid], seb.absAmt[sid])
		seb.ret[10] = DivIgNa(seb.smallSellAmt[sid], seb.absAmt[sid])

		bias := 11

		//fmt.Println(gid, sid, seb.bigAmtGroup[gid])

		if _, ok := seb.bigAmtGroup[gid]; !ok {
			return seb.ret, nil
		}

		seb.ret[0+bias] = DivIgNa(math.Abs(seb.bigAmtGroup[gid])-math.Abs(seb.smallAmtGroup[gid]), math.Abs(seb.bigAmtGroup[gid])+math.Abs(seb.smallAmtGroup[gid]))
		seb.ret[1+bias] = DivIgNa(math.Abs(seb.bigSellAmtGroup[gid])-math.Abs(seb.smallSellAmtGroup[gid]), math.Abs(seb.bigSellAmtGroup[gid])+math.Abs(seb.smallSellAmtGroup[gid]))
		seb.ret[2+bias] = DivIgNa(math.Abs(seb.bigBuyAmtGroup[gid])-math.Abs(seb.smallBuyAmtGroup[gid]), math.Abs(seb.bigBuyAmtGroup[gid])+math.Abs(seb.smallBuyAmtGroup[gid]))
		seb.ret[3+bias] = DivIgNa(math.Abs(seb.bigBuyAmtGroup[gid])-math.Abs(seb.bigSellAmtGroup[gid]), math.Abs(seb.bigBuyAmtGroup[gid])+math.Abs(seb.bigSellAmtGroup[gid]))
		seb.ret[4+bias] = DivIgNa(math.Abs(seb.smallBuyAmtGroup[gid])-math.Abs(seb.smallSellAmtGroup[gid]), math.Abs(seb.smallBuyAmtGroup[gid])+math.Abs(seb.smallSellAmtGroup[gid]))
		seb.ret[5+bias] = DivIgNa(seb.bigAmtGroup[gid], seb.absAmtGroup[gid])
		seb.ret[6+bias] = DivIgNa(seb.smallAmtGroup[gid], seb.absAmtGroup[gid])
		seb.ret[7+bias] = DivIgNa(seb.bigBuyAmtGroup[gid], seb.absAmtGroup[gid])
		seb.ret[8+bias] = DivIgNa(seb.smallBuyAmtGroup[gid], seb.absAmtGroup[gid])
		seb.ret[9+bias] = DivIgNa(seb.bigSellAmtGroup[gid], seb.absAmtGroup[gid])
		seb.ret[10+bias] = DivIgNa(seb.smallSellAmtGroup[gid], seb.absAmtGroup[gid])

		for i := 0; i < bias; i++ {
			seb.ret[i+bias+bias] = seb.ret[i] - seb.ret[i+bias]
		}
	}
	return seb.ret, nil
}
