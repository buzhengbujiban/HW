package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
)

//累计imbalance 10s, 1min或者5min, 这里先用1min
type T_12 struct {
	FeatureBase

	start map[int]bool

	midPriceMap map[int]float64

	//return
	ret []float64

	kSnap     int //默认1个 1min， 可以是1个5min, 或者1个10min, 但是09:00:00开盘的没有数据，因此开盘第一个用1min，后面的用多分钟
	retLast   map[int][]float64
	countSnap map[int]int

	qtyStatsAsk   map[int]map[float64]float64
	qtyStatsBid   map[int]map[float64]float64
	askAmtHigh    []map[int]float64
	askQtyHigh    []map[int]float64
	bidAmtLow     []map[int]float64
	bidQtyLow     []map[int]float64
	priceTradeMax []map[int]float64
	priceTradeMin []map[int]float64
}

func (seb *T_12) loadFeaturePrefs() error {
	seb.kSnap = seb.prefs.GetIntPref(seb.featureName + "_kSnap")
	return nil
}

//setFeatureNames: set column names.
func (seb *T_12) setFeatureNames() {
	seb.colNames = make([]string, 1)
	for j := 0; j < 1; j++ {
		seb.colNames[j] = fmt.Sprintf("%s-%ds", seb.featureName, j)
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_12) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.midPriceMap = make(map[int]float64)
	seb.start = make(map[int]bool)
	seb.retLast = make(map[int][]float64)
	seb.countSnap = make(map[int]int)

	seb.qtyStatsAsk = make(map[int]map[float64]float64)
	seb.qtyStatsBid = make(map[int]map[float64]float64)
	seb.askAmtHigh = make([]map[int]float64, 1)
	seb.askQtyHigh = make([]map[int]float64, 1)
	seb.bidAmtLow = make([]map[int]float64, 1)
	seb.bidQtyLow = make([]map[int]float64, 1)
	seb.priceTradeMax = make([]map[int]float64, 1)
	seb.priceTradeMin = make([]map[int]float64, 1)
	for i := 0; i < 1; i++ {
		seb.askAmtHigh[i] = make(map[int]float64)
		seb.askQtyHigh[i] = make(map[int]float64)
		seb.bidAmtLow[i] = make(map[int]float64)
		seb.bidQtyLow[i] = make(map[int]float64)
		seb.priceTradeMax[i] = make(map[int]float64)
		seb.priceTradeMin[i] = make(map[int]float64)
	}

	for sid := range seb.sidUniverse {
		seb.qtyStatsAsk[sid] = make(map[float64]float64)
		seb.qtyStatsBid[sid] = make(map[float64]float64)
		seb.start[sid] = false
		seb.retLast[sid] = make([]float64, len(seb.ret))

		for i := 0; i < 1; i++ {
			seb.priceTradeMax[i][sid] = -1.
			seb.priceTradeMin[i][sid] = math.MaxFloat64
		}
	}
}

//Update
func (seb *T_12) UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	amt := 0.

	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt > 0 {
			seb.priceTradeMax[0][sid] = math.Max(seb.priceTradeMax[0][sid], psp.Price)
		}
	}
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt > 0 {
			seb.priceTradeMin[0][sid] = math.Min(seb.priceTradeMin[0][sid], psp.Price)
		}
	}

	if snapDataLast == nil {
		return true
	}

	seb.start[sid] = true

	seb.midPriceMap[sid] = E_midPrc(snapData[0], snapData[20])

	for i := 0; i < 10; i++ {
		seb.qtyStatsAsk[sid][snapData[i*2]] += snapData[i*2+1]
		seb.qtyStatsBid[sid][snapData[i*2+20]] += snapData[i*2+1+20]
	}

	return true
}

//GetValues
func (seb *T_12) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else if seb.countSnap[sid]+1 >= seb.kSnap && seb.countSnap[sid]%seb.kSnap > 0 {
		seb.countSnap[sid] += 1
		copy(seb.ret, seb.retLast[sid])
		return seb.ret, nil
	} else { //seb.kSnap前的每1分钟都更新，毕竟交易量大，其次每隔seb.kSnap更新一次
		seb.countSnap[sid] += 1

		for i := 0; i < 1; i++ {
			for price, qty := range seb.qtyStatsAsk[sid] {
				if price >= seb.priceTradeMax[i][sid] {
					seb.askAmtHigh[i][sid] += price * qty
					seb.askQtyHigh[i][sid] += qty
				}
			}
		}

		for i := 0; i < 1; i++ {
			for price, qty := range seb.qtyStatsBid[sid] {
				if price <= seb.priceTradeMin[i][sid] {
					seb.bidAmtLow[i][sid] += price * qty
					seb.bidQtyLow[i][sid] += qty
				}
			}
		}

		for i := 0; i < 1; i++ {
			if math.Abs(seb.askAmtHigh[i][sid]) <= E_EPS || math.Abs(seb.askQtyHigh[i][sid]) <= E_EPS || math.Abs(seb.bidAmtLow[i][sid]) <= E_EPS || math.Abs(seb.bidQtyLow[i][sid]) <= E_EPS {
				seb.ret[i] = math.NaN()
			} else {
				seb.ret[i] = (seb.askAmtHigh[i][sid]/seb.askQtyHigh[i][sid] + seb.bidAmtLow[i][sid]/seb.bidQtyLow[i][sid] - 2*seb.midPriceMap[sid]) / seb.midPriceMap[sid]
			}
		}

		//清空
		seb.qtyStatsAsk[sid] = make(map[float64]float64)
		seb.qtyStatsBid[sid] = make(map[float64]float64)

		for i := 0; i < 1; i++ {
			seb.priceTradeMax[i][sid] = -1.
			seb.priceTradeMin[i][sid] = math.MaxFloat64
		}
	}
	if seb.kSnap > 1 {
		copy(seb.retLast[sid], seb.ret)
	}
	return seb.ret, nil
}
