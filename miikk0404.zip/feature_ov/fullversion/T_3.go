package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
)

//TODO sid=1982 i=0, 会有连续很多snap进来的big单子为0， 因此buf求mean会有很多本来是0，但是结果是1e-10, 另外
//这种价格-大单的统计表，如果hl够大，那么即使最近时间big单子为0，历史的big单子会有影响，不至于让ema值是0
//统计大单的数量，以及连续进来的密度（平方统计来着），如果连续进的密度很大

// 选2个特征
type T_3 struct {
	FeatureBase
	hlList []float64 //1200-2400
	pLen   int

	emaBig       map[int][]*MXEMA
	emaBigSell   map[int][]*MXEMA
	emaBigBuy    map[int][]*MXEMA
	emaSmall     map[int][]*MXEMA
	emaSmallSell map[int][]*MXEMA
	emaSmallBuy  map[int][]*MXEMA

	//return
	ret []float64
}

func (seb *T_3) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.pLen = len(seb.hlList)
	return nil
}

//setFeatureNames: set column names.
func (seb *T_3) setFeatureNames() {
	seb.colNames = make([]string, 5*seb.pLen)
	for i := 0; i < seb.pLen; i++ {
		seb.colNames[i] = fmt.Sprintf("%s-env%ds", seb.featureName, int(seb.hlList[i]))
		seb.colNames[i+1*seb.pLen] = fmt.Sprintf("%s-se%ds", seb.featureName, int(seb.hlList[i]))
		seb.colNames[i+2*seb.pLen] = fmt.Sprintf("%s-be%ds", seb.featureName, int(seb.hlList[i]))
		seb.colNames[i+3*seb.pLen] = fmt.Sprintf("%s-bd%ds", seb.featureName, int(seb.hlList[i]))
		seb.colNames[i+4*seb.pLen] = fmt.Sprintf("%s-sbd%ds", seb.featureName, int(seb.hlList[i]))
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_3) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.emaBig = make(map[int][]*MXEMA)
	seb.emaBigSell = make(map[int][]*MXEMA)
	seb.emaBigBuy = make(map[int][]*MXEMA)
	seb.emaSmall = make(map[int][]*MXEMA)
	seb.emaSmallSell = make(map[int][]*MXEMA)
	seb.emaSmallBuy = make(map[int][]*MXEMA)

	for sid := range seb.sidUniverse {

		seb.emaBig[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBigSell[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBigBuy[sid] = make([]*MXEMA, seb.pLen)
		seb.emaSmall[sid] = make([]*MXEMA, seb.pLen)
		seb.emaSmallSell[sid] = make([]*MXEMA, seb.pLen)
		seb.emaSmallBuy[sid] = make([]*MXEMA, seb.pLen)

		for i := 0; i < seb.pLen; i++ {
			seb.emaBig[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.emaBigSell[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.emaBigBuy[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.emaSmall[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.emaSmallSell[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.emaSmallBuy[sid][i] = NewMXEMA(seb.hlList[i], 3)
		}
	}
}

//Update
func (seb *T_3) UpdateDoubleSecPrcQtySliceSnap(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	amt := 0.
	bigAmt := 0.
	bigSellAmt := 0.
	bigBuyAmt := 0.
	smallAmt := 0.
	smallSellAmt := 0.
	smallBuyAmt := 0.
	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			smallAmt -= amt
			smallBuyAmt -= amt
		} else {
			bigAmt += amt
			bigBuyAmt += amt
		}
	}
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			smallAmt -= amt
			smallSellAmt -= amt
		} else {
			bigAmt += amt
			bigSellAmt += amt
		}
	}

	for i := 0; i < seb.pLen; i++ {
		seb.emaBig[sid][i].Update(secSinceEpoch, bigAmt)
		seb.emaBigSell[sid][i].Update(secSinceEpoch, bigSellAmt)
		seb.emaBigBuy[sid][i].Update(secSinceEpoch, bigBuyAmt)
		seb.emaSmall[sid][i].Update(secSinceEpoch, smallAmt)
		seb.emaSmallSell[sid][i].Update(secSinceEpoch, smallSellAmt)
		seb.emaSmallBuy[sid][i].Update(secSinceEpoch, smallBuyAmt)
	}

	return true
}

//GetValues
func (seb *T_3) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	if _, ok := seb.sidUniverse[sid]; !ok {
		for i := 0; i < len(seb.ret); i++ {
			seb.ret[i] = 0
		}
		return seb.ret, nil
	} else {
		for i := 0; i < seb.pLen; i++ {
			bigAmt := seb.emaBig[sid][i].GetEms(secEpoch)
			smallAmt := seb.emaSmall[sid][i].GetEms(secEpoch)
			bigSellAmt := seb.emaBigSell[sid][i].GetEms(secEpoch)
			smallSellAmt := seb.emaSmallSell[sid][i].GetEms(secEpoch)
			bigBuyAmt := seb.emaBigBuy[sid][i].GetEms(secEpoch)
			smallBuyAmt := seb.emaSmallBuy[sid][i].GetEms(secEpoch)

			seb.ret[i] = DivIgNa(bigAmt-smallAmt, bigAmt+smallAmt)
			seb.ret[i+1*seb.pLen] = DivIgNa(bigSellAmt-smallSellAmt, bigSellAmt+smallSellAmt)
			seb.ret[i+2*seb.pLen] = DivIgNa(bigBuyAmt-smallBuyAmt, bigBuyAmt+smallBuyAmt)
			seb.ret[i+3*seb.pLen] = DivIgNa(bigSellAmt-bigBuyAmt, bigSellAmt+bigBuyAmt)
			seb.ret[i+4*seb.pLen] = DivIgNa(smallSellAmt-smallBuyAmt, smallSellAmt+smallBuyAmt)
		}
	}
	return seb.ret, nil
}
