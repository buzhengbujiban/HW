package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
)

//APBU
//两个our time的snapshot之间夹着trade数据，这个trade数据不是用source time去对齐的，暂时可以用our time近似，后续需要动态infer
//2个特征
type T_1 struct {
	FeatureBase
	hlList     []float64 //600-1200
	pLen       int
	pow        float64
	pricesSeen map[int][]float64
	emaData    map[int]map[float64][]*MXEMA

	BSRatios     map[int][]*floatRingBuf //BSLenList 1min-5min
	midPrices    map[int][]*floatRingBuf //priceLenList 1min-5min
	priceChange  map[int][]*floatRingBuf //priceLenList
	BSLenList    []int
	priceLenList []int
	emaAcc       map[int][]*MXEMA
	emaLag       map[int][]*MXEMA
	emaLagPP     map[int][]*MXEMA
	emaLagPN     map[int][]*MXEMA
	emaLagNP     map[int][]*MXEMA
	emaLagNN     map[int][]*MXEMA

	sellPress map[int][]*floatRingBuf //BSLenList
	buyPress  map[int][]*floatRingBuf //BSLenList
	tempBuf   []float64

	//return
	ret []float64
}

func (seb *T_1) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.pLen = len(seb.hlList)
	seb.pow = seb.prefs.GetFloat64Pref(seb.featureName + "_power")
	seb.BSLenList = seb.prefs.GetIntListPref(seb.featureName + "_BSLenList")
	seb.priceLenList = seb.prefs.GetIntListPref(seb.featureName + "_priceLenList")
	if len(seb.BSLenList) != seb.pLen || len(seb.priceLenList) != seb.pLen {
		panic("some parameter lists differ in their lengths")
	}
	return nil
}

//setFeatureNames: set column names.
func (seb *T_1) setFeatureNames() {
	seb.colNames = make([]string, 8*seb.pLen)
	for i := 0; i < seb.pLen; i++ {
		seb.colNames[i] = fmt.Sprintf("%s-acc%ds", seb.featureName, int(seb.hlList[i]))
		seb.colNames[i+seb.pLen] = fmt.Sprintf("%s-lag%ds", seb.featureName, int(seb.hlList[i]))
		seb.colNames[i+2*seb.pLen] = fmt.Sprintf("%s-lagPP%ds", seb.featureName, int(seb.hlList[i]))
		seb.colNames[i+3*seb.pLen] = fmt.Sprintf("%s-lagPN%ds", seb.featureName, int(seb.hlList[i]))
		seb.colNames[i+4*seb.pLen] = fmt.Sprintf("%s-lagNP%ds", seb.featureName, int(seb.hlList[i]))
		seb.colNames[i+5*seb.pLen] = fmt.Sprintf("%s-lagNN%ds", seb.featureName, int(seb.hlList[i]))
		seb.colNames[i+6*seb.pLen] = fmt.Sprintf("%s-buy%ds", seb.featureName, int(seb.hlList[i]))
		seb.colNames[i+7*seb.pLen] = fmt.Sprintf("%s-sell%ds", seb.featureName, int(seb.hlList[i]))
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_1) initInternalVars() {
	seb.FeatureBase.initInternalVars()
	seb.pricesSeen = map[int][]float64{} // slice map 的make和初始化都返回指针， struct make返回指针，初始化返回值
	seb.emaData = make(map[int]map[float64][]*MXEMA)
	seb.emaAcc = make(map[int][]*MXEMA)
	seb.emaLag = make(map[int][]*MXEMA)
	seb.emaLagPP = make(map[int][]*MXEMA)
	seb.emaLagPN = make(map[int][]*MXEMA)
	seb.emaLagNP = make(map[int][]*MXEMA)
	seb.emaLagNN = make(map[int][]*MXEMA)
	seb.BSRatios = make(map[int][]*floatRingBuf)
	seb.midPrices = make(map[int][]*floatRingBuf)
	seb.priceChange = make(map[int][]*floatRingBuf)
	seb.sellPress = make(map[int][]*floatRingBuf)
	seb.buyPress = make(map[int][]*floatRingBuf)
	for sid := range seb.sidUniverse {
		seb.pricesSeen[sid] = make([]float64, 0, 100) //In most case, cap 100 seen prices would be enough for whole day.
		seb.emaData[sid] = make(map[float64][]*MXEMA)
		seb.emaAcc[sid] = make([]*MXEMA, seb.pLen)
		seb.emaLag[sid] = make([]*MXEMA, seb.pLen)
		seb.emaLagPP[sid] = make([]*MXEMA, seb.pLen)
		seb.emaLagPN[sid] = make([]*MXEMA, seb.pLen)
		seb.emaLagNP[sid] = make([]*MXEMA, seb.pLen)
		seb.emaLagNN[sid] = make([]*MXEMA, seb.pLen)
		seb.BSRatios[sid] = make([]*floatRingBuf, seb.pLen)
		seb.midPrices[sid] = make([]*floatRingBuf, seb.pLen)
		seb.priceChange[sid] = make([]*floatRingBuf, seb.pLen)
		seb.sellPress[sid] = make([]*floatRingBuf, seb.pLen)
		seb.buyPress[sid] = make([]*floatRingBuf, seb.pLen)
		for i := 0; i < seb.pLen; i++ {
			seb.BSRatios[sid][i] = newFloatRingBuf(seb.BSLenList[i])
			seb.midPrices[sid][i] = newFloatRingBuf(seb.priceLenList[i])
			seb.priceChange[sid][i] = newFloatRingBuf(seb.priceLenList[i])
			seb.emaAcc[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.emaLag[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.emaLagPP[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.emaLagPN[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.emaLagNP[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.emaLagNN[sid][i] = NewMXEMA(seb.hlList[i], 3)
			seb.sellPress[sid][i] = newFloatRingBuf(seb.BSLenList[i])
			seb.buyPress[sid][i] = newFloatRingBuf(seb.BSLenList[i])
		}
	}
	seb.tempBuf = make([]float64, 10)
}

func (seb *T_1) initializeEMAs(sid int, price float64) {
	if _, ok := seb.emaData[sid][price]; !ok {
		seb.pricesSeen[sid] = append(seb.pricesSeen[sid], price)
		seb.emaData[sid][price] = make([]*MXEMA, seb.pLen)
		for i, hl := range seb.hlList {
			seb.emaData[sid][price][i] = NewMXEMA(hl, 3)
		}
	}
}

//Update
func (seb *T_1) UpdateSecPrcQtySliceSnap(sid int, secSinceEpoch float64, newObs []data.PriceQty, snapData []float64) bool { //spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	amt := 0.
	sellAmt := 0.
	buyAmt := 0.
	for _, psp := range newObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			sellAmt += math.Abs(amt)
		} else {
			buyAmt += amt
		}
	}
	ratio := 0.
	if math.Abs(sellAmt+buyAmt) > E_EPS {
		ratio = (buyAmt - sellAmt) / (sellAmt + buyAmt)
	}
	for i := 0; i < seb.pLen; i++ {
		seb.BSRatios[sid][i].push(ratio)
		seb.midPrices[sid][i].push(E_midPrc(snapData[0], snapData[20]))
	}
	midPriceEnd := 0.
	midPriceFront := 0.
	for i := 0; i < seb.pLen; i++ {
		midPriceEnd = seb.midPrices[sid][i].getEnd()
		midPriceFront = seb.midPrices[sid][i].getFront()
		priceChange := midPriceFront/midPriceEnd - 1.0
		if math.IsNaN(priceChange) || math.IsInf(priceChange, 0) {
			priceChange = 0.
		}
		seb.priceChange[sid][i].push(priceChange)
	}

	bsRatioFront := 0.
	bsRatioEnd := 0.
	priceChangeFront := 0.
	temp := 0.
	for i := 0; i < seb.pLen; i++ {
		bsRatioFront = seb.BSRatios[sid][i].getFront()
		bsRatioEnd = seb.BSRatios[sid][i].getEnd()
		priceChangeFront = seb.priceChange[sid][i].getFront()
		seb.emaAcc[sid][i].Update(secSinceEpoch, bsRatioFront*priceChangeFront)
		temp = bsRatioEnd * priceChangeFront
		seb.emaLag[sid][i].Update(secSinceEpoch, temp)
		if bsRatioEnd > 0 && priceChangeFront > 0 {
			seb.emaLagPP[sid][i].Update(secSinceEpoch, temp)
		} else if bsRatioEnd > 0 && priceChangeFront < 0 {
			seb.emaLagPN[sid][i].Update(secSinceEpoch, temp)
		} else if bsRatioEnd < 0 && priceChangeFront > 0 {
			seb.emaLagNP[sid][i].Update(secSinceEpoch, temp)
		} else if bsRatioEnd < 0 && priceChangeFront < 0 {
			seb.emaLagNN[sid][i].Update(secSinceEpoch, temp)
		} else {
		}
	}

	for i := 0; i < 10; i++ {
		seb.tempBuf[i] = snapData[2*i+1] //asksize
	}
	askSizeSum := SumVecIgNa(seb.tempBuf)
	askSizeMax, _ := MaxVecLocIgNa((seb.tempBuf[1:]))
	for i := 0; i < 10; i++ {
		seb.tempBuf[i] = snapData[2*i+1+20] //bidsize
	}
	bidSizeSum := SumVecIgNa(seb.tempBuf)
	bidSizeMax, _ := MaxVecLocIgNa((seb.tempBuf[1:]))

	sellP := powerTransform(askSizeMax, seb.pow) / powerTransform(bidSizeSum, seb.pow)
	buyP := powerTransform(bidSizeMax, seb.pow) / powerTransform(askSizeSum, seb.pow)
	sellP = math.Min(sellP, 5)
	buyP = math.Min(buyP, 5)
	for i := 0; i < seb.pLen; i++ {
		seb.sellPress[sid][i].push(sellP)
		seb.buyPress[sid][i].push(buyP)
	}

	return true
}

//GetValues
func (seb *T_1) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	if _, ok := seb.sidUniverse[sid]; !ok {
		for i := 0; i < len(seb.ret); i++ {
			seb.ret[i] = 0
		}
		return seb.ret, nil
	} else {
		for i := 0; i < seb.pLen; i++ {
			seb.ret[i] = seb.emaAcc[sid][i].GetEma()
			seb.ret[i+1*seb.pLen] = seb.emaLag[sid][i].GetEma()
			seb.ret[i+2*seb.pLen] = seb.emaLagPP[sid][i].GetEmaDecayed(secEpoch)
			seb.ret[i+3*seb.pLen] = seb.emaLagPN[sid][i].GetEmaDecayed(secEpoch)
			seb.ret[i+4*seb.pLen] = seb.emaLagNP[sid][i].GetEmaDecayed(secEpoch)
			seb.ret[i+5*seb.pLen] = seb.emaLagNN[sid][i].GetEmaDecayed(secEpoch)
			seb.ret[i+6*seb.pLen] = seb.sellPress[sid][i].mean() * seb.BSRatios[sid][i].mean()
			seb.ret[i+7*seb.pLen] = -seb.buyPress[sid][i].mean() * seb.BSRatios[sid][i].mean()
		}
	}
	return seb.ret, nil
}
