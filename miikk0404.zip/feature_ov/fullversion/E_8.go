package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"math"
	"sort"
)

//类似E_7.go
type E_8Item struct {
	ema           map[float64]*MXEMA
	emaSell       map[float64]*MXEMA
	emaBuy        map[float64]*MXEMA
	prices        []float64
	updateNum     int
	midPrice      float64
	priceNumLimit int
	nearSize      int
}

const E_8CPNAME = "E_8" //这种写法只支持feature只有一种参数配置

var E_8CPnames = []string{}

func (item *E_8Item) ToCP() []interface{} {
	return []interface{}{}
}

func (item *E_8Item) FromCP(v []interface{}) {
}

func (item *E_8Item) String() string {
	return fmt.Sprintf("%T", item)
}

func (item *E_8Item) OVRoll(ca, emaTime float64) bool {
	r := false
	return r
}

var _ OVIterm = (*E_8Item)(nil)

type E_8 struct {
	OVBase

	items              []*E_8Item
	hl                 float64
	power              float64
	priceNumLimitRatio float64
	nearSizeRatio      float64
	tag                string
	debug              bool
}

var (
	E_8TermnamesDebug = []string{"ratio", "spread", "tStats", "ret", "ratioLoc", "ratioLoc2", "Pres", "Resis", "Pres2", "Resis2"}
	E_8Termnames      = []string{"ratio", "spread", "tStats", "ret", "ratioLoc", "ratioLoc2", "Pres", "Resis", "Pres2", "Resis2"}
)

// prefs_name, feature_name, log_dir, datestr
func (t *E_8) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *E_8) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	t.UpdateCPInfo(t, E_8CPNAME, E_8CPnames)
	return nil
}

func (t *E_8) TermName() string {
	return "E_8"
}

func (t *E_8) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *E_8) names() []string {
	if t.debug {
		return E_8TermnamesDebug
	}
	return E_8Termnames
}

func (t *E_8) inputs() []int {
	return []int{INPUT_MSG_TOB, INPUT_MSG_TRADE}
}

func (t *E_8) loadFeaturePrefs() error {
	t.priceNumLimitRatio = t.prefs.GetFloat64Pref(t.featureName + ".priceNumLimitRatio")
	t.nearSizeRatio = t.prefs.GetFloat64Pref(t.featureName + ".nearSizeRatio")
	t.power = t.prefs.GetFloat64Pref(t.featureName + ".power")
	t.hl = t.prefs.GetFloat64Pref(t.featureName + ".hl")
	t.debug = t.prefs.GetBoolPref(t.featureName + ".debug")
	t.tag = t.prefs.GetStringPref(t.featureName + ".tag")
	return nil
}

func (t *E_8) loadDailyStats() {
}

//setFeatureNames: set column names.
func (t *E_8) setFeatureNames() {
	t.colNames = t.names()
	for i, n := range t.colNames {
		t.colNames[i] = fmt.Sprintf("%s.%s.%s", t.featureName, n, t.tag)
	}
}

//initialize internal variables
func (t *E_8) initInternalVars() {
	t.OVInit()
	t.items = make([]*E_8Item, t.nSids)
	for idx, _ := range t.items {
		item := new(E_8Item)
		item.ema = make(map[float64]*MXEMA)
		item.emaSell = make(map[float64]*MXEMA)
		item.emaBuy = make(map[float64]*MXEMA)
		item.prices = make([]float64, 0, 100) // 事先分配cap，加快速度
		t.items[idx] = item
	}
}

func (t *E_8) updateItem(item *E_8Item, secs float64, price float64, qty float64, tag string) {
	if _, ok := item.ema[price]; !ok {
		item.prices = append(item.prices, price)
		item.ema[price] = NewMXEMA(t.hl, 3)
		item.emaSell[price] = NewMXEMA(t.hl, 3)
		item.emaBuy[price] = NewMXEMA(t.hl, 3)
	}
	item.ema[price].Update(secs, powerTransform(qty, t.power))
	if tag == "sell" {
		item.emaSell[price].Update(secs, -powerTransform(qty, t.power)) // 负负得正
	} else if tag == "buy" {
		item.emaBuy[price].Update(secs, powerTransform(qty, t.power))
	} else {
	}
}

func (t *E_8) TermUpdateTOB(sid int, secs float64, it OVIterm, tob *MsgTOB) {
	item := it.(*E_8Item)
	item.updateNum += 1

	tickNums := tob.open * 0.02 / 0.01
	item.priceNumLimit = int(tickNums * t.priceNumLimitRatio)
	item.nearSize = int(tickNums * t.nearSizeRatio)
	if item.priceNumLimit < 50 {
		item.priceNumLimit = 50
	}
	if item.nearSize < 2 {
		item.nearSize = 2
	}

	AgTrade := tob.AgTrade

	if math.Abs(AgTrade[2]*AgTrade[5]+1) <= E_EPS { // -1 异号
		for i := 0; i < 2; i++ {
			notl := AgTrade[1+i*3]
			if math.IsNaN(notl) || math.IsInf(notl, 0) || notl <= E_EPS {
				continue
			}
			price := AgTrade[0+i*3]
			qty := AgTrade[1+i*3]
			if AgTrade[2+i*3] < 0 {
				if qty > E_EPS {
					t.updateItem(item, secs, price, -qty, "sell") //这里假设买卖价格不一样, 否则同一个价格同时Update，会有bug
				}
			} else {
				if qty > E_EPS {
					t.updateItem(item, secs, price, qty, "buy")
				}
			}
		}
	} else {
		price := AgTrade[0]
		qty := 0.
		if math.Abs(AgTrade[3]) > E_EPS {
			qty = AgTrade[1] + AgTrade[4]
		} else {
			qty = AgTrade[1]
		}
		if AgTrade[2] < 0 {
			if qty > E_EPS {
				t.updateItem(item, secs, price, -qty, "sell")
			}
		} else {
			if qty > E_EPS {
				t.updateItem(item, secs, price, qty, "buy")
			}
		}
	}

	//item.midPrice = tob.mid
	item.midPrice = tob.robust
}

func (t *E_8) TermUpdateTrade(sid int, secs float64, it OVIterm, trade *MsgTrade) {
	panic("E_8 not for TermUpdateTrade currently!")
}

func (t *E_8) TermUpdateAny(sid int, secs float64, it OVIterm) {
	// common logic for TermUpdateTOB & TermUpdateTrade
}

func (t *E_8) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*E_8Item)

	if len(item.prices) == 0 { // TOB接受到第一个股票时候，便会开始snap所有的sid
		return
	}

	sort.Float64s(item.prices) //用于后面sort.SearchFloat64s, SearchNearLoc
	qtys := make([]float64, len(item.prices))
	qtysSell := make([]float64, len(item.prices))
	qtysBuy := make([]float64, len(item.prices))
	for i, price := range item.prices {
		qtys[i] = item.ema[price].GetEma()
		qtysSell[i] = item.emaSell[price].GetEma()
		qtysBuy[i] = item.emaBuy[price].GetEma()
	}

	locMid := SearchNearLocSimilarAsOldDeleted(item.prices, item.midPrice) // 如果找不到就返回最相邻的位置
	locLeft := int(math.Max(0., float64(locMid-item.priceNumLimit)))
	locRight := int(math.Min(float64(locMid+item.priceNumLimit), float64(len(item.prices))-1.))

	if len(qtys[locLeft:locRight+1]) <= 0 {
		return
	}

	res[0] = BuySellRatioIgNa(qtys[locLeft : locRight+1])
	res[1] = BuySellSpreadIgNa(item.prices[locLeft:locRight+1], qtys[locLeft:locRight+1], item.midPrice)
	//qtysAbs := MU.ArrAbs(qtys) // 这是inplace
	qtysAbs := E_ArrAbs(qtys)
	res[2] = CalcTstatIgNa(item.prices[locLeft:locRight+1], qtysAbs[locLeft:locRight+1], item.midPrice)
	res[3] = CalcDevIgNa(item.prices[locLeft:locRight+1], qtysAbs[locLeft:locRight+1], item.midPrice)

	//和当前价格最近的几个
	tickPrice := 0.01
	locs := make([]int, 0, 2*item.nearSize+1)
	for i := 1; i <= item.nearSize; i++ {
		if locMid-i >= 0 && locMid < len(item.prices) && item.prices[locMid]-item.prices[locMid-i] <= float64(item.nearSize)*tickPrice+E_EPS {
			locs = append(locs, locMid-i)
		}
		if locMid+i < len(item.prices) && locMid >= 0 && item.prices[locMid+i]-item.prices[locMid] <= float64(item.nearSize)*tickPrice+E_EPS {
			locs = append(locs, locMid+i)
		}
	}
	if locMid >= 0 && locMid < len(item.prices) {
		locs = append(locs, locMid)
	}
	locs = RemoveDuplicateInt(locs)

	if len(locs) <= 0 {
		return
	}
	//
	res[4] = BuySellRatioLocsIgNa(qtys, locs)
	res[5] = BuySellRatioLocs2IgNaSimilarAsOldDeleted(qtysSell, qtysBuy, locs)

	res[6], res[7] = GetPresResisSimilarAsOldDeleted(VecAddVec(qtysSell, qtysBuy), item.prices, item.midPrice, item.nearSize)
	res[8], res[9] = GetPresResisSimilarAsOldDeleted(qtys, item.prices, item.midPrice, item.nearSize)
}

var _ OVInterface = (*E_8)(nil)

func init() {
	TermFactoryInstance().Register("E-8", func() ITerm { return &E_8{} })
}
