package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
)

const T5_NUM_FOR_OUTPUT = 16

// 后面改成streaming 找最大最小，并且还要返回对应loc

// 选2个特征
type T_5 struct {
	FeatureBase
	pLen   int
	hlList []float64

	sizeList []int //20-100

	priceList        map[int][][]float64
	amtList          map[int][][]float64
	amtBigList       map[int][][]float64
	amtSmallList     map[int][][]float64
	amtSellList      map[int][][]float64
	amtSellBigList   map[int][][]float64
	amtSellSmallList map[int][][]float64
	amtBuyList       map[int][][]float64
	amtBuyBigList    map[int][][]float64
	amtBuySmallList  map[int][][]float64
	epochList        map[int][][]float64

	amtUp          map[int][]*MXEMA
	amtBigUp       map[int][]*MXEMA
	amtSmallUp     map[int][]*MXEMA
	amtSellUp      map[int][]*MXEMA
	amtSellBigUp   map[int][]*MXEMA
	amtSellSmallUp map[int][]*MXEMA
	amtBuyUp       map[int][]*MXEMA
	amtBuyBigUp    map[int][]*MXEMA
	amtBuySmallUp  map[int][]*MXEMA
	epochUp        map[int][]*MXEMA

	amtDown          map[int][]*MXEMA
	amtBigDown       map[int][]*MXEMA
	amtSmallDown     map[int][]*MXEMA
	amtSellDown      map[int][]*MXEMA
	amtSellBigDown   map[int][]*MXEMA
	amtSellSmallDown map[int][]*MXEMA
	amtBuyDown       map[int][]*MXEMA
	amtBuyBigDown    map[int][]*MXEMA
	amtBuySmallDown  map[int][]*MXEMA
	epochDown        map[int][]*MXEMA

	numGot map[int]int

	//return
	ret []float64
}

func (seb *T_5) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.sizeList = seb.prefs.GetIntListPref(seb.featureName + "_sizeList")
	seb.pLen = len(seb.sizeList)
	if len(seb.hlList) != seb.pLen {
		panic("some parameter lists differ in their lengths")
	}
	return nil
}

//setFeatureNames: set column names.
func (seb *T_5) setFeatureNames() {
	seb.colNames = make([]string, 10*seb.pLen)
	for i := 0; i < seb.pLen; i++ {
		seb.colNames[i] = fmt.Sprintf("%s-a%ds", seb.featureName, int(seb.sizeList[i]))
		seb.colNames[i+1*seb.pLen] = fmt.Sprintf("%s-abig%ds", seb.featureName, int(seb.sizeList[i]))
		seb.colNames[i+2*seb.pLen] = fmt.Sprintf("%s-asmall%ds", seb.featureName, int(seb.sizeList[i]))
		seb.colNames[i+3*seb.pLen] = fmt.Sprintf("%s-as%ds", seb.featureName, int(seb.sizeList[i]))
		seb.colNames[i+4*seb.pLen] = fmt.Sprintf("%s-asb%ds", seb.featureName, int(seb.sizeList[i]))
		seb.colNames[i+5*seb.pLen] = fmt.Sprintf("%s-ass%ds", seb.featureName, int(seb.sizeList[i]))
		seb.colNames[i+6*seb.pLen] = fmt.Sprintf("%s-ab%ds", seb.featureName, int(seb.sizeList[i]))
		seb.colNames[i+7*seb.pLen] = fmt.Sprintf("%s-abb%ds", seb.featureName, int(seb.sizeList[i]))
		seb.colNames[i+8*seb.pLen] = fmt.Sprintf("%s-abs%ds", seb.featureName, int(seb.sizeList[i]))
		seb.colNames[i+9*seb.pLen] = fmt.Sprintf("%s-t%ds", seb.featureName, int(seb.sizeList[i]))
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_5) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.priceList = make(map[int][][]float64)
	seb.amtList = make(map[int][][]float64)
	seb.amtBigList = make(map[int][][]float64)
	seb.amtSmallList = make(map[int][][]float64)
	seb.amtSellList = make(map[int][][]float64)
	seb.amtSellBigList = make(map[int][][]float64)
	seb.amtSellSmallList = make(map[int][][]float64)
	seb.amtBuyList = make(map[int][][]float64)
	seb.amtBuyBigList = make(map[int][][]float64)
	seb.amtBuySmallList = make(map[int][][]float64)
	seb.epochList = make(map[int][][]float64)

	seb.amtUp = make(map[int][]*MXEMA)
	seb.amtBigUp = make(map[int][]*MXEMA)
	seb.amtSmallUp = make(map[int][]*MXEMA)
	seb.amtSellUp = make(map[int][]*MXEMA)
	seb.amtSellBigUp = make(map[int][]*MXEMA)
	seb.amtSellSmallUp = make(map[int][]*MXEMA)
	seb.amtBuyUp = make(map[int][]*MXEMA)
	seb.amtBuyBigUp = make(map[int][]*MXEMA)
	seb.amtBuySmallUp = make(map[int][]*MXEMA)
	seb.epochUp = make(map[int][]*MXEMA)

	seb.amtDown = make(map[int][]*MXEMA)
	seb.amtBigDown = make(map[int][]*MXEMA)
	seb.amtSmallDown = make(map[int][]*MXEMA)
	seb.amtSellDown = make(map[int][]*MXEMA)
	seb.amtSellBigDown = make(map[int][]*MXEMA)
	seb.amtSellSmallDown = make(map[int][]*MXEMA)
	seb.amtBuyDown = make(map[int][]*MXEMA)
	seb.amtBuyBigDown = make(map[int][]*MXEMA)
	seb.amtBuySmallDown = make(map[int][]*MXEMA)
	seb.epochDown = make(map[int][]*MXEMA)
	seb.numGot = make(map[int]int)

	for sid := range seb.sidUniverse {
		seb.priceList[sid] = make([][]float64, seb.pLen)
		seb.amtList[sid] = make([][]float64, seb.pLen)
		seb.amtBigList[sid] = make([][]float64, seb.pLen)
		seb.amtSmallList[sid] = make([][]float64, seb.pLen)
		seb.amtSellList[sid] = make([][]float64, seb.pLen)
		seb.amtSellBigList[sid] = make([][]float64, seb.pLen)
		seb.amtSellSmallList[sid] = make([][]float64, seb.pLen)
		seb.amtBuyList[sid] = make([][]float64, seb.pLen)
		seb.amtBuyBigList[sid] = make([][]float64, seb.pLen)
		seb.amtBuySmallList[sid] = make([][]float64, seb.pLen)
		seb.epochList[sid] = make([][]float64, seb.pLen)

		seb.amtUp[sid] = make([]*MXEMA, seb.pLen)
		seb.amtBigUp[sid] = make([]*MXEMA, seb.pLen)
		seb.amtSmallUp[sid] = make([]*MXEMA, seb.pLen)
		seb.amtSellUp[sid] = make([]*MXEMA, seb.pLen)
		seb.amtSellBigUp[sid] = make([]*MXEMA, seb.pLen)
		seb.amtSellSmallUp[sid] = make([]*MXEMA, seb.pLen)
		seb.amtBuyUp[sid] = make([]*MXEMA, seb.pLen)
		seb.amtBuyBigUp[sid] = make([]*MXEMA, seb.pLen)
		seb.amtBuySmallUp[sid] = make([]*MXEMA, seb.pLen)
		seb.epochUp[sid] = make([]*MXEMA, seb.pLen)

		seb.amtDown[sid] = make([]*MXEMA, seb.pLen)
		seb.amtBigDown[sid] = make([]*MXEMA, seb.pLen)
		seb.amtSmallDown[sid] = make([]*MXEMA, seb.pLen)
		seb.amtSellDown[sid] = make([]*MXEMA, seb.pLen)
		seb.amtSellBigDown[sid] = make([]*MXEMA, seb.pLen)
		seb.amtSellSmallDown[sid] = make([]*MXEMA, seb.pLen)
		seb.amtBuyDown[sid] = make([]*MXEMA, seb.pLen)
		seb.amtBuyBigDown[sid] = make([]*MXEMA, seb.pLen)
		seb.amtBuySmallDown[sid] = make([]*MXEMA, seb.pLen)
		seb.epochDown[sid] = make([]*MXEMA, seb.pLen)

		seb.numGot[sid] = 0
		for i, hl := range seb.hlList {
			seb.priceList[sid][i] = make([]float64, 0, seb.sizeList[i])
			seb.amtList[sid][i] = make([]float64, 0, seb.sizeList[i])
			seb.amtBigList[sid][i] = make([]float64, 0, seb.sizeList[i])
			seb.amtSmallList[sid][i] = make([]float64, 0, seb.sizeList[i])
			seb.amtSellList[sid][i] = make([]float64, 0, seb.sizeList[i])
			seb.amtSellBigList[sid][i] = make([]float64, 0, seb.sizeList[i])
			seb.amtSellSmallList[sid][i] = make([]float64, 0, seb.sizeList[i])
			seb.amtBuyList[sid][i] = make([]float64, 0, seb.sizeList[i])
			seb.amtBuyBigList[sid][i] = make([]float64, 0, seb.sizeList[i])
			seb.amtBuySmallList[sid][i] = make([]float64, 0, seb.sizeList[i])
			seb.epochList[sid][i] = make([]float64, 0, seb.sizeList[i])

			seb.amtUp[sid][i] = NewMXEMA(hl, 3)
			seb.amtBigUp[sid][i] = NewMXEMA(hl, 3)
			seb.amtSmallUp[sid][i] = NewMXEMA(hl, 3)
			seb.amtSellUp[sid][i] = NewMXEMA(hl, 3)
			seb.amtSellBigUp[sid][i] = NewMXEMA(hl, 3)
			seb.amtSellSmallUp[sid][i] = NewMXEMA(hl, 3)
			seb.amtBuyUp[sid][i] = NewMXEMA(hl, 3)
			seb.amtBuyBigUp[sid][i] = NewMXEMA(hl, 3)
			seb.amtBuySmallUp[sid][i] = NewMXEMA(hl, 3)
			seb.epochUp[sid][i] = NewMXEMA(hl, 3)

			seb.amtDown[sid][i] = NewMXEMA(hl, 3)
			seb.amtBigDown[sid][i] = NewMXEMA(hl, 3)
			seb.amtSmallDown[sid][i] = NewMXEMA(hl, 3)
			seb.amtSellDown[sid][i] = NewMXEMA(hl, 3)
			seb.amtSellBigDown[sid][i] = NewMXEMA(hl, 3)
			seb.amtSellSmallDown[sid][i] = NewMXEMA(hl, 3)
			seb.amtBuyDown[sid][i] = NewMXEMA(hl, 3)
			seb.amtBuyBigDown[sid][i] = NewMXEMA(hl, 3)
			seb.amtBuySmallDown[sid][i] = NewMXEMA(hl, 3)
			seb.epochDown[sid][i] = NewMXEMA(hl, 3)
		}
	}
}

//Update
func (seb *T_5) UpdateDoubleSecPrcQtySliceSnap(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64) bool { // tmpPrcQtySlice5 bigActiveBuy - smallActiveBuy, tmpPrcQtySlice6 bigActiveSell - smallActiveSell
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	amt := 0.
	amtTotal := 0.
	amtBig := 0.
	amtSmall := 0.
	amtSell := 0.
	amtSellBig := 0.
	amtSellSmall := 0.
	amtBuy := 0.
	amtBuyBig := 0.
	amtBuySmall := 0.

	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		amtTotal += math.Abs(amt)
		amtBuy += math.Abs(amt)
		if amt < 0 {
			amtSmall -= amt
			amtBuySmall -= amt
		} else {
			amtBig += amt
			amtBuyBig += amt
		}
	}
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		amtTotal += math.Abs(amt)
		amtSell += math.Abs(amt)
		if amt < 0 {
			amtSmall -= amt
			amtSellSmall -= amt
		} else {
			amtBig += amt
			amtSellBig += amt
		}
	}

	midPrice := E_midPrc(snapData[0], snapData[20])

	for i := 0; i < seb.pLen; i++ {
		seb.priceList[sid][i] = SlicePush(seb.priceList[sid][i], midPrice)
		seb.amtList[sid][i] = SlicePush(seb.amtList[sid][i], amtTotal)
		seb.amtBigList[sid][i] = SlicePush(seb.amtBigList[sid][i], amtBig)
		seb.amtSmallList[sid][i] = SlicePush(seb.amtSmallList[sid][i], amtSmall)
		seb.amtSellList[sid][i] = SlicePush(seb.amtSellList[sid][i], amtSell)
		seb.amtSellBigList[sid][i] = SlicePush(seb.amtSellBigList[sid][i], amtSellBig)
		seb.amtSellSmallList[sid][i] = SlicePush(seb.amtSellSmallList[sid][i], amtSellSmall)
		seb.amtBuyList[sid][i] = SlicePush(seb.amtBuyList[sid][i], amtBuy)
		seb.amtBuyBigList[sid][i] = SlicePush(seb.amtBuyBigList[sid][i], amtBuyBig)
		seb.amtBuySmallList[sid][i] = SlicePush(seb.amtBuySmallList[sid][i], amtBuySmall)
		seb.epochList[sid][i] = SlicePush(seb.epochList[sid][i], secSinceEpoch)
	}

	seb.numGot[sid] += 1

	if seb.numGot[sid] < T5_NUM_FOR_OUTPUT {
		return true
	}

	for i := 0; i < seb.pLen; i++ {
		priceMax, locMax := MaxVecLocIgNa(seb.priceList[sid][i])
		priceMin, locMin := MinVecLocIgNa(seb.priceList[sid][i])
		priceGap := priceMax - priceMin
		if locMax == -1 || locMin == -1 || locMax == locMin || math.Abs(priceGap) <= E_EPS || priceGap <= E_EPS {
			return true
		} else if locMax > locMin { //up
			seb.amtUp[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtList[sid][i][locMin+1:locMax+1])/priceGap)
			seb.amtBigUp[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtBigList[sid][i][locMin+1:locMax+1])/priceGap)
			seb.amtSmallUp[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtSmallList[sid][i][locMin+1:locMax+1])/priceGap)
			seb.amtSellUp[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtSellList[sid][i][locMin+1:locMax+1])/priceGap)
			seb.amtSellBigUp[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtSellBigList[sid][i][locMin+1:locMax+1])/priceGap)
			seb.amtSellSmallUp[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtSellSmallList[sid][i][locMin+1:locMax+1])/priceGap)
			seb.amtBuyUp[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtBuyList[sid][i][locMin+1:locMax+1])/priceGap)
			seb.amtBuyBigUp[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtBuyBigList[sid][i][locMin+1:locMax+1])/priceGap)
			seb.amtBuySmallUp[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtBuySmallList[sid][i][locMin+1:locMax+1])/priceGap)
			if seb.epochList[sid][i][locMax]-seb.epochList[sid][i][locMin] > 0 {
				seb.epochUp[sid][i].Update(secSinceEpoch, (seb.epochList[sid][i][locMax]-seb.epochList[sid][i][locMin])/priceGap)
			}
		} else if locMax < locMin {
			seb.amtDown[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtList[sid][i][locMax+1:locMin+1])/priceGap)
			seb.amtBigDown[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtBigList[sid][i][locMax+1:locMin+1])/priceGap)
			seb.amtSmallDown[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtSmallList[sid][i][locMax+1:locMin+1])/priceGap)
			seb.amtSellDown[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtSellList[sid][i][locMax+1:locMin+1])/priceGap)
			seb.amtSellBigDown[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtSellBigList[sid][i][locMax+1:locMin+1])/priceGap)
			seb.amtSellSmallDown[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtSellSmallList[sid][i][locMax+1:locMin+1])/priceGap)
			seb.amtBuyDown[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtBuyList[sid][i][locMax+1:locMin+1])/priceGap)
			seb.amtBuyBigDown[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtBuyBigList[sid][i][locMax+1:locMin+1])/priceGap)
			seb.amtBuySmallDown[sid][i].Update(secSinceEpoch, SumVecIgNa(seb.amtBuySmallList[sid][i][locMax+1:locMin+1])/priceGap)
			if seb.epochList[sid][i][locMin]-seb.epochList[sid][i][locMax] > 0 {
				seb.epochDown[sid][i].Update(secSinceEpoch, (seb.epochList[sid][i][locMin]-seb.epochList[sid][i][locMax])/priceGap)
			}
		} else {
		}
	}

	return true
}

//GetValues
func (seb *T_5) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	}

	if seb.numGot[sid] < T5_NUM_FOR_OUTPUT {
		return seb.ret, nil
	} else {
		for i := 0; i < seb.pLen; i++ {
			seb.ret[i] = DivIgNa(seb.amtUp[sid][i].GetEma()-seb.amtDown[sid][i].GetEma(), seb.amtUp[sid][i].GetEma()+seb.amtDown[sid][i].GetEma())
			seb.ret[i+1*seb.pLen] = DivIgNa(seb.amtBigUp[sid][i].GetEma()-seb.amtBigDown[sid][i].GetEma(), seb.amtBigUp[sid][i].GetEma()+seb.amtBigDown[sid][i].GetEma())
			seb.ret[i+2*seb.pLen] = DivIgNa(seb.amtSmallUp[sid][i].GetEma()-seb.amtSmallDown[sid][i].GetEma(), seb.amtSmallUp[sid][i].GetEma()+seb.amtSmallDown[sid][i].GetEma())
			seb.ret[i+3*seb.pLen] = DivIgNa(seb.amtSellUp[sid][i].GetEma()-seb.amtSellDown[sid][i].GetEma(), seb.amtSellUp[sid][i].GetEma()+seb.amtSellDown[sid][i].GetEma())
			seb.ret[i+4*seb.pLen] = DivIgNa(seb.amtSellBigUp[sid][i].GetEma()-seb.amtSellBigDown[sid][i].GetEma(), seb.amtSellBigUp[sid][i].GetEma()+seb.amtSellBigDown[sid][i].GetEma())
			seb.ret[i+5*seb.pLen] = DivIgNa(seb.amtSellSmallUp[sid][i].GetEma()-seb.amtSellSmallDown[sid][i].GetEma(), seb.amtSellSmallUp[sid][i].GetEma()+seb.amtSellSmallDown[sid][i].GetEma())
			seb.ret[i+6*seb.pLen] = DivIgNa(seb.amtBuyUp[sid][i].GetEma()-seb.amtBuyDown[sid][i].GetEma(), seb.amtBuyUp[sid][i].GetEma()+seb.amtBuyDown[sid][i].GetEma())
			seb.ret[i+7*seb.pLen] = DivIgNa(seb.amtBuyBigUp[sid][i].GetEma()-seb.amtBuyBigDown[sid][i].GetEma(), seb.amtBuyBigUp[sid][i].GetEma()+seb.amtBuyBigDown[sid][i].GetEma())
			seb.ret[i+8*seb.pLen] = DivIgNa(seb.amtBuySmallUp[sid][i].GetEma()-seb.amtBuySmallDown[sid][i].GetEma(), seb.amtBuySmallUp[sid][i].GetEma()+seb.amtBuySmallDown[sid][i].GetEma())
			seb.ret[i+9*seb.pLen] = DivIgNa(seb.epochUp[sid][i].GetEma()-seb.epochDown[sid][i].GetEma(), seb.epochUp[sid][i].GetEma()+seb.epochDown[sid][i].GetEma())
		}
	}
	return seb.ret, nil
}
