package feature

import (
	"TES/QR/alpha_ov/data"
	MU "TES/QR/alpha_ov/mathUtils"
	"fmt"
	"math"
)

type T_17 struct {
	FeatureBase
	pLen   int
	hlList []float64

	doCross  bool
	crossers []*MU.WeightedNestedGroupMeanFast

	start map[int]bool

	snapAskK map[int][]map[float64]float64
	snapBidK map[int][]map[float64]float64

	sellMin map[int]float64
	buyMax  map[int]float64

	amtSell map[int]float64
	amtBuy  map[int]float64
	qtySell map[int]float64
	qtyBuy  map[int]float64

	midPriceMap map[int]float64

	askAmtCancel map[int]float64
	bidAmtCancel map[int]float64
	askQtyCancel map[int]float64
	bidQtyCancel map[int]float64
	askAmtAdd    map[int]float64
	bidAmtAdd    map[int]float64
	askQtyAdd    map[int]float64
	bidQtyAdd    map[int]float64

	ratiosFirst []map[int][]*MXEMA

	tempVals  []float64
	tempVals2 []float64

	//return
	ret []float64
}

func (seb *T_17) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.pLen = len(seb.hlList)
	seb.doCross = seb.prefs.GetBoolPref(seb.featureName + "_do_cross")

	return nil
}

//setFeatureNames: set column names.
func (seb *T_17) setFeatureNames() {
	seb.colNames = make([]string, (24*seb.pLen+4)*4)
	for i := 0; i < 24; i++ {
		for j := 0; j < seb.pLen; j++ {
			seb.colNames[j+i*seb.pLen] = fmt.Sprintf("%s-%draw-%ds", seb.featureName, i, int(seb.hlList[j]))
		}
	}
	bias := 24
	for i := 0; i < 4; i++ {
		seb.colNames[bias+i] = fmt.Sprintf("%s-%draw", seb.featureName, bias+i)
	}
	bias = 28
	for i := 0; i < 28; i++ {
		seb.colNames[bias] = fmt.Sprintf("%s-%dm", seb.featureName, i)
		seb.colNames[bias+1] = fmt.Sprintf("%s-%dim", seb.featureName, i)
		seb.colNames[bias+2] = fmt.Sprintf("%s-%dir", seb.featureName, i)
		bias += 3
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_17) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.crossers = make([]*MU.WeightedNestedGroupMeanFast, 28)
	for i := 0; i < 28; i++ {
		seb.crossers[i] = MU.NewWeightedNestedGroupMeanFast(seb.sidUniverseList, 1, seb.baseSidWgts, seb.industryCode, seb.conceptCodes)
	}

	seb.start = make(map[int]bool)

	seb.snapAskK = make(map[int][]map[float64]float64)
	seb.snapBidK = make(map[int][]map[float64]float64)

	seb.sellMin = make(map[int]float64)
	seb.buyMax = make(map[int]float64)

	seb.midPriceMap = make(map[int]float64)

	seb.askAmtCancel = make(map[int]float64)
	seb.bidAmtCancel = make(map[int]float64)
	seb.askQtyCancel = make(map[int]float64)
	seb.bidQtyCancel = make(map[int]float64)
	seb.askAmtAdd = make(map[int]float64)
	seb.bidAmtAdd = make(map[int]float64)
	seb.askQtyAdd = make(map[int]float64)
	seb.bidQtyAdd = make(map[int]float64)

	seb.amtSell = make(map[int]float64)
	seb.amtBuy = make(map[int]float64)
	seb.qtySell = make(map[int]float64)
	seb.qtyBuy = make(map[int]float64)

	seb.ratiosFirst = make([]map[int][]*MXEMA, 24)

	for i := 0; i < 24; i++ {
		seb.ratiosFirst[i] = make(map[int][]*MXEMA)
	}

	seb.tempVals = make([]float64, 1)
	seb.tempVals2 = make([]float64, 5)

	for sid := range seb.sidUniverse {
		seb.start[sid] = false
		seb.sellMin[sid] = math.MaxFloat64
		seb.snapAskK[sid] = make([]map[float64]float64, 0, 32)
		seb.snapBidK[sid] = make([]map[float64]float64, 0, 32)
		for i := 0; i < 24; i++ {
			seb.ratiosFirst[i][sid] = make([]*MXEMA, seb.pLen)
		}
		for i := 0; i < 24; i++ {
			for j := 0; j < seb.pLen; j++ {
				seb.ratiosFirst[i][sid][j] = NewMXEMA(seb.hlList[j], 3)
			}
		}
	}
}

//Update
func (seb *T_17) UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int, extraInfo map[int][]float64) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}

	amt := 0.
	for _, psp := range buyObs {
		seb.buyMax[sid] = math.Max(seb.buyMax[sid], psp.Price)
		amt = psp.Qty * psp.Price
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		seb.amtBuy[sid] += math.Abs(amt)
		seb.qtyBuy[sid] += math.Abs(psp.Qty)
	}
	for _, psp := range sellObs {
		seb.sellMin[sid] = math.Min(seb.sellMin[sid], psp.Price)
		amt = psp.Qty * psp.Price
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		seb.amtSell[sid] += math.Abs(amt)
		seb.qtySell[sid] += math.Abs(psp.Qty)
	}

	askK := make(map[float64]float64)
	bidK := make(map[float64]float64)
	for i := 0; i < 10; i++ {
		askK[snapData[2*i]] = snapData[2*i+1]
		bidK[snapData[2*i+20]] = snapData[2*i+21]
	}

	seb.snapAskK[sid] = append(seb.snapAskK[sid], askK)
	seb.snapBidK[sid] = append(seb.snapBidK[sid], bidK)

	seb.start[sid] = true

	seb.midPriceMap[sid] = E_midPrc(snapData[0], snapData[20])

	return true
}

//GetValues
func (seb *T_17) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else {
		askAmtCancel := 0.
		bidAmtCancel := 0.
		askQtyCancel := 0.
		bidQtyCancel := 0.
		askAmtAdd := 0.
		bidAmtAdd := 0.
		askQtyAdd := 0.
		bidQtyAdd := 0.

		qtyLast := 0.

		askQtyLast := 0.
		bidQtyLast := 0.
		for j, snapK := range seb.snapAskK[sid] {
			for price, qty := range snapK {
				if price > seb.buyMax[sid] {
					if j > 0 {
						if _, ok := seb.snapAskK[sid][j-1][price]; ok {
							qtyLast = seb.snapAskK[sid][j-1][price]
							if qtyLast < qty {
								askAmtAdd += (qty - qtyLast) * price
								askQtyAdd += qty - qtyLast
							} else {
								askAmtCancel += (qtyLast - qty) * price
								askQtyCancel += qtyLast - qty
							}
							askQtyLast += qtyLast
						}
					}
				}
			}
		}
		for j, snapK := range seb.snapBidK[sid] {
			for price, qty := range snapK {
				if price < seb.sellMin[sid] {
					if j > 0 {
						if _, ok := seb.snapBidK[sid][j-1][price]; ok {
							qtyLast = seb.snapBidK[sid][j-1][price]
							if qtyLast < qty {
								bidAmtAdd += (qty - qtyLast) * price
								bidQtyAdd += qty - qtyLast
							} else {
								bidAmtCancel += (qtyLast - qty) * price
								bidQtyCancel += qtyLast - qty
							}
							bidQtyLast += qtyLast
						}
					}
				}
			}
		}
		/*
			if sid == 1 {
				fmt.Println(seb.buyMax[sid], seb.sellMin[sid])
				fmt.Println(seb.snapAskK[sid])
				fmt.Println(seb.snapBidK[sid])
			}
		*/

		seb.ret[0] = DivIgNa(askAmtCancel, askQtyCancel)/seb.midPriceMap[sid] - 1.
		seb.ret[1] = DivIgNa(askAmtAdd, askQtyAdd)/seb.midPriceMap[sid] - 1.
		seb.ret[2] = DivIgNa(bidAmtCancel, bidQtyCancel)/seb.midPriceMap[sid] - 1.
		seb.ret[3] = DivIgNa(bidAmtAdd, bidQtyAdd)/seb.midPriceMap[sid] - 1.
		seb.ret[4] = seb.ret[0] - seb.ret[1]
		seb.ret[5] = seb.ret[2] - seb.ret[3]
		seb.ret[6] = seb.ret[0] - seb.ret[2]
		seb.ret[7] = seb.ret[1] - seb.ret[3]
		seb.ret[8] = seb.ret[0] + seb.ret[2]
		seb.ret[9] = seb.ret[1] + seb.ret[3]

		seb.ret[10] = DivIgNa(askAmtCancel, askQtyCancel)/DivIgNa(seb.amtBuy[sid], seb.qtyBuy[sid]) - 1.
		seb.ret[11] = DivIgNa(askAmtAdd, askQtyAdd)/DivIgNa(seb.amtBuy[sid], seb.qtyBuy[sid]) - 1.
		seb.ret[12] = DivIgNa(bidAmtCancel, bidQtyCancel)/DivIgNa(seb.amtSell[sid], seb.qtySell[sid]) - 1.
		seb.ret[13] = DivIgNa(bidAmtAdd, bidQtyAdd)/DivIgNa(seb.amtSell[sid], seb.qtySell[sid]) - 1.
		seb.ret[14] = seb.ret[10] - seb.ret[11]
		seb.ret[15] = seb.ret[12] - seb.ret[13]
		seb.ret[16] = seb.ret[10] - seb.ret[12]
		seb.ret[17] = seb.ret[11] - seb.ret[13]
		seb.ret[18] = seb.ret[10] + seb.ret[12]
		seb.ret[19] = seb.ret[11] + seb.ret[13]

		seb.ret[20] = ClipIgNa(DivIgNa(askQtyAdd, askQtyLast), 5.)
		seb.ret[21] = ClipIgNa(DivIgNa(askQtyCancel, askQtyLast), 5.)
		seb.ret[22] = ClipIgNa(DivIgNa(bidQtyAdd, bidQtyLast), 5.)
		seb.ret[23] = ClipIgNa(DivIgNa(bidQtyCancel, bidQtyLast), 5.)

		/*
			if DivIgNa(bidQtyAdd, bidQtyLast) > 5 {
				fmt.Println(sid, bidQtyAdd, bidQtyLast, askQtyAdd, askQtyLast)
			}
		*/

		for i := 0; i < 24; i++ {
			for j := 0; j < seb.pLen; j++ {
				seb.ratiosFirst[i][sid][j].Update(secEpoch, seb.ret[i])
			}
		}
		for i := 0; i < 24; i++ {
			for j := 0; j < seb.pLen; j++ {
				seb.ret[j+i*seb.pLen] = seb.ratiosFirst[i][sid][j].GetEma()
			}
		}
		bias := seb.pLen * 24

		seb.askAmtCancel[sid] += askAmtCancel
		seb.bidAmtCancel[sid] += bidAmtCancel
		seb.askQtyCancel[sid] += askQtyCancel
		seb.bidQtyCancel[sid] += bidQtyCancel
		seb.askAmtAdd[sid] += askAmtAdd
		seb.bidAmtAdd[sid] += bidAmtAdd
		seb.askQtyAdd[sid] += askQtyAdd
		seb.bidQtyAdd[sid] += bidQtyAdd

		seb.ret[bias] = DivIgNa(seb.askQtyAdd[sid]-seb.askQtyCancel[sid], seb.askQtyAdd[sid]+seb.askQtyCancel[sid])
		seb.ret[bias+1] = DivIgNa(seb.bidQtyAdd[sid]-seb.bidQtyCancel[sid], seb.bidQtyAdd[sid]+seb.bidQtyCancel[sid])
		seb.ret[bias+2] = DivIgNa(seb.askQtyAdd[sid]-seb.bidQtyAdd[sid], seb.askQtyAdd[sid]+seb.bidQtyAdd[sid])
		seb.ret[bias+3] = DivIgNa(seb.askQtyCancel[sid]-seb.bidQtyCancel[sid], seb.askQtyCancel[sid]+seb.bidQtyCancel[sid])

		bias = seb.pLen*24 + 4
		num := bias

		for i := 0; i < num; i++ {
			seb.tempVals[0] = naInf2Zero(seb.ret[i])
			seb.crossers[i].Update(sid, seb.tempVals)
			seb.crossers[i].GetValue(sid, seb.tempVals2)
			seb.ret[bias] = seb.tempVals2[0]
			seb.ret[bias+1] = seb.tempVals2[1]
			seb.ret[bias+2] = seb.tempVals2[3]
			bias += 3
		}
	}
	seb.snapAskK[sid] = seb.snapAskK[sid][:0]
	seb.snapBidK[sid] = seb.snapBidK[sid][:0]

	seb.amtSell[sid] = 0.
	seb.amtBuy[sid] = 0.
	seb.qtySell[sid] = 0.
	seb.qtyBuy[sid] = 0.

	seb.sellMin[sid] = math.MaxFloat64
	seb.buyMax[sid] = 0.

	return seb.ret, nil
}
