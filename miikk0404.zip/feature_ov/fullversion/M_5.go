package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
)

//PMXJ P31 P34, P35 imdex
//部分和T_8可能重合

//
//TODO 截面ir特征
//TODO delta版本

//M-5-s1, M-5-s4, M-5-s6, M-5-s7, M-5-s9-600, M-5-s10-600, M-5-s12-600, M-5-s13-600, M-5-s19-2400, M-5-s22-2400, M-5-s60, M-5-s61, M-5-s64, M-5-s67, M-5-s70, M-5-s73, M-5-s75, M-5-s76
//M-5-s2-im, M-5-s5-im, M-5-s20-im-2400, M-5-s29-im-2400, M-5-s56-im-2400, M-5-s58-im-2400, M-5-s77-im, M-5-s79-im, M-5-s80-im //im feature stronger this year than years before!

//['M-5-s73', 'M-5-s19-2400', 'M-5-s13-600', 'M-5-s6', 'M-5-s34-2400', 'M-5-s1', 'M-5-s15-600', 'M-5-s61', 'M-5-s10-600', 'M-5-s4']
//['M-5-s2-im', 'M-5-s74-im', 'M-5-s20-im-2400', 'M-5-s8-im', 'M-5-s78-im', 'M-5-s54-im-2400', 'M-5-s14-im-600',  'M-5-s35-im-2400', 'M-5-s26-im-2400', 'M-5-s38-im-2400']

type M_5 struct {
	FeatureBase
	hl   float64 //2400
	size int     // 600
	pow  float64

	start map[int]bool

	midPriceMap map[int]float64

	//return
	ret []float64

	avgPrice map[int]*floatRingBuf // hl 固定为10 主要防止在分钟的整数点附近有变化波动
	avgQty   map[int]*floatRingBuf
	cumAmt   map[int]*floatRingBuf

	groupData map[int]int //增加一个-1，表示全部股票

	retSinceOpenGroup        map[int]float64 // -1的特征已有, 但是这里用交易量加权
	retSinceCloseGroup       map[int]float64 // -1的特征已有, 但是这里用交易量加权
	retSinceAvgPriceGroup    map[int]float64
	retStdSinceOpenGroup     map[int]float64
	retStdSinceCloseGroup    map[int]float64
	retStdSinceAvgPriceGroup map[int]float64
	bidQtySinceAvgQtyGroup   map[int][]float64 // l1 l2 l3-l5sum l3-l5max l6-l10sum l6-l10max
	askQtySinceAvgQtyGroup   map[int][]float64 // l1 l2 l3-l5sum l3-l5max l6-l10sum l6-l10max
	buyAmtSincecumAmtGroup   map[int][]float64 // big small all
	sellAmtSincecumAmtGroup  map[int][]float64 // big small all
	cumAmtGroup              map[int]float64
	wGroup                   map[int]float64

	retSinceOpenLast        map[int]float64
	retSinceCloseLast       map[int]float64
	retSinceAvgPriceLast    map[int]float64
	retStdSinceOpenLast     map[int]float64
	retStdSinceCloseLast    map[int]float64
	retStdSinceAvgPriceLast map[int]float64
	bidQtySinceAvgQtyLast   map[int][]float64
	askQtySinceAvgQtyLast   map[int][]float64
	buyAmtSincecumAmtLast   map[int][]float64
	sellAmtSincecumAmtLast  map[int][]float64
	wLast                   map[int]float64

	priceOpen  map[int]float64
	priceClose map[int]float64

	retSinceOpenBuff        map[int]*floatRingBuf
	retStdSinceCloseBuff    map[int]*floatRingBuf
	retStdSinceAvgPricebuff map[int]*floatRingBuf

	emaAskQty map[int][]*MXEMA // l1 l2 l3-l5sum l3-l5max l6-l10sum l6-l10max
	emaBidQty map[int][]*MXEMA
	amtSell   map[int][]float64
	amtBuy    map[int][]float64

	qtyList []float64
	amtList []float64

	w map[int]float64
}

func (seb *M_5) loadFeaturePrefs() error {
	seb.hl = seb.prefs.GetFloat64Pref(seb.featureName + "_hl")
	seb.size = seb.prefs.GetIntPref(seb.featureName + "_size")
	seb.pow = seb.prefs.GetFloat64Pref(seb.featureName + "_power")
	return nil
}

//setFeatureNames: set column names.
func (seb *M_5) setFeatureNames() {
	seb.colNames = make([]string, 81)
	for i := 0; i < 9; i++ {
		if math.Mod(float64(i), 3) == 2 {
			seb.colNames[i] = fmt.Sprintf("%s-s%d-im", seb.featureName, i)
		} else {
			seb.colNames[i] = fmt.Sprintf("%s-s%d", seb.featureName, i)
		}
	}
	for i := 9; i < 18; i++ {
		if math.Mod(float64(i), 3) == 2 {
			seb.colNames[i] = fmt.Sprintf("%s-s%d-im-%d", seb.featureName, i, seb.size)
		} else {
			seb.colNames[i] = fmt.Sprintf("%s-s%d-%d", seb.featureName, i, seb.size)
		}
	}
	for i := 18; i < 60; i++ {
		if math.Mod(float64(i), 3) == 2 || i >= 54 {
			seb.colNames[i] = fmt.Sprintf("%s-s%d-im-%d", seb.featureName, i, int(seb.hl))
		} else {
			seb.colNames[i] = fmt.Sprintf("%s-s%d-%d", seb.featureName, i, int(seb.hl))
		}
	}
	for i := 60; i < 81; i++ {
		if math.Mod(float64(i), 3) == 2 || i >= 78 {
			seb.colNames[i] = fmt.Sprintf("%s-s%d-im", seb.featureName, i)
		} else {
			seb.colNames[i] = fmt.Sprintf("%s-s%d", seb.featureName, i)
		}
	}

	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *M_5) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.midPriceMap = make(map[int]float64)
	seb.start = make(map[int]bool)

	seb.avgPrice = make(map[int]*floatRingBuf)
	seb.avgQty = make(map[int]*floatRingBuf)
	seb.cumAmt = make(map[int]*floatRingBuf)

	seb.groupData = make(map[int]int)

	seb.retSinceOpenGroup = make(map[int]float64)
	seb.retSinceCloseGroup = make(map[int]float64)
	seb.retSinceAvgPriceGroup = make(map[int]float64)
	seb.retStdSinceOpenGroup = make(map[int]float64)
	seb.retStdSinceCloseGroup = make(map[int]float64)
	seb.retStdSinceAvgPriceGroup = make(map[int]float64)
	seb.bidQtySinceAvgQtyGroup = make(map[int][]float64)
	seb.askQtySinceAvgQtyGroup = make(map[int][]float64)
	seb.buyAmtSincecumAmtGroup = make(map[int][]float64)
	seb.sellAmtSincecumAmtGroup = make(map[int][]float64)
	seb.cumAmtGroup = make(map[int]float64)
	seb.wGroup = make(map[int]float64)

	seb.retSinceOpenLast = make(map[int]float64)
	seb.retSinceCloseLast = make(map[int]float64)
	seb.retSinceAvgPriceLast = make(map[int]float64)
	seb.retStdSinceOpenLast = make(map[int]float64)
	seb.retStdSinceCloseLast = make(map[int]float64)
	seb.retStdSinceAvgPriceLast = make(map[int]float64)
	seb.bidQtySinceAvgQtyLast = make(map[int][]float64)
	seb.askQtySinceAvgQtyLast = make(map[int][]float64)
	seb.buyAmtSincecumAmtLast = make(map[int][]float64)
	seb.sellAmtSincecumAmtLast = make(map[int][]float64)
	seb.wLast = make(map[int]float64)
	seb.w = make(map[int]float64)

	seb.priceOpen = make(map[int]float64)
	seb.priceClose = make(map[int]float64)

	seb.retSinceOpenBuff = make(map[int]*floatRingBuf)
	seb.retStdSinceCloseBuff = make(map[int]*floatRingBuf)
	seb.retStdSinceAvgPricebuff = make(map[int]*floatRingBuf)

	seb.emaAskQty = make(map[int][]*MXEMA)
	seb.emaBidQty = make(map[int][]*MXEMA)
	seb.amtBuy = make(map[int][]float64)
	seb.amtSell = make(map[int][]float64)

	seb.qtyList = make([]float64, 6)
	seb.amtList = make([]float64, 3)

	for sid := range seb.sidUniverse {
		seb.avgPrice[sid] = newFloatRingBuf(10)
		seb.avgQty[sid] = newFloatRingBuf(10)
		seb.cumAmt[sid] = newFloatRingBuf(10)
		seb.bidQtySinceAvgQtyLast[sid] = make([]float64, 6)
		seb.askQtySinceAvgQtyLast[sid] = make([]float64, 6)
		seb.buyAmtSincecumAmtLast[sid] = make([]float64, 3)
		seb.sellAmtSincecumAmtLast[sid] = make([]float64, 3)
		seb.retSinceOpenBuff[sid] = newFloatRingBuf(seb.size)
		seb.retStdSinceCloseBuff[sid] = newFloatRingBuf(seb.size)
		seb.retStdSinceAvgPricebuff[sid] = newFloatRingBuf(seb.size)
		seb.emaAskQty[sid] = make([]*MXEMA, 6)
		seb.emaBidQty[sid] = make([]*MXEMA, 6)
		seb.amtBuy[sid] = make([]float64, 3)
		seb.amtSell[sid] = make([]float64, 3)
		for j := 0; j < 6; j++ {
			seb.emaAskQty[sid][j] = NewMXEMA(seb.hl, 3)
			seb.emaBidQty[sid][j] = NewMXEMA(seb.hl, 3)
		}
	}
}

func (seb *M_5) initializeGroup(gid int) {
	if _, ok := seb.retSinceOpenGroup[gid]; !ok {
		seb.retSinceOpenGroup[gid] = 0.
		seb.retSinceCloseGroup[gid] = 0.
		seb.retSinceAvgPriceGroup[gid] = 0.
		seb.retStdSinceOpenGroup[gid] = 0.
		seb.retStdSinceCloseGroup[gid] = 0.
		seb.retStdSinceAvgPriceGroup[gid] = 0.
		seb.bidQtySinceAvgQtyGroup[gid] = make([]float64, 6)
		seb.askQtySinceAvgQtyGroup[gid] = make([]float64, 6)
		seb.buyAmtSincecumAmtGroup[gid] = make([]float64, 3)
		seb.sellAmtSincecumAmtGroup[gid] = make([]float64, 3)
		seb.cumAmtGroup[gid] = 0.
		seb.wGroup[gid] = 0.
	}
}

//update gid with -1,  and update vlast of this sid to the latest
func (seb *M_5) updateGroup(gid, sid int, group map[int]float64, vLast map[int]float64, vNew float64, w float64) {
	if math.IsNaN(vNew) || math.IsInf(vNew, 0) {
		return
	}
	group[gid] -= vLast[sid] * w
	group[gid] += vNew * w
	group[-1] -= vLast[sid] * w
	group[-1] += vNew * w
	vLast[sid] = vNew
}

func (seb *M_5) updateGroupList(gid, sid int, group map[int][]float64, vLast map[int][]float64, vNew []float64, w float64) {
	for i := 0; i < len(vNew); i++ {
		if math.IsNaN(vNew[i]) || math.IsInf(vNew[i], 0) {
			continue
		}
		group[gid][i] -= vLast[sid][i] * w
		group[gid][i] += vNew[i] * w
		group[-1][i] -= vLast[sid][i] * w
		group[-1][i] += vNew[i] * w
		vLast[sid][i] = vNew[i]
	}
}

//Update
func (seb *M_5) UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int, extraInfo map[int][]float64) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	seb.start[sid] = true

	if _, ok := seb.priceOpen[sid]; !ok {
		seb.priceOpen[sid] = snapData[40]
		seb.priceClose[sid] = snapData[43]
	}
	avgPrice := extraInfo[sid][4] / extraInfo[sid][3] //这个是median/median，不是mean/mean, 因此严格上不是很准确
	avgQty := extraInfo[sid][2]
	cumAmt := extraInfo[sid][4]
	seb.avgPrice[sid].push(avgPrice)
	seb.avgQty[sid].push(avgQty)
	seb.cumAmt[sid].push(cumAmt)

	//use a fixed 0.3 instead of a dynamic seb.pow
	if _, ok := seb.w[sid]; !ok {
		seb.w[sid] = powerTransform(IgNa2Zero(extraInfo[sid][5]), 0.3) / 100.0
	}

	if len(seb.groupData) == 0 {
		for sid, gid := range groupData {
			seb.groupData[sid] = gid
		}
	}
	gid := seb.groupData[sid]

	seb.initializeGroup(-1) //all
	seb.initializeGroup(gid)

	seb.updateGroup(gid, sid, seb.wGroup, seb.wLast, seb.w[sid], 1.)

	seb.midPriceMap[sid] = E_midPrc(snapData[0], snapData[20])
	seb.updateGroup(gid, sid, seb.retSinceOpenGroup, seb.retSinceOpenLast, seb.midPriceMap[sid]/seb.priceOpen[sid], seb.w[sid])
	seb.updateGroup(gid, sid, seb.retSinceCloseGroup, seb.retSinceCloseLast, seb.midPriceMap[sid]/seb.priceClose[sid], seb.w[sid])
	seb.updateGroup(gid, sid, seb.retSinceAvgPriceGroup, seb.retSinceAvgPriceLast, seb.midPriceMap[sid]/seb.avgPrice[sid].mean(), seb.w[sid])
	seb.retSinceOpenBuff[sid].push(seb.midPriceMap[sid] / seb.priceOpen[sid])
	seb.retStdSinceCloseBuff[sid].push(seb.midPriceMap[sid] / seb.priceClose[sid])
	seb.retStdSinceAvgPricebuff[sid].push(seb.midPriceMap[sid] / seb.avgPrice[sid].mean())

	if seb.retSinceOpenBuff[sid].getNT() > 5 {
		seb.updateGroup(gid, sid, seb.retStdSinceOpenGroup, seb.retStdSinceOpenLast, seb.retSinceOpenBuff[sid].std(), seb.w[sid])
		seb.updateGroup(gid, sid, seb.retStdSinceCloseGroup, seb.retStdSinceCloseLast, seb.retStdSinceCloseBuff[sid].std(), seb.w[sid])
		seb.updateGroup(gid, sid, seb.retStdSinceAvgPriceGroup, seb.retStdSinceAvgPriceLast, seb.retStdSinceAvgPricebuff[sid].std(), seb.w[sid])
	}

	// exactly same as M_4 except for not supporting hl_list
	askQtySum35 := 0.
	bidQtySum35 := 0.
	askQtyMax35 := 0.
	bidQtyMax35 := 0.
	askQtySum610 := 0.
	bidQtySum610 := 0.
	askQtyMax610 := 0.
	bidQtyMax610 := 0.

	for i := 0; i < 10; i++ {
		if i >= 2 && i < 5 {
			askQtySum35 += snapData[i*2+1]
			bidQtySum35 += snapData[i*2+21]
			askQtyMax35 = math.Max(askQtyMax35, snapData[i*2+1])
			bidQtyMax35 = math.Max(bidQtyMax35, snapData[i*2+21])
		}
		if i >= 5 && i < 10 {
			askQtySum610 += snapData[i*2+1]
			bidQtySum610 += snapData[i*2+21]
			askQtyMax610 = math.Max(askQtyMax610, snapData[i*2+1])
			bidQtyMax610 = math.Max(bidQtyMax610, snapData[i*2+21])
		}
	}
	avgQtyPop := seb.avgQty[sid].mean()

	seb.emaAskQty[sid][0].Update(secSinceEpoch, snapData[1]/avgQtyPop)
	seb.emaBidQty[sid][0].Update(secSinceEpoch, snapData[21]/avgQtyPop)
	seb.emaAskQty[sid][1].Update(secSinceEpoch, snapData[3]/avgQtyPop)
	seb.emaBidQty[sid][1].Update(secSinceEpoch, snapData[23]/avgQtyPop)
	seb.emaAskQty[sid][2].Update(secSinceEpoch, askQtySum35/3.0/avgQtyPop)
	seb.emaBidQty[sid][2].Update(secSinceEpoch, bidQtySum35/3.0/avgQtyPop)
	seb.emaAskQty[sid][3].Update(secSinceEpoch, askQtyMax35/avgQtyPop)
	seb.emaBidQty[sid][3].Update(secSinceEpoch, bidQtyMax35/avgQtyPop)
	seb.emaAskQty[sid][4].Update(secSinceEpoch, askQtySum610/5.0/avgQtyPop)
	seb.emaBidQty[sid][4].Update(secSinceEpoch, bidQtySum610/5.0/avgQtyPop)
	seb.emaAskQty[sid][5].Update(secSinceEpoch, askQtyMax610/avgQtyPop)
	seb.emaBidQty[sid][5].Update(secSinceEpoch, bidQtyMax610/avgQtyPop)

	for i := 0; i < 6; i++ {
		seb.qtyList[i] = ClipIgNa(powerTransform(seb.emaBidQty[sid][i].GetEma(), seb.pow), 10.0)
	}
	seb.updateGroupList(gid, sid, seb.bidQtySinceAvgQtyGroup, seb.bidQtySinceAvgQtyLast, seb.qtyList, seb.w[sid])
	for i := 0; i < 6; i++ {
		seb.qtyList[i] = ClipIgNa(powerTransform(seb.emaAskQty[sid][i].GetEma(), seb.pow), 10.0)
	}
	seb.updateGroupList(gid, sid, seb.askQtySinceAvgQtyGroup, seb.askQtySinceAvgQtyLast, seb.qtyList, seb.w[sid])

	amt := 0.
	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.amtBuy[sid][0] -= amt
		} else {
			seb.amtBuy[sid][1] += amt
		}
		seb.amtBuy[sid][2] += math.Abs(amt)
	}
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.amtSell[sid][0] -= amt
		} else {
			seb.amtSell[sid][1] += amt
		}
		seb.amtSell[sid][2] += math.Abs(amt)
	}
	for i := 0; i < 3; i++ {
		seb.amtList[i] = ClipIgNa(powerTransform(seb.amtBuy[sid][i]/seb.cumAmt[sid].mean(), seb.pow), 10.0)
	}
	seb.updateGroupList(gid, sid, seb.buyAmtSincecumAmtGroup, seb.buyAmtSincecumAmtLast, seb.amtList, seb.w[sid])
	for i := 0; i < 3; i++ {
		seb.amtList[i] = ClipIgNa(powerTransform(seb.amtSell[sid][i]/seb.cumAmt[sid].mean(), seb.pow), 10.0)
	}
	seb.updateGroupList(gid, sid, seb.sellAmtSincecumAmtGroup, seb.sellAmtSincecumAmtLast, seb.amtList, seb.w[sid])

	return true
}

//GetValues
func (seb *M_5) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else {
		gid := seb.groupData[sid]
		seb.ret[0] = seb.retSinceOpenLast[sid] - seb.retSinceOpenGroup[gid]/seb.wGroup[gid]
		seb.ret[1] = seb.retSinceOpenLast[sid] - seb.retSinceOpenGroup[-1]/seb.wGroup[-1]
		seb.ret[2] = seb.ret[0] - seb.ret[1] //m
		seb.ret[3] = seb.retSinceCloseLast[sid] - seb.retSinceCloseGroup[gid]/seb.wGroup[gid]
		seb.ret[4] = seb.retSinceCloseLast[sid] - seb.retSinceCloseGroup[-1]/seb.wGroup[-1]
		seb.ret[5] = seb.ret[3] - seb.ret[4] //m
		seb.ret[6] = seb.retSinceAvgPriceLast[sid] - seb.retSinceAvgPriceGroup[gid]/seb.wGroup[gid]
		seb.ret[7] = seb.retSinceAvgPriceLast[sid] - seb.retSinceAvgPriceGroup[-1]/seb.wGroup[-1]
		seb.ret[8] = seb.ret[6] - seb.ret[7] //m

		loc := 9
		seb.ret[loc+0] = DivIgNa(seb.retStdSinceOpenLast[sid], seb.retStdSinceOpenGroup[gid]/seb.wGroup[gid]) - 1.
		seb.ret[loc+1] = DivIgNa(seb.retStdSinceOpenLast[sid], seb.retStdSinceOpenGroup[-1]/seb.wGroup[-1]) - 1.
		seb.ret[loc+2] = DivIgNa(seb.retStdSinceOpenGroup[gid]/seb.wGroup[gid], seb.retStdSinceOpenGroup[-1]/seb.wGroup[-1]) - 1. //m
		seb.ret[loc+3] = DivIgNa(seb.retStdSinceCloseLast[sid], seb.retStdSinceCloseGroup[gid]/seb.wGroup[gid]) - 1.
		seb.ret[loc+4] = DivIgNa(seb.retStdSinceCloseLast[sid], seb.retStdSinceCloseGroup[-1]/seb.wGroup[-1]) - 1.
		seb.ret[loc+5] = DivIgNa(seb.retStdSinceCloseGroup[gid]/seb.wGroup[gid], seb.retStdSinceCloseGroup[-1]/seb.wGroup[-1]) - 1. //m
		seb.ret[loc+6] = DivIgNa(seb.retStdSinceAvgPriceLast[sid], seb.retStdSinceAvgPriceGroup[gid]/seb.wGroup[gid]) - 1.
		seb.ret[loc+7] = DivIgNa(seb.retStdSinceAvgPriceLast[sid], seb.retStdSinceAvgPriceGroup[-1]/seb.wGroup[-1]) - 1.
		seb.ret[loc+8] = DivIgNa(seb.retStdSinceAvgPriceGroup[gid]/seb.wGroup[gid], seb.retStdSinceAvgPriceGroup[-1]/seb.wGroup[-1]) - 1. //m

		loc = 18
		for i := 0; i < 6; i++ {
			seb.ret[loc] = DivIgNa(seb.bidQtySinceAvgQtyLast[sid][i], seb.bidQtySinceAvgQtyGroup[gid][i]/seb.wGroup[gid]) - 1.
			loc += 1
			seb.ret[loc] = DivIgNa(seb.bidQtySinceAvgQtyLast[sid][i], seb.bidQtySinceAvgQtyGroup[-1][i]/seb.wGroup[-1]) - 1.
			loc += 1
			seb.ret[loc] = DivIgNa(seb.bidQtySinceAvgQtyGroup[gid][i]/seb.wGroup[gid], seb.bidQtySinceAvgQtyGroup[-1][i]/seb.wGroup[-1]) - 1. //m
			loc += 1
		}
		loc = 36
		for i := 0; i < 6; i++ {
			seb.ret[loc] = DivIgNa(seb.askQtySinceAvgQtyLast[sid][i], seb.askQtySinceAvgQtyGroup[gid][i]/seb.wGroup[gid]) - 1.
			loc += 1
			seb.ret[loc] = DivIgNa(seb.askQtySinceAvgQtyLast[sid][i], seb.askQtySinceAvgQtyGroup[-1][i]/seb.wGroup[-1]) - 1.
			loc += 1
			seb.ret[loc] = DivIgNa(seb.askQtySinceAvgQtyGroup[gid][i]/seb.wGroup[gid], seb.askQtySinceAvgQtyGroup[-1][i]/seb.wGroup[-1]) - 1. //m
			loc += 1
		}
		loc = 54
		for i := 0; i < 6; i++ {
			seb.ret[loc] = seb.askQtySinceAvgQtyGroup[gid][i]/seb.wGroup[gid] - seb.bidQtySinceAvgQtyGroup[gid][i]/seb.wGroup[gid] //m
			loc += 1
		}
		loc = 60
		for i := 0; i < 3; i++ {
			seb.ret[loc] = DivIgNa(seb.buyAmtSincecumAmtLast[sid][i], seb.buyAmtSincecumAmtGroup[gid][i]/seb.wGroup[gid]) - 1.
			loc += 1
			seb.ret[loc] = DivIgNa(seb.buyAmtSincecumAmtLast[sid][i], seb.buyAmtSincecumAmtGroup[-1][i]/seb.wGroup[-1]) - 1.
			loc += 1
			seb.ret[loc] = DivIgNa(seb.buyAmtSincecumAmtGroup[gid][i]/seb.wGroup[gid], seb.buyAmtSincecumAmtGroup[-1][i]/seb.wGroup[-1]) - 1. //m
			loc += 1
		}
		loc = 69
		for i := 0; i < 3; i++ {
			seb.ret[loc] = DivIgNa(seb.sellAmtSincecumAmtLast[sid][i], seb.sellAmtSincecumAmtGroup[gid][i]/seb.wGroup[gid]) - 1.
			loc += 1
			seb.ret[loc] = DivIgNa(seb.sellAmtSincecumAmtLast[sid][i], seb.sellAmtSincecumAmtGroup[-1][i]/seb.wGroup[-1]) - 1.
			loc += 1
			seb.ret[loc] = DivIgNa(seb.sellAmtSincecumAmtGroup[gid][i]/seb.wGroup[gid], seb.sellAmtSincecumAmtGroup[-1][i]/seb.wGroup[-1]) - 1. //m
			loc += 1
		}
		loc = 78
		for i := 0; i < 3; i++ {
			seb.ret[loc] = seb.buyAmtSincecumAmtGroup[gid][i]/seb.wGroup[gid] - seb.sellAmtSincecumAmtGroup[gid][i]/seb.wGroup[gid] //m
			loc += 1
		}

		for i := 0; i < len(seb.ret); i++ {
			seb.ret[i] = ClipIgNa(seb.ret[i], 10.0)
		}
	}
	return seb.ret, nil
}
