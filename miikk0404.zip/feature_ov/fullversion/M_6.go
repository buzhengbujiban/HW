package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
)

//和M_5类似，但是主要用了rw22
//

//M-6-s0 M-6-s1 M-6-s8 M-6-s10 M-6-s13
//M-6-s5-im M-6-s11-im

//['M-6-s8', 'M-6-s7', 'M-6-s15', 'M-6-s10', 'M-6-s0']
//['M-6-s11-im', 'M-6-s5-im']

type M_6 struct {
	FeatureBase
	pow float64 //0.3

	start map[int]bool

	//return
	ret []float64

	cumAmt map[int]*floatRingBuf // hl 固定为10 主要防止在分钟的整数点附近有变化波动

	groupData map[int]int //增加一个-1，表示全部股票

	dailyAmtBuyGroup   map[int]float64
	dailyAmtSellGroup  map[int]float64
	dailyAmtBuyPGroup  map[int][]float64 // big small all
	dailyAmtSellPGroup map[int][]float64 // big small all
	wGroup             map[int]float64

	amtBuy        map[int][]float64
	amtSell       map[int][]float64
	dailyAmtBuy   map[int]float64
	dailyAmtSell  map[int]float64
	dailyAmtBuyP  map[int][]float64 // big small all
	dailyAmtSellP map[int][]float64 // big small all
	wLast         map[int]float64

	amtList []float64

	w map[int]float64
}

func (seb *M_6) loadFeaturePrefs() error {
	seb.pow = seb.prefs.GetFloat64Pref(seb.featureName + "_power")
	return nil
}

//setFeatureNames: set column names.
func (seb *M_6) setFeatureNames() {
	seb.colNames = make([]string, 18)
	for i := 0; i < 18; i++ {
		if math.Mod(float64(i), 6) == 5 {
			seb.colNames[i] = fmt.Sprintf("%s-s%d-im", seb.featureName, i)
		} else {
			seb.colNames[i] = fmt.Sprintf("%s-s%d", seb.featureName, i)
		}
	}

	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *M_6) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.start = make(map[int]bool)

	seb.cumAmt = make(map[int]*floatRingBuf)

	seb.groupData = make(map[int]int)

	seb.dailyAmtBuyGroup = make(map[int]float64)
	seb.dailyAmtSellGroup = make(map[int]float64)
	seb.dailyAmtBuyPGroup = make(map[int][]float64)
	seb.dailyAmtSellPGroup = make(map[int][]float64)
	seb.wGroup = make(map[int]float64)

	seb.amtBuy = make(map[int][]float64)
	seb.amtSell = make(map[int][]float64)
	seb.dailyAmtBuy = make(map[int]float64)
	seb.dailyAmtSell = make(map[int]float64)
	seb.dailyAmtBuyP = make(map[int][]float64)
	seb.dailyAmtSellP = make(map[int][]float64)
	seb.wLast = make(map[int]float64)
	seb.w = make(map[int]float64)

	seb.amtList = make([]float64, 3)

	for sid := range seb.sidUniverse {
		seb.cumAmt[sid] = newFloatRingBuf(10)
		seb.amtBuy[sid] = make([]float64, 3)
		seb.amtSell[sid] = make([]float64, 3)
		seb.dailyAmtBuyP[sid] = make([]float64, 3)
		seb.dailyAmtSellP[sid] = make([]float64, 3)
	}
}

func (seb *M_6) initializeGroup(gid int) {
	if _, ok := seb.dailyAmtBuyGroup[gid]; !ok {
		seb.dailyAmtBuyGroup[gid] = 0.
		seb.dailyAmtSellGroup[gid] = 0.
		seb.dailyAmtBuyPGroup[gid] = make([]float64, 3)
		seb.dailyAmtSellPGroup[gid] = make([]float64, 3)
		seb.wGroup[gid] = 0.
	}
}

//update gid with -1,  and update vlast of this sid to the latest
func (seb *M_6) updateGroup(gid, sid int, group map[int]float64, vLast map[int]float64, vNew float64, w float64) {
	if math.IsNaN(vNew) || math.IsInf(vNew, 0) {
		return
	}
	group[gid] -= vLast[sid] * w
	group[gid] += vNew * w
	group[-1] -= vLast[sid] * w
	group[-1] += vNew * w
	vLast[sid] = vNew
}

func (seb *M_6) updateGroupList(gid, sid int, group map[int][]float64, vLast map[int][]float64, vNew []float64, w float64) {
	for i := 0; i < len(vNew); i++ {
		if math.IsNaN(vNew[i]) || math.IsInf(vNew[i], 0) {
			continue
		}
		group[gid][i] -= vLast[sid][i] * w
		group[gid][i] += vNew[i] * w
		group[-1][i] -= vLast[sid][i] * w
		group[-1][i] += vNew[i] * w
		vLast[sid][i] = vNew[i]
	}
}

//Update
func (seb *M_6) UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int, extraInfo map[int][]float64) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	seb.start[sid] = true

	cumAmt := extraInfo[sid][4]
	seb.cumAmt[sid].push(cumAmt)

	dailyAmt := extraInfo[sid][5]
	ratio := seb.cumAmt[sid].mean() / dailyAmt

	//use a fixed 0.3 instead of a dynamic seb.pow
	if _, ok := seb.w[sid]; !ok {
		seb.w[sid] = powerTransform(IgNa2Zero(dailyAmt), 0.3) / 100.0
	}

	if len(seb.groupData) == 0 {
		for sid, gid := range groupData {
			seb.groupData[sid] = gid
		}
	}
	gid := seb.groupData[sid]

	seb.initializeGroup(-1) //all
	seb.initializeGroup(gid)

	seb.updateGroup(gid, sid, seb.wGroup, seb.wLast, seb.w[sid], 1.)

	seb.updateGroup(gid, sid, seb.dailyAmtBuyGroup, seb.dailyAmtBuy, powerTransform(extraInfo[sid][6], seb.pow), seb.w[sid])
	seb.updateGroup(gid, sid, seb.dailyAmtSellGroup, seb.dailyAmtSell, powerTransform(extraInfo[sid][7], seb.pow), seb.w[sid])

	amt := 0.
	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.amtBuy[sid][0] -= amt
		} else {
			seb.amtBuy[sid][1] += amt
		}
		seb.amtBuy[sid][2] += math.Abs(amt)
	}
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.amtSell[sid][0] -= amt
		} else {
			seb.amtSell[sid][1] += amt
		}
		seb.amtSell[sid][2] += math.Abs(amt)
	}

	for i := 0; i < 3; i++ {
		seb.amtList[i] = powerTransform(seb.amtBuy[sid][i]/ratio, seb.pow)
	}
	seb.updateGroupList(gid, sid, seb.dailyAmtBuyPGroup, seb.dailyAmtBuyP, seb.amtList, seb.w[sid])

	for i := 0; i < 3; i++ {
		seb.amtList[i] = powerTransform(seb.amtSell[sid][i]/ratio, seb.pow)
	}
	seb.updateGroupList(gid, sid, seb.dailyAmtSellPGroup, seb.dailyAmtSellP, seb.amtList, seb.w[sid])

	return true
}

//GetValues
func (seb *M_6) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else {
		gid := seb.groupData[sid]
		loc := 0
		a := 0.
		b := 0.
		c := 0.
		for i := 0; i < 3; i++ {
			a = DivIgNa(seb.dailyAmtBuyP[sid][i], seb.dailyAmtBuy[sid])
			seb.ret[loc] = a
			loc += 1
			b = DivIgNa(seb.dailyAmtSellP[sid][i], seb.dailyAmtSell[sid])
			seb.ret[loc] = b
			loc += 1
			seb.ret[loc] = a - b
			loc += 1

			a = DivIgNa(seb.dailyAmtBuyPGroup[gid][i], seb.dailyAmtSellPGroup[gid][i])
			b = DivIgNa(seb.dailyAmtBuyPGroup[-1][i], seb.dailyAmtSellPGroup[-1][i])
			c = DivIgNa(seb.dailyAmtBuyP[sid][i], seb.dailyAmtSellP[sid][i])
			seb.ret[loc] = c - a
			loc += 1
			seb.ret[loc] = c - b
			loc += 1
			seb.ret[loc] = a - b //m
			loc += 1
		}
		for i := 0; i < len(seb.ret); i++ {
			seb.ret[i] = ClipIgNa(seb.ret[i], 10.0)
		}

	}
	return seb.ret, nil
}
