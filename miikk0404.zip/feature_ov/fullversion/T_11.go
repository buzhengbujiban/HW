package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
	"sort"
)

/*
var i2nT11 = map[string]int{
	"sell":      0,
	"buy":       1,
	"bigSell":   2,
	"bigBuy":    3,
	"smallSell": 4,
	"smallBuy":  5,
}
*/

const (
	i2nT11Sell      int = 0
	i2nT11Buy       int = 1
	i2nT11BigSell   int = 2
	i2nT11BigBuy    int = 3
	i2nT11SmallSell int = 4
	i2nT11SmallBuy  int = 5
)

//累计imbalance 30s, 1min或者5min, 这里先用1min
//2个特征
type T_11 struct {
	FeatureBase
	hlList []float64
	pLen   int
	pow    float64

	size  map[int]int //默认3
	ratio float64     //默认1.1， 对于power=0.3

	pricesSeen []map[int][]float64
	emaData    []map[int]map[float64][]*MXEMA
	qtyStats   []map[int]map[float64]float64

	tempPrices   []float64
	tempSellQtys []float64
	tempBuyQtys  []float64

	prices [][]float64
	qtys   [][]float64

	start map[int]bool

	midPriceMap map[int]float64

	tag []bool

	//return
	ret []float64
}

func (seb *T_11) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.pLen = len(seb.hlList)
	seb.pow = seb.prefs.GetFloat64Pref(seb.featureName + "_power")
	//seb.size = seb.prefs.GetIntPref(seb.featureName + "_size")
	seb.ratio = seb.prefs.GetFloat64Pref(seb.featureName + "_ratio")
	return nil
}

//setFeatureNames: set column names.
func (seb *T_11) setFeatureNames() {
	seb.colNames = make([]string, 9*seb.pLen)
	for i := 0; i < seb.pLen; i++ {
		for j := 0; j < 9; j++ {
			seb.colNames[i+j*seb.pLen] = fmt.Sprintf("%s-%d-%ds", seb.featureName, j, int(seb.hlList[i]))
		}
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_11) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.pricesSeen = make([]map[int][]float64, 6)
	seb.emaData = make([]map[int]map[float64][]*MXEMA, 6)
	seb.qtyStats = make([]map[int]map[float64]float64, 6)

	seb.tempPrices = make([]float64, 0, 100)
	seb.tempSellQtys = make([]float64, 0, 100)
	seb.tempBuyQtys = make([]float64, 0, 100)

	seb.prices = make([][]float64, 6)
	seb.qtys = make([][]float64, 6)

	seb.midPriceMap = make(map[int]float64)
	seb.start = make(map[int]bool)

	seb.tag = make([]bool, 3)

	seb.size = make(map[int]int)

	for i := 0; i < 6; i++ {
		seb.pricesSeen[i] = make(map[int][]float64)
		seb.emaData[i] = make(map[int]map[float64][]*MXEMA)
		seb.qtyStats[i] = make(map[int]map[float64]float64)
		seb.prices[i] = make([]float64, seb.pLen)
		seb.qtys[i] = make([]float64, seb.pLen)
	}

	for sid := range seb.sidUniverse {
		for i := 0; i < 6; i++ {
			seb.pricesSeen[i][sid] = make([]float64, 0, 100) //In most case, cap 100 seen prices would be enough for whole day.
			seb.emaData[i][sid] = make(map[float64][]*MXEMA)
			seb.qtyStats[i][sid] = make(map[float64]float64)
		}
		seb.start[sid] = false
	}
}

func (seb *T_11) initializeEMAs(sid int, price float64, k int) {
	if _, ok := seb.emaData[k][sid][price]; !ok {
		seb.pricesSeen[k][sid] = append(seb.pricesSeen[k][sid], price)
		seb.emaData[k][sid][price] = make([]*MXEMA, seb.pLen)
		for j, hl := range seb.hlList {
			seb.emaData[k][sid][price][j] = NewMXEMA(hl, 3)
		}
	}
}

func (seb *T_11) tickSizeAdapt(price float64) float64 {
	tickSize := powerTransform(price/10., 0.5) * 0.01
	tickSize = math.Round(tickSize/0.01) * 0.01
	return tickSize
}

func (seb *T_11) priceAdjust(price, priceOpen float64) float64 {
	tickSize := seb.tickSizeAdapt(priceOpen)
	return math.Round(price/tickSize) * tickSize
}

//Update
func (seb *T_11) UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	amt := 0.
	qty := 0.

	for _, psp := range buyObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		qty = powerTransform(psp.Qty, seb.pow)
		price := seb.priceAdjust(psp.Price, snapData[40])
		if amt < 0 {
			seb.qtyStats[i2nT11SmallBuy][sid][price] -= qty
			seb.qtyStats[i2nT11Buy][sid][price] -= qty
		} else {
			seb.qtyStats[i2nT11BigBuy][sid][price] += qty
			seb.qtyStats[i2nT11Buy][sid][price] += qty
		}
	}
	for _, psp := range sellObs {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		qty = powerTransform(psp.Qty, seb.pow)
		price := seb.priceAdjust(psp.Price, snapData[40])
		if amt < 0 {
			seb.qtyStats[i2nT11SmallSell][sid][price] -= qty
			seb.qtyStats[i2nT11Sell][sid][price] -= qty
		} else {
			seb.qtyStats[i2nT11BigSell][sid][price] += qty
			seb.qtyStats[i2nT11Sell][sid][price] += qty
		}
	}

	if snapDataLast == nil {
		return true
	}

	seb.start[sid] = true

	seb.midPriceMap[sid] = E_midPrc(snapData[0], snapData[20])

	return true
}

//GetValues
func (seb *T_11) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else {
		for i := 0; i < 3; i++ {
			seb.tempPrices = seb.tempPrices[:0]
			seb.tempSellQtys = seb.tempSellQtys[:0]
			seb.tempBuyQtys = seb.tempBuyQtys[:0]

			for price := range seb.qtyStats[i*2][sid] {
				seb.tempPrices = append(seb.tempPrices, price)
			}
			for price := range seb.qtyStats[i*2+1][sid] {
				seb.tempPrices = append(seb.tempPrices, price)
			}
			sort.Float64s(seb.tempPrices)
			seb.tempPrices = RemoveDuplicateSortedFloat(seb.tempPrices)

			seb.size[sid] = int(math.Max(2., math.Min(float64(len(seb.tempPrices))/3., 3.)))

			seb.tag[i] = true
			if len(seb.tempPrices) < seb.size[sid] {
				seb.tag[i] = false
				continue
			}
			qty := 0.
			for _, price := range seb.tempPrices {
				if _, ok := seb.qtyStats[i*2][sid][price]; !ok {
					seb.tempSellQtys = append(seb.tempSellQtys, 0)
				} else {
					qty = seb.qtyStats[i*2][sid][price]
					if math.IsNaN(qty) || math.IsInf(qty, 0) {
						seb.tempSellQtys = append(seb.tempSellQtys, 0)
					} else {
						seb.tempSellQtys = append(seb.tempSellQtys, qty)
					}
				}

				if _, ok := seb.qtyStats[i*2+1][sid][price]; !ok {
					seb.tempBuyQtys = append(seb.tempBuyQtys, 0)
				} else {
					qty = seb.qtyStats[i*2+1][sid][price]
					if math.IsNaN(qty) || math.IsInf(qty, 0) {
						seb.tempBuyQtys = append(seb.tempBuyQtys, 0)
					} else {
						seb.tempBuyQtys = append(seb.tempBuyQtys, qty)
					}
				}
			}
			/*
				if sid == 2406 && i == 0 {
					//fmt.Println(seb.tempSellQtys)
					//fmt.Println(seb.tempBuyQtys)
					fmt.Println(seb.qtyStats[i2nT11["buy"]][sid])
					fmt.Println(seb.qtyStats[i2nT11["sell"]][sid])
					fmt.Println(seb.size[sid])
					fmt.Println(seb.tempSellQtys)
					fmt.Println(seb.tempBuyQtys)
				}
			*/
			leftLoc, leftDir, rightLoc, rightDir := DetectStackingOld(seb.tempSellQtys, seb.tempBuyQtys, seb.size[sid], seb.ratio)
			if leftLoc > 0 {
				for j := 0; j < seb.pLen; j++ {
					for k := 0; k <= leftLoc; k++ {
						if leftDir == -1 {
							seb.initializeEMAs(sid, seb.tempPrices[k], i*2)
							seb.emaData[i*2][sid][seb.tempPrices[k]][j].Update(secEpoch, seb.tempSellQtys[k])
						} else if leftDir == 1 {
							seb.initializeEMAs(sid, seb.tempPrices[k], i*2+1)
							seb.emaData[i*2+1][sid][seb.tempPrices[k]][j].Update(secEpoch, seb.tempBuyQtys[k])
						} else {
						}

					}

				}

			}
			if rightLoc > 0 {
				for j := 0; j < seb.pLen; j++ {
					for k := rightLoc; k <= len(seb.tempPrices)-1; k++ {
						if rightDir == -1 {
							seb.initializeEMAs(sid, seb.tempPrices[k], i*2)
							seb.emaData[i*2][sid][seb.tempPrices[k]][j].Update(secEpoch, seb.tempSellQtys[k])
						} else if rightDir == 1 {
							seb.initializeEMAs(sid, seb.tempPrices[k], i*2+1)
							seb.emaData[i*2+1][sid][seb.tempPrices[k]][j].Update(secEpoch, seb.tempBuyQtys[k])
						} else {
						}
					}
				}
			}

			for j := 0; j < seb.pLen; j++ {
				seb.tempSellQtys = seb.tempSellQtys[:0]
				for _, price := range seb.pricesSeen[i*2][sid] {
					seb.tempSellQtys = append(seb.tempSellQtys, seb.emaData[i*2][sid][price][j].GetEms(secEpoch))
				}
				seb.prices[i*2][j] = MeanVecXOnYIgNa(seb.pricesSeen[i*2][sid], seb.tempSellQtys)
				seb.qtys[i*2][j] = SumVecIgNa(seb.tempSellQtys)

				/*
					if sid == 1 && i == 0 && j == 0 {
						fmt.Println(seb.pricesSeen[i*2][sid])
						fmt.Println(seb.tempSellQtys)
						fmt.Println(MeanVecXOnYIgNa(seb.pricesSeen[i*2][sid], seb.tempSellQtys))
					}
				*/

				seb.tempBuyQtys = seb.tempBuyQtys[:0]
				for _, price := range seb.pricesSeen[i*2+1][sid] {
					seb.tempBuyQtys = append(seb.tempBuyQtys, seb.emaData[i*2+1][sid][price][j].GetEms(secEpoch))
				}
				seb.prices[i*2+1][j] = MeanVecXOnYIgNa(seb.pricesSeen[i*2+1][sid], seb.tempBuyQtys)
				seb.qtys[i*2+1][j] = SumVecIgNa(seb.tempBuyQtys)
			}
		}
		for j := 0; j < seb.pLen; j++ {
			bias := 0
			for i := 0; i < 3; i++ {
				if seb.tag[i] {
					//seb.prices[i*2+1][j]   seb.prices[i*2][j] 如果都是0, seb.ret[j+bias*seb.pLen]会都是-2
					seb.prices[i*2+1][j] = Zero2Na(seb.prices[i*2+1][j])
					seb.prices[i*2][j] = Zero2Na(seb.prices[i*2][j])
					seb.prices[i*2+1][j] = Zero2Na(seb.prices[i*2+1][j])
					seb.prices[i*2][j] = Zero2Na(seb.prices[i*2][j])
					seb.ret[j+bias*seb.pLen] = (seb.prices[i*2+1][j] + seb.prices[i*2][j] - 2*seb.midPriceMap[sid]) / seb.midPriceMap[sid]
					bias += 1
					seb.ret[j+bias*seb.pLen] = DivIgNa(seb.qtys[i*2+1][j]-seb.qtys[i*2][j], seb.qtys[i*2+1][j]+seb.qtys[i*2][j])
					bias += 1
					seb.ret[j+bias*seb.pLen] = DivIgNa(seb.prices[i*2+1][j]-seb.prices[i*2][j], seb.prices[i*2+1][j]+seb.prices[i*2][j])
					bias += 1
				} else {
					bias += 3 //20220818
				}
			}
		}
		/*
			if sid == 1 {
				fmt.Println("---", seb.ret[0])
			}
		*/

		//清空
		for i := 0; i < 6; i++ {
			seb.qtyStats[i][sid] = make(map[float64]float64)
		}
	}
	return seb.ret, nil
}
