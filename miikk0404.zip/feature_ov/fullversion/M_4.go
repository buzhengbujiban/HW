package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
)

//PMXJ P7 P11, 都是通过挂单, delta

//
//TODO 截面ir特征
//['M-4-8-1800s', 'M-4-16-1800s',  'M-4-24-1800s', 'M-4-22-1800s', 'M-4-21-1800s', 'M-4-78-1800s', 'M-4-30-1800s', 'M-4-77-1800s', 'M-4-76-1800s', 'M-4-80-1800s', 'M-4-72-1800s', 'M-4-68-1800s']

type M_4 struct {
	FeatureBase
	hlList      []float64 //1800
	hlListShort []float64 //60

	pLen int
	pow  float64

	start map[int]bool

	//return
	ret []float64

	emaAskQty map[int][][]*MXEMA    // l1 l2 l3-l5sum l3-l5max l6-l10sum l6-l10max
	emaBidQty map[int][][]*MXEMA    // l1 l2 l3-l5sum l3-l5max l6-l10sum l6-l10max
	avgPrice  map[int]*floatRingBuf // hl 固定为10 主要防止在分钟的整数点附近有变化波动
	avgQty    map[int]*floatRingBuf

	emaAskQtyShort map[int][][]*MXEMA
	emaBidQtyShort map[int][][]*MXEMA
}

func (seb *M_4) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.hlListShort = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list_short")
	seb.pow = seb.prefs.GetFloat64Pref(seb.featureName + "_power")
	seb.pLen = len(seb.hlList)
	if seb.pLen != len(seb.hlListShort) {
		panic("should ensure all hl list with same length")
	}
	return nil
}

//setFeatureNames: set column names.
func (seb *M_4) setFeatureNames() {
	seb.colNames = make([]string, seb.pLen*88)
	for i := 0; i < seb.pLen; i++ {
		for j := 0; j < 88; j++ {
			seb.colNames[i+j*seb.pLen] = fmt.Sprintf("%s-%d-%ds", seb.featureName, j, int(seb.hlList[i]))
		}
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *M_4) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.start = make(map[int]bool)
	seb.emaAskQty = make(map[int][][]*MXEMA)
	seb.emaBidQty = make(map[int][][]*MXEMA)
	seb.avgPrice = make(map[int]*floatRingBuf)
	seb.avgQty = make(map[int]*floatRingBuf)

	seb.emaAskQtyShort = make(map[int][][]*MXEMA)
	seb.emaBidQtyShort = make(map[int][][]*MXEMA)

	for sid := range seb.sidUniverse {
		seb.emaAskQty[sid] = make([][]*MXEMA, 6)
		seb.emaBidQty[sid] = make([][]*MXEMA, 6)
		seb.emaAskQtyShort[sid] = make([][]*MXEMA, 6)
		seb.emaBidQtyShort[sid] = make([][]*MXEMA, 6)
		for j := 0; j < 6; j++ {
			seb.emaAskQty[sid][j] = make([]*MXEMA, seb.pLen)
			seb.emaBidQty[sid][j] = make([]*MXEMA, seb.pLen)
			seb.emaAskQtyShort[sid][j] = make([]*MXEMA, seb.pLen)
			seb.emaBidQtyShort[sid][j] = make([]*MXEMA, seb.pLen)
			for i := 0; i < seb.pLen; i++ {
				seb.emaAskQty[sid][j][i] = NewMXEMA(seb.hlList[i], 3)
				seb.emaBidQty[sid][j][i] = NewMXEMA(seb.hlList[i], 3)
				seb.emaAskQtyShort[sid][j][i] = NewMXEMA(seb.hlListShort[i], 3)
				seb.emaBidQtyShort[sid][j][i] = NewMXEMA(seb.hlListShort[i], 3)
			}
		}
		seb.avgPrice[sid] = newFloatRingBuf(10)
		seb.avgQty[sid] = newFloatRingBuf(10)
	}
}

//Update
func (seb *M_4) UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int, extraInfo map[int][]float64) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}

	seb.start[sid] = true

	askQtySuM45 := 0.
	bidQtySuM45 := 0.
	askQtyMax35 := 0.
	bidQtyMax35 := 0.
	askQtySum610 := 0.
	bidQtySum610 := 0.
	askQtyMax610 := 0.
	bidQtyMax610 := 0.

	for i := 0; i < 10; i++ {
		if i >= 2 && i < 5 {
			askQtySuM45 += snapData[i*2+1]
			bidQtySuM45 += snapData[i*2+21]
			askQtyMax35 = math.Max(askQtyMax35, snapData[i*2+1])
			bidQtyMax35 = math.Max(bidQtyMax35, snapData[i*2+21])
		}
		if i >= 5 && i < 10 {
			askQtySum610 += snapData[i*2+1]
			bidQtySum610 += snapData[i*2+21]
			askQtyMax610 = math.Max(askQtyMax610, snapData[i*2+1])
			bidQtyMax610 = math.Max(bidQtyMax610, snapData[i*2+21])
		}
	}

	avgPrice := extraInfo[sid][4] / extraInfo[sid][3]
	avgQty := extraInfo[sid][2]
	seb.avgPrice[sid].push(avgPrice)
	seb.avgQty[sid].push(avgQty)

	avgQtyPop := seb.avgQty[sid].mean()

	for i := 0; i < seb.pLen; i++ {
		seb.emaAskQty[sid][0][i].Update(secSinceEpoch, snapData[1]/avgQtyPop)
		seb.emaBidQty[sid][0][i].Update(secSinceEpoch, snapData[21]/avgQtyPop)
		seb.emaAskQty[sid][1][i].Update(secSinceEpoch, snapData[3]/avgQtyPop)
		seb.emaBidQty[sid][1][i].Update(secSinceEpoch, snapData[23]/avgQtyPop)
		seb.emaAskQty[sid][2][i].Update(secSinceEpoch, askQtySuM45/3.0/avgQtyPop)
		seb.emaBidQty[sid][2][i].Update(secSinceEpoch, bidQtySuM45/3.0/avgQtyPop)
		seb.emaAskQty[sid][3][i].Update(secSinceEpoch, askQtyMax35/avgQtyPop)
		seb.emaBidQty[sid][3][i].Update(secSinceEpoch, bidQtyMax35/avgQtyPop)
		seb.emaAskQty[sid][4][i].Update(secSinceEpoch, askQtySum610/5.0/avgQtyPop)
		seb.emaBidQty[sid][4][i].Update(secSinceEpoch, bidQtySum610/5.0/avgQtyPop)
		seb.emaAskQty[sid][5][i].Update(secSinceEpoch, askQtyMax610/avgQtyPop)
		seb.emaBidQty[sid][5][i].Update(secSinceEpoch, bidQtyMax610/avgQtyPop)
	}

	for i := 0; i < seb.pLen; i++ {
		seb.emaAskQtyShort[sid][0][i].Update(secSinceEpoch, snapData[1]/avgQtyPop)
		seb.emaBidQtyShort[sid][0][i].Update(secSinceEpoch, snapData[21]/avgQtyPop)
		seb.emaAskQtyShort[sid][1][i].Update(secSinceEpoch, snapData[3]/avgQtyPop)
		seb.emaBidQtyShort[sid][1][i].Update(secSinceEpoch, snapData[23]/avgQtyPop)
		seb.emaAskQtyShort[sid][2][i].Update(secSinceEpoch, askQtySuM45/3.0/avgQtyPop)
		seb.emaBidQtyShort[sid][2][i].Update(secSinceEpoch, bidQtySuM45/3.0/avgQtyPop)
		seb.emaAskQtyShort[sid][3][i].Update(secSinceEpoch, askQtyMax35/avgQtyPop)
		seb.emaBidQtyShort[sid][3][i].Update(secSinceEpoch, bidQtyMax35/avgQtyPop)
		seb.emaAskQtyShort[sid][4][i].Update(secSinceEpoch, askQtySum610/5.0/avgQtyPop)
		seb.emaBidQtyShort[sid][4][i].Update(secSinceEpoch, bidQtySum610/5.0/avgQtyPop)
		seb.emaAskQtyShort[sid][5][i].Update(secSinceEpoch, askQtyMax610/avgQtyPop)
		seb.emaBidQtyShort[sid][5][i].Update(secSinceEpoch, bidQtyMax610/avgQtyPop)
	}

	return true
}

//GetValues
func (seb *M_4) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else {
		a := 0.
		b := 0.
		count := 0
		for i := 0; i < seb.pLen; i++ {
			count = 0
			for m := 0; m < 2; m++ {
				a = seb.emaAskQty[sid][m][i].GetEms(secEpoch)
				for n := 2; n < 6; n++ {
					b = seb.emaBidQty[sid][n][i].GetEms(secEpoch)
					seb.ret[i+count*seb.pLen] = DivIgNa(a, b) //TODO clip
					count += 1
				}
			}
			for m := 0; m < 2; m++ {
				a = seb.emaBidQty[sid][m][i].GetEms(secEpoch)
				for n := 2; n < 6; n++ {
					b = seb.emaAskQty[sid][n][i].GetEms(secEpoch)
					seb.ret[i+count*seb.pLen] = DivIgNa(a, b) //TODO clip
					count += 1
				}
			}
		}
		for i := 0; i < seb.pLen; i++ {
			count = 16 * seb.pLen
			//这16个和前面的16个类似，在特征选择的时候，最好只选其中一个
			for m := 0; m < 2; m++ {
				a = seb.emaAskQty[sid][m][i].GetEma()
				for n := 2; n < 6; n++ {
					b = seb.emaBidQty[sid][n][i].GetEma()
					seb.ret[i+count*seb.pLen] = a - b //TODO clip
					count += 1
				}
			}
			for m := 0; m < 2; m++ {
				a = seb.emaBidQty[sid][m][i].GetEma()
				for n := 2; n < 6; n++ {
					b = seb.emaAskQty[sid][n][i].GetEma()
					seb.ret[i+count*seb.pLen] = a - b //TODO clip
					count += 1
				}
			}
			//这12个比较重要
			for m := 0; m < 6; m++ {
				a = seb.emaAskQty[sid][m][i].GetEma()
				seb.ret[i+count*seb.pLen] = a
				count += 1
			}
			for m := 0; m < 6; m++ {
				a = seb.emaBidQty[sid][m][i].GetEma()
				seb.ret[i+count*seb.pLen] = a
				count += 1
			}
		}
		as := 0.
		bs := 0.
		for i := 0; i < seb.pLen; i++ {
			for m := 0; m < 2; m++ {
				a = seb.emaAskQty[sid][m][i].GetEms(secEpoch)
				as = seb.emaAskQtyShort[sid][m][i].GetEms(secEpoch)
				for n := 2; n < 6; n++ {
					b = seb.emaBidQty[sid][n][i].GetEms(secEpoch)
					bs := seb.emaBidQtyShort[sid][n][i].GetEms(secEpoch)
					seb.ret[i+count*seb.pLen] = DivIgNa((as-a)-(bs-b), math.Abs(as-a)+math.Abs(bs-b)) //TODO clip
					count += 1
				}
			}
			for m := 0; m < 2; m++ {
				a = seb.emaBidQty[sid][m][i].GetEms(secEpoch)
				as = seb.emaBidQtyShort[sid][m][i].GetEms(secEpoch)
				for n := 2; n < 6; n++ {
					b = seb.emaAskQty[sid][n][i].GetEms(secEpoch)
					bs := seb.emaAskQtyShort[sid][n][i].GetEms(secEpoch)
					seb.ret[i+count*seb.pLen] = DivIgNa((as-a)-(bs-b), math.Abs(as-a)+math.Abs(bs-b)) //TODO clip
					count += 1
				}
			}
		}
		for i := 0; i < seb.pLen; i++ {
			//这16个和前面的16个类似，在特征选择的时候，最好只选其中一个
			for m := 0; m < 2; m++ {
				a = seb.emaAskQty[sid][m][i].GetEma()
				as = seb.emaAskQtyShort[sid][m][i].GetEma()
				for n := 2; n < 6; n++ {
					b = seb.emaBidQty[sid][n][i].GetEma()
					bs = seb.emaBidQtyShort[sid][n][i].GetEma()
					seb.ret[i+count*seb.pLen] = (as - a) - (bs - b) //TODO clip
					count += 1
				}
			}
			for m := 0; m < 2; m++ {
				a = seb.emaBidQty[sid][m][i].GetEma()
				as = seb.emaBidQtyShort[sid][m][i].GetEma()
				for n := 2; n < 6; n++ {
					b = seb.emaAskQty[sid][n][i].GetEma()
					bs = seb.emaAskQtyShort[sid][n][i].GetEma()
					seb.ret[i+count*seb.pLen] = (as - a) - (bs - b) //TODO clip
					count += 1
				}
			}
			//这12个比较重要
			for m := 0; m < 6; m++ {
				a = seb.emaAskQty[sid][m][i].GetEma()
				as = seb.emaAskQtyShort[sid][m][i].GetEma()
				seb.ret[i+count*seb.pLen] = a - as
				count += 1
			}
			for m := 0; m < 6; m++ {
				a = seb.emaBidQty[sid][m][i].GetEma()
				as = seb.emaBidQtyShort[sid][m][i].GetEma()
				seb.ret[i+count*seb.pLen] = a - as
				count += 1
			}
		}
		for i := 0; i < len(seb.ret); i++ {
			seb.ret[i] = ClipIgNa(powerTransform(seb.ret[i], seb.pow), 10.0)
		}
	}
	return seb.ret, nil
}
