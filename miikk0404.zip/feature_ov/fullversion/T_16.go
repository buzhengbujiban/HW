package feature

import (
	"TES/QR/alpha_ov/data"
	MU "TES/QR/alpha_ov/mathUtils"
	"fmt"
	"math"
)

/*
var i2nT16 = map[string]int{
	"sell":      0,
	"buy":       1,
	"bigSell":   2,
	"bigBuy":    3,
	"smallSell": 4,
	"smallBuy":  5,
}
*/

const (
	i2nT16Sell      int = 0
	i2nT16Buy       int = 1
	i2nT16BigSell   int = 2
	i2nT16BigBuy    int = 3
	i2nT16SmallSell int = 4
	i2nT16SmallBuy  int = 5
)

//HT 66-13

type T_16 struct {
	FeatureBase

	doCross  bool
	crossers []*MU.WeightedNestedGroupMeanFast

	start map[int]bool

	amtTotal          map[int][]float64
	amtK              map[int][]float64
	amtTotalDown      map[int][]float64
	amtTotalUp        map[int][]float64
	tradeNumTotal     map[int][]float64
	tradeNumK         map[int][]float64
	tradeNumTotalDown map[int][]float64
	tradeNumTotalUp   map[int][]float64
	qtyK              map[int][]float64
	amtCumR22         map[int]float64
	qtyCumR22         map[int]float64
	amtCumR22LastSnap map[int]float64
	qtyCumR22LastSnap map[int]float64

	openSnap  map[int]float64
	closeSnap map[int]float64

	tempVals  []float64
	tempVals2 []float64

	//return
	ret []float64
}

func (seb *T_16) loadFeaturePrefs() error {
	seb.doCross = seb.prefs.GetBoolPref(seb.featureName + "_do_cross")

	return nil
}

//setFeatureNames: set column names.
func (seb *T_16) setFeatureNames() {
	seb.colNames = make([]string, 21*4)
	for i := 0; i < 21; i++ {
		seb.colNames[i] = fmt.Sprintf("%s-%draw", seb.featureName, i)
	}

	bias := 21
	for i := 0; i < 21; i++ {
		seb.colNames[bias] = fmt.Sprintf("%s-%dm", seb.featureName, i)
		seb.colNames[bias+1] = fmt.Sprintf("%s-%dim", seb.featureName, i)
		seb.colNames[bias+2] = fmt.Sprintf("%s-%dir", seb.featureName, i)
		bias += 3
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_16) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.crossers = make([]*MU.WeightedNestedGroupMeanFast, 21)
	for i := 0; i < 21; i++ {
		seb.crossers[i] = MU.NewWeightedNestedGroupMeanFast(seb.sidUniverseList, 1, seb.baseSidWgts, seb.industryCode, seb.conceptCodes)
	}

	seb.start = make(map[int]bool)

	seb.amtTotal = make(map[int][]float64)
	seb.amtK = make(map[int][]float64)
	seb.amtTotalDown = make(map[int][]float64)
	seb.amtTotalUp = make(map[int][]float64)
	seb.tradeNumTotal = make(map[int][]float64)
	seb.tradeNumK = make(map[int][]float64)
	seb.tradeNumTotalDown = make(map[int][]float64)
	seb.tradeNumTotalUp = make(map[int][]float64)
	seb.qtyK = make(map[int][]float64)
	seb.amtCumR22 = make(map[int]float64)
	seb.qtyCumR22 = make(map[int]float64)

	seb.openSnap = make(map[int]float64)
	seb.closeSnap = make(map[int]float64)
	seb.amtCumR22LastSnap = make(map[int]float64)
	seb.qtyCumR22LastSnap = make(map[int]float64)

	seb.tempVals = make([]float64, 1)
	seb.tempVals2 = make([]float64, 5)

	for sid := range seb.sidUniverse {
		seb.start[sid] = false

		seb.amtTotal[sid] = make([]float64, 6)
		seb.amtTotalDown[sid] = make([]float64, 6)
		seb.amtTotalUp[sid] = make([]float64, 6)
		seb.amtK[sid] = make([]float64, 6)
		seb.tradeNumTotal[sid] = make([]float64, 6)
		seb.tradeNumTotalDown[sid] = make([]float64, 6)
		seb.tradeNumTotalUp[sid] = make([]float64, 6)
		seb.tradeNumK[sid] = make([]float64, 6)
		seb.qtyK[sid] = make([]float64, 6)
	}
}

//Update
func (seb *T_16) UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int, extraInfo map[int][]float64) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	seb.qtyCumR22[sid] = extraInfo[sid][3]
	seb.amtCumR22[sid] = extraInfo[sid][4]

	for _, psp := range buyObs {
		qty := psp.Qty
		price := psp.Price
		amt := qty * price
		if math.IsNaN(qty) || math.IsInf(qty, 0) {
			continue
		}
		if qty < 0 {
			seb.amtTotal[sid][i2nT16SmallBuy] -= amt
			seb.amtTotal[sid][i2nT16Buy] -= amt
			seb.amtK[sid][i2nT16SmallBuy] -= amt
			seb.amtK[sid][i2nT16Buy] -= amt
			seb.qtyK[sid][i2nT16SmallBuy] -= qty
			seb.qtyK[sid][i2nT16Buy] -= qty
			seb.tradeNumK[sid][i2nT16SmallBuy] += 1.
			seb.tradeNumK[sid][i2nT16Buy] += 1.
			seb.tradeNumTotal[sid][i2nT16SmallBuy] += 1.
			seb.tradeNumTotal[sid][i2nT16Buy] += 1.
		} else {
			seb.amtTotal[sid][i2nT16BigBuy] += amt
			seb.amtTotal[sid][i2nT16Buy] += amt
			seb.amtK[sid][i2nT16BigBuy] += amt
			seb.amtK[sid][i2nT16Buy] += amt
			seb.qtyK[sid][i2nT16BigBuy] += qty
			seb.qtyK[sid][i2nT16Buy] += qty
			seb.tradeNumK[sid][i2nT16BigBuy] += 1.
			seb.tradeNumK[sid][i2nT16Buy] += 1.
			seb.tradeNumTotal[sid][i2nT16BigBuy] += 1.
			seb.tradeNumTotal[sid][i2nT16Buy] += 1.
		}
	}
	for _, psp := range sellObs {
		qty := psp.Qty
		price := psp.Price
		amt := qty * price
		if math.IsNaN(qty) || math.IsInf(qty, 0) {
			continue
		}
		if qty < 0 {
			seb.amtTotal[sid][i2nT16SmallSell] -= amt
			seb.amtTotal[sid][i2nT16Sell] -= amt
			seb.amtK[sid][i2nT16SmallSell] -= amt
			seb.amtK[sid][i2nT16Sell] -= amt
			seb.qtyK[sid][i2nT16SmallSell] -= qty
			seb.qtyK[sid][i2nT16Sell] -= qty
			seb.tradeNumK[sid][i2nT16SmallSell] += 1.
			seb.tradeNumK[sid][i2nT16Sell] += 1.
			seb.tradeNumTotal[sid][i2nT16SmallSell] += 1.
			seb.tradeNumTotal[sid][i2nT16Sell] += 1.
		} else {
			seb.amtTotal[sid][i2nT16BigSell] += amt
			seb.amtTotal[sid][i2nT16Sell] += amt
			seb.amtK[sid][i2nT16BigSell] += amt
			seb.amtK[sid][i2nT16Sell] += amt
			seb.qtyK[sid][i2nT16BigSell] += qty
			seb.qtyK[sid][i2nT16Sell] += qty
			seb.tradeNumK[sid][i2nT16BigSell] += 1.
			seb.tradeNumK[sid][i2nT16Sell] += 1.
			seb.tradeNumTotal[sid][i2nT16BigSell] += 1.
			seb.tradeNumTotal[sid][i2nT16Sell] += 1.
		}
	}

	seb.closeSnap[sid] = E_midPrc(snapData[0], snapData[20])

	if seb.openSnap[sid] < E_EPS {
		seb.openSnap[sid] = E_midPrc(snapData[0], snapData[20])
	}

	seb.start[sid] = true

	return true
}

//GetValues
func (seb *T_16) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else {
		for i := 0; i < 6; i++ {
			if seb.openSnap[sid] < seb.closeSnap[sid] {
				seb.amtTotalUp[sid][i] += seb.amtK[sid][i]
				seb.tradeNumTotalUp[sid][i] += seb.amtK[sid][i]
			} else if seb.openSnap[sid] > seb.closeSnap[sid] {
				seb.amtTotalDown[sid][i] += seb.amtK[sid][i]
				seb.tradeNumTotalDown[sid][i] += seb.tradeNumK[sid][i]
			} else {
			}
		}
		for i := 0; i < 6; i++ {
			seb.ret[i] = DivIgNa(DivIgNa(seb.amtTotalDown[sid][i], seb.tradeNumTotalDown[sid][i]), DivIgNa(seb.amtTotal[sid][i], seb.tradeNumTotal[sid][i]))
		}
		//特征选择的时候，所有大资金（并且包含买卖和）的好像才是最重要的, 下同
		for i := 0; i < 3; i++ {
			seb.ret[6+i] = DivIgNa(DivIgNa(seb.amtTotalDown[sid][2*i]+seb.amtTotalDown[sid][2*i+1], seb.tradeNumTotalDown[sid][2*i]+seb.tradeNumTotalDown[sid][2*i+1]), DivIgNa(seb.amtTotal[sid][2*i]+seb.amtTotal[sid][2*i+1], seb.tradeNumTotal[sid][2*i]+seb.tradeNumTotal[sid][2*i+1]))
		}
		for i := 0; i < 9; i++ {
			seb.ret[i] = ClipIgNa(seb.ret[i], 10.)
		}
		bias := 9
		for i := 0; i < 6; i++ {
			seb.ret[bias+i] = DivIgNa(seb.amtTotalUp[sid][i]-seb.amtTotalDown[sid][i], seb.amtTotal[sid][i])

		}
		for i := 0; i < 3; i++ {
			seb.ret[bias+6+i] = DivIgNa(seb.amtTotalUp[sid][2*i]+seb.amtTotalUp[sid][2*i+1]-seb.amtTotalDown[sid][2*i]-seb.amtTotalDown[sid][2*i+1], seb.amtTotal[sid][2*i]+seb.amtTotal[sid][2*i+1])
		}
		bias = 18

		qtyAvg := DivIgNa(seb.amtK[sid][0]+seb.amtK[sid][1], seb.qtyK[sid][0]+seb.qtyK[sid][1])
		qtyAvgR22 := DivIgNa(seb.amtCumR22[sid]-seb.amtCumR22LastSnap[sid], seb.qtyCumR22[sid]-seb.qtyCumR22LastSnap[sid])
		/*
			if sid == 1 {
				fmt.Println(seb.amtK[sid][0]+seb.amtK[sid][1], seb.qtyK[sid][0]+seb.qtyK[sid][1], seb.amtCumR22[sid]-seb.amtCumR22LastSnap[sid], seb.qtyCumR22[sid]-seb.qtyCumR22LastSnap[sid])
			}
		*/
		ratioLog := seb.closeSnap[sid]/seb.openSnap[sid] - 1.
		if qtyAvg > qtyAvgR22 {
			seb.ret[bias] += ratioLog
		}
		if qtyAvg > qtyAvgR22*1.5 {
			seb.ret[bias+1] += ratioLog
		}
		if qtyAvg > qtyAvgR22*0.5 {
			seb.ret[bias+2] += ratioLog
		}

		bias = 21
		for i := 0; i < 21; i++ {
			seb.tempVals[0] = naInf2Zero(seb.ret[i])
			seb.crossers[i].Update(sid, seb.tempVals)
			seb.crossers[i].GetValue(sid, seb.tempVals2)
			seb.ret[bias] = seb.tempVals2[0]
			seb.ret[bias+1] = seb.tempVals2[1]
			seb.ret[bias+2] = seb.tempVals2[3]
			bias += 3
		}
	}
	for i := 0; i < 6; i++ {
		seb.amtK[sid][i] = 0.
		seb.qtyK[sid][i] = 0.
		seb.tradeNumK[sid][i] = 0.
	}
	seb.openSnap[sid] = 0.
	seb.qtyCumR22LastSnap[sid] = seb.qtyCumR22[sid]
	seb.amtCumR22LastSnap[sid] = seb.amtCumR22[sid]

	return seb.ret, nil
}
