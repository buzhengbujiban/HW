package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
	"sort"
)

/*
var i2nT9 = map[string]int{
	"big":       0,
	"bigSell":   1,
	"bigBuy":    2,
	"small":     3,
	"smallSell": 4,
	"smallBuy":  5,
}
*/

const (
	i2nT9Big       int = 0
	i2nT9BigSell   int = 1
	i2nT9BigBuy    int = 2
	i2nT9Small     int = 3
	i2nT9SmallSell int = 4
	i2nT9SmallBuy  int = 5
)

// 取了E_8部分特征
// 取4个特征
type T_9 struct {
	FeatureBase
	hlList     []float64 //600-1200
	pLen       int
	pow        float64
	pricesSeen map[int][]float64
	emaA       []map[int]map[float64][]*MXEMA
	emaP       []map[int]map[float64][]*MXEMA

	midPriceMap map[int]float64

	qtysA [][]float64
	qtysP [][]float64

	//return
	ret []float64
}

func (seb *T_9) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.pLen = len(seb.hlList)
	seb.pow = seb.prefs.GetFloat64Pref(seb.featureName + "_power")
	return nil
}

//setFeatureNames: set column names.
func (seb *T_9) setFeatureNames() {
	seb.colNames = make([]string, 36*seb.pLen)
	for i := 0; i < seb.pLen; i++ {
		for j := 0; j < 36; j++ {
			seb.colNames[i+j*seb.pLen] = fmt.Sprintf("%s-%d-%ds", seb.featureName, j, int(seb.hlList[i]))
		}
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_9) initInternalVars() {
	seb.FeatureBase.initInternalVars()
	seb.pricesSeen = map[int][]float64{} // slice map 的make和初始化都返回指针， struct make返回指针，初始化返回值
	seb.emaA = make([]map[int]map[float64][]*MXEMA, 6)
	seb.emaP = make([]map[int]map[float64][]*MXEMA, 6)
	for i := 0; i < 6; i++ {
		seb.emaA[i] = make(map[int]map[float64][]*MXEMA)
		seb.emaP[i] = make(map[int]map[float64][]*MXEMA)
	}

	seb.qtysA = make([][]float64, 6)
	seb.qtysP = make([][]float64, 6)
	for i := 0; i < 6; i++ {
		seb.qtysA[i] = make([]float64, 0, 100)
		seb.qtysP[i] = make([]float64, 0, 100)
	}

	seb.midPriceMap = make(map[int]float64)

	for sid := range seb.sidUniverse {
		seb.pricesSeen[sid] = make([]float64, 0, 100) //In most case, cap 100 seen prices would be enough for whole day.
		for i := 0; i < 6; i++ {
			seb.emaA[i][sid] = make(map[float64][]*MXEMA)
			seb.emaP[i][sid] = make(map[float64][]*MXEMA)
		}
	}
}

func (seb *T_9) initializeEMAs(sid int, price float64) {
	if _, ok := seb.emaA[0][sid][price]; !ok {
		seb.pricesSeen[sid] = append(seb.pricesSeen[sid], price)
		for i := 0; i < 6; i++ {
			seb.emaA[i][sid][price] = make([]*MXEMA, seb.pLen)
			seb.emaP[i][sid][price] = make([]*MXEMA, seb.pLen)
		}
		for j, hl := range seb.hlList {
			for i := 0; i < 6; i++ {
				seb.emaA[i][sid][price][j] = NewMXEMA(hl, 3)
				seb.emaP[i][sid][price][j] = NewMXEMA(hl, 3)
			}
		}
	}
}

func (seb *T_9) updateItem(sid int, secSinceEpoch float64, price float64, qty float64, tag string) {
	seb.initializeEMAs(sid, price)
	qtyT := powerTransform(qty, seb.pow)
	for i := 0; i < seb.pLen; i++ {
		if tag == "bigSellA" {
			seb.emaA[i2nT9Big][sid][price][i].Update(secSinceEpoch, -qtyT)
			seb.emaA[i2nT9BigSell][sid][price][i].Update(secSinceEpoch, qtyT)
		} else if tag == "bigBuyA" {
			seb.emaA[i2nT9Big][sid][price][i].Update(secSinceEpoch, qtyT)
			seb.emaA[i2nT9BigBuy][sid][price][i].Update(secSinceEpoch, qtyT)
		} else if tag == "smallSellA" {
			seb.emaA[i2nT9Small][sid][price][i].Update(secSinceEpoch, -qtyT)
			seb.emaA[i2nT9SmallSell][sid][price][i].Update(secSinceEpoch, qtyT)
		} else if tag == "smallBuyA" {
			seb.emaA[i2nT9Small][sid][price][i].Update(secSinceEpoch, qtyT)
			seb.emaA[i2nT9SmallBuy][sid][price][i].Update(secSinceEpoch, qtyT)
		} else if tag == "bigSellP" {
			seb.emaP[i2nT9Big][sid][price][i].Update(secSinceEpoch, -qtyT)
			seb.emaP[i2nT9BigSell][sid][price][i].Update(secSinceEpoch, qtyT)
		} else if tag == "bigBuyP" {
			seb.emaP[i2nT9Big][sid][price][i].Update(secSinceEpoch, qtyT)
			seb.emaP[i2nT9BigBuy][sid][price][i].Update(secSinceEpoch, qtyT)
		} else if tag == "smallSellP" {
			seb.emaP[i2nT9Small][sid][price][i].Update(secSinceEpoch, -qtyT)
			seb.emaP[i2nT9SmallSell][sid][price][i].Update(secSinceEpoch, qtyT)
		} else if tag == "smallBuyP" {
			seb.emaP[i2nT9Small][sid][price][i].Update(secSinceEpoch, qtyT)
			seb.emaP[i2nT9SmallBuy][sid][price][i].Update(secSinceEpoch, qtyT)
		} else {
			panic("invalid tag")
		}
	}
}

//Update
func (seb *T_9) UpdateQuadrupleSecPrcQtySliceSnapGroup(sid int, secSinceEpoch float64, buyObsA []data.PriceQty, sellObsA []data.PriceQty, buyObsP []data.PriceQty, sellObsP []data.PriceQty, snapData []float64, groupData map[int]int) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	amt := 0.

	for _, psp := range buyObsA {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.updateItem(sid, secSinceEpoch, psp.Price, -psp.Qty, "smallBuyA") //p
		} else {
			seb.updateItem(sid, secSinceEpoch, psp.Price, psp.Qty, "bigBuyA") //p
		}
	}
	for _, psp := range sellObsA {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.updateItem(sid, secSinceEpoch, psp.Price, -psp.Qty, "smallSellA") //p
		} else {
			seb.updateItem(sid, secSinceEpoch, psp.Price, psp.Qty, "bigSellA") //p
		}
	}

	for _, psp := range buyObsP {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.updateItem(sid, secSinceEpoch, psp.Price, -psp.Qty, "smallBuyP") //p
		} else {
			seb.updateItem(sid, secSinceEpoch, psp.Price, psp.Qty, "bigBuyP") //p
		}
	}
	for _, psp := range sellObsP {
		amt = psp.Price * psp.Qty
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		if amt < 0 {
			seb.updateItem(sid, secSinceEpoch, psp.Price, -psp.Qty, "smallSellP") //p
		} else {
			seb.updateItem(sid, secSinceEpoch, psp.Price, psp.Qty, "bigSellP") //p
		}
	}

	seb.midPriceMap[sid] = E_midPrc(snapData[0], snapData[20])

	// 遇到相同价格 使用GetImpulseMeanIdx(h, secEpoch)

	return true
}

//GetValues
func (seb *T_9) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}

	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if len(seb.pricesSeen[sid]) == 0 {
		return seb.ret, nil
	} else {
		sort.Float64s(seb.pricesSeen[sid])

		for j := 0; j < seb.pLen; j++ {

			for i := 0; i < 6; i++ {
				seb.qtysA[i] = seb.qtysA[i][:0]
				seb.qtysP[i] = seb.qtysP[i][:0]
			}

			for _, price := range seb.pricesSeen[sid] {
				for i := 0; i < 6; i++ {
					seb.qtysA[i] = append(seb.qtysA[i], seb.emaA[i][sid][price][j].GetEms(secEpoch))
					seb.qtysP[i] = append(seb.qtysP[i], seb.emaP[i][sid][price][j].GetEms(secEpoch))
				}
			}

			priceVolA := make([]float64, 6)
			priceVolP := make([]float64, 6)

			for i := 0; i < 6; i++ {
				if i == 0 || i == 3 {
					priceVolA[i] = MeanVecXOnYIgNa(seb.pricesSeen[sid], E_ArrAbs(seb.qtysA[i]))
					priceVolP[i] = MeanVecXOnYIgNa(seb.pricesSeen[sid], E_ArrAbs(seb.qtysP[i]))
				} else {
					priceVolA[i] = MeanVecXOnYIgNa(seb.pricesSeen[sid], seb.qtysA[i])
					priceVolP[i] = MeanVecXOnYIgNa(seb.pricesSeen[sid], seb.qtysP[i])
				}
				priceVolA[i] = Zero2Na(priceVolA[i]) // 0值在下面的一些计算里，会得到非0值的结果！！！
				priceVolP[i] = Zero2Na(priceVolP[i])
			}

			bigBuySellRatioA := BuySellRatioIgNa(seb.qtysA[i2nT9Big])
			smallBuySellRatioA := BuySellRatioIgNa(seb.qtysA[i2nT9Small])
			bigBuySellRatioP := BuySellRatioIgNa(seb.qtysP[i2nT9Big])
			smallBuySellRatioP := BuySellRatioIgNa(seb.qtysP[i2nT9Small])

			seb.ret[j] = bigBuySellRatioA - smallBuySellRatioA
			seb.ret[j+1*seb.pLen] = bigBuySellRatioA - bigBuySellRatioP
			seb.ret[j+2*seb.pLen] = bigBuySellRatioA - smallBuySellRatioP
			seb.ret[j+3*seb.pLen] = smallBuySellRatioA - bigBuySellRatioP
			seb.ret[j+4*seb.pLen] = smallBuySellRatioA - smallBuySellRatioP
			seb.ret[j+5*seb.pLen] = bigBuySellRatioP - smallBuySellRatioP

			seb.ret[j+6*seb.pLen] = (priceVolA[0] - priceVolA[3]) / seb.midPriceMap[sid]
			seb.ret[j+7*seb.pLen] = (priceVolA[0] - priceVolP[0]) / seb.midPriceMap[sid]
			seb.ret[j+8*seb.pLen] = (priceVolA[0] - priceVolP[3]) / seb.midPriceMap[sid]
			seb.ret[j+9*seb.pLen] = (priceVolA[3] - priceVolP[0]) / seb.midPriceMap[sid]
			seb.ret[j+10*seb.pLen] = (priceVolA[3] - priceVolP[3]) / seb.midPriceMap[sid]
			seb.ret[j+11*seb.pLen] = (priceVolP[0] - priceVolP[3]) / seb.midPriceMap[sid]

			seb.ret[j+12*seb.pLen] = (priceVolA[1] - priceVolA[4]) / seb.midPriceMap[sid]
			seb.ret[j+13*seb.pLen] = (priceVolA[2] - priceVolA[5]) / seb.midPriceMap[sid]
			seb.ret[j+14*seb.pLen] = (priceVolP[1] - priceVolP[4]) / seb.midPriceMap[sid]
			seb.ret[j+15*seb.pLen] = (priceVolP[2] - priceVolP[5]) / seb.midPriceMap[sid]

			bias := 16
			a := []int{1, 2, 4, 5}

			for m := range a {
				for n := range a {
					seb.ret[j+bias*seb.pLen] = (priceVolA[m] - priceVolP[n]) / seb.midPriceMap[sid]
					bias += 1
				}
			}

			seb.ret[j+32*seb.pLen] = (priceVolA[1] + priceVolA[2] - 2*seb.midPriceMap[sid]) / seb.midPriceMap[sid]
			seb.ret[j+33*seb.pLen] = (priceVolA[4] + priceVolA[5] - 2*seb.midPriceMap[sid]) / seb.midPriceMap[sid]
			seb.ret[j+34*seb.pLen] = (priceVolP[1] + priceVolP[2] - 2*seb.midPriceMap[sid]) / seb.midPriceMap[sid]
			seb.ret[j+35*seb.pLen] = (priceVolP[4] + priceVolP[5] - 2*seb.midPriceMap[sid]) / seb.midPriceMap[sid]
		}
	}
	return seb.ret, nil
}
