package feature

import (
	"TES/QR/alpha_ov/data"
	MU "TES/QR/alpha_ov/mathUtils"
	"fmt"
	"math"
)

/*
var i2nT15 = map[string]int{
	"sell":      0,
	"buy":       1,
	"bigSell":   2,
	"bigBuy":    3,
	"smallSell": 4,
	"smallBuy":  5,
}
*/

const (
	i2nT15Sell      int = 0
	i2nT15Buy       int = 1
	i2nT15BigSell   int = 2
	i2nT15BigBuy    int = 3
	i2nT15SmallSell int = 4
	i2nT15SmallBuy  int = 5
)

//HT 56-8

type T_15 struct {
	FeatureBase

	doCross  bool
	crossers []*MU.WeightedNestedGroupMeanFast

	start map[int]bool

	qtyTotal      map[int][]float64
	qtySquareEach map[int][]float64

	tempVals  []float64
	tempVals2 []float64

	tempFlag int

	//return
	ret []float64
}

func (seb *T_15) loadFeaturePrefs() error {
	seb.doCross = seb.prefs.GetBoolPref(seb.featureName + "_do_cross")

	return nil
}

//setFeatureNames: set column names.
func (seb *T_15) setFeatureNames() {
	seb.colNames = make([]string, 12*4)
	for i := 0; i < 12; i++ {
		seb.colNames[i] = fmt.Sprintf("%s-%draw", seb.featureName, i)
	}

	bias := 12
	for i := 0; i < 12; i++ {
		seb.colNames[bias] = fmt.Sprintf("%s-%dm", seb.featureName, i)
		seb.colNames[bias+1] = fmt.Sprintf("%s-%dim", seb.featureName, i)
		seb.colNames[bias+2] = fmt.Sprintf("%s-%dir", seb.featureName, i)
		bias += 3
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_15) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.crossers = make([]*MU.WeightedNestedGroupMeanFast, 12)
	for i := 0; i < 12; i++ {
		seb.crossers[i] = MU.NewWeightedNestedGroupMeanFast(seb.sidUniverseList, 1, seb.baseSidWgts, seb.industryCode, seb.conceptCodes)
	}

	seb.start = make(map[int]bool)

	seb.qtyTotal = make(map[int][]float64)
	seb.qtySquareEach = make(map[int][]float64)

	seb.tempVals = make([]float64, 1)
	seb.tempVals2 = make([]float64, 5)

	for sid := range seb.sidUniverse {
		seb.start[sid] = false

		seb.qtyTotal[sid] = make([]float64, 6)
		seb.qtySquareEach[sid] = make([]float64, 6)
	}
}

//Update
func (seb *T_15) UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}

	for _, psp := range buyObs {
		qty := psp.Qty
		if math.IsNaN(qty) || math.IsInf(qty, 0) {
			continue
		}
		if qty < 0 {
			seb.qtyTotal[sid][i2nT15SmallBuy] -= qty
			seb.qtyTotal[sid][i2nT15Buy] -= qty
			seb.qtySquareEach[sid][i2nT15SmallBuy] += qty * qty
			seb.qtySquareEach[sid][i2nT15Buy] += qty * qty
		} else {
			seb.qtyTotal[sid][i2nT15BigBuy] += qty
			seb.qtyTotal[sid][i2nT15Buy] += qty
			seb.qtySquareEach[sid][i2nT15BigBuy] += qty * qty
			seb.qtySquareEach[sid][i2nT15Buy] += qty * qty
		}
	}
	for _, psp := range sellObs {
		qty := psp.Qty
		if math.IsNaN(qty) || math.IsInf(qty, 0) {
			continue
		}
		if qty < 0 {
			seb.qtyTotal[sid][i2nT15SmallSell] -= qty
			seb.qtyTotal[sid][i2nT15Sell] -= qty
			seb.qtySquareEach[sid][i2nT15SmallSell] += qty * qty
			seb.qtySquareEach[sid][i2nT15Sell] += qty * qty
		} else {
			seb.qtyTotal[sid][i2nT15BigSell] += qty
			seb.qtyTotal[sid][i2nT15Sell] += qty
			seb.qtySquareEach[sid][i2nT15BigSell] += qty * qty
			seb.qtySquareEach[sid][i2nT15Sell] += qty * qty
		}
	}

	/*
		if snapDataLast == nil {
			return true
		}
	*/

	seb.start[sid] = true

	seb.tempFlag = 0

	return true
}

//GetValues
func (seb *T_15) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else {
		for i := 0; i < 6; i++ {
			seb.ret[i] = DivIgNa(seb.qtySquareEach[sid][i], seb.qtyTotal[sid][i]*seb.qtyTotal[sid][i])
			/*
				if math.Abs(seb.qtyTotal[sid][i]) <= E_EPS && seb.tempFlag == 0 {
					fmt.Println(sid, seb.qtyTotal[sid][i], seb.ret[i])
					seb.tempFlag = 1
				}
			*/
		}
		/*
			if sid == 1 {
				fmt.Println(seb.ret[0:6])
			}
		*/

		seb.ret[6] = seb.ret[0] - seb.ret[1]
		seb.ret[7] = seb.ret[2] - seb.ret[3]
		seb.ret[8] = seb.ret[4] - seb.ret[5]
		seb.ret[9] = seb.ret[0] + seb.ret[1]
		seb.ret[10] = seb.ret[2] + seb.ret[3]
		seb.ret[11] = seb.ret[4] + seb.ret[5]

		bias := 12
		for i := 0; i < 12; i++ {
			seb.tempVals[0] = naInf2Zero(seb.ret[i])

			seb.crossers[i].Update(sid, seb.tempVals)
			seb.crossers[i].GetValue(sid, seb.tempVals2)
			seb.ret[bias] = seb.tempVals2[0]
			seb.ret[bias+1] = seb.tempVals2[1]
			seb.ret[bias+2] = seb.tempVals2[3]
			bias += 3
			/*
				if sid == 1 {
					fmt.Println(i, bias, seb.tempVals, seb.tempVals2)
				}
			*/
		}
	}
	return seb.ret, nil
}
