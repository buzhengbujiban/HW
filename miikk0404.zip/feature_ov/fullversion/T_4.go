package feature

import (
	"TES/QR/alpha_ov/data"
	"fmt"
	"math"
)

const ticksizeT4 = 0.01

// price 这里被除以0.01强制转化为int， snap或者trade数据里的 股票挂单价，成交价 ， 一定是事先被处理成0.01的精度吗，可能会有10.01001这种

// 选4个特征
type T_4 struct {
	FeatureBase
	hlList     []float64 //1200-2400
	pLen       int
	pow        float64
	pricesSeen map[int][]int
	emaData    map[int]map[int][]*MXEMA
	emaDataP   map[int]map[int][]*MXEMA
	emaDataQ50 map[int]map[int][]*MXEMA

	pricesSeenDeal map[int][]int
	emaDataDeal    map[int]map[int][]*MXEMA
	tag            string //bid ask

	sizeList []int                   //1min-3min
	cQtyBuf  map[int][]*floatRingBuf //至少长度100

	cumTo     map[int]float64
	cumToLast map[int]float64
	amtActive map[int]float64

	//return
	ret []float64
}

func (seb *T_4) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.pLen = len(seb.hlList)
	seb.pow = seb.prefs.GetFloat64Pref(seb.featureName + "_power")
	seb.tag = seb.prefs.GetStringPref(seb.featureName + "_tag")
	seb.sizeList = seb.prefs.GetIntListPref(seb.featureName + "_sizeList")

	return nil
}

//setFeatureNames: set column names.
func (seb *T_4) setFeatureNames() {
	seb.colNames = make([]string, 6*seb.pLen)
	for i := 0; i < seb.pLen; i++ {
		seb.colNames[i] = fmt.Sprintf("%s-%s-can%ds", seb.featureName, seb.tag, int(seb.hlList[i]))
		seb.colNames[i+1*seb.pLen] = fmt.Sprintf("%s-%s-canP%ds", seb.featureName, seb.tag, int(seb.hlList[i]))
		seb.colNames[i+2*seb.pLen] = fmt.Sprintf("%s-%s-canMid%ds", seb.featureName, seb.tag, int(seb.hlList[i]))
		seb.colNames[i+3*seb.pLen] = fmt.Sprintf("%s-%s-tstats%ds", seb.featureName, seb.tag, int(seb.hlList[i]))
		seb.colNames[i+4*seb.pLen] = fmt.Sprintf("%s-%s-dev%ds", seb.featureName, seb.tag, int(seb.hlList[i]))
		seb.colNames[i+5*seb.pLen] = fmt.Sprintf("%s-%s-BS%ds", seb.featureName, seb.tag, int(seb.hlList[i]))
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

//initialize internal variables'
func (seb *T_4) initInternalVars() {
	seb.FeatureBase.initInternalVars()
	seb.pricesSeen = map[int][]int{}
	seb.pricesSeenDeal = map[int][]int{}
	seb.emaData = make(map[int]map[int][]*MXEMA)
	seb.emaDataP = make(map[int]map[int][]*MXEMA)
	seb.emaDataQ50 = make(map[int]map[int][]*MXEMA)
	seb.emaDataDeal = make(map[int]map[int][]*MXEMA)
	seb.cQtyBuf = make(map[int][]*floatRingBuf)
	seb.cumTo = make(map[int]float64)
	seb.cumToLast = make(map[int]float64)
	seb.amtActive = make(map[int]float64)
	for sid := range seb.sidUniverse {
		seb.pricesSeen[sid] = make([]int, 0, 100)
		seb.emaData[sid] = make(map[int][]*MXEMA)
		seb.emaDataP[sid] = make(map[int][]*MXEMA)
		seb.emaDataQ50[sid] = make(map[int][]*MXEMA)
		seb.emaDataDeal[sid] = make(map[int][]*MXEMA)
		seb.pricesSeenDeal[sid] = make([]int, 0, 100)
		seb.cQtyBuf[sid] = make([]*floatRingBuf, seb.pLen)
		seb.cumTo[sid] = 0.
		seb.cumToLast[sid] = 0.
		seb.amtActive[sid] = 0.
		for i := 0; i < seb.pLen; i++ {
			seb.cQtyBuf[sid][i] = newFloatRingBuf(seb.sizeList[i])
		}
	}
}

func (seb *T_4) initializeEMAs(sid int, price int) {
	if _, ok := seb.emaData[sid][price]; !ok {
		seb.pricesSeen[sid] = append(seb.pricesSeen[sid], price)
		seb.emaData[sid][price] = make([]*MXEMA, seb.pLen)
		seb.emaDataP[sid][price] = make([]*MXEMA, seb.pLen)
		seb.emaDataQ50[sid][price] = make([]*MXEMA, seb.pLen)
		for i, hl := range seb.hlList {
			seb.emaData[sid][price][i] = NewMXEMA(hl, 3)
			seb.emaDataP[sid][price][i] = NewMXEMA(hl, 3)
			seb.emaDataQ50[sid][price][i] = NewMXEMA(hl, 3)
		}
	}
}

func (seb *T_4) initializeEMAsDeal(sid int, price int) {
	if _, ok := seb.emaDataDeal[sid][price]; !ok {
		seb.pricesSeenDeal[sid] = append(seb.pricesSeenDeal[sid], price)
		seb.emaDataDeal[sid][price] = make([]*MXEMA, seb.pLen)
		for i, hl := range seb.hlList {
			seb.emaDataDeal[sid][price][i] = NewMXEMA(hl, 3)
		}
	}
}

//Update
func (seb *T_4) UpdateSecPrcQtySliceDoubleSnap(sid int, secSinceEpoch float64, newObs []data.PriceQty, snapData []float64, snapDataLast []float64) bool { // activeBuy-ask或者activeSell-bid, spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}

	if snapDataLast == nil {
		return true
	}

	var bias int
	if seb.tag == "ask" {
		bias = 0

	} else if seb.tag == "bid" {
		bias = 20
	} else {
		panic("tag error for T_4 only ask or bid is valid")
	}

	priceQtyMap := make(map[int]float64)
	priceQtyMapLast := make(map[int]float64)
	pmap := 0
	for i := 0; i < 10; i++ {
		pmap = RoundAsInt(snapData[2*i+bias], ticksizeT4)
		priceQtyMap[pmap] = snapData[2*i+1+bias]
	}
	for i := 0; i < 10; i++ { // 20220816 2改为10
		pmap = RoundAsInt(snapDataLast[2*i+bias], ticksizeT4)
		if _, ok := priceQtyMap[pmap]; !ok { // 确保priceQtyMapLast的价格一定能在priceQtyMap找到
			continue
		}
		priceQtyMapLast[pmap] = snapDataLast[2*i+1+bias]
	}

	addQtyInfer := 0.
	cancelQty := 0. //粗浅近似
	amt := 0.

	for _, psp := range newObs {
		amt = math.Abs(psp.Price * psp.Qty)
		if math.IsNaN(amt) || math.IsInf(amt, 0) {
			continue
		}
		seb.amtActive[sid] += amt

		pmap = RoundAsInt(psp.Price, ticksizeT4)

		seb.initializeEMAsDeal(sid, pmap)
		for i := 0; i < seb.pLen; i++ {
			seb.emaDataDeal[sid][pmap][i].Update(secSinceEpoch, powerTransform(math.Abs(psp.Qty), seb.pow))
		}

		if _, ok := priceQtyMapLast[pmap]; !ok {
			continue
		}

		seb.initializeEMAs(sid, pmap)
		cancelQty = priceQtyMapLast[pmap] - priceQtyMap[pmap] - psp.Qty + addQtyInfer
		cancelQty = powerTransform(cancelQty, seb.pow)
		for i := 0; i < seb.pLen; i++ {
			seb.emaData[sid][pmap][i].Update(secSinceEpoch, cancelQty) // 同样的价格相同时间多次update，Ema有问题Ems没有问题
			if cancelQty > 0 {
				seb.emaDataP[sid][pmap][i].Update(secSinceEpoch, cancelQty)
			}
			seb.cQtyBuf[sid][i].push(cancelQty) //具有很强的随机性
			if cancelQty > seb.cQtyBuf[sid][i].mean() {
				seb.emaDataQ50[sid][pmap][i].Update(secSinceEpoch, cancelQty)
			}
		}
	}

	seb.cumTo[sid] = snapData[42]

	return true
}

//GetValues
func (seb *T_4) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	if _, ok := seb.sidUniverse[sid]; !ok {
		for i := 0; i < len(seb.ret); i++ {
			seb.ret[i] = 0
		}
		return seb.ret, nil
	} else {
		pmap := RoundAsInt(mPrice, ticksizeT4)
		a := 0.
		b := 0.
		qtys := make([]float64, len(seb.pricesSeen[sid]))
		prices := make([]float64, len(seb.pricesSeen[sid]))
		if _, ok1 := seb.emaDataDeal[sid][pmap]; ok1 {
			if _, ok2 := seb.emaData[sid][pmap]; ok2 {
				for i := 0; i < seb.pLen; i++ {
					a = seb.emaDataDeal[sid][pmap][i].GetEms(secEpoch)
					b = seb.emaData[sid][pmap][i].GetEms(secEpoch)
					seb.ret[i] = ClipIgNa(powerTransform(DivIgNa(b, a), seb.pow), 3.0)

					b = seb.emaDataP[sid][pmap][i].GetEms(secEpoch)
					seb.ret[i+seb.pLen] = ClipIgNa(powerTransform(DivIgNa(b, a), seb.pow), 3.0)

					b = seb.emaDataQ50[sid][pmap][i].GetEms(secEpoch)
					seb.ret[i+2*seb.pLen] = ClipIgNa(powerTransform(DivIgNa(b, a), seb.pow), 3.0)
				}
			}
		}

		r := math.Min(1, seb.amtActive[sid]/(seb.cumTo[sid]-seb.cumToLast[sid]))
		seb.amtActive[sid] = 0.
		seb.cumToLast[sid] = seb.cumTo[sid]
		for i := 0; i < seb.pLen; i++ {
			for j, price := range seb.pricesSeen[sid] {
				qtys[j] = seb.emaDataP[sid][price][i].GetEms(secEpoch)
				prices[j] = float64(price) * ticksizeT4
			}

			seb.ret[i+3*seb.pLen] = CalcTstatIgNa(prices, qtys, mPrice)
			if seb.ret[i+3*seb.pLen] > 5. {
				seb.ret[i+3*seb.pLen] = 5.
			}
			if seb.ret[i+3*seb.pLen] < -5. {
				seb.ret[i+3*seb.pLen] = -5.
			}
			seb.ret[i+4*seb.pLen] = CalcDevIgNa(prices, qtys, mPrice)
			seb.ret[i+5*seb.pLen] = r * seb.ret[i+1*seb.pLen]
		}
	}
	return seb.ret, nil
}
