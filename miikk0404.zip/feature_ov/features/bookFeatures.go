/*
 * ported from book_features_p2.py by Han and Yingfa
 * author: Yingfa;
 * author: yzhu; BollingerBand, Chartist
 * date: 201805
 */

package feature

import (
	"errors"
	"fmt"
	"math"
	"sort"
	"strconv"
	"time"

	"TES/QR/alpha_ov/data"
	MU "TES/QR/alpha_ov/mathUtils"
	tu "TES/tesUtilsGo"
	"TES/tesUtilsGo/common"
)

func sign(x float64) float64 {
	if x > 0 {
		return 1.0
	} else if x < 0 {
		return -1.0
	} else {
		return 0.0
	}
}

func powerTransform(x float64, pow float64) float64 {
	return MU.SignOfFloat(x) * math.Pow(math.Abs(x), pow)
}

func trueRange(high, low, prevClose float64) float64 {
	return math.Max(high-low, math.Max(math.Abs(high-prevClose),
		math.Abs(low-prevClose)))
}

type PriceQty struct {
	price float64
	qty   float64
}

// BollingerBand is a rewrite of BollingerBand in Python code
type BollingerBand struct {
	FeatureBase

	halfLives []int
	bandBound float64
	mas       map[int]*MU.MA
	lastPrice map[int]float64
	fvalues   []float64
}

func (b *BollingerBand) loadFeaturePrefs() error {
	b.halfLives = b.prefs.GetIntListPref(b.featureName + "_hl_list")
	b.bandBound = b.prefs.GetFloat64Pref(b.featureName + "_band_bound")
	//fmt.Printf("halfLives=%v bandBound=%v\n", b.halfLives, b.bandBound)
	return nil
}

func (b *BollingerBand) setFeatureNames() {
	b.colNames = make([]string, len(b.halfLives))
	for i, hl := range b.halfLives {
		b.colNames[i] = fmt.Sprintf("%s-t%ds", b.featureName, hl)
	}
}

func (b *BollingerBand) UpdateValue(sid int, price float64) bool {
	if _, ok := b.sidUniverse[sid]; !ok || price == 0 || math.IsNaN(price) {
		return false
	}
	b.mas[sid].Add(price)
	b.lastPrice[sid] = price

	return true
}

func (b *BollingerBand) initInternalVars() {
	b.mas = make(map[int]*MU.MA)
	b.lastPrice = make(map[int]float64)
	for sid := range b.sidUniverse {
		b.mas[sid] = MU.NewMA(b.halfLives)
		b.lastPrice[sid] = 0
	}

	b.fvalues = make([]float64, len(b.halfLives))
}

func (b *BollingerBand) GetValues(midPrice, secSinceEpoch float64) ([]float64, error) {
	ma := b.mas[b.baseSid]
	last := b.lastPrice[b.baseSid]

	for i := 0; i < len(b.halfLives); i++ {
		v := ma.GetVarianceIdx(i)
		if v <= 0 {
			v = 1e8
		} else {
			v = math.Sqrt(v)
		}

		x := (last - ma.GetMeanIdx(i)) / v
		b.fvalues[i] = MU.Bound(x, -b.bandBound, b.bandBound)
	}
	return b.fvalues, nil
}

type ChartistSubClass int

const (
	ChartistSingle ChartistSubClass = iota + 1
	ChartistGroup
	ChartistChinaEquity
)

// Chartist: indicators based on elevator.
type Chartist struct {
	FeatureBase

	SubClass ChartistSubClass

	dailyRoot string

	//prefs
	numSections       int
	useSmoothedPrice  bool
	kernelWidth       float64
	smoothOrder       int
	elevatorThreshold float64
	printTOD          bool

	//internal temp vars
	emptyVector MU.Vector

	secMorning float64
	res        []float64
	//to support poor man's dynamic dispatch
	elev       map[int]*Elevator
	elevSmooth map[int]*SmoothElevator
}

func (c *Chartist) loadFeaturePrefs() error {
	c.numSections = c.prefs.GetIntPref(c.featureName + "_num_sections")
	c.useSmoothedPrice = c.prefs.GetBoolPref(c.featureName + "_use_smoothed_price")
	if c.useSmoothedPrice {
		c.kernelWidth = c.prefs.GetFloat64Pref(c.featureName + "_kernel_width")
		c.smoothOrder = c.prefs.GetIntPref(c.featureName + "_smoother_order")
	}
	c.elevatorThreshold = c.prefs.GetFloat64Pref(c.featureName + "_elevator_threshold")
	if c.prefs.HasPref(c.featureName + "_print_TOD") {
		c.printTOD = c.prefs.GetBoolPref(c.featureName + "_print_TOD")
	} else {
		c.printTOD = true
	}

	c.dailyRoot = c.prefs.GetStringPref("daily_root")

	return nil
}

func (c *Chartist) setFeatureNames() {
	if c.printTOD {
		c.colNames = []string{c.featureName + "-TOD"}
	} else {
		c.colNames = []string{}
	}
	c.colNames = append(c.colNames, c.featureName+"-max_ret", c.featureName+"-trend_prob")
	for h := 0; h < c.numSections; h++ {
		c.colNames = append(c.colNames, fmt.Sprintf("%s-ret-s%d", c.featureName, h))
	}
	for h := 0; h < c.numSections; h++ {
		c.colNames = append(c.colNames, fmt.Sprintf("%s-time-s%d", c.featureName, h))
	}
}

func (c *Chartist) UpdateSecValue(sid int, secSinceEpoch float64, midPrice float64) bool {
	if _, ok := c.sidUniverse[sid]; !ok {
		return false
	}
	if c.useSmoothedPrice {
		c.elevSmooth[sid].Update(secSinceEpoch-c.secMorning, math.Log(midPrice), c.emptyVector)
	} else {
		c.elev[sid].Update(secSinceEpoch-c.secMorning, math.Log(midPrice), c.emptyVector)
	}
	return true
}

func (c *Chartist) initInternalVars() {
	c.FeatureBase.initInternalVars()

	threshold := make(map[int]float64)
	if c.SubClass == ChartistGroup {
		// TODO: factor out load daily stats in all features code
		prevDate := common.PreTradeDate(c.dateStr)
		dateStart, _ := common.Get2MonthsEarlier(c.dateStr)
		fullList := append(c.basisList, c.baseSid) // fullList = c.sidUniverse
		dailyData, _, err := data.LoadDailyDataMedian(dateStart, prevDate, []string{"high"}, fullList, c.dailyRoot)
		if err != nil {
			tu.Logger.Warn(err.Error())
		}
		sidValueMap := dailyData["high"]

		for sid := range c.sidUniverse {
			if values, ok := sidValueMap[sid]; ok {
				medianHigh := values[len(values)-1]
				tickSize := common.SecMasterMap[sid].TickSize
				threshold[sid] = tickSize / medianHigh
			} else {
				// if no "high" price stats for this fmid (i.e. the fmid has no volume for a long time)
				// we set a maximum threshold for Chartist to yield no zig-zag patterns
				tu.Logger.Error(fmt.Sprintf("Feature %s initInternalVars: No high price stats for %d", c.featureName, sid))
				threshold[sid] = 1.0
			}
		}

	} else {
		// All names with the same threshold
		for sid := range c.sidUniverse {
			threshold[sid] = c.elevatorThreshold
		}

		// TODO: need to refactor for Eq
		if c.SubClass == ChartistChinaEquity {
			prevdate := common.PreTradeDate(c.dateStr)
			/*
				mktStats := &data.DailyMktStats{}
				window := 22
				fullList := append(c.basisList, c.baseSid) // fullList = c.sidUniverse
				res, _ := mktStats.MedianOfOneStat("/data/chinaEquityData/daily", prevdate, window, fullList, "high", true)

				for i, highPrice := range res {
					sid := fullList[i]
					if highPrice > 0 {
						tickSize := common.SecMasterMap[sid].TickSize
						threshold[sid] = tickSize / highPrice
					} else {
						threshold[sid] = 0.005
					}
				}
			*/

			sid2high := data.GetSidValueMapFromPanelData("daily-rollstats", prevdate, "00:00:00", "high.rw22")
			sid2high = data.ConformSidValueMap(sid2high, c.sidUniverseList, 0.0)

			/*
				// do rec
				for i, highPrice := range res {
					sid := fullList[i]
					if math.Abs(sid2high[sid] - highPrice) > 1e-2 {
						panic(fmt.Sprintf("high price does not match csv=%.3f sdiv=%.3f", highPrice, sid2high[sid]))
					} else {
						fmt.Printf("sid=%d csv=%.3f sdiv=%.3f\n", sid, highPrice, sid2high[sid])
					}
				}
			*/

			for sid, highPrice := range sid2high {
				if highPrice > 0 {
					tickSize := common.SecMasterMap[sid].TickSize
					threshold[sid] = tickSize / highPrice
				} else {
					threshold[sid] = 0.005
				}
			}
		}
	}

	if c.useSmoothedPrice {
		c.elevSmooth = make(map[int]*SmoothElevator)
		for sid := range c.sidUniverse {
			c.elevSmooth[sid] = &SmoothElevator{}
			c.elevSmooth[sid].Init(
				c.numSections,
				threshold[sid],
				0,
				c.kernelWidth,
				"epanechnikov",
				c.smoothOrder,
			)
		}
	} else {
		c.elev = make(map[int]*Elevator)
		for sid := range c.sidUniverse {
			c.elev[sid] = &Elevator{}
			c.elev[sid].Init(
				c.numSections,
				threshold[sid],
				0,
			)
		}
	}

	switch c.SubClass {
	case ChartistGroup, ChartistSingle:
		c.secMorning = common.GetBeginTimestampOfDay(c.dateStr)
	case ChartistChinaEquity:
		date2MinuteStr := fmt.Sprintf("%s0900", c.dateStr)
		t, _ := time.ParseInLocation("200601021504", date2MinuteStr, time.UTC)
		c.secMorning = float64(t.Unix())
	}

	if c.printTOD {
		c.res = make([]float64, 3+c.numSections*2)
	} else {
		c.res = make([]float64, 2+c.numSections*2)
	}
}

func (c *Chartist) GetValues(midPrice, secSinceEpoch float64) ([]float64, error) {
	return c.GetSidValues(c.baseSid, midPrice, secSinceEpoch)
}

func (c *Chartist) GetSidValues(sid int, midPrice, secSinceEpoch float64) ([]float64, error) {
	var sct []*IdxSecPrice
	if c.useSmoothedPrice {
		sct = c.elevSmooth[sid].GetSections(0)
	} else {
		sct = c.elev[sid].GetSections(0)
	}
	if len(sct)-1 > c.numSections {
		msg := fmt.Sprintf("assert len(sct) - 1 <= c.numSections; len(sct)=%d, numSections=%d", len(sct), c.numSections)
		panic(msg)
	}

	TOD := (secSinceEpoch - c.secMorning) / 3600
	if len(sct) >= 2 {
		maxRet := math.Abs(sct[1].Price - sct[0].Price)
		for i := 2; i < len(sct); i++ {
			ret := math.Abs(sct[i].Price - sct[i-1].Price)
			if maxRet < ret {
				maxRet = ret
			}
		}
		trendProb := 0.0
		if c.useSmoothedPrice {
			trendProb = c.elevSmooth[sid].trend_prob
		} else {
			trendProb = c.elev[sid].trend_prob
		}
		var nextIdx int
		if c.printTOD {
			c.res[0] = TOD
			c.res[1] = maxRet
			c.res[2] = trendProb
			nextIdx = 3
		} else {
			c.res[0] = maxRet
			c.res[1] = trendProb
			nextIdx = 2
		}
		//#add ret
		for i := 1; i < len(sct); i++ {
			c.res[nextIdx] = sct[0].Price - sct[i].Price
			nextIdx++
		}
		//#pad with last
		if len(sct)-1 < c.numSections {
			padValue := c.res[nextIdx-1]
			for i := 0; i < (c.numSections - len(sct) + 1); i++ {
				c.res[nextIdx] = padValue
				nextIdx++
			}
		}
		//#add time
		for i := 1; i < len(sct); i++ {
			c.res[nextIdx] = sct[0].SecEpoch - sct[i].SecEpoch
			nextIdx++
		}
		//#pad with last
		if len(sct)-1 < c.numSections {
			padValue := c.res[nextIdx-1]
			for i := 0; i < (c.numSections - len(sct) + 1); i++ {
				c.res[nextIdx] = padValue
				nextIdx++
			}
		}
	} else {
		for i := 0; i < len(c.res); i++ {
			c.res[i] = 0.0
		}
		if c.printTOD {
			c.res[0] = TOD
		}
	}

	return c.res, nil
}

func (c *Chartist) GetSmoothedPriceDeque(sid int) []SecPrice {
	if c.useSmoothedPrice {
		return c.elevSmooth[sid].smooth_price_deque
	} else {
		panic("Chartist is configured as non-smooth; now you want to get smooth_price_deque!")
	}
}

func (c *Chartist) ExtremaIsMax(sid int) bool {
	if c.useSmoothedPrice {
		return c.elevSmooth[sid].extrema_is_max
	} else {
		panic("Chartist is configured as non-smooth; now you want to get smooth_price_deque!")
	}
}

//////////// Yang  -->

//BollingerBandEMA indicators based on Bollinger Band (EMA version).
type BollingerBandEMA struct {
	FeatureBase

	hlList    []int
	hlLen     int
	bandBound float64
	colNames  []string
	lastPrice map[int]float64
	dataEma   map[int]*MU.EMA

	//ret assigned
	ret []float64
}

func (bbe *BollingerBandEMA) loadFeaturePrefs() error {
	bbe.hlList = bbe.prefs.GetIntListPref(bbe.featureName + "_hl_list")
	bbe.hlLen = len(bbe.hlList)
	bbe.bandBound = bbe.prefs.GetFloat64Pref(bbe.featureName + "_band_bound")
	return nil
}

func (bbe *BollingerBandEMA) setFeatureNames() {
	bbe.colNames = make([]string, len(bbe.hlList))
	for i, hl := range bbe.hlList {
		bbe.colNames[i] = fmt.Sprintf("%s-t%ds", bbe.featureName, hl)
	}
	// assign ret memory
	bbe.ret = make([]float64, len(bbe.colNames))
}

func (bbe *BollingerBandEMA) initInternalVars() {
	bbe.dataEma = map[int]*MU.EMA{}
	bbe.lastPrice = map[int]float64{}
	for sid := range bbe.sidUniverse {
		bbe.dataEma[sid] = MU.NewEMA(bbe.hlList)
		bbe.lastPrice[sid] = 0
	}

}

func (bbe *BollingerBandEMA) UpdateSecValue(sid int, secEpoch, price float64) bool {
	if _, ok := bbe.sidUniverse[sid]; !ok || price == 0 || math.IsNaN(price) {
		return false
	}
	bbe.dataEma[sid].Add(price, secEpoch)
	bbe.lastPrice[sid] = price
	return true
}

func (bbe *BollingerBandEMA) GetValues(midPrice, secSinceEpoch float64) ([]float64, error) {
	if lastPrice, ok := bbe.lastPrice[bbe.baseSid]; !ok || lastPrice == 0 {
		return nil, errors.New("No last price existed. sid:" + strconv.Itoa(bbe.baseSid))
	}
	for i := 0; i < bbe.hlLen; i++ {
		tmp := bbe.dataEma[bbe.baseSid].GetVarianceIdx(i)
		if tmp <= 0 {
			tmp = 1e8
		} else {
			tmp = math.Sqrt(tmp)
		}

		bbe.ret[i] = (bbe.lastPrice[bbe.baseSid] - bbe.dataEma[bbe.baseSid].GetMeanIdx(i)) / tmp
	}

	return bbe.ret, nil
}

/* SignedEMABookV2
indicators based on signed EMA book.
    EMA is taken on quote size.
    Size is signed with normal convention.
*/
type SignedEMABookV2 struct {
	FeatureBase
	hlList     []int
	hlLen      int
	pow        float64
	pricesSeen map[int][]float64
	dataEMA    map[int]map[float64]*MU.EMA

	//return
	ret []float64
}

func (seb *SignedEMABookV2) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetIntListPref(seb.featureName + "_hl_list")
	seb.hlLen = len(seb.hlList)
	seb.pow = seb.prefs.GetFloat64Pref(seb.featureName + "_power")
	return nil
}

//setFeatureNames: set column names.
func (seb *SignedEMABookV2) setFeatureNames() {
	seb.colNames = make([]string, 4*seb.hlLen)
	for i := 0; i < seb.hlLen; i++ {
		seb.colNames[i] = fmt.Sprintf("%s-bsr%ds", seb.featureName, seb.hlList[i])
		seb.colNames[i+seb.hlLen] = fmt.Sprintf("%s-bss%ds", seb.featureName, seb.hlList[i])
		seb.colNames[i+2*seb.hlLen] = fmt.Sprintf("%s-t%ds", seb.featureName, seb.hlList[i])
		seb.colNames[i+3*seb.hlLen] = fmt.Sprintf("%s-dev%ds", seb.featureName, seb.hlList[i])
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
}

//initialize internal variables'
func (seb *SignedEMABookV2) initInternalVars() {
	seb.FeatureBase.initInternalVars()
	seb.pricesSeen = map[int][]float64{}
	seb.dataEMA = map[int]map[float64]*MU.EMA{}
	for sid := range seb.sidUniverse {
		seb.pricesSeen[sid] = make([]float64, 0, 100) //In most case, cap 100 seen prices would be enough for whole day.
		seb.dataEMA[sid] = map[float64]*MU.EMA{}
	}
}

func (seb *SignedEMABookV2) initializeEMAs(sid int, price float64) {
	if _, ok := seb.dataEMA[sid][price]; !ok {
		seb.pricesSeen[sid] = append(seb.pricesSeen[sid], price)
		seb.dataEMA[sid][price] = MU.NewEMA(seb.hlList)
	}
}

//Update
func (seb *SignedEMABookV2) UpdateSecPrcQtySlice(sid int, secSinceEpoch float64, newObs []data.PriceQty) bool {
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}
	for _, psp := range newObs {
		pmap := psp.Price
		seb.initializeEMAs(sid, pmap)
		seb.dataEMA[sid][pmap].Add(powerTransform(psp.Qty, seb.pow), secSinceEpoch)
	}
	return true
}

//GetValues
func (seb *SignedEMABookV2) GetValues(mPrice, secEpoch float64) ([]float64, error) {

	if len(seb.dataEMA[seb.baseSid]) == 0 {
		for i := 0; i < seb.hlLen; i++ {
			seb.ret[i] = 0
		}
		return seb.ret, nil
	}
	//if len(seb.dataEMA[seb.baseSid]) != seb.hlLen {
	//	err := errors.New("Hllen not equals with EMS's keys length. ")
	//	return nil, err
	//}
	err := bfEMAMean4Func(seb.pricesSeen[seb.baseSid], seb.dataEMA[seb.baseSid], mPrice, seb.hlLen, seb.ret)
	return seb.ret, err
}

// back-compatible class
type SignedEMABook struct {
	SignedEMABookV2
	ret1 []float64 // result feature vector, excluding -bss values
}

//setFeatureNames: set column names.
func (seb *SignedEMABook) setFeatureNames() {
	seb.colNames = make([]string, 3*seb.hlLen)
	for i := 0; i < seb.hlLen; i++ {
		seb.colNames[i] = fmt.Sprintf("%s-bsr%ds", seb.featureName, seb.hlList[i])
		seb.colNames[i+1*seb.hlLen] = fmt.Sprintf("%s-t%ds", seb.featureName, seb.hlList[i])
		seb.colNames[i+2*seb.hlLen] = fmt.Sprintf("%s-dev%ds", seb.featureName, seb.hlList[i])
	}
	// assign ret memory
	seb.SignedEMABookV2.ret = make([]float64, len(seb.colNames)+seb.hlLen)
	seb.ret1 = make([]float64, len(seb.colNames))
}

func (seb *SignedEMABook) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	ret, _ := seb.SignedEMABookV2.GetValues(mPrice, secEpoch)
	for i := 0; i < len(seb.ret1); i++ {
		if i < seb.hlLen {
			seb.ret1[i] = ret[i]
		} else {
			seb.ret1[i] = ret[i+seb.hlLen]
		}
	}
	return seb.ret1, nil
}

//class LastSeenBookV2(FeatureBase)
/* indicators based on detrended last seen book */
type LastSeenBookV2 struct {
	FeatureBase
	hlList     []int
	hlLen      int
	pow        float64
	pricesSeen map[int][]float64
	dataEMA    map[int]map[float64]*MU.EMA

	//return
	ret []float64
}

func (lsb *LastSeenBookV2) loadFeaturePrefs() error {
	lsb.hlList = lsb.prefs.GetIntListPref(lsb.featureName + "_hl_list")
	lsb.hlLen = len(lsb.hlList)
	lsb.pow = lsb.prefs.GetFloat64Pref(lsb.featureName + "_power")
	return nil
}

//setFeatureNames: set column names.
func (lsb *LastSeenBookV2) setFeatureNames() {
	lsb.colNames = make([]string, 4*lsb.hlLen)
	for i := 0; i < lsb.hlLen; i++ {
		lsb.colNames[i] = fmt.Sprintf("%s-bsr%ds", lsb.featureName, lsb.hlList[i])
		lsb.colNames[i+lsb.hlLen] = fmt.Sprintf("%s-bss%ds", lsb.featureName, lsb.hlList[i])
		lsb.colNames[i+2*lsb.hlLen] = fmt.Sprintf("%s-t%ds", lsb.featureName, lsb.hlList[i])
		lsb.colNames[i+3*lsb.hlLen] = fmt.Sprintf("%s-dev%ds", lsb.featureName, lsb.hlList[i])
	}
	// assign ret memory
	lsb.ret = make([]float64, len(lsb.colNames))
}

//initialize internal variables'
func (lsb *LastSeenBookV2) initInternalVars() {
	lsb.FeatureBase.initInternalVars()
	lsb.pricesSeen = map[int][]float64{}
	lsb.dataEMA = map[int]map[float64]*MU.EMA{}
	for sid := range lsb.sidUniverse {
		lsb.pricesSeen[sid] = make([]float64, 0, 100) //In most case, cap 100 seen prices would be enough for whole day.
		lsb.dataEMA[sid] = map[float64]*MU.EMA{}
	}
}

func (lsb *LastSeenBookV2) initializeEMAs(sid int, price float64) {
	if _, ok := lsb.dataEMA[sid][price]; !ok {
		lsb.pricesSeen[sid] = append(lsb.pricesSeen[sid], price)
		lsb.dataEMA[sid][price] = MU.NewEMA(lsb.hlList)
	}
}

//Update
func (lsb *LastSeenBookV2) UpdateSecPrcQtySlice(sid int, secSinceEpoch float64, newObs []data.PriceQty) bool {
	if _, ok := lsb.sidUniverse[sid]; !ok {
		return false
	}
	for _, psp := range newObs {
		pmap := psp.Price
		lsb.initializeEMAs(sid, pmap)
		lsb.dataEMA[sid][pmap].Reset()
		lsb.dataEMA[sid][pmap].Add(powerTransform(psp.Qty, lsb.pow), secSinceEpoch)
	}
	return true
}

//GetValues
func (lsb *LastSeenBookV2) GetValues(mPrice, secEpoch float64) ([]float64, error) {

	if len(lsb.dataEMA[lsb.baseSid]) == 0 {
		for i := 0; i < len(lsb.ret); i++ {
			lsb.ret[i] = 0.0
		}
		return lsb.ret, nil
	}
	err := bfEMAImpulseMean4Func(lsb.pricesSeen[lsb.baseSid], lsb.dataEMA[lsb.baseSid], mPrice, secEpoch, lsb.hlLen, lsb.ret)
	return lsb.ret, err
}

//class HorizonPriceExtrema(FeatureBase)
/* indicators based on new high/low of prices in a fixed (moving) horizon. */

type HorizonPriceExtremaSubClass int

const (
	HorizonPriceExtremaGroup HorizonPriceExtremaSubClass = iota + 1
	HorizonPriceExtremaSingle
)

type HorizonPriceExtrema struct {
	FeatureBase

	SubClass HorizonPriceExtremaSubClass

	hlList []int
	hlLen  int
	//pow        float64
	dataEMA   map[IntPair]*MU.EMA
	dataEMA2  map[IntPair]*MU.EMA
	emaHlList []int
	//horizonDeck map[IntPair][]HPEobs
	secEpochArr, priceHighArr, priceLowArr, sizeArr, askSizeArr, bidSizeArr map[IntPair][]float64
	priceHighMax, priceLowMin                                               map[IntPair]float64 // save this when putting it save the cost of iterating.

	//Group specific variables
	highMA map[int]*MU.MATime
	lowMA  map[int]*MU.MATime
	sizeMA map[int]*MU.MATime
	askMA  map[int]*MU.MATime
	bidMA  map[int]*MU.MATime

	//return
	ret []float64
}
type IntPair struct {
	v1, v2 int
}

func (hpe *HorizonPriceExtrema) loadFeaturePrefs() error {
	hpe.hlList = hpe.prefs.GetIntListPref(hpe.featureName + "_hl_list")
	hpe.hlLen = len(hpe.hlList)
	//hpe.pow = hpe.prefs.GetFloat64Pref(hpe.featureName + "_power")
	hpe.emaHlList = make([]int, hpe.hlLen)
	for i, v := range hpe.hlList {
		hpe.emaHlList[i] = int(math.Ceil(float64(v) / 2.0))
	}
	return nil
}

//setFeatureNames: set column names.
func (hpe *HorizonPriceExtrema) setFeatureNames() {
	hpe.colNames = make([]string, 2*hpe.hlLen)
	for i := 0; i < hpe.hlLen; i++ {
		hpe.colNames[i] = fmt.Sprintf("%s-mom-t%ds", hpe.featureName, hpe.hlList[i])
		hpe.colNames[i+hpe.hlLen] = fmt.Sprintf("%s-spt-t%ds", hpe.featureName, hpe.hlList[i])
	}
	// assign ret memory
	hpe.ret = make([]float64, len(hpe.colNames))
}

//initialize internal variables'
func (hpe *HorizonPriceExtrema) initInternalVars() {
	hpe.FeatureBase.initInternalVars()
	//TODO: HorizonPriceExtremaGroup does not need "horizon_deck" variables
	hpe.secEpochArr, hpe.priceHighArr, hpe.priceLowArr,
		hpe.sizeArr, hpe.askSizeArr, hpe.bidSizeArr =
		map[IntPair][]float64{}, map[IntPair][]float64{}, map[IntPair][]float64{},
		map[IntPair][]float64{}, map[IntPair][]float64{}, map[IntPair][]float64{}
	hpe.dataEMA = map[IntPair]*MU.EMA{}
	hpe.dataEMA2 = map[IntPair]*MU.EMA{}
	hpe.priceHighMax, hpe.priceLowMin = map[IntPair]float64{}, map[IntPair]float64{}
	for sid := range hpe.sidUniverse {
		for i, hl := range hpe.hlList {
			emaHl := hpe.emaHlList[i]
			ip := IntPair{sid, hl}
			hpe.secEpochArr[ip], hpe.priceHighArr[ip], hpe.priceLowArr[ip] = make([]float64, 0, 48), make([]float64, 0, 48),
				make([]float64, 0, 48)
			hpe.sizeArr[ip], hpe.askSizeArr[ip], hpe.bidSizeArr[ip] = make([]float64, 0, 48), make([]float64, 0, 48),
				make([]float64, 0, 48)

			hpe.dataEMA[ip] = MU.NewEMA([]int{emaHl})
			hpe.dataEMA2[ip] = MU.NewEMA([]int{emaHl})
			hpe.priceHighMax[ip] = math.Inf(-1)
			hpe.priceLowMin[ip] = math.Inf(1)
		}
	}

	if hpe.SubClass == HorizonPriceExtremaGroup {
		hpe.highMA = make(map[int]*MU.MATime)
		hpe.lowMA = make(map[int]*MU.MATime)
		hpe.sizeMA = make(map[int]*MU.MATime)
		hpe.askMA = make(map[int]*MU.MATime)
		hpe.bidMA = make(map[int]*MU.MATime)
		for sid := range hpe.sidUniverse {
			hpe.highMA[sid] = MU.NewMATime(hpe.hlList)
			hpe.lowMA[sid] = MU.NewMATime(hpe.hlList)
			hpe.sizeMA[sid] = MU.NewMATime(hpe.hlList)
			hpe.askMA[sid] = MU.NewMATime(hpe.hlList)
			hpe.bidMA[sid] = MU.NewMATime(hpe.hlList)
		}
	}
}

//Update
func (hpe *HorizonPriceExtrema) UpdateSecValueSlice(sid int, secSinceEpoch float64, obs []float64) bool {
	if _, ok := hpe.sidUniverse[sid]; !ok {
		return false
	}
	priceHigh, priceLow, tSize, netSize, adjSizeAsk, adjSizeBid := obs[0], obs[1], obs[2], obs[3], obs[4], obs[5]

	switch hpe.SubClass {
	case HorizonPriceExtremaSingle:
		for _, hl := range hpe.hlList {
			ipk := IntPair{sid, hl}
			theSEA := hpe.secEpochArr[ipk]
			thePHA := hpe.priceHighArr[ipk]
			thePLA := hpe.priceLowArr[ipk]
			theSA := hpe.sizeArr[ipk]
			theASA := hpe.askSizeArr[ipk]
			theBSA := hpe.bidSizeArr[ipk]
			theSEA = append(theSEA, secSinceEpoch+float64(hl))
			thePHA = append(thePHA, priceHigh)
			thePLA = append(thePLA, priceLow)
			theSA = append(theSA, tSize)
			theASA = append(theASA, adjSizeAsk)
			theBSA = append(theBSA, adjSizeBid)
			if hpe.priceHighMax[ipk] < priceHigh {
				hpe.priceHighMax[ipk] = priceHigh
			}
			if hpe.priceLowMin[ipk] > priceLow {
				hpe.priceLowMin[ipk] = priceLow
			}
			for len(theSEA) >= 2 && theSEA[1] <= secSinceEpoch {
				// pop left
				theSEA = theSEA[1:]
				thePHA = thePHA[1:]
				thePLA = thePLA[1:]
				theSA = theSA[1:]
				theASA = theASA[1:]
				theBSA = theBSA[1:]
			}
			hpe.secEpochArr[ipk] = theSEA
			hpe.priceHighArr[ipk] = thePHA
			hpe.priceLowArr[ipk] = thePLA
			hpe.sizeArr[ipk] = theSA
			hpe.askSizeArr[ipk] = theASA
			hpe.bidSizeArr[ipk] = theBSA
			if len(theSA) >= hl/10 {
				var avgSize, avgAskSize, avgBidSize, sizeHigh, sizeLow float64
				var sizeTotal, askSizeTotal, bidSizeTotal float64 = 0.0, 0.0, 0.0
				maxPrice := thePHA[0]
				minPrice := thePLA[0]
				for i := 0; i < len(theSA); i++ {
					sizeTotal += theSA[i]
					askSizeTotal += theASA[i]
					bidSizeTotal += theBSA[i]
					if thePHA[i] > maxPrice {
						maxPrice = thePHA[i]
					}
					if thePLA[i] < minPrice {
						minPrice = thePLA[i]
					}
				}
				lf := float64(len(theSA))
				avgSize = sizeTotal / lf
				avgAskSize = askSizeTotal / lf
				avgBidSize = bidSizeTotal / lf
				sizeHigh = (tSize + netSize) / 2.0
				sizeLow = (tSize - netSize) / 2.0
				if priceHigh >= maxPrice {
					hpe.dataEMA[ipk].Add(sizeHigh/avgSize, secSinceEpoch)
					hpe.dataEMA2[ipk].Add(-adjSizeAsk/avgAskSize, secSinceEpoch)
				} else if priceLow <= minPrice {
					hpe.dataEMA[ipk].Add(-sizeLow/avgSize, secSinceEpoch)
					hpe.dataEMA2[ipk].Add(adjSizeBid/avgBidSize, secSinceEpoch)
				}
			}
		}
	case HorizonPriceExtremaGroup:
		hpe.highMA[sid].Add(priceHigh, secSinceEpoch)
		hpe.lowMA[sid].Add(priceLow, secSinceEpoch)
		hpe.sizeMA[sid].Add(tSize, secSinceEpoch)
		hpe.askMA[sid].Add(adjSizeAsk, secSinceEpoch)
		hpe.bidMA[sid].Add(adjSizeBid, secSinceEpoch)
		for h, hl := range hpe.hlList {
			if hpe.highMA[sid].NumObs() >= hl/10 {
				avgSize := hpe.sizeMA[sid].GetMeanIdx(h, secSinceEpoch)
				avgAskSize := hpe.askMA[sid].GetMeanIdx(h, secSinceEpoch)
				avgBidSize := hpe.bidMA[sid].GetMeanIdx(h, secSinceEpoch)
				sizeHigh := (tSize + netSize) / 2
				sizeLow := (tSize - netSize) / 2
				key := IntPair{sid, hl}
				if priceHigh >= hpe.highMA[sid].GetMaxIdx(h, secSinceEpoch) {
					hpe.dataEMA[key].Add(sizeHigh/avgSize, secSinceEpoch)
					hpe.dataEMA2[key].Add(-adjSizeAsk/avgAskSize, secSinceEpoch)
				} else if priceLow <= hpe.lowMA[sid].GetMinIdx(h, secSinceEpoch) {
					hpe.dataEMA[key].Add(-sizeLow/avgSize, secSinceEpoch)
					hpe.dataEMA2[key].Add(adjSizeBid/avgBidSize, secSinceEpoch)
				}
			}
		}
	}
	return true
}

//GetValues
// NOTE: In the original python edtion, there is a para named "mid_price" while not used. So omit it here.
func (hpe *HorizonPriceExtrema) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return hpe.GetSidValues(hpe.baseSid, mPrice, secEpoch)
}
func (hpe *HorizonPriceExtrema) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	for i := 0; i < hpe.hlLen; i++ {
		ipk := IntPair{sid, hpe.hlList[i]}
		hpe.ret[i] = hpe.dataEMA[ipk].GetImpulseMeanIdx(0, secEpoch)
		hpe.ret[hpe.hlLen+i] = hpe.dataEMA2[ipk].GetImpulseMeanIdx(0, secEpoch)
	}
	return hpe.ret, nil
}

type HorizonStatDeltaSubClass int

const (
	HorizonStatDeltaChinaFutures HorizonStatDeltaSubClass = iota + 1
	HorizonStatDeltaChinaEquity
)

//class HorizonStatDelta.
/*  indicators based on delta of a given stat calculated
    in a fixed (moving) horizon. */
type HorizonStatDelta struct {
	FeatureBase
	SubClass        HorizonStatDeltaSubClass
	hlList          []int
	hlLen           int
	hlPairList      []IntPair
	secBeginMapList map[IntPair][]float64
	secEndMapList   map[IntPair][]float64
	sizeMapList     map[IntPair][]float64

	//return
	ret []float64
}

func (hsd *HorizonStatDelta) loadFeaturePrefs() error {
	hsd.hlList = hsd.prefs.GetIntListPref(hsd.featureName + "_hl_list")
	hsd.hlLen = len(hsd.hlList)
	extHlList := make([]int, hsd.hlLen+1)
	extHlList[0] = 0
	copy(extHlList[1:], hsd.hlList)
	hsd.hlPairList = make([]IntPair, hsd.hlLen)
	for i := 0; i < hsd.hlLen; i++ {
		hsd.hlPairList[i] = IntPair{extHlList[i], extHlList[i+1]}
	}
	return nil
}

//setFeatureNames: set column names.
func (hsd *HorizonStatDelta) setFeatureNames() {
	hsd.colNames = make([]string, 1*hsd.hlLen)
	for i := 0; i < hsd.hlLen; i++ {
		hsd.colNames[i] = fmt.Sprintf("%s-delta-t%ds", hsd.featureName, hsd.hlList[i])
	}
	// assign ret memory
	hsd.ret = make([]float64, len(hsd.colNames))
}

//initialize internal variables'
func (hsd *HorizonStatDelta) initInternalVars() {
	hsd.FeatureBase.initInternalVars()
	hsd.secBeginMapList, hsd.secEndMapList, hsd.sizeMapList = map[IntPair][]float64{}, map[IntPair][]float64{}, map[IntPair][]float64{}
	for sid := range hsd.sidUniverse {
		for _, hl := range hsd.hlList {
			ip := IntPair{sid, hl}
			hsd.secBeginMapList[ip] = make([]float64, 0, 48) //set the original length to 0 so that can use append.
			hsd.secEndMapList[ip] = make([]float64, 0, 48)
			hsd.sizeMapList[ip] = make([]float64, 0, 48)
		}
	}
}

//Update
func (hsd *HorizonStatDelta) UpdateSecValue(sid int, secSinceEpoch, size float64) bool {
	if _, ok := hsd.sidUniverse[sid]; !ok {
		return false
	}
	for _, hlBEpair := range hsd.hlPairList {
		hlBegin, hlEnd := hlBEpair.v1, hlBEpair.v2
		ipk := IntPair{sid, hlEnd}
		hsd.secBeginMapList[ipk] = append(hsd.secBeginMapList[ipk], secSinceEpoch+float64(hlBegin))
		hsd.secEndMapList[ipk] = append(hsd.secEndMapList[ipk], secSinceEpoch+float64(hlEnd))
		hsd.sizeMapList[ipk] = append(hsd.sizeMapList[ipk], size)
		for len(hsd.sizeMapList[ipk]) >= 2 && hsd.secEndMapList[ipk][1] <= secSinceEpoch {
			//pop left
			hsd.sizeMapList[ipk] = hsd.sizeMapList[ipk][1:]
			hsd.secBeginMapList[ipk] = hsd.secBeginMapList[ipk][1:]
			hsd.secEndMapList[ipk] = hsd.secEndMapList[ipk][1:]
		}
	}
	return true
}

//GetValues
func (hsd *HorizonStatDelta) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return hsd.GetSidValues(hsd.baseSid, mPrice, secEpoch)
}

func (hsd *HorizonStatDelta) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	var havingV, lastHavingV bool = false, false
	var v, lastV, currentV float64 = 0.0, 0.0, 0.0
	var hlBegin, hlEnd int
	for i := 0; i < hsd.hlLen; i++ {
		lastHavingV = havingV
		lastV = currentV
		havingV = false
		hlBegin, hlEnd = hsd.hlPairList[i].v1, hsd.hlPairList[i].v2
		v = 0.0
		ipk := IntPair{sid, hlEnd}
		secBegin, sizex := 0.0, 0.0
		for j := 0; j < len(hsd.secBeginMapList[ipk]); j++ {
			secBegin = hsd.secBeginMapList[ipk][j]
			sizex = hsd.sizeMapList[ipk][j]
			if secBegin <= secEpoch {
				havingV = true
				v += sizex
			}
		}
		if havingV && hlEnd != hlBegin {
			currentV = v / float64(hlEnd-hlBegin)
		} else if hlBegin == hlEnd {
			havingV = false
		}
		if !havingV {
			currentV = 0.0
		}
		if i == 0 {
			continue
		}

		if hsd.SubClass == HorizonStatDeltaChinaEquity {
			if lastHavingV && havingV && lastV > 0 && currentV > 0 {
				hsd.ret[i-1] = math.Log(lastV) - math.Log(currentV)
			} else {
				hsd.ret[i-1] = 0.0
			}
		} else {
			if lastHavingV && havingV {
				hsd.ret[i-1] = lastV - currentV
			} else {
				hsd.ret[i-1] = 0.0
			}
		}
		if i == hsd.hlLen-1 {
			if havingV {
				hsd.ret[i] = currentV
			} else {
				hsd.ret[i] = 0.0
			}
		}
	}
	return hsd.ret, nil
}

//class HorizonStatDelta.
/*  indicators based on delta of range of a given stat calculated
    in a fixed (moving) horizon. */
type HorizonStatsRangeDelta struct {
	HorizonStatDelta // all the funcs same as HorizonStatDelta but only GetValues is diff.
}

//GetValues
func (hsrd *HorizonStatsRangeDelta) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return hsrd.GetSidValues(hsrd.baseSid, mPrice, secEpoch)
}

func (hsrd *HorizonStatsRangeDelta) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	var havingV, lastHavingV bool = false, false
	var lastV, currentV float64 = 0.0, 0.0
	var maxV, minV float64 = 0.0, 0.0

	for i := 0; i < hsrd.hlLen; i++ {
		lastHavingV = havingV
		lastV = currentV
		havingV = false
		hl := hsrd.hlList[i]
		ipk := IntPair{sid, hl}
		secBegin, sizex := 0.0, 0.0
		for j := 0; j < len(hsrd.secBeginMapList[ipk]); j++ {
			secBegin = hsrd.secBeginMapList[ipk][j]
			sizex = hsrd.sizeMapList[ipk][j]
			if secBegin <= secEpoch {
				if !havingV { // first value
					maxV = sizex
					minV = sizex
				} else {
					if maxV < sizex {
						maxV = sizex
					}
					if minV > sizex {
						minV = sizex
					}
				}
				havingV = true
			}
		}
		if havingV {
			currentV = maxV - minV
		} else {
			havingV = false
		}
		if i == 0 {
			continue
		}
		if lastHavingV && havingV {
			hsrd.ret[i-1] = lastV - currentV
		} else {
			hsrd.ret[i-1] = 0.0
		}
		if i == hsrd.hlLen-1 {
			if havingV {
				hsrd.ret[i] = currentV
			} else {
				hsrd.ret[i] = 0.0
			}
		}
	}
	return hsrd.ret, nil
}

//class SignedIDSBookV2.
/*  indicators based on signed impulse decayed sum book.
    decay is taken on quote size.
    Size is signed with normal convention. */
type SignedIDSBookV2 struct {
	FeatureBase
	hlList     []int
	hlLen      int
	pow        float64
	pricesSeen map[int][]float64
	dataEMA    map[int]map[float64]*MU.EMA

	//return
	ret []float64
}

func (sidb *SignedIDSBookV2) loadFeaturePrefs() error {
	sidb.hlList = sidb.prefs.GetIntListPref(sidb.featureName + "_hl_list")
	sidb.hlLen = len(sidb.hlList)
	sidb.pow = sidb.prefs.GetFloat64Pref(sidb.featureName + "_power")
	return nil
}

//setFeatureNames: set column names.
func (sidb *SignedIDSBookV2) setFeatureNames() {
	sidb.colNames = make([]string, 4*sidb.hlLen)
	for i := 0; i < sidb.hlLen; i++ {
		sidb.colNames[i] = fmt.Sprintf("%s-bsr%ds", sidb.featureName, sidb.hlList[i])
		sidb.colNames[i+sidb.hlLen] = fmt.Sprintf("%s-bss%ds", sidb.featureName, sidb.hlList[i])
		sidb.colNames[i+2*sidb.hlLen] = fmt.Sprintf("%s-t%ds", sidb.featureName, sidb.hlList[i])
		sidb.colNames[i+3*sidb.hlLen] = fmt.Sprintf("%s-dev%ds", sidb.featureName, sidb.hlList[i])
	}
	// assign ret memory
	sidb.ret = make([]float64, len(sidb.colNames))
}

//initialize internal variables'
func (sidb *SignedIDSBookV2) initInternalVars() {
	sidb.FeatureBase.initInternalVars()
	sidb.pricesSeen = map[int][]float64{}
	sidb.dataEMA = map[int]map[float64]*MU.EMA{}
	for sid := range sidb.sidUniverse {
		sidb.pricesSeen[sid] = make([]float64, 0, 100) //In most case, cap 100 seen prices would be enough for whole day.
		sidb.dataEMA[sid] = map[float64]*MU.EMA{}
	}
}

func (sidb *SignedIDSBookV2) initializeEMAs(sid int, price float64) {
	//if _, ok := sidb.pricesSeen[sid]; !ok {
	//	sidb.pricesSeen[sid] = map[float64]bool{price: true}
	//	sidb.dataEMA[sid][price] = MU.NewEMA(sidb.hlList)
	//} else
	if _, ok := sidb.dataEMA[sid][price]; !ok {
		sidb.pricesSeen[sid] = append(sidb.pricesSeen[sid], price)
		sidb.dataEMA[sid][price] = MU.NewEMA(sidb.hlList)
	}
}

//Update
func (sidb *SignedIDSBookV2) UpdateSecPrcQtySlice(sid int, secSinceEpoch float64, newObs []data.PriceQty) bool {
	if _, ok := sidb.sidUniverse[sid]; !ok {
		return false
	}
	for _, psp := range newObs {
		pmap := psp.Price
		sidb.initializeEMAs(sid, pmap)
		sidb.dataEMA[sid][pmap].Add(powerTransform(psp.Qty, sidb.pow), secSinceEpoch)
	}
	return true
}

//GetValues
func (sidb *SignedIDSBookV2) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	if len(sidb.dataEMA[sidb.baseSid]) == 0 {
		for i := 0; i < len(sidb.ret); i++ {
			sidb.ret[i] = 0
		}
		return sidb.ret, nil
	}
	//if len(sidb.dataEMA[sidb.baseSid]) != sidb.hlLen {
	//	err := errors.New("Hllen not equals with EMS's keys length. ")
	//	return nil, err
	//}
	err := bfEMAImpulseMean4Func(sidb.pricesSeen[sidb.baseSid], sidb.dataEMA[sidb.baseSid], mPrice, secEpoch, sidb.hlLen, sidb.ret)
	return sidb.ret, err
}

//class BookPressureIDS.
/*      indicators based on impulsed decayed sum of book pressure.
 */
type BookPressureIDS struct {
	FeatureBase
	hlList         []int   //horizon life
	hlLen          int     //len of horizon lives will be used many times so it is pre-calculated
	valueBound     float64 //bound on value
	dailyRoot      string  //
	basisOnly      bool    //whether it's basis only
	pow            float64
	dataEMA        map[int]*MU.EMA
	prevDayAvgSize map[int]float64

	//return
	ret []float64
}

func (bpids *BookPressureIDS) loadFeaturePrefs() error {
	bpids.hlList = bpids.prefs.GetIntListPref(bpids.featureName + "_hl_list")
	bpids.hlLen = len(bpids.hlList)
	bpids.pow = bpids.prefs.GetFloat64Pref(bpids.featureName + "_power")
	bpids.valueBound = bpids.prefs.GetFloat64Pref(bpids.featureName + "_bound")
	bpids.dailyRoot = bpids.prefs.GetStringPref("daily_root")
	if bpids.prefs.HasPref(bpids.featureName + "_basis_only") {
		bpids.basisOnly = bpids.prefs.GetBoolPref(bpids.featureName + "_basis_only")
	} else {
		bpids.basisOnly = false
	}
	return nil
}

//setFeatureNames: set column names.
func (bpids *BookPressureIDS) setFeatureNames() {
	startIndex := 0
	if bpids.basisOnly {
		bpids.colNames = make([]string, len(bpids.basisNames)*bpids.hlLen)
	} else {
		bpids.colNames = make([]string, len(bpids.basisNames)*bpids.hlLen+bpids.hlLen)
		for i := 0; i < bpids.hlLen; i++ {
			bpids.colNames[i] = fmt.Sprintf("%s-t%ds", bpids.featureName, bpids.hlList[i])
		}
		startIndex = bpids.hlLen
	}
	for i := 0; i < len(bpids.basisNames); i++ {
		for j := 0; j < bpids.hlLen; j++ {
			bpids.colNames[startIndex+i*bpids.hlLen+j] = fmt.Sprintf("%s-%s-t%ds", bpids.featureName,
				bpids.basisNames[i].symbol, bpids.hlList[j])
		}
	}
	// assign ret memory
	bpids.ret = make([]float64, len(bpids.colNames))
}

//initialize internal variables'
func (bpids *BookPressureIDS) initInternalVars() {
	bpids.FeatureBase.initInternalVars()
	bpids.dataEMA = map[int]*MU.EMA{}
	for sid := range bpids.sidUniverse {
		bpids.dataEMA[sid] = MU.NewEMA(bpids.hlList)
	}
}

//'load daily stats needed for feature calculations'
func (bpids *BookPressureIDS) loadDailyStats() {
	prevDate := common.PreTradeDate(bpids.dateStr)
	dateStart, _ := common.Get2MonthsEarlier(bpids.dateStr)
	fullList := append(bpids.basisList, bpids.baseSid)
	dailyData, _, err := data.LoadDailyDataMedian(dateStart, prevDate, []string{"day_avg_top_size"}, fullList, bpids.dailyRoot)
	if err != nil {
		tu.Logger.Warn(err.Error())
	}
	sidValueMap := dailyData["day_avg_top_size"]
	bpids.prevDayAvgSize = map[int]float64{}
	for sid := range bpids.sidUniverse {
		if _, ok := sidValueMap[sid]; !ok {
			continue
		}
		bpids.prevDayAvgSize[sid] = sidValueMap[sid][len(sidValueMap[sid])-1]
	}
}

//Update
func (bpids *BookPressureIDS) UpdateSecValue(sid int, secSinceEpoch, newObs float64) bool {
	if _, ok := bpids.sidUniverse[sid]; !ok {
		return false
	}
	normFactor := bpids.prevDayAvgSize[sid]
	x := MU.ClipFloat(newObs/normFactor, -bpids.valueBound, bpids.valueBound)
	bpids.dataEMA[sid].Add(powerTransform(x, bpids.pow), secSinceEpoch)
	return true
}

//GetValues
func (bpids *BookPressureIDS) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	startIndex := 0
	if bpids.basisOnly {
		for i := 0; i < len(bpids.ret); i++ {
			bpids.ret[i] = 0
		}
	} else {
		bpids.dataEMA[bpids.baseSid].GetImpulseMean(secEpoch, bpids.ret)
		startIndex = bpids.hlLen
	}
	for i, bsid := range bpids.basisList {
		bpids.dataEMA[bsid].GetImpulseMean(secEpoch, bpids.ret[startIndex+i*bpids.hlLen:startIndex+(i+1)*bpids.hlLen])
	}
	return bpids.ret, nil
}

//BidAskRatio; derived from BookPressureIDS
type BidAskRatio struct {
	BookPressureIDS
}

//Update; only this method diff from BookPressureIDS
func (bart *BidAskRatio) UpdateSecValueSlice(sid int, secSinceEpoch float64, sizeBAPair []float64) bool {
	if _, ok := bart.sidUniverse[sid]; !ok {
		return false
	}
	sizeBid, sizeAsk := sizeBAPair[0], sizeBAPair[1]
	var x float64
	if sizeAsk == 0 || sizeAsk == math.NaN() {
		x = bart.valueBound
	} else if sizeBid == 0 || sizeBid == math.NaN() {
		x = 0 - bart.valueBound
	} else {
		bar := math.Log(sizeBid+1) - math.Log(sizeAsk+1)
		x = MU.ClipFloat(bar, -bart.valueBound, bart.valueBound)
	}

	bart.dataEMA[sid].Add(powerTransform(x, bart.pow), secSinceEpoch)
	return true
}

//EMADiffEMA; EMA of diff of EMA
type EMADiffEMA struct {
	hlList          []int //horizon life
	hlLen           int   //len of horizon lives will be used many times so it is pre-calculated
	diffEMA         map[int]*MU.EMA
	signEMA         map[int]*MU.EMA
	bothDiffAndSign bool
}

func newEMADiffEMA(hlList []int, bothDiffAndSign bool) *EMADiffEMA {
	ede := &EMADiffEMA{hlList: hlList, hlLen: len(hlList), bothDiffAndSign: bothDiffAndSign}
	ede.diffEMA = map[int]*MU.EMA{}
	ede.signEMA = map[int]*MU.EMA{}
	for _, hl := range hlList {
		ede.diffEMA[hl] = MU.NewEMA([]int{hl})
		if bothDiffAndSign {
			ede.signEMA[hl] = MU.NewEMA([]int{hl})
		}
	}
	return ede
}

func (ede *EMADiffEMA) update(secEpoch float64, newObs []float64) error {
	if len(newObs) != ede.hlLen+1 {
		return errors.New("Length ")
	}
	for i := 0; i < ede.hlLen; i++ {
		hl := ede.hlList[i]
		d := newObs[i] - newObs[i+1]
		ede.diffEMA[hl].Add(d, secEpoch)
		if ede.bothDiffAndSign {
			s := MU.SignOfFloat(newObs[i]) * MU.SignOfFloat(newObs[i+1])
			ede.signEMA[hl].Add(s, secEpoch)
		}
	}
	return nil
}

func (ede *EMADiffEMA) getValues(res []float64) error {
	if ede.bothDiffAndSign {
		if len(res) < 2*ede.hlLen {
			return errors.New("Length of res should not less than 2 times of hl len.")
		}
	} else {
		if len(res) < ede.hlLen {
			return errors.New("Length of res should not less than hl len.")
		}
	}
	for i, hl := range ede.hlList {
		//ede.diffEMA[hl].GetMean(res[i:i+1])
		res[i] = ede.diffEMA[hl].GetMeanIdx(0)
		if ede.bothDiffAndSign {
			//ede.signEMA[hl].GetMean(res[i+ede.hlLen:i+ede.hlLen+1])
			res[i+ede.hlLen] = ede.signEMA[hl].GetMeanIdx(0)
		}
	}
	return nil
}

//BookPressureIDSNDiff; indicators based on impulsed decayed sum of book pressure and their differences.
type BookPressureIDSNDiff struct {
	BookPressureIDS
	ede      map[int]*EMADiffEMA
	idctMean []float64
}

//setFeatureNames: set column names.
func (bpidd *BookPressureIDSNDiff) setFeatureNames() {
	startIndex := 0
	nbasis := len(bpidd.basisNames)
	if bpidd.basisOnly {
		bpidd.colNames = make([]string, nbasis*bpidd.hlLen*2-nbasis)
	} else {
		bpidd.colNames = make([]string, nbasis*bpidd.hlLen*2+bpidd.hlLen*2-(nbasis+1))
		for i := 0; i < bpidd.hlLen; i++ {
			bpidd.colNames[i] = fmt.Sprintf("%s-t%ds", bpidd.featureName, bpidd.hlList[i])
			if i < bpidd.hlLen-1 {
				bpidd.colNames[i+bpidd.hlLen] = fmt.Sprintf("%s-diff-t%ds", bpidd.featureName, bpidd.hlList[i])
			}
		}
		startIndex = bpidd.hlLen*2 - 1
	}
	onePartLen := nbasis * bpidd.hlLen
	for i := 0; i < nbasis; i++ {
		for j := 0; j < bpidd.hlLen; j++ {
			bpidd.colNames[startIndex+i*bpidd.hlLen+j] = fmt.Sprintf("%s-%s-t%ds", bpidd.featureName,
				bpidd.basisNames[i].symbol, bpidd.hlList[j])
			if j < bpidd.hlLen-1 {
				bpidd.colNames[onePartLen+startIndex+i*(bpidd.hlLen-1)+j] = fmt.Sprintf("%s-%s-diff-t%ds", bpidd.featureName,
					bpidd.basisNames[i].symbol, bpidd.hlList[j])
			}
		}
	}
	// assign ret memory
	bpidd.ret = make([]float64, len(bpidd.colNames))
	bpidd.idctMean = make([]float64, bpidd.hlLen)
}

//initialize internal variables'
func (bpidd *BookPressureIDSNDiff) initInternalVars() {
	bpidd.FeatureBase.initInternalVars()
	bpidd.dataEMA = map[int]*MU.EMA{}
	bpidd.ede = map[int]*EMADiffEMA{}

	//short_hl_list = [int(hl + 1) / 2 for hl in self.hl_list[:-1]]
	shortHlList := make([]int, bpidd.hlLen-1)
	for i := range shortHlList {
		shortHlList[i] = (bpidd.hlList[i] + 1) / 2
	}
	for sid := range bpidd.sidUniverse {
		bpidd.dataEMA[sid] = MU.NewEMA(bpidd.hlList)
		bpidd.ede[sid] = newEMADiffEMA(shortHlList, false)
	}
}

//Update
func (bpidd *BookPressureIDSNDiff) UpdateSecValue(sid int, secSinceEpoch, newObs float64) bool {
	if _, ok := bpidd.sidUniverse[sid]; !ok {
		return false
	}
	normFactor := bpidd.prevDayAvgSize[sid]
	x := MU.ClipFloat(newObs/normFactor, -bpidd.valueBound, bpidd.valueBound)
	bpidd.dataEMA[sid].Add(powerTransform(x, bpidd.pow), secSinceEpoch)

	//idctMean := make([]float64, bpidd.hlLen)
	bpidd.dataEMA[sid].GetMean(bpidd.idctMean)
	bpidd.ede[sid].update(secSinceEpoch, bpidd.idctMean)
	return true
}

//GetValues
func (bpidd *BookPressureIDSNDiff) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	startIndex := 0
	if bpidd.basisOnly {
		for i := 0; i < len(bpidd.ret); i++ {
			bpidd.ret[i] = 0
		}

	} else {
		bpidd.dataEMA[bpidd.baseSid].GetImpulseMean(secEpoch, bpidd.ret)
		bpidd.ede[bpidd.baseSid].getValues(bpidd.ret[bpidd.hlLen:])
		startIndex = bpidd.hlLen*2 - 1
	}

	onePartLen := len(bpidd.basisList) * bpidd.hlLen
	for i, bsid := range bpidd.basisList {
		bpidd.dataEMA[bsid].GetImpulseMean(secEpoch, bpidd.ret[startIndex+i*bpidd.hlLen:startIndex+(i+1)*bpidd.hlLen])
		bpidd.ede[bsid].getValues(bpidd.ret[onePartLen+startIndex+i*(bpidd.hlLen-1) : onePartLen+startIndex+(i+1)*(bpidd.hlLen-1)])
	}
	return bpidd.ret, nil
}

type BidAskRatioNDiff struct {
	BookPressureIDSNDiff
}

//Update
func (bpidd *BidAskRatioNDiff) UpdateSecValue(sid int, secSinceEpoch, newObs float64) bool {
	// in case the fall back to this update. raise alert.
	panic(fmt.Sprintf("UpdateSecValue in [BidAskRatioNDiff] not implemented for %s", bpidd.featureName))
	return false
}

//Update
func (barnd *BidAskRatioNDiff) UpdateSecValueSlice(sid int, secSinceEpoch float64, sizeBAPair []float64) bool {
	if _, ok := barnd.sidUniverse[sid]; !ok {
		return false
	}
	sizeBid, sizeAsk := sizeBAPair[0], sizeBAPair[1]
	var x float64
	if sizeAsk == 0 || sizeAsk == math.NaN() {
		x = barnd.valueBound
	} else if sizeBid == 0 || sizeBid == math.NaN() {
		x = 0 - barnd.valueBound
	} else {
		bar := math.Log(sizeBid+1) - math.Log(sizeAsk+1)
		x = MU.ClipFloat(bar, -barnd.valueBound, barnd.valueBound)
	}

	barnd.dataEMA[sid].Add(powerTransform(x, barnd.pow), secSinceEpoch)
	//idctMean := make([]float64, barnd.hlLen)
	barnd.dataEMA[sid].GetMean(barnd.idctMean)
	barnd.ede[sid].update(secSinceEpoch, barnd.idctMean)
	return true
}

//class ADXIndicator.
/*  indicators based on average directional movement. */
type ADXIndicator struct {
	FeatureBase
	hlList   []int
	hlLen    int
	pDMEma   map[int]*MU.EMA
	nDMEma   map[int]*MU.EMA
	trEma    map[int]*MU.EMA
	adx      map[int]map[int]*MU.EMA
	prevLast map[int]float64

	//return
	ret []float64

	//internal variables
	vpDM []float64
	vnDM []float64
	vtr  []float64
}

func (adxi *ADXIndicator) loadFeaturePrefs() error {
	adxi.hlList = adxi.prefs.GetIntListPref(adxi.featureName + "_hl_list")
	adxi.hlLen = len(adxi.hlList)
	return nil
}

//setFeatureNames: set column names.
func (adxi *ADXIndicator) setFeatureNames() {
	adxi.colNames = make([]string, adxi.hlLen)
	for i := 0; i < adxi.hlLen; i++ {
		adxi.colNames[i] = fmt.Sprintf("%s-t%ds", adxi.featureName, adxi.hlList[i])
	}
	// assign ret memory
	adxi.ret = make([]float64, len(adxi.colNames))
}

//initialize internal variables'
func (adxi *ADXIndicator) initInternalVars() {
	adxi.FeatureBase.initInternalVars()

	adxi.pDMEma = map[int]*MU.EMA{}
	adxi.nDMEma = map[int]*MU.EMA{}
	adxi.trEma = map[int]*MU.EMA{}
	adxi.adx = map[int]map[int]*MU.EMA{}
	adxi.prevLast = map[int]float64{}
	for sid := range adxi.sidUniverse {
		adxi.prevLast[sid] = math.NaN()
		adxi.pDMEma[sid] = MU.NewEMA(adxi.hlList)
		adxi.nDMEma[sid] = MU.NewEMA(adxi.hlList)
		adxi.trEma[sid] = MU.NewEMA(adxi.hlList)
		adxi.adx[sid] = map[int]*MU.EMA{}
		for _, hl := range adxi.hlList {
			adxi.adx[sid][hl] = MU.NewEMA([]int{hl})
		}
	}

	adxi.vpDM = make([]float64, adxi.hlLen)
	adxi.vnDM = make([]float64, adxi.hlLen)
	adxi.vtr = make([]float64, adxi.hlLen)
}

//Update
func (adxi *ADXIndicator) UpdateSecValueSlice(sid int, secSinceEpoch float64, highLowLast []float64) bool {
	if _, ok := adxi.sidUniverse[sid]; !ok {
		return false
	}
	high, low, last := highLowLast[0], highLowLast[1], highLowLast[2]
	if lp, ok := adxi.prevLast[sid]; !ok || math.IsNaN(lp) {
		adxi.prevLast[sid] = last
		return false
	}
	lp := adxi.prevLast[sid]
	upMove := high - lp
	downMove := lp - low
	var pDM, nDM float64
	if upMove > downMove && upMove > 0 {
		pDM = upMove
	} else {
		pDM = 0
	}
	if downMove > upMove && downMove > 0 {
		nDM = downMove
	} else {
		nDM = 0
	}
	adxi.pDMEma[sid].Add(pDM, secSinceEpoch)
	adxi.nDMEma[sid].Add(nDM, secSinceEpoch)
	adxi.trEma[sid].Add(trueRange(high, low, lp), secSinceEpoch)

	adxi.pDMEma[sid].GetMean(adxi.vpDM)
	adxi.nDMEma[sid].GetMean(adxi.vnDM)
	adxi.trEma[sid].GetMean(adxi.vtr)
	for i := 0; i < adxi.hlLen; i++ {
		hl := adxi.hlList[i]
		if adxi.vtr[i] <= 0 {
			adxi.adx[sid][hl].Add(0, secSinceEpoch)
		} else {
			pDI := adxi.vpDM[i] / adxi.vtr[i]
			nDI := adxi.vnDM[i] / adxi.vtr[i]
			tmp := 0.0
			if pDI+nDI != 0 {
				tmp = math.Abs((pDI - nDI) / (pDI + nDI))
			}
			adxi.adx[sid][hl].Add(tmp, secSinceEpoch)
		}
	}
	adxi.prevLast[sid] = last
	return true
}

//GetValues return values of each feature column at sec_since_epoch as a list
func (adxi *ADXIndicator) GetValues(NOUSEDprice, NOUSEDsecEpoch float64) ([]float64, error) {
	return adxi.GetSidValues(adxi.baseSid, NOUSEDprice, NOUSEDsecEpoch)
}

func (adxi *ADXIndicator) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i, hl := range adxi.hlList {
		adxi.ret[i] = adxi.adx[sid][hl].GetMeanIdx(0)
	}
	return adxi.ret, nil
}

//class UnsignedIDSBook.
/*  indicators based on signed impulse decayed sum book.
    decay is taken on quote size.
    Size is signed with normal convention. */
type UnsignedIDSBook struct {
	FeatureBase
	hlList     []int
	hlLen      int
	pow        float64
	pricesSeen map[int][]float64
	dataEMA    map[int]map[float64]*MU.EMA

	//return
	ret []float64
}

func (usib *UnsignedIDSBook) loadFeaturePrefs() error {
	usib.hlList = usib.prefs.GetIntListPref(usib.featureName + "_hl_list")
	usib.hlLen = len(usib.hlList)
	usib.pow = usib.prefs.GetFloat64Pref(usib.featureName + "_power")
	return nil
}

//setFeatureNames: set column names.
func (usib *UnsignedIDSBook) setFeatureNames() {
	usib.colNames = make([]string, 2*usib.hlLen)
	for i := 0; i < usib.hlLen; i++ {
		usib.colNames[i] = fmt.Sprintf("%s-t%ds", usib.featureName, usib.hlList[i])
		usib.colNames[i+usib.hlLen] = fmt.Sprintf("%s-dev%ds", usib.featureName, usib.hlList[i])
	}
	// assign ret memory
	usib.ret = make([]float64, len(usib.colNames))
}

//initialize internal variables'
func (usib *UnsignedIDSBook) initInternalVars() {
	usib.FeatureBase.initInternalVars()
	usib.pricesSeen = map[int][]float64{}
	usib.dataEMA = map[int]map[float64]*MU.EMA{}
	for sid := range usib.sidUniverse {
		usib.pricesSeen[sid] = make([]float64, 0, 100) //In most case, cap 100 seen prices would be enough for whole day.
		usib.dataEMA[sid] = map[float64]*MU.EMA{}
	}
}

func (usib *UnsignedIDSBook) initializeEMAs(sid int, price float64) {
	if _, ok := usib.dataEMA[sid][price]; !ok {
		usib.pricesSeen[sid] = append(usib.pricesSeen[sid], price)
		usib.dataEMA[sid][price] = MU.NewEMA(usib.hlList)
	}
}

//Update
func (usib *UnsignedIDSBook) UpdateSecPrcQtySlice(sid int, secSinceEpoch float64, newObs []data.PriceQty) bool {
	if _, ok := usib.sidUniverse[sid]; !ok {
		return false
	}
	for _, psp := range newObs {
		pmap := psp.Price
		usib.initializeEMAs(sid, pmap)
		usib.dataEMA[sid][pmap].Add(powerTransform(psp.Qty, usib.pow), secSinceEpoch)
	}
	return true
}

//GetValues
func (usib *UnsignedIDSBook) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	if len(usib.dataEMA[usib.baseSid]) == 0 {
		for i := 0; i < len(usib.ret); i++ {
			usib.ret[i] = 0
		}
		return usib.ret, nil
	}
	err := bfEMAImpulseMean2Func(usib.pricesSeen[usib.baseSid], usib.dataEMA[usib.baseSid], mPrice, secEpoch, usib.hlLen, usib.ret)
	return usib.ret, err
}

//TrueStrengthIndex: indicators based on true strength index.
type TrueStrengthIndex struct {
	FeatureBase
	hlList                []int
	hlLen                 int
	lastPrice             map[int]float64
	dpMA, adpMA           map[int]*MU.MA
	outerdpMA, outerAdpMA map[int]map[int]*MU.MA
	tsi                   map[int][]float64
}

func (tsi *TrueStrengthIndex) loadFeaturePrefs() error {
	tsi.hlList = tsi.prefs.GetIntListPref(tsi.featureName + "_hl_list")
	tsi.hlLen = len(tsi.hlList)
	return nil
}

//setFeatureNames: set column names.
func (tsi *TrueStrengthIndex) setFeatureNames() {
	tsi.colNames = make([]string, 1*tsi.hlLen)
	for i := 0; i < tsi.hlLen; i++ {
		tsi.colNames[i] = fmt.Sprintf("%s-t%ds", tsi.featureName, tsi.hlList[i])
	}
}

//initialize internal variables'
func (tsi *TrueStrengthIndex) initInternalVars() {
	tsi.FeatureBase.initInternalVars()
	tsi.lastPrice = map[int]float64{}
	tsi.dpMA = map[int]*MU.MA{}
	tsi.adpMA = map[int]*MU.MA{}
	tsi.outerdpMA = map[int]map[int]*MU.MA{}
	tsi.outerAdpMA = map[int]map[int]*MU.MA{}
	tsi.tsi = map[int][]float64{}
	for sid := range tsi.sidUniverse {
		tsi.dpMA[sid] = MU.NewMA(tsi.hlList)
		tsi.adpMA[sid] = MU.NewMA(tsi.hlList)
		tsi.outerdpMA[sid] = map[int]*MU.MA{}
		tsi.outerAdpMA[sid] = map[int]*MU.MA{}
		tsi.lastPrice[sid] = math.NaN()
		for i, hl := range tsi.hlList {
			tmpi := int(math.RoundToEven(float64(hl) / 2.0)) //replicate np.round behavior
			tsi.outerdpMA[sid][i] = MU.NewMA([]int{tmpi})
			tsi.outerAdpMA[sid][i] = MU.NewMA([]int{tmpi})
		}
		tsi.tsi[sid] = make([]float64, tsi.hlLen)
	}
}

//Update
func (tsi *TrueStrengthIndex) UpdateValue(sid int, price float64) bool {
	if _, ok := tsi.sidUniverse[sid]; !ok {
		return false
	}

	if lp, ok := tsi.lastPrice[sid]; !ok || math.IsNaN(lp) {
		tsi.lastPrice[sid] = price
		return true
	} else {
		dp := price - lp
		tsi.dpMA[sid].Add(dp)
		tsi.adpMA[sid].Add(math.Abs(dp))

		for i := 0; i < tsi.hlLen; i++ {
			tsi.outerdpMA[sid][i].Add(tsi.dpMA[sid].GetMeanIdx(i))
			tsi.outerAdpMA[sid][i].Add(tsi.adpMA[sid].GetMeanIdx(i))
		}
		for i := 0; i < tsi.hlLen; i++ {
			odp := tsi.outerdpMA[sid][i].GetMeanIdx(0)
			oadp := tsi.outerAdpMA[sid][i].GetMeanIdx(0)
			if oadp <= 0 {
				oadp = 1e8
			}
			tsi.tsi[sid][i] = odp / oadp
		}
	}
	tsi.lastPrice[sid] = price
	return true
}

//GetValues
func (tsi *TrueStrengthIndex) GetValues(NOUSEDPrice, NOUSEDsecEpoch float64) ([]float64, error) {
	return tsi.GetSidValues(tsi.baseSid, NOUSEDPrice, NOUSEDsecEpoch)
}

//GetValues
func (tsi *TrueStrengthIndex) GetSidValues(sid int, NOUSEDPrice, NOUSEDsecEpoch float64) ([]float64, error) {
	if res, ok := tsi.tsi[sid]; ok {
		return res, nil
	} else {
		return make([]float64, tsi.hlLen), nil
	}
}

//CommodityChannelIndex indicators based on Commodity channel index.
type CommodityChannelIndex struct {
	FeatureBase
	hlList    []int
	hlLen     int
	lastPrice map[int]float64
	dataMa    map[int]*MU.MA

	//return
	ret []float64
}

func (cci *CommodityChannelIndex) loadFeaturePrefs() error {
	cci.hlList = cci.prefs.GetIntListPref(cci.featureName + "_hl_list")
	cci.hlLen = len(cci.hlList)
	return nil
}

//setFeatureNames: set column names.
func (cci *CommodityChannelIndex) setFeatureNames() {
	cci.colNames = make([]string, 1*cci.hlLen)
	for i := 0; i < cci.hlLen; i++ {
		cci.colNames[i] = fmt.Sprintf("%s-t%ds", cci.featureName, cci.hlList[i])
	}
	// assign ret memory
	cci.ret = make([]float64, len(cci.colNames))
}

//initialize internal variables'
func (cci *CommodityChannelIndex) initInternalVars() {
	cci.FeatureBase.initInternalVars()
	cci.lastPrice = map[int]float64{}
	cci.dataMa = map[int]*MU.MA{}
	for sid := range cci.sidUniverse {
		cci.dataMa[sid] = MU.NewMA(cci.hlList)
		cci.lastPrice[sid] = 0.0
	}
}

//Update
func (cci *CommodityChannelIndex) UpdateValue(sid int, price float64) bool {
	if _, ok := cci.sidUniverse[sid]; !ok {
		return false
	}

	cci.lastPrice[sid] = price
	cci.dataMa[sid].Add(price)

	return true
}

//GetValues
func (cci *CommodityChannelIndex) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return cci.GetSidValues(cci.baseSid, mPrice, secEpoch)
}

func (cci *CommodityChannelIndex) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	if _, ok := cci.lastPrice[sid]; !ok {
		for i := 0; i < len(cci.ret); i++ {
			cci.ret[i] = 0
		}
		return cci.ret, nil
	}
	for i := 0; i < cci.hlLen; i++ {
		tmp := cci.lastPrice[sid] - cci.dataMa[sid].GetMeanIdx(i)
		s := cci.dataMa[sid].GetL1StdDevIdx(i)
		if s <= 0 {
			s = 1e8
		}
		cci.ret[i] = tmp / s / 0.015
	}
	return cci.ret, nil
}

//RelativeStrengthIndex indicators based on relative strength index.
type RelativeStrengthIndex struct {
	FeatureBase
	hlList    []int
	hlLen     int
	lastPrice map[int]float64
	cnt       map[int]float64
	uMa, dMa  map[int]*MU.MA
	rsi       map[int][]float64
}

func (rsi *RelativeStrengthIndex) loadFeaturePrefs() error {
	rsi.hlList = rsi.prefs.GetIntListPref(rsi.featureName + "_hl_list")
	rsi.hlLen = len(rsi.hlList)
	return nil
}

//setFeatureNames: set column names.
func (rsi *RelativeStrengthIndex) setFeatureNames() {
	rsi.colNames = make([]string, 1*rsi.hlLen)
	for i := 0; i < rsi.hlLen; i++ {
		rsi.colNames[i] = fmt.Sprintf("%s-t%ds", rsi.featureName, rsi.hlList[i])
	}
}

//initialize internal variables'
func (rsi *RelativeStrengthIndex) initInternalVars() {
	rsi.FeatureBase.initInternalVars()
	rsi.lastPrice = map[int]float64{}
	rsi.cnt = map[int]float64{}
	rsi.uMa = map[int]*MU.MA{}
	rsi.dMa = map[int]*MU.MA{}
	rsi.rsi = map[int][]float64{}
	for sid := range rsi.sidUniverse {
		rsi.uMa[sid] = MU.NewMA(rsi.hlList)
		rsi.dMa[sid] = MU.NewMA(rsi.hlList)
		rsi.lastPrice[sid] = math.NaN()
		rsi.cnt[sid] = 0.0
		rsi.rsi[sid] = make([]float64, rsi.hlLen)
	}
}

//Update
func (rsi *RelativeStrengthIndex) UpdateValue(sid int, price float64) bool {
	if _, ok := rsi.sidUniverse[sid]; !ok {
		return false
	}
	if !math.IsNaN(rsi.lastPrice[sid]) {
		lp := rsi.lastPrice[sid]
		u := math.Max(price-lp, 0)
		d := math.Max(lp-price, 0)
		rsi.uMa[sid].Add(u)
		rsi.dMa[sid].Add(d)

		rsi.cnt[sid]++

		for i := 0; i < rsi.hlLen; i++ {
			uma := rsi.uMa[sid].GetMeanIdx(i)
			tma := uma + rsi.dMa[sid].GetMeanIdx(i)
			if tma <= 0 {
				uma = 1
				tma = 2
			}
			cnt := rsi.cnt[sid]
			if cnt < 10 {
				rsi.rsi[sid][i] = ((10-cnt)*50 + cnt*100*uma/tma) / 10
			} else {
				rsi.rsi[sid][i] = 100.0 * uma / tma
			}
		}
	} else {
		// for first point set to prior value 50.0
		for i := 0; i < rsi.hlLen; i++ {
			rsi.rsi[sid][i] = 50.0
		}
	}
	rsi.lastPrice[sid] = price

	return true
}

//GetValues
func (rsi *RelativeStrengthIndex) GetValues(mPrice, secEpoch float64) (res []float64, err error) {
	return rsi.GetSidValues(rsi.baseSid, mPrice, secEpoch)
}

func (rsi *RelativeStrengthIndex) GetSidValues(sid int, mPrice, secEpoch float64) (res []float64, err error) {
	if _, ok := rsi.rsi[sid]; !ok {
		res, err = make([]float64, rsi.hlLen), nil
		return
	}
	res = rsi.rsi[sid]
	err = nil
	return
}

//class LaggingBasisReturn.
/*      indicators based on lagging basis returns.
 */

type LaggingBasisReturnSubClass int

const (
	LaggingBasisReturnSingle LaggingBasisReturnSubClass = iota + 1
	LaggingBasisReturnGroup
	LaggingBasisReturnFactor
)

type LaggingBasisReturn struct {
	FeatureBase

	SubClass LaggingBasisReturnSubClass

	hlList                                       []int           //horizon life
	hlLen                                        int             //len of horizon lives will be used many times so it is pre-calculated
	basisOnly                                    bool            //whether it's basis only
	firstNightPrice, firstDayPrice, overNightRet map[int]float64 // first_night_price=prev_close_price(EQ) first_day_price=open_price(EQ)
	secMidNight                                  float64
	secMorning                                   float64
	secArr                                       map[IntPair][]float64
	mpriceArr                                    map[IntPair][]float64

	// Group version variables
	lastMidPrice map[int]float64
	dataRecalc   map[int]bool
	dataLag      *MU.GroupMean
	tmpRet       []float64

	dataLag2 *MU.WeightedNestedGroupMeanFast // for LaggingBasisReturnFactor

	//return
	ret    []float64
	hPrice []float64
}

func (lbr *LaggingBasisReturn) loadFeaturePrefs() error {
	lbr.hlList = lbr.prefs.GetIntListPref(lbr.featureName + "_hl_list")
	lbr.hlLen = len(lbr.hlList)

	switch lbr.SubClass {
	case LaggingBasisReturnGroup, LaggingBasisReturnFactor:
		// no action for Group version/Equity version
	default:
		if lbr.prefs.HasPref(lbr.featureName + "_basis_only") {
			lbr.basisOnly = lbr.prefs.GetBoolPref(lbr.featureName + "_basis_only")
		} else {
			lbr.basisOnly = false
		}
	}
	return nil
}

//setFeatureNames: set column names.
func (lbr *LaggingBasisReturn) setFeatureNames() {
	startIndex := 0

	fillNonBasisNames := func() {
		for i := 0; i < lbr.hlLen; i++ {
			lbr.colNames[i] = fmt.Sprintf("%s-t%ds", lbr.featureName, lbr.hlList[i])
		}
		lbr.colNames[lbr.hlLen] = fmt.Sprintf("%s-tDays", lbr.featureName)
		lbr.colNames[lbr.hlLen+1] = fmt.Sprintf("%s-tNights", lbr.featureName)
		startIndex = lbr.hlLen + 2
	}

	fillNamesWithLabel := func(label string) {
		for i := 0; i < lbr.hlLen; i++ {
			lbr.colNames[startIndex+i] = fmt.Sprintf("%s-%s-t%ds", lbr.featureName, label, lbr.hlList[i])
		}
		lbr.colNames[startIndex+lbr.hlLen] = fmt.Sprintf("%s-%s-tDays", lbr.featureName, label)
		lbr.colNames[startIndex+lbr.hlLen+1] = fmt.Sprintf("%s-%s-tNights", lbr.featureName, label)
		startIndex += lbr.hlLen + 2
	}

	switch lbr.SubClass {
	case LaggingBasisReturnFactor:
		lbr.colNames = make([]string, 5*(lbr.hlLen+2))
		fillNamesWithLabel("m")
		fillNamesWithLabel("im")
		fillNamesWithLabel("cm")
		fillNamesWithLabel("ir")
		fillNamesWithLabel("cr")

	case LaggingBasisReturnGroup:
		lbr.colNames = make([]string, 2*(lbr.hlLen+2))
		fillNonBasisNames()
		// add -g feature names
		for i := 0; i < lbr.hlLen; i++ {
			lbr.colNames[startIndex+i] = fmt.Sprintf("%s-g-t%ds", lbr.featureName, lbr.hlList[i])
		}
		lbr.colNames[startIndex+lbr.hlLen] = fmt.Sprintf("%s-g-tDays", lbr.featureName)
		lbr.colNames[startIndex+lbr.hlLen+1] = fmt.Sprintf("%s-g-tNights", lbr.featureName)

	case LaggingBasisReturnSingle:
		lb := len(lbr.basisNames)
		if lbr.basisOnly {
			lbr.colNames = make([]string, lb*(lbr.hlLen+2))
		} else {
			lbr.colNames = make([]string, (lb+1)*(lbr.hlLen+2))
			fillNonBasisNames()
		}
		for i := 0; i < lb; i++ {
			for j := 0; j < lbr.hlLen; j++ {
				lbr.colNames[startIndex+i*(lbr.hlLen+2)+j] = fmt.Sprintf("%s-%s-t%ds", lbr.featureName,
					lbr.basisNames[i].symbol, lbr.hlList[j])
			}
			lbr.colNames[startIndex+i*(lbr.hlLen+2)+lbr.hlLen] = fmt.Sprintf("%s-%s-tDays", lbr.featureName, lbr.basisNames[i].symbol)
			lbr.colNames[startIndex+i*(lbr.hlLen+2)+lbr.hlLen+1] = fmt.Sprintf("%s-%s-tNights", lbr.featureName, lbr.basisNames[i].symbol)
		}
	}

	// allocate return's memory
	lbr.ret = make([]float64, len(lbr.colNames))

}

//initialize internal variables'
func (lbr *LaggingBasisReturn) initInternalVars() {
	lbr.FeatureBase.initInternalVars()

	if lbr.SubClass == LaggingBasisReturnSingle || lbr.SubClass == LaggingBasisReturnGroup {
		// mid-night (Futures only)
		lbr.secMidNight, _ = common.ParseDateTime2UnixFast([]byte(lbr.dateStr + " 00:00:00"))
		lbr.secMorning = common.GetBeginTimestampOfDay(lbr.dateStr)
	}

	lbr.firstNightPrice = map[int]float64{} //# first price during night session
	lbr.firstDayPrice = map[int]float64{}   //# first price during day session
	lbr.overNightRet = map[int]float64{}    //# overnight return
	lbr.secArr = map[IntPair][]float64{}    //
	lbr.mpriceArr = map[IntPair][]float64{}
	lbr.hPrice = make([]float64, lbr.hlLen+1)

	lbr.tmpRet = make([]float64, lbr.hlLen+2)
	lbr.dataLag = MU.NewGroupMean(lbr.hlLen + 2)
	lbr.dataLag2 = MU.NewWeightedNestedGroupMeanFast(lbr.sidUniverseList, lbr.hlLen+2, lbr.baseSidWgts, lbr.industryCode, lbr.conceptCodes)
	lbr.lastMidPrice = make(map[int]float64)
	lbr.dataRecalc = make(map[int]bool)
	for sid := range lbr.sidUniverse {
		lbr.lastMidPrice[sid] = math.NaN()
		lbr.dataRecalc[sid] = true
	}
}

//Update (Equity)
func (lbr *LaggingBasisReturn) UpdateSecValueSlice(sid int, secSinceEpoch float64, values []float64) bool {
	if lbr.SubClass != LaggingBasisReturnFactor {
		panic("This method only supports LaggingBasisReturnFactor SubClass")
	}

	if _, ok := lbr.sidUniverse[sid]; !ok {
		return false
	}

	midPrice, prevClosePrice, openPrice := values[0], values[1], values[2]

	//Note that: firstNightPrice(Futs) = prev_close_price(Eq)
	//           firstDayPrice(Futs) = open_price(Eq)

	if _, ok := lbr.firstNightPrice[sid]; !ok && !math.IsNaN(prevClosePrice) && prevClosePrice > 0 {
		//set first price in night session
		lbr.firstNightPrice[sid] = prevClosePrice
	}
	if _, ok := lbr.firstDayPrice[sid]; !ok && !math.IsNaN(openPrice) && openPrice > 0 {
		//set first price in day session
		lbr.firstDayPrice[sid] = openPrice
		// calculate overnight return
		lbr.overNightRet[sid] = math.Log(openPrice) - math.Log(lbr.firstNightPrice[sid])
	}

	lbr.lastMidPrice[sid] = midPrice
	lbr.dataRecalc[sid] = true

	// update lagging return stats
	// use mid-price to update horizon deck
	for i, hl := range lbr.hlList {
		k := IntPair{sid, i}
		if _, ok := lbr.secArr[k]; !ok {
			lbr.secArr[k] = make([]float64, 0, 48)
			lbr.mpriceArr[k] = make([]float64, 0, 48)
		}
		lbr.secArr[k] = append(lbr.secArr[k], secSinceEpoch+float64(hl))
		lbr.mpriceArr[k] = append(lbr.mpriceArr[k], math.Log(midPrice))
		/*
					# here we are checking if the second element is also at least
			            # hrz seconds away. If yes then the first element is no longer
			            # needed. WARNING: possible bug here if src time are not in
			            # order. We have checked if received time is in order, but
			            # we haven't checked if source time is in order
		*/
		for len(lbr.secArr[k]) >= 2 && lbr.secArr[k][1] <= secSinceEpoch {
			lbr.secArr[k] = lbr.secArr[k][1:]
			lbr.mpriceArr[k] = lbr.mpriceArr[k][1:]
		}
	}
	return true
}

//Update (Futures)
func (lbr *LaggingBasisReturn) UpdateSecValue(sid int, secSinceEpoch, midPrice float64) bool {
	if lbr.SubClass != LaggingBasisReturnSingle && lbr.SubClass != LaggingBasisReturnGroup {
		panic("UpdateSecValue only supports Futures (Single+Group) SubClass")
	}

	if _, ok := lbr.sidUniverse[sid]; !ok {
		return false
	}
	if _, ok := lbr.firstNightPrice[sid]; !ok && secSinceEpoch < lbr.secMorning-3600 {
		//set first price in night session
		lbr.firstNightPrice[sid] = midPrice
	} else if _, ok := lbr.firstDayPrice[sid]; !ok && secSinceEpoch >= lbr.secMorning {
		//set first price in day session
		lbr.firstDayPrice[sid] = midPrice
		if _, ok = lbr.firstNightPrice[sid]; !ok {
			// in case there is no night session
			lbr.firstNightPrice[sid] = midPrice
		}
		// calculate overnight return
		lbr.overNightRet[sid] = math.Log(midPrice) - math.Log(lbr.firstNightPrice[sid])
	}

	switch lbr.SubClass {
	case LaggingBasisReturnGroup:
		lbr.lastMidPrice[sid] = midPrice
		lbr.dataRecalc[sid] = true
	}

	// update lagging return stats
	// use mid-price to update horizon deck
	for i, hl := range lbr.hlList {
		k := IntPair{sid, i}
		if _, ok := lbr.secArr[k]; !ok {
			lbr.secArr[k] = make([]float64, 0, 48)
			lbr.mpriceArr[k] = make([]float64, 0, 48)
		}
		lbr.secArr[k] = append(lbr.secArr[k], secSinceEpoch+float64(hl))
		lbr.mpriceArr[k] = append(lbr.mpriceArr[k], math.Log(midPrice))
		/*
					# here we are checking if the second element is also at least
			            # hrz seconds away. If yes then the first element is no longer
			            # needed. WARNING: possible bug here if src time are not in
			            # order. We have checked if received time is in order, but
			            # we haven't checked if source time is in order
		*/
		for len(lbr.secArr[k]) >= 2 && lbr.secArr[k][1] <= secSinceEpoch {
			lbr.secArr[k] = lbr.secArr[k][1:]
			lbr.mpriceArr[k] = lbr.mpriceArr[k][1:]
		}
	}
	return true
}

func (lbr *LaggingBasisReturn) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	if lbr.SubClass != LaggingBasisReturnGroup && lbr.SubClass != LaggingBasisReturnFactor {
		panic("GetSidValues method in LaggingBasisReturn only work in Group/Factor mode")
	}

	//# in some rare cases get_values is called before update
	if lbr.SubClass == LaggingBasisReturnGroup {
		if _, ok := lbr.secArr[IntPair{sid, 0}]; !ok {
			lbr.UpdateSecValue(sid, secEpoch, mPrice)
		}
	}

	for _, _sid := range lbr.sidUniverseList {
		if lbr.SubClass == LaggingBasisReturnFactor && !lbr.dataRecalc[_sid] {
			continue
		}
		if _, ok := lbr.secArr[IntPair{_sid, 0}]; !ok {
			continue
		}
		_midPrice := lbr.lastMidPrice[_sid]
		lbr.hPrice[0] = math.Log(_midPrice)
		for h := 0; h < lbr.hlLen; h++ {
			lbr.hPrice[h+1] = lbr.mpriceArr[IntPair{_sid, h}][0]
			lbr.tmpRet[h] = lbr.hPrice[h+1] - lbr.hPrice[h]
		}

		retSinceMorning := 0.0
		if fdp, ok := lbr.firstDayPrice[_sid]; ok {
			//add day return
			retSinceMorning = lbr.hPrice[lbr.hlLen] - math.Log(fdp)
		}
		lbr.tmpRet[lbr.hlLen] = retSinceMorning //day return

		retOvernight := 0.0
		if onr, ok := lbr.overNightRet[_sid]; ok {
			//add overnight return
			retOvernight = onr
		}
		lbr.tmpRet[lbr.hlLen+1] = retOvernight //overnight return

		switch lbr.SubClass {
		case LaggingBasisReturnFactor:
			lbr.dataLag2.Update(_sid, lbr.tmpRet)
		case LaggingBasisReturnGroup:
			lbr.dataLag.Update(_sid, lbr.tmpRet)
		}

		lbr.dataRecalc[_sid] = false
	}

	switch lbr.SubClass {
	case LaggingBasisReturnFactor:
		lbr.dataLag2.GetValue(sid, lbr.ret)
	case LaggingBasisReturnGroup:
		lbr.dataLag.GetValue(sid, lbr.ret)
	}

	return lbr.ret, nil
}

//GetValues
func (lbr *LaggingBasisReturn) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	if lbr.SubClass != LaggingBasisReturnSingle {
		panic("GetValues method in LaggingBasisReturn only work in Single mode")
	}
	//lbr.hPrice[0] = math.Log(mPrice)
	prevPrice := math.Log(mPrice)
	lbr.hPrice[0] = prevPrice
	startIndex := 0
	ipk := IntPair{lbr.baseSid, 0}
	retSinceMorning := 0.0
	retOvernight := 0.0

	if !lbr.basisOnly { //add base sid's lagging horizon returns to output
		if _, ok := lbr.secArr[ipk]; ok {
			//# retrieve horizon mid-price from horizon deck
			for i := 0; i < lbr.hlLen; i++ {
				ipk.v2 = i
				lbr.ret[i] = lbr.mpriceArr[ipk][0] - prevPrice
				prevPrice = lbr.mpriceArr[ipk][0]
				lbr.hPrice[i+1] = prevPrice
			}
		} else {
			// defalt 0
			for i := 0; i < lbr.hlLen; i++ {
				lbr.ret[i] = 0 - prevPrice
				prevPrice = 0
				lbr.hPrice[i+1] = 0
			}
		}
		// return since morning

		if fdp, ok := lbr.firstDayPrice[lbr.baseSid]; ok {
			//add day return
			retSinceMorning = prevPrice - math.Log(fdp)
		}
		lbr.ret[lbr.hlLen] = retSinceMorning //day return

		if onr, ok := lbr.overNightRet[lbr.baseSid]; ok {
			//add overnight return
			retOvernight = onr
		}
		lbr.ret[lbr.hlLen+1] = retOvernight //overnight return
		startIndex = lbr.hlLen + 2
	} else { // basis only == true
		if _, ok := lbr.secArr[ipk]; ok {
			//# retrieve horizon mid-price from horizon deck
			for i := 0; i < lbr.hlLen; i++ {
				ipk.v2 = i
				lbr.ret[i] = lbr.mpriceArr[ipk][0] - prevPrice
				prevPrice = lbr.mpriceArr[ipk][0]
				lbr.hPrice[i+1] = prevPrice
			}
		} else {
			// defalt 0
			for i := 0; i < lbr.hlLen; i++ {
				lbr.ret[i] = 0 - prevPrice
				prevPrice = 0
				lbr.hPrice[i+1] = 0
			}
		}
	}
	var bPrevPrice float64 = 0.0
	//add lagging basis returns to output
	for _, sid := range lbr.basisList {
		ipk.v1 = sid
		ipk.v2 = 0
		if _, ok := lbr.secArr[ipk]; ok {
			bPrevPrice = lbr.mpriceArr[ipk][len(lbr.mpriceArr[ipk])-1] - lbr.hPrice[0]
			//# retrieve horizon mid-price from horizon deck
			for i := 0; i < lbr.hlLen; i++ {
				ipk.v2 = i
				lbr.ret[startIndex+i] = lbr.mpriceArr[ipk][0] - lbr.hPrice[i+1] - bPrevPrice
				bPrevPrice = lbr.mpriceArr[ipk][0] - lbr.hPrice[i+1]
			}
		} else {
			// defalt 0
			for i := 0; i < lbr.hlLen; i++ {
				lbr.ret[startIndex+i] = 0
			}
		}
		startIndex += lbr.hlLen
		// now add return since morning open and overnight.

		if fdp, ok := lbr.firstDayPrice[sid]; ok {
			lbr.ret[startIndex] = bPrevPrice + prevPrice - math.Log(fdp) - retSinceMorning
		} else {
			lbr.ret[startIndex] = 0 - retSinceMorning
		}
		if onr, ok := lbr.overNightRet[sid]; ok {
			lbr.ret[startIndex+1] = onr - retOvernight
		} else {
			lbr.ret[startIndex+1] = 0 - retOvernight
		}
		startIndex += 2
	}
	return lbr.ret, nil
}

//class TradeOpenInterestEMA.
/*     indicators based on ema of trade and open interest (normalized)
 */
type TradeOpenInterestEMA struct {
	FeatureBase
	hlList                                                                       []int //horizon life
	hlLen                                                                        int   //len of horizon lives will be used many times so it is pre-calculated
	pow                                                                          float64
	tradeSizeEMA, quoteSizeEMA, nvData1Ema, nvData2Ema, doiData1Ema, doiData2Ema map[int]*MU.EMA

	//return
	ret []float64
}

func (toie *TradeOpenInterestEMA) loadFeaturePrefs() error {
	toie.hlList = toie.prefs.GetIntListPref(toie.featureName + "_hl_list")
	toie.hlLen = len(toie.hlList)
	toie.pow = toie.prefs.GetFloat64Pref(toie.featureName + "_power")

	return nil
}

//setFeatureNames: set column names.
func (toie *TradeOpenInterestEMA) setFeatureNames() {
	toie.colNames = make([]string, 4*toie.hlLen)

	for i := 0; i < toie.hlLen; i++ {
		toie.colNames[i] = fmt.Sprintf("%s-trade1-t%ds", toie.featureName, toie.hlList[i])
		toie.colNames[toie.hlLen+i] = fmt.Sprintf("%s-trade2-t%ds", toie.featureName, toie.hlList[i])
		toie.colNames[toie.hlLen*2+i] = fmt.Sprintf("%s-OI1-t%ds", toie.featureName, toie.hlList[i])
		toie.colNames[toie.hlLen*3+i] = fmt.Sprintf("%s-OI2-t%ds", toie.featureName, toie.hlList[i])
	}

	// allocate return's memory
	toie.ret = make([]float64, len(toie.colNames))

}

//initialize internal variables'
func (toie *TradeOpenInterestEMA) initInternalVars() {
	toie.FeatureBase.initInternalVars()
	// mid-night
	toie.tradeSizeEMA = map[int]*MU.EMA{}
	toie.quoteSizeEMA = map[int]*MU.EMA{}
	toie.nvData1Ema = map[int]*MU.EMA{}
	toie.nvData2Ema = map[int]*MU.EMA{}
	toie.doiData1Ema = map[int]*MU.EMA{}
	toie.doiData2Ema = map[int]*MU.EMA{}
	for sid := range toie.sidUniverse {
		toie.tradeSizeEMA[sid] = MU.NewEMA([]int{toie.hlList[toie.hlLen-1]})
		toie.quoteSizeEMA[sid] = MU.NewEMA([]int{toie.hlList[toie.hlLen-1]})
		toie.nvData1Ema[sid] = MU.NewEMA(toie.hlList)
		toie.nvData2Ema[sid] = MU.NewEMA(toie.hlList)
		toie.doiData1Ema[sid] = MU.NewEMA(toie.hlList)
		toie.doiData2Ema[sid] = MU.NewEMA(toie.hlList)
	}
}

//Update
func (toie *TradeOpenInterestEMA) UpdateSecValueSlice(sid int, secSinceEpoch float64, valueSlice []float64) bool {
	if _, ok := toie.sidUniverse[sid]; !ok {
		return false
	}
	netVolume, sizeTrade, quoteSize, oiDelta := valueSlice[0], valueSlice[1], valueSlice[2], valueSlice[3]
	toie.tradeSizeEMA[sid].Add(sizeTrade, secSinceEpoch)
	toie.quoteSizeEMA[sid].Add(quoteSize, secSinceEpoch)
	toie.nvData1Ema[sid].Add(powerTransform(netVolume/toie.tradeSizeEMA[sid].GetMeanIdx(0), toie.pow), secSinceEpoch)
	toie.nvData2Ema[sid].Add(powerTransform(netVolume/toie.quoteSizeEMA[sid].GetMeanIdx(0), toie.pow), secSinceEpoch)
	toie.doiData1Ema[sid].Add(powerTransform(oiDelta/toie.tradeSizeEMA[sid].GetMeanIdx(0), toie.pow), secSinceEpoch)
	toie.doiData2Ema[sid].Add(powerTransform(oiDelta/toie.quoteSizeEMA[sid].GetMeanIdx(0), toie.pow), secSinceEpoch)

	return true
}

//GetValues
func (toie *TradeOpenInterestEMA) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return toie.GetSidValues(toie.baseSid, mPrice, secEpoch)
}

func (toie *TradeOpenInterestEMA) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	toie.nvData1Ema[sid].GetImpulseMean(secEpoch, toie.ret[:toie.hlLen])
	toie.nvData2Ema[sid].GetImpulseMean(secEpoch, toie.ret[toie.hlLen:toie.hlLen*2])
	toie.doiData1Ema[sid].GetImpulseMean(secEpoch, toie.ret[toie.hlLen*2:toie.hlLen*3])
	toie.doiData2Ema[sid].GetImpulseMean(secEpoch, toie.ret[toie.hlLen*3:])
	return toie.ret, nil
}

//class StochasticOscillator.
/*     indicators based on ema of trade and open interest (normalized)
 */
type StochasticOscillator struct {
	FeatureBase
	hlList []int //horizon life
	hlLen  int   //len of horizon lives will be used many times so it is pre-calculated

	lowMA, highMA map[int]*MU.MA
	soMA          map[int]map[int]*MU.MA //map[sid]->map[idx]->ma
	pctD          map[int][]float64
	//return
	//ret []float64
}

func (so *StochasticOscillator) loadFeaturePrefs() error {
	so.hlList = so.prefs.GetIntListPref(so.featureName + "_hl_list")
	so.hlLen = len(so.hlList)

	return nil
}

//setFeatureNames: set column names.
func (so *StochasticOscillator) setFeatureNames() {
	so.colNames = make([]string, 1*so.hlLen)

	for i := 0; i < so.hlLen; i++ {
		so.colNames[i] = fmt.Sprintf("%s-t%ds", so.featureName, so.hlList[i])
	}

	// allocate return's memory
	//so.ret = make([]float64, len(so.colNames))

}

//initialize internal variables'
func (so *StochasticOscillator) initInternalVars() {
	so.FeatureBase.initInternalVars()
	// mid-night
	so.lowMA = map[int]*MU.MA{}
	so.highMA = map[int]*MU.MA{}
	so.soMA = map[int]map[int]*MU.MA{}
	so.pctD = map[int][]float64{}
	for sid := range so.sidUniverse {
		so.lowMA[sid] = MU.NewMA(so.hlList)
		so.highMA[sid] = MU.NewMA(so.hlList)
		so.soMA[sid] = map[int]*MU.MA{}
		for i := 0; i < so.hlLen; i++ {
			ii := int(math.RoundToEven(float64(so.hlList[i]) / 2.0)) //np.Round if round to floor.
			so.soMA[sid][i] = MU.NewMA([]int{ii})
		}
		so.pctD[sid] = make([]float64, so.hlLen)

	}
	so.pctD[-1] = make([]float64, so.hlLen)
}

//Update
func (so *StochasticOscillator) UpdateValueSlice(sid int, valueSlice []float64) bool {
	if _, ok := so.sidUniverse[sid]; !ok {
		return false
	}
	high, low, last := valueSlice[0], valueSlice[1], valueSlice[2]
	so.lowMA[sid].Add(low)
	so.highMA[sid].Add(high)
	for i := 0; i < so.hlLen; i++ {
		l := so.lowMA[sid].GetMeanIdx(i)
		h := so.highMA[sid].GetMeanIdx(i)
		rng := h - l
		if rng == 0 {
			rng = 1e8
		}
		k := (last - l) / rng
		if math.IsNaN(k) {
			k = 0
		}

		so.soMA[sid][i].Add(k)
		//calculate percentage
		so.pctD[sid][i] = 100 * so.soMA[sid][i].GetMeanIdx(0)
	}
	return true
}

//GetValues
func (so *StochasticOscillator) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return so.GetSidValues(so.baseSid, mPrice, secEpoch)
}

func (so *StochasticOscillator) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	if _, ok := so.pctD[sid]; ok {
		return so.pctD[sid], nil
	} else { //I think this will never happen.
		return so.pctD[-1], nil
	}
}

//---Common methods for book features getValues methods usage.
// added by Yingfa 20180523

//EMAImpulseMean4Func
// golang version of emav2_impulse_mean_4func
func bfEMAImpulseMean4Func(priceArr []float64, priceEmaMap map[float64]*MU.EMA, mPrice, secEpoch float64, hllen int, output []float64) error {
	//if len(output) != hllen*4 {
	//	return errors.New("Length of output result slice should be 4 times of 'hllen'. ")
	//}
	plen := len(priceEmaMap)

	//sort the price arr increasingly.
	sort.Float64s(priceArr)

	tmpSizeArr := make([]float64, plen)
	//middle values:
	for i := 0; i < hllen; i++ {
		for j := 0; j < plen; j++ {
			tmpSizeArr[j] = priceEmaMap[priceArr[j]].GetImpulseMeanIdx(i, secEpoch) //sizeArr2D[j][i]
		}
		output[i] = calcBuySellRatioV2(tmpSizeArr)
		output[hllen+i] = calcBuySellSpread(priceArr, tmpSizeArr, mPrice)
		tmpAbsSizeArr := MU.ArrAbs(tmpSizeArr) // this will not allocate memory again. Just an alias.
		output[hllen*2+i] = bfCalcTstat(priceArr, tmpAbsSizeArr, mPrice)
		output[hllen*3+i] = bfCalcDev(priceArr, tmpAbsSizeArr, mPrice)
	}
	return nil
}

//EMAImpulseMean2Func
// golang version of get_values_emav2_impulse_mean_2func
func bfEMAImpulseMean2Func(priceArr []float64, priceEmaMap map[float64]*MU.EMA, mPrice, secEpoch float64, hllen int, output []float64) error {
	//if len(output) != hllen*2 {
	//	return errors.New("Length of output result slice should be 2 times of 'hllen'. ")
	//}
	plen := len(priceEmaMap)

	//sort the price arr increasingly.
	sort.Float64s(priceArr)

	//tmpSizeArr := make([]float64, plen)
	tmpAbsSizeArr := make([]float64, plen)
	//middle values:
	for i := 0; i < hllen; i++ {
		for j := 0; j < plen; j++ {
			tmpAbsSizeArr[j] = math.Abs(priceEmaMap[priceArr[j]].GetImpulseMeanIdx(i, secEpoch))
		}
		output[i] = bfCalcTstat(priceArr, tmpAbsSizeArr, mPrice)
		output[hllen+i] = bfCalcDev(priceArr, tmpAbsSizeArr, mPrice)
	}
	return nil
}

//EMAMean4Func
// golang version of get_values_emav2_mean_4func
func bfEMAMean4Func(priceArr []float64, priceEmaMap map[float64]*MU.EMA, mPrice float64, hllen int, output []float64) error {
	//if len(output) != hllen*4 {
	//	return errors.New("Length of output result slice should be 4 times of 'hllen'. ")
	//}
	plen := len(priceEmaMap)

	//sort the price arr increasingly.
	sort.Float64s(priceArr)

	tmpSizeArr := make([]float64, plen)
	//middle values:
	for i := 0; i < hllen; i++ {
		for j := 0; j < plen; j++ {
			tmpSizeArr[j] = priceEmaMap[priceArr[j]].GetMeanIdx(i) //sizeArr2D[j][i]
			//tmpAbsSizeArr[j] = math.Abs(sizeArr2D[j][i])
		}
		output[i] = calcBuySellRatioV2(tmpSizeArr)
		output[hllen+i] = calcBuySellSpread(priceArr, tmpSizeArr, mPrice)
		tmpAbsSizeArr := MU.ArrAbs(tmpSizeArr) // this will not allocate memory again.
		output[hllen*2+i] = bfCalcTstat(priceArr, tmpAbsSizeArr, mPrice)
		output[hllen*3+i] = bfCalcDev(priceArr, tmpAbsSizeArr, mPrice)
	}
	return nil
}

//bfCalcDev: calc_dev in book_features_toolkits.pyx
// returns deviation of mid_price (in log terms), with respect to the book price distribution
// parameter abssa is Abs(size array). As the input part have the loop already. Pass it here would reduce some calculation efforts.
func bfCalcDev(pa, abssa []float64, midPrice float64) float64 {
	absSas := MU.SumFloatSlice(abssa)
	if absSas == 0 {
		return 0
	}
	m := MU.ArrMultiplyArrAndSum(pa, abssa, false) / absSas

	return math.Log(midPrice) - math.Log(m)
}

//bfCalcTstat: book features calc_tstat in book_features_toolkits.pyx
// returns t-stat of mid_price with respect to the book price distribution
func bfCalcTstat(priceArray, absSa []float64, midPrice float64) float64 {
	sas := MU.SumFloatSlice(absSa)
	if sas <= 1e-6 {
		return 0.0
	}
	m := MU.CalcMeanFloatSlice(priceArray, absSa)
	var v float64 = 0.0
	for i := 0; i < len(priceArray); i++ {
		v += (priceArray[i] - m) * (priceArray[i] - m) * absSa[i]
	}
	v = v / sas
	if v <= 1e-6 {
		return 0.0
	}
	r := (midPrice - m) / math.Sqrt(v/sas)
	return r
	//return MU.ClipFloat(r, -100, 100)
}

//bfCalcAvgPrice: calc_avg_price in detrend_book_features_toolkits.pyx
func bfCalcAvgPrice(pa, sa []float64) float64 {
	absSas := MU.SumAbsFloatSlice(sa)
	if absSas == 0 {
		return 0.0
	}
	s := MU.ArrMultiplyAbsArrAndSum(pa, sa) / absSas
	return s
}
