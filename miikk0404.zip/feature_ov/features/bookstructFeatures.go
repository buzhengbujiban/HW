// yzhu, 2020-3-12, new features from the book data structures
package feature

import (
	hastats "TES/QR/hastats/model"
	"fmt"
	"math"

	"TES/QR/alpha_ov/data"
	MU "TES/QR/alpha_ov/mathUtils"
)

type TSFuncName int

const (
	TSFuncEMA TSFuncName = iota
	TSFuncLast
)

type TSFuncFeature struct {
	FeatureBase
	SidIdxMap

	nHL      int
	hlList   []int
	funcName TSFuncName
	doCross  bool // use cross section operator

	crosser *MU.WeightedNestedGroupMeanFast

	//
	funcs     []ITSFunc // func vec
	perSidVec []float64 // feature vec before cross op

	//return
	ret []float64
}

func (feat *TSFuncFeature) loadFeaturePrefs() error {
	if feat.prefs.HasPref(feat.featureName + "_hl_list") {
		feat.hlList = feat.prefs.GetIntListPref(feat.featureName + "_hl_list")
	} else {
		// make a dummy horizon
		feat.hlList = make([]int, 1, 1)
		feat.hlList[0] = 0
	}
	feat.doCross = feat.prefs.GetBoolPref(feat.featureName + "_do_cross")
	funcName := feat.prefs.GetStringPref(feat.featureName + "_func_name")
	switch funcName {
	case "EMA":
		feat.funcName = TSFuncEMA
	case "Last":
		feat.funcName = TSFuncLast
	default:
		panic(fmt.Sprintf("Unknown func_name in TSFuncFeature: %s", funcName))
	}
	feat.nHL = len(feat.hlList)
	return nil
}

func (feat *TSFuncFeature) setFeatureNames() {
	if feat.doCross {
		// 1 feat * 5 group vals * nHL versions
		feat.colNames = make([]string, 5*feat.nHL)
		i := 0
		{
			for j := 0; j < feat.nHL; j++ {
				feat.colNames[i*5*feat.nHL+j] = fmt.Sprintf("%s-m-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+feat.nHL+j] = fmt.Sprintf("%s-im-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+2*feat.nHL+j] = fmt.Sprintf("%s-cm-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+3*feat.nHL+j] = fmt.Sprintf("%s-ir-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+4*feat.nHL+j] = fmt.Sprintf("%s-cr-%ds", feat.featureName, feat.hlList[j])
			}
		}
	} else {
		// per feat * nHL versions
		feat.colNames = make([]string, feat.nHL)
		i := 0
		{
			for j := 0; j < feat.nHL; j++ {
				feat.colNames[i*feat.nHL+j] = fmt.Sprintf("%s-%ds", feat.featureName, feat.hlList[j])
			}
		}
	}

	// allocate ret memory
	feat.ret = make([]float64, len(feat.colNames))
}

func (feat *TSFuncFeature) initInternalVars() {
	feat.FeatureBase.initInternalVars()
	feat.SidIdxMap.Init(feat.sidUniverseList)

	// init cross sectional op
	if feat.doCross {
		feat.crosser = MU.NewWeightedNestedGroupMeanFast(feat.sidUniverseList, len(feat.hlList), feat.baseSidWgts, feat.industryCode, feat.conceptCodes)
	}

	// init
	feat.perSidVec = make([]float64, feat.nHL)
	feat.funcs = make([]ITSFunc, feat.nSids)
	for i := 0; i < feat.nSids; i++ {
		switch feat.funcName {
		case TSFuncEMA:
			feat.funcs[i] = NewEMA(feat.hlList)
		case TSFuncLast:
			feat.funcs[i] = NewLastValue()
		default:
			panic("Unknown funcName")
		}
	}
}

func (feat *TSFuncFeature) UpdateSecValue(sid int, secSinceEpoch float64, value float64) bool {
	if idx, ok := feat.sid2idx[sid]; ok {
		feat.funcs[idx].Update(secSinceEpoch, value)
		return true
	} else {
		return false
	}
}

func (feat *TSFuncFeature) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return feat.GetSidValues(feat.baseSid, mPrice, secEpoch)
}

func (feat *TSFuncFeature) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	if idx, ok := feat.sid2idx[sid]; ok {
		vals := feat.funcs[idx].Calc(secEpoch)
		if feat.doCross {
			feat.crosser.Update(sid, vals)
			feat.crosser.GetValue(sid, feat.ret)
		} else { // no cross
			copy(feat.ret, vals)
		}
	} else {
		for i := 0; i < len(feat.ret); i++ {
			feat.ret[i] = 0
		}
	}
	//
	return feat.ret, nil
}

type LastValueFeature struct {
	FeatureBase
	SidIdxMap
	CrosserMixin

	valueNames []string // similar to hlList
	nValues    int

	//
	lastValues [][]float64
	perSidVec  []float64 // feature vec before cross op

	//return
	ret []float64
}

func (feat *LastValueFeature) loadFeaturePrefs() error {
	feat.valueNames = feat.prefs.GetStringListPref(feat.featureName + "_names")
	feat.nValues = len(feat.valueNames)

	feat.crosserName = feat.prefs.GetStringPref(feat.featureName + "_crosser")
	feat.doCross = feat.crosserName != "" && feat.crosserName != "none"

	return nil
}

func (feat *LastValueFeature) setFeatureNames() {
	if feat.doCross {
		if feat.crosserName == "nest" {
			// 1 feat * 5 group vals * nHL versions
			feat.colNames = make([]string, 5*feat.nValues)
			i := 0
			{
				for j := 0; j < feat.nValues; j++ {
					feat.colNames[i*5*feat.nValues+j] = fmt.Sprintf("%s-m-%s", feat.featureName, feat.valueNames[j])
					feat.colNames[i*5*feat.nValues+feat.nValues+j] = fmt.Sprintf("%s-im-%s", feat.featureName, feat.valueNames[j])
					feat.colNames[i*5*feat.nValues+2*feat.nValues+j] = fmt.Sprintf("%s-cm-%s", feat.featureName, feat.valueNames[j])
					feat.colNames[i*5*feat.nValues+3*feat.nValues+j] = fmt.Sprintf("%s-ir-%s", feat.featureName, feat.valueNames[j])
					feat.colNames[i*5*feat.nValues+4*feat.nValues+j] = fmt.Sprintf("%s-cr-%s", feat.featureName, feat.valueNames[j])
				}
			}
		} else if feat.crosserName == "barrastyle" || feat.crosserName == "barrafull" {
			feat.colNames = make([]string, 2*feat.nValues)
			label := "s"
			if feat.crosserName == "barrafull" {
				label = "b"
			}
			for i := 0; i < feat.nValues; i++ {
				feat.colNames[feat.nValues*0+i] = fmt.Sprintf("%s-%s-%sr", feat.featureName, feat.valueNames[i], label)
				feat.colNames[feat.nValues*1+i] = fmt.Sprintf("%s-%s-%sm", feat.featureName, feat.valueNames[i], label)
			}
		} else {
			panic(fmt.Sprintf("Unknown crosser name: %s", feat.crosserName))
		}
	} else {
		// per feat * nHL versions
		feat.colNames = make([]string, feat.nValues)
		i := 0
		{
			for j := 0; j < feat.nValues; j++ {
				feat.colNames[i*feat.nValues+j] = fmt.Sprintf("%s-%s", feat.featureName, feat.valueNames[j])
			}
		}
	}

	// allocate ret memory
	feat.ret = make([]float64, len(feat.colNames))
}

func (feat *LastValueFeature) initInternalVars() {
	feat.FeatureBase.initInternalVars()
	feat.SidIdxMap.Init(feat.sidUniverseList)

	// init cross sectional op
	if feat.doCross {
		panelRoot := PanelRootInFeature
		switch feat.crosserName {
		case "nest":
			feat.crosser = MU.NewWeightedNestedGroupMeanFast(feat.sidUniverseList, feat.nValues, feat.baseSidWgts, feat.industryCode, feat.conceptCodes)
		case "barrastyle":
			feat.crosser = MU.NewBarraCrosser(panelRoot, feat.dateStr, feat.sidUniverseList, feat.nValues, true, MU.BarraStyleCrosser)
		case "barrafull":
			feat.crosser = MU.NewBarraCrosser(panelRoot, feat.dateStr, feat.sidUniverseList, feat.nValues, true, MU.BarraFullCrosser)
		default:
			panic(fmt.Sprintf("Unknown crosser name: %s", feat.crosserName))
		}
	}

	// init
	feat.perSidVec = make([]float64, feat.nValues, feat.nValues)
	feat.lastValues = make([][]float64, feat.nSids, feat.nSids)
	for i := 0; i < feat.nSids; i++ {
		feat.lastValues[i] = make([]float64, feat.nValues, feat.nValues)
	}
}

/*
// update only one value
func (feat *LastValueFeature) UpdateSecValue(sid int, secSinceEpoch float64, value float64) bool {
	if idx, ok := feat.sid2idx[sid]; ok {
		feat.funcs[idx].Update(secSinceEpoch, value)
		return true
	} else {
		return false
	}
}
*/

// update a few values
func (feat *LastValueFeature) UpdateSecValueSlice(sid int, secSinceEpoch float64, values []float64) bool {
	if len(values) != feat.nValues {
		panic(fmt.Sprintf("LastValueFeature update error: %s", feat.featureName))
	}

	if idx, ok := feat.sid2idx[sid]; ok {
		copy(feat.lastValues[idx], values)
	}
	return true
}

func (feat *LastValueFeature) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	if idx, ok := feat.sid2idx[sid]; ok {
		vals := feat.lastValues[idx]
		if feat.doCross {
			feat.crosser.Update(sid, vals)
			feat.crosser.GetValue(sid, feat.ret)
		} else { // no cross
			copy(feat.ret, vals)
		}
	} else {
		for i := 0; i < len(feat.ret); i++ {
			feat.ret[i] = 0
		}
	}
	//
	return feat.ret, nil
}

type RatioFeature struct {
	FeatureBase
	SidIdxMap

	nHL     int
	hlList  []int
	doCross bool // use cross section operator

	crosser *MU.WeightedNestedGroupMeanFast

	//
	astat     []ITSFunc
	bstat     []ITSFunc
	perSidVec []float64 // feature vec before cross op

	//return
	ret []float64
}

func (feat *RatioFeature) loadFeaturePrefs() error {
	feat.hlList = feat.prefs.GetIntListPref(feat.featureName + "_hl_list")
	feat.doCross = feat.prefs.GetBoolPref(feat.featureName + "_do_cross")
	feat.nHL = len(feat.hlList)
	return nil
}

func (feat *RatioFeature) setFeatureNames() {
	if feat.doCross {
		// 1 feat * 5 group vals * nHL versions
		feat.colNames = make([]string, 5*feat.nHL)
		i := 0
		{
			for j := 0; j < feat.nHL; j++ {
				feat.colNames[i*5*feat.nHL+j] = fmt.Sprintf("%s-m-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+feat.nHL+j] = fmt.Sprintf("%s-im-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+2*feat.nHL+j] = fmt.Sprintf("%s-cm-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+3*feat.nHL+j] = fmt.Sprintf("%s-ir-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+4*feat.nHL+j] = fmt.Sprintf("%s-cr-%ds", feat.featureName, feat.hlList[j])
			}
		}
	} else {
		// per feat * nHL versions
		feat.colNames = make([]string, feat.nHL)
		i := 0
		{
			for j := 0; j < feat.nHL; j++ {
				feat.colNames[i*feat.nHL+j] = fmt.Sprintf("%s-%ds", feat.featureName, feat.hlList[j])
			}
		}
	}

	// allocate ret memory
	feat.ret = make([]float64, len(feat.colNames))
}

func (feat *RatioFeature) initInternalVars() {
	feat.FeatureBase.initInternalVars()
	feat.SidIdxMap.Init(feat.sidUniverseList)

	// init cross sectional op
	if feat.doCross {
		feat.crosser = MU.NewWeightedNestedGroupMeanFast(feat.sidUniverseList, len(feat.hlList), feat.baseSidWgts, feat.industryCode, feat.conceptCodes)
	}

	// init mid-price books
	feat.perSidVec = make([]float64, feat.nHL)
	feat.astat = make([]ITSFunc, feat.nSids)
	feat.bstat = make([]ITSFunc, feat.nSids)
	for i := 0; i < feat.nSids; i++ {
		feat.astat[i] = NewEMA(feat.hlList)
		feat.bstat[i] = NewEMA(feat.hlList)
	}
}

func (feat *RatioFeature) UpdateSecValueSlice(sid int, secSinceEpoch float64, values []float64) bool {
	a, b := values[0], values[1]

	if idx, ok := feat.sid2idx[sid]; ok {
		feat.astat[idx].Update(secSinceEpoch, a)
		feat.bstat[idx].Update(secSinceEpoch, b)
		return true
	} else {
		return false
	}
}

func (feat *RatioFeature) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return feat.GetSidValues(feat.baseSid, mPrice, secEpoch)
}

func (feat *RatioFeature) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	if idx, ok := feat.sid2idx[sid]; ok {
		as := feat.astat[idx].Calc(secEpoch)
		bs := feat.bstat[idx].Calc(secEpoch)
		vals := make([]float64, feat.nHL)
		calc := func(a float64, b float64) float64 {
			s := a + b
			if math.Abs(s) < 1e-4 {
				return 0
			} else {
				return (a - b) / (a + b)
			}
		}
		for i := 0; i < feat.nHL; i++ {
			vals[i] = calc(as[i], bs[i])
		}
		if feat.doCross {
			feat.crosser.Update(sid, vals)
			feat.crosser.GetValue(sid, feat.ret)
		} else { // no cross
			copy(feat.ret, vals)
		}
	} else {
		for i := 0; i < len(feat.ret); i++ {
			feat.ret[i] = 0
		}
	}
	//
	return feat.ret, nil
}

type BookFeatCalc int

const (
	BookFeatTopPressure BookFeatCalc = iota
	BookFeatPressure2
	BookFeatPressure3
	BookFeatPressure4
	BookFeatMPBSR
	BookFeatMPBSS
	BookFeatMPDEV
)

var BookFeatCalc2NumFeats = map[BookFeatCalc]int{
	BookFeatTopPressure: 1,
}

func ParseBookFeatCalc(name string) BookFeatCalc {
	switch name {
	case "top_pressure":
		return BookFeatTopPressure
	case "pressure2":
		return BookFeatPressure2
	case "pressure3":
		return BookFeatPressure3
	case "pressure4":
		return BookFeatPressure4
	case "BSR":
		return BookFeatMPBSR
	case "BSS":
		return BookFeatMPBSS
	case "DEV":
		return BookFeatMPDEV
	default:
		panic(fmt.Sprintf("Unknown BookFeatCalc: %s", name))
	}
}

func calcBookFeat(x []float64, t BookFeatCalc) float64 {
	switch t {
	case BookFeatTopPressure:
		n := len(x)
		a := x[n/2-1]
		b := x[n/2]
		s := a + b
		if math.Abs(s) < 1e-4 {
			return 0
		} else {
			return (a - b) / (a + b)
		}
	case BookFeatPressure2:
		n := len(x)
		a := x[n/2-2]
		b := x[n/2+1]
		s := a + b
		if math.Abs(s) < 1e-4 {
			return 0
		} else {
			return (a - b) / (a + b)
		}
	case BookFeatPressure3:
		n := len(x)
		a := x[n/2-3]
		b := x[n/2+2]
		s := a + b
		if math.Abs(s) < 1e-4 {
			return 0
		} else {
			return (a - b) / (a + b)
		}
	case BookFeatPressure4:
		n := len(x)
		a := x[n/2-4]
		b := x[n/2+3]
		s := a + b
		if math.Abs(s) < 1e-4 {
			return 0
		} else {
			return (a - b) / (a + b)
		}
	case BookFeatMPBSR:
		s := 0.0
		b := 0.0
		n := len(x)
		for i := 0; i < n; i++ {
			if x[i] > 0 {
				b += x[i]
			} else {
				s -= x[i]
			}
		}
		sum := b + s
		if math.Abs(sum) < 1e-4 {
			return 0
		} else {
			return (b - s) / sum
		}
	case BookFeatMPBSS:
		n := len(x)
		m := n / 2
		sb, wb, ss, ws := 0.0, 0.0, 0.0, 0.0
		i := 0
		// from bid(n) to ask(n), ignore mid (p=0)
		for p := -m; p <= m; p++ {
			if p == 0 {
				continue
			}
			if x[i] > 0 { //buy, p is usually < 0
				sb += float64(p) * x[i]
				wb += x[i]
			} else { //sell, p is usually > 0
				ss += float64(p) * x[i]
				ws += x[i]
			}
			i++
		}
		if wb == 0 || ws == 0 {
			return 0
		} else {
			avgB := sb / wb
			avgS := ss / ws
			return avgB - avgS
		}
	case BookFeatMPDEV:
		n := len(x)
		m := n / 2
		sum := 0.0
		w := 0.0
		i := 0
		// from bid(n) to ask(n), ignore mid (p=0)
		for p := -m; p <= m; p++ {
			if p == 0 {
				continue
			}
			sum += float64(p) * math.Abs(x[i])
			w += math.Abs(x[i])
			i++
		}
		if w == 0 {
			return 0
		} else {
			return sum / w
		}
	default:
		panic("Unknown BookFeatCalc")
	}
}

type MidPriceBookFeature struct {
	FeatureBase
	SidIdxMap

	// prefs
	levelSpreadDir string
	depth          int
	hlList         []int
	doCross        bool // use cross section operator
	nHL            int
	featCalc       BookFeatCalc

	levelStat string

	// states
	books []*MidPriceBook // sidIdx -> MidPriceBook obj

	crosser *MU.WeightedNestedGroupMeanFast

	// temp variables
	statTmpArray [][]float64 // nHL * (2depth) array
	perSidVec    []float64   // feature vec before cross op
	clFeats      []float64   // sidIdx -> count level feature value

	//return
	ret []float64
}

func (feat *MidPriceBookFeature) loadFeaturePrefs() error {
	feat.levelSpreadDir = feat.prefs.GetStringPref(feat.featureName + "_level_spread_dir")
	feat.depth = feat.prefs.GetIntPref(feat.featureName + "_depth")
	feat.hlList = feat.prefs.GetIntListPref(feat.featureName + "_hl_list")
	feat.doCross = feat.prefs.GetBoolPref(feat.featureName + "_do_cross")
	feat.featCalc = ParseBookFeatCalc(feat.prefs.GetStringPref(feat.featureName + "_feat_calc"))
	feat.levelStat = feat.prefs.GetStringPref(feat.featureName + "_level_stat")
	feat.nHL = len(feat.hlList)
	return nil
}

func (feat *MidPriceBookFeature) setFeatureNames() {
	if feat.doCross {
		// per feat * 5 group vals * nHL versions
		feat.colNames = make([]string, 5*feat.nHL)
		i := 0
		{
			for j := 0; j < feat.nHL; j++ {
				feat.colNames[i*5*feat.nHL+j] = fmt.Sprintf("%s-m-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+feat.nHL+j] = fmt.Sprintf("%s-im-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+2*feat.nHL+j] = fmt.Sprintf("%s-cm-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+3*feat.nHL+j] = fmt.Sprintf("%s-ir-%ds", feat.featureName, feat.hlList[j])
				feat.colNames[i*5*feat.nHL+4*feat.nHL+j] = fmt.Sprintf("%s-cr-%ds", feat.featureName, feat.hlList[j])
			}
		}
	} else {
		// per feat * nHL versions
		feat.colNames = make([]string, feat.nHL)
		i := 0
		{
			for j := 0; j < feat.nHL; j++ {
				feat.colNames[i*feat.nHL+j] = fmt.Sprintf("%s-%ds", feat.featureName, feat.hlList[j])
			}
		}
	}

	// allocate ret memory
	feat.ret = make([]float64, len(feat.colNames))
}

func (feat *MidPriceBookFeature) initInternalVars() {
	feat.FeatureBase.initInternalVars()
	feat.SidIdxMap.Init(feat.sidUniverseList)

	// init mid-price books
	epochBreaks, sidLevelSpread := hastats.InitTickSize(feat.dateStr, feat.levelSpreadDir, feat.depth)
	feat.books = make([]*MidPriceBook, feat.nSids)
	for i, sid := range feat.sidUniverseList {
		var statParam interface{}
		switch feat.levelStat {
		case "EMS":
			statParam = EMSParam{feat.hlList}
		case "EMA":
			statParam = EMAParam{feat.hlList}
		case "DiffRatioEMA":
			statParam = DiffRatioEMAParam{feat.hlList}
		default:
			panic(fmt.Sprintf("Unknown level_stat name %s %s", feat.featureName, feat.levelStat))
		}
		feat.books[i] = NewMidPriceBook(sid, statParam, feat.depth, sidLevelSpread, epochBreaks)
	}

	// init cross sectional op
	if feat.doCross {
		feat.crosser = MU.NewWeightedNestedGroupMeanFast(feat.sidUniverseList, len(feat.hlList), feat.baseSidWgts, feat.industryCode, feat.conceptCodes)
	}

	// pre-allocate tmp array
	feat.statTmpArray = make([][]float64, feat.nHL)
	for i := 0; i < feat.nHL; i++ {
		feat.statTmpArray[i] = make([]float64, feat.depth*2)
	}
	feat.perSidVec = make([]float64, feat.nHL)
	feat.clFeats = make([]float64, feat.nSids)
}

// Used to update MidPrice book
func (feat *MidPriceBookFeature) UpdateValueSlice(sid int, valueSlice []float64) bool {
	if feat.featureName == "MPCL" {
		// ignore book update for count level
		return false
	}
	if idx, ok := feat.sid2idx[sid]; ok {
		book := feat.books[idx]
		ask, bid, mid := valueSlice[0], valueSlice[1], valueSlice[2]
		if book.midBooker != nil {
			book.midBooker.UpdateMidPrc(ask, bid, mid)
		}
		return true
	} else {
		return false
	}
}

// Used to update book events
func (feat *MidPriceBookFeature) UpdateSecPrcQtySlice(sid int, secSinceEpoch float64, prcQtySlice []data.PriceQty) bool {
	if len(prcQtySlice) == 0 {
		return false
	}

	if idx, ok := feat.sid2idx[sid]; ok {
		if feat.featureName == "MPCL" {
			// special logic for CL
			cAsk := 0
			cBid := 0
			for _, pq := range prcQtySlice {
				if pq.Qty > 0 {
					cBid++
				} else if pq.Qty < 0 {
					cAsk++
				}
			}
			feat.clFeats[idx] = float64(cBid - cAsk)
			return true
		}

		if feat.featureName == "MPAR" {
			sum := 0.0
			wgt := 0.0
			for i, pq := range prcQtySlice {
				if i >= feat.depth {
					break
				}
				sum += pq.Qty * float64(i+1)
				wgt += pq.Qty
			}
			if wgt != 0 {
				feat.clFeats[idx] = sum / wgt
			} else {
				feat.clFeats[idx] = 0
			}
			// dont return and continue to update the mid price book
		}

		book := feat.books[idx]
		if book.midBooker == nil {
			return false
		}
		smid := book.midBooker.GetStableMidPrice()
		if smid <= 0 {
			return false
		}
		for _, pq := range prcQtySlice {
			delta := 100 * (pq.Price - smid) // because spread data is in 1 cent
			pos := book.FindIdx(secSinceEpoch, delta)
			if pos != -1 {
				//qty := math.Abs(pq.Qty) // signed qty to unsigned
				book.UpdateAtIdx(pos, secSinceEpoch, pq.Qty)
			}
		}
		return true
	} else {
		return false
	}
}

func (feat *MidPriceBookFeature) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return feat.GetSidValues(feat.baseSid, mPrice, secEpoch)
}

func (feat *MidPriceBookFeature) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	if idx, ok := feat.sid2idx[sid]; ok {
		if feat.featureName == "MPCL" {
			// MPCL has only one dummy horizon
			feat.perSidVec[0] = feat.clFeats[idx]
		} else {
			book := feat.books[idx]

			// fill statTmpArr
			for i, stat := range book.stats {
				tmp := stat.Calc(secEpoch)
				for j, val := range tmp {
					feat.statTmpArray[j][i] = val
				}
			}

			if feat.featureName == "MPAR" {
				// MPAR needs both level stats and current info
				for i := 0; i < feat.nHL; i++ {
					// calc stat weighted mean
					sum := 0.0
					wgt := 0.0
					for j := 0; j < feat.depth; j++ {
						qty := feat.statTmpArray[i][feat.depth+j]
						if qty < 0 {
							// valid
							sum -= qty * float64(j+1)
							wgt -= qty
						}
					}
					if wgt != 0 && feat.clFeats[idx] != 0 {
						feat.perSidVec[i] = feat.clFeats[idx]/(sum/wgt) - 1
					} else {
						feat.perSidVec[i] = 0
					}
				}
			} else {
				// calculate features
				for i := 0; i < feat.nHL; i++ {
					feat.perSidVec[i] = calcBookFeat(feat.statTmpArray[i], feat.featCalc)
				}
			}
		}

		//fmt.Printf("docross = %v val = %f\n", feat.doCross, feat.perSidVec[0])

		if feat.doCross {
			feat.crosser.Update(sid, feat.perSidVec)
			feat.crosser.GetValue(sid, feat.ret)
		} else { // no cross
			for i := 0; i < len(feat.ret); i++ {
				feat.ret[i] = feat.perSidVec[i]
			}
		}
	} else {
		for i := 0; i < len(feat.ret); i++ {
			feat.ret[i] = 0
		}
	}
	//
	return feat.ret, nil
}

//==================================================================
//==================================================================

type GeneralBookFeature struct {
	FeatureBase
	SidIdxMap
	CrosserMixin

	// prefs
	hlList []int
	hlLen  int
	pow    float64

	subClass    string   //TODO: use enum to optimize code
	extractors  []string // feature extractors e.g. [BSR, BSS, DEV]
	nExtractors int

	// sorted book struct of stats
	sortedPrices [][]float64 // sidIdx -> sorted prices
	dataEMA      [][]*MU.EMA // sidIdx -> corresponding EMA
	dataRecalc   []bool      //sidIdx -> bool
	lastMidPrice []float64   //sidIdx -> mid price

	// temp variables
	tmpret        []float64   // hlLen * nExtractors
	tmpSizeArr    [][]float64 // hlLen * num of prices
	tmpAbsSizeArr [][]float64 //abs of tmpSizeArray

	// pre-allocated ret array
	ret []float64
}

func (feat *GeneralBookFeature) loadFeaturePrefs() error {
	feat.hlList = feat.prefs.GetIntListPref(feat.featureName + "_hl_list")
	feat.subClass = feat.prefs.GetStringPref(feat.featureName + "_subclass")
	feat.extractors = feat.prefs.GetStringListPref(feat.featureName + "_extractors")
	feat.pow = feat.prefs.GetFloat64Pref(feat.featureName + "_power")

	feat.crosserName = feat.prefs.GetStringPref(feat.featureName + "_crosser")
	feat.doCross = feat.crosserName != "" && feat.crosserName != "none"

	feat.hlLen = len(feat.hlList)
	feat.nExtractors = len(feat.extractors)

	if feat.hlLen == 0 || feat.subClass == "" || len(feat.extractors) == 0 {
		panic(fmt.Sprintf("Check parameters for %s", feat.featureName))
	}

	if feat.subClass != "LastSeenBook" &&
		feat.subClass != "EMABook" &&
		feat.subClass != "IDSBook" &&
		feat.subClass != "UnsignedIDSBook" {
		panic(fmt.Sprintf("Unknown subclass name: %s", feat.subClass))
	}

	return nil
}

func (feat *GeneralBookFeature) setFeatureNames() {
	if feat.doCross {
		if feat.crosserName == "nest" {
			feat.crosserMult = 5
			// per feat * 5 group vals * hlLen versions
			feat.colNames = make([]string, 5*feat.nExtractors*feat.hlLen)
			for i := 0; i < feat.nExtractors; i++ {
				for j := 0; j < feat.hlLen; j++ {
					feat.colNames[i*5*feat.hlLen+j] = fmt.Sprintf("%s-%s-m-%ds", feat.featureName, feat.extractors[i], feat.hlList[j])
					feat.colNames[i*5*feat.hlLen+feat.hlLen+j] = fmt.Sprintf("%s-%s-im-%ds", feat.featureName, feat.extractors[i], feat.hlList[j])
					feat.colNames[i*5*feat.hlLen+2*feat.hlLen+j] = fmt.Sprintf("%s-%s-cm-%ds", feat.featureName, feat.extractors[i], feat.hlList[j])
					feat.colNames[i*5*feat.hlLen+3*feat.hlLen+j] = fmt.Sprintf("%s-%s-ir-%ds", feat.featureName, feat.extractors[i], feat.hlList[j])
					feat.colNames[i*5*feat.hlLen+4*feat.hlLen+j] = fmt.Sprintf("%s-%s-cr-%ds", feat.featureName, feat.extractors[i], feat.hlList[j])
				}
			}
		} else if feat.crosserName == "barrastyle" || feat.crosserName == "barrafull" {
			feat.crosserMult = 2
			feat.colNames = make([]string, 2*feat.nExtractors*feat.hlLen)
			label := "s"
			if feat.crosserName == "barrafull" {
				label = "b"
			}
			for i := 0; i < feat.nExtractors; i++ {
				for j := 0; j < feat.hlLen; j++ {
					feat.colNames[i*2*feat.hlLen+j] = fmt.Sprintf("%s-%s-%sr-%ds", feat.featureName, feat.extractors[i], label, feat.hlList[j])
					feat.colNames[i*2*feat.hlLen+feat.hlLen+j] = fmt.Sprintf("%s-%s-%sm-%ds", feat.featureName, feat.extractors[i], label, feat.hlList[j])
				}
			}
		} else {
			panic(fmt.Sprintf("Unknown crosser name: %s", feat.crosserName))
		}
	} else {
		// per feat * hlLen versions
		feat.colNames = make([]string, feat.nExtractors*feat.hlLen)
		for i := 0; i < feat.nExtractors; i++ {
			for j := 0; j < feat.hlLen; j++ {
				feat.colNames[i*feat.hlLen+j] = fmt.Sprintf("%s-%s-%ds", feat.featureName, feat.extractors[i], feat.hlList[j])
			}
		}
	}

	// allocate ret memory
	feat.ret = make([]float64, len(feat.colNames))
}

func (feat *GeneralBookFeature) initInternalVars() {
	feat.FeatureBase.initInternalVars()
	feat.SidIdxMap.Init(feat.sidUniverseList)

	// init cross sectional op
	if feat.doCross {
		feat.crossers = make([]MU.ICrosser, feat.nExtractors)
		panelRoot := PanelRootInFeature
		for i := 0; i < feat.nExtractors; i++ {
			var crosser MU.ICrosser
			switch feat.crosserName {
			case "nest":
				crosser = MU.NewWeightedNestedGroupMeanFast(feat.sidUniverseList, feat.hlLen, feat.baseSidWgts, feat.industryCode, feat.conceptCodes)
			case "barrastyle":
				crosser = MU.NewBarraCrosser(panelRoot, feat.dateStr, feat.sidUniverseList, feat.hlLen, true, MU.BarraStyleCrosser)
			case "barrafull":
				crosser = MU.NewBarraCrosser(panelRoot, feat.dateStr, feat.sidUniverseList, feat.hlLen, true, MU.BarraFullCrosser)
			case "bigraph":
				// TODO: conceptCodes change to Barra top 3 styles
				crosser = MU.NewBiGraphCrosser(feat.sidUniverseList, feat.hlLen, feat.baseSidWgts, feat.conceptCodes)
			default:
				panic(fmt.Sprintf("Unknown crosser name: %s", feat.crosserName))
			}
			feat.crossers[i] = crosser
		}

	}

	// book struct stats
	feat.sortedPrices = make([][]float64, feat.nSids)
	feat.dataEMA = make([][]*MU.EMA, feat.nSids)

	feat.dataRecalc = make([]bool, feat.nSids)
	feat.lastMidPrice = make([]float64, feat.nSids)
	for idx := 0; idx < feat.nSids; idx++ {
		feat.sortedPrices[idx] = make([]float64, 0, EnoughPriceLevels)
		feat.dataEMA[idx] = make([]*MU.EMA, 0, EnoughPriceLevels)
		feat.dataRecalc[idx] = true
		feat.lastMidPrice[idx] = math.NaN()
	}

	feat.tmpSizeArr = make([][]float64, feat.hlLen)
	feat.tmpAbsSizeArr = make([][]float64, feat.hlLen)
	for h := 0; h < feat.hlLen; h++ {
		feat.tmpSizeArr[h] = make([]float64, 0, EnoughPriceLevels)
		feat.tmpAbsSizeArr[h] = make([]float64, 0, EnoughPriceLevels)
	}

	feat.tmpret = make([]float64, feat.nExtractors*feat.hlLen)
}

func (feat *GeneralBookFeature) initializeEMAs(sid int, price float64) int {
	idx := feat.sid2idx[sid]
	prices := feat.sortedPrices[idx]
	emas := feat.dataEMA[idx]
	j := binSearch(prices, price)
	if j < 0 {
		// parallel insertion sort
		prices = append(prices, price)
		emas = append(emas, MU.NewEMA(feat.hlList))

		j = 0 // if the following loop does not do the assignment

		for i := len(prices) - 1; i > 0; i-- {
			if prices[i] < prices[i-1] {
				prices[i], prices[i-1] = prices[i-1], prices[i]
				emas[i], emas[i-1] = emas[i-1], emas[i]
			} else {
				// price is now at the right slot
				j = i
				break
			}
		}

		feat.sortedPrices[idx] = prices
		feat.dataEMA[idx] = emas
	}
	return j
}

func (feat *GeneralBookFeature) UpdateSecPrcQtySlice(sid int, secSinceEpoch float64, newObs []data.PriceQty) bool {
	if _, ok := feat.sidUniverse[sid]; !ok || len(newObs) == 0 {
		return false
	}
	idx := feat.sid2idx[sid]

	for _, pq := range newObs {
		price := pq.Price
		j := feat.initializeEMAs(sid, price)
		if feat.subClass == "LastSeenBook" {
			feat.dataEMA[idx][j].Reset()
		}
		feat.dataEMA[idx][j].Add(powerTransform(pq.Qty, feat.pow), secSinceEpoch)
	}
	feat.dataRecalc[idx] = true
	return true
}

//GetValues
func (feat *GeneralBookFeature) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	idx, ok := feat.sid2idx[sid]
	if !ok {
		//panic("bad sid query")
	}

	feat.lastMidPrice[idx] = mPrice

	if len(feat.dataEMA[idx]) == 0 {
		for i := 0; i < len(feat.ret); i++ {
			feat.ret[i] = 0
		}
		return feat.ret, nil
	}

	fillSizeArray := func(hllen int, plen int, priceArr []float64, priceEmaMap []*MU.EMA) {
		feat.tmpSizeArr = resizeSizeArray(feat.tmpSizeArr, plen)
		//fill [h,p] size array
		if feat.subClass == "EMABook" {
			for h := 0; h < hllen; h++ {
				for p := 0; p < plen; p++ {
					feat.tmpSizeArr[h][p] = priceEmaMap[p].GetMeanIdx(h)
				}
			}
		} else {
			for h := 0; h < hllen; h++ {
				for p := 0; p < plen; p++ {
					feat.tmpSizeArr[h][p] = priceEmaMap[p].GetImpulseMeanIdx(h, secEpoch)
				}
			}
		}
	}

	fillAbsSizeArray := func() {
		hllen := feat.hlLen
		plen := len(feat.tmpSizeArr[0])
		feat.tmpAbsSizeArr = resizeSizeArray(feat.tmpAbsSizeArr, plen)
		//fill [h,p] abs size array
		for h := 0; h < hllen; h++ {
			for p := 0; p < plen; p++ {
				feat.tmpAbsSizeArr[h][p] = math.Abs(feat.tmpSizeArr[h][p])
			}
		}
	}

	for _idx, _sid := range feat.sidUniverseList {
		_mPrice := feat.lastMidPrice[_idx]
		if !math.IsNaN(_mPrice) && feat.dataRecalc[_idx] && len(feat.dataEMA[_idx]) > 0 {
			if !feat.doCross && _sid != sid {
				// the sid loop and recalc logic are for crosser
				// without the crosser, we just do calculation once
				continue
			}
			// HOW MANY TIMES this is executed? I think = # of ticks, not more!
			// alias
			priceArr := feat.sortedPrices[_idx]
			priceEmaMap := feat.dataEMA[_idx]
			output := feat.tmpret
			hllen := feat.hlLen

			plen := len(priceEmaMap)

			// prepare 2D size array [h,p]
			fillSizeArray(hllen, plen, priceArr, priceEmaMap)
			fillAbsSizeArray()

			switch feat.subClass {
			case "LastSeenBook",
				"IDSBook",
				"EMABook":
				for h := 0; h < hllen; h++ {
					output[h] = calcBuySellRatioV3(feat.tmpSizeArr[h])
					output[h+hllen] = calcBuySellSpreadV3(priceArr, feat.tmpSizeArr[h], _mPrice)
					output[h+hllen*2] = bfCalcDev(priceArr, feat.tmpAbsSizeArr[h], _mPrice)
				}

				if feat.doCross {
					feat.crossers[0].Update(_sid, output[0:hllen])
					feat.crossers[1].Update(_sid, output[hllen:hllen*2])
					feat.crossers[2].Update(_sid, output[hllen*2:hllen*3])
				}
			case "UnsignedIDSBook":
				for h := 0; h < hllen; h++ {
					output[h] = bfCalcDev(priceArr, feat.tmpAbsSizeArr[h], _mPrice)
				}
				if feat.doCross {
					feat.crossers[0].Update(_sid, output[0:hllen])
				}
			}

			feat.dataRecalc[_idx] = false
		}
	}

	n := feat.hlLen
	switch feat.subClass {
	case "LastSeenBook",
		"IDSBook",
		"EMABook":
		if feat.doCross {
			m := feat.crosserMult
			feat.crossers[0].GetValue(sid, feat.ret[0:n*m])
			feat.crossers[1].GetValue(sid, feat.ret[n*m:n*m*2])
			feat.crossers[2].GetValue(sid, feat.ret[n*m*2:n*m*3])
		} else {
			for i := 0; i < 3*feat.hlLen; i++ {
				feat.ret[i] = feat.tmpret[i]
			}
		}
	case "UnsignedIDSBook":
		if feat.doCross {
			m := feat.crosserMult
			feat.crossers[0].GetValue(sid, feat.ret[0:n*m])
		} else {
			for i := 0; i < feat.hlLen; i++ {
				feat.ret[i] = feat.tmpret[i]
			}
		}
	}

	return feat.ret, nil
}

type CrosserMixin struct {
	doCross     bool
	crosserName string
	crosserMult int // one raw feature -> how many cross features

	crosser  MU.ICrosser
	crossers []MU.ICrosser // use this if need more than one crossers
}

// ========================================================
type VariableBackRet struct {
	FeatureBase
	SidIdxMap
	CrosserMixin

	// prefs
	hors int // num of horizons

	// stats
	dataRecalc   []bool      //sidIdx -> bool
	lastMidPrice []float64   //sidIdx -> mid price
	logPrices    [][]TVPair  //sidIdx -> timed price series
	backSecs     [][]float64 //sidIdx -> K hors
	returns      [][]float64 //sidIdex -> K rets

	// temp variables
	tmpret []float64 // hors

	// pre-allocated ret array
	ret []float64
}

func (feat *VariableBackRet) loadFeaturePrefs() error {
	feat.crosserName = feat.prefs.GetStringPref(feat.featureName + "_crosser")
	feat.doCross = feat.crosserName != "" && feat.crosserName != "none"

	feat.hors = feat.prefs.GetIntPref(feat.featureName + "_hors")
	return nil
}

func (feat *VariableBackRet) setFeatureNames() {
	if feat.crosserName == "nest" {
		// per feat * 5 group vals * hlLen versions
		feat.colNames = make([]string, 5*feat.hors)
		for i := 0; i < feat.hors; i++ {
			feat.colNames[feat.hors*0+i] = fmt.Sprintf("%s-h%d-m", feat.featureName, i)
			feat.colNames[feat.hors*1+i] = fmt.Sprintf("%s-h%d-im", feat.featureName, i)
			feat.colNames[feat.hors*2+i] = fmt.Sprintf("%s-h%d-cm", feat.featureName, i)
			feat.colNames[feat.hors*3+i] = fmt.Sprintf("%s-h%d-ir", feat.featureName, i)
			feat.colNames[feat.hors*4+i] = fmt.Sprintf("%s-h%d-cr", feat.featureName, i)
		}
	} else if feat.crosserName == "barrastyle" || feat.crosserName == "barrafull" {
		feat.colNames = make([]string, 2*feat.hors)
		label := "s"
		if feat.crosserName == "barrafull" {
			label = "b"
		}
		for i := 0; i < feat.hors; i++ {
			feat.colNames[feat.hors*0+i] = fmt.Sprintf("%s-h%d-%sr", feat.featureName, i, label)
			feat.colNames[feat.hors*1+i] = fmt.Sprintf("%s-h%d-%sm", feat.featureName, i, label)
		}
	} else {
		// per feat * hlLen versions
		feat.colNames = make([]string, feat.hors)
		for i := 0; i < feat.hors; i++ {
			feat.colNames[i] = fmt.Sprintf("%s-h%d", feat.featureName, i)
		}
	}

	// allocate ret memory
	feat.ret = make([]float64, len(feat.colNames))
}

func (feat *VariableBackRet) initInternalVars() {
	feat.FeatureBase.initInternalVars()
	feat.SidIdxMap.Init(feat.sidUniverseList)

	// init cross sectional op
	if feat.doCross {
		panelRoot := PanelRootInFeature
		switch feat.crosserName {
		case "nest":
			feat.crosser = MU.NewWeightedNestedGroupMeanFast(feat.sidUniverseList, feat.hors, feat.baseSidWgts, feat.industryCode, feat.conceptCodes)
		case "barrastyle":
			feat.crosser = MU.NewBarraCrosser(panelRoot, feat.dateStr, feat.sidUniverseList, feat.hors, true, MU.BarraStyleCrosser)
		case "barrafull":
			feat.crosser = MU.NewBarraCrosser(panelRoot, feat.dateStr, feat.sidUniverseList, feat.hors, true, MU.BarraFullCrosser)
		default:
			panic(fmt.Sprintf("Unknown crosser name: %s", feat.crosserName))
		}
	}

	// book struct stats
	feat.dataRecalc = make([]bool, feat.nSids)
	feat.logPrices = make([][]TVPair, feat.nSids)
	feat.backSecs = make([][]float64, feat.nSids)
	feat.lastMidPrice = make([]float64, feat.nSids)
	for idx := 0; idx < feat.nSids; idx++ {
		feat.dataRecalc[idx] = true
		feat.lastMidPrice[idx] = math.NaN()
		feat.logPrices[idx] = make([]TVPair, 0, 4500) //TODO: resampling mechanism
		feat.backSecs[idx] = make([]float64, feat.hors, feat.hors)
	}

	// tmp vars
	feat.tmpret = make([]float64, feat.hors)
}

func (feat *VariableBackRet) UpdateSecValue(sid int, secSinceEpoch float64, midPrice float64) bool {
	if idx, ok := feat.sid2idx[sid]; ok && midPrice > 0 {
		feat.dataRecalc[idx] = true
		feat.lastMidPrice[idx] = midPrice
		n := len(feat.logPrices[idx])
		//           in case, srcTime is not increasing
		if n == 0 || feat.logPrices[idx][n-1].epoch <= secSinceEpoch {
			feat.logPrices[idx] = append(feat.logPrices[idx], TVPair{secSinceEpoch, math.Log(midPrice)})
		}
	}
	return true
}

func (feat *VariableBackRet) UpdateSecValueSlice(sid int, secSinceEpoch float64, backSecs []float64) bool {
	if len(backSecs) != feat.hors {
		panic("input data length does not match")
	}
	if idx, ok := feat.sid2idx[sid]; ok {
		copy(feat.backSecs[idx], backSecs)
	}
	return true
}

func binSearchTVPairs(tvPairs []TVPair, epoch float64) int {
	l := 0
	r := len(tvPairs) - 1
	ans := r // if lowerbound does not exist, return last
	for l <= r {
		mid := (l + r) / 2
		q := tvPairs[mid].epoch
		if epoch <= q {
			r = mid - 1
			ans = mid
		} else {
			l = mid + 1
		}
	}
	return ans
}

func (feat *VariableBackRet) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for _idx, _sid := range feat.sidUniverseList {
		_mPrice := feat.lastMidPrice[_idx]
		if !math.IsNaN(_mPrice) && feat.dataRecalc[_idx] {
			if !feat.doCross && _sid != sid {
				// the sid loop and recalc logic are for crosser
				// without the crosser, we just do calculation once
				continue
			}

			prevPos := 0
			for i := 0; i < feat.hors; i++ {
				// do binary search
				pos := binSearchTVPairs(feat.logPrices[_idx], secEpoch-feat.backSecs[_idx][i])
				if i == 0 {
					feat.tmpret[i] = feat.logPrices[_idx][pos].val - math.Log(_mPrice)
				} else /* i > 0 */ {
					feat.tmpret[i] = feat.logPrices[_idx][pos].val - feat.logPrices[_idx][prevPos].val
				}
				//if _sid == 2 && i == 0 {
				//	fmt.Printf("DRET time=%f  mid=%.3f  ret=%.4f  t0=%f mid0=%.3f\n", secEpoch, _mPrice, feat.tmpret[0], feat.logPrices[_idx][pos].epoch, math.Exp(feat.logPrices[_idx][pos].val))
				//}
				prevPos = pos
			}

			if feat.doCross {
				feat.crosser.Update(_sid, feat.tmpret)
			}
			feat.dataRecalc[_idx] = false
		}
	}

	if feat.doCross {
		feat.crosser.GetValue(sid, feat.ret)
	} else {
		copy(feat.ret, feat.tmpret)
	}

	return feat.ret, nil
}
