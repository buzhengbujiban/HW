package feature

import (
	"math"
)

//使用calcBuySellRatioV2，涨跌停时候仍然输出+-1
//calcBuySellRatioV3，涨跌停时输出0

var globalFloat64List []float64 = make([]float64, 0, 100) // may cause logical error, if used parallelly

func BuySellRatioIgNa(sa []float64) float64 {
	l := len(sa)
	var buyVol, sellVol float64 = 0.0, 0.0
	for i := 0; i < l; i++ {
		if math.IsNaN(sa[i]) || math.IsInf(sa[i], 0) {
			continue
		}
		if sa[i] > 0 {
			buyVol += sa[i]
		} else {
			sellVol += sa[i]
		}
	}
	if buyVol == 0.0 && sellVol == 0.0 { //v2
		//if buyVol == 0.0 || sellVol == 0.0 { //v3
		return 0.0
	} else {
		return buyVol/(buyVol-sellVol)*2 - 1
	}
}

//calcBuySellSpread
func BuySellSpreadIgNa(pa, sa []float64, mPrice float64) float64 {
	if len(pa) != len(sa) {
		return 0.0
	}

	var buyVol, sellVol float64 = 0.0, 0.0
	var buyAmt, sellAmt float64 = 0.0, 0.0
	for i := 0; i < len(pa); i++ {
		if math.IsNaN(sa[i]) || math.IsInf(sa[i], 0) || math.IsNaN(pa[i]) || math.IsInf(pa[i], 0) {
			continue
		}
		if sa[i] > 0 {
			buyVol += sa[i]
			buyAmt += sa[i] * pa[i]
		} else {
			sellVol += sa[i]
			sellAmt += sa[i] * pa[i]
		}
	}
	if buyVol == 0.0 && sellVol == 0.0 {
		return 0.0
	} else {
		var avgBPrice, avgSPrice float64 = 0, 0
		if buyVol > 0 {
			avgBPrice = buyAmt / buyVol
		}
		if sellVol < 0 {
			avgSPrice = sellAmt / sellVol
		}
		return (math.Abs(avgBPrice) - math.Abs(avgSPrice)) / mPrice
	}
}

//bfCalcTstat
func CalcTstatIgNa(priceArray, absSa []float64, midPrice float64) float64 {
	sas := 0.
	m := MeanVecXOnYIgNa(priceArray, absSa)
	var v float64 = 0.0
	for i := 0; i < len(priceArray); i++ {
		if math.IsNaN(priceArray[i]) || math.IsInf(priceArray[i], 0) || math.IsNaN(absSa[i]) || math.IsInf(absSa[i], 0) {
			continue
		}
		sas += absSa[i]
		v += (priceArray[i] - m) * (priceArray[i] - m) * absSa[i]
	}
	if sas <= 1e-6 {
		return 0.0
	}
	v = v / sas
	if v <= 1e-6 {
		return 0.0
	}
	r := (midPrice - m) / math.Sqrt(v) // 修改 v/sas 变成了 v

	return r
}

//bfCalcDev
func CalcDevIgNa(pa, abssa []float64, midPrice float64) float64 {
	absSas := 0.
	for i := 0; i < len(pa); i++ {
		if math.IsNaN(pa[i]) || math.IsInf(pa[i], 0) || math.IsNaN(abssa[i]) || math.IsInf(abssa[i], 0) {
			continue
		}
		absSas += abssa[i]
	}
	if absSas == 0 {
		return 0
	}
	m := VecMultiplyVecAndSumIgNa(pa, abssa) / absSas
	return math.Log(midPrice) - math.Log(m)
}

func BuySellRatioLocsIgNa(qtys []float64, locs []int) float64 {
	qtys_ := globalFloat64List
	if len(qtys_) > 0 {
		qtys_ = qtys_[:0]
	}
	for _, v := range locs {
		qtys_ = append(qtys_, qtys[v])
	}
	return BuySellRatioIgNa(qtys_)
}

func BuySellRatioLocs2IgNa(qtysAsk, qtysBid []float64, locs []int) float64 {
	qtys_ := globalFloat64List
	if len(qtys_) > 0 {
		qtys_ = qtys_[:0]
	}
	for _, v := range locs {
		qtys_ = append(qtys_, -qtysAsk[v])
		qtys_ = append(qtys_, qtysBid[v])
	}
	return BuySellRatioIgNa(qtys_)
}

func BuySellRatioLocs2IgNaSimilarAsOldDeleted(qtysAsk, qtysBid []float64, locs []int) float64 {
	return -BuySellRatioLocs2IgNa(qtysAsk, qtysBid, locs)
}

func GetPresResis(qtys, prices []float64, midPrice float64, nearSize int) (float64, float64) {
	maxPrice, minPrice := MeanOfMaxMinOfXOnYIgNa(qtys, prices, nearSize)
	if math.Abs(maxPrice) <= E_EPS {
		maxPrice = math.NaN()
	}
	if math.Abs(minPrice) <= E_EPS {
		minPrice = math.NaN()
	}
	return midPrice/maxPrice - 1., midPrice/minPrice - 1.
}

func GetPresResisSimilarAsOldDeleted(qtys, prices []float64, midPrice float64, nearSize int) (float64, float64) {
	maxPrice, minPrice := MeanOfMaxMinOfXOnYIgNa(qtys, prices, nearSize)
	if math.Abs(maxPrice) <= E_EPS {
		maxPrice = math.NaN()
	}
	if math.Abs(minPrice) <= E_EPS {
		minPrice = math.NaN()
	}
	return midPrice / maxPrice, midPrice / minPrice
}
