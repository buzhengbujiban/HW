package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"log"
	"math"
	"strconv"
)

// VPC: volume price correlation

/////////////////////////////////////////
// VPCItem
type VPCItem struct {
	lastVolume      float64
	iPrice, iVolume IntervalValue
	corL, cor5D     float64
}

const VPCCPNAME = "MXVPC"

var VPCCPNames = []string{}

func (item *VPCItem) ToCP() []interface{} {
	r := []interface{}{}
	if len(r) != len(VPCCPNames) {
		log.Panicf("VPCItem CP value size(%d) != CP names size(%d)\n", len(r), len(VPCCPNames))
	}
	return r
}

func (item *VPCItem) FromCP(v []interface{}) {
}

func (item *VPCItem) String() string {
	return fmt.Sprintf("%T", item)
}

// return true if corp action factor != 1.
func (item *VPCItem) OVRoll(ca, emaTime float64) bool {
	return false
}

var _ OVIterm = (*VPCItem)(nil)

/////////////////////////////////////////
// Term: MXVPC
type MXVPC struct {
	OVBase

	// VPC
	items []*VPCItem
}

// prefs_name, feature_name, log_dir, datestr
func (t *MXVPC) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *MXVPC) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	t.UpdateCPInfo(t, VPCCPNAME, VPCCPNames)
	return nil
}

func (t *MXVPC) TermName() string {
	return "MXVPC"
}

func (t *MXVPC) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *MXVPC) names() []string {
	return []string{"i", "dL", "d5"}
}

func (t *MXVPC) inputs() []int {
	return []int{INPUT_MSG_TRADE, INPUT_MSG_TOB}
}

func (t *MXVPC) loadFeaturePrefs() error {
	return nil
}

const MXVPC_BACKDAYS = 10

func (t *MXVPC) loadDailyStats() {
	dateInt, err := strconv.Atoi(t.dateStr)
	if err != nil {
		log.Panicf("cannot parse date as int. %s", t.dateStr)
	}
	lastDayInt := BDSH.PrevBDateInt(dateInt)
	// load data
	for sid, idx := range t.sid2idx {
		item := t.items[idx]
		bd := t.dateStr
		close := make([]float64, MXVPC_BACKDAYS)
		volume := make([]float64, MXVPC_BACKDAYS)
		for i := 0; i < MXTNOP_BACKDAYS; i++ {
			bd = BDSH.PrevBDate(bd)
			prevDateInt, err := strconv.Atoi(bd)
			if err != nil {
				log.Panicf("cannot parse date as int. %s", bd)
			}
			ca := CA.Factor(sid, prevDateInt, lastDayInt)
			daily := PanelDaily{}
			daily.Init(bd)
			v := daily.Sid(sid)
			c := v.SDIstr("close")
			vol := v.SDIstr("volume")
			close[i] = c * ca
			volume[i] = vol * ca
		}
		item.corL = CorZero(close, volume)
		item.cor5D = CorZero(close[0:5], volume[0:5])
		if math.IsNaN(item.corL) {
			item.corL = 0
		}
		if math.IsNaN(item.cor5D) {
			item.cor5D = 0
		}
	}
}

//setFeatureNames: set column names.
func (t *MXVPC) setFeatureNames() {
	t.colNames = t.names()
	for i, n := range t.colNames {
		t.colNames[i] = fmt.Sprintf("%s.5m.%s", t.featureName, n) //TODO: remove 5m after rec with Julia
	}
}

//initialize internal variables
func (t *MXVPC) initInternalVars() {
	t.OVInit()
	t.items = make([]*VPCItem, t.nSids)
	for idx, _ := range t.items {
		t.items[idx] = &VPCItem{
			iPrice:  NewIntervalValue(30),
			iVolume: NewIntervalValue(30)}
	}
}

func (t *MXVPC) TermUpdateTrade(sid int, secs float64, it OVIterm, trade *MsgTrade) {
	item := it.(*VPCItem)
	item.lastVolume += trade.price * trade.shares
}

func (t *MXVPC) TermUpdateTOB(sid int, secs float64, it OVIterm, tob *MsgTOB) {
	item := it.(*VPCItem)
	price := tob.last
	if !(price > 0) {
		price = tob.LastOrRobust()
	}
	jump := item.iPrice.Update(secs, price)
	item.iVolume.Update(secs, item.lastVolume)
	if jump {
		item.lastVolume = 0
	}
}

// snap
func (t *MXVPC) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*VPCItem)
	idx, ok := item.iPrice.Idx(secs)
	if !ok {
		return
	}

	if idx < 10 || item.iPrice.Length() < 10 || item.iVolume.Length() < 10 {
		res[0] = 0
	} else {
		res[0] = CorZero(item.iPrice.Slice(idx-9, idx+1), item.iVolume.Slice(idx-9, idx+1))
	}

	res[1] = item.corL
	res[2] = item.cor5D
}

var _ OVInterface = (*MXVPC)(nil)

func init() {
	TermFactoryInstance().Register("MX-VPC", func() ITerm { return &MXVPC{} })
}
