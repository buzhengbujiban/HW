// Equity Specific Features
// ported from tes_china_equity project
// yzhu, 20181201

package feature

import (
	"fmt"
	"math"

	"TES/QR/alpha_ov/data"
	MU "TES/QR/alpha_ov/mathUtils"
	"TES/tesUtilsGo/common"
)

func resizeSizeArray(S [][]float64, newDim2 int) [][]float64 {
	// S = [h,p]
	if len(S) == 0 { // first dim (h) is empty
		return S
	}

	// enlarge the array if necessary
	for len(S[0]) < newDim2 {
		for i, arr := range S {
			S[i] = append(arr, 0)
		}
	}
	// shrink the array if necessary
	if len(S[0]) > newDim2 {
		for i, arr := range S {
			S[i] = arr[:newDim2]
		}
	}
	return S
}

func insertionSort(arr []float64, val float64) []float64 {
	arr = append(arr, val)
	for i := len(arr) - 1; i > 0; i-- {
		if arr[i] < arr[i-1] {
			arr[i], arr[i-1] = arr[i-1], arr[i]
		} else {
			break
		}
	}
	return arr
}

func binSearch(prices []float64, p float64) int {
	l := 0
	r := len(prices) - 1
	for l <= r {
		mid := (l + r) / 2
		q := prices[mid]
		if q == p {
			return mid
		} else if q < p {
			l = mid + 1
		} else /* q > p */ {
			r = mid - 1
		}
	}
	return -1
}

type FactorPriceLevelSubClass int

const (
	FactorLastSeenBook FactorPriceLevelSubClass = iota + 1
	FactorSignedIDSBook
	FactorUnsignedIDSBook
	FactorSignedEMABook // <-- this enum is deprecated, only to support old prefs before alpha upgrade (2020)
	FactorSignedEMABook2
)

type FactorPriceLevels struct {
	FeatureBase

	SubClass FactorPriceLevelSubClass

	nSids   int
	sid2idx map[int]int

	hlList []int
	hlLen  int
	pow    float64

	sortedPrices [][]float64 // sidIdx -> sorted prices
	dataEMA      [][]*MU.EMA // sidIdx -> corresponding EMA

	// specific to Factor
	dataBSR *MU.WeightedNestedGroupMeanFast
	dataBSS *MU.WeightedNestedGroupMeanFast
	dataDEV *MU.WeightedNestedGroupMeanFast

	dataRecalc   []bool    //sidIdx -> bool
	lastMidPrice []float64 //sidIdx -> mid price

	// result and temp result arrays
	ret           []float64
	tmpret        []float64
	tmpSizeArr    [][]float64 //(horizon,price)
	tmpAbsSizeArr [][]float64 //abs of tmpSizeArray
}

func (gpl *FactorPriceLevels) loadFeaturePrefs() error {
	gpl.hlList = gpl.prefs.GetIntListPref(gpl.featureName + "_hl_list")
	gpl.hlLen = len(gpl.hlList)
	gpl.pow = gpl.prefs.GetFloat64Pref(gpl.featureName + "_power")
	return nil
}

func (gpl *FactorPriceLevels) setFeatureNames() {
	n := gpl.hlLen

	switch gpl.SubClass {
	case FactorLastSeenBook,
		FactorSignedIDSBook,
		FactorSignedEMABook,
		FactorSignedEMABook2:
		gpl.colNames = make([]string, 15*n)
		for h := 0; h < n; h++ {
			gpl.colNames[h+n*0] = fmt.Sprintf("%s-bsr-m%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*1] = fmt.Sprintf("%s-bsr-im%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*2] = fmt.Sprintf("%s-bsr-cm%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*3] = fmt.Sprintf("%s-bsr-ir%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*4] = fmt.Sprintf("%s-bsr-cr%ds", gpl.featureName, gpl.hlList[h])

			gpl.colNames[h+n*5] = fmt.Sprintf("%s-bss-m%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*6] = fmt.Sprintf("%s-bss-im%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*7] = fmt.Sprintf("%s-bss-cm%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*8] = fmt.Sprintf("%s-bss-ir%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*9] = fmt.Sprintf("%s-bss-cr%ds", gpl.featureName, gpl.hlList[h])

			gpl.colNames[h+n*10] = fmt.Sprintf("%s-dev-m%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*11] = fmt.Sprintf("%s-dev-im%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*12] = fmt.Sprintf("%s-dev-cm%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*13] = fmt.Sprintf("%s-dev-ir%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*14] = fmt.Sprintf("%s-dev-cr%ds", gpl.featureName, gpl.hlList[h])
		}

	case FactorUnsignedIDSBook:
		gpl.colNames = make([]string, 5*n)
		for h := 0; h < n; h++ {
			gpl.colNames[h+n*0] = fmt.Sprintf("%s-dev-m%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*1] = fmt.Sprintf("%s-dev-im%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*2] = fmt.Sprintf("%s-dev-cm%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*3] = fmt.Sprintf("%s-dev-ir%ds", gpl.featureName, gpl.hlList[h])
			gpl.colNames[h+n*4] = fmt.Sprintf("%s-dev-cr%ds", gpl.featureName, gpl.hlList[h])
		}

	default:
		panic("Unknown Subclass")
	}

	// allocate feature values array
	gpl.ret = make([]float64, len(gpl.colNames))
	gpl.tmpret = make([]float64, 4*gpl.hlLen)
}

func (gpl *FactorPriceLevels) initInternalVars() {
	gpl.FeatureBase.initInternalVars()

	if gpl.industryCode == nil {
		// will be called a second time when industryCode and conceptCode are not nil
		return
	}

	gpl.nSids = len(gpl.sidUniverseList)
	gpl.sid2idx = make(map[int]int, gpl.nSids)
	for idx, sid := range gpl.sidUniverseList {
		gpl.sid2idx[sid] = idx
	}

	gpl.sortedPrices = make([][]float64, gpl.nSids)
	gpl.dataEMA = make([][]*MU.EMA, gpl.nSids)

	gpl.dataBSR = MU.NewWeightedNestedGroupMeanFast(gpl.sidUniverseList, gpl.hlLen, gpl.baseSidWgts, gpl.industryCode, gpl.conceptCodes)
	gpl.dataBSS = MU.NewWeightedNestedGroupMeanFast(gpl.sidUniverseList, gpl.hlLen, gpl.baseSidWgts, gpl.industryCode, gpl.conceptCodes)
	gpl.dataDEV = MU.NewWeightedNestedGroupMeanFast(gpl.sidUniverseList, gpl.hlLen, gpl.baseSidWgts, gpl.industryCode, gpl.conceptCodes)

	gpl.dataRecalc = make([]bool, gpl.nSids)
	gpl.lastMidPrice = make([]float64, gpl.nSids)
	for idx := 0; idx < gpl.nSids; idx++ {
		gpl.sortedPrices[idx] = make([]float64, 0, EnoughPriceLevels)
		gpl.dataEMA[idx] = make([]*MU.EMA, 0, EnoughPriceLevels)
		gpl.dataRecalc[idx] = true
		gpl.lastMidPrice[idx] = math.NaN()
	}

	gpl.tmpSizeArr = make([][]float64, gpl.hlLen)
	gpl.tmpAbsSizeArr = make([][]float64, gpl.hlLen)
	for h := 0; h < gpl.hlLen; h++ {
		gpl.tmpSizeArr[h] = make([]float64, 0, EnoughPriceLevels)
		gpl.tmpAbsSizeArr[h] = make([]float64, 0, EnoughPriceLevels)
	}
}

func (gpl *FactorPriceLevels) initializeEMAs(sid int, price float64) int {
	idx := gpl.sid2idx[sid]
	prices := gpl.sortedPrices[idx]
	emas := gpl.dataEMA[idx]
	j := binSearch(prices, price)
	if j < 0 {
		// parallel insertion sort
		prices = append(prices, price)
		emas = append(emas, MU.NewEMA(gpl.hlList))

		j = 0 // if the following loop does not do the assignment

		for i := len(prices) - 1; i > 0; i-- {
			if prices[i] < prices[i-1] {
				prices[i], prices[i-1] = prices[i-1], prices[i]
				emas[i], emas[i-1] = emas[i-1], emas[i]
			} else {
				// price is now at the right slot
				j = i
				break
			}
		}

		gpl.sortedPrices[idx] = prices
		gpl.dataEMA[idx] = emas
	}
	return j
}

//Update
func (gpl *FactorPriceLevels) UpdateSecPrcQtySlice(sid int, secSinceEpoch float64, newObs []data.PriceQty) bool {
	if _, ok := gpl.sidUniverse[sid]; !ok || len(newObs) == 0 {
		return false
	}
	idx := gpl.sid2idx[sid]

	for _, pq := range newObs {
		price := pq.Price
		j := gpl.initializeEMAs(sid, price)
		if gpl.SubClass == FactorLastSeenBook {
			gpl.dataEMA[idx][j].Reset()
		}
		gpl.dataEMA[idx][j].Add(powerTransform(pq.Qty, gpl.pow), secSinceEpoch)
	}
	gpl.dataRecalc[idx] = true
	return true
}

//GetValues
func (gpl *FactorPriceLevels) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	idx, ok := gpl.sid2idx[sid]
	if !ok {
		//panic("bad sid query")
	}

	gpl.lastMidPrice[idx] = mPrice

	if len(gpl.dataEMA[idx]) == 0 {
		for i := 0; i < len(gpl.ret); i++ {
			gpl.ret[i] = 0
		}
		return gpl.ret, nil
	}

	fillSizeArray := func(hllen int, plen int, priceArr []float64, priceEmaMap []*MU.EMA) {
		gpl.tmpSizeArr = resizeSizeArray(gpl.tmpSizeArr, plen)
		//fill [h,p] size array
		if gpl.SubClass == FactorSignedEMABook2 {
			for h := 0; h < hllen; h++ {
				for p := 0; p < plen; p++ {
					gpl.tmpSizeArr[h][p] = priceEmaMap[p].GetMeanIdx(h)
				}
			}
		} else {
			for h := 0; h < hllen; h++ {
				for p := 0; p < plen; p++ {
					gpl.tmpSizeArr[h][p] = priceEmaMap[p].GetImpulseMeanIdx(h, secEpoch)
				}
			}
		}
	}

	fillAbsSizeArray := func() {
		hllen := gpl.hlLen
		plen := len(gpl.tmpSizeArr[0])
		gpl.tmpAbsSizeArr = resizeSizeArray(gpl.tmpAbsSizeArr, plen)
		//fill [h,p] abs size array
		for h := 0; h < hllen; h++ {
			for p := 0; p < plen; p++ {
				gpl.tmpAbsSizeArr[h][p] = math.Abs(gpl.tmpSizeArr[h][p])
			}
		}
	}

	for _idx, _sid := range gpl.sidUniverseList {
		_mPrice := gpl.lastMidPrice[_idx]
		if !math.IsNaN(_mPrice) && gpl.dataRecalc[_idx] && len(gpl.dataEMA[_idx]) > 0 {
			// HOW MANY TIMES this is executed? I think = # of ticks, not more!
			// alias
			priceArr := gpl.sortedPrices[_idx]
			priceEmaMap := gpl.dataEMA[_idx]
			output := gpl.tmpret
			hllen := gpl.hlLen

			plen := len(priceEmaMap)

			// prepare 2D size array [h,p]
			fillSizeArray(hllen, plen, priceArr, priceEmaMap)
			fillAbsSizeArray()

			switch gpl.SubClass {
			case FactorLastSeenBook,
				FactorSignedIDSBook,
				FactorSignedEMABook,
				FactorSignedEMABook2:
				for h := 0; h < hllen; h++ {
					output[h] = calcBuySellRatioV3(gpl.tmpSizeArr[h])
					output[h+hllen] = calcBuySellSpreadV3(priceArr, gpl.tmpSizeArr[h], _mPrice)
					output[h+hllen*2] = bfCalcDev(priceArr, gpl.tmpAbsSizeArr[h], _mPrice)
				}

				gpl.dataBSR.Update(_sid, output[0:hllen])
				gpl.dataBSS.Update(_sid, output[hllen:hllen*2])
				gpl.dataDEV.Update(_sid, output[hllen*2:hllen*3])

			case FactorUnsignedIDSBook:
				for h := 0; h < hllen; h++ {
					output[h] = bfCalcDev(priceArr, gpl.tmpAbsSizeArr[h], _mPrice)
				}
				gpl.dataDEV.Update(_sid, output[0:hllen])
			}

			gpl.dataRecalc[_idx] = false
		}
	}

	n := gpl.hlLen
	switch gpl.SubClass {
	case FactorLastSeenBook,
		FactorSignedIDSBook,
		FactorSignedEMABook,
		FactorSignedEMABook2:
		gpl.dataBSR.GetValue(sid, gpl.ret[0:n*5])
		gpl.dataBSS.GetValue(sid, gpl.ret[n*5:n*10])
		gpl.dataDEV.GetValue(sid, gpl.ret[n*10:n*15])
	case FactorUnsignedIDSBook:
		gpl.dataDEV.GetValue(sid, gpl.ret[0:n*5])
	}

	return gpl.ret, nil
}

type TradeEMA struct {
	FeatureBase
	hlList                  []int
	hlLen                   int
	pow                     float64
	quoteSizeEMA, nvDataEma map[int]*MU.EMA

	//return
	ret []float64
}

func (tema *TradeEMA) loadFeaturePrefs() error {
	tema.hlList = tema.prefs.GetIntListPref(tema.featureName + "_hl_list")
	tema.hlLen = len(tema.hlList)
	tema.pow = tema.prefs.GetFloat64Pref(tema.featureName + "_power")

	return nil
}

//setFeatureNames: set column names.
func (tema *TradeEMA) setFeatureNames() {
	tema.colNames = make([]string, tema.hlLen)

	for i := 0; i < tema.hlLen; i++ {
		tema.colNames[i] = fmt.Sprintf("%s-trade-t%ds", tema.featureName, tema.hlList[i])
	}

	// allocate return's memory
	tema.ret = make([]float64, len(tema.colNames))
}

//initialize internal variables'
func (tema *TradeEMA) initInternalVars() {
	tema.FeatureBase.initInternalVars()
	tema.quoteSizeEMA = map[int]*MU.EMA{}
	tema.nvDataEma = map[int]*MU.EMA{}
	for sid := range tema.sidUniverse {
		tema.quoteSizeEMA[sid] = MU.NewEMA([]int{tema.hlList[tema.hlLen-1]})
		tema.nvDataEma[sid] = MU.NewEMA(tema.hlList)
	}
}

//Update
func (tema *TradeEMA) UpdateSecValueSlice(sid int, secSinceEpoch float64, valueSlice []float64) bool {
	if _, ok := tema.sidUniverse[sid]; !ok || len(valueSlice) == 0 {
		return false
	}
	netVolume, _, quoteSize := valueSlice[0], valueSlice[1], valueSlice[2] // tradeSize not used
	tema.quoteSizeEMA[sid].Add(quoteSize, secSinceEpoch)
	tema.nvDataEma[sid].Add(powerTransform(netVolume/tema.quoteSizeEMA[sid].GetMeanIdx(0), tema.pow), secSinceEpoch)

	return true
}

//GetValues
func (tema *TradeEMA) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return tema.GetSidValues(tema.baseSid, mPrice, secEpoch)
}

func (tema *TradeEMA) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	tema.nvDataEma[sid].GetImpulseMean(secEpoch, tema.ret[:tema.hlLen])
	return tema.ret, nil
}

type FactorBookPressureIDSSubClass int

const (
	FactorBookPressureIDS FactorBookPressureIDSSubClass = iota + 1
	FactorBookPressureIDSNDiff
	FactorAskBidRatio
)

type FactorBookPressures struct {
	FeatureBase

	sid2idx map[int]int
	nSids   int

	hlList         []int   //horizon life
	hlLen          int     //len of horizon lives will be used many times so it is pre-calculated
	valueBound     float64 //bound on value
	basisOnly      bool    //whether it's basis only
	pow            float64
	dataEMA        []*MU.EMA
	prevDayAvgSize map[int]float64

	SubClass FactorBookPressureIDSSubClass

	//Specific to Factor features
	dataBook   *MU.WeightedNestedGroupMeanFast
	dataRecalc []bool
	tmpret     []float64
	dataEDE    []*EMADiffEMA

	//return
	ret []float64
}

func (bpids *FactorBookPressures) loadFeaturePrefs() error {
	bpids.hlList = bpids.prefs.GetIntListPref(bpids.featureName + "_hl_list")
	bpids.hlLen = len(bpids.hlList)
	bpids.pow = bpids.prefs.GetFloat64Pref(bpids.featureName + "_power")
	bpids.valueBound = bpids.prefs.GetFloat64Pref(bpids.featureName + "_bound")

	return nil
}

func (bpids *FactorBookPressures) setFeatureNames() {
	// feature names for all SubClasses
	switch bpids.SubClass {
	case FactorBookPressureIDS, FactorAskBidRatio:
		bpids.colNames = make([]string, 5*bpids.hlLen)
	case FactorBookPressureIDSNDiff:
		bpids.colNames = make([]string, 6*bpids.hlLen)
	}

	for i := 0; i < bpids.hlLen; i++ {
		bpids.colNames[i] = fmt.Sprintf("%s-m-t%ds", bpids.featureName, bpids.hlList[i])
		bpids.colNames[i+bpids.hlLen] = fmt.Sprintf("%s-im-t%ds", bpids.featureName, bpids.hlList[i])
		bpids.colNames[i+bpids.hlLen*2] = fmt.Sprintf("%s-cm-t%ds", bpids.featureName, bpids.hlList[i])
		bpids.colNames[i+bpids.hlLen*3] = fmt.Sprintf("%s-ir-t%ds", bpids.featureName, bpids.hlList[i])
		bpids.colNames[i+bpids.hlLen*4] = fmt.Sprintf("%s-cr-t%ds", bpids.featureName, bpids.hlList[i])
	}

	if bpids.SubClass == FactorBookPressureIDSNDiff {
		for i := 0; i < bpids.hlLen; i++ {
			bpids.colNames[i+bpids.hlLen*5] = fmt.Sprintf("%s-diff-t%ds", bpids.featureName, bpids.hlList[i])
		}
	}

	// assign ret memory
	bpids.ret = make([]float64, len(bpids.colNames))
	bpids.tmpret = make([]float64, bpids.hlLen)
}

func (bpids *FactorBookPressures) initInternalVars() {
	bpids.FeatureBase.initInternalVars()

	if bpids.industryCode == nil {
		// will be called a second time when industryCode and conceptCode are not nil
		return
	}

	bpids.nSids = len(bpids.sidUniverseList)
	bpids.sid2idx = make(map[int]int, bpids.nSids)
	for idx, sid := range bpids.sidUniverseList {
		bpids.sid2idx[sid] = idx
	}

	bpids.dataEMA = make([]*MU.EMA, bpids.nSids)
	for idx := 0; idx < bpids.nSids; idx++ {
		bpids.dataEMA[idx] = MU.NewEMA(bpids.hlList)
	}

	// dataBook & dataRecalc for all SubClasses
	bpids.dataBook = MU.NewWeightedNestedGroupMeanFast(bpids.sidUniverseList, bpids.hlLen, bpids.baseSidWgts, bpids.industryCode, bpids.conceptCodes)
	bpids.dataRecalc = make([]bool, bpids.nSids)
	for idx := 0; idx < bpids.nSids; idx++ {
		bpids.dataRecalc[idx] = true
	}

	// dataEDE specific for FactorBookPressureIDSNDiff
	if bpids.SubClass == FactorBookPressureIDSNDiff {
		shortHlList := make([]int, bpids.hlLen-1)
		for h := 0; h < bpids.hlLen-1; h++ {
			shortHlList[h] = (bpids.hlList[h] + 1) / 2
		}
		bpids.dataEDE = make([]*EMADiffEMA, bpids.nSids)
		for idx := 0; idx < bpids.nSids; idx++ {
			bpids.dataEDE[idx] = newEMADiffEMA(shortHlList, false)
		}
	}
}

func (bpids *FactorBookPressures) loadDailyStats() {
	bpids.prevDayAvgSize = make(map[int]float64)
	prevdate := common.PreTradeDate(bpids.dateStr)

	sid2avgSize := data.GetSidValueMapFromPanelData("daily-rollstats", prevdate, "00:00:00", "avg_top_size.rw22")
	sid2avgSize = data.ConformSidValueMap(sid2avgSize, bpids.sidUniverseList, 0.0)

	for sid, avgSize := range sid2avgSize {
		bpids.prevDayAvgSize[sid] = avgSize
	}
}

func (bpids *FactorBookPressures) UpdateSecValue(sid int, secSinceEpoch, newObs float64) bool {
	if _, ok := bpids.sidUniverse[sid]; !ok {
		return false
	}

	idx := bpids.sid2idx[sid]

	normFactor := bpids.prevDayAvgSize[sid]
	if normFactor < 1 {
		// Python version raise FloatingPointError
		return false
	}

	x := MU.ClipFloat(newObs/normFactor, -bpids.valueBound, bpids.valueBound)
	bpids.dataEMA[idx].Add(powerTransform(x, bpids.pow), secSinceEpoch)
	bpids.dataRecalc[idx] = true

	if bpids.SubClass == FactorBookPressureIDSNDiff {
		bpids.dataEMA[idx].GetMean(bpids.tmpret)
		bpids.dataEDE[idx].update(secSinceEpoch, bpids.tmpret)
	}

	return true
}

func (bpids *FactorBookPressures) UpdateSecValueSlice(sid int, secSinceEpoch float64, obs []float64) bool {
	if bpids.SubClass != FactorAskBidRatio {
		panic("UpdateSecValueSlice is for FactorBidAskRatio SubClass")
	}

	if !bpids.sidUniverse[sid] {
		return false
	}

	idx := bpids.sid2idx[sid]

	size_b, size_a := obs[0], obs[1]
	var x float64
	if size_a == 0 {
		x = bpids.valueBound
	} else if size_b == 0 {
		x = -bpids.valueBound
	} else {
		bar := math.Log(size_b+1) - math.Log(size_a+1)
		x = MU.Bound(bar, -bpids.valueBound, bpids.valueBound)
	}
	bpids.dataEMA[idx].Add(powerTransform(x, bpids.pow), secSinceEpoch)
	bpids.dataRecalc[idx] = true
	return true
}

func (bpids *FactorBookPressures) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {

	for _idx, _sid := range bpids.sidUniverseList {
		if bpids.dataRecalc[_idx] && bpids.dataEMA[_idx].NumObs() > 0 {
			bpids.dataEMA[_idx].GetImpulseMean(secEpoch, bpids.tmpret)
			bpids.dataBook.Update(_sid, bpids.tmpret)
			bpids.dataRecalc[_idx] = false
		}
	}

	bpids.dataBook.GetValue(sid, bpids.ret)

	if bpids.SubClass == FactorBookPressureIDSNDiff {
		idx := bpids.sid2idx[sid]
		bpids.dataEDE[idx].getValues(bpids.ret[5*bpids.hlLen:])
	}

	return bpids.ret, nil
}

type EquityDetrendPriceLevelsSubClass int

const (
	EquityDetrendLastSeenBook EquityDetrendPriceLevelsSubClass = iota + 1
	EquityDetrendSignedIDSBook
	EquityDetrendUnsignedIDSBook
	EquityDetrendSignedEMABook
)

type EquityDetrendPriceLevels struct {
	FeatureBase

	SubClass EquityDetrendPriceLevelsSubClass

	nSids   int
	sid2idx map[int]int

	hlList []int
	hlLen  int
	pow    float64

	sortedPrices [][]float64 // sidIdx -> sorted prices
	dataEMA      [][]*MU.EMA // sidIdx -> corresponding EMA
	lastAdjPrice []float64   // sidIdx -> adjusted price

	//return
	ret []float64

	// internal temp variables
	tmpSizeArr    [][]float64 //(horizon,price)
	tmpAbsSizeArr [][]float64
}

func (dpl *EquityDetrendPriceLevels) loadFeaturePrefs() error {
	dpl.hlList = dpl.prefs.GetIntListPref(dpl.featureName + "_hl_list")
	dpl.hlLen = len(dpl.hlList)
	dpl.pow = dpl.prefs.GetFloat64Pref(dpl.featureName + "_power")
	return nil
}

//setFeatureNames: set column names.
func (dpl *EquityDetrendPriceLevels) setFeatureNames() {
	switch dpl.SubClass {
	case EquityDetrendLastSeenBook, EquityDetrendSignedIDSBook, EquityDetrendSignedEMABook:
		dpl.colNames = make([]string, 2*dpl.hlLen)
		for i := 0; i < dpl.hlLen; i++ {
			dpl.colNames[i] = fmt.Sprintf("%s-bsr%ds", dpl.featureName, dpl.hlList[i])
			dpl.colNames[i+dpl.hlLen] = fmt.Sprintf("%s-bss%ds", dpl.featureName, dpl.hlList[i])
		}
	case EquityDetrendUnsignedIDSBook:
		dpl.colNames = make([]string, 2*dpl.hlLen)
		for i := 0; i < dpl.hlLen; i++ {
			dpl.colNames[i] = fmt.Sprintf("%s-t%ds", dpl.featureName, dpl.hlList[i])
			dpl.colNames[i+dpl.hlLen] = fmt.Sprintf("%s-dev%ds", dpl.featureName, dpl.hlList[i])
		}
	}
	// assign ret memory
	dpl.ret = make([]float64, len(dpl.colNames))
}

//initialize internal variables'
func (dpl *EquityDetrendPriceLevels) initInternalVars() {
	dpl.FeatureBase.initInternalVars()

	dpl.nSids = len(dpl.sidUniverseList)
	dpl.sid2idx = make(map[int]int, dpl.nSids)
	for idx, sid := range dpl.sidUniverseList {
		dpl.sid2idx[sid] = idx
	}

	dpl.sortedPrices = make([][]float64, dpl.nSids)
	dpl.dataEMA = make([][]*MU.EMA, dpl.nSids)

	dpl.lastAdjPrice = make([]float64, dpl.nSids)

	for idx := 0; idx < dpl.nSids; idx++ {
		dpl.sortedPrices[idx] = make([]float64, 0, EnoughPriceLevels)
		dpl.dataEMA[idx] = make([]*MU.EMA, 0, EnoughPriceLevels)
		dpl.lastAdjPrice[idx] = math.NaN()
	}

	dpl.tmpSizeArr = make([][]float64, dpl.hlLen)
	dpl.tmpAbsSizeArr = make([][]float64, dpl.hlLen)
	for h := 0; h < dpl.hlLen; h++ {
		dpl.tmpSizeArr[h] = make([]float64, 0, EnoughPriceLevels)
		dpl.tmpAbsSizeArr[h] = make([]float64, 0, EnoughPriceLevels)
	}
}

func (dpl *EquityDetrendPriceLevels) initializeEMAs(sid int, price float64) int {
	idx := dpl.sid2idx[sid]
	prices := dpl.sortedPrices[idx]
	emas := dpl.dataEMA[idx]
	j := binSearch(prices, price)
	if j < 0 {
		// parallel insertion sort
		prices = append(prices, price)
		emas = append(emas, MU.NewEMA(dpl.hlList))

		j = 0 // if the following loop does not do the assignment

		for i := len(prices) - 1; i > 0; i-- {
			if prices[i] < prices[i-1] {
				prices[i], prices[i-1] = prices[i-1], prices[i]
				emas[i], emas[i-1] = emas[i-1], emas[i]
			} else {
				// price is now at the right slot
				j = i
				break
			}
		}

		dpl.sortedPrices[idx] = prices
		dpl.dataEMA[idx] = emas
	}
	return j
}

//Update
func (dpl *EquityDetrendPriceLevels) UpdateSecPrcQtySliceAndValue(sid int, secSinceEpoch float64, newObs []data.PriceQty, adjPrice float64) bool {
	if _, ok := dpl.sidUniverse[sid]; !ok {
		return false
	}
	idx := dpl.sid2idx[sid]
	for _, psp := range newObs {
		pmap := psp.Price - adjPrice
		pmap = math.Round(pmap*1000) / 1000 // HC fix, round to 0.001
		j := dpl.initializeEMAs(sid, pmap)
		switch dpl.SubClass {
		case EquityDetrendLastSeenBook:
			dpl.dataEMA[idx][j].Reset()
		case EquityDetrendSignedEMABook, EquityDetrendSignedIDSBook, EquityDetrendUnsignedIDSBook:
		}
		dpl.dataEMA[idx][j].Add(powerTransform(psp.Qty, dpl.pow), secSinceEpoch)
		dpl.lastAdjPrice[idx] = adjPrice
	}
	return true
}

func (dpl *EquityDetrendPriceLevels) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return dpl.GetSidValues(dpl.baseSid, mPrice, secEpoch)
}

func (dpl *EquityDetrendPriceLevels) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	idx := dpl.sid2idx[sid]
	if math.IsNaN(dpl.lastAdjPrice[idx]) || len(dpl.dataEMA[idx]) == 0 {
		for i := 0; i < len(dpl.ret); i++ {
			dpl.ret[i] = 0
		}
		return dpl.ret, nil
	}

	priceArr := dpl.sortedPrices[idx]
	priceEmaMap := dpl.dataEMA[idx]

	output := dpl.ret
	hllen := dpl.hlLen
	plen := len(priceEmaMap)

	// calculate [h,p] 2D size array
	dpl.tmpSizeArr = resizeSizeArray(dpl.tmpSizeArr, plen)
	switch dpl.SubClass {
	case EquityDetrendLastSeenBook, EquityDetrendSignedIDSBook, EquityDetrendUnsignedIDSBook:
		for h := 0; h < hllen; h++ {
			for p := 0; p < plen; p++ {
				dpl.tmpSizeArr[h][p] = priceEmaMap[p].GetImpulseMeanIdx(h, secEpoch)
			}
		}
	case EquityDetrendSignedEMABook:
		for h := 0; h < hllen; h++ {
			for p := 0; p < plen; p++ {
				dpl.tmpSizeArr[h][p] = priceEmaMap[p].GetMeanIdx(h)
			}
		}
	}

	// for each horizon calculate features
	switch dpl.SubClass {
	case EquityDetrendLastSeenBook, EquityDetrendSignedIDSBook, EquityDetrendSignedEMABook:
		for i := 0; i < hllen; i++ {
			output[i] = calcBuySellRatioV3(dpl.tmpSizeArr[i])
			output[hllen+i] = calcBuySellSpreadV3(priceArr, dpl.tmpSizeArr[i], mPrice)
		}
	case EquityDetrendUnsignedIDSBook:
		// calculate abs size array
		dpl.tmpAbsSizeArr = resizeSizeArray(dpl.tmpAbsSizeArr, plen)
		for h := 0; h < hllen; h++ {
			for p := 0; p < plen; p++ {
				dpl.tmpAbsSizeArr[h][p] = math.Abs(dpl.tmpSizeArr[h][p])
			}
		}
		adjPrice := dpl.lastAdjPrice[idx]
		for i := 0; i < hllen; i++ {
			output[i] = dbfCalcTstat(priceArr, dpl.tmpAbsSizeArr[i], mPrice, adjPrice)
			output[hllen+i] = dbfCalcDev(priceArr, dpl.tmpAbsSizeArr[i], mPrice, adjPrice)
		}
	}

	return dpl.ret, nil
}
