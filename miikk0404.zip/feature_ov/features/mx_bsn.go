package feature

import (
	tu "TES/tesUtilsGo"
	"autosupply/bookmsg"
	"fmt"
	"log"
	"math"

	"github.com/montanaflynn/stats"
)

// BSN: Buy-Sell Net on trading volume

/////////////////////////////////////////
// BSNItem
type BSNItem struct {
	buy, sell, code IntervalValue
	netBase         float64
}

const BSNCPNAME = "MXBSN"

var BSNCPNames = []string{"code", "netBase"}

func (item *BSNItem) ToCP() []interface{} {
	item.Update()
	r := []interface{}{&item.code.array, item.netBase}
	if len(r) != len(BSNCPNames) {
		log.Panicf("BSNItem CP value size(%d) != CP names size(%d)\n", len(r), len(BSNCPNames))
	}
	return r
}

func (item *BSNItem) FromCP(v []interface{}) {
	item.code.Unmarshal(v[0])
	item.netBase = v[1].(float64)
}

func (item *BSNItem) String() string {
	return fmt.Sprintf("%T", item)
}

// return true if corp action factor != 1.
func (item *BSNItem) OVRoll(ca, emaTime float64) bool {
	return false
}

func EncodeNet(net float64) float64 {
	var thresholds = [4]float64{0.6, 0.2, -0.2, -0.6}
	size := len(thresholds)
	result := .0
	for idx, v := range thresholds {
		if net > v {
			result = float64(size - idx)
			break
		}
	}
	return result
}

func (x *BSNItem) Update() {
	// idx = max(buy.idx, sell.idx)
	idx := x.buy.lastIndex
	if idx < x.sell.lastIndex {
		idx = x.sell.lastIndex
	}

	if idx == 0 {
		return
	}

	for i := 0; i <= idx; i++ {
		net := NetNormal(x.buy.AtIdx(i), x.sell.AtIdx(i))
		code := EncodeNet(net)
		x.code.UpdateAt(i, code)
	}

	meanBuy, _ := stats.Mean(x.buy.Slice(0, idx))
	meanSell, _ := stats.Mean(x.sell.Slice(0, idx))
	x.netBase = NetNormal(meanBuy, meanSell)
}

var _ OVIterm = (*BSNItem)(nil)

/////////////////////////////////////////
// Term: MXBSN
type MXBSN struct {
	OVBase

	// BSN
	items []*BSNItem
}

// prefs_name, feature_name, log_dir, datestr
func (t *MXBSN) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *MXBSN) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	t.UpdateCPInfo(t, BSNCPNAME, BSNCPNames)
	return nil
}

func (t *MXBSN) TermName() string {
	return "MXBSN"
}

func (t *MXBSN) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *MXBSN) names() []string {
	return []string{"n", "c"}
}

func (t *MXBSN) inputs() []int {
	return []int{INPUT_MSG_TRADE}
}

func (t *MXBSN) loadFeaturePrefs() error {
	return nil
}

func (t *MXBSN) loadDailyStats() {
}

//setFeatureNames: set column names.
func (t *MXBSN) setFeatureNames() {
	t.colNames = t.names()
	for i, n := range t.colNames {
		t.colNames[i] = fmt.Sprintf("%s.%s", t.featureName, n)
	}
}

//initialize internal variables
func (t *MXBSN) initInternalVars() {
	t.OVInit()
	t.items = make([]*BSNItem, t.nSids)
	for idx, _ := range t.items {
		t.items[idx] = &BSNItem{buy: NewIntervalValue(10), sell: NewIntervalValue(10), code: NewIntervalValue(10)}
	}
}

func (t *MXBSN) TermUpdateTrade(sid int, secs float64, it OVIterm, trade *MsgTrade) {
	item := it.(*BSNItem)
	if trade.dir == bookmsg.DirSell {
		item.sell.AddTo(secs, trade.price*trade.shares)
	} else if trade.dir == bookmsg.DirBuy {
		item.buy.AddTo(secs, trade.price*trade.shares)
	}
}

// snap
func (t *MXBSN) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*BSNItem)
	idx := int(math.Floor(secs / float64(item.code.I)))
	remain := math.Mod(secs, float64(item.code.I))
	if remain < float64(item.code.I/2) {
		idx -= 1
	}
	if idx <= 0 {
		return
	}

	buy, _ := stats.Mean(item.buy.Slice(0, idx))
	sell, _ := stats.Mean(item.sell.Slice(0, idx))
	if buy == 0 || sell == 0 {
		return
	}
	net := NetNormal(buy, sell)
	netDiff := net - item.netBase
	code := EncodeNet(netDiff)
	res[0] = net
	res[1] = item.code.AtIdx(idx) + 5*code + float64(idx)*25
}

var _ OVInterface = (*MXBSN)(nil)

func init() {
	TermFactoryInstance().Register("MX-BSN", func() ITerm { return &MXBSN{} })
}
