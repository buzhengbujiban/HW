package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"log"
	"math"
)

// VPT: volume price trend

/////////////////////////////////////////
// VPTItem
type VPTItem struct {
	IntervalValue
	volEMA     *MXEMA
	lastVol    float64
	vpt        float64
	trackIndex int
}

const VPTCPNAME = "MXVPT"

var VPTCPNames = []string{"iprc", "volEMA.wgt", "volEMA.sum", "volEMA.t", "vpt"}

func (item *VPTItem) ToCP() []interface{} {
	r := []interface{}{&item.array, item.volEMA.wgt, item.volEMA.sum, item.volEMA.t, item.vpt}
	if len(r) != len(VPTCPNames) {
		log.Panicf("VPTItem CP value size(%d) != CP names size(%d)\n", len(r), len(VPTCPNames))
	}
	return r
}

func (item *VPTItem) FromCP(v []interface{}) {
	item.Unmarshal(v[0])
	i := 1
	item.volEMA.wgt, i = v[i].(float64), i+1
	item.volEMA.sum, i = v[i].(float64), i+1
	item.volEMA.t, i = v[i].(float64), i+1
	item.vpt, i = v[i].(float64), i+1
}

func (item *VPTItem) String() string {
	return fmt.Sprintf("%T", item)
}

// return true if corp action factor != 1.
func (item *VPTItem) OVRoll(ca, emaTime float64) bool {
	r := false
	if math.Abs(1.-ca) > 1e-8 {
		item.Scale(ca)
		r = true
	}
	item.volEMA.t -= emaTime
	return r
}

var _ OVIterm = (*VPTItem)(nil)

/////////////////////////////////////////
// Term: MXVPT
type MXVPT struct {
	OVBase

	// VPT
	items []*VPTItem
	hl    float64
}

// prefs_name, feature_name, log_dir, datestr
func (t *MXVPT) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *MXVPT) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	t.UpdateCPInfo(t, VPTCPNAME, VPTCPNames)
	return nil
}

func (t *MXVPT) TermName() string {
	return "MXVPT"
}

func (t *MXVPT) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *MXVPT) names() []string {
	return []string{""}
}

func (t *MXVPT) inputs() []int {
	return []int{INPUT_MSG_TOB}
}

func (t *MXVPT) loadFeaturePrefs() error {
	t.hl = t.prefs.GetFloat64PrefWithDefault(t.featureName+".hl", 300)
	return nil
}

func (t *MXVPT) loadDailyStats() {
}

//setFeatureNames: set column names.
func (t *MXVPT) setFeatureNames() {
	t.colNames = t.names()
	for i, _ := range t.colNames {
		t.colNames[i] = fmt.Sprintf("%s.%s", t.featureName, HLFormat(t.hl))
	}
}

//initialize internal variables
func (t *MXVPT) initInternalVars() {
	t.OVInit()
	t.items = make([]*VPTItem, t.nSids)
	for idx, _ := range t.items {
		t.items[idx] = &VPTItem{
			IntervalValue: NewIntervalValue(30),
			volEMA:        NewMXEMA(t.hl, 1.),
			trackIndex:    -1}
	}
}

func (t *MXVPT) TermUpdateTOB(sid int, secs float64, it OVIterm, tob *MsgTOB) {
	item := it.(*VPTItem)
	idx, ok := item.Idx(secs)
	if !ok {
		return
	}
	if idx <= item.trackIndex {
		return
	}
	// volume update
	volume := tob.notional - item.lastVol
	item.volEMA.Update(secs, volume)
	item.lastVol = tob.notional
	// price update
	if t.DataOnly() {
		item.UpdateAt(idx, tob.robust)
	} else {
		lagPrice := item.AtIdx(idx)
		if lagPrice > 0 {
			ret := math.Log(tob.robust / lagPrice)
			item.vpt += volume * ret
			if sid == 0 {
				log.Printf("sid=%d secs=%f lagPrice=%f ret=%f volDiff=%f vol=%f vpt=%f volEMA=%f\n",
					sid, secs, lagPrice, ret, volume, item.lastVol, item.vpt, item.volEMA.GetEma())
			}
		}
	}
	item.trackIndex = idx
}

// snap
func (t *MXVPT) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*VPTItem)
	volEMA := item.volEMA.GetEma()
	if volEMA == 0 {
		return
	}
	res[0] = item.vpt / volEMA
}

var _ OVInterface = (*MXVPT)(nil)

func init() {
	TermFactoryInstance().Register("MX-VPT", func() ITerm { return &MXVPT{} })
}
