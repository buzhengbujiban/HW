package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"math"
)

// MVOL
/////////////////////////////////////////
// MVOLItem
type (
	MVOLItem struct {
		iVol    IntervalValue
		lastVol float64
		sid     int
	}
)

const MVOLCPNAME = "MXMVOL"

var MVOLCPNames = []string{"iPrice"}

func (item *MVOLItem) ToCP() []interface{} {
	return []interface{}{&item.iVol.array}
}

func (item *MVOLItem) FromCP(v []interface{}) {
	iv := v[0]
	for idx, i := range iv.([]interface{}) {
		item.iVol.array[idx] = i.(float64)
	}
}

func (item *MVOLItem) String() string {
	return fmt.Sprintf("last=%f", item.iVol.V)
}

// return true if corp action factor != 1.
func (item *MVOLItem) OVRoll(ca, emaTime float64) bool {
	return false
}

var _ OVIterm = (*MVOLItem)(nil)

/////////////////////////////////////////
// Term: MXMVOL
type MXMVOL struct {
	OVBase

	// MVOL
	items []*MVOLItem

	lastVolHS300 float64
	lastVolZZ500 float64
	hs300Vol     IntervalValue
	zz500Vol     IntervalValue
}

const MVOL_INTERVAL = 20

// prefs_name, feature_name, log_dir, datestr
func (t *MXMVOL) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *MXMVOL) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	t.UpdateCPInfo(t, MVOLCPNAME, MVOLCPNames)
	t.UpdateCPInfoIndex(t, MVOLCPNAME, []string{"ivol"})
	return nil
}

func (t *MXMVOL) TermName() string {
	return "MXMVOL"
}

func (t *MXMVOL) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *MXMVOL) names() []string {
	return []string{"B0", "B1"}
}

func (t *MXMVOL) inputs() []int {
	return []int{INPUT_MSG_TOB, INPUT_MSG_INDEX}
}

func (t *MXMVOL) loadFeaturePrefs() error {
	return nil
}

//initialize internal variables
func (t *MXMVOL) initInternalVars() {
	t.OVInit()
	t.items = make([]*MVOLItem, t.nSids)
	for idx, _ := range t.items {
		sid := t.sids[idx]
		t.items[idx] = &MVOLItem{
			sid:  sid,
			iVol: NewIntervalValue(MVOL_INTERVAL)}
	}
	t.hs300Vol = NewIntervalValue(MVOL_INTERVAL)
	t.zz500Vol = NewIntervalValue(MVOL_INTERVAL)
}

func (t *MXMVOL) loadDailyStats() {
}

//setFeatureNames: set column names.
func (t *MXMVOL) setFeatureNames() {
	t.colNames = t.names()
	for i, n := range t.colNames {
		t.colNames[i] = fmt.Sprintf("%s.%s", t.featureName, n)
	}
}

func (t *MXMVOL) TermUpdateTOB(sid int, secs float64, it OVIterm, tob *MsgTOB) {
	item := it.(*MVOLItem)
	if math.IsNaN(tob.notional) {
		return
	}

	if t.DataOnly() {
		item.iVol.Update(secs, tob.notional)
	}

	item.lastVol = tob.notional
}

func (t *MXMVOL) TermUpdateIndex(isid int, secs float64, msg *MsgIndex) {
	if isid != HS300_SID && isid != ZZ500_SID {
		return
	}

	if msg.notional > 0 {
		if isid == HS300_SID {
			if t.DataOnly() {
				t.hs300Vol.Update(secs, msg.notional)
			}
			t.lastVolHS300 = msg.notional
		}
		if isid == ZZ500_SID {
			if t.DataOnly() {
				t.zz500Vol.Update(secs, msg.notional)
			}
			t.lastVolZZ500 = msg.notional
		}
	}
}

func SafeMvol(s, i float64) float64 {
	if i == 0 {
		return 0
	}
	return s * 800 / i
}

// snap
func (t *MXMVOL) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*MVOLItem)
	secsIdx, ok := item.iVol.Idx(secs)
	if !ok {
		return
	}
	res[0] = SafeMvol(item.lastVol, t.lastVolHS300+t.lastVolZZ500)
	res[1] = SafeMvol(item.iVol.AtIdx(secsIdx), t.hs300Vol.AtIdx(secsIdx)+t.zz500Vol.AtIdx(secsIdx))
}

//Index OV Interface
func (t *MXMVOL) ToCPForIndex(cp *CheckPoint) {
	cp.Update(MVOLCPNAME, HS300_SID, []interface{}{&t.hs300Vol.array})
	cp.Update(MVOLCPNAME, ZZ500_SID, []interface{}{&t.zz500Vol.array})
}

func (t *MXMVOL) FromCPForIndex(cp *CheckPoint) {
	v300 := cp.Get(MVOLCPNAME, HS300_SID)
	for idx, i := range v300[0].([]interface{}) {
		t.hs300Vol.array[idx] = i.(float64)
	}
	v500 := cp.Get(MVOLCPNAME, ZZ500_SID)
	for idx, i := range v500[0].([]interface{}) {
		t.zz500Vol.array[idx] = i.(float64)
	}
}

var _ OVInterface = (*MXMVOL)(nil)
var _ IndexOVInterface = (*MXMVOL)(nil)

func init() {
	TermFactoryInstance().Register("MX-MVOL", func() ITerm { return &MXMVOL{} })
}
