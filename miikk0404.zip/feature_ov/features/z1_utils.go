package feature

import "math"

// constants
const (
	Z1_INPUT_BOOKSIZE      = 1
	Z1_INPUT_SNAPSHOT_BOOK = 2
	Z1_INPUT_AG_TRADE      = 3
)

type ITerm interface {
	FeatureInterface

	// julia grid alpha interfaces
	Init(sidUniverseList []int)
	TermInput() map[int]bool
	//TermUpdate(sid int, epoch float64, inputType int, n int, data []float64) // moved to FeatureInterface
}

const Z1_EPS = 1e-5
const Z1_TIME_TOLERANCE = 150

func naInf2Zero(x float64) float64 {
	if math.IsNaN(x) || math.IsInf(x, 0) {
		x = 0
	}
	return x
}

func epochToSecsSinceMid(unixSecs float64) float64 {
	secInt := int64(unixSecs)
	nsec := unixSecs - float64(secInt)

	return float64((secInt+28800)%86400) + nsec
}

func inTrading(unixSecs float64) bool {
	secsSinceMid := epochToSecsSinceMid(unixSecs)

	return (secsSinceMid >= 34200-Z1_EPS && secsSinceMid <= 41400+Z1_TIME_TOLERANCE) ||
		(secsSinceMid >= 46800-Z1_EPS && secsSinceMid <= 54000+Z1_TIME_TOLERANCE)
}

func secsSinceTrade(unixSecs float64) float64 {
	secsSinceMid := epochToSecsSinceMid(unixSecs)

	if secsSinceMid < 34200 {
		return secsSinceMid
	} else if secsSinceMid <= 41400 {
		return secsSinceMid - 34200
	} else if secsSinceMid < 46800 {
		return 7200
	} else if secsSinceMid <= 54000 {
		return 7200 + secsSinceMid - 46800
	} else {
		return 14400
	}
}

func midPrc(askPrc, bidPrc float64) float64 {
	if askPrc < 1e-10 && bidPrc > 0 {
		return bidPrc
	} else if bidPrc < 1e-10 && askPrc > 0 {
		return askPrc
	} else if bidPrc <= askPrc && bidPrc > 0 {
		return (askPrc + bidPrc) / 2
	} else {
		return math.NaN()
	}
}

// ###########################################
type floatRingBuf struct {
	cap    int
	buf    []float64
	next   int
	n      int
	s      float64
	ss     float64
	nTotal int
}

func newFloatRingBuf(size int) *floatRingBuf {
	ret := &floatRingBuf{
		cap:    size,
		buf:    make([]float64, size),
		next:   0,
		n:      0,
		s:      0,
		ss:     0,
		nTotal: 0,
	}

	for i := range ret.buf {
		ret.buf[i] = 0
	}
	return ret
}

func (b *floatRingBuf) push(v float64) {
	if math.IsNaN(v) || math.IsInf(v, 0) { //xixian
		return
	}
	del := b.buf[b.next]
	b.s -= del
	b.ss -= del * del
	b.s += v
	b.ss += v * v
	if b.n < b.cap {
		b.n += 1
	}
	b.nTotal += 1

	b.buf[b.next] = v
	b.next = (b.next + 1) % b.cap
}

func (b *floatRingBuf) data() []float64 {
	return b.buf
}
func (b *floatRingBuf) sum() float64 {
	return b.s
}

func (b *floatRingBuf) mean() float64 {
	if b.n == 0 {
		return math.NaN() //xixian
	} else {
		return b.s / float64(b.n)
	}
}

func (b *floatRingBuf) variance() float64 {
	if b.n == 0 || b.n == 1 { //xixian add b.n==1
		return math.NaN()
	} else {
		n := float64(b.n)
		m := b.s / n
		return (b.ss - m*m*n) / (n - 1)
	}
}

func (b *floatRingBuf) std() float64 {
	return math.Sqrt(b.variance())
}

func (b *floatRingBuf) square() float64 { //xixian
	return b.ss
}

func (b *floatRingBuf) getFront() float64 { //xixian
	if b.nTotal <= 0 {
		return math.NaN()
	} else if b.nTotal <= b.cap {
		return b.buf[b.nTotal-1]
	} else if b.next == 0 {
		return b.buf[b.cap-1]
	} else {
		return b.buf[b.next-1]
	}
}

func (b *floatRingBuf) getEnd() float64 { //xixian
	if b.nTotal <= 0 {
		return math.NaN()
	} else if b.nTotal <= b.cap {
		return b.buf[0]
	} else {
		return b.buf[b.next]
	}
}

func (b *floatRingBuf) getNT() int { //xixian
	return b.nTotal
}

// ###########################################
const log2 = 0.6931472

type ema struct {
	hl      float64
	wgt     float64
	sum     float64
	t       float64
	normFac float64
}

func newEma(hl float64, tickSec float64) *ema {
	return &ema{
		hl:      hl,
		wgt:     0,
		sum:     0,
		t:       0,
		normFac: (1 - math.Pow(2, (-tickSec/hl))) / tickSec,
	}
}

func (e *ema) reset() {
	e.sum = 0
	e.wgt = 0
	e.t = 0
}

func (e *ema) update(epochSec float64, x float64) {
	if math.IsNaN(x) {
		return
	}
	if e.t >= epochSec {
		epochSec = e.t
	}

	secSinceLast := epochSec - e.t
	e.t = epochSec

	n_halfs := secSinceLast / e.hl
	decay := 0.0
	if n_halfs <= 20 {
		decay = math.Exp(-n_halfs * log2)
	}

	e.sum = e.sum*decay + x
	if math.Abs(e.sum) < 1e-10 {
		e.sum = 0
	}

	e.wgt = e.wgt*decay + 1
}

func (e *ema) calcDecay(epochSec float64) float64 {
	secSinceLast := 0.0
	if epochSec > e.t {
		secSinceLast = epochSec - e.t
	}
	n_halfs := secSinceLast / e.hl
	decay := 0.0
	if n_halfs <= 20 {
		decay = math.Exp(-n_halfs * log2)
	}
	return decay
}

func (e *ema) getEms(epochSec float64) float64 {
	return e.sum * e.calcDecay(epochSec)
}

func (e *ema) getEma() float64 {
	if e.wgt != 0 {
		return e.sum / e.wgt
	} else {
		return 0
	}
}

func (e *ema) getEmsNormed(epochSec float64) float64 {
	return e.getEms(epochSec) * e.normFac
}

func (e *ema) getEmaDecayed(epochSec float64) float64 {
	return e.getEma() * e.calcDecay(epochSec)
}
