/*
yzhu, 20180509
*/
package feature

import (
	"TES/QR/alpha_ov/data"
	"TES/tesUtilsGo/common"
	"fmt"

	tu "TES/tesUtilsGo"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

type SEvent int

const (
	AGG SEvent = iota
	TRADE
	PRICE
	QUOTE
	TIMER
)

type SamplerMode int

const (
	PerSid SamplerMode = iota + 1
	Group
)

type SamplerV2 struct {
	prefs       *tu.PreferenceAdapter
	prefName    string
	samplerName string
	datestr     string
	dateint     int
	secMorning  float64

	// related to tickupdate and frequently updated
	inTrading    data.TradingSessionInfo
	eventType    []SEvent
	flbBook      map[int]*data.FixedLevelBook
	seenDayEvent map[int]bool //ukey -> bool(has seen day event) map

	mode SamplerMode

	baseSid     int
	sidUniverse []int
	basisList   []int
	fmidMap     map[int]int // raw sid -> fmid
	tickSize    map[int]float64

	featureNameList        []string                    //feature names sorted alphabetically
	featureDict            map[string]FeatureInterface //feature abbrev name -> feature object map
	smoothPriceBaseFeature string                      //NOTE: empty string denotes None

	// general prefs
	dailyRoot         string
	outputDir         string // strictly speaking this is outputRoot, the dir is a date subdir under this root
	logDir            string
	sEventsStr        []string
	sEvents           []SEvent
	publishEventsStr  []string
	publishEvents     []SEvent
	timerIntv         int
	numLevels         int
	tradeNightSession bool

	timerIntvNum map[int]int //sid -> index map

	// output related
	header     string
	outputFile string

	numFeatures      int
	featurePosOffset []int
	outputMatrix     [][]float64

	// fields for extra features
	extraFeatureNameList  []string
	extraNumFeatures      int
	extraFeaturePosOffset []int
	extraOutputMatrix     [][]float64

	DoAppendData bool // TODO: this is a hacking field, thinking about how to do dynamic dispatch gracefully

	// GroupSampler Specific:
	baseSidList []int
	baseSidSet  map[int]bool
}

func (spl *SamplerV2) Init(prefName string, mode SamplerMode, samplerName string, datestr string, alwaysLoadEverything bool) {
	spl.mode = mode
	spl.DoAppendData = true
	//# preferences are loaded from file
	fmt.Println("SamplerV2 prefs_name: ", prefName)
	spl.prefs = tu.NewPreferenceAdapter(prefName)
	spl.prefName = prefName
	spl.samplerName = samplerName
	if datestr == "" {
		spl.datestr = spl.prefs.GetStringPref("date")
	} else {
		spl.datestr = datestr
	}
	spl.dateint, _ = strconv.Atoi(spl.datestr)
	if spl.dateint <= 19700000 || spl.dateint >= 20500000 {
		panic(fmt.Sprintf("datestr must be a 8-digit string and be within [19700000, 20500000]"))
	}
	//# mark whether a day event has been seen
	spl.seenDayEvent = make(map[int]bool)
	spl.LoadGeneralPrefs()
	//# check output dir and create if necessary
	if spl.createOutputDir() || alwaysLoadEverything {
		spl.LoadSamplerPrefs() // dynamic dispatch
		spl.loadFmidMap()
		spl.SetHeader() // dynamic dispatch
		//# daily stats file root
		spl.dailyRoot = spl.prefs.GetStringPref("daily_root")
		//TODO: self.load_daily_stats()
		//# load tick size
		spl.tickSize = make(map[int]float64)
		for _, sid := range spl.sidUniverse {
			spl.tickSize[sid] = common.SecMasterMap[sid].TickSize
		}
	}

	// flbBook and eventType are both updated by tick
	// init flbBook and pre-allocate eventType
	spl.flbBook = make(map[int]*data.FixedLevelBook)
	spl.eventType = make([]SEvent, 0, 10)

	//# morning
	spl.secMorning = common.GetBeginTimestampOfDay(datestr)
	//# output_data is used to store results
	spl.outputMatrix = make([][]float64, 0)
	spl.extraOutputMatrix = make([][]float64, 0)
}

func (spl *SamplerV2) createOutputDir() bool {
	outputDir := filepath.Join(spl.outputDir, spl.datestr)
	if _, err := os.Stat(outputDir); err != nil { //path not exist
		err := os.MkdirAll(outputDir, os.ModePerm)
		if err != nil {
			msg := fmt.Sprintf("cannot create folder %s; pleae check permission.", outputDir)
			panic(msg)
		}
	}

	//# copy prefs file to output directory
	localFn := filepath.Join(spl.outputDir, fmt.Sprintf("%s.prefs", spl.samplerName))
	_, err := tu.Copy(spl.prefName, localFn, true)
	if err != nil {
		fmt.Println(fmt.Sprintf("cannot copy prefs file %s to %s", spl.prefName, localFn))
	}

	spl.outputFile = filepath.Join(outputDir, fmt.Sprintf("%s.zstd", spl.samplerName))
	if _, err := os.Stat(spl.outputFile); err == nil {
		return false //sampler outputFile already exists
	} else {
		return true //outputFile Not Exist, waiting to be written
	}
}

func (spl *SamplerV2) LoadGeneralPrefs() {
	//# load output_dir
	spl.outputDir = spl.prefs.GetStringPref("output_dir")
	//# set up logging
	spl.setupLogging()

	//# load sampling events
	spl.sEventsStr = spl.prefs.GetStringListPref("sampling_events")
	spl.sEvents = SEventsFromStringSlice(spl.sEventsStr)
	if InSEventSlice(TIMER, spl.sEvents) {
		spl.timerIntv = spl.prefs.GetIntPref("timer_interval")
		spl.setupTimer()
	}
	//# order book number of levels
	spl.numLevels = spl.prefs.GetIntPref("FLB_num_levels")
	if spl.prefs.HasPref("trade_night_session") {
		spl.tradeNightSession = spl.prefs.GetBoolPref("trade_night_session")
	} else {
		spl.tradeNightSession = false
	}

	//fmt.Printf("LoadGeneralPrefs %#v\n", spl)
	//fmt.Printf("sampler prefs %#v\n", spl.prefs)
}

func (spl *SamplerV2) LoadSamplerPrefs() {
	//# feature values are published at publish events
	spl.publishEventsStr = spl.prefs.GetStringListPref("publish_events")
	spl.publishEvents = SEventsFromStringSlice(spl.publishEventsStr)
	//# base sid is the sid we want to predict
	if spl.mode == Group {
		spl.baseSidList = spl.prefs.GetIntListPref("base_sid_list")
		spl.baseSidSet = make(map[int]bool)
		for _, sid := range spl.baseSidList {
			spl.baseSidSet[sid] = true
		}
	} else if spl.mode == PerSid {
		spl.baseSid = spl.prefs.GetIntPref("base_sid")
	} else {
		panic("Unknown SamplerMode")
	}
	/*
		# load feature list
		# IMPORTANT:
		# feature name is just an alias
		# note that the feature class name here should be the full name so that
		# class instances can be instantiated by str_to_class
		# UNLESS it's under feature module in which case only the short name
		# is needed
	*/

	spl.featureDict = make(map[string]FeatureInterface)
	if spl.mode == Group {
		spl.sidUniverse = spl.baseSidList
	} else if spl.mode == PerSid {
		spl.sidUniverse = append(spl.sidUniverse, spl.baseSid) // self.sid_universe = [self.base_sid]
	} else {
		panic("Unknown SamplerMode")
	}

	loadOneFeatureName := func(fn string) {
		className := spl.prefs.GetStringPref(fmt.Sprintf("%s_class_name", fn))
		prefsName := spl.prefs.GetStringPref(fmt.Sprintf("%s_prefs_name", fn))
		spl.featureDict[fn] = NewFeatureInst(prefsName, fn, className, spl.logDir, spl.datestr)
		if spl.mode == Group {
			spl.featureDict[fn].SetSidUniverse(spl.sidUniverse[0], spl.sidUniverse[1:])
		} else if spl.mode == PerSid {
			basisPrefsName := fmt.Sprintf("%s_basis_list", fn)
			var basisList []int
			if spl.prefs.HasPref(basisPrefsName) {
				basisList = spl.prefs.GetIntListPref(basisPrefsName)
				spl.sidUniverse = append(spl.sidUniverse, basisList...)
			} else {
				basisList = nil
			}
			spl.featureDict[fn].SetSidUniverse(spl.baseSid, basisList)
		} else {
			panic("Unknown SamplerMode")
		}
	}

	//NOTE: featureNameList is Python version's feature_name_tuple
	spl.featureNameList = spl.prefs.GetStringListPref("feature_list")
	sort.Strings(spl.featureNameList)
	for _, fn := range spl.featureNameList {
		loadOneFeatureName(fn)
	}

	if spl.prefs.HasPref("smooth_price_base_feature") {
		spl.smoothPriceBaseFeature = spl.prefs.GetStringPref("smooth_price_base_feature")
	} else {
		spl.smoothPriceBaseFeature = ""
	}

	// init extra feature list
	spl.extraFeatureNameList = spl.prefs.GetStringListPref("extra_feature_list")
	sort.Strings(spl.extraFeatureNameList)
	for _, efn := range spl.extraFeatureNameList {
		loadOneFeatureName(efn)
	}

	for _, sid := range spl.sidUniverse {
		spl.seenDayEvent[sid] = false
	}
}

func (spl *SamplerV2) loadFmidMap() {
	//activeUniverse := make([]int, 0, 0)
	spl.fmidMap = make(map[int]int)
	//# check if sids are raw sids or generic sids
	//# for generic sids we use fmid_map to map raw sid to generic sid
	for _, sid := range spl.sidUniverse {
		if common.SecMasterMap[sid].ExpiryDate == 0 {
			//if sid is a generic id, map the underlying to it
			date, _ := strconv.Atoi(spl.datestr)
			if rawSid, ok := common.MostLiquidFuturesMap[common.MostLiquidKey{sid, date}]; ok {
				spl.fmidMap[rawSid] = sid
				//activeUniverse = append(activeUniverse, sid)
			} else {
				fmt.Printf("ERROR: cannot find fmid mapping %d on %s\n", sid, spl.datestr)
			}
		} else {
			// if sid is a raw sid
			spl.fmidMap[sid] = sid
			//activeUniverse = append(activeUniverse, sid)
		}
	}

	// Filter out the dead sids on this date
	//spl.sidUniverse = activeUniverse

	fmt.Printf("FMID_MAP in SAMPLEV2: %v\n", spl.fmidMap)
}

func (spl *SamplerV2) SetHeader() {
	//# output header is created here

	spl.header = "sid,rec_epoch,ex_time,date"

	// normal feature names
	spl.numFeatures = 0
	spl.featurePosOffset = make([]int, len(spl.featureNameList))
	var allFeatureNames []string
	for i, fn := range spl.featureNameList {
		spl.featurePosOffset[i] = spl.numFeatures
		spl.numFeatures += len(spl.featureDict[fn].GetFeatureNames())
		allFeatureNames = append(allFeatureNames, spl.featureDict[fn].GetFeatureNames()...)
	}

	// extra feature names
	spl.extraNumFeatures = 0
	spl.extraFeaturePosOffset = make([]int, len(spl.extraFeatureNameList))
	var allExtraFeatureNames []string
	for i, efn := range spl.extraFeatureNameList {
		spl.extraFeaturePosOffset[i] = spl.extraNumFeatures
		spl.extraNumFeatures += len(spl.featureDict[efn].GetFeatureNames())
		allExtraFeatureNames = append(allExtraFeatureNames, spl.featureDict[efn].GetFeatureNames()...)
	}

	// standard header + all normal features + day_session + all extra features
	spl.header = spl.header + "," + strings.Join(allFeatureNames, ",") + ",day_session"
	if spl.extraNumFeatures > 0 {
		spl.header = spl.header + "," + strings.Join(allExtraFeatureNames, ",")
	}
}

func (spl *SamplerV2) setupLogging() {
	spl.logDir = filepath.Join(spl.outputDir, "log")
	//logLevelStr := spl.prefs.GetStringPref("log_level")
	//log_level = getattr(logging, log_level_str)
	//logFile := filepath.Join(spl.logDir, fmt.Sprintf("%s-sampler.log", spl.samplerName))
}

func (spl *SamplerV2) setupTimer() {
	spl.timerIntvNum = make(map[int]int)
}

func (spl *SamplerV2) OnTickdataUpdate(td *data.TesTOBSlice) bool {
	// reset the slice (but will reuse the memory)
	spl.eventType = spl.eventType[:0]

	rawSid := td.Sid
	if _, ok := spl.fmidMap[rawSid]; !ok && spl.mode == PerSid {
		// if the sampler does not need this raw sid and if not under GroupSampler mode
		return false
	}
	sid := spl.fmidMap[rawSid]

	//# update order book
	if _, ok := spl.flbBook[sid]; !ok {
		spl.flbBook[sid] = data.NewFixedLevelBook(rawSid, spl.numLevels, 0)
	}
	updateResult := spl.flbBook[sid].Update(td)
	if !updateResult {
		tu.Logger.Error(fmt.Sprintf("Bad update: problematic time or volume. %d at %.3f", sid, td.ExTimestamp()))
		return false
	}
	book := spl.flbBook[sid]
	spl.inTrading = book.IsInTrading()
	if (spl.tradeNightSession && !spl.inTrading.InNightSession) ||
		(!spl.tradeNightSession && !spl.inTrading.InTrading) {
		return false
	}

	var isFirstDayEvent bool
	if spl.mode == PerSid {
		if spl.inTrading.InDaySession && !spl.seenDayEvent[sid] {
			isFirstDayEvent = true
			spl.seenDayEvent[sid] = true
		} else {
			isFirstDayEvent = false
		}
	}

	// FWDRET gets the data independent of the event check
	if feature, ok := spl.featureDict["FWDRET"]; ok {
		mid := book.GetMidPrice()
		adj_src_epoch := common.SubtractBreakSeconds(book.ExTimestamp, spl.secMorning, book.EID)
		feature.UpdateSecValue(sid, adj_src_epoch, mid)
	}

	//# check SEvent.AGG event
	if book.IsAggPriceValid(0.09) {
		spl.eventType = append(spl.eventType, AGG)
	}
	//# check SEvent.TRADE event
	if book.IsTradeEvent() {
		spl.eventType = append(spl.eventType, TRADE)
	}
	//# check SEvent.PRICE
	if spl.mode == Group {
		if book.IsPriceEvent() {
			spl.eventType = append(spl.eventType, PRICE)
		}
	} else if spl.mode == PerSid {
		if book.IsPriceEvent() || (isFirstDayEvent && book.IsValidPriceEvent()) {
			spl.eventType = append(spl.eventType, PRICE)
		}
	}
	//# check SEvent.QUOTE
	if spl.mode == Group {
		if book.IsQuoteEvent() {
			spl.eventType = append(spl.eventType, QUOTE)
		}
	} else if spl.mode == PerSid {
		if book.IsQuoteEvent() || (isFirstDayEvent && book.IsValidQuoteEvent()) {
			spl.eventType = append(spl.eventType, QUOTE)
		}
	}
	//# check SEvent.TIMER
	if spl.timerIntvNum != nil { //<==> if SEvent.TIMER in self.s_events
		if _, ok := spl.timerIntvNum[sid]; !ok {
			spl.timerIntvNum[sid] = 0
		}
		srcEpoch := book.ExTimestamp
		tmp := int(math.Floor(srcEpoch / float64(spl.timerIntv)))
		if tmp > spl.timerIntvNum[sid] {
			spl.timerIntvNum[sid] = tmp
			spl.eventType = append(spl.eventType, TIMER)
		}
	}

	if !SEventIsIntersect(spl.sEvents, spl.eventType) {
		/*
		   if self.logger.isEnabledFor(logging.DEBUG):
		       msg = 'Event type is not in sampling event list. {} at {}'
		       self.logger.debug(msg.format(sid, td.ex_timestamp))
		*/
		return false
	}

	return true
}

func (spl *SamplerV2) appendOutputData(sid int, book *data.FixedLevelBook) {
	//# retrieve receive time stamp for calculating EMA
	origRecEpoch := book.RecSecSinceEpoch
	adjRecEpoch := common.SubtractBreakSeconds(origRecEpoch, spl.secMorning, book.EID)
	//# retrieve source time stamp for calculating lagging returns
	srcEpoch := book.ExTimestamp
	//# features are calculated based on bid/ask price/sizes
	priceM := book.GetMidPrice()
	//# only append output_data at PUBLISH events
	inTrading := (spl.tradeNightSession && spl.inTrading.InNightSession) || (!spl.tradeNightSession && spl.inTrading.InDaySession)
	if inTrading &&
		(spl.mode == PerSid && sid == spl.baseSid || spl.mode == Group && spl.baseSidSet[sid]) &&
		SEventIsIntersect(spl.eventType, spl.publishEvents) {

		fields := make([]float64, 4+spl.numFeatures+1)
		fields[0] = float64(sid)
		fields[1] = book.RecSecSinceEpoch
		fields[2] = book.ExTimestamp
		fields[3] = float64(spl.dateint)
		fieldIdx := 4

		extraFields := make([]float64, spl.extraNumFeatures)
		extraFieldIdx := 0

		calculateOneFeature := func(fn string, isExtra bool) {
			var vals []float64
			if spl.mode == PerSid {
				vals, _ = spl.featureDict[fn].GetValues(priceM, adjRecEpoch)
			} else if spl.mode == Group {
				vals, _ = spl.featureDict[fn].GetSidValues(sid, priceM, adjRecEpoch)
			}
			numExpectedVals := len(spl.featureDict[fn].GetFeatureNames())
			if numExpectedVals != len(vals) {
				msg := fmt.Sprintf("feature %s expects %d values, but get %v", fn, numExpectedVals, vals)
				panic(msg)
			}
			if isExtra {
				for _, val := range vals {
					extraFields[extraFieldIdx] = val
					extraFieldIdx++
				}
			} else {
				for _, val := range vals {
					fields[fieldIdx] = val
					fieldIdx++
				}
			}
		}

		// calculate each feature and append each's values
		for _, fn := range spl.featureNameList {
			calculateOneFeature(fn, false)
		}

		// calculate each extra feature
		for _, efn := range spl.extraFeatureNameList {
			calculateOneFeature(efn, true)
		}

		//# add day_session
		sessionNumber := spl.SessionNumber(srcEpoch)
		fields[fieldIdx] = float64(sessionNumber)
		spl.outputMatrix = append(spl.outputMatrix, fields)
		spl.extraOutputMatrix = append(spl.extraOutputMatrix, extraFields)
	}
}

func (spl *SamplerV2) SessionNumber(secEpoch float64) int {
	var sessionNumber int
	if !spl.inTrading.InDaySession {
		sessionNumber = 0
	} else {
		if secEpoch-spl.secMorning <= 90*60 {
			//# 9:00 - 10:30
			sessionNumber = 1
		} else if secEpoch-spl.secMorning <= 150*60 {
			//# 10:30 - 11:30
			sessionNumber = 2
		} else {
			//# afternoon
			sessionNumber = 3
		}
	}
	return sessionNumber
}

func (spl *SamplerV2) FinalizeExtraFeatures() {
	// finalize & revision (for Forward Stats)
	for featIdx, featName := range spl.extraFeatureNameList {
		spl.featureDict[featName].Finalize()
		revisionList := spl.featureDict[featName].GetRevisionList()
		if len(revisionList) > 0 {
			for _, update := range revisionList {
				spl.extraOutputMatrix[update.i][spl.extraFeaturePosOffset[featIdx]+update.j] = update.v
			}
		}
	}
}

func (spl *SamplerV2) PublishData() {
	spl.FinalizeExtraFeatures()
	// a temp array
	strs := make([]string, 4+spl.numFeatures+1+spl.extraNumFeatures)
	stringer := func(rowVec []float64, extraRowVec []float64) string {
		m := len(rowVec)
		// transform a row feature vector into a string
		for j, val := range rowVec {
			if j == 0 { // sid
				strs[j] = fmt.Sprintf("%.0f", val)
			} else if j == 1 { // rec_epoch
				strs[j] = fmt.Sprintf("%f", val)
			} else if j == 2 { // ex_time (readable)
				strs[j] = common.SecSinceEpochToTimestr(val - 3600*8)
			} else if j == 3 { // date
				strs[j] = fmt.Sprintf("%.0f", val)
			} else if j == m-1 { // day_session
				strs[j] = fmt.Sprintf("%.0f", val)
			} else { // normal feature value
				strs[j] = fmt.Sprintf("%.6f", val)
			}
		}

		extraOff := 4 + spl.numFeatures + 1
		for j, val := range extraRowVec {
			strs[extraOff+j] = fmt.Sprintf("%g", val) // use %g for extra feature
		}

		rowStr := strings.Join(strs, ",")
		return rowStr
	}

	err := tu.DumpFloat64MatrixIntoZstdFile(spl.header, spl.outputMatrix, spl.extraOutputMatrix, stringer, spl.outputFile)
	if err != nil {
		tu.Logger.Fatal(err.Error())
	} else {
		tu.Logger.Info(fmt.Sprintf("zstd sampler data dumped to %s\n", spl.outputFile))
	}
}

/*
   load_daily_stats(self):
   def close_loggers(self):
*/

type BookSamplerV2 struct {
	SamplerV2
}

func (spl *BookSamplerV2) Init(prefsName string, mode SamplerMode, datestr string) {
	spl.SamplerV2.Init(prefsName, mode, "BookSamplerV2", datestr, true) //TODO: check alwaysLoadEverything design
}

func (spl *BookSamplerV2) PublishData() {
	spl.SamplerV2.PublishData()
}

func InIntSlice(x int, xs []int) bool {
	for _, v := range xs {
		if x == v {
			return true
		}
	}
	return false
}

func (spl *BookSamplerV2) OnTickDataUpdateUglyForward(td *data.TesTOBSlice) bool {
	return spl.OnTickDataUpdate(td)
}

func (spl *BookSamplerV2) OnTickDataUpdate(td *data.TesTOBSlice) bool {
	success := spl.SamplerV2.OnTickdataUpdate(td)
	if !success {
		return false
	}

	//# tickdata_replay passes in raw sid
	raw_sid := td.Sid
	//# need to convert it to generic sid if necessary
	sid := spl.fmidMap[raw_sid]
	//# retrieve book by generic sid
	book := spl.flbBook[sid]
	//# retrieve receive time stamp for calculating EMA
	//rec_epoch := book.RecSecSinceEpoch //NOTE: rec_epoch is not used in this function
	//# retrieve exchange time stamp for calculating lagging returns
	orig_src_epoch := book.ExTimestamp
	adj_src_epoch := common.SubtractBreakSeconds(orig_src_epoch, spl.secMorning, book.EID)

	//# do not update on first slice
	if book.IsFirstSlice {
		return false
	}

	//# returns are typically calculated as the change in mid_price
	m_price := book.GetMidPrice()
	if m_price <= 0 {
		return false
	}
	size_a := book.GetAskSize()
	size_b := book.GetBidSize()
	var adj_size_a, adj_size_b, avg_quote_size float64
	if size_a == 0 || size_a == 0 {
		adj_size_a = size_b
		adj_size_b = size_b
		avg_quote_size = size_b
	} else if size_b == 0 || size_b == 0 {
		adj_size_a = size_a
		adj_size_b = size_a
		avg_quote_size = size_a
	} else {
		adj_size_a = size_a
		adj_size_b = size_b
		avg_quote_size = (size_a + size_b) / 2.0
	}

	if InSEventSlice(TRADE, spl.eventType) || InSEventSlice(QUOTE, spl.eventType) {
		//# features that need to be updated at both TRADE and QUOTE
		//# features that depend on mid price
		if m_price != 0 {
			if feature, ok := spl.featureDict["LBR"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELE"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELE0"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELES"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELEL"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELEL0"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELELL"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
		}

		sizeSlice := []float64{size_b, size_a}
		//# features that do not depend on mid price
		if feature, ok := spl.featureDict["BAR"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, sizeSlice)
		}
		if feature, ok := spl.featureDict["BARD"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, sizeSlice)
		}

		//# features that depend on change in liquidity
		delta_ask_liq, delta_bid_liq, taken_liq, sweep_level := book.GetDeltaLiquidity()

		if feature, ok := spl.featureDict["DAL"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, delta_ask_liq)
		}
		if feature, ok := spl.featureDict["DBL"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, delta_bid_liq)
		}
		if feature, ok := spl.featureDict["TL"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, taken_liq)
		}
		if feature, ok := spl.featureDict["SL"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, sweep_level)
		}
		if feature, ok := spl.featureDict["DALD"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, delta_ask_liq)
		}
		if feature, ok := spl.featureDict["DBLD"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, delta_bid_liq)
		}
		if feature, ok := spl.featureDict["TLD"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, taken_liq)
		}
		if feature, ok := spl.featureDict["SLD"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, sweep_level)
		}
		if feature, ok := spl.featureDict["DQS"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, avg_quote_size)
		}

	}

	//# calculated detrended price
	mid_price_tick := math.Mod(m_price, spl.tickSize[sid]) //mid_price_tick = m_price % self.tick_size[sid]
	var smoothed_price float64
	//# use the smoothed price in ELE to adjust
	if spl.smoothPriceBaseFeature != "" {
		feature := spl.featureDict[spl.smoothPriceBaseFeature].(*Chartist)
		if feature.sidUniverse[sid] && len(feature.GetSmoothedPriceDeque(sid)) > 0 {
			smooth_price_deque := feature.GetSmoothedPriceDeque(sid)
			smoothed_price = math.Exp(smooth_price_deque[len(smooth_price_deque)-1].Price)
		} else {
			smoothed_price = m_price
		}
	} else {
		smoothed_price = m_price
	}
	adj_price := spl.tickSize[sid]*math.Floor(smoothed_price/spl.tickSize[sid]) + mid_price_tick

	//# features that need to be updated at QUOTE
	if InSEventSlice(QUOTE, spl.eventType) {
		last_seen_book, average_book := book.GetQuoteDerivedBookDelta()
		//last_seen_book = average_book//tested: last_seen_book and average_book are indeed the same
		if feature, ok := spl.featureDict["LSB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, last_seen_book)
		}
		if feature, ok := spl.featureDict["AB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, average_book)
		}
		if feature, ok := spl.featureDict["ABD"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, average_book)
		}
		if feature, ok := spl.featureDict["DLSB"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, last_seen_book, adj_price)
		}
		if feature, ok := spl.featureDict["DAB"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, average_book, adj_price)
		}
		if feature, ok := spl.featureDict["LSBD"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, last_seen_book)
		}
		if feature, ok := spl.featureDict["DLSBD"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, last_seen_book, adj_price)
		}
	}

	//# features that need to be updated at TRADE
	if InSEventSlice(TRADE, spl.eventType) {
		bd := book.GetTradeDerivedBookDelta()
		net_oi_book, trade_book, taken_book, sweep_book := bd.Net_oi_book, bd.Trade_book, bd.Taken_book, bd.Sweep_book
		if feature, ok := spl.featureDict["OIB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, net_oi_book)
		}
		if feature, ok := spl.featureDict["TB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, trade_book)
		}
		if feature, ok := spl.featureDict["TLB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, taken_book)
		}
		if feature, ok := spl.featureDict["SLB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, sweep_book)
		}
		if feature, ok := spl.featureDict["DOIB"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, net_oi_book, adj_price)
		}
		if feature, ok := spl.featureDict["DTB"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, trade_book, adj_price)
		}
		if feature, ok := spl.featureDict["DTLB"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, taken_book, adj_price)
		}
		if feature, ok := spl.featureDict["DSLB"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, sweep_book, adj_price)
		}
		if feature, ok := spl.featureDict["OIBD"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, net_oi_book)
		}
		if feature, ok := spl.featureDict["TLBD"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, taken_book)
		}
		if feature, ok := spl.featureDict["SLBD"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, sweep_book)
		}
		//# features that depend on average price
		//TODO: upgrade to GetInferredHighLowLast when fully verified
		price_high, price_low, price_last, net_volume := book.GetCZCEInferredHighLowLast()
		hll := []float64{price_high, price_low, price_last}
		price_avg := (price_high + price_low + price_last) / 3

		if price_avg == 0 {
			tu.Logger.Error(fmt.Sprintf("price_ave==0 ex_timestamp=%.3f sid=%d price_high=%f price_low=%f price_last=%f",
				book.ExTimestamp, sid, price_high, price_low, price_last))
			tu.Logger.Error(fmt.Sprintf("top book bsize=%f bid=%.2f ask=%.2f asize=%f",
				book.GetBidSize(), book.GetBidPrice(), book.GetAskPrice(), book.GetAskSize()))
			return false
		}

		if feature, ok := spl.featureDict["BB"]; ok {
			feature.UpdateValue(sid, price_avg)
		}
		if feature, ok := spl.featureDict["ADX"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, hll)
		}
		if feature, ok := spl.featureDict["CCI"]; ok {
			feature.UpdateValue(sid, price_avg)
		}
		if feature, ok := spl.featureDict["RSI"]; ok {
			feature.UpdateValue(sid, price_avg)
		}
		if feature, ok := spl.featureDict["TSI"]; ok {
			feature.UpdateValue(sid, price_avg)
		}
		if feature, ok := spl.featureDict["SOI"]; ok {
			feature.UpdateValueSlice(sid, hll)
		}

		//# unpack price, size and side from agg_trade
		//t_price, t_size, t_side := book.AggTrade.Price, book.AggTrade.Size, book.AggTrade.Side
		t_size := book.AggTrade.Size //NOTE: t_price, t_side not used in this function
		//# change in open interest
		oi_delta := book.NewPos - book.UnwoundPos

		ntaoco := []float64{net_volume, t_size, avg_quote_size, oi_delta, book.CumVol, book.OI}
		ntao := ntaoco[:4]

		if feature, ok := spl.featureDict["TOIE"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, ntao)
		}
		if feature, ok := spl.featureDict["L1L2"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, ntaoco)
		}
		if spl.smoothPriceBaseFeature != "" {
			chartist := spl.featureDict[spl.smoothPriceBaseFeature].(*Chartist)
			if chartist.sidUniverse[sid] {
				if feature, ok := spl.featureDict["TOIU"]; ok {
					ele_is_up_trend := chartist.ExtremaIsMax(sid)
					if ele_is_up_trend {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, ntao)
					}
				}

				if feature, ok := spl.featureDict["TOID"]; ok {
					ele_is_up_trend := chartist.ExtremaIsMax(sid)
					if !ele_is_up_trend {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, ntao)
					}
				}

				if feature, ok := spl.featureDict["TOIA"]; ok {
					if m_price > smoothed_price {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, ntao)
					}
				}

				if feature, ok := spl.featureDict["TOIB"]; ok {
					if m_price < smoothed_price {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, ntao)
					}
				}
			}
		}

		adj_price_high := price_high - adj_price
		adj_price_low := price_low - adj_price
		adj_price_last := price_last - adj_price
		adj_price_avg := price_avg - adj_price

		ahll := []float64{adj_price_high, adj_price_low, adj_price_last}
		hlsnab := []float64{price_high, price_low, t_size, net_volume, adj_size_a, adj_size_b}
		if feature, ok := spl.featureDict["DADX"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, ahll)
		}
		if feature, ok := spl.featureDict["DRSI"]; ok {
			feature.UpdateValue(sid, adj_price_avg)
		}
		if feature, ok := spl.featureDict["DTSI"]; ok {
			feature.UpdateValue(sid, adj_price_avg)
		}
		if feature, ok := spl.featureDict["DSOI"]; ok {
			feature.UpdateValueSlice(sid, ahll)
		}
		if feature, ok := spl.featureDict["DVOL"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, t_size)
		}
		if feature, ok := spl.featureDict["DRNG"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, price_high)
		}
		if feature, ok := spl.featureDict["HPE"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, hlsnab)
		}
	}

	if spl.DoAppendData {
		spl.appendOutputData(sid, book)
	}
	return true
}

func RunBookSamplerV2(samplerPrefsFile string, mode SamplerMode, datestr string) {
	// create sampler object
	spl := &BookSamplerV2{}
	spl.Init(samplerPrefsFile, mode, datestr)
	fmt.Println(spl.sidUniverse)

	// new replay object
	replay := data.NewFLBTickDataReplay(samplerPrefsFile, datestr, true)

	//register three callback functions
	replay.RegisterSetup(func(sidList []int) {
		fmt.Println("I am in Setup and I see the following sids are avaliable from the 'replay' center: ")
		for _, sid := range sidList {
			fmt.Printf("%d ", sid)
		}
		fmt.Println()
	})

	replay.RegisterTickdataUpdate(func(slice *data.TesTOBSlice) {
		spl.OnTickDataUpdate(slice)
	}, spl.sidUniverse)
	replay.RegisterTeardown(spl.PublishData)

	replay.RegisterTeardown(func() {
		fmt.Println("I am in Teardown.")
	})

	// event loop
	replay.Replay()
}

func DumpMktData(symbol2fmid map[string]int, datestr string, samplerPrefsFile string, mode string) {

	if mode != "book" && mode != "trade" {
		panic(fmt.Sprintf("unsupported mode %s", mode))
	}

	fmid2rsid := map[int]int{}
	rsid2fmid := map[int]int{}

	fmids := make([]int, 0)

	for symbol, fmid := range symbol2fmid {
		date, _ := strconv.Atoi(datestr)
		if rawSid, ok := common.MostLiquidFuturesMap[common.MostLiquidKey{fmid, date}]; ok {
			fmids = append(fmids, fmid)
			fmt.Printf("%6d <-> %6d\n", fmid, rawSid)
			fmid2rsid[fmid] = rawSid
			rsid2fmid[rawSid] = fmid
		} else {
			msg := fmt.Sprintf("cannot find fmid mapping %d on %s; ignore this symbol %s.", fmid, datestr, symbol)
			println(msg)
		}
	}

	if len(fmids) == 0 {
		panic("Cannot build any fmid map. Check your secMaster cache.")
	}

	flbs := make(map[int]*data.FixedLevelBook)
	for _, fmid := range fmids {
		flbs[fmid] = data.NewFixedLevelBook(fmid2rsid[fmid], 1, 0)
	}

	// new replay object
	replay := data.NewFLBTickDataReplay(samplerPrefsFile, datestr, true)

	//register three callback functions
	replay.RegisterSetup(func(sidList []int) {
		fmt.Println("I am in Setup and I see the following sids are avaliable from the 'replay' center: ")
		for _, sid := range sidList {
			fmt.Printf("%d ", sid)
		}
		fmt.Println()
	})

	count := 0
	replay.RegisterTickdataUpdate(func(slice *data.TesTOBSlice) {
		//fmt.Printf("update sid : %d fmid:%d\n", slice.Sid, rsid2fmid[slice.Sid])
		fmid := rsid2fmid[slice.Sid]
		flb := flbs[fmid]
		flb.Update(slice)
		switch mode {
		case "trade":
			for _, t := range flb.InfTrades {
				count += 1
				fmt.Printf("TRADE,%d,%.0f,%v,%v,%v,%v,%v,%v,%v,%v\n", fmid, flb.ExTimestamp, common.SecSinceEpochToTimestr(flb.RecSecSinceEpoch-3600*8), flb.GetLastBidSize(), flb.GetLastBidPrice(), flb.GetLastAskPrice(), flb.GetLastAskSize(), t.Price, t.Size, t.Side)
			}
		case "book":
			fmt.Printf("BOOK,%d,%.3f,%.3f,%.0f,%.2f,%.2f,%.0f\n",
				fmid, flb.RecSecSinceEpoch, flb.ExTimestamp,
				flb.GetBidSize(), flb.GetBidPrice(), flb.GetAskPrice(), flb.GetAskSize())
		}
	}, fmids)

	replay.RegisterTeardown(func() {
		fmt.Printf("I am in Teardown. Total msgs: %d\n", count)
	})

	// event loop
	replay.Replay()
}
