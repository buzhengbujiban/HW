package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"log"
	"math"
)

/////////////////////////////////////////
// ATRItem
type ATRItem struct {
	last           float64
	high           float64
	low            float64
	atrEMA, prcEMA *MXEMA
}

const atrCPNAME = "MXATR"

var atrCPNames = []string{"prcEma.wgt", "prcEma.sum", "prcEma.t", "atrEma.wgt", "atrEma.sum", "atrEma.t"}

func (item *ATRItem) ToCP() []interface{} {
	return []interface{}{
		item.prcEMA.wgt,
		item.prcEMA.sum,
		item.prcEMA.t,
		item.atrEMA.wgt,
		item.atrEMA.sum,
		item.atrEMA.t}
}

func (item *ATRItem) FromCP(v []interface{}) {
	item.prcEMA.wgt = v[0].(float64)
	item.prcEMA.sum = v[1].(float64)
	item.prcEMA.t = v[2].(float64)
	item.atrEMA.wgt = v[3].(float64)
	item.atrEMA.sum = v[4].(float64)
	item.atrEMA.t = v[5].(float64)
}

func (item *ATRItem) String() string {
	return fmt.Sprintf("last=%f high=%f low=%f prcEma=[%s] atrEma=[%s]",
		item.last, item.high, item.low,
		item.prcEMA, item.atrEMA)
}

// return true if corp action factor != 1.
func (item *ATRItem) OVRoll(ca, emaTime float64) bool {
	r := false
	if math.Abs(1.-ca) > 1e-8 {
		item.prcEMA.sum *= ca
		item.atrEMA.sum *= ca
		r = true
	}
	item.prcEMA.t -= emaTime
	item.atrEMA.t -= emaTime
	return r
}

var _ OVIterm = (*ATRItem)(nil)

/////////////////////////////////////////
// Term MXATR
type MXATR struct {
	OVBase

	// ATR
	items []*ATRItem
	hl    float64
	debug bool
}

var (
	atrTermnamesDebug = []string{"high", "low", "last", "prcEma", "atrEma"}
	atrTermnames      = []string{""}
)

// prefs_name, feature_name, log_dir, datestr
func (t *MXATR) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *MXATR) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	t.UpdateCPInfo(t, atrCPNAME, atrCPNames)
	return nil
}

func (t *MXATR) TermName() string {
	return "MXATR"
}

func (t *MXATR) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *MXATR) names() []string {
	if t.debug {
		return atrTermnamesDebug
	}
	return atrTermnames
}

func (t *MXATR) inputs() []int {
	return []int{INPUT_MSG_TOB, INPUT_MSG_TRADE}
}

func (t *MXATR) loadFeaturePrefs() error {
	t.hl = t.prefs.GetFloat64PrefWithDefault(t.featureName+".hl", 300)
	t.debug = t.prefs.GetBoolPref(t.featureName + ".debug")
	log.Printf("MXATR half life=%f debug=%v\n", t.hl, t.debug)
	return nil
}

func (t *MXATR) loadDailyStats() {
}

//setFeatureNames: set column names.
func (t *MXATR) setFeatureNames() {
	t.colNames = t.names()
	for i, n := range t.colNames {
		if len(n) > 0 {
			t.colNames[i] = fmt.Sprintf("%s.%s.%s", t.featureName, n, HLFormat(t.hl))
			continue
		}
		t.colNames[i] = fmt.Sprintf("%s.%s", t.featureName, HLFormat(t.hl))
	}
}

//initialize internal variables
func (t *MXATR) initInternalVars() {
	t.OVInit()
	t.items = make([]*ATRItem, t.nSids)
	for idx, _ := range t.items {
		item := new(ATRItem)
		item.atrEMA = NewMXEMA(t.hl, 1.)
		item.prcEMA = NewMXEMA(t.hl, 1.)
		t.items[idx] = item
	}
}

func (t *MXATR) TermUpdateTOB(sid int, secs float64, it OVIterm, tob *MsgTOB) {
	item := it.(*ATRItem)
	item.last = tob.last

	if item.high == 0 || (tob.high > 0 && item.high < tob.high) {
		item.high = tob.high
	}
	if item.low == 0 || (tob.low > 0 && item.low > tob.low) {
		item.low = tob.low
	}
}

func (t *MXATR) TermUpdateTrade(sid int, secs float64, it OVIterm, trade *MsgTrade) {
	item := it.(*ATRItem)
	if item.high == 0 || item.high < trade.price {
		item.high = trade.price
	}
	if item.low == 0 || item.low > trade.price {
		item.low = trade.price
	}
}

func (t *MXATR) TermUpdateAny(sid int, secs float64, it OVIterm) {
	item := it.(*ATRItem)
	if item.last == 0 {
		return
	}

	item.prcEMA.Update(secs, item.last)

	tr := item.high - item.low
	item.atrEMA.Update(secs, tr)
}
func (t *MXATR) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*ATRItem)
	prcEma := item.prcEMA.GetEma()
	atrEma := item.atrEMA.GetEma()
	var atrNorm float64
	if prcEma > 0 {
		atrNorm = atrEma / prcEma
	}
	if t.debug {
		res[0] = item.high
		res[1] = item.low
		res[2] = item.last
		res[3] = prcEma
		res[4] = atrNorm
	} else {
		res[0] = atrNorm
	}
}

var _ OVInterface = (*MXATR)(nil)

func init() {
	TermFactoryInstance().Register("MX-ATR", func() ITerm { return &MXATR{} })
}
