package feature

import (
	tu "TES/tesUtilsGo"
	"autosupply/bookmsg"
	"fmt"
	"log"
)

// ASR: book Ask to aggressive Sell trade Ratio.

/////////////////////////////////////////
// ASRItem
type ASRItem struct {
	ratioEMA *MXEMA
	askSize  float64
	askPrice float64
	sellNotl float64
}

const ASRCPNAME = "MXASR"

var ASRCPNames = []string{"ratioEMA.wgt", "ratioEMA.sum", "ratioEMA.t"}

func (item *ASRItem) ToCP() []interface{} {
	r := []interface{}{item.ratioEMA.wgt, item.ratioEMA.sum, item.ratioEMA.t}
	if len(r) != len(ASRCPNames) {
		log.Panicf("ASRItem CP value size(%d) != CP names size(%d)\n", len(r), len(ASRCPNames))
	}
	return r
}

func (item *ASRItem) FromCP(v []interface{}) {
	i := 0
	item.ratioEMA.wgt, i = v[i].(float64), i+1
	item.ratioEMA.sum, i = v[i].(float64), i+1
	item.ratioEMA.t, i = v[i].(float64), i+1
}

func (item *ASRItem) String() string {
	return fmt.Sprintf("%T", item)
}

// return true if corp action factor != 1.
func (item *ASRItem) OVRoll(ca, emaTime float64) bool {
	item.ratioEMA.t -= emaTime
	return false
}

var _ OVIterm = (*ASRItem)(nil)

/////////////////////////////////////////
// Term: MXASR
type MXASR struct {
	OVBase

	// ASR
	items []*ASRItem
	hl    float64
}

// prefs_name, feature_name, log_dir, datestr
func (t *MXASR) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *MXASR) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	t.UpdateCPInfo(t, ASRCPNAME, ASRCPNames)
	return nil
}

func (t *MXASR) TermName() string {
	return "MXASR"
}

func (t *MXASR) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *MXASR) names() []string {
	return []string{""}
}

func (t *MXASR) inputs() []int {
	return []int{INPUT_MSG_TRADE, INPUT_MSG_TOB}
}

func (t *MXASR) loadFeaturePrefs() error {
	t.hl = t.prefs.GetFloat64PrefWithDefault(t.featureName+".hl", 300)
	return nil
}

func (t *MXASR) loadDailyStats() {
}

//setFeatureNames: set column names.
func (t *MXASR) setFeatureNames() {
	t.colNames = t.names()
	for i, _ := range t.colNames {
		// TODO: remove D1 after rec with julia
		t.colNames[i] = fmt.Sprintf("%s.D1.%s", t.featureName, HLFormat(t.hl))
	}
}

//initialize internal variables
func (t *MXASR) initInternalVars() {
	t.OVInit()
	t.items = make([]*ASRItem, t.nSids)
	for idx, _ := range t.items {
		t.items[idx] = &ASRItem{ratioEMA: NewMXEMA(t.hl, 1.)}
	}
}

func (t *MXASR) TermUpdateTOB(sid int, secs float64, it OVIterm, tob *MsgTOB) {
	item := it.(*ASRItem)
	if tob.askSize > 0 {
		item.askSize += tob.askSize
		item.askPrice = tob.askPrice
	}
	if item.sellNotl == 0 {
		return
	}

	r := item.askSize * item.askPrice / item.sellNotl
	item.ratioEMA.Update(secs, r)
	if !t.DataOnly() && sid == 0 && secs < 100 {
		fmt.Printf("secs=%f sid=%d askSize=%f askPrice=%f sellNotl=%f ratioEma=%f\n",
			secs, sid, item.askSize, item.askPrice, item.sellNotl, item.ratioEMA.GetEma())
	}
}

func (t *MXASR) TermUpdateTrade(sid int, secs float64, it OVIterm, trade *MsgTrade) {
	item := it.(*ASRItem)
	if trade.dir == bookmsg.DirSell {
		item.sellNotl += trade.shares * trade.price
	}
}

// snap
func (t *MXASR) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*ASRItem)
	res[0] = item.ratioEMA.GetEma()
}

var _ OVInterface = (*MXASR)(nil)

func init() {
	TermFactoryInstance().Register("MX-ASR", func() ITerm { return &MXASR{} })
}
