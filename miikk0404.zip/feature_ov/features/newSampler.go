// 20200214, yzhu, SamplerCore for both futures and equity

package feature

import (
	"autosupply/bookmsg"
	"autosupply/model"
	"fmt"
	"math"
	"math/rand"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"table"

	"TES/QR/alpha_ov/data"
	tu "TES/tesUtilsGo"
	"TES/tesUtilsGo/common"
)

var PanelRootInFeature string
var HAStatsRootInFeature string

const NumSamplerMetaFields = 7

type EventIndex int

const (
	TradeIdx EventIndex = iota
	PriceIdx
	QuoteIdx
	TimerIntervalIdx

	NumEvents /* Keep NumEvents as last enum */
)

type IntervalTimer struct {
	sidList         []int
	intervalId      []int
	secsPerInterval int
}

func NewIntervalTimer(sidList []int, secsPerInterval int) *IntervalTimer {
	return &IntervalTimer{
		sidList:         sidList,
		intervalId:      make([]int, len(sidList)+1), // the last field is used for a global timer
		secsPerInterval: secsPerInterval,
	}
}

func (it *IntervalTimer) Update(sidIdx int, epochSec float64) bool {
	tmp := int(math.Floor(epochSec / float64(it.secsPerInterval)))
	if tmp > it.intervalId[sidIdx] {
		it.intervalId[sidIdx] = tmp
		return true
	} else {
		return false
	}
}

/*
Naming convention note:

	strictly speaking most `sid` usages should be named as gid (generic sid), which is either fmid or raw sid
	but a lot of places `sid` is used for gid
	and considering that rawsid is seldom used in most places
	we use `rawsid` as raw sid and `sid` as gid
*/
type SidListInfo struct {
	sidList    []int       // generic id (rawsid/fmid) list
	rawsidList []int       // rawsid list
	rawsid2gid map[int]int // rawsid -> generic id
	sid2idx    map[int]int // generic id -> idx in sidList
}

func NewSidListInfoWithGidList(dateStr string, gidList []int) *SidListInfo {
	sort.Ints(gidList)
	m, err := common.MakeFmidMap(gidList, dateStr)
	if err != nil {
		tu.Logger.Info(fmt.Sprintf("ERROR: %s\n", err.Error()))
	}
	if len(m.Rsid2fmid) == 0 {
		panic(fmt.Sprintf("None of the gid(sid/fmid) could find sid map on %s. gids = %v", dateStr, gidList))
	}

	sidList := make([]int, len(gidList))
	for i, gid := range gidList {
		sidList[i] = m.Fmid2rsid[gid]
	}

	gid2idx := make(map[int]int)
	for i, gid := range gidList {
		gid2idx[gid] = i
	}

	return &SidListInfo{
		sidList:    gidList,
		rawsidList: sidList,
		rawsid2gid: m.Rsid2fmid,
		sid2idx:    gid2idx,
	}
}

func NewSidListInfo(dateStr string, sidNameList []string, panelRoot string) *SidListInfo {
	gidSet := make(map[int]bool)
	for _, sidName := range sidNameList {
		if val, err := strconv.ParseInt(sidName, 10, 64); err == nil {
			gidSet[int(val)] = true
		} else {
			sids := common.GetSidListByNameNew(dateStr, sidName, panelRoot)
			for _, sid := range sids {
				gidSet[sid] = true
			}
		}
	}

	gidList := make([]int, 0, len(gidSet))
	for gid := range gidSet {
		gidList = append(gidList, gid)
	}

	return NewSidListInfoWithGidList(dateStr, gidList)
}

func (s *SidListInfo) ContainsRawSid(rawsid int) bool {
	_, ok := s.rawsid2gid[rawsid]
	return ok
}

func (s *SidListInfo) ContainsSid(sid int) bool {
	_, ok := s.sid2idx[sid]
	return ok
}

func (s *SidListInfo) Size() int {
	return len(s.sidList)
}

type ISampler interface {
	// IMsgObserver
	Start()
	Final()
	OnMsg(data model.IMsg)

	// Getters
	GetHeaders() []string
	GetOneFeatureVec() []float64
	GetDoneSnapFeatures() bool

	GetNumMetaFields() int
	GetNumFeatures() int
	GetNumActiveFeatures() int
	GetExtraNumFeatures() int

	// Special funcs
	FinalizeExtraFeatures(dt *table.DataTable, extraFeatureOffset int)

	// For snap all at once
	SnapOnlyAtTimeIntervalEventsAndSnapAllAtOnce() bool
	GetOneFeatureVecForSid(sid int) []float64
	GetSnapSidsQueue() []int
}

type SamplerCore struct {
	prefFileName string
	prefs        *tu.PreferenceAdapter

	alphaMode bool

	/* output */
	outputRoot      string
	logDir          string
	outputBySession bool
	outputName      string

	/* D */
	dateStr     string
	dateInt     int
	prevDateStr string

	/* S */
	fullSid *SidListInfo
	snapSid *SidListInfo

	// NOTE: snap2 is a mechanism to speed up computation for HB, not used for HC anymore
	//       any sid not in snap2 set will be periodically dropped for its snaps
	//       this makes snap2 set as the main sid set and non-snap2 set as supplymentary set
	snap2Cnt []int
	snap2Sid *SidListInfo
	snap2mod int

	/* E */
	eventFlags        [NumEvents]bool
	snapEventFlags    [NumEvents]bool
	publishEventFlags [NumEvents]bool
	ivalTimer         *IntervalTimer

	doneSnapFeatures bool
	numSnaps         int

	numPublishes   int
	snapIdx2PubIdx map[int]int     // a subset of snap leads to publish
	downSampleRate map[int]float64 // session -> down sample rate

	/* V */
	featureDict map[string]FeatureInterface //feature abbrev name -> feature object

	featureNameList      []string //feature names sorted alphabetically
	extraFeatureNameList []string //extra feature names not sorted

	numFeatures      int
	extraNumFeatures int

	featurePosOffset      []int
	extraFeaturePosOffset []int

	headers       []string
	oneFeatureVec []float64

	snapOnlyAtTimeIntervalEventsAndSnapAllAtOnce bool
	oneFeatureVecPerSid                          map[int][]float64
	snapSidsQueue                                []int

	inactiveFeatureNames []string
	numActiveFeatures    int
	activePosMap         []int // new pos -> old pos
	activeHeaders        []string

	/* callback funcs impl by sub classes */
	sessionFunc func(epochSec float64) int
	wgtFunc     func(sid int) float64

	/* Output */
	dt *table.DataTable
}

func NewSamplerCore(dateStr string, prefFileName string, alphaMode bool) *SamplerCore {
	sc := new(SamplerCore)
	// prefs object
	sc.prefFileName = prefFileName
	sc.prefs = tu.NewPreferenceAdapter(prefFileName)

	// is inside alpha or independent
	sc.alphaMode = alphaMode

	// general prefs
	panelRoot := sc.prefs.GetStringPref("panel_root")
	data.SetPanelRoot(panelRoot)                                  // set panel root to data package
	PanelRootInFeature = panelRoot                                // set panel root to feature package
	HAStatsRootInFeature = sc.prefs.GetStringPref("hastats_root") // set hastats root to feature package

	// output
	sc.outputRoot = sc.prefs.GetStringPref("output_dir")
	sc.outputBySession = sc.prefs.GetBoolPref("output_by_session")
	sc.logDir = filepath.Join(sc.outputRoot, "sampler_log")
	if sc.prefs.HasPref("output_name") {
		sc.outputName = sc.prefs.GetStringPref("output_name")
	} else {
		sc.outputName = "sampler"
	}

	// D
	sc.dateStr = dateStr
	sc.dateInt, _ = strconv.Atoi(dateStr)
	sc.prevDateStr = common.PreTradeDate(dateStr)

	// S
	fullSidList := sc.prefs.GetStringListPref("sid_list")
	tu.Logger.Info(fmt.Sprintf("NewSamplerCore: sid list: %v\n", fullSidList))
	sc.fullSid = NewSidListInfo(dateStr, fullSidList, PanelRootInFeature)
	if sc.prefs.HasPref("snap_sid_list") {
		snapSidList := sc.prefs.GetStringListPref("snap_sid_list")
		sc.snapSid = NewSidListInfo(dateStr, snapSidList, PanelRootInFeature)
		for _, gid := range sc.snapSid.sidList {
			if !sc.fullSid.ContainsSid(gid) {
				panic(fmt.Sprintf("Wrong snap_sid_list; snap sid %d is not in (full) sid_list!", gid))
			}
		}
	} else {
		// if snapSid is not specified, then snap full sid list
		sc.snapSid = sc.fullSid
	}

	if sc.prefs.HasPref("snap2_sid_list") {
		snap2SidList := sc.prefs.GetStringListPref("snap2_sid_list")
		sc.snap2Sid = NewSidListInfo(dateStr, snap2SidList, PanelRootInFeature)
		for _, gid := range sc.snap2Sid.sidList {
			if !sc.snapSid.ContainsSid(gid) {
				panic(fmt.Sprintf("Wrong snap2_sid_list; snap2 sid %d is not in snap_sid_list!", gid))
			}
		}
		sc.snap2Cnt = make([]int, sc.fullSid.Size())
		sc.snap2mod = sc.prefs.GetIntPref("snap2_mod")
	} else {
		sc.snap2mod = 0
	}

	// E
	secsPerInterval := sc.prefs.GetIntPref("timer_interval")
	sc.ivalTimer = NewIntervalTimer(sc.fullSid.sidList, secsPerInterval)

	parseEventFlags := func(eventNames []string) [NumEvents]bool {
		var flags [NumEvents]bool
		for _, eventName := range eventNames {
			switch eventName {
			case "TIMER":
				flags[TimerIntervalIdx] = true
			case "QUOTE":
				flags[QuoteIdx] = true
			case "TRADE":
				flags[TradeIdx] = true
			default:
				panic(fmt.Sprintf("Unknown snap event name: %s", eventName))
			}
		}
		return flags
	}

	// parse snap events
	snapEvents := sc.prefs.GetStringListPref("snap_events")
	sc.snapEventFlags = parseEventFlags(snapEvents)

	// snap ONLY at time-interval events and snap ALL at once
	if sc.prefs.HasPref("snap_only_at_time_interval_events_and_snap_all_at_once") {
		sc.snapOnlyAtTimeIntervalEventsAndSnapAllAtOnce = sc.prefs.GetBoolPref("snap_only_at_time_interval_events_and_snap_all_at_once")
	} else {
		sc.snapOnlyAtTimeIntervalEventsAndSnapAllAtOnce = false
	}
	if sc.snapOnlyAtTimeIntervalEventsAndSnapAllAtOnce {
		fmt.Printf("Set snapOnlyAtTimeIntervalEventsAndSnapAllAtOnce!\n")
		for i := 0; i < int(NumEvents); i++ {
			if (i == int(TimerIntervalIdx) && sc.snapEventFlags[i] == true) ||
				(i != int(TimerIntervalIdx) && sc.snapEventFlags[i] == false) {
				//OK
			} else {
				fmt.Printf("i=%d eventFlags=%v\n", i, sc.snapEventFlags)
				panic("Check your snap events settings; when you set snap_only_at_time_interval_events_and_snap_all_at_once, you can only snap at time intervals!")
			}
		}
	}
	sc.snapSidsQueue = make([]int, 0, 2000)

	// parse publish events
	publishEvents := sc.prefs.GetStringListPref("publish_events")
	sc.publishEventFlags = parseEventFlags(publishEvents)

	sc.snapIdx2PubIdx = make(map[int]int)

	// session based down sampling
	rand.Seed(37)
	downSampleRateSpec := sc.prefs.GetStringPref("down_sample_rate")
	sc.downSampleRate = make(map[int]float64)
	if downSampleRateSpec != "" {
		fields := strings.Split(downSampleRateSpec, ",")
		for _, field := range fields {
			s := strings.Split(field, ":")
			session, _ := strconv.Atoi(s[0])
			rate, _ := strconv.ParseFloat(s[1], 64)
			if rate >= 0 && rate <= 1 {
				sc.downSampleRate[session] = rate
			} else {
				panic(fmt.Sprintf("Wrong down_sample_rate spec: %s", downSampleRateSpec))
			}
		}
	}

	// V
	sc.featureDict = make(map[string]FeatureInterface)

	loadOneFeatureName := func(fn string) {
		className := sc.prefs.GetStringPref(fmt.Sprintf("%s_class_name", fn))
		prefsName := sc.prefs.GetStringPref(fmt.Sprintf("%s_prefs_name", fn))
		sc.featureDict[fn] = NewFeatureInst(prefsName, fn, className, sc.logDir, sc.dateStr)

		// TODO: Ugly logic because feature does not have the concept of full_sid and snap_sid
		if fn == "FWDMRET" || fn == "OVFWDRET" {
			sc.featureDict[fn].SetSidUniverse(sc.fullSid.sidList[0], sc.fullSid.sidList[1:])
		} else if fn == "MX-ASR" || fn == "MX-ATR" || fn == "MX-BSD" || fn == "MX-BSN" || fn == "MX-DPO" ||
			fn == "MX-ENP" || fn == "MX-ICK" || fn == "MX-KAMA" || fn == "MX-MACD" ||
			fn == "MX-MRET" || fn == "MX-MSI" || fn == "MX-MVOL" || fn == "MX-PCG" || fn == "MX-PDT" ||
			fn == "MX-VPC" || fn == "MX-RCE" || fn == "MX-TRD" || fn == "MX-TNOP" || fn == "MX-UCR" || fn == "MX-VTR" || fn == "MX-VPT" || fn == "MX-VWP" ||
			fn == "E-7" || fn == "E-7L1" || fn == "E-7L2" || fn == "E-8" {
			// Special logic for MX set universe
			term := sc.featureDict[fn].(ITerm)
			term.Init(sc.snapSid.sidList)
			sc.featureDict[fn].SetSidUniverse(sc.snapSid.sidList[0], sc.snapSid.sidList[1:])
		} else {
			//TODO: check if len(snapSid) = 1
			sc.featureDict[fn].SetSidUniverse(sc.snapSid.sidList[0], sc.snapSid.sidList[1:])
		}
	}

	// init normal feature list
	sc.featureNameList = sc.prefs.GetStringListPref("feature_list")
	sort.Strings(sc.featureNameList)
	for _, fn := range sc.featureNameList {
		loadOneFeatureName(fn)
	}

	// init extra feature list
	sc.extraFeatureNameList = sc.prefs.GetStringListPref("extra_feature_list")
	for _, efn := range sc.extraFeatureNameList {
		loadOneFeatureName(efn)
	}

	// header and full feature vector
	sc.setHeader()
	sc.oneFeatureVec = make([]float64, len(sc.headers))
	sc.oneFeatureVecPerSid = make(map[int][]float64)
	for _, sid := range sc.snapSid.sidList {
		sc.oneFeatureVecPerSid[sid] = make([]float64, len(sc.headers))
	}

	// inactive features
	sc.setInactiveFeatures()

	// Output DataTable
	if !sc.alphaMode {
		sc.createOutputDir()
		sc.dt = table.NewDataTable(len(sc.activeHeaders))
		sc.dt.SetColNames(sc.activeHeaders)
		sc.dt.SetDefaultTypes(table.TYPE_F32)
		sc.dt.SetColNameTypes([]string{"sid", "rec_epoch", "src_epoch", "date"}, table.TYPE_F64)
	}

	return sc
}

func (sc *SamplerCore) GetHeaders() []string {
	return sc.activeHeaders
}

func (sc *SamplerCore) GetDoneSnapFeatures() bool {
	return sc.doneSnapFeatures
}

func (sc *SamplerCore) GetOneFeatureVec() []float64 {
	if sc.inactiveFeatureNames == nil {
		return sc.oneFeatureVec
	} else {
		return sc.oneFeatureVec[:len(sc.activePosMap)]
	}
}

/* the following three functions are for snap all at once */
func (sc *SamplerCore) SnapOnlyAtTimeIntervalEventsAndSnapAllAtOnce() bool {
	return sc.snapOnlyAtTimeIntervalEventsAndSnapAllAtOnce
}

func (sc *SamplerCore) GetSnapSidsQueue() []int {
	return sc.snapSidsQueue
}

func (sc *SamplerCore) GetOneFeatureVecForSid(sid int) []float64 {
	if sc.inactiveFeatureNames == nil {
		return sc.oneFeatureVecPerSid[sid]
	} else {
		return sc.oneFeatureVecPerSid[sid][:len(sc.activePosMap)]
	}
}

func (sc *SamplerCore) GetNumMetaFields() int {
	return NumSamplerMetaFields
}

func (sc *SamplerCore) GetNumActiveFeatures() int {
	return sc.numActiveFeatures
}

func (sc *SamplerCore) GetNumFeatures() int {
	return sc.numFeatures
}

func (sc *SamplerCore) GetExtraNumFeatures() int {
	return sc.extraNumFeatures
}

func (sc *SamplerCore) FinalizeExtraFeatures(dt *table.DataTable, extraFeatureOffset int) {
	/*
		extraFeatureOffset = 0                  in samplerMode
		                   = -(NumFeatures - 1) in alphaMode
	*/
	// finalize & revision (for Forward Stats)
	var allUpdates []table.IJVTuple
	for featIdx, featName := range sc.extraFeatureNameList {
		sc.featureDict[featName].Finalize()
		revisionList := sc.featureDict[featName].GetRevisionList()
		if len(revisionList) > 0 {
			for _, update := range revisionList {
				if !sc.alphaMode { // sampler mode
					if publishIdx, ok := sc.snapIdx2PubIdx[update.i]; ok {
						allUpdates = append(allUpdates, table.IJVTuple{publishIdx, sc.extraFeaturePosOffset[featIdx] + update.j + extraFeatureOffset, update.v})
					}
				} else { // alpha mode
					allUpdates = append(allUpdates, table.IJVTuple{update.i, sc.extraFeaturePosOffset[featIdx] + update.j + extraFeatureOffset, update.v})
				}
			}
		}
	}
	// set to DT
	dt.SetIJVTuples(allUpdates)
}

func (sc *SamplerCore) verifySamplerCore() {
	if sc.sessionFunc == nil {
		panic(fmt.Sprintf("SamplerCore's sessionFunc must be set!"))
	}

	// snapEvents must be set
	snap := false
	for _, flag := range sc.snapEventFlags {
		snap = snap || flag
	}
	if !snap {
		panic("Sampler snap event not set")
	}

	// publishEvents must be set
	if !sc.alphaMode {
		publish := false
		for _, flag := range sc.publishEventFlags {
			publish = publish || flag
		}
		if !publish {
			panic("Sampler publish event not set")
		}
	}
}

func (sc *SamplerCore) createOutputDir() {
	// Create output dir
	outputDir := filepath.Join(sc.outputRoot, sc.dateStr)
	if _, err := os.Stat(outputDir); err != nil {
		//path not exist
		err := os.MkdirAll(outputDir, os.ModePerm)
		if err != nil {
			msg := fmt.Sprintf("cannot create folder %s; pleae check permission.", outputDir)
			panic(msg)
		}
	} else {
		// path already exists, test if it is writable
		if !IsPathWritable(sc.outputRoot) {
			panic(fmt.Sprintf("I don't have write access to the output root folder: %s", sc.outputRoot))
		}
	}

	// Copy prefs file to output directory
	localFileName := filepath.Join(sc.outputRoot, "sampler.prefs")
	_, err := tu.Copy(sc.prefFileName, localFileName, true)
	if err != nil {
		tu.Logger.Error(fmt.Sprintf("cannot copy prefs file %s to %s", sc.prefFileName, localFileName))
	}
}

func (sc *SamplerCore) writeSamplerTable() {
	if sc.outputBySession {
		outDir := filepath.Join(sc.outputRoot, sc.dateStr)
		outFiles := table.FWriteWithSessionSplits(sc.dt, outDir, sc.outputName, "session", table.COMPRESSION_ZSTD)
		tu.Logger.Info(fmt.Sprintf("Sampler Output written to : \n%s", strings.Join(outFiles, "\n")))
	} else {
		outTblFile := filepath.Join(sc.outputRoot, sc.dateStr, sc.outputName+".tbl")
		table.FWrite(outTblFile, sc.dt, table.COMPRESSION_ZSTD)
		tu.Logger.Info(fmt.Sprintf("Sampler Output written to : %s", outTblFile))
	}
}

func (sc *SamplerCore) resetEventFlags() {
	for i := 0; i < int(NumEvents); i++ {
		sc.eventFlags[i] = false
	}
	sc.doneSnapFeatures = false
}

func (sc *SamplerCore) setHeader() {
	sc.headers = make([]string, 0)

	// meta features
	metaHeaders := [NumSamplerMetaFields]string{
		"sid",
		"rec_epoch",
		"src_epoch",
		"date",
		"session",
		"event",
		"wgt",
	}
	for _, s := range metaHeaders {
		sc.headers = append(sc.headers, s)
	}

	// normal features
	sc.numFeatures = 0
	sc.featurePosOffset = make([]int, len(sc.featureNameList)+1)
	for i, fn := range sc.featureNameList {
		sc.featurePosOffset[i] = NumSamplerMetaFields + sc.numFeatures
		sc.numFeatures += len(sc.featureDict[fn].GetFeatureNames())
		sc.headers = append(sc.headers, sc.featureDict[fn].GetFeatureNames()...)
	}
	sc.featurePosOffset[len(sc.featureNameList)] = NumSamplerMetaFields + sc.numFeatures

	// extra features
	sc.extraNumFeatures = 0
	sc.extraFeaturePosOffset = make([]int, len(sc.extraFeatureNameList)+1)
	for i, efn := range sc.extraFeatureNameList {
		sc.extraFeaturePosOffset[i] = NumSamplerMetaFields + sc.numFeatures + sc.extraNumFeatures
		sc.extraNumFeatures += len(sc.featureDict[efn].GetFeatureNames())
		sc.headers = append(sc.headers, sc.featureDict[efn].GetFeatureNames()...)
	}
	sc.extraFeaturePosOffset[len(sc.extraFeatureNameList)] = NumSamplerMetaFields + sc.numFeatures + sc.extraNumFeatures
}

func (sc *SamplerCore) setInactiveFeatures() {
	if !sc.prefs.HasPref("inactive_feature_list") {
		sc.inactiveFeatureNames = nil
		sc.numActiveFeatures = sc.numFeatures
		sc.activePosMap = nil
		sc.activeHeaders = sc.headers
		return
	}
	sc.inactiveFeatureNames = sc.prefs.GetStringListPref("inactive_feature_list")
	markInactivePos := make([]bool, len(sc.headers))
	for _, inactiveName := range sc.inactiveFeatureNames {
		foundJ := -1
		for j, name := range sc.headers {
			if name == inactiveName {
				foundJ = j
				break
			}
		}
		if foundJ == -1 {
			panic(fmt.Sprintf("Could not find inactive feature %s in the full feature list", inactiveName))
		} else {
			if markInactivePos[foundJ] {
				panic(fmt.Sprintf("Feature name %s duplicated in the inactive_feature_list", inactiveName))
			} else {
				markInactivePos[foundJ] = true
			}
		}
	}

	sc.numActiveFeatures = sc.numFeatures - len(sc.inactiveFeatureNames)
	sc.activePosMap = make([]int, NumSamplerMetaFields+sc.numActiveFeatures+sc.extraNumFeatures)
	activePos := 0
	for j, isInactive := range markInactivePos {
		if !isInactive {
			sc.activePosMap[activePos] = j
			activePos++
		}
	}
	if activePos != len(sc.activePosMap) {
		panic("Something wrong in setInactiveFeatures; activePos != NumSamplerMetaFields+sc.numActiveFeatures+sc.extraNumFeatures")
	}

	sc.activeHeaders = make([]string, len(sc.activePosMap))
	for i, j := range sc.activePosMap {
		sc.activeHeaders[i] = sc.headers[j]
	}
}

func (sc *SamplerCore) GetSnapEventId() int {
	snapEventId := -1
	for i := 0; i < int(NumEvents); i++ {
		if sc.eventFlags[i] && sc.snapEventFlags[i] {
			snapEventId = i
			break
		}
	}
	return snapEventId
}

func (sc *SamplerCore) snapCheck(sid int) bool {
	// check if in snap sid
	if !sc.snapSid.ContainsSid(sid) {
		return false
	}

	// check event flags and decide snap or not
	snapEventId := sc.GetSnapEventId()
	if snapEventId < 0 {
		return false
	}

	// check snap2 logic
	if sc.snap2mod != 0 && !sc.snap2Sid.ContainsSid(sid) {
		// not in snap2 set
		sidIdx := sc.fullSid.sid2idx[sid]
		cnt := sc.snap2Cnt[sidIdx]
		sc.snap2Cnt[sidIdx] = cnt + 1
		if cnt > 5 && (sid+cnt)%sc.snap2mod != 0 {
			// not-in-mod
			return false
		}
	}

	return true
}

func (sc *SamplerCore) snapFeatures(sid int, ourEpoch float64, srcEpoch float64,
	priceM float64, adjRecEpoch float64 /* priceM, adjRecEpoch used by GetSidValues */) {

	// meta info
	snapEventId := sc.GetSnapEventId()
	sessionId := sc.sessionFunc(ourEpoch)
	sc.oneFeatureVec[0] = float64(sid)
	sc.oneFeatureVec[1] = ourEpoch
	sc.oneFeatureVec[2] = srcEpoch
	sc.oneFeatureVec[3] = float64(sc.dateInt)
	sc.oneFeatureVec[4] = float64(sessionId)
	sc.oneFeatureVec[5] = float64(snapEventId)
	sc.oneFeatureVec[6] = sc.wgtFunc(sid)

	calculateOneFeature := func(fn string, beginIdx int, endIdx int) {
		var vals []float64

		/* NOTE: PerSid mode in Futures will be disabled
		if spl.mode == PerSid {
			vals, _ = spl.featureDict[fn].GetValues(priceM, adjRecEpoch)
		}
		*/

		if fn == "Z1-BP" || fn == "Z1-HBP" || fn == "Z1-SD" || fn == "Z1-SL" || fn == "Z1-HSL" || fn == "Z1-TSD" || fn == "Z1-PSP" ||
			fn == "Z1-PS" || fn == "Z1-PS2" || fn == "Z1-PS3" || fn == "Z1-LC" || fn == "Z1-LC2" || fn == "Z1-AGT" || fn == "Z1-AGT2" || fn == "Z1-AGT3" ||
			fn == "Z1-AGT4" || fn == "Z1-AGT5" || fn == "Z1-DBG" ||
			fn == "MX-ASR" || fn == "MX-ATR" || fn == "MX-BSD" || fn == "MX-BSN" || fn == "MX-DPO" ||
			fn == "MX-ENP" || fn == "MX-ICK" || fn == "MX-KAMA" || fn == "MX-MACD" ||
			fn == "MX-MRET" || fn == "MX-MSI" || fn == "MX-MVOL" || fn == "MX-PCG" || fn == "MX-PDT" ||
			fn == "MX-VPC" || fn == "MX-RCE" || fn == "MX-TRD" || fn == "MX-TNOP" || fn == "MX-UCR" || fn == "MX-VTR" || fn == "MX-VPT" || fn == "MX-VWP" ||
			fn == "OVFWDRET" ||
			fn == "E-7" || fn == "E-7L1" || fn == "E-7L2" || fn == "E-8" /* special one, as its input timestamp is not adjusted */ {
			vals, _ = sc.featureDict[fn].GetSidValues(sid, priceM, ourEpoch)
		} else {
			vals, _ = sc.featureDict[fn].GetSidValues(sid, priceM, adjRecEpoch)
		}

		numExpectedVals := endIdx - beginIdx
		if numExpectedVals != len(vals) {
			msg := fmt.Sprintf("feature %s expects %d values, but get %v", fn, numExpectedVals, vals)
			panic(msg)
		}

		for i := beginIdx; i < endIdx; i++ {
			sc.oneFeatureVec[i] = vals[i-beginIdx]
		}
	}

	// calculate each feature
	for i, fn := range sc.featureNameList {
		beginIdx := sc.featurePosOffset[i]
		endIdx := sc.featurePosOffset[i+1]
		calculateOneFeature(fn, beginIdx, endIdx)
	}

	// calculate each extra feature
	for i, efn := range sc.extraFeatureNameList {
		beginIdx := sc.extraFeaturePosOffset[i]
		endIdx := sc.extraFeaturePosOffset[i+1]
		calculateOneFeature(efn, beginIdx, endIdx)
	}

	// shift oneFeatureVec to remove inactive features
	if sc.inactiveFeatureNames != nil {
		for i, j := range sc.activePosMap {
			sc.oneFeatureVec[i] = sc.oneFeatureVec[j]
		}
	}

	// make a copy to the per sid vector store
	copy(sc.oneFeatureVecPerSid[sid], sc.oneFeatureVec)

	sc.doneSnapFeatures = true
	if !sc.alphaMode {
		sc.numSnaps++

		doPublish := false
		// check publish events
		for i := 0; i < int(NumEvents); i++ {
			if sc.eventFlags[i] && sc.publishEventFlags[i] {
				doPublish = true
				break
			}
		}
		// check session based down sampling
		if doPublish {
			if rate, ok := sc.downSampleRate[sessionId]; ok {
				if rand.Float64() /* [0.0, 1.0) */ >= rate {
					doPublish = false
				}
			}
		}

		if doPublish {
			sc.numPublishes++
			sc.snapIdx2PubIdx[sc.numSnaps-1] = sc.numPublishes - 1
			if sc.inactiveFeatureNames == nil {
				sc.dt.AddRow(sc.oneFeatureVec)
			} else {
				sc.dt.AddRow(sc.oneFeatureVec[:len(sc.activePosMap)])
			}
		}
	}
}

/*
The following must be called by a concrete impl of Sampler
*/

func (sc *SamplerCore) start() {
	sc.verifySamplerCore()
}

func (sc *SamplerCore) final() {
	if !sc.alphaMode {
		sc.FinalizeExtraFeatures(sc.dt, -(sc.numFeatures - sc.numActiveFeatures))
		sc.writeSamplerTable()
	}
}

func (sc *SamplerCore) onMsg(data model.IMsg) {
	// reset event flags on each msg
	sc.resetEventFlags()

	switch msg := data.(type) {
	case *bookmsg.FLBEndBatchMsg:
		if !sc.fullSid.ContainsRawSid(msg.Sid) {
			return
		}

		sid := sc.fullSid.rawsid2gid[msg.Sid]
		sidIdx := sc.fullSid.sid2idx[sid]

		// TODO: entry point to refactor Event logic
		// check if timer triggered
		if sc.snapSid.ContainsSid(sid) {
			if sc.snapOnlyAtTimeIntervalEventsAndSnapAllAtOnce {
				//                                                    last position reserved for global interval updater
				sc.eventFlags[TimerIntervalIdx] = sc.ivalTimer.Update(len(sc.fullSid.sidList), msg.SrcEpoch)
				if sc.eventFlags[TimerIntervalIdx] {
					fmt.Printf("Ival Event: %s\n", common.SecSinceEpochToTimestr(msg.OurEpoch))
				}
			} else {
				sc.eventFlags[TimerIntervalIdx] = sc.ivalTimer.Update(sidIdx, msg.SrcEpoch)
			}
		}
	default:
		// no action for other msgs
	}
}
