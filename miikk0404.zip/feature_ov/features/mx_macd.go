package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"log"
	"math"
)

// MACD: moving average convergence divergence

/////////////////////////////////////////
// MACDItem
type MACDItem struct {
	fast, slow *MXEMA
}

const MACDCPNAME = "MXMACD"

var MACDCPNames = []string{"fast.wgt", "fast.sum", "fast.t", "slow.wgt", "slow.sum", "slow.t"}

func (item *MACDItem) ToCP() []interface{} {
	r := []interface{}{
		item.fast.wgt, item.fast.sum, item.fast.t,
		item.slow.wgt, item.slow.sum, item.slow.t,
	}
	if len(r) != len(MACDCPNames) {
		log.Panicf("MACDItem CP value size(%d) != CP names size(%d)\n", len(r), len(MACDCPNames))
	}
	return r
}

func (item *MACDItem) FromCP(v []interface{}) {
	i := 0
	item.fast.wgt, i = v[i].(float64), i+1
	item.fast.sum, i = v[i].(float64), i+1
	item.fast.t, i = v[i].(float64), i+1
	item.slow.wgt, i = v[i].(float64), i+1
	item.slow.sum, i = v[i].(float64), i+1
	item.slow.t, i = v[i].(float64), i+1
}

func (item *MACDItem) String() string {
	return fmt.Sprintf("%T", item)
}

// return true if corp action factor != 1.
func (item *MACDItem) OVRoll(ca, emaTime float64) bool {
	r := false
	if math.Abs(1.-ca) > 1e-8 {
		item.fast.sum *= ca
		item.slow.sum *= ca
		r = true
	}
	item.fast.t -= emaTime
	item.slow.t -= emaTime
	return r
}

var _ OVIterm = (*MACDItem)(nil)

/////////////////////////////////////////
// Term: MXMACD
type MXMACD struct {
	OVBase

	// MACD
	items          []*MACDItem
	hlSlow, hlFast float64
}

// prefs_name, feature_name, log_dir, datestr
func (t *MXMACD) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *MXMACD) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	t.UpdateCPInfo(t, MACDCPNAME, MACDCPNames)
	return nil
}

func (t *MXMACD) TermName() string {
	return "MXMACD"
}

func (t *MXMACD) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *MXMACD) names() []string {
	return []string{"mavg"}
}

func (t *MXMACD) inputs() []int {
	return []int{INPUT_MSG_TOB}
}

func (t *MXMACD) loadFeaturePrefs() error {
	t.hlFast = t.prefs.GetFloat64PrefWithDefault(t.featureName+".hlFast", 300)
	t.hlSlow = t.prefs.GetFloat64PrefWithDefault(t.featureName+".hlSlow", 600)
	return nil
}

func (t *MXMACD) loadDailyStats() {
}

//setFeatureNames: set column names.
func (t *MXMACD) setFeatureNames() {
	t.colNames = t.names()
	for i, n := range t.colNames {
		// TODO: remove 3m after rec with Julia
		t.colNames[i] = fmt.Sprintf("%s.%s%s3m.%s", t.featureName, HLFormat(t.hlSlow), HLFormat(t.hlFast), n)
	}
}

//initialize internal variables
func (t *MXMACD) initInternalVars() {
	t.OVInit()
	t.items = make([]*MACDItem, t.nSids)
	for idx, _ := range t.items {
		t.items[idx] = &MACDItem{fast: NewMXEMA(t.hlFast, 1.), slow: NewMXEMA(t.hlSlow, 1.)}
	}
}

func (t *MXMACD) TermUpdateTOB(sid int, secs float64, it OVIterm, tob *MsgTOB) {
	item := it.(*MACDItem)
	price := tob.LastOrRobust()
	if math.IsNaN(price) {
		return
	}
	item.slow.Update(secs, price)
	item.fast.Update(secs, price)
}

// snap
func (t *MXMACD) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*MACDItem)
	slowEMA := item.slow.GetEma()
	if slowEMA == 0 {
		return
	}
	mavg := item.fast.GetEma() / slowEMA
	res[0] = mavg
}

var _ OVInterface = (*MXMACD)(nil)

func init() {
	TermFactoryInstance().Register("MX-MACD", func() ITerm { return &MXMACD{} })
}
