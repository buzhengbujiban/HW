// A New Set of Equity Specific Features
// yzhu, 20190827

package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"incremental/function"
	"incremental/function/median"
	"incremental/input"
	"math"
	"panel"
	"path"
	"sort"
	"strconv"
	"time"

	"TES/QR/alpha_ov/data"
	MU "TES/QR/alpha_ov/mathUtils"
	"TES/tesUtilsGo/common"

	"barra"
)

////////// HELPERS
var SH_LOC, _ = time.LoadLocation("Asia/Shanghai")

func SecsSinceMidFromEpoch(epoch float64) float64 {
	secInt := int64(epoch)
	nsec := epoch - float64(secInt)
	date := time.Unix(secInt, 0)
	date = date.In(SH_LOC)

	return float64(date.Hour()*3600+date.Minute()*60+date.Second()) + nsec
}

func MidEpochFromDate(dateStr string) float64 {
	dateStr += " 00:00:00"
	date, err := time.ParseInLocation("20060102 15:04:05", dateStr, SH_LOC)
	if err != nil {
		panic(err)
	}

	return float64(date.Unix()) + float64(date.Nanosecond())/1e9
}

func Create2DMatrixFloat64(n int, m int) [][]float64 {
	res := make([][]float64, n)
	for i := 0; i < n; i++ {
		res[i] = make([]float64, m)
	}
	return res
}

func Bound(x float64, l float64, u float64) float64 {
	if math.IsNaN(x) || math.IsInf(x, 0) {
		x = 0
	}
	if x < l {
		x = l
	}
	if x > u {
		x = u
	}
	return x
}

func NaInf2Zero(x float64) float64 {
	if math.IsNaN(x) || math.IsInf(x, 0) {
		x = 0
	}
	return x
}

//////// END of HELPERS

type SidIdxMap struct {
	nSids   int
	sid2idx map[int]int
	sids    []int
}

func (si *SidIdxMap) Init(sidUniverseList []int) {
	si.nSids = len(sidUniverseList)
	si.sid2idx = make(map[int]int, si.nSids)
	si.sids = make([]int, si.nSids)
	for idx, sid := range sidUniverseList {
		si.sid2idx[sid] = idx
		si.sids[idx] = sid
	}
}

const nOAFeatures = 8

type EquityOpenAuction struct {
	FeatureBase
	SidIdxMap

	baseFeat        [][]float64
	auctionPrice    []float64
	auctionVol      []float64
	firstContiTrade []bool

	high, low, open []float64

	midNightEpoch float64

	prev_minute_turnover *data.MinuteTable

	gm *MU.WeightedNestedGroupMeanFast

	//return
	ret []float64
}

func (oa *EquityOpenAuction) loadFeaturePrefs() error {
	return nil
}

//setFeatureNames: set column names.
func (oa *EquityOpenAuction) setFeatureNames() {

	oa.colNames = make([]string, nOAFeatures*5+1)
	for i := 0; i < nOAFeatures; i++ {
		oa.colNames[i+nOAFeatures*0] = fmt.Sprintf("ZOA-r%d-m", i)
		oa.colNames[i+nOAFeatures*1] = fmt.Sprintf("ZOA-r%d-im", i)
		oa.colNames[i+nOAFeatures*2] = fmt.Sprintf("ZOA-r%d-cm", i)
		oa.colNames[i+nOAFeatures*3] = fmt.Sprintf("ZOA-r%d-ir", i)
		oa.colNames[i+nOAFeatures*4] = fmt.Sprintf("ZOA-r%d-cr", i)
	}
	oa.colNames[nOAFeatures*5] = "ZOA-tod"

	// allocate ret memory
	oa.ret = make([]float64, len(oa.colNames))
}

//initialize internal variables'
func (oa *EquityOpenAuction) initInternalVars() {
	oa.FeatureBase.initInternalVars()
	oa.SidIdxMap.Init(oa.sidUniverseList)

	oa.baseFeat = Create2DMatrixFloat64(oa.nSids, nOAFeatures)
	oa.auctionPrice = make([]float64, oa.nSids)
	oa.auctionVol = make([]float64, oa.nSids)
	oa.firstContiTrade = make([]bool, oa.nSids)

	oa.high = make([]float64, oa.nSids)
	oa.low = make([]float64, oa.nSids)
	oa.open = make([]float64, oa.nSids)

	oa.midNightEpoch = MidEpochFromDate(oa.dateStr)

	prevdate := common.EquityPrevBusdateRemoveMissingDates(oa.dateStr)
	oa.prev_minute_turnover = data.GetMinuteTableFromPanelData("minute-rollstats", prevdate, "turnover.rw22")

	oa.gm = MU.NewWeightedNestedGroupMeanFast(oa.sidUniverseList, 8, oa.baseSidWgts, oa.industryCode, oa.conceptCodes)
}

//Update
func (oa *EquityOpenAuction) UpdateSecValueSlice(sid int, secSinceEpoch float64, valueSlice []float64) bool {
	if _, ok := oa.sidUniverse[sid]; !ok {
		return false
	}

	secSinceMid := secSinceEpoch - oa.midNightEpoch

	idx := oa.sid2idx[sid]

	cumVol := valueSlice[0]
	cumNotl := valueSlice[1]
	prevClose := valueSlice[2]
	lastPrc := valueSlice[3]

	asize1 := valueSlice[4]
	bsize1 := valueSlice[5]

	aucPrc := valueSlice[6]

	// between [9:20, 9:25] && valid auc price
	// record HLOC
	if secSinceMid >= (9*3600+20*60) && secSinceMid <= (9*3600+25*60) && aucPrc > 0 {
		if oa.high[idx] == 0 || oa.high[idx] < aucPrc {
			oa.high[idx] = aucPrc
		}
		if oa.low[idx] == 0 || oa.low[idx] > aucPrc {
			oa.low[idx] = aucPrc
		}
		if oa.open[idx] == 0 {
			oa.open[idx] = aucPrc
		}
	}

	// after 9:25, after auction, first trade
	if cumVol > 0 && oa.auctionPrice[idx] == 0 {
		oa.auctionVol[idx] = cumVol
		oa.auctionPrice[idx] = cumNotl / cumVol
		oa.baseFeat[idx][0] = oa.auctionPrice[idx]/prevClose - 1.0
		oa.baseFeat[idx][2] = Bound((asize1-bsize1)/(asize1+bsize1), -1, 1)
	}

	// the first trade after 9:25-9:30
	if cumVol > oa.auctionVol[idx] && !oa.firstContiTrade[idx] {
		oa.firstContiTrade[idx] = true
		oa.baseFeat[idx][1] = lastPrc/oa.auctionPrice[idx] - 1
		oa.baseFeat[idx][3] = Bound((asize1-bsize1)/(asize1+bsize1), -1, 1)

		h, l, o, c := oa.high[idx], oa.low[idx], oa.open[idx], oa.auctionPrice[idx]

		// Progress features
		// (h-l) / (h+l)
		// close/( (high+low)/2 ) - 1
		// close / open - 1
		// vol / past average
		oa.baseFeat[idx][4] = Bound((h-l)/(h+l), 0, 0.02)
		oa.baseFeat[idx][5] = Bound(c/((h+l)*0.5)-1, -0.03, 0.03)
		oa.baseFeat[idx][6] = Bound(c/o-1, -0.03, 0.03)
		oa.baseFeat[idx][7] = Bound(cumNotl/oa.prev_minute_turnover.Get(sid, 0), 0.1, 10)

		oa.gm.Update(sid, oa.baseFeat[idx])
	}

	return true
}

func (oa *EquityOpenAuction) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return oa.GetSidValues(oa.baseSid, mPrice, secEpoch)
}

func (oa *EquityOpenAuction) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	oa.gm.GetValue(sid, oa.ret)
	oa.ret[nOAFeatures*5] = (secEpoch - oa.midNightEpoch) / 3600

	return oa.ret, nil
}

type EquityStyle struct {
	FeatureBase
	SidIdxMap

	//return
	ret [][]float64 // sid -> 20 style factors
}

func (feat *EquityStyle) loadFeaturePrefs() error {
	return nil
}

func (feat *EquityStyle) setFeatureNames() {
	// Done in initInternalVars()
}

func (feat *EquityStyle) initInternalVars() {
	feat.FeatureBase.initInternalVars()
	feat.SidIdxMap.Init(feat.sidUniverseList)

	feat.colNames = []string{"ANLYSTSN", "BETA", "BTOP", "DIVYILD", "EARNQLTY", "EARNVAR",
		"EARNYILD", "GROWTH", "INDMOM", "INVSQLTY", "LEVERAGE", "LIQUIDTY",
		"LTREVRSL", "MIDCAP", "MOMENTUM", "PROFIT", "RESVOL", "SEASON", "STREVRSL", "SIZE"}

	for i := 0; i < len(feat.colNames); i++ {
		feat.colNames[i] = "ZBS-" + feat.colNames[i]
	}

	// allocate ret memory
	feat.ret = make([][]float64, feat.nSids)
	for i := 0; i < feat.nSids; i++ {
		feat.ret[i] = make([]float64, len(feat.colNames))
	}

	// load Barra model
	barra.SetPanelRoot(data.PanelRoot)
	barra.SetPreBusDateFun(common.PreTradeDateEquityFix)
	pdate := common.PreTradeDateEquityFix(feat.dateStr)
	risk := barra.GetRiskModel(pdate, feat.sidUniverseList, false)
	expMat := risk.Exp
	for i := 0; i < feat.nSids; i++ {
		for j := 0; j < len(feat.colNames); j++ {
			expMat.Get(i, j)
			feat.ret[i][j] = expMat.Get(i, j)
			if math.IsNaN(feat.ret[i][j]) {
				feat.ret[i][j] = 0
			}
		}
	}
}

// EquityStyle feature does not need any Update method

func (feat *EquityStyle) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return feat.GetSidValues(feat.baseSid, mPrice, secEpoch)
}

func (feat *EquityStyle) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	idx := feat.sid2idx[sid]
	return feat.ret[idx], nil
}

const nBasicStatsFeatures = 12

type EquityBasicStats struct {
	FeatureBase
	SidIdxMap

	// global stat (all the same)
	secMorning float64

	// state vars
	curMMIdx      map[int]int
	toRatioIdx    map[int]int
	toRatio       map[int]float64
	toRatioMedian function.Function

	toRatioMedianCount int64

	openPrc   map[int]float64
	topSize   map[int]float64
	prevClose map[int]float64

	// stats
	stats *EquityStats

	// more per-sid var
	univIds    []int
	sid2bucket map[int]int
	limitRet   []float64

	//return
	ret []float64
}

func (feat *EquityBasicStats) loadFeaturePrefs() error {
	return nil
}

func (feat *EquityBasicStats) setFeatureNames() {
	// small cap for these NoName features
	feat.colNames = []string{"prev-vol", "avg-size", "to-ratio-group", "to-ratio", "tp-ratio", "tod-", "limitd-", "limitd2-", "univ-", "sidbucket-", "isST-", "is20pct-"}

	if len(feat.colNames) != nBasicStatsFeatures {
		panic(fmt.Sprintf("EquityBasicStats num of features does not match"))
	}

	// allocate ret memory
	feat.ret = make([]float64, len(feat.colNames))
}

func (feat *EquityBasicStats) initInternalVars() {
	feat.FeatureBase.initInternalVars()
	feat.SidIdxMap.Init(feat.sidUniverseList)

	// state vars
	feat.toRatioMedian = median.NewMedianFunc(nil)
	feat.toRatioMedianCount = 0

	feat.curMMIdx = make(map[int]int)
	feat.toRatioIdx = make(map[int]int)
	feat.toRatio = make(map[int]float64)
	for _, sid := range feat.sidUniverseList {
		feat.toRatio[sid] = 1
	}

	feat.openPrc = make(map[int]float64)
	feat.topSize = make(map[int]float64)
	feat.prevClose = make(map[int]float64)

	{
		//NOTE: now same with ELELL's
		//      first half hour: -7.5 to -7.0 (hours)
		date2MinuteStr := fmt.Sprintf("%s0900", feat.dateStr)
		t, _ := time.ParseInLocation("200601021504", date2MinuteStr, time.UTC)
		feat.secMorning = float64(t.Unix())
	}
	// load stats
	// this feature does not use weight in stats; so dummy "onetwo" is ok
	feat.stats = NewEquityStats(feat.dateStr, feat.sidUniverseList, "onetwo")

	prevDate := common.PreTradeDateEquityFix(feat.dateStr)
	feat.univIds = LabelChinaEquityUniv(data.PanelRoot, prevDate, feat.sidUniverseList, false)

	// process sidbucket-
	{
		sortedSids := make([]int, len(feat.sidUniverseList))
		copy(sortedSids, feat.sidUniverseList)
		sort.Ints(sortedSids)
		feat.sid2bucket = make(map[int]int)
		for i, sid := range sortedSids {
			feat.sid2bucket[sid] = i * 10 / len(feat.sidUniverseList)
		}
	}

	{
		feat.limitRet = make([]float64, len(feat.sidUniverseList))
		for i, sid := range feat.sidUniverseList {
			limitType := common.GetSidPriceLimitThresholdType(sid, feat.dateStr)
			switch limitType {
			case 5:
				feat.limitRet[i] = 0.05
			case 10:
				feat.limitRet[i] = 0.10
			case 20:
				feat.limitRet[i] = 0.20
			default:
				panic(fmt.Sprintf("Unknown limitType from common.GetSidPriceLimitThresholdType(%d, %s) = %d", sid, feat.dateStr, limitType))
			}
		}
	}
}

const (
	UnivNonx = 0 + iota
	UnivSh50
	UnivSh250
	UnivHs300
	UnivZz500
	UnivNon800
	UnivMidx
	UnivBotx
)

func InitSh50Sids(panelFolder, dateStr string) map[int]bool {
	indexSids := map[int]bool{}
	indexData, err := panel.Panel.ReadSdiv(path.Join(panelFolder+"/index", fmt.Sprintf("index-%s.sdiv", dateStr)), "S", "D", "I", "V")
	if err != nil {
		panic(err)
	}

	for _, sidStr := range indexData.Coords()["S"] {
		if indexData.Loc(sidStr, dateStr, "00:00:00", "sh50") > 0 {
			sid, _ := strconv.Atoi(sidStr)
			indexSids[sid] = true
		}
	}

	return indexSids
}

func InitHs300Sids(panelFolder, dateStr string) map[int]bool {
	indexSids := map[int]bool{}
	indexData, err := panel.Panel.ReadSdiv(path.Join(panelFolder+"/index", fmt.Sprintf("index-%s.sdiv", dateStr)), "S", "D", "I", "V")
	if err != nil {
		panic(err)
	}

	for _, sidStr := range indexData.Coords()["S"] {
		if indexData.Loc(sidStr, dateStr, "00:00:00", "csi300") > 0 {
			sid, _ := strconv.Atoi(sidStr)
			indexSids[sid] = true
		}
	}

	return indexSids
}

func InitZz500Sids(panelFolder, dateStr string) map[int]bool {
	indexSids := map[int]bool{}
	indexData, err := panel.Panel.ReadSdiv(path.Join(panelFolder+"/index", fmt.Sprintf("index-%s.sdiv", dateStr)), "S", "D", "I", "V")
	if err != nil {
		panic(err)
	}

	for _, sidStr := range indexData.Coords()["S"] {
		if indexData.Loc(sidStr, dateStr, "00:00:00", "csi500") > 0 {
			sid, _ := strconv.Atoi(sidStr)
			indexSids[sid] = true
		}
	}

	return indexSids
}

func InitUnivSids(panelFolder, dateStr string) (topx, midx, botx map[int]bool) {
	topx = map[int]bool{}
	midx = map[int]bool{}
	botx = map[int]bool{}

	indexData, err := panel.Panel.ReadSdiv(path.Join(panelFolder+"/univ", fmt.Sprintf("univ-%s.sdiv", dateStr)), "S", "D", "I", "V")
	if err != nil {
		panic(err)
	}

	for _, sidStr := range indexData.Coords()["S"] {
		if indexData.Loc(sidStr, dateStr, "00:00:00", "topx") > 0 {
			sid, _ := strconv.Atoi(sidStr)
			topx[sid] = true
		}

		if indexData.Loc(sidStr, dateStr, "00:00:00", "midx") > 0 {
			sid, _ := strconv.Atoi(sidStr)
			midx[sid] = true
		}

		if indexData.Loc(sidStr, dateStr, "00:00:00", "botx") > 0 {
			sid, _ := strconv.Atoi(sidStr)
			botx[sid] = true
		}
	}

	return
}

func LabelChinaEquityUniv(panelFolder, dateStr string, sids []int, locf bool) []int {

	targetDateStr := dateStr
	if locf {
		indexPath := panelFolder + "/index" + "/index-" + targetDateStr + ".sdiv"
		for !tu.PathExisted(indexPath) && targetDateStr >= "20150917" {
			targetDateStr = common.PreTradeDateEquityFix(targetDateStr)
			indexPath = panelFolder + "/index" + "/index-" + targetDateStr + ".sdiv"
		}
	}

	sh50 := InitSh50Sids(panelFolder, targetDateStr)
	hs300 := InitHs300Sids(panelFolder, targetDateStr)
	zz500 := InitZz500Sids(panelFolder, targetDateStr)
	topx, midx, botx := InitUnivSids(panelFolder, targetDateStr)

	univs := make([]int, len(sids), len(sids))
	for i, sid := range sids {
		switch {
		case sh50[sid]:
			univs[i] = UnivSh50
		case hs300[sid]:
			univs[i] = UnivSh250
		case zz500[sid]:
			univs[i] = UnivZz500
		case topx[sid]:
			univs[i] = UnivNon800
		case midx[sid]:
			univs[i] = UnivMidx
		case botx[sid]:
			univs[i] = UnivBotx
		default:
			univs[i] = UnivNonx
		}
	}
	return univs
}

func (feat *EquityBasicStats) UpdateValueSlice(sid int, valueSlice []float64) bool {
	exTimeInt, cumTo, openPrice, topSize, prevClose := valueSlice[0], valueSlice[1], valueSlice[2], valueSlice[3], valueSlice[4]
	/*
		// openPrice could also be last exec price in case openPrice is not available
		if openPrice < 0 {
			openPrice = 0
		}
		feat.openPrc[sid] = openPrice
	*/

	if openPrice > 0 && feat.openPrc[sid] == 0 {
		feat.openPrc[sid] = openPrice
	}

	feat.topSize[sid] = topSize
	feat.prevClose[sid] = prevClose

	//# update turnover ratio
	feat.curMMIdx[sid] = timeint_to_minute(int64(exTimeInt))
	if feat.curMMIdx[sid] > feat.toRatioIdx[sid] {
		if feat.stats.prevMinuteTurnover.HasSid(sid) {
			pto := feat.stats.prevMinuteTurnover.Get(sid, feat.curMMIdx[sid]-1)

			if math.IsNaN(pto) || math.IsInf(pto, 0) {
				feat.toRatio[sid] = 1
			} else {
				feat.toRatio[sid] = cumTo / pto
			}

			feat.toRatioMedian.Update(&input.Data{0, sid, feat.toRatio[sid]})
			feat.toRatioMedianCount++
		}
		feat.toRatioIdx[sid] = feat.curMMIdx[sid]
	}

	return true
}

func (feat *EquityBasicStats) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return feat.GetSidValues(feat.baseSid, mPrice, secEpoch)
}

func (feat *EquityBasicStats) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	openPrice, topSize, prevClose := feat.openPrc[sid], feat.topSize[sid], feat.prevClose[sid]
	idx := feat.sid2idx[sid]

	prevVola := feat.stats.prevDayVolatility[sid]
	if math.IsNaN(prevVola) {
		prevVola = 0
	}
	avgSize := openPrice * feat.stats.prevDayAvgSize[sid]

	toRatioMedian := feat.toRatioMedian.CalcValue().(float64)
	if feat.toRatioMedianCount < 10000 {
		// when # of snapshots < 10000 (10000/1250*3 = 24seconds), set group median to a prior value 1.0
		// a better method is to pre-load this prior value from stat of previous days
		toRatioMedian = 1.0
	}
	toRatio := feat.toRatio[sid]

	avgMinuteSize := feat.stats.prevMinuteAvgSize.Get(sid, feat.curMMIdx[sid])

	var tpRatio float64
	if !math.IsNaN(avgMinuteSize) && avgMinuteSize > 0 {
		tpRatio = math.Max(10.0, topSize/avgMinuteSize)
	} else {
		tpRatio = 1.0
	}

	feat.ret[0] = prevVola
	feat.ret[1] = avgSize
	feat.ret[2] = toRatioMedian
	feat.ret[3] = toRatio - toRatioMedian
	feat.ret[4] = tpRatio
	feat.ret[5] = (secEpoch - feat.secMorning) / 3600
	// 6 & 7 - limitd & limitd2
	if prevVola == 0 || mPrice == 0 {
		feat.ret[6] = 0
		feat.ret[7] = 0
	} else {
		ret := (mPrice - prevClose) / prevClose
		sd := math.Sqrt(prevVola)
		feat.ret[6] = Bound(ret/sd, -1, 1)
		feat.ret[7] = sign(ret) * (feat.limitRet[idx] - math.Abs(ret)) / sd
	}
	// 8 - univ id
	feat.ret[8] = float64(feat.univIds[idx])
	// 9 - sid bucket in [0, 9]
	feat.ret[9] = float64(feat.sid2bucket[sid])
	// 10 - isST
	if feat.limitRet[idx] == 0.05 {
		feat.ret[10] = 1
	} else {
		feat.ret[10] = 0
	}
	// 11 - is20pct
	if feat.limitRet[idx] == 0.20 {
		feat.ret[11] = 1
	} else {
		feat.ret[11] = 0
	}

	return feat.ret, nil
}

type TVPair struct {
	epoch float64
	val   float64
}

type ROC struct {
	FeatureBase
	SidIdxMap

	hlList     []int
	includePrc bool
	mode       int

	queues [][]TVPair // sidIdx -> price queues
	pos    [][]int    //sidIdx -> nHorizon positions in queue

	//return
	ret []float64
}

func (feat *ROC) loadFeaturePrefs() error {
	feat.hlList = feat.prefs.GetIntListPref(feat.featureName + "_hl_list")
	feat.includePrc = feat.prefs.GetBoolPref(feat.featureName + "_include_prc")
	feat.mode = feat.prefs.GetIntPref(feat.featureName + "_mode")
	if feat.mode < 1 || feat.mode > 2 {
		panic(fmt.Sprintf("ROC mode must be 1 or 2; 1 -- return; 2 -- diff"))
	}
	return nil
}

func (feat *ROC) setFeatureNames() {
	for _, hl := range feat.hlList {
		feat.colNames = append(feat.colNames, feat.featureName+fmt.Sprintf("-%ds", hl))
	}
	if feat.includePrc {
		feat.colNames = append(feat.colNames, feat.featureName+"-val")
	}

	// allocate ret memory
	feat.ret = make([]float64, len(feat.colNames))
}

func (feat *ROC) initInternalVars() {
	feat.FeatureBase.initInternalVars()
	feat.SidIdxMap.Init(feat.sidUniverseList)

	feat.queues = make([][]TVPair, feat.nSids)
	feat.pos = make([][]int, feat.nSids)
	for i := 0; i < feat.nSids; i++ {
		feat.pos[i] = make([]int, len(feat.hlList))
	}
}

func (feat *ROC) UpdateSecValue(sid int, secSinceEpoch float64, value float64) bool {
	if idx, ok := feat.sid2idx[sid]; ok {
		feat.queues[idx] = append(feat.queues[idx], TVPair{secSinceEpoch, value})
		minPos := 0
		for i, hl := range feat.hlList {
			j := feat.pos[idx][i]
			for j < len(feat.queues[idx]) && feat.queues[idx][j].epoch < secSinceEpoch-float64(hl) {
				j++
			}
			feat.pos[idx][i] = j
			if minPos > j {
				minPos = j
			}
		}
		if minPos > 0 {
			feat.queues[idx] = feat.queues[idx][minPos:]
		}
	}

	return true
}

func (feat *ROC) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {
	if idx, ok := feat.sid2idx[sid]; ok {
		q := feat.queues[idx]
		n := len(q)
		if n > 0 {
			lastValue := q[n-1].val
			if feat.mode == 1 {
				for i := range feat.hlList {
					feat.ret[i] = lastValue/q[feat.pos[idx][i]].val - 1.0
				}
			} else if feat.mode == 2 {
				for i := range feat.hlList {
					feat.ret[i] = lastValue - q[feat.pos[idx][i]].val
				}
			}
			if feat.includePrc {
				feat.ret[len(feat.hlList)] = lastValue
			}

			return feat.ret, nil
		}
	}

	for i := range feat.ret {
		feat.ret[i] = 0
	}
	return feat.ret, nil
}

/*
// New Feature Template
const nStyleFeatures = 8

type EquityStyle struct {
	FeatureBase
	SidIdxMap


	//return
	ret []float64
}

func (feat *EquityStyle) loadFeaturePrefs() error {
	return nil
}

func (feat *EquityStyle) setFeatureNames() {

	feat.colNames = make([]string, 100)

	// allocate ret memory
	feat.ret = make([]float64, len(feat.colNames))
}

func (feat *EquityStyle) initInternalVars() {
	feat.FeatureBase.initInternalVars()
	feat.SidIdxMap.Init(feat.sidUniverseList)

}

func (feat *EquityStyle) UpdateSecValueSlice(sid int, secSinceEpoch float64, valueSlice []float64) bool {


	return true
}

func (feat *EquityStyle) GetValues(mPrice, secEpoch float64) ([]float64, error) {
	return feat.GetSidValues(feat.baseSid, mPrice, secEpoch)
}

func (feat *EquityStyle) GetSidValues(sid int, mPrice, secEpoch float64) ([]float64, error) {

	//
	return feat.ret, nil
}
*/
