/**
 * Author: Yingfa
 * Date: 18-5-14
 * yzhu: support ChinaEquity 2018-12-13
 */
package feature

import (
	"fmt"
	"math"
	"path"
	"sort"

	"TES/QR/alpha_ov/data"
	tu "TES/tesUtilsGo"
	"TES/tesUtilsGo/common"
)

type SidSymbolPair struct {
	sid    int
	symbol string //native exchange id
}
type FeatureInterface interface {
	init(string, string, string, string) error //prefs_name, feature_name, log_dir, datestr
	initInternalVars()
	loadDailyStats()
	loadGeneralPrefs() error
	loadFeaturePrefs() error
	setupLogging()
	setFeatureNames()

	Finalize()
	GetRevisionList() []ForwardUpdate

	GetFeatureNames() []string
	SetSidUniverse(baseSid int, basisList []int)
	GetValues(price float64, secSinceEpoch float64) ([]float64, error)             //for PerSid mode
	GetSidValues(sid int, price float64, secSinceEpoch float64) ([]float64, error) //for Group mode

	WriteCheckPoint()

	// for ChinaEquity
	SetIndustryAndConcept(industryCode map[int]int, conceptCodes map[int][]int)
	SetWeight(baseSidWgts map[int]float64)

	// updates
	UpdateValue(sid int, value float64) bool
	UpdateValueSlice(sid int, valueSlice []float64) bool
	UpdateSecValue(sid int, secSinceEpoch float64, value float64) bool
	UpdateSecValueSlice(sid int, secSinceEpoch float64, valueSlice []float64) bool
	UpdateSecPrcQtySlice(sid int, secSinceEpoch float64, prcQtySlice []data.PriceQty) bool
	UpdateSecPrcQtySliceAndValue(sid int, secSinceEpoch float64, prcQtySlice []data.PriceQty, value float64) bool

	UpdateSecPrcQtySliceSnap(sid int, secSinceEpoch float64, prcQtySlice []data.PriceQty, snapData []float64) bool
	UpdateDoubleSecPrcQtySliceSnap(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, snapData []float64) bool
	UpdateDoubleSecPrcQtySliceSnapGroup(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, snapData []float64, groupData map[int]int) bool
	UpdateQuadrupleSecPrcQtySliceSnapGroup(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, prcQtySlice3 []data.PriceQty, prcQtySlice4 []data.PriceQty, snapData []float64, groupData map[int]int) bool
	UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, snapData1 []float64, snapData2 []float64, groupData map[int]int) bool
	UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, snapData1 []float64, snapData2 []float64, groupData map[int]int, extraInfo map[int][]float64) bool
	UpdateSecPrcQtySliceDoubleSnap(sid int, secSinceEpoch float64, prcQtySlice []data.PriceQty, snapData1 []float64, snapData2 []float64) bool
	UpdateDoubleSecPrcQtySliceSnapCheck(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, snapData []float64, epochOri float64) bool
	UpdateDoubleSecPrcQtyTagSliceSnapCheck(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQtyTag, prcQtySlice2 []data.PriceQtyTag, snapData []float64, epochOri float64) bool
	UpdateSecPrcQtyOidTagSliceSnapCheck(sid int, secSinceEpoch float64, prcQtyOidTag []data.PriceQtyOidTag, snapData []float64, epochOri float64) bool

	TermUpdate(sid int, epoch float64, inputType int, n int, data []float64)
}

type FeatureBase struct {
	PrefsName   string
	prefs       *tu.PreferenceAdapter
	featureName string
	colNames    []string //feature column names
	logger      *tu.TLogger
	logDir      string
	logLevel    byte //I/D/W/E/F
	dateStr     string
	checkValues bool
	//secMorning float64
	//secDateEnd float64
	sidUniverse     map[int]bool    //sid->true
	sidUniverseList []int           //sorted list of the sids in sidUniverse map
	basisNames      []SidSymbolPair //native exchange id of the symbol
	basisList       []int           //sid list
	baseSid         int             //fmid most likely?
	useGlobalLogger bool            // NOTE: in production prefs, should use global logger. use_global_logger=1
	selfP           FeatureInterface

	// Weight fields for ChinaEquity
	industryCode map[int]int
	conceptCodes map[int][]int
	baseSidWgts  map[int]float64
}

// for ChinaEquity
func (fb *FeatureBase) SetIndustryAndConcept(industryCode map[int]int, conceptCodes map[int][]int) {
	fb.industryCode = industryCode
	fb.conceptCodes = conceptCodes
}

func (fb *FeatureBase) SetWeight(baseSidWgts map[int]float64) {
	fb.baseSidWgts = baseSidWgts
}

//Not implemented panics
func (fb *FeatureBase) UpdateValue(sid int, value float64) bool {
	panic(fmt.Sprintf("UpdateValue not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateValueSlice(sid int, valueSlice []float64) bool {
	panic(fmt.Sprintf("UpdateValueSlice not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateSecValue(sid int, secSinceEpoch float64, value float64) bool {
	panic(fmt.Sprintf("UpdateSecValue not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateSecValueSlice(sid int, secSinceEpoch float64, valueSlice []float64) bool {
	panic(fmt.Sprintf("UpdateSecValueSlice not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateSecPrcQtySlice(sid int, secSinceEpoch float64, prcQtySlice []data.PriceQty) bool {
	panic(fmt.Sprintf("UpdateSecPrcQtySlice not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateSecPrcQtySliceAndValue(sid int, secSinceEpoch float64, prcQtySlice []data.PriceQty, value float64) bool {
	panic(fmt.Sprintf("UpdateSecPrcQtySliceAndValue not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateSecPrcQtySliceSnap(sid int, secSinceEpoch float64, prcQtySlice []data.PriceQty, snapData []float64) bool {
	panic(fmt.Sprintf("UpdateSecPrcQtySliceSnap not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateDoubleSecPrcQtySliceSnap(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, snapData []float64) bool {
	panic(fmt.Sprintf("UpdateDoubleSecPrcQtySliceSnap not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateDoubleSecPrcQtySliceSnapGroup(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, snapData []float64, groupData map[int]int) bool {
	panic(fmt.Sprintf("UpdateDoubleSecPrcQtySliceSnapGroup not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateQuadrupleSecPrcQtySliceSnapGroup(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, prcQtySlice3 []data.PriceQty, prcQtySlice4 []data.PriceQty, snapData []float64, groupData map[int]int) bool {
	panic(fmt.Sprintf("UpdateQuadrupleSecPrcQtySliceSnapGroup not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, snapData1 []float64, snapData2 []float64, groupData map[int]int) bool {
	panic(fmt.Sprintf("UpdateDoubleSecPrcQtySliceDoubleSnapGroup not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, snapData1 []float64, snapData2 []float64, groupData map[int]int, extraInfo map[int][]float64) bool {
	panic(fmt.Sprintf("UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateSecPrcQtySliceDoubleSnap(sid int, secSinceEpoch float64, prcQtySlice []data.PriceQty, snapData1 []float64, snapData2 []float64) bool {
	panic(fmt.Sprintf("UpdateSecPrcQtySliceDoubleSnap not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateDoubleSecPrcQtySliceSnapCheck(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQty, prcQtySlice2 []data.PriceQty, snapData []float64, epochOri float64) bool {
	panic(fmt.Sprintf("UpdateDoubleSecPrcQtySliceSnapCheck not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateDoubleSecPrcQtyTagSliceSnapCheck(sid int, secSinceEpoch float64, prcQtySlice1 []data.PriceQtyTag, prcQtySlice2 []data.PriceQtyTag, snapData []float64, epochOri float64) bool {
	panic(fmt.Sprintf("UpdateDoubleSecPrcQtyTagSliceSnapCheck not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) UpdateSecPrcQtyOidTagSliceSnapCheck(sid int, secSinceEpoch float64, prcQtyOidTagSlice []data.PriceQtyOidTag, snapData []float64, epochOri float64) bool {
	panic(fmt.Sprintf("UpdateSecPrcQtyOidTagSliceSnapCheck not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) TermUpdate(sid int, epoch float64, inputType int, n int, data []float64) {
	panic(fmt.Sprintf("TermUpdate not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) GetValues(price, secSinceEpoch float64) ([]float64, error) {
	panic(fmt.Sprintf("GetValues not implemented for %s", fb.featureName))
}
func (fb *FeatureBase) GetSidValues(sid int, price, secSinceEpoch float64) ([]float64, error) {
	panic(fmt.Sprintf("GetSidValues not implemented for %s", fb.featureName))
}

func (fb *FeatureBase) Finalize() {
	//EMPTY Finalize by default
}

func (fb *FeatureBase) WriteCheckPoint() {
	//EMPTY WriteCheckPoint by default
	fmt.Println("Default WriteCheckPoint called")
}

func (fb *FeatureBase) GetRevisionList() []ForwardUpdate {
	//nil revision by default
	//revision is usually used by a forward stat
	return nil
}

// this could be over
func (fb *FeatureBase) init(prefsName, featureName, logDir, dateStr string) error {
	fb.dateStr = dateStr
	fb.featureName = featureName
	fb.logDir = logDir
	fb.PrefsName = prefsName
	fb.loadGeneralPrefs()
	fb.setupLogging()
	return nil
}

//setSelfPointer. this should be called after init. Set the derived class self back to selfP so that can call derived methods in SetSidUniverse()
func (fb *FeatureBase) setSelfPointer(fip FeatureInterface) {
	fb.selfP = fip
}

func (fb *FeatureBase) loadGeneralPrefs() error {
	fb.prefs = tu.NewPreferenceAdapter(fb.PrefsName)
	fb.useGlobalLogger = true

	/* disable this 2018-12-07
	// copy prefs file to output directory
	localFn := path.Join(fb.logDir, fmt.Sprintf("%s_feature.prefs", fb.featureName))
	tu.CopyFile(fb.PrefsName, localFn, false)

	//use global logger or not?
	fb.useGlobalLogger = false
	if fb.prefs.HasPref("use_global_logger") && fb.prefs.GetIntPref("use_global_logger") == 1 {
		fb.useGlobalLogger = true
	} else {
		//log file and log level
		if fb.prefs.HasPref("log_level") {
			fb.logLevel = fb.prefs.GetStringPref("log_level")[0]
		} else {
			fb.logLevel = 'I'
		}
	}
	*/

	return nil
}

func (fb *FeatureBase) setupLogging() {
	if fb.useGlobalLogger {
		fb.logger = tu.Logger
	} else {
		logPath := path.Join(fb.logDir, fmt.Sprintf("%s_feature.log", fb.featureName))
		fb.logger, _ = tu.NewLogger(fb.logLevel, logPath)
	}
}

//loadFeaturePrefs this should be called after init() and should have it's own implementation in every derived class.
func (fb *FeatureBase) loadFeaturePrefs() error {
	return nil
}

func (fb *FeatureBase) GetFeatureNames() []string {
	return fb.colNames
}

func (fb *FeatureBase) loadDailyStats() {}

//func (fb *FeatureBase) Update(int, ...interface{}) error{}

func (fb *FeatureBase) setFeatureNames() {}

func (fb *FeatureBase) initInternalVars() {
	//fb.secMorning = common.GetBeginTimestampOfDay(fb.dateStr)//what about night? Have to see where use this in future coding.
	//fb.secDateEnd = common.GetEndTimestampOfDay(fb.dateStr)
}

func (fb *FeatureBase) SetSidUniverse(baseSid int, basisList []int) {
	fb.sidUniverse = make(map[int]bool)
	fb.baseSid = baseSid
	fb.sidUniverse[baseSid] = true
	fb.sidUniverseList = append(fb.sidUniverseList, baseSid)

	if basisList != nil && len(basisList) > 0 {
		for _, sid := range basisList {
			fb.sidUniverse[sid] = true
			fb.sidUniverseList = append(fb.sidUniverseList, sid)
			if sid == data.SidCSI300 || sid == data.SidCSI500 {
				// Special logic for CSI300/CSI500 index sids
			} else {
				if _, ok := common.SecMasterMap[sid]; !ok {
					panic(fmt.Sprintf("There is no such sid %d in ref data.", sid))
				}
				item := SidSymbolPair{sid, common.SecMasterMap[sid].NativeExId}
				fb.basisNames = append(fb.basisNames, item)
			}
			fb.basisList = append(fb.basisList, sid)
		}
		//TODO: there's a bug in python code, it sorts fb.basisNames which are later used in feature names
		//TODO     however fb.basisList is not sorted (in prefs, it is usually manually sorted)
		//TODO     here we maintain the same behavior to let basisList unsorted
		sort.Slice(fb.basisNames, func(i, j int) bool {
			return fb.basisNames[i].sid < fb.basisNames[j].sid
		})
	}
	sort.Ints(fb.sidUniverseList)
	// call the derived class's implementation of below methods.
	fb.selfP.setFeatureNames()

	// wanted to moved to newEquitySampler.go; but FwdStats crashed
	fb.selfP.initInternalVars()
	fb.selfP.loadDailyStats()
}

//NewFeature: factory to create new feature struct instance and call init and loadFeaturePrefs.
func NewFeatureInst(prefsName, featureName, className, logDir, dateStr string) FeatureInterface {
	switch className {
	case "DetrendLastSeenBookV2":
		fi := &DetrendLastSeenBookV2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "DetrendSignedIDSBookV2":
		fi := &DetrendSignedIDSBookV2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "DetrendSignedEMABookV2":
		fi := &DetrendSignedEMABookV2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "DetrendUnsignedIDSBook":
		fi := &DetrendUnSignedIDSBook{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
		//book features
	case "ADXIndicator":
		fi := &ADXIndicator{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BidAskRatio":
		fi := &BidAskRatio{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BollingerBand":
		fi := &BollingerBand{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BollingerBandEMA":
		fi := &BollingerBandEMA{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BookPressureIDS":
		fi := &BookPressureIDS{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BookPressureIDSNDiff":
		fi := &BookPressureIDSNDiff{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "CommodityChannelIndex":
		fi := &CommodityChannelIndex{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "HorizonPriceExtrema":
		fi := &HorizonPriceExtrema{}
		fi.SubClass = HorizonPriceExtremaSingle
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "HorizonPriceExtrema2":
		fi := &HorizonPriceExtrema2{}
		fi.SubClass = HorizonPriceExtremaSingle
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "HorizonStatDelta":
		fi := &HorizonStatDelta{}
		fi.SubClass = HorizonStatDeltaChinaFutures
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "HorizonStatsRangeDelta":
		fi := &HorizonStatsRangeDelta{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "HorizonStatsRangeDelta2":
		fi := &HorizonStatsRangeDelta2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "LaggingBasisReturn":
		fi := &LaggingBasisReturn{}
		fi.SubClass = LaggingBasisReturnSingle
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "LastSeenBookV2":
		fi := &LastSeenBookV2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "RelativeStrengthIndex":
		fi := &RelativeStrengthIndex{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "SignedEMABookV2":
		fi := &SignedEMABookV2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "SignedEMABook":
		fi := &SignedEMABook{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "SignedIDSBookV2":
		fi := &SignedIDSBookV2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "StochasticOscillator":
		fi := &StochasticOscillator{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "TradeOpenInterestEMA":
		fi := &TradeOpenInterestEMA{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "TrueStrengthIndex":
		fi := &TrueStrengthIndex{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "UnsignedIDSBook":
		fi := &UnsignedIDSBook{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "Chartist":
		fi := &Chartist{}
		fi.SubClass = ChartistSingle
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	/* BEGIN of Group Features */
	case "BatchLastSeenBookV2":
		fi := &GroupPriceLevels{}
		fi.SubClass = BatchLastSeenBookV2
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchSignedEMABookV2":
		fi := &GroupPriceLevels{}
		fi.SubClass = BatchSignedEMABookV2
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchSignedIDSBookV2":
		fi := &GroupPriceLevels{}
		fi.SubClass = BatchSignedIDSBookV2
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchUnsignedIDSBook":
		fi := &GroupPriceLevels{}
		fi.SubClass = BatchUnsignedIDSBook
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchBollingerBand":
		fi := &GroupBollinger{}
		fi.SubClass = BollingerMA
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchBookPressureIDS":
		fi := &GroupBookPressureIDS{}
		fi.SubClass = BookPressureIDSGroup
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchBookPressureIDSNDiff":
		fi := &GroupBookPressureIDS{}
		fi.SubClass = BookPressureIDSNDiffGroup
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchBidAskRatio":
		fi := &GroupBookPressureIDS{}
		fi.SubClass = BookPressureIDSGroup
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	/*    BEGIN of modified existing features */
	case "BatchChartist":
		fi := &Chartist{}
		fi.SubClass = ChartistGroup
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchLaggingBasisReturn":
		fi := &LaggingBasisReturn{}
		fi.SubClass = LaggingBasisReturnGroup
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchHorizonPriceExtrema":
		fi := &HorizonPriceExtrema{}
		fi.SubClass = HorizonPriceExtremaGroup
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	/*    END of modified existing features */

	/*    BEGIN of reuse of existing technical classes */
	case "BatchADXIndicator":
		fi := &ADXIndicator{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchCommodityChannelIndex":
		fi := &CommodityChannelIndex{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchRelativeStrengthIndex":
		fi := &RelativeStrengthIndex{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchTrueStrengthIndex":
		fi := &TrueStrengthIndex{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchStochasticOscillator":
		fi := &StochasticOscillator{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchHorizonStatDelta":
		fi := &HorizonStatDelta{}
		fi.SubClass = HorizonStatDeltaChinaFutures
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchHorizonStatsRangeDelta":
		fi := &HorizonStatsRangeDelta{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchTradeOpenInterestEMA":
		fi := &TradeOpenInterestEMA{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	/*     END of reuse of existing technical classes */

	/*     BEGIN of resue of exisisting detrend classes */
	case "BatchDetrendLastSeenBookV2":
		fi := &DetrendLastSeenBookV2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchDetrendSignedEMABookV2":
		fi := &DetrendSignedEMABookV2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchDetrendSignedIDSBookV2":
		fi := &DetrendSignedIDSBookV2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BatchDetrendUnsignedIDSBook":
		fi := &DetrendUnSignedIDSBook{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	/*     END of resue of exisisting detrend classes */
	/* END of Group Features */

	/* BEGIN of Factor Features */
	case "FactorLastSeenBook":
		fi := &FactorPriceLevels{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = FactorLastSeenBook
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "FactorSignedEMABook":
		fi := &FactorPriceLevels{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = FactorSignedEMABook
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "FactorSignedEMABook2":
		fi := &FactorPriceLevels{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = FactorSignedEMABook2
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "FactorSignedIDSBook":
		fi := &FactorPriceLevels{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = FactorSignedIDSBook
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "FactorUnsignedIDSBook":
		fi := &FactorPriceLevels{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = FactorUnsignedIDSBook
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "FactorLaggingBasisReturn":
		fi := &LaggingBasisReturn{}
		fi.SubClass = LaggingBasisReturnFactor
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "FactorLaggingBasisReturn2":
		fi := &LaggingBasisReturn2{}
		fi.SubClass = LaggingBasisReturnFactor
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "FactorBookPressureIDS":
		fi := &FactorBookPressures{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = FactorBookPressureIDS
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "FactorBookPressureIDSNDiff":
		fi := &FactorBookPressures{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = FactorBookPressureIDSNDiff
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "FactorBidAskRatio":
		fi := &FactorBookPressures{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = FactorAskBidRatio
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	/* END of Factor Features */

	/* BEGIN of Equity Specific Features */
	case "TradeEMA":
		fi := &TradeEMA{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "EquityChartist":
		fi := &Chartist{}
		fi.SubClass = ChartistChinaEquity
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "EquityHorizonStatDelta":
		fi := &HorizonStatDelta{}
		fi.SubClass = HorizonStatDeltaChinaEquity
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "EquityHorizonStatDelta2":
		fi := &HorizonStatDelta2{}
		fi.SubClass = HorizonStatDeltaChinaEquity
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "EquityDetrendLastSeenBook":
		fi := &EquityDetrendPriceLevels{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = EquityDetrendLastSeenBook
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "EquityDetrendSignedIDSBook":
		fi := &EquityDetrendPriceLevels{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = EquityDetrendSignedIDSBook
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "EquityDetrendUnsignedIDSBook":
		fi := &EquityDetrendPriceLevels{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = EquityDetrendUnsignedIDSBook
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "EquityDetrendSignedEMABook":
		fi := &EquityDetrendPriceLevels{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.SubClass = EquityDetrendSignedEMABook
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	/* END of Equity Sepcific Features */

	/* BEGIN of New Features */
	case "EquityBasicStats":
		fi := &EquityBasicStats{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "EquityOpenAuction":
		fi := &EquityOpenAuction{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "EquityStyle":
		fi := &EquityStyle{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "GeneralBookFeature":
		fi := &GeneralBookFeature{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "MidPriceBookFeature":
		fi := &MidPriceBookFeature{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "TSFuncFeature":
		fi := &TSFuncFeature{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "RatioFeature":
		fi := &RatioFeature{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "ROC":
		fi := &ROC{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "VariableBackRet":
		fi := &VariableBackRet{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "LastValueFeature":
		fi := &LastValueFeature{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-1":
		fi := &T_1{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-3":
		fi := &T_3{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-4A":
		fi := &T_4{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-4B":
		fi := &T_4{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-5":
		fi := &T_5{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-8":
		fi := &T_8{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-9":
		fi := &T_9{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-10":
		fi := &T_10{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-11":
		fi := &T_11{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-12":
		fi := &T_12{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-14A":
		fi := &T_14A{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-14B":
		fi := &T_14B{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-14C":
		fi := &T_14C{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-14D":
		fi := &T_14D{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-14E":
		fi := &T_14E{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-15":
		fi := &T_15{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-16":
		fi := &T_16{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "T-17":
		fi := &T_17{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "M-1":
		fi := &M_1{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "M-2":
		fi := &M_2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "M-3":
		fi := &M_3{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "M-4":
		fi := &M_4{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "M-5":
		fi := &M_5{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "M-6":
		fi := &M_6{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	/* END of New Features */

	/* BEGIN of Forward Stats */
	case "ForwardRet":
		fi := &ForwardRet{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "OvForwardRet":
		fi := &OvForwardRet{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "BookStatus":
		fi := &BookStatus{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	/* END   of Forward Stats */

	/* BEGIN of chart features */
	case "DragonChartOrder":
		fi := &OrderClassification{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	/* END of chart features */

	/* BEGIN of z1 features */
	case "Z1-BP":
		fi := &Z1_BP{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-HBP":
		fi := &Z1_HBP{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-SD":
		fi := &Z1_SD{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-SL":
		fi := &Z1_SL{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-HSL":
		fi := &Z1_HSL{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-TSD":
		fi := &Z1_TSD{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-PSP":
		fi := &Z1_PrcSharp{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-PS":
		fi := &Z1_PrcSup{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-PS2":
		fi := &Z1_PrcSup2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-PS3":
		fi := &Z1_PrcSup3{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-LC":
		fi := &Z1_LevelChase{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-LC2":
		fi := &Z1_LevelChase2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-AGT":
		fi := &Z1_AgTrd{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "Z1-AGT2":
		fi := &Z1_AgTrd2{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "Z1-AGT3":
		fi := &Z1_AgTrd3{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "Z1-AGT4":
		fi := &Z1_AgTrd4{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "Z1-AGT5":
		fi := &Z1_AgTrd5{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "Z1-DBG":
		fi := &Z1_DEBUG{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	/* END of z1 features */

	/* BEGIN of MX features */
	case "MX-ASR":
		fi := &MXASR{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-ATR":
		fi := &MXATR{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-BSD":
		fi := &MXBSD{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-BSN":
		fi := &MXBSN{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-DPO":
		fi := &MXDPO{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-ENP":
		fi := &MXENP{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-ICK":
		fi := &MXICK{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-KAMA":
		fi := &MXKAMA{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-MACD":
		fi := &MXMACD{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-MRET":
		fi := &MXMRET{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "MX-MSI":
		fi := &MXMSI{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi
	case "MX-MVOL":
		fi := &MXMVOL{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-PCG":
		fi := &MXPCG{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-PDT":
		fi := &MXPDT{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-VPC":
		fi := &MXVPC{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-RCE":
		fi := &MXRCE{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-TRD":
		fi := &MXTrend{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-TNOP":
		fi := &MXTNOP{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-UCR":
		fi := &MXUlcer{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-VTR":
		fi := &MXVTR{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-VPT":
		fi := &MXVPT{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "MX-VWP":
		fi := &MXVWAP{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "E-7":
		fi := &E_7{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "E-7L1":
		fi := &E_7{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "E-7L2":
		fi := &E_7{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	case "E-8":
		fi := &E_8{}
		fi.init(prefsName, featureName, logDir, dateStr)
		fi.loadFeaturePrefs()
		fi.setSelfPointer(fi)
		return fi

	/* END of MX features */

	default:
		panic(fmt.Sprintf("Unknown feature class name '%s' (feature name '%s')", className, featureName))
	}
}

//common methods used in features class/structs.

//calcBuySellSpread
//calc_buy_sell_spread in book_features_toolkits.pyx.
// used in both BookFeature.go and detrendBookFeatures.go
func calcBuySellSpread(pa, sa []float64, mPrice float64) float64 {
	if len(pa) != len(sa) {
		return 0.0
	}

	var buyVol, sellVol float64 = 0.0, 0.0
	var buyAmt, sellAmt float64 = 0.0, 0.0
	for i := 0; i < len(pa); i++ {
		if sa[i] > 0 {
			buyVol += sa[i]
			buyAmt += sa[i] * pa[i]
		} else {
			sellVol += sa[i]
			sellAmt += sa[i] * pa[i]
		}
	}
	if buyVol == 0.0 && sellVol == 0.0 {
		return 0.0
	} else {
		var avgBPrice, avgSPrice float64 = 0, 0
		if buyVol > 0 {
			avgBPrice = buyAmt / buyVol
		}
		if sellVol < 0 {
			avgSPrice = sellAmt / sellVol
		}
		return (math.Abs(avgBPrice) - math.Abs(avgSPrice)) / mPrice
	}
}

//calcBuySellRatioV2: calc_buy_sell_ratio_v2 in book_features_toolkits.pyx
// returns ratio between buy orders and sell orders, without respect to the book price distribution
// used in both BookFeature.go and detrendBookFeatures.go
func calcBuySellRatioV2(sa []float64) float64 {
	l := len(sa)
	var buyVol, sellVol float64 = 0.0, 0.0
	for i := 0; i < l; i++ {
		if sa[i] > 0 {
			buyVol += sa[i]
		} else {
			sellVol += sa[i]
		}
	}
	if buyVol == 0.0 && sellVol == 0.0 {
		return 0.0
	} else {
		return buyVol/(buyVol-sellVol)*2 - 1
	}
}

// V3 functions: limitUp/Down -> 0, rather than -1/1

func calcBuySellRatioV3(sa []float64) float64 {
	l := len(sa)
	var buyVol, sellVol float64 = 0.0, 0.0
	for i := 0; i < l; i++ {
		if sa[i] > 0 {
			buyVol += sa[i]
		} else {
			sellVol += sa[i]
		}
	}
	if buyVol == 0.0 || sellVol == 0.0 {
		return 0.0
	} else {
		return buyVol/(buyVol-sellVol)*2 - 1
	}
}

func calcBuySellSpreadV3(pa, sa []float64, mPrice float64) float64 {
	if len(pa) != len(sa) {
		return 0.0
	}

	var buyVol, sellVol float64 = 0.0, 0.0
	var buyAmt, sellAmt float64 = 0.0, 0.0
	for i := 0; i < len(pa); i++ {
		if sa[i] > 0 {
			buyVol += sa[i]
			buyAmt += sa[i] * pa[i]
		} else {
			sellVol += sa[i]
			sellAmt += sa[i] * pa[i]
		}
	}
	if buyVol == 0.0 || sellVol == 0.0 {
		return 0.0
	} else {
		var avgBPrice, avgSPrice float64 = 0, 0
		if buyVol > 0 {
			avgBPrice = buyAmt / buyVol
		}
		if sellVol < 0 {
			avgSPrice = sellAmt / sellVol
		}
		return (math.Abs(avgBPrice) - math.Abs(avgSPrice)) / mPrice
	}
}
