// ported from combo_rf.py
// yzhu, 20180703
// Yingfa, add some new methods for PROD. Also some optimization on performance. 20180720+

package feature

import (
	"fmt"
	"os"
	"path/filepath"
	"time"

	"TES/QR/infer/regressor"
	"bufio"
	"bytes"
	"compress/gzip"
	"io/ioutil"
	"math"
	"strconv"
	"strings"

	"TES/QR/alpha_ov/data"
	"TES/QR/alpha_ov/mathUtils"
	tu "TES/tesUtilsGo"
	"TES/tesUtilsGo/common"
)

/*
AlphaV2 is an implementation of BookAlphaV2 in Python
BookAlphaV2 in Python inherits ALphaV2 + BookSamplerV2
*/

// this epsilon value is to deal with the rounding off from floats to strings
// example: 1522314000.9151 is converted to "1522314000.92" in python
// so in replay mode, we have to subtract a epsilon from the time parsed.
const timeEps = 0.1 //0.005

type timedAlpha struct {
	secEpoch float64
	alpha    float64
}

type AlphaMode int

const (
	LiveAlpha AlphaMode = iota + 1
	BatchAlpha
	ReplayAlpha
)

type AlphaV2 struct {
	BookSamplerV2
	AlphaItf

	alphaMode         AlphaMode
	alpha_logging_all bool
	alpha_coefs_path  string

	// model
	fitterName      string
	alpha_regressor *regressor.Regressor

	// alpha values
	sid2alphas    map[int][]timedAlpha
	sid2index     map[int]int
	sid2lastAlpha map[int]timedAlpha

	// features
	hExtra       []string // extra header fields for all features
	numFeatures  int
	featureArray []float64

	// alpha & sampler output
	outputData    []string    //outputData specific for AlphaV2 (removed from base class)
	featureMatrix [][]float64 //n x p feature matrix for batch mode, replaces python's feature_value_deque

	// post-processing features
	bound_by_std int
	feature_std  map[string]float64 //featureName -> median of StdDev of this feature in past 3 days
	ret_name     string             //return normalized by
	fstats       *data.FeatureStats

	//---prod--
	keyInAlphaServer      [3]byte
	func2TellAlphaUpdated func([3]byte, int, float64, float64, float64) // for prod usage. "alpha_value, exTms, localTms"
	outputLiveResultData  []float64                                     //for prod usage. Yingfa. Sim/batch mode should be also the same to use this,not to use outputData. But not now. todo
}

func (alp *AlphaV2) Init(prefName string, samplerName string, datestr string, alwaysLoadEverything bool, samplerMode SamplerMode) {
	alp.BookSamplerV2.Init(prefName, samplerMode, datestr)
	alp.LoadGeneralPrefs()
	alp.SetHeader()

	alp.outputData = append(alp.outputData, alp.header)

	alp.BookSamplerV2.DoAppendData = false //HACK

	alp.fstats = &data.FeatureStats{}

	alp.setAlphaMode(alp.prefs.GetStringPref("alpha_mode"))

	if alp.createOutputDir() || alwaysLoadEverything {
		alp.numFeatures = 0
		for _, fn := range alp.featureNameList {
			alp.numFeatures += len(alp.featureDict[fn].GetFeatureNames())
		}
		alp.featureArray = make([]float64, alp.numFeatures)
	}

	alp.sid2alphas = make(map[int][]timedAlpha)
	alp.sid2index = make(map[int]int)
	alp.sid2lastAlpha = make(map[int]timedAlpha)

	alp.initAlphaModel()

	//# alpha_value is updated at alpha_update_sec
	if alp.prefs.HasPref("bound_by_std") {
		alp.bound_by_std = alp.prefs.GetIntPref("bound_by_std")
	} else {
		alp.bound_by_std = 0
	}

	if alp.bound_by_std != 0 {
		window := 3
		alp.feature_std = alp.fstats.LoadPrevDayStdMedian(alp.outputDir, alp.datestr, window)
	}

	if alp.prefs.HasPref("ret_normalized_by") {
		alp.ret_name = alp.prefs.GetStringPref("ret_normalized_by")
	} else {
		alp.ret_name = ""
	}

	//init output result data slice. yangyingfa
	alp.outputLiveResultData = make([]float64, 0, 48000) //3 floats for one line.
	alp.func2TellAlphaUpdated = nil
}

// GetName, implement of interface method. //yang
func (alp *AlphaV2) GetName() string {
	return "AlphaV2"
}

func (alp *AlphaV2) LoadGeneralPrefs() {
	//alp.SamplerV2.LoadGeneralPrefs()  //because go has no dyanmic dispatching, we have to call LoadGeneralPrefs explicitly!
	if alp.prefs.HasPref("fitter_name") {
		alp.fitterName = alp.prefs.GetStringPref("fitter_name")
	} else {
		panic("golang version requires fitter_name explicitly.")
	}
}

func (alp *AlphaV2) SetHeader() {
	//# output header is created here
	alp.header = "sid,rec_epoch,ex_time,date"
	hExtra := make([]string, 0)
	for _, fn := range alp.featureNameList {
		hExtra = append(hExtra, alp.featureDict[fn].GetFeatureNames()...)
	}
	alp.hExtra = hExtra

	//# set alpha logging verbosity level
	if alp.prefs.HasPref("alpha_logging_all") {
		alp.alpha_logging_all = alp.prefs.GetBoolPref("alpha_logging_all")
	} else {
		alp.alpha_logging_all = false
	}
	if alp.alpha_logging_all {
		extraHeader := strings.Join(hExtra, ",")
		alp.header = alp.header + "," + extraHeader + ",day_session,alpha"
	} else {
		alp.header = alp.header + ",day_session,alpha"
	}

	//Add extra feature names if any
	var allExtraFeatureNames []string
	for _, efn := range alp.extraFeatureNameList {
		allExtraFeatureNames = append(allExtraFeatureNames, alp.featureDict[efn].GetFeatureNames()...)
	}

	if alp.extraNumFeatures != len(allExtraFeatureNames) {
		panic("alp.extraNumFeatures != len(allExtraFeatureNames): extraNumFeatures should be initialized in SamplerV2.Init method")
	}

	if len(allExtraFeatureNames) > 0 {
		alp.header = alp.header + "," + strings.Join(allExtraFeatureNames, ",")
	}
}

func (alp *AlphaV2) setAlphaMode(alphaModeStr string) {
	// alphaModeStr -> alphaMode
	switch alphaModeStr {
	case "batch":
		alp.alphaMode = BatchAlpha
	case "live":
		alp.alphaMode = LiveAlpha
	case "replay":
		alp.alphaMode = ReplayAlpha
	default:
		panic(fmt.Sprintf("Unknown alpha mode: %s", alphaModeStr))
	}
	fmt.Println("Alpha mode is: ", alphaModeStr, alp.alphaMode)
}

func (alp *AlphaV2) initAlphaModel() {
	if alp.alphaMode == BatchAlpha {
		//# in batch mode we need to store features of all updates
		alp.featureMatrix = make([][]float64, 0)
	}
	//# read alpha coefs location
	alp.alpha_coefs_path = alp.prefs.GetStringPref("alpha_coefs_path")
	//# load alpha regressor
	//# use current month
	//# only use this in live/batch mode
	if alp.alphaMode == LiveAlpha || alp.alphaMode == BatchAlpha {
		if alp.fitterName == "xgb" {
			// create the booster and load some parameters
			//fname := filepath.Join(alp.alpha_coefs_path,
			//	alp.datestr[:6],
			//	"xgb.model")
			//2022-04-11
			//alphaV2.go is deadcode, the change here is to ignore compile error
			empty_cfg := ``
			alp.alpha_regressor = regressor.NewRegressorByJsonStr(empty_cfg, alp.datestr)
		} else {
			panic(fmt.Sprintf("Unknown fitter name %s", alp.fitterName))
		}
	} else if alp.alphaMode == ReplayAlpha {
		alp.loadAlpha()
	}
}

func (alp *AlphaV2) UpdateAlphaMode(alphaModeStr string) {
	alp.setAlphaMode(alphaModeStr)
	alp.createOutputDir()
	alp.initAlphaModel()
}

func (alp *AlphaV2) loadAlpha() {
	//# this is for replay mode only
	//# assume alpha values are generated by batch/live mode
	outputDir := filepath.Join(alp.outputDir, alp.datestr)
	alphaFile := filepath.Join(outputDir, fmt.Sprintf("%s_alpha.gz", alp.fitterName))

	f, err := os.Open(alphaFile)
	defer f.Close()
	if err != nil {
		panic(fmt.Sprintf("cannot access alpha file %s", alphaFile))
	}

	gr, _ := gzip.NewReader(f)
	defer gr.Close()

	reader := bufio.NewReader(gr)

	firstLine := true
	for {
		line, _, err := reader.ReadLine()
		if err != nil {
			break
		}
		if firstLine {
			firstLine = false
			continue
		}
		fields := strings.Split(string(line), ",")
		v, err := strconv.ParseFloat(fields[5], 64)
		if err != nil {
			v = math.NaN()
		}
		sid, _ := strconv.Atoi(fields[0])
		secEpoch, _ := strconv.ParseFloat(fields[1], 64)
		if _, ok := alp.sid2alphas[sid]; !ok {
			// encounter a new sid, initialize alpha vector and position
			alp.sid2alphas[sid] = make([]timedAlpha, 0, 4000)
			alp.sid2index[sid] = 0
		}
		alp.sid2alphas[sid] = append(alp.sid2alphas[sid], timedAlpha{secEpoch, v})
	}
}

func (alp *AlphaV2) createOutputDir() bool {

	outputDir := filepath.Join(alp.outputDir, alp.datestr)
	tu.CreateDirIfNotExist(outputDir)

	if alp.alphaMode == BatchAlpha || alp.alphaMode == ReplayAlpha {
		alp.outputFile = filepath.Join(outputDir, fmt.Sprintf("%s_alpha.gz", alp.fitterName))
	} else if alp.alphaMode == LiveAlpha {
		alp.outputFile = filepath.Join(outputDir, fmt.Sprintf("%s_alpha_live_%s.gz",
			alp.fitterName, common.SecSinceEpochToTimestr(float64(time.Now().Unix()))))
		//# <-- alpha_live may break and continue for several times, so put the timestamp into filename. Yingfa.
	}

	if alp.alphaMode == BatchAlpha || alp.alphaMode == LiveAlpha {
		if _, err := os.Stat(alp.outputFile); err == nil {
			return false //sampler outputFile already exists
		} else {
			return true //outputFile Not Exist, waiting to be written
		}
	} else if alp.alphaMode == ReplayAlpha {
		if _, err := os.Stat(alp.outputFile); err != nil {
			panic(fmt.Sprintf("In alpha replay mode, outputFile must exist. %s", alp.outputFile))
		}
		return false //if no error, file exists
	}

	panic("Unreachable code")
}

func (alp *AlphaV2) PublishData() {
	if alp.alphaMode == LiveAlpha {
		// live output is diff, to save time in every tick cal, we have some calculation job in publishdata when in live mode.
		alp.publishLiveData() //added by Yingfa.
		return
	}
	if alp.alphaMode == ReplayAlpha {
		// for Reply mode, we don't publish anything
		return
	}

	// Now the alphaModeStr must be "Batch"
	if alp.alphaMode != BatchAlpha {
		panic("The following code is for alp.alphaModeStr == Batch")
	}

	alp.FinalizeExtraFeatures()

	var alps []float64
	{
		// Calculate all alphas in a batch
		if alp.fitterName == "xgb" {
			if len(alp.featureMatrix) > 0 {
				for _, featVec := range alp.featureMatrix {
					alpha := alp.alpha_regressor.PredictSerial(0, 0, featVec)
					alps = append(alps, alpha)
				}
			} else {
				fmt.Printf("ERROR: featureMatrix size = 0 in Predict.\n")
			}
		} else {
			panic("fitter name other than xgb not implemented yet!")
		}

		//normalize
		if alp.ret_name != "" {
			//# predicted value is return divided by previous day's std
			//# need to multiply std back
			for i := 0; i < len(alps); i++ {
				alps[i] *= alp.feature_std[alp.ret_name]
			}
		}
	}

	if len(alp.outputData)-1 != len(alps) {
		panic(fmt.Sprintf("length of outputData %d - 1 != length of predicted alphas %d",
			len(alp.outputData), len(alps)))
	}
	for i, value := range alps {
		alp.outputData[i+1] = alp.outputData[i+1] + "," + fmt.Sprintf("%g", float64(value))
	}
	if len(alp.extraOutputMatrix) > 0 {
		if len(alps) != len(alp.extraOutputMatrix) {
			panic(fmt.Sprintf("length of extraOuputMatrix %d != length of predicted alphas %d",
				len(alp.extraOutputMatrix), len(alps)))
		}
		rowStrs := make([]string, alp.extraNumFeatures)
		for i, rowVals := range alp.extraOutputMatrix {
			for j, val := range rowVals {
				rowStrs[j] = fmt.Sprintf("%g", val) // use %g for extra feature
			}
			alp.outputData[i+1] = alp.outputData[i+1] + "," + strings.Join(rowStrs, ",")
		}
	}

	// write lines of outputData into a gzip file
	outputDir := filepath.Join(alp.outputDir, alp.datestr)
	tu.CreateDirIfNotExist(outputDir)

	var buf bytes.Buffer
	w := gzip.NewWriter(&buf)
	for _, row := range alp.outputData {
		w.Write([]byte(row))
		w.Write([]byte("\n"))
	}
	w.Close()
	err := ioutil.WriteFile(alp.outputFile, buf.Bytes(), 0666)
	if err != nil {
		panic(fmt.Sprintf("writing file to %s fails", alp.outputFile))
	} else {
		fmt.Printf("Alpha file written to %s\n", alp.outputFile)
	}
}

func (alp *AlphaV2) appendOutputData(sid int, book *data.FixedLevelBook) {
	//# retrieve receive time stamp for calculating EMA
	origRecEpoch := book.RecSecSinceEpoch
	adjRecEpoch := common.SubtractBreakSeconds(origRecEpoch, alp.secMorning, book.EID)
	//# retrieve source time stamp for calculating lagging returns
	srcEpoch := book.ExTimestamp
	//# features are calculated based on bid/ask price/sizes
	priceM := book.GetMidPrice()

	//# only append output_data at PUBLISH events
	//# if would like to trade at night, check in_trading[0];
	inTrading := (alp.tradeNightSession && alp.inTrading.InNightSession) || (!alp.tradeNightSession && alp.inTrading.InDaySession)
	if inTrading &&
		(alp.BookSamplerV2.mode == PerSid && sid == alp.baseSid || alp.BookSamplerV2.mode == Group && alp.baseSidSet[sid]) &&
		SEventIsIntersect(alp.eventType, alp.publishEvents) {

		fields := make([]string, 0) //TODO: make fields as member &
		//TODO: further optimization: use float64 instead of strings
		//live-batch same impl
		fields = append(fields,
			strconv.Itoa(sid),
			fmt.Sprintf("%.2f", book.RecSecSinceEpoch), //TODO: use logic .1 or .2 (otherwise Replay mode won't read)
			common.SecSinceEpochToTimestr(book.ExTimestamp-3600*8),
			alp.datestr)

		if alp.alphaMode == BatchAlpha {
			//batch mode keeps the full n*p feature matrix
			alp.featureMatrix = append(alp.featureMatrix, make([]float64, alp.numFeatures))
		}

		feature_idx := 0
		for _, fn := range alp.featureNameList {
			var featValues []float64
			if alp.BookSamplerV2.mode == PerSid {
				featValues, _ = alp.featureDict[fn].GetValues(priceM, adjRecEpoch)
			} else { // Group
				featValues, _ = alp.featureDict[fn].GetSidValues(sid, priceM, adjRecEpoch)
			}
			expectedNum := len(alp.featureDict[fn].GetFeatureNames())
			if len(featValues) != expectedNum {
				panic(fmt.Sprintf("feature %s does not return %d values: %v", fn, expectedNum, featValues))
			}
			//# bound by previous day's 3 * std
			if alp.bound_by_std != 0 {
				tmp_name := alp.featureDict[fn].GetFeatureNames()
				for idx, featName := range tmp_name {
					ub := 3 * alp.feature_std[featName]
					lb := -3 * alp.feature_std[featName]
					featValues[idx] = mathUtils.Bound(featValues[idx], lb, ub)
				}
			}

			// log all features
			if alp.alpha_logging_all {
				//live-batch same impl
				for _, v := range featValues {
					fields = append(fields, fmt.Sprintf("%g", float64(v)))
				}
			}

			// append values of one feature
			// live-batch same impl
			i := len(alp.featureMatrix) - 1
			for j, value := range featValues {
				alp.featureMatrix[i][feature_idx+j] = value
			}
			feature_idx += expectedNum
		}

		//# add day_session
		var sessionNumber int
		if !alp.inTrading.InDaySession {
			sessionNumber = 0
		} else {
			if srcEpoch-alp.secMorning <= 90*60 {
				//# 9:00 - 10:30
				sessionNumber = 1
			} else if srcEpoch-alp.secMorning <= 150*60 {
				//# 10:30 - 11:30
				sessionNumber = 2
			} else {
				//# afternoon
				sessionNumber = 3
			}
		}

		fields = append(fields, strconv.Itoa(sessionNumber))

		alp.outputData = append(alp.outputData, strings.Join(fields, ","))

		// now save extra features to the matrix
		if len(alp.extraFeatureNameList) > 0 {
			row := make([]float64, alp.extraNumFeatures)
			alp.extraOutputMatrix = append(alp.extraOutputMatrix, row)

			feature_idx := 0
			for _, fn := range alp.extraFeatureNameList {
				var featValues []float64
				if alp.BookSamplerV2.mode == PerSid {
					featValues, _ = alp.featureDict[fn].GetValues(priceM, adjRecEpoch)
				} else { // Group
					featValues, _ = alp.featureDict[fn].GetSidValues(sid, priceM, adjRecEpoch)
				}
				expectedNum := len(alp.featureDict[fn].GetFeatureNames())
				if len(featValues) != expectedNum {
					panic(fmt.Sprintf("feature %s does not return %d values: %v", fn, expectedNum, featValues))
				}
				copy(row[feature_idx:], featValues)
				feature_idx += expectedNum
			}
		}
	}
}

//-------------------------------
//--Begin of production methods---
// added by Yingfa Yang. 20180727

// predict and appendoutputdata. For live mode only. and for production.
// added by Yang.
func (alp *AlphaV2) predictAndAppendResult(sid int, book *data.FixedLevelBook) {
	//# retrieve receive time stamp for calculating EMA
	origRecEpoch := book.RecSecSinceEpoch
	adjRecEpoch := common.SubtractBreakSeconds(origRecEpoch, alp.secMorning, book.EID)
	//# retrieve source time stamp for calculating lagging returns
	//srcEpoch := book.ExTimestamp
	//# features are calculated based on bid/ask price/sizes
	priceM := book.GetMidPrice()

	isInBaseSids := (alp.BookSamplerV2.mode == PerSid && sid == alp.baseSid) || (alp.BookSamplerV2.mode == Group && alp.baseSidSet[sid])
	//# only append output_data at PUBLISH events
	//# if would like to trade at night, check in_trading[0];
	inTrading := (alp.tradeNightSession && alp.inTrading.InNightSession) || (!alp.tradeNightSession && alp.inTrading.InDaySession)
	if inTrading &&
		isInBaseSids &&
		SEventIsIntersect(alp.eventType, alp.publishEvents) {

		//if alp.alphaModeStr == "live" {
		//live mode keeps only 1*p, i.e., the current feature vector
		if len(alp.featureMatrix) < 1 {
			alp.featureMatrix = append(alp.featureMatrix, make([]float64, alp.numFeatures))
		}
		//}else if alp.alphaModeStr == "batch" {
		//	//batch mode keeps the full n*p feature matrix
		//	alp.featureMatrix = append(alp.featureMatrix, make([]float64, alp.numFeatures))
		//}

		feature_idx := 0

		//prepare matrix for prediction.
		for _, fn := range alp.featureNameList {
			var featValues []float64
			if alp.BookSamplerV2.mode == PerSid {
				featValues, _ = alp.featureDict[fn].GetValues(priceM, adjRecEpoch)
			} else { // Group
				featValues, _ = alp.featureDict[fn].GetSidValues(sid, priceM, adjRecEpoch)
			}
			expectedNum := len(alp.featureDict[fn].GetFeatureNames())
			if len(featValues) != expectedNum {
				panic(fmt.Sprintf("feature %s does not return %d values: %v", fn, expectedNum, featValues))
			}
			//# bound by previous day's 3 * std
			if alp.bound_by_std != 0 {
				tmp_name := alp.featureDict[fn].GetFeatureNames()
				for idx, featName := range tmp_name {
					ub := 3 * alp.feature_std[featName]
					lb := -3 * alp.feature_std[featName]
					featValues[idx] = mathUtils.Bound(featValues[idx], lb, ub)
				}
			}

			// append values of one feature
			// live-batch same impl
			i := len(alp.featureMatrix) - 1
			for j, value := range featValues {
				alp.featureMatrix[i][feature_idx+j] = value
			}
			feature_idx += expectedNum
		}

		//# calculate alpha value (only for live mode)

		alpha := alp.alpha_regressor.PredictSerial(0, 0, alp.featureMatrix[0])
		//normalize
		if alp.ret_name != "" {
			//# predicted value is return divided by previous day's std
			//# need to multiply std back
			alpha *= alp.feature_std[alp.ret_name]
		}

		alp.sid2lastAlpha[sid] = timedAlpha{book.ExTimestamp, alpha}

		// update the result for alpha server.
		if alp.func2TellAlphaUpdated != nil {
			//fmt.Println(alp.keyInAlphaServer, alpha, book.ExTimestamp, book.RecSecSinceEpoch)
			alp.func2TellAlphaUpdated(alp.keyInAlphaServer, sid, alpha, book.ExTimestamp, book.RecSecSinceEpoch)
		}

		//live-batch same impl
		alp.outputLiveResultData = append(alp.outputLiveResultData,
			float64(sid),
			book.RecSecSinceEpoch,
			book.ExTimestamp,
			alpha) // 4 float64 as a group for one line's output in result gz file.
	} else if inTrading && isInBaseSids && alp.func2TellAlphaUpdated != nil {
		// even not in events. we should also tell the alpha service that we have got the latest tick.
		alp.func2TellAlphaUpdated(alp.keyInAlphaServer, sid, 0, -1, origRecEpoch) // -1 means return back the last stamp and alpha is fine.
	}
}

// whichSession, findout which session the ex_timestamp is in. This would be used in publish method.
// Not to use in live mode to save time.
// added by YangYingfa.
func (alp *AlphaV2) whichSession(sid int, exTms float64) int {
	//# add day_session
	var sessionNumber int
	_, inDaySession, _ := common.InTradingBatch(exTms, sid) //timestamp here should add 8*3600 into it as in UTC mode.
	if !inDaySession {
		sessionNumber = 0
	} else {
		if exTms-alp.secMorning <= 90*60 {
			//# 9:00 - 10:30
			sessionNumber = 1
		} else if exTms-alp.secMorning <= 150*60 {
			//# 10:30 - 11:30
			sessionNumber = 2
		} else {
			//# afternoon
			sessionNumber = 3
		}
	}
	return sessionNumber
}

// live mode only. batch may use this.
func (alp *AlphaV2) publishLiveData() {
	var buf bytes.Buffer
	resFloats := alp.outputLiveResultData
	w := gzip.NewWriter(&buf)
	w.Write([]byte(alp.header + "\n"))
	for i := 0; i < len(resFloats); i += 4 {
		sid := int(resFloats[i])
		w.Write([]byte(fmt.Sprintf("%d,%.2f,%s,%s,%d,%g\n", sid, //alp.baseSid,
			resFloats[i+1], //local time stamp
			common.SecSinceEpochToTimestr(resFloats[i+2]-3600*8),
			alp.datestr,
			alp.whichSession(sid, resFloats[i+2]),
			resFloats[i+3], //predict result
		)))
	}
	w.Close()
	err := ioutil.WriteFile(alp.outputFile, buf.Bytes(), 0666)
	if err != nil {
		panic(fmt.Sprintf("writing file to %s fails", alp.outputFile))
	}
}

// "alpha_value, exTms, localTms"
func (alp *AlphaV2) RegisterAlphaUpdate(key [3]byte, f func([3]byte, int, float64, float64, float64)) {
	alp.keyInAlphaServer = key
	alp.func2TellAlphaUpdated = f
}

//--End of production methods---
//-------------------------------

func (alp *AlphaV2) GetAlpha(sid int) (float64, float64) {
	if a, ok := alp.sid2lastAlpha[sid]; ok {
		return a.alpha, a.secEpoch
	} else {
		return 0, 0
	}
}

func (alp *AlphaV2) OnTickdataUpdate(td *data.TesTOBSlice) bool {
	//start := time.Now()
	//# tickdata_replay passes in raw sid
	rawSid := td.Sid
	//# need to convert it to generic sid if necessary
	if _, ok := alp.fmidMap[rawSid]; !ok {
		// in batch trader prefs, one alpha may get more symbols tick data than it really needs.
		return false
	}
	sid := alp.fmidMap[rawSid]
	//# sample only at registered events
	if alp.BookSamplerV2.OnTickDataUpdateUglyForward(td) {
		//# retrieve book by generic sid
		book := alp.flbBook[sid]
		//# retrieve receive time stamp for calculating EMA
		rec_epoch := book.RecSecSinceEpoch
		//# retrieve exchange time stamp for calculating lagging returns
		//src_epoch := book.ExTimestamp
		if alp.alphaMode == LiveAlpha {
			//fmt.Println("LiveAlpha ", string(alp.keyInAlphaServer[:]) )
			alp.predictAndAppendResult(sid, book) //added by Yang
		} else if alp.alphaMode == ReplayAlpha {
			// new impl for replay mode
			if alphas, ok := alp.sid2alphas[sid]; ok {
				i, _ := alp.sid2index[sid]
				for i < len(alphas)-1 && alphas[i+1].secEpoch-timeEps < rec_epoch {
					i++
				}
				if alphas[i].secEpoch-timeEps < rec_epoch {
					alp.sid2lastAlpha[sid] = timedAlpha{book.ExTimestamp, alphas[i].alpha}
				} else {
					// haven't found any time stamp before rec_epoch, mark alpha as zero
					alp.sid2lastAlpha[sid] = timedAlpha{book.ExTimestamp, 0}
				}
			} else {
				// replay a non-alpha universe sid
				// TODO: filter these names firstly
			}
		} else {
			// for batch modes todo: this should be combine into live mode. comment by Yingfa. will do after.
			//NOTE: BookSamplerV2.OnTickDataUpdate would call its own appendOutputData (because go has no dynamic dispatch)
			alp.appendOutputData(sid, book)
		}
		//dur := time.Now().Sub(start)
		//fmt.Println(td.Sid, td.RecSecSinceEpoch, start.UnixNano(),  dur )
		return true
	} else {
		//dur := time.Now().Sub(start)
		//fmt.Println(td.Sid, td.RecSecSinceEpoch, start.UnixNano(),  dur , "sampler not")
		// update the result for alpha server.
		// added by Yang. Only in prod
		if alp.alphaMode == LiveAlpha &&
			((alp.BookSamplerV2.mode == PerSid && sid == alp.baseSid) || (alp.BookSamplerV2.mode == Group && alp.baseSidSet[sid])) &&
			alp.func2TellAlphaUpdated != nil {
			alp.func2TellAlphaUpdated(alp.keyInAlphaServer, sid, 0, -1, td.RecSecSinceEpoch) // -1 means return back the last stamp and alpha is fine.
		}
		return false // sampler not successful
	}
}

func (alp *AlphaV2) SidUniverse() []int {
	return alp.sidUniverse
}

func GenerateAlpha(prefsName string, datestr string, samplerMode SamplerMode) {
	replay := data.NewFLBTickDataReplay(prefsName, datestr, true)

	alp := &AlphaV2{}
	alp.Init(prefsName, "AlphaV2", datestr, true, samplerMode)

	replay.RegisterTickdataUpdate(func(slice *data.TesTOBSlice) {
		alp.OnTickdataUpdate(slice)
	}, alp.sidUniverse)

	replay.RegisterTeardown(alp.PublishData)

	replay.RegisterTeardown(func() {
		fmt.Println("I am in AlphaV2's Teardown.")
	})

	// event loop
	replay.Replay()
}
