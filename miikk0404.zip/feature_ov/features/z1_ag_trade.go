package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"math"
)

type Z1_AgTrd struct {
	FeatureBase
	SidIdxMap

	ids       []int
	backTicks []int

	buyNotls  [][]*floatRingBuf
	sellNotls [][]*floatRingBuf

	termValues []float64
	termInput  map[int]bool
}

// prefs_name, feature_name, log_dir, datestr
func (t *Z1_AgTrd) init(prefsPath, featureName, logDir, datestr string) error {
	t.prefs = tu.NewPreferenceAdapter(prefsPath)
	t.featureName = featureName
	return nil
}

func (t *Z1_AgTrd) loadFeaturePrefs() error {
	t.ids = t.prefs.GetIntListPref(t.featureName + "_id_list")
	t.backTicks = t.prefs.GetIntListPref(t.featureName + "_back_ticks")

	return nil
}

//setFeatureNames: set column names.
func (t *Z1_AgTrd) setFeatureNames() {
	t.colNames = make([]string, len(t.ids))
	for i, id := range t.ids {
		t.colNames[i] = fmt.Sprintf("%s-%d", t.featureName, id)
	}
}

//initialize internal variables
func (t *Z1_AgTrd) initInternalVars() {
	t.SidIdxMap.Init(t.sidUniverseList)

	t.buyNotls = make([][]*floatRingBuf, t.nSids)
	t.sellNotls = make([][]*floatRingBuf, t.nSids)

	for i := 0; i < t.nSids; i++ {
		t.buyNotls[i] = make([]*floatRingBuf, len(t.ids))
		t.sellNotls[i] = make([]*floatRingBuf, len(t.ids))

		for j := range t.ids {
			backTick := t.backTicks[j]
			t.buyNotls[i][j] = newFloatRingBuf(backTick)
			t.sellNotls[i][j] = newFloatRingBuf(backTick)
		}
	}

	t.termValues = make([]float64, len(t.ids))
	t.termInput = map[int]bool{Z1_INPUT_AG_TRADE: true}
}

func (t *Z1_AgTrd) TermInput() map[int]bool {
	return t.termInput
}

func (t *Z1_AgTrd) TermUpdate(sid int, epoch float64, inputType int, n int, data []float64) {
	if !inTrading(epoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	buyNotls := t.buyNotls[idx]
	sellNotls := t.sellNotls[idx]

	buyNotlValue := 0.0
	sellNotlValue := 0.0
	for i := 0; i < 2; i++ {
		s := 3 * i
		if data[s] > 0 {
			if data[s+2] > 0 {
				buyNotlValue += data[s] * data[s+1]
			} else if data[s+2] < 0 {
				sellNotlValue += data[s] * data[s+1]
			}
		}
	}

	for i := range t.ids {
		buyNotlBuf := buyNotls[i]
		sellNotlBuf := sellNotls[i]

		buyNotlBuf.push(buyNotlValue)
		sellNotlBuf.push(sellNotlValue)
	}
}

// snap
func (t *Z1_AgTrd) GetSidValues(sid int, mPrice, secEpoch float64) (res []float64, err error) {
	for i := range t.ids {
		t.termValues[i] = 0
	}
	res = t.termValues
	err = nil

	if !inTrading(secEpoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	buyNotls := t.buyNotls[idx]
	sellNotls := t.sellNotls[idx]

	// secEpoch >= 9:30
	for i := range t.ids {
		buyNotl := buyNotls[i]
		sellNotl := sellNotls[i]

		sumNotl := buyNotl.sum() + sellNotl.sum()
		if buyNotl.n < buyNotl.cap || math.Abs(sumNotl) < Z1_EPS {
			res[i] = 0
		} else {
			res[i] = (buyNotl.sum() - sellNotl.sum()) / sumNotl
		}
	}

	return
}

//######################################################################
type Z1_AgTrd2 struct {
	FeatureBase
	SidIdxMap

	ids       []int
	backTicks []int
	halflives []float64

	hisBuyNotl  [][]float64
	hisSellNotl [][]float64

	hisALine []float64
	hisBLine []float64
	cursors  []int
	counts   []int

	signals [][]*ema

	termValues []float64
	termInput  map[int]bool
}

// prefs_name, feature_name, log_dir, datestr
func (t *Z1_AgTrd2) init(prefsPath, featureName, logDir, datestr string) error {
	t.prefs = tu.NewPreferenceAdapter(prefsPath)
	t.featureName = featureName
	return nil
}

func (t *Z1_AgTrd2) loadFeaturePrefs() error {
	t.ids = t.prefs.GetIntListPref(t.featureName + "_id_list")
	t.backTicks = t.prefs.GetIntListPref(t.featureName + "_back_ticks")
	t.halflives = t.prefs.GetFloat64ListPref(t.featureName + "_half_lives")

	return nil
}

//setFeatureNames: set column names.
func (t *Z1_AgTrd2) setFeatureNames() {
	t.colNames = make([]string, len(t.ids))
	for i, id := range t.ids {
		t.colNames[i] = fmt.Sprintf("%s-%d", t.featureName, id)
	}
}

//initialize internal variables
func (t *Z1_AgTrd2) initInternalVars() {
	t.SidIdxMap.Init(t.sidUniverseList)

	t.hisBuyNotl = make([][]float64, t.nSids)
	t.hisSellNotl = make([][]float64, t.nSids)
	t.signals = make([][]*ema, t.nSids)

	for i := 0; i < t.nSids; i++ {
		t.hisBuyNotl[i] = make([]float64, 50)
		t.hisSellNotl[i] = make([]float64, 50)

		t.signals[i] = make([]*ema, len(t.ids))
		for j := 0; j < len(t.ids); j++ {
			halflife := t.halflives[j]
			t.signals[i][j] = newEma(halflife, 3)
		}
	}

	t.hisALine = make([]float64, 50)
	t.hisBLine = make([]float64, 50)
	t.cursors = make([]int, t.nSids)
	t.counts = make([]int, t.nSids)

	t.termValues = make([]float64, len(t.ids))
	t.termInput = map[int]bool{Z1_INPUT_AG_TRADE: true}
}

func (t *Z1_AgTrd2) TermInput() map[int]bool {
	return t.termInput
}

func (t *Z1_AgTrd2) TermUpdate(sid int, epoch float64, inputType int, n int, data []float64) {
	if !inTrading(epoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	cursor := t.cursors[idx]
	buyNotls := t.hisBuyNotl[idx]
	sellNotls := t.hisSellNotl[idx]
	signals := t.signals[idx]

	buyNotls[cursor] = 0.0
	sellNotls[cursor] = 0.0

	for i := 0; i < 2; i++ {
		s := 3 * i
		if data[s] > 0 {
			if data[s+2] > 0 {
				buyNotls[cursor] += data[s] * data[s+1]
			} else if data[s+2] < 0 {
				sellNotls[cursor] += data[s] * data[s+1]
			}
		}
	}

	count := t.counts[idx] + 1
	t.counts[idx] = count

	for i := range t.ids {
		beginTick := cursor
		backTick := t.backTicks[i]

		if count < backTick {
			continue
		}

		hisALine := t.hisALine[:0]
		hisBLine := t.hisBLine[:0]

		hisALine = append(hisALine, sellNotls[cursor])
		hisBLine = append(hisBLine, buyNotls[cursor])

		signal := signals[i]

		for j := 1; j <= backTick; j++ {
			backIdx := (beginTick - j + 50) % 50
			hisALine = append(hisALine, sellNotls[backIdx])
			hisBLine = append(hisBLine, buyNotls[backIdx])
		}

		aValue := 0.0
		n := len(hisALine)
		if n >= 3 {
			splitNum := n / 3
			m1 := 0.0
			m2 := 0.0
			m3 := 0.0

			for _, value := range hisALine[:splitNum] {
				m1 += value
			}
			for _, value := range hisALine[splitNum:(2 * splitNum)] {
				m2 += value
			}
			for _, value := range hisALine[(2*splitNum)-1:] {
				m3 += value
			}
			if m1 < m2 && m2 < m3 {
				aValue = 1.0
			}
		}

		bValue := 0.0
		n = len(hisBLine)
		if n >= 3 {
			splitNum := n / 3
			m1 := 0.0
			m2 := 0.0
			m3 := 0.0

			for _, value := range hisBLine[:splitNum] {
				m1 += value
			}
			for _, value := range hisBLine[splitNum:(2 * splitNum)] {
				m2 += value
			}
			for _, value := range hisBLine[(2*splitNum)-1:] {
				m3 += value
			}
			if m1 < m2 && m2 < m3 {
				bValue = 1.0
			}
		}

		signal.update(secsSinceTrade(epoch), naInf2Zero((aValue-bValue)/(bValue+aValue)))
	}

	t.cursors[idx] = (cursor + 1) % 50
}

// snap
func (t *Z1_AgTrd2) GetSidValues(sid int, mPrice, secEpoch float64) (res []float64, err error) {
	for i := range t.ids {
		t.termValues[i] = 0
	}
	res = t.termValues
	err = nil

	if !inTrading(secEpoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	signals := t.signals[idx]
	for i := range t.ids {
		res[i] = signals[i].getEms(secsSinceTrade(secEpoch))
	}

	return
}

//######################################################################
type Z1_AgTrd3 struct {
	FeatureBase
	SidIdxMap

	ids       []int
	backTicks []int
	halflives []float64

	hisBuyNotl  [][]float64
	hisSellNotl [][]float64

	hisALine []float64
	hisBLine []float64
	cursors  []int
	counts   []int

	signals [][]*ema

	termValues []float64
	termInput  map[int]bool
}

// prefs_name, feature_name, log_dir, datestr
func (t *Z1_AgTrd3) init(prefsPath, featureName, logDir, datestr string) error {
	t.prefs = tu.NewPreferenceAdapter(prefsPath)
	t.featureName = featureName
	return nil
}

func (t *Z1_AgTrd3) loadFeaturePrefs() error {
	t.ids = t.prefs.GetIntListPref(t.featureName + "_id_list")
	t.backTicks = t.prefs.GetIntListPref(t.featureName + "_back_ticks")
	t.halflives = t.prefs.GetFloat64ListPref(t.featureName + "_half_lives")

	return nil
}

//setFeatureNames: set column names.
func (t *Z1_AgTrd3) setFeatureNames() {
	t.colNames = make([]string, len(t.ids))
	for i, id := range t.ids {
		t.colNames[i] = fmt.Sprintf("%s-%d", t.featureName, id)
	}
}

//initialize internal variables
func (t *Z1_AgTrd3) initInternalVars() {
	t.SidIdxMap.Init(t.sidUniverseList)

	t.hisBuyNotl = make([][]float64, t.nSids)
	t.hisSellNotl = make([][]float64, t.nSids)
	t.signals = make([][]*ema, t.nSids)

	for i := 0; i < t.nSids; i++ {
		t.hisBuyNotl[i] = make([]float64, 50)
		t.hisSellNotl[i] = make([]float64, 50)

		t.signals[i] = make([]*ema, len(t.ids))
		for j := 0; j < len(t.ids); j++ {
			halflife := t.halflives[j]
			t.signals[i][j] = newEma(halflife, 3)
		}
	}

	t.hisALine = make([]float64, 50)
	t.hisBLine = make([]float64, 50)
	t.cursors = make([]int, t.nSids)
	t.counts = make([]int, t.nSids)

	t.termValues = make([]float64, len(t.ids))
	t.termInput = map[int]bool{Z1_INPUT_AG_TRADE: true}
}

func (t *Z1_AgTrd3) TermInput() map[int]bool {
	return t.termInput
}

func (t *Z1_AgTrd3) TermUpdate(sid int, epoch float64, inputType int, n int, data []float64) {
	if !inTrading(epoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	cursor := t.cursors[idx]
	buyNotls := t.hisBuyNotl[idx]
	sellNotls := t.hisSellNotl[idx]
	signals := t.signals[idx]

	buyNotls[cursor] = 0.0
	sellNotls[cursor] = 0.0

	for i := 0; i < 2; i++ {
		s := 3 * i
		if data[s] > 0 {
			if data[s+2] > 0 {
				buyNotls[cursor] += data[s] * data[s+1]
			} else if data[s+2] < 0 {
				sellNotls[cursor] += data[s] * data[s+1]
			}
		}
	}

	count := t.counts[idx] + 1
	t.counts[idx] = count

	for i := range t.ids {
		beginTick := cursor
		backTick := t.backTicks[i]

		if count < backTick {
			continue
		}

		hisALine := t.hisALine[:0]
		hisBLine := t.hisBLine[:0]

		hisALine = append(hisALine, sellNotls[cursor])
		hisBLine = append(hisBLine, buyNotls[cursor])

		signal := signals[i]

		for j := 1; j <= backTick; j++ {
			backIdx := (beginTick - j + 50) % 50
			hisALine = append(hisALine, sellNotls[backIdx])
			hisBLine = append(hisBLine, buyNotls[backIdx])
		}

		aValue := 0.0
		n := len(hisALine)
		if n >= 3 {
			splitNum := n / 3
			m1 := 0.0
			m2 := 0.0
			m3 := 0.0

			for _, value := range hisALine[:splitNum] {
				m1 += value
			}
			for _, value := range hisALine[splitNum:(2 * splitNum)] {
				m2 += value
			}
			for _, value := range hisALine[(2*splitNum)-1:] {
				m3 += value
			}
			if m1 >= m2 && m2 >= m3 {
				aValue = 1.0
			}
		}

		bValue := 0.0
		n = len(hisBLine)
		if n >= 3 {
			splitNum := n / 3
			m1 := 0.0
			m2 := 0.0
			m3 := 0.0

			for _, value := range hisBLine[:splitNum] {
				m1 += value
			}
			for _, value := range hisBLine[splitNum:(2 * splitNum)] {
				m2 += value
			}
			for _, value := range hisBLine[(2*splitNum)-1:] {
				m3 += value
			}
			if m1 >= m2 && m2 >= m3 {
				bValue = 1.0
			}
		}

		signal.update(secsSinceTrade(epoch), naInf2Zero((bValue-aValue)/(bValue+aValue)))
	}

	t.cursors[idx] = (cursor + 1) % 50
}

// snap
func (t *Z1_AgTrd3) GetSidValues(sid int, mPrice, secEpoch float64) (res []float64, err error) {
	for i := range t.ids {
		t.termValues[i] = 0
	}
	res = t.termValues
	err = nil

	if !inTrading(secEpoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	signals := t.signals[idx]
	for i := range t.ids {
		res[i] = signals[i].getEms(secsSinceTrade(secEpoch))
	}

	return
}

//######################################################################
type Z1_AgTrd4 struct {
	FeatureBase
	SidIdxMap

	ids       []int
	backTicks []int
	halflives []float64

	hisBuyNotl  [][]float64
	hisSellNotl [][]float64

	hisALine []float64
	hisBLine []float64
	cursors  []int
	counts   []int

	buySignals  [][]*ema
	sellSignals [][]*ema

	termValues []float64
	termInput  map[int]bool
}

// prefs_name, feature_name, log_dir, datestr
func (t *Z1_AgTrd4) init(prefsPath, featureName, logDir, datestr string) error {
	t.prefs = tu.NewPreferenceAdapter(prefsPath)
	t.featureName = featureName
	return nil
}

func (t *Z1_AgTrd4) loadFeaturePrefs() error {
	t.ids = t.prefs.GetIntListPref(t.featureName + "_id_list")
	t.backTicks = t.prefs.GetIntListPref(t.featureName + "_back_ticks")
	t.halflives = t.prefs.GetFloat64ListPref(t.featureName + "_half_lives")

	return nil
}

//setFeatureNames: set column names.
func (t *Z1_AgTrd4) setFeatureNames() {
	t.colNames = make([]string, len(t.ids))
	for i, id := range t.ids {
		t.colNames[i] = fmt.Sprintf("%s-%d", t.featureName, id)
	}
}

//initialize internal variables
func (t *Z1_AgTrd4) initInternalVars() {
	t.SidIdxMap.Init(t.sidUniverseList)

	t.hisBuyNotl = make([][]float64, t.nSids)
	t.hisSellNotl = make([][]float64, t.nSids)
	t.buySignals = make([][]*ema, t.nSids)
	t.sellSignals = make([][]*ema, t.nSids)

	for i := 0; i < t.nSids; i++ {
		t.hisBuyNotl[i] = make([]float64, 50)
		t.hisSellNotl[i] = make([]float64, 50)

		t.buySignals[i] = make([]*ema, len(t.ids))
		t.sellSignals[i] = make([]*ema, len(t.ids))
		for j := 0; j < len(t.ids); j++ {
			halflife := t.halflives[j]
			t.buySignals[i][j] = newEma(halflife, 3)
			t.sellSignals[i][j] = newEma(halflife, 3)
		}
	}

	t.hisALine = make([]float64, 50)
	t.hisBLine = make([]float64, 50)
	t.cursors = make([]int, t.nSids)
	t.counts = make([]int, t.nSids)

	t.termValues = make([]float64, len(t.ids))
	t.termInput = map[int]bool{Z1_INPUT_AG_TRADE: true}
}

func (t *Z1_AgTrd4) TermInput() map[int]bool {
	return t.termInput
}

func (t *Z1_AgTrd4) TermUpdate(sid int, epoch float64, inputType int, n int, data []float64) {
	if !inTrading(epoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	cursor := t.cursors[idx]
	buyNotls := t.hisBuyNotl[idx]
	sellNotls := t.hisSellNotl[idx]
	buySignals := t.buySignals[idx]
	sellSignals := t.sellSignals[idx]

	buyNotls[cursor] = 0.0
	sellNotls[cursor] = 0.0

	for i := 0; i < 2; i++ {
		s := 3 * i
		if data[s] > 0 {
			if data[s+2] > 0 {
				buyNotls[cursor] += data[s] * data[s+1]
			} else if data[s+2] < 0 {
				sellNotls[cursor] += data[s] * data[s+1]
			}
		}
	}

	count := t.counts[idx] + 1
	t.counts[idx] = count

	secsSinceTrade := secsSinceTrade(epoch)

	for i := range t.ids {
		beginTick := cursor
		backTick := t.backTicks[i]

		if count < backTick {
			continue
		}

		hisALine := t.hisALine[:0]
		hisBLine := t.hisBLine[:0]

		hisALine = append(hisALine, sellNotls[cursor])
		hisBLine = append(hisBLine, buyNotls[cursor])

		buySignal := buySignals[i]
		sellSignal := sellSignals[i]

		for j := 1; j <= backTick; j++ {
			backIdx := (beginTick - j + 50) % 50
			hisALine = append(hisALine, sellNotls[backIdx])
			hisBLine = append(hisBLine, buyNotls[backIdx])
		}

		aValue := 0.0
		n := len(hisALine)
		if n > 1 {
			splitNum := n / 2
			m1 := 0.0
			m2 := 0.0

			for _, value := range hisALine[:splitNum] {
				m1 += value
			}
			for _, value := range hisALine[splitNum:] {
				m2 += value
			}
			if m1 > m2 {
				aValue = math.Min(naInf2Zero(m1/m2), 1)
			}
		}

		bValue := 0.0
		n = len(hisBLine)
		if n > 1 {
			splitNum := n / 2
			m1 := 0.0
			m2 := 0.0

			for _, value := range hisBLine[:splitNum] {
				m1 += value
			}
			for _, value := range hisBLine[splitNum:] {
				m2 += value
			}
			if m1 > m2 {
				bValue = math.Min(naInf2Zero(m1/m2), 1)
			}
		}

		buySignal.update(secsSinceTrade, bValue)
		sellSignal.update(secsSinceTrade, aValue)
	}

	t.cursors[idx] = (cursor + 1) % 50
}

// snap
func (t *Z1_AgTrd4) GetSidValues(sid int, mPrice, secEpoch float64) (res []float64, err error) {
	for i := range t.ids {
		t.termValues[i] = 0
	}
	res = t.termValues
	err = nil

	if !inTrading(secEpoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	secsSinceTrade := secsSinceTrade(secEpoch)
	buySignals := t.buySignals[idx]
	sellSignals := t.sellSignals[idx]
	for i := range t.ids {
		res[i] = naInf2Zero(buySignals[i].getEms(secsSinceTrade) - sellSignals[i].getEms(secsSinceTrade))
	}

	return
}

//######################################################################
type Z1_AgTrd5 struct {
	FeatureBase
	SidIdxMap

	ids       []int
	backTicks []int
	halflives []float64

	hisBuyNotl  [][]float64
	hisSellNotl [][]float64

	hisALine []float64
	hisBLine []float64
	cursors  []int
	counts   []int

	buySignals  [][]*ema
	sellSignals [][]*ema

	termValues []float64
	termInput  map[int]bool
}

// prefs_name, feature_name, log_dir, datestr
func (t *Z1_AgTrd5) init(prefsPath, featureName, logDir, datestr string) error {
	t.prefs = tu.NewPreferenceAdapter(prefsPath)
	t.featureName = featureName
	return nil
}

func (t *Z1_AgTrd5) loadFeaturePrefs() error {
	t.ids = t.prefs.GetIntListPref(t.featureName + "_id_list")
	t.backTicks = t.prefs.GetIntListPref(t.featureName + "_back_ticks")
	t.halflives = t.prefs.GetFloat64ListPref(t.featureName + "_half_lives")

	return nil
}

//setFeatureNames: set column names.
func (t *Z1_AgTrd5) setFeatureNames() {
	t.colNames = make([]string, len(t.ids))
	for i, id := range t.ids {
		t.colNames[i] = fmt.Sprintf("%s-%d", t.featureName, id)
	}
}

//initialize internal variables
func (t *Z1_AgTrd5) initInternalVars() {
	t.SidIdxMap.Init(t.sidUniverseList)

	t.hisBuyNotl = make([][]float64, t.nSids)
	t.hisSellNotl = make([][]float64, t.nSids)
	t.buySignals = make([][]*ema, t.nSids)
	t.sellSignals = make([][]*ema, t.nSids)

	for i := 0; i < t.nSids; i++ {
		t.hisBuyNotl[i] = make([]float64, 50)
		t.hisSellNotl[i] = make([]float64, 50)

		t.buySignals[i] = make([]*ema, len(t.ids))
		t.sellSignals[i] = make([]*ema, len(t.ids))
		for j := 0; j < len(t.ids); j++ {
			halflife := t.halflives[j]
			t.buySignals[i][j] = newEma(halflife, 3)
			t.sellSignals[i][j] = newEma(halflife, 3)
		}
	}

	t.hisALine = make([]float64, 50)
	t.hisBLine = make([]float64, 50)
	t.cursors = make([]int, t.nSids)
	t.counts = make([]int, t.nSids)

	t.termValues = make([]float64, len(t.ids))
	t.termInput = map[int]bool{Z1_INPUT_AG_TRADE: true}
}

func (t *Z1_AgTrd5) TermInput() map[int]bool {
	return t.termInput
}

func (t *Z1_AgTrd5) TermUpdate(sid int, epoch float64, inputType int, n int, data []float64) {
	if !inTrading(epoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	cursor := t.cursors[idx]
	buyNotls := t.hisBuyNotl[idx]
	sellNotls := t.hisSellNotl[idx]
	buySignals := t.buySignals[idx]
	sellSignals := t.sellSignals[idx]

	buyNotls[cursor] = 0.0
	sellNotls[cursor] = 0.0

	for i := 0; i < 2; i++ {
		s := 3 * i
		if data[s] > 0 {
			if data[s+2] > 0 {
				buyNotls[cursor] += data[s] * data[s+1]
			} else if data[s+2] < 0 {
				sellNotls[cursor] += data[s] * data[s+1]
			}
		}
	}

	count := t.counts[idx] + 1
	t.counts[idx] = count

	secsSinceTrade := secsSinceTrade(epoch)
	for i := range t.ids {
		beginTick := cursor
		backTick := t.backTicks[i]

		if count < backTick {
			continue
		}

		hisALine := t.hisALine[:0]
		hisBLine := t.hisBLine[:0]

		hisALine = append(hisALine, sellNotls[cursor])
		hisBLine = append(hisBLine, buyNotls[cursor])

		buySignal := buySignals[i]
		sellSignal := sellSignals[i]

		for j := 1; j <= backTick; j++ {
			backIdx := (beginTick - j + 50) % 50
			hisALine = append(hisALine, sellNotls[backIdx])
			hisBLine = append(hisBLine, buyNotls[backIdx])
		}

		aValue := 0.0
		n := len(hisALine)
		if n > 1 {
			splitNum := n / 2
			m1 := 0.0
			m2 := 0.0

			for _, value := range hisALine[:splitNum] {
				m1 += value
			}
			for _, value := range hisALine[splitNum:] {
				m2 += value
			}
			if m1 < m2 {
				aValue = math.Min(naInf2Zero(m2/m1), 1)
			}
		}

		bValue := 0.0
		n = len(hisBLine)
		if n > 1 {
			splitNum := n / 2
			m1 := 0.0
			m2 := 0.0

			for _, value := range hisBLine[:splitNum] {
				m1 += value
			}
			for _, value := range hisBLine[splitNum:] {
				m2 += value
			}
			if m1 < m2 {
				bValue = math.Min(naInf2Zero(m2/m1), 1)
			}
		}

		buySignal.update(secsSinceTrade, bValue)
		sellSignal.update(secsSinceTrade, aValue)
	}

	t.cursors[idx] = (cursor + 1) % 50
}

// snap
func (t *Z1_AgTrd5) GetSidValues(sid int, mPrice, secEpoch float64) (res []float64, err error) {
	for i := range t.ids {
		t.termValues[i] = 0
	}
	res = t.termValues
	err = nil

	if !inTrading(secEpoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	secsSinceTrade := secsSinceTrade(secEpoch)
	buySignals := t.buySignals[idx]
	sellSignals := t.sellSignals[idx]
	for i := range t.ids {
		res[i] = naInf2Zero(sellSignals[i].getEms(secsSinceTrade) - buySignals[i].getEms(secsSinceTrade))
	}

	return
}
