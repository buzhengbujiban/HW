// 20200308, yzhu, EquitySampler2 based on SamplerCore

package feature

import (
	"autosupply/bookmsg"
	"autosupply/model"
	"fmt"
	"log"
	"math"
	"strconv"
	"time"

	"TES/QR/alpha_ov/data"
	"TES/tesUtilsGo/common"

	hastats "TES/QR/hastats/model"

	"TES/QR/alpha_ov/feature/idxfut"
	"TES/QR/alpha_ov/feature/zigzag"

	tu "TES/tesUtilsGo"
)

// helper functions
func beginTimestampEq(dateStr string) float64 {
	secondsEastOfUTC := int((8 * time.Hour).Seconds())
	beijing := time.FixedZone("Beijing Time", secondsEastOfUTC)
	date2MinuteStr := fmt.Sprintf("%s0930", dateStr)
	t, _ := time.ParseInLocation("200601021504", date2MinuteStr, beijing)
	return float64(t.Unix())
}

type GroupMap struct {
	dateStr string
	sidList *SidListInfo

	G1Map map[int]int   // sid -> g1 id
	G2Map map[int][]int // sid -> g2 id list
}

func NewGroupMap(dateStr string, sidList []int, useSwIndustry bool, predefinedConceptFile string) *GroupMap {
	gm := new(GroupMap)
	gm.dateStr = dateStr
	gm.sidList = NewSidListInfoWithGidList(dateStr, sidList)
	gm.loadG1(useSwIndustry)
	gm.loadG2(predefinedConceptFile)
	return gm
}

func (gm *GroupMap) loadG1(useSwIndustry bool) {
	// G1 is for one-group-per-sid mapping, e.g. industry group
	var industryInfoMap map[int][]common.EqIndustryInfo

	if useSwIndustry {
		industryInfoMap = common.EqIndustryInfoMap
		tu.Logger.Info(fmt.Sprintf("EquitySampler.loadIndustryCodes: Use SW2 industry in EquitySampler (ov25 is the first user)\n"))
	} else {
		industryInfoMap = common.EqIndustryL1InfoMap
		tu.Logger.Info(fmt.Sprintf("EquitySampler.loadIndustryCodes: Use L1 industry in EquitySampler\n"))
	}

	// print out a bit of industry info
	printCnt := 0
	for sid, iinfo := range industryInfoMap {
		tu.Logger.Info(fmt.Sprintf("industry info sid=%d info=%v", sid, iinfo))
		printCnt++
		if printCnt == 3 {
			break
		}
	}

	dateInt, _ := strconv.Atoi(gm.dateStr)

	gm.G1Map = make(map[int]int)
	industry2id := make(map[int]int)
	iid := 0
	for _, sid := range gm.sidList.sidList {
		records := industryInfoMap[sid]
		for _, record := range records {
			if record.StartDate <= dateInt {
				if id, ok := industry2id[record.IndustryCode]; ok {
					gm.G1Map[sid] = id
				} else {
					gm.G1Map[sid] = iid
					industry2id[record.IndustryCode] = iid
					iid++
				}
				break
			}
		}
	}
}

func (gm *GroupMap) loadG2(predefinedConceptFile string) {
	// G2 is for many-groups-per-sid mapping, e.g. concept group
	dateInt, _ := strconv.Atoi(gm.dateStr)
	gm.G2Map = make(map[int][]int)
	concept2id := make(map[string]int)
	cid := 0
	//conceptfiltered := GetPredefinedConcept("/data/nas4Data/chinaEquityData/xixian/adj/concept_name_map_sort_pick2.tbl")
	conceptfiltered := GetPredefinedConcept(predefinedConceptFile)
	for _, sid := range gm.sidList.sidList {
		conceptStrs := common.ConceptsLookupBySid(sid, dateInt)
		for _, conceptStr := range conceptStrs {
			if !HasConcept(conceptStr, conceptfiltered) {
				continue
			}
			if id, ok := concept2id[conceptStr]; ok {
				gm.G2Map[sid] = append(gm.G2Map[sid], id)
			} else {
				gm.G2Map[sid] = append(gm.G2Map[sid], cid)
				concept2id[conceptStr] = cid
				cid++
			}
		}
	}
}

type EquityStats struct {
	dateStr string
	sidList *SidListInfo

	tickSize map[int]float64
	groupWgt map[int]float64
	regWgt   map[int]float64

	prevDayAvgSize    map[int]float64
	prevDayVolatility map[int]float64
	prevDayVolume     map[int]float64
	prevDayTurnover   map[int]float64
	prevDayBuyVolume  map[int]float64
	prevDaySellVolume map[int]float64

	prevMinuteAvgSize   *data.MinuteTable
	prevMinuteAvgSize01 *data.MinuteTable
	prevMinuteAvgSize99 *data.MinuteTable
	prevMinuteTurnover  *data.MinuteTable
	prevMinuteVolume    *data.MinuteTable
}

func NewEquityStats(dateStr string, sidList []int, weightMethod string) *EquityStats {
	stats := new(EquityStats)
	stats.dateStr = dateStr
	stats.sidList = NewSidListInfoWithGidList(dateStr, sidList)

	stats.loadDailyRollStats()
	stats.loadMinutesRollStats()
	stats.loadIndexWeight(weightMethod)

	return stats
}

func (stats *EquityStats) loadMinutesRollStats() {
	prevdate := common.EquityPrevBusdateRemoveMissingDates(stats.dateStr)
	stats.prevMinuteAvgSize = data.GetMinuteTableFromPanelData("minute-rollstats", prevdate, "topsize50.rw22")
	stats.prevMinuteAvgSize01 = data.GetMinuteTableFromPanelData("minute-rollstats", prevdate, "topsize01.rw22")
	stats.prevMinuteAvgSize99 = data.GetMinuteTableFromPanelData("minute-rollstats", prevdate, "topsize99.rw22")
	stats.prevMinuteTurnover = data.GetMinuteTableFromPanelData("minute-rollstats", prevdate, "turnover.rw22")
	stats.prevMinuteVolume = data.GetMinuteTableFromPanelData("minute-rollstats", prevdate, "volume.rw22")
}

func (stats *EquityStats) loadDailyRollStats() {
	stats.prevDayAvgSize = make(map[int]float64)
	stats.prevDayVolatility = make(map[int]float64)
	stats.prevDayVolume = make(map[int]float64)
	stats.prevDayTurnover = make(map[int]float64)
	stats.prevDayBuyVolume = make(map[int]float64)
	stats.prevDaySellVolume = make(map[int]float64)

	prevdate := common.PreTradeDate(stats.dateStr)

	stats.prevDayAvgSize = data.GetSidValueMapFromPanelData("daily-rollstats", prevdate, "00:00:00", "avg_top_size.rw22")
	stats.prevDayAvgSize = data.ConformSidValueMap(stats.prevDayAvgSize, stats.sidList.sidList, 0.0)

	stats.prevDayVolatility = data.GetSidValueMapFromPanelData("daily-rollstats", prevdate, "00:00:00", "variance.rw22")
	stats.prevDayVolatility = data.ConformSidValueMap(stats.prevDayVolatility, stats.sidList.sidList, 0.0)

	stats.prevDayVolume = data.GetSidValueMapFromPanelData("daily-rollstats", prevdate, "00:00:00", "volume.rw22")
	stats.prevDayVolume = data.ConformSidValueMap(stats.prevDayVolume, stats.sidList.sidList, 0.0)

	stats.prevDayTurnover = data.GetSidValueMapFromPanelData("daily-rollstats", prevdate, "00:00:00", "turnover.rw22")
	stats.prevDayTurnover = data.ConformSidValueMap(stats.prevDayTurnover, stats.sidList.sidList, 0.0)

	stats.prevDayBuyVolume = data.GetSidValueMapFromPanelData("daily-rollstats", prevdate, "00:00:00", "buy_volume.rw22")
	stats.prevDayBuyVolume = data.ConformSidValueMap(stats.prevDayBuyVolume, stats.sidList.sidList, 0.0)

	stats.prevDaySellVolume = data.GetSidValueMapFromPanelData("daily-rollstats", prevdate, "00:00:00", "sell_volume.rw22")
	stats.prevDaySellVolume = data.ConformSidValueMap(stats.prevDaySellVolume, stats.sidList.sidList, 0.0)
}

func (stats *EquityStats) loadIndexWeight(weightMethod string) {
	dateInt, _ := strconv.Atoi(stats.dateStr)

	var wgt300, wgt500 []common.EqIndexWeights
	wgt300, _ = common.HS300IndexWeightMap[dateInt]
	wgt500, _ = common.ZZ500IndexWeightMap[dateInt]

	stats.groupWgt = make(map[int]float64)
	stats.regWgt = make(map[int]float64)

	if weightMethod != "index" && weightMethod != "onetwo" {
		panic(fmt.Sprintf("Unknown weight method: %s", weightMethod))
	}

	if weightMethod == "onetwo" {
		for _, sid := range stats.sidList.sidList {
			found := false
			// find in hs300
			for _, record := range wgt300 {
				if sid == record.SID {
					stats.regWgt[sid] = 2.0
					stats.groupWgt[sid] = 2.0
					found = true
					break
				}
			}
			if !found {
				// find in zz500
				for _, record := range wgt500 {
					if sid == record.SID {
						stats.regWgt[sid] = 2.0
						stats.groupWgt[sid] = 2.0
						found = true
						break
					}
				}
			}
			// not 300/500
			if !found {
				stats.regWgt[sid] = 1.0
				stats.groupWgt[sid] = 1.0
			}
		}
	}

	if weightMethod == "index" {
		pdate := common.EquityPrevBusdateRemoveMissingDates(stats.dateStr)
		sid2freemv := data.GetSidValueMapFromPanelData("cap", pdate, "00:00:00", "free.mv")
		sid2freemv = data.ConformSidValueMap(sid2freemv, stats.sidList.sidList, 0)

		// find min and sum of free mv
		minValue := 1e15
		sum := 0.0
		for _, value := range sid2freemv {
			if value > 0 && value < minValue {
				minValue = value
			}
			sum += value
		}
		// assign index weight
		for sid, value := range sid2freemv {
			if value > 0 {
				stats.groupWgt[sid] = value / sum
			} else {
				stats.groupWgt[sid] = minValue / sum
			}
		}

		// regWgt (use hs300 and zz500 index weight as weight)
		defaultRegWgt := 0.0
		for _, record := range wgt500 {
			defaultRegWgt += record.Weight
		}
		defaultRegWgt = defaultRegWgt / float64(len(wgt500)) / 3 // 1/3 of the mean zz500 weight seems reasonable

		for _, sid := range stats.sidList.sidList {
			found := false
			// find in hs300
			for _, record := range wgt300 {
				if sid == record.SID {
					stats.regWgt[sid] = record.Weight
					found = true
					break
				}
			}
			if !found {
				// find in zz500
				for _, record := range wgt500 {
					if sid == record.SID {
						stats.regWgt[sid] = record.Weight
						found = true
						break
					}
				}
			}
			// still not found, use default regwgt
			if !found {
				stats.regWgt[sid] = defaultRegWgt
			}
		}
	}
}

type EquitySampler2 struct {
	*SamplerCore

	// Equity-specific cfgs
	weightMethod           string
	samplingEndTime        int64
	numLevels              int
	smoothPriceBaseFeature string
	doSnapRetThresMode     int

	predefinedConceptFile string
	useSwIndustry         bool

	// Stats Object
	stat     *EquityStats
	groupMap *GroupMap

	// Denoiser and Normalizer (similar to stats)
	levelSizer *LevelSizer
	tradeSizer *TradeSizer

	// Index Futs
	futIR         *FutIR
	idxFutfeature *idxfut.IdxFutFeatures

	// Dragon/ZigZag
	zigZag300S *zigzag.ZigZag
	zigZag300L *zigzag.ZigZag
	zigZag500S *zigzag.ZigZag
	zigZag500L *zigzag.ZigZag

	zzS []*zigzag.ZigZag
	zzL []*zigzag.ZigZag

	// FLB -> Old Slice Converter
	bookSlice *data.TesTOBSliceWrapper

	// forAll values
	secMorning float64
	inTrading  data.TradingSessionInfo

	// perSid values
	tickSize     []float64
	flbBook      []*data.FixedLevelBook
	seenDayEvent []bool

	// perSid hastats
	trdAgg               []*hastats.TradeAggregator
	passiveOrderTimeSpan []*hastats.OrderLifeSpanStat

	// extra snap logic
	validSnapshotCountsSinceLastSnap []int64
	sampleWeightFlag                 int
	limitRet                         []float64

	// temp state vars
	tmpSlice               []float64
	tmpPrcQtySlice         []data.PriceQty    // static and no resize
	tmpPrcQtySlice2        []data.PriceQty    // resize every time
	tmpPrcQtySlice3        []data.PriceQty    // resize every time
	tmpPrcQtySlice4        []data.PriceQty    // resize every time
	tmpPrcQtySlice5        []data.PriceQty    // resize every time
	tmpPrcQtySlice6        []data.PriceQty    // resize every time
	tmpPrcQtySlice7        []data.PriceQty    // resize every time
	tmpPrcQtySlice8        []data.PriceQty    // resize every time
	tmpPrcQtySlice9        []data.PriceQty    // resize every time
	tmpPrcQtyTagSlice5     []data.PriceQtyTag // resize every time
	tmpPrcQtyTagSlice6     []data.PriceQtyTag
	tmpPrcQtyOidTagSlice10 []data.PriceQtyOidTag
	extraInfo              map[int][]float64

	z1_data1         []float64
	z1_data2         []float64
	z1_data3         []float64
	lastSnapshotData map[int][]float64

	lastSnapshotDataT map[int][]float64

	t_data []float64

	mx_data               []float64
	last_mx_data_all_sids map[int][]float64
	CPManager
}

func NewEquitySampler2(dateStr string, prefsFileName string, alphaMode bool) *EquitySampler2 {
	spl := new(EquitySampler2)

	// Create SamplerCore
	spl.SamplerCore = NewSamplerCore(dateStr, prefsFileName, alphaMode)

	spl.loadSpecificPrefs()

	// forAll values
	spl.secMorning = beginTimestampEq(spl.dateStr)

	// perSid values
	spl.tickSize = make([]float64, spl.fullSid.Size())
	for i, sid := range spl.fullSid.sidList {
		if info, ok := common.SecMasterMap[sid]; ok {
			spl.tickSize[i] = info.TickSize
		} else {
			spl.tickSize[i] = 0.01 // for some sids, such as index, no ticksize info loaded
		}
	}
	spl.seenDayEvent = make([]bool, spl.fullSid.Size())

	spl.validSnapshotCountsSinceLastSnap = make([]int64, spl.fullSid.Size())
	spl.limitRet = make([]float64, spl.fullSid.Size())
	for i, sid := range spl.fullSid.sidList {
		limitType := 0
		if spl.snapSid.ContainsSid(sid) {
			// this function will crash if a non equity sid is called
			limitType = common.GetSidPriceLimitThresholdType(sid, spl.dateStr)
		}
		switch limitType {
		case 5:
			spl.limitRet[i] = 0.05
		case 10:
			spl.limitRet[i] = 0.10
		case 20:
			spl.limitRet[i] = 0.20
		default:
			spl.limitRet[i] = 0
		}
	}

	spl.flbBook = make([]*data.FixedLevelBook, spl.fullSid.Size())
	for i, rawsid := range spl.fullSid.rawsidList {
		spl.flbBook[i] = data.NewFixedLevelBook(rawsid, spl.numLevels, 0)
	}

	// perSid hastats
	spl.trdAgg = make([]*hastats.TradeAggregator, spl.fullSid.Size())
	for i := range spl.fullSid.sidList {
		spl.trdAgg[i] = hastats.NewTradeAggregator()
	}
	spl.passiveOrderTimeSpan = make([]*hastats.OrderLifeSpanStat, spl.fullSid.Size())
	for i := range spl.fullSid.sidList {
		spl.passiveOrderTimeSpan[i] = hastats.NewOrderLifeSpanStat(spl.dateStr)
	}

	// FLBEndBatchMsg -> TESDOBSlice converter
	spl.bookSlice = data.NewTesTOBSliceWrapper(data.ChinaEquity, spl.numLevels)
	spl.bookSlice.Datestr = spl.dateStr // hack for equity slice

	// set dynamic functions
	spl.setSessionFunc()
	spl.setWgtFunc()

	// load stats
	spl.stat = NewEquityStats(spl.dateStr, spl.snapSid.sidList, spl.weightMethod)
	spl.groupMap = NewGroupMap(spl.dateStr, spl.snapSid.sidList, spl.useSwIndustry, spl.predefinedConceptFile)

	// book & tade sizer
	spl.levelSizer = NewLevelSizer(spl.dateStr)
	spl.tradeSizer = NewTradeSizer(spl.dateStr)

	// Set G1 and G2 group mapping to features
	for _, fn := range spl.featureNameList {
		spl.featureDict[fn].SetIndustryAndConcept(spl.groupMap.G1Map, spl.groupMap.G2Map)
		spl.featureDict[fn].SetWeight(spl.stat.groupWgt)
		// NOTE: this is the second time to call initInternalVars() method
		//       because the first time does not init weight/industry/concept
		if fn == "MX-ASR" || fn == "MX-ATR" || fn == "MX-BSD" || fn == "MX-BSN" || fn == "MX-DPO" ||
			fn == "MX-ENP" || fn == "MX-ICK" || fn == "MX-KAMA" || fn == "MX-MACD" ||
			fn == "MX-MRET" || fn == "MX-MSI" || fn == "MX-MVOL" || fn == "MX-PCG" || fn == "MX-PDT" ||
			fn == "MX-VPC" || fn == "MX-RCE" || fn == "MX-TRD" || fn == "MX-TNOP" || fn == "MX-UCR" || fn == "MX-VTR" || fn == "MX-VPT" || fn == "MX-VWP" ||
			fn == "E-7" || fn == "E-7L1" || fn == "E-7L2" || fn == "E-8" {
			// pass, don't do the twice initIntervalVars for MX!
		} else {
			spl.featureDict[fn].initInternalVars()
		}
	}

	// check if we use index futs
	if spl.featureDict["IRIF"] == nil && spl.featureDict["IRIC"] == nil {
		spl.futIR = nil
	} else {
		spl.futIR = NewFutIR(spl.dateStr)
	}

	if spl.featureDict["IFF"] == nil {
		spl.idxFutfeature = nil
	} else {
		spl.idxFutfeature = idxfut.NewIdxFutFeatures(spl.dateStr)
	}

	// zigzag
	prevdate := common.PreTradeDate(spl.dateStr)
	stds := zigzag.GetDailyStd(prevdate)
	// zigzag hs300
	rho300S := zigzag.RhoCalc(stds[data.SidCSI300], zigzag.ZigZagFreq10s)
	rho300L := zigzag.RhoCalc(stds[data.SidCSI300], zigzag.ZigZagFreq1m)
	spl.zigZag300S = zigzag.NewZigZag(spl.dateStr, rho300S, zigzag.ZigZagFreq10s, 0)
	spl.zigZag300L = zigzag.NewZigZag(spl.dateStr, rho300L, zigzag.ZigZagFreq1m, 0)
	// zigzag zz500
	rho500S := zigzag.RhoCalc(stds[data.SidCSI500], zigzag.ZigZagFreq10s)
	rho500L := zigzag.RhoCalc(stds[data.SidCSI500], zigzag.ZigZagFreq1m)
	spl.zigZag500S = zigzag.NewZigZag(spl.dateStr, rho500S, zigzag.ZigZagFreq10s, 0)
	spl.zigZag500L = zigzag.NewZigZag(spl.dateStr, rho500L, zigzag.ZigZagFreq1m, 0)

	spl.zzS = make([]*zigzag.ZigZag, spl.fullSid.Size())
	spl.zzL = make([]*zigzag.ZigZag, spl.fullSid.Size())
	for i, sid := range spl.fullSid.sidList {
		rhoShort := zigzag.RhoCalc(stds[sid], zigzag.ZigZagFreq10s)
		rhoLong := zigzag.RhoCalc(stds[sid], zigzag.ZigZagFreq1m)
		spl.zzS[i] = zigzag.NewZigZag(spl.dateStr, rhoShort, zigzag.ZigZagFreq10s, 0)
		spl.zzL[i] = zigzag.NewZigZag(spl.dateStr, rhoLong, zigzag.ZigZagFreq1m, 0)
	}

	// init temp variables
	spl.tmpSlice = make([]float64, 25)
	spl.tmpPrcQtySlice = make([]data.PriceQty, 25)
	spl.tmpPrcQtySlice2 = make([]data.PriceQty, 500)
	spl.tmpPrcQtySlice3 = make([]data.PriceQty, 500)
	spl.tmpPrcQtySlice4 = make([]data.PriceQty, 500)
	spl.tmpPrcQtySlice5 = make([]data.PriceQty, 500)
	spl.tmpPrcQtySlice6 = make([]data.PriceQty, 500)
	spl.tmpPrcQtySlice7 = make([]data.PriceQty, 500)
	spl.tmpPrcQtySlice8 = make([]data.PriceQty, 500)
	spl.tmpPrcQtySlice9 = make([]data.PriceQty, 500)
	spl.tmpPrcQtyTagSlice5 = make([]data.PriceQtyTag, 500)
	spl.tmpPrcQtyTagSlice6 = make([]data.PriceQtyTag, 500)
	spl.tmpPrcQtyOidTagSlice10 = make([]data.PriceQtyOidTag, 500)
	spl.extraInfo = make(map[int][]float64)

	spl.z1_data1 = make([]float64, 20)
	spl.z1_data2 = make([]float64, 43)
	spl.z1_data3 = make([]float64, 6)

	spl.lastSnapshotData = make(map[int][]float64)
	spl.lastSnapshotDataT = make(map[int][]float64)

	spl.t_data = make([]float64, 44)

	spl.mx_data = make([]float64, 100)
	spl.last_mx_data_all_sids = make(map[int][]float64)

	return spl
}

func (spl *EquitySampler2) loadSpecificPrefs() {
	spl.numLevels = spl.prefs.GetIntPref("FLB_num_levels")
	if spl.prefs.HasPref("sampling_end_time") {
		spl.samplingEndTime = spl.prefs.GetInt64Pref("sampling_end_time")
	} else {
		spl.samplingEndTime = 145630000 // 14:56:30.000
	}
	if spl.prefs.HasPref("smooth_price_base_feature") {
		spl.smoothPriceBaseFeature = spl.prefs.GetStringPref("smooth_price_base_feature")
	} else {
		spl.smoothPriceBaseFeature = ""
	}
	spl.weightMethod = spl.prefs.GetStringPref("weight_method")
	if spl.prefs.HasPref("do_snap_ret_thres_mode") {
		spl.doSnapRetThresMode = spl.prefs.GetIntPref("do_snap_ret_thres_mode")
	}

	checkPointPathRead := spl.prefs.GetStringPref("mx_checkpoint_path")
	spl.SetCheckPointPath(checkPointPathRead, "")

	if spl.prefs.HasPref("predefined_concept_file") {
		spl.predefinedConceptFile = spl.prefs.GetStringPref("predefined_concept_file")
	} else {
		spl.predefinedConceptFile = ""
	}

	spl.useSwIndustry = spl.prefs.GetBoolPref("use_sw_industry")
}

func (spl *EquitySampler2) setSessionFunc() {
	/* //old session function
	func(srcEpoch float64) int {
		if srcEpoch-spl.secMorning <= 30*60 {
			//# 9:30 - 10:00
			return 1
		} else if srcEpoch-spl.secMorning <= 60*60 {
			//# 10:00 - 10:30
			return 2
		} else if srcEpoch-spl.secMorning <= 120*60 {
			//# 10:30 - 11:30
			return 3
		} else if srcEpoch-spl.secMorning <= 270*60 {
			//# 13:00 - 14:00
			return 4
		} else {
			//# 14:00-15:00
			return 5
		}
	}
	*/

	spl.sessionFunc = func(epochSec float64) int {
		sinceOpen := epochSec - spl.secMorning
		if sinceOpen <= 30*60 {
			//# 9:30 - 10:00
			return 1
		} else if epochSec-spl.secMorning <= 120*60 {
			//# 10:00 - 11:30
			return 2
		} else if epochSec-spl.secMorning <= 300*60 {
			//# 13:00 - 14:30
			return 3
		} else {
			//# 14:30 - 15:00
			return 4
		}
	}
}

func (spl *EquitySampler2) setWgtFunc() {
	spl.wgtFunc = func(sid int) float64 {
		if spl.sampleWeightFlag != 0 {
			return spl.stat.regWgt[sid]
		} else {
			return 0.0
		}
	}
}

/* BEGIN of IMsgObserver impl  */
func (spl *EquitySampler2) Start() {
	tu.Logger.Info(fmt.Sprintf("Start of EquitySampler2\n"))
	spl.SamplerCore.start()

	if spl.futIR != nil {
		spl.futIR.Start()
	}

	// Init MX, e.g. checkpoints

	spl.CPManager.CPInit(spl.snapSid.sidList, spl.dateStr)
	ovterms := make([]ITerm, 0, 0)
	for _, term := range spl.featureDict {
		if ovterm, ok := term.(OVInterface); ok {
			spl.CPManager.CPRegisterTerm(ovterm)
			ovterms = append(ovterms, ovterm.(ITerm))
		}
	}

	spl.CPManager.CPStart(ovterms)
}

func (spl *EquitySampler2) Final() {
	tu.Logger.Info(fmt.Sprintf("Final of EquitySampler2\n"))
	spl.SamplerCore.final()

	if spl.futIR != nil {
		spl.futIR.Final()
	}

	//cxx write T checkpoint
	for _, term := range spl.featureDict {
		if Tterm, ok := term.(FeatureInterface); ok {
			Tterm.WriteCheckPoint()
		}
	}

	//cxx write MX checkpoint
}

func (spl *EquitySampler2) OnMsg(data model.IMsg) {
	spl.SamplerCore.onMsg(data)

	if spl.futIR != nil {
		spl.futIR.OnMsg(data)
	}

	switch msg := data.(type) {
	case *bookmsg.FLBEndBatchMsg:
		if spl.idxFutfeature != nil {
			spl.idxFutfeature.Update(msg)
		}
		if sid, ok := spl.fullSid.rawsid2gid[msg.Sid]; ok {
			sidIdx := spl.fullSid.sid2idx[sid]
			// Filter bad/redundant msgs

			// Update old FLB object
			slice := spl.bookSlice.FromFLBEndBatchMsg(msg)
			updateResult := spl.flbBook[sidIdx].Update(slice)
			if !updateResult {
				tu.Logger.Info(fmt.Sprintf("Bad update: problematic time or volume. %d at %.3f", sid, slice.ExTimestamp()))
				return
			}

			spl.updateFeatures(sid, sidIdx, msg)
		}
	case *bookmsg.OBTradeMsg:
		if sid, ok := spl.fullSid.rawsid2gid[msg.Sid]; ok {
			sidIdx := spl.fullSid.sid2idx[sid]

			//TODO: conditional update on these hastats
			spl.trdAgg[sidIdx].Update(msg)
			spl.passiveOrderTimeSpan[sidIdx].Update(msg)

			spl.updateMxTrade(sid, sidIdx, msg)
		}
	default:
		// no action for other msgs
	}
}

/* END of IMsgObserver impl  */

// prepare book size
func prepareBooksize(sid int, epoch float64, newMsg *bookmsg.FLBEndBatchMsg, data []float64) {
	for i := 0; i < 10; i++ {
		data[i] = newMsg.GetAsize(i)
		data[i+10] = newMsg.GetBsize(i)
	}
}

// prepare_snapshot_book!
func prepareSnapshotBook(sid int, epoch float64, newMsg *bookmsg.FLBEndBatchMsg, data []float64, data2 []float64) {
	for i := 0; i < 10; i++ {
		data[2*i] = newMsg.GetAsk(i)
		data[2*i+1] = newMsg.GetAsize(i)
	}
	for i := 10; i < 20; i++ {
		data[2*i] = newMsg.GetBid(i - 10)
		data[2*i+1] = newMsg.GetBsize(i - 10)
	}
	switch extra := newMsg.Extra.(type) {
	case *bookmsg.ChinaEquitySnapshotExtra:
		data[40] = extra.OpenPrice
		data2[43] = extra.PrevClose
	default:
		data[40] = 0
		data2[43] = math.NaN()
	}
	data[41] = newMsg.CumVol
	data[42] = newMsg.CumTo

	copy(data2[:len(data)], data)
}

func prepareAgTrade(sid int, epoch float64, newMsg *bookmsg.FLBEndBatchMsg, lastSnapshotData []float64, data []float64) {
	for i := 0; i < 6; i++ {
		data[i] = 0
	}

	if lastSnapshotData == nil {
		return
	}

	// if sid == 9 && EpochToSecsSinceMid(epoch) > 34200 {
	// 	fmt.Printf("")
	// }

	V := newMsg.CumVol - lastSnapshotData[41]
	T := newMsg.CumTo - lastSnapshotData[42]

	if V <= 0 {
		return
	}

	p := T / V
	tickSize := 0.01
	upperPrc := math.Ceil((p-1e-9)/tickSize) * tickSize
	p2 := upperPrc
	lowerPrc := math.Floor((p+1e-9)/tickSize) * tickSize
	p1 := lowerPrc

	upperDiff := math.MaxFloat64
	lowerDiff := math.MaxFloat64

	for i := 0; i < 2; i++ {
		askPrc := lastSnapshotData[2*i]
		bidPrc := lastSnapshotData[20+2*i]

		if askPrc >= upperPrc && (askPrc-upperPrc) < upperDiff {
			upperDiff = askPrc - upperPrc
			p2 = askPrc
		}
		if bidPrc >= upperPrc && bidPrc-upperPrc < upperDiff {
			upperDiff = bidPrc - upperPrc
			p2 = bidPrc
		}

		if askPrc <= lowerPrc && lowerPrc-askPrc < lowerDiff {
			lowerDiff = lowerPrc - askPrc
			p1 = askPrc
		}
		if bidPrc <= lowerPrc && lowerPrc-bidPrc < lowerDiff {
			lowerDiff = lowerPrc - bidPrc
			p1 = bidPrc
		}
	}
	lastMidPrc := midPrc(lastSnapshotData[0], lastSnapshotData[20])
	spread := p2 - p1
	get_trade_dir := func(tradePrc float64, lastMidPrc float64) float64 {
		if tradePrc > lastMidPrc {
			return 1.0
		} else if tradePrc < lastMidPrc {
			return -1.0
		} else {
			return 0.0
		}
	}
	if math.Abs(spread) < 1e-9 {
		data[0] = p1
		data[1] = V
		data[2] = get_trade_dir(p1, lastMidPrc)
	} else {
		s1 := math.Trunc((p2*V - T) / spread)
		s2 := math.Trunc((T - p1*V) / spread)
		data[0] = p1
		data[1] = s1
		data[2] = get_trade_dir(p1, lastMidPrc)
		data[3] = p2
		data[4] = s2
		data[5] = get_trade_dir(p2, lastMidPrc)
	}
}

func (spl *EquitySampler2) extraSnapCheck(sid int) bool {
	doSnap := true
	spl.sampleWeightFlag = 1

	if spl.doSnapRetThresMode == 0 {
		// doSnap = true
	} else if spl.doSnapRetThresMode == 1 || spl.doSnapRetThresMode == 2 {
		sidIdx := spl.fullSid.sid2idx[sid]
		book := spl.flbBook[sidIdx]
		// MODE=1: Filter out near limit up/down cases
		// MODE=2: Still snap samples, however set weight as 0
		retSinceYestday := book.GetMidPrice()/book.PrevClose - 1.0
		thres85 := spl.limitRet[sidIdx] * 0.85
		if math.Abs(retSinceYestday) <= thres85 && book.GetAskPrice() > 0 && book.GetBidPrice() > 0 && book.GetAskSize() > 0 && book.GetBidSize() > 0 {
			// doSnap = true
		} else {
			if spl.doSnapRetThresMode == 1 {
				doSnap = false
			} else {
				// MODE=2
				spl.sampleWeightFlag = 0
			}
		}
	} else {
		panic(fmt.Sprintf("do snap ret thres mode %d not implemented", spl.doSnapRetThresMode))
	}

	return doSnap
}

func (spl *EquitySampler2) updateFeatures(sid int, sidIdx int, endBatch *bookmsg.FLBEndBatchMsg) {
	book := spl.flbBook[sidIdx]
	spl.inTrading = book.IsInTrading()

	if !spl.inTrading.InTrading {
		// if not in trading (e.g. during AM auction), we get and clean the trades
		// so that auction trades do not go to alpha calculations
		trdAgg := spl.trdAgg[sidIdx]
		trdAgg.GetTradesByOrder()
		return
	}

	// SESSION 1. Update as long as InTrading [FwdStats]
	spl.updateFeaturesSession1(sid, sidIdx, book)

	// the rest sessions only run before sampleingEndTime
	if book.ExTimeInt > spl.samplingEndTime {
		return
	}

	// SESSION 2. Update InTrading & before sampling end [A01ST and ZigZag keepers]
	spl.updateFeaturesSession2(sid, sidIdx, book, endBatch)

	// SESSION 3. Update on specific events [All other features]
	spl.updateFeaturesSession3(sid, sidIdx, book, endBatch)

	// count valid books
	if book.GetAskPrice() > 0 && book.GetBidPrice() > 0 && book.GetAskSize() > 0 && book.GetBidSize() > 0 {
		spl.validSnapshotCountsSinceLastSnap[sidIdx]++
	}

	adjRecEpoch := common.SubtractBreakSeconds(book.RecSecSinceEpoch, spl.secMorning, book.EID)

	// clear snapSid queue on every update
	if len(spl.SamplerCore.snapSidsQueue) > 0 {
		spl.SamplerCore.snapSidsQueue = spl.SamplerCore.snapSidsQueue[:0]
	}

	check1 := spl.extraSnapCheck(sid) // specific check for EqSampler
	check2 := spl.snapCheck(sid)      // general check for CoreSampler
	//fmt.Printf("SNAP %v %v\n", check1, check2)
	if check1 && check2 {
		spl.snapFeatures(sid, book.RecSecSinceEpoch, book.ExTimestamp, book.GetMidPrice(), adjRecEpoch)
		if spl.SamplerCore.snapOnlyAtTimeIntervalEventsAndSnapAllAtOnce {
			spl.SamplerCore.snapSidsQueue = append(spl.SamplerCore.snapSidsQueue, sid)
		}
	}

	if spl.SamplerCore.snapOnlyAtTimeIntervalEventsAndSnapAllAtOnce {
		for _, sid0 := range spl.SamplerCore.snapSid.sidList {
			if sid0 != sid {
				sid0Idx := spl.fullSid.sid2idx[sid0]
				checka := spl.extraSnapCheck(sid0)
				checkb := spl.snapCheck(sid0)
				book0 := spl.flbBook[sid0Idx]
				adjRecEpoch0 := common.SubtractBreakSeconds(book0.RecSecSinceEpoch, spl.secMorning, book0.EID)
				//                     >=3 valid snapshots since last snap
				if checka && checkb && spl.validSnapshotCountsSinceLastSnap[sid0Idx] >= 3 {
					//spl.snapFeatures(sid0, book.RecSecSinceEpoch, book.ExTimestamp, book.GetMidPrice(), adjRecEpoch)
					spl.snapFeatures(sid0, book.RecSecSinceEpoch, book0.ExTimestamp, book0.GetMidPrice(), adjRecEpoch0)
					spl.validSnapshotCountsSinceLastSnap[sid0Idx] = 0
					spl.SamplerCore.snapSidsQueue = append(spl.SamplerCore.snapSidsQueue, sid0)
				}
			}
		}
	}
}

func (spl *EquitySampler2) updateFeaturesSession1(sid int, sidIdx int, book *data.FixedLevelBook) {
	if feature, ok := spl.featureDict["FWDRET"]; ok {
		mid := book.GetMidPrice()
		adj_src_epoch := common.SubtractBreakSeconds(book.ExTimestamp, spl.secMorning, book.EID)
		feature.UpdateSecValue(sid, adj_src_epoch, mid)
	}
	if feature, ok := spl.featureDict["FWDMRET"]; ok {
		var price float64
		if sid == data.SidCSI300 || sid == data.SidCSI500 {
			price = book.GetLastPrice()
		} else {
			price = book.GetMidPrice()
		}
		adj_src_epoch := common.SubtractBreakSeconds(book.ExTimestamp, spl.secMorning, book.EID)
		feature.UpdateSecValue(sid, adj_src_epoch, price)
	}
	if feature, ok := spl.featureDict["OVFWDRET"]; ok {
		var price float64
		if sid == data.SidCSI300 || sid == data.SidCSI500 {
			price = book.GetLastPrice()
		} else {
			price = book.GetMidPrice()
		}
		feature.UpdateSecValue(sid, book.ExTimestamp, price)
	}
	if feature, ok := spl.featureDict["BOOKST"]; ok {
		if len(spl.tmpSlice) < 5 {
			spl.tmpSlice = make([]float64, 5)
		}
		spl.tmpSlice[0] = book.GetAskPrice()
		spl.tmpSlice[1] = book.GetBidPrice()
		spl.tmpSlice[2] = book.GetAskSize()
		spl.tmpSlice[3] = book.GetBidSize()
		spl.tmpSlice[4] = book.CumVol
		feature.UpdateValueSlice(sid, spl.tmpSlice[:5])
	}
}

func (spl *EquitySampler2) updateFeaturesSession2(sid int, sidIdx int, book *data.FixedLevelBook, endBatch *bookmsg.FLBEndBatchMsg) {
	if feature, ok := spl.featureDict["A01ST"]; ok {
		if len(spl.tmpSlice) < 4 {
			spl.tmpSlice = make([]float64, 4)
		}
		spl.tmpSlice[0] = float64(book.ExTimeInt)
		spl.tmpSlice[1] = book.GetCumTo()
		spl.tmpSlice[2] = book.GetLastPrice()
		spl.tmpSlice[3] = book.GetTopSize()
		spl.tmpSlice[4] = book.PrevClose

		feature.UpdateValueSlice(sid, spl.tmpSlice[:5])
	}

	// Update ZigZag
	if sid == data.SidCSI300 {
		spl.zigZag300S.UpdateTimeAndPrice(book.ExTimestamp, book.GetLastPrice())
		spl.zigZag300L.UpdateTimeAndPrice(book.ExTimestamp, book.GetLastPrice())
	} else if sid == data.SidCSI500 {
		spl.zigZag500S.UpdateTimeAndPrice(book.ExTimestamp, book.GetLastPrice())
		spl.zigZag500L.UpdateTimeAndPrice(book.ExTimestamp, book.GetLastPrice())
	} else {
		spl.zzS[sidIdx].UpdateTimeAndPrice(book.ExTimestamp, book.GetLastPrice())
		spl.zzL[sidIdx].UpdateTimeAndPrice(book.ExTimestamp, book.GetLastPrice())
	}

	// Alpha MX Updates
	newMsg := *endBatch
	epoch := newMsg.OurEpoch

	if sid == data.SidCSI300 || sid == data.SidCSI500 {
		IndexToBuf(newMsg, spl.mx_data)
		if feature, ok := spl.featureDict["MX-MRET"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_INDEX, INPUT_MSG_INDEX_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-MVOL"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_INDEX, INPUT_MSG_INDEX_N, spl.mx_data)
		}
	} else {
		if extra, ok := newMsg.Extra.(*bookmsg.ChinaEquitySnapshotExtra); ok {
			//m.TermUpdateCorpAction(sid, epoch, extra)
			TermUpdateCorpAction := func(sid int, epoch float64, extra *bookmsg.ChinaEquitySnapshotExtra) {
				if CA.IsBootstrapFinished() {
					return
				}

				if hasUpdate := CA.UpdateSnapshotPrevClose(sid, extra.PrevClose, epoch); hasUpdate {
					for _, term := range spl.featureDict {
						if requireCA, ok := term.(CorpActioner); ok {
							requireCA.OnCorpActionLoaded(sid, epoch)
						}
					}
				}

				if CA.IsBootstrapFinished() {
					log.Println("AlphaManager CorpAction bootstrap finished")
				}

			}

			TermUpdateCorpAction(sid, epoch, extra)
		}

		FLBToBuf(newMsg, spl.mx_data, spl.last_mx_data_all_sids)
		if spl.last_mx_data_all_sids[sid] == nil {
			spl.last_mx_data_all_sids[sid] = make([]float64, len(spl.mx_data))
		}
		copy(spl.last_mx_data_all_sids[sid], spl.mx_data)

		if feature, ok := spl.featureDict["MX-ASR"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-ATR"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-DPO"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-ENP"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-ICK"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-KAMA"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-MACD"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}

		if feature, ok := spl.featureDict["MX-MRET"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-MSI"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-MVOL"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}

		if feature, ok := spl.featureDict["MX-PCG"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-PDT"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-VPC"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-RCE"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-TRD"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-TNOP"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-UCR"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["MX-VPT"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["E-7"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["E-7L1"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["E-7L2"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
		if feature, ok := spl.featureDict["E-8"]; ok {
			feature.TermUpdate(sid, epoch, INPUT_MSG_TOB, INPUT_MSG_TOB_N, spl.mx_data)
		}
	}
}

func (spl *EquitySampler2) updateMxTrade(sid int, sidIdx int, trade *bookmsg.OBTradeMsg) {
	epoch := trade.OurEpoch
	TradeToBuf(*trade, spl.mx_data)

	if feature, ok := spl.featureDict["MX-ASR"]; ok {
		feature.TermUpdate(sid, epoch, INPUT_MSG_TRADE, INPUT_MSG_TRADE_N, spl.mx_data)
	}
	if feature, ok := spl.featureDict["MX-ATR"]; ok {
		feature.TermUpdate(sid, epoch, INPUT_MSG_TRADE, INPUT_MSG_TRADE_N, spl.mx_data)
	}
	if feature, ok := spl.featureDict["MX-BSD"]; ok {
		feature.TermUpdate(sid, epoch, INPUT_MSG_TRADE, INPUT_MSG_TRADE_N, spl.mx_data)
	}
	if feature, ok := spl.featureDict["MX-BSN"]; ok {
		feature.TermUpdate(sid, epoch, INPUT_MSG_TRADE, INPUT_MSG_TRADE_N, spl.mx_data)
	}

	if feature, ok := spl.featureDict["MX-VPC"]; ok {
		feature.TermUpdate(sid, epoch, INPUT_MSG_TRADE, INPUT_MSG_TRADE_N, spl.mx_data)
	}
	if feature, ok := spl.featureDict["MX-VPT"]; ok {
		feature.TermUpdate(sid, epoch, INPUT_MSG_TRADE, INPUT_MSG_TRADE_N, spl.mx_data)
	}
	if feature, ok := spl.featureDict["MX-VWP"]; ok {
		feature.TermUpdate(sid, epoch, INPUT_MSG_TRADE, INPUT_MSG_TRADE_N, spl.mx_data)
	}
}

func (spl *EquitySampler2) updateFeaturesSession3(sid int, sidIdx int, book *data.FixedLevelBook, endBatch *bookmsg.FLBEndBatchMsg) {
	//# do not update on first slice
	if book.IsFirstSlice {
		return
	}

	// Set isFirstDayEvent flag
	var isFirstDayEvent bool
	{
		if spl.inTrading.InTrading && !spl.seenDayEvent[sidIdx] {
			isFirstDayEvent = true
			spl.seenDayEvent[sidIdx] = true
		} else {
			isFirstDayEvent = false
		}
	}
	// Update Trade/Price/Quote events
	spl.eventFlags[TradeIdx] = book.IsTradeEvent()
	spl.eventFlags[PriceIdx] = book.IsPriceEvent() || (isFirstDayEvent && book.IsValidPriceEvent())
	spl.eventFlags[QuoteIdx] = book.IsQuoteEvent() || (isFirstDayEvent && book.IsValidQuoteEvent())

	// Various time stamps
	curMMIdx := timeint_to_minute(book.ExTimeInt)
	orig_src_epoch := book.ExTimestamp
	adj_src_epoch := common.SubtractBreakSeconds(orig_src_epoch, spl.secMorning, book.EID)

	// prices and sizes
	m_price := book.GetMidPrice()
	if m_price <= 0 {
		return
	}

	size_a := book.GetAskSize()
	size_b := book.GetBidSize()

	if !spl.stat.prevMinuteAvgSize01.HasSid(sid) {
		return
	}
	ts_lb := spl.stat.prevMinuteAvgSize01.Get(sid, curMMIdx)
	ts_ub := spl.stat.prevMinuteAvgSize99.Get(sid, curMMIdx)
	ts_avg := spl.stat.prevMinuteAvgSize.Get(sid, curMMIdx)
	qty_cum := spl.stat.prevMinuteVolume.Get(sid, curMMIdx)
	amt_cum := spl.stat.prevMinuteTurnover.Get(sid, curMMIdx)

	if _, ok := spl.extraInfo[sid]; !ok {
		spl.extraInfo[sid] = make([]float64, 10)
	}
	spl.extraInfo[sid][0] = ts_lb
	spl.extraInfo[sid][1] = ts_ub
	spl.extraInfo[sid][2] = ts_avg
	spl.extraInfo[sid][3] = qty_cum
	spl.extraInfo[sid][4] = amt_cum
	spl.extraInfo[sid][5] = spl.stat.prevDayTurnover[sid]
	spl.extraInfo[sid][6] = spl.stat.prevDayBuyVolume[sid]
	spl.extraInfo[sid][7] = spl.stat.prevDaySellVolume[sid]

	if math.IsNaN(ts_lb) || ts_lb < 100 {
		ts_lb = 100
	}
	if ts_ub < 100 {
		ts_ub = 100
	}
	size_a = math.Min(size_a, ts_ub)
	size_a = math.Max(size_a, ts_lb)
	size_b = math.Min(size_b, ts_ub)
	size_b = math.Max(size_b, ts_lb)
	avg_quote_size := (size_a + size_b) / 2.0

	delta_ask_liq, delta_bid_liq, taken_liq, sweep_level, new_line_list, cancel_line_list := book.GetDepthBookDeltaLiquidity()

	if false {
		fmt.Printf("NOT USED VARIABLES %v %v\n", new_line_list, cancel_line_list)
	}

	if spl.eventFlags[TradeIdx] || spl.eventFlags[QuoteIdx] {

		ourEpoch := endBatch.OurEpoch

		// Z1 DATA
		prepareBooksize(sid, ourEpoch, endBatch, spl.z1_data1)
		prepareSnapshotBook(sid, ourEpoch, endBatch, spl.z1_data2, spl.t_data)

		lastSnapshot := spl.lastSnapshotData[sid]
		prepareAgTrade(sid, ourEpoch, endBatch, lastSnapshot, spl.z1_data3)

		// Z1 dispachers
		if feature, ok := spl.featureDict["Z1-BP"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_BOOKSIZE, len(spl.z1_data1), spl.z1_data1)
		}

		if feature, ok := spl.featureDict["Z1-HBP"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_BOOKSIZE, len(spl.z1_data1), spl.z1_data1)
		}

		if feature, ok := spl.featureDict["Z1-SD"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_SNAPSHOT_BOOK, len(spl.z1_data2), spl.z1_data2)
		}

		if feature, ok := spl.featureDict["Z1-SL"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_SNAPSHOT_BOOK, len(spl.z1_data2), spl.z1_data2)
		}

		if feature, ok := spl.featureDict["Z1-HSL"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_SNAPSHOT_BOOK, len(spl.z1_data2), spl.z1_data2)
		}

		if feature, ok := spl.featureDict["Z1-TSD"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_SNAPSHOT_BOOK, len(spl.z1_data2), spl.z1_data2)
		}

		if feature, ok := spl.featureDict["Z1-PSP"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_SNAPSHOT_BOOK, len(spl.z1_data2), spl.z1_data2)
		}

		if feature, ok := spl.featureDict["Z1-PS"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_SNAPSHOT_BOOK, len(spl.z1_data2), spl.z1_data2)
		}
		if feature, ok := spl.featureDict["Z1-PS2"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_SNAPSHOT_BOOK, len(spl.z1_data2), spl.z1_data2)
		}
		if feature, ok := spl.featureDict["Z1-PS3"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_SNAPSHOT_BOOK, len(spl.z1_data2), spl.z1_data2)
		}

		if feature, ok := spl.featureDict["Z1-LC"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_SNAPSHOT_BOOK, len(spl.z1_data2), spl.z1_data2)
		}
		if feature, ok := spl.featureDict["Z1-LC2"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_SNAPSHOT_BOOK, len(spl.z1_data2), spl.z1_data2)
		}

		if feature, ok := spl.featureDict["Z1-AGT"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_AG_TRADE, len(spl.z1_data3), spl.z1_data3)
		}
		if feature, ok := spl.featureDict["Z1-AGT2"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_AG_TRADE, len(spl.z1_data3), spl.z1_data3)
		}
		if feature, ok := spl.featureDict["Z1-AGT3"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_AG_TRADE, len(spl.z1_data3), spl.z1_data3)
		}
		if feature, ok := spl.featureDict["Z1-AGT4"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_AG_TRADE, len(spl.z1_data3), spl.z1_data3)
		}
		if feature, ok := spl.featureDict["Z1-AGT5"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_AG_TRADE, len(spl.z1_data3), spl.z1_data3)
		}

		if feature, ok := spl.featureDict["Z1-DBG"]; ok {
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_SNAPSHOT_BOOK, len(spl.z1_data2), spl.z1_data2)
			feature.TermUpdate(sid, ourEpoch, Z1_INPUT_AG_TRADE, len(spl.z1_data3), spl.z1_data3)
		}

		if lastSnapshot == nil {
			spl.lastSnapshotData[sid] = make([]float64, len(spl.z1_data2))
		}
		copy(spl.lastSnapshotData[sid], spl.z1_data2)

		//# features that need to be updated at both TRADE and QUOTE
		//# features that depend on mid price
		if m_price != 0 {
			if feature, ok := spl.featureDict["LBR"]; ok {
				new_obs := []float64{m_price, book.PrevClose, book.Open}
				feature.UpdateSecValueSlice(sid, adj_src_epoch, new_obs)
			}
			if feature, ok := spl.featureDict["LBR2"]; ok {
				new_obs := []float64{m_price, book.PrevClose, book.Open}
				feature.UpdateSecValueSlice(sid, adj_src_epoch, new_obs)
			}

			// dragon LBR
			if feature, ok := spl.featureDict["DRETS"]; ok {
				// default backward secs
				spl.tmpSlice[0] = 120
				spl.tmpSlice[1] = 1800
				{
					res := spl.zigZag500S.GetZigZag()
					n := len(res.Breaks)
					// breaks include the last one
					// -3, -2[last turning point], -1[last one]
					if n > 2 {
						spl.tmpSlice[0] = adj_src_epoch - res.Ts[res.Breaks[n-2]]
						spl.tmpSlice[1] = adj_src_epoch - res.Ts[res.Breaks[n-3]]
					} else if n == 2 {
						spl.tmpSlice[0] = adj_src_epoch - res.Ts[res.Breaks[n-2]]
						spl.tmpSlice[1] = spl.tmpSlice[0]
					}
					// short index trend time
					if feature2, ok2 := spl.featureDict["DIDXS"]; ok2 && n >= 2 {
						feature2.UpdateSecValueSlice(sid, adj_src_epoch, spl.tmpSlice[:1])
					}
				}
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
				feature.UpdateSecValueSlice(sid, adj_src_epoch, spl.tmpSlice[:2])
			}
			if feature, ok := spl.featureDict["DRETL"]; ok {
				spl.tmpSlice[0] = 120
				spl.tmpSlice[1] = 1800
				{
					res := spl.zigZag500L.GetZigZag()
					n := len(res.Breaks)
					if n > 2 {
						spl.tmpSlice[0] = adj_src_epoch - res.Ts[res.Breaks[n-2]]
						spl.tmpSlice[1] = adj_src_epoch - res.Ts[res.Breaks[n-3]]
					} else if n == 2 {
						spl.tmpSlice[0] = adj_src_epoch - res.Ts[res.Breaks[n-2]]
						spl.tmpSlice[1] = spl.tmpSlice[0]
					}
					// long index trend time
					if feature2, ok2 := spl.featureDict["DIDXL"]; ok2 && n >= 2 {
						feature2.UpdateSecValueSlice(sid, adj_src_epoch, spl.tmpSlice[:1])
					}
				}
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
				feature.UpdateSecValueSlice(sid, adj_src_epoch, spl.tmpSlice[:2])
			}

			if feature, ok := spl.featureDict["SSDRETS"]; ok && spl.snapSid.ContainsSid(sid) {
				spl.tmpSlice[0] = 0 // seg1 ret
				spl.tmpSlice[1] = 0 // seg2 ret
				spl.tmpSlice[2] = 0 // seg1 time span
				spl.tmpSlice[3] = 0 // seg2 time span
				res := spl.zzS[sidIdx].GetZigZag()
				n := len(res.Breaks)
				if n > 2 {
					spl.tmpSlice[0] = NaInf2Zero(m_price/res.Prices[res.Breaks[n-2]] - 1)
					spl.tmpSlice[1] = NaInf2Zero(res.Prices[res.Breaks[n-2]]/res.Prices[res.Breaks[n-3]] - 1)
					spl.tmpSlice[2] = adj_src_epoch - res.Ts[res.Breaks[n-2]]
					spl.tmpSlice[3] = res.Ts[res.Breaks[n-3]] - res.Ts[res.Breaks[n-2]]
				} else if n == 2 {
					spl.tmpSlice[0] = NaInf2Zero(m_price/res.Prices[res.Breaks[n-2]] - 1)
					spl.tmpSlice[1] = spl.tmpSlice[0]
					spl.tmpSlice[2] = adj_src_epoch - res.Ts[res.Breaks[n-2]]
					spl.tmpSlice[3] = spl.tmpSlice[2]
				}
				feature.UpdateSecValueSlice(sid, adj_src_epoch, spl.tmpSlice[:4])
			}

			if feature, ok := spl.featureDict["SSDRETL"]; ok && spl.snapSid.ContainsSid(sid) {
				spl.tmpSlice[0] = 0 // seg1 ret
				spl.tmpSlice[1] = 0 // seg2 ret
				spl.tmpSlice[2] = 0 // seg1 time span
				spl.tmpSlice[3] = 0 // seg2 time span
				res := spl.zzL[sidIdx].GetZigZag()
				n := len(res.Breaks)
				if n > 2 {
					spl.tmpSlice[0] = NaInf2Zero(m_price/res.Prices[res.Breaks[n-2]] - 1)
					spl.tmpSlice[1] = NaInf2Zero(res.Prices[res.Breaks[n-2]]/res.Prices[res.Breaks[n-3]] - 1)
					spl.tmpSlice[2] = adj_src_epoch - res.Ts[res.Breaks[n-2]]
					spl.tmpSlice[3] = res.Ts[res.Breaks[n-2]] - res.Ts[res.Breaks[n-3]]
				} else if n == 2 {
					spl.tmpSlice[0] = NaInf2Zero(m_price/res.Prices[res.Breaks[n-2]] - 1)
					spl.tmpSlice[1] = spl.tmpSlice[0]
					spl.tmpSlice[2] = adj_src_epoch - res.Ts[res.Breaks[n-2]]
					spl.tmpSlice[3] = spl.tmpSlice[2]
				}
				feature.UpdateSecValueSlice(sid, adj_src_epoch, spl.tmpSlice[:4])
			}

			if feature, ok := spl.featureDict["ELE"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELE0"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELES"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELEL"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELEL0"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELELL"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
		}

		sizeSlice := []float64{size_b, size_a}
		//# features that do not depend on mid price
		if feature, ok := spl.featureDict["BAR"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, sizeSlice)
		}
		if feature, ok := spl.featureDict["BARD"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, sizeSlice)
		}
		if feature, ok := spl.featureDict["DAL"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, delta_ask_liq)
		}
		if feature, ok := spl.featureDict["DBL"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, delta_bid_liq)
		}
		if feature, ok := spl.featureDict["TL"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, taken_liq)
		}
		if feature, ok := spl.featureDict["SL"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, sweep_level)
		}
		if feature, ok := spl.featureDict["DALD"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, delta_ask_liq)
		}
		if feature, ok := spl.featureDict["DBLD"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, delta_bid_liq)
		}
		if feature, ok := spl.featureDict["TLD"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, taken_liq)
		}
		if feature, ok := spl.featureDict["SLD"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, sweep_level)
		}
		if feature, ok := spl.featureDict["DQS"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, avg_quote_size)
		}
		if feature, ok := spl.featureDict["DQS2"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, avg_quote_size)
		}

		if spl.futIR != nil {
			if02IR := spl.futIR.GetIR("IF02")
			ic02IR := spl.futIR.GetIR("IC02")
			if feature, ok := spl.featureDict["IRIF"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, if02IR)
			}
			if feature, ok := spl.featureDict["IRIC"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, ic02IR)
			}
		}

		if feature, ok := spl.featureDict["IFF"]; ok && spl.idxFutfeature != nil {
			/*
			   names = append(names, "IC03-ifd-zz")
			   names = append(names, "IC03-br-zz")
			   names = append(names, "IF01-ifd-3m")
			   names = append(names, "IF01-pr-zz")
			   names = append(names, "IF01-IF04-3m")
			   names = append(names, "IH03-IC03-zz")
			*/
			spl.tmpSlice[0] = spl.idxFutfeature.GetIfdZigZag("IC03")
			spl.tmpSlice[1] = spl.idxFutfeature.GetBasisZigZag("IC03")
			spl.tmpSlice[2] = spl.idxFutfeature.GetIfdRet("IF01")
			spl.tmpSlice[3] = spl.idxFutfeature.GetPrcZigZag("IF01")
			spl.tmpSlice[4] = spl.idxFutfeature.GetFutDiffRet("IF01", "IF04")
			spl.tmpSlice[5] = spl.idxFutfeature.GetFutDiffZigZag("IH03", "IC03")
			feature.UpdateSecValueSlice(sid, adj_src_epoch, spl.tmpSlice[:6])
		}
	}

	//# calculated detrended price
	mid_price_tick := math.Mod(m_price, spl.tickSize[sidIdx]) //mid_price_tick = m_price % self.tick_size[sid]
	var smoothed_price float64
	//# use the smoothed price in ELE to adjust
	if spl.smoothPriceBaseFeature != "" {
		feature := spl.featureDict[spl.smoothPriceBaseFeature].(*Chartist)
		if feature.sidUniverse[sid] && len(feature.GetSmoothedPriceDeque(sid)) > 0 {
			smooth_price_deque := feature.GetSmoothedPriceDeque(sid)
			smoothed_price = math.Exp(smooth_price_deque[len(smooth_price_deque)-1].Price)
		} else {
			smoothed_price = m_price
		}

	} else {
		smoothed_price = m_price
	}
	adj_price := spl.tickSize[sidIdx]*math.Floor(smoothed_price/spl.tickSize[sidIdx]) + mid_price_tick

	//# features that need to be updated at QUOTE
	if spl.eventFlags[QuoteIdx] {
		max_size := spl.stat.prevMinuteAvgSize99.Get(sid, curMMIdx)
		update_book := book.GetEquityQuoteDerivedBookUpdate(max_size)

		if feature, ok := spl.featureDict["LSB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["APLSB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["AB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["APAB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["DLSB"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, update_book, adj_price)
		}
		if feature, ok := spl.featureDict["DAB"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, update_book, adj_price)
		}

		// Following three are not used in Equity now. D stands for NDiff
		if feature, ok := spl.featureDict["ABD"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["LSBD"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["DLSBD"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, update_book, adj_price)
		}

		// order of update book: ask1,ask2,..,askn,bid1,bid2,...,bidn
		//                       up....            ,down...
		updateBook, normUpdateBook := spl.levelSizer.Update(endBatch)

		if feature, ok := spl.featureDict["APLSB2"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, updateBook)
		}
		if feature, ok := spl.featureDict["APAB2"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, updateBook)
		}

		// calculate diff book
		var deltaBookSize int
		{
			n := 0
			prevAsks := book.GetPrevAskBook()
			currAsks := book.GetAskBook()
			for _, pq := range prevAsks {
				if pq.Price != 0 {
					for i := 1; i < len(currAsks); i++ {
						if pq.Price < currAsks[i].Price {
							break
						} else if pq.Price == currAsks[i].Price && pq.Qty != currAsks[i].Qty {
							spl.tmpPrcQtySlice[n].Price = pq.Price
							spl.tmpPrcQtySlice[n].Qty = pq.Qty - currAsks[i].Qty
							n++
						}
					}
				}
			}

			prevBids := book.GetPrevBidBook()
			currBids := book.GetBidBook()
			for _, pq := range prevBids {
				if pq.Price != 0 {
					for i := 1; i < len(currBids); i++ {
						if pq.Price > currBids[i].Price {
							break
						} else if pq.Price == currBids[i].Price && pq.Qty != currBids[i].Qty {
							spl.tmpPrcQtySlice[n].Price = pq.Price
							spl.tmpPrcQtySlice[n].Qty = currBids[i].Qty - pq.Qty
							n++
						}
					}
				}
			}

			deltaBookSize = n
		}

		if feature, ok := spl.featureDict["APDB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice[:deltaBookSize])
		}
		if feature, ok := spl.featureDict["APLSDB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice[:deltaBookSize])
		}

		if feature, ok := spl.featureDict["MPBSR"]; ok { // BSR
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, updateBook)
		}
		if feature, ok := spl.featureDict["MPBSS"]; ok { // BSS
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, updateBook)
		}
		if feature, ok := spl.featureDict["MPDEV"]; ok { // DEV
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, normUpdateBook)
		}
		if feature, ok := spl.featureDict["MPAR"]; ok { // AR
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, normUpdateBook)
		}
		if feature, ok := spl.featureDict["MPCL"]; ok { // CL
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, updateBook)
		}

		if feature, ok := spl.featureDict["MPBR1"]; ok { // book-ratio
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["MPBR2"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["MPBR3"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["MPBR4"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}

		if feature, ok := spl.featureDict["MPBDR1"]; ok { // book-diff-ratio
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["MPBDR2"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["MPBDR3"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["MPBDR4"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
	}

	//# features that need to be updated at TRADE
	if spl.eventFlags[TradeIdx] {
		bd := book.GetEquityTradeDerivedBookDelta()
		trade_book, taken_book, sweep_book := bd.Trade_book, bd.Taken_book, bd.Sweep_book
		if feature, ok := spl.featureDict["TB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, trade_book)
		}
		if feature, ok := spl.featureDict["APTB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, trade_book)
		}
		if feature, ok := spl.featureDict["TLB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, taken_book)
		}
		if feature, ok := spl.featureDict["APTLB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, taken_book)
		}
		if feature, ok := spl.featureDict["SLB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, sweep_book)
		}
		if feature, ok := spl.featureDict["APSLB"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, sweep_book)
		}
		if feature, ok := spl.featureDict["DTB"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, trade_book, adj_price)
		}
		if feature, ok := spl.featureDict["DTLB"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, taken_book, adj_price)
		}
		if feature, ok := spl.featureDict["DSLB"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, sweep_book, adj_price)
		}
		if feature, ok := spl.featureDict["TLBD"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, taken_book)
		}
		if feature, ok := spl.featureDict["SLBD"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, sweep_book)
		}

		if feature, ok := spl.featureDict["MPS"]; ok { // mid-price-sweep
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, sweep_book)
		}
		if feature, ok := spl.featureDict["MPSX"]; ok { // mid-price-sweep X
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, sweep_book)
		}

		if feature, ok := spl.featureDict["MPT"]; ok { // mid-price-trade
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, taken_book)
		}
		if feature, ok := spl.featureDict["MPTX"]; ok { // mid-price-trade X
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, taken_book)
		}

		trdAgg := spl.trdAgg[sidIdx]
		ordByTypeByLevel := trdAgg.GetTradesByOrder()

		passiveOrderTimeSpan := spl.passiveOrderTimeSpan[sidIdx]
		orderSpans := passiveOrderTimeSpan.GetPassiveOrdersLifeSpan()

		// AP TRADE events
		{

			asize, bsize := book.GetLastAskSize(), book.GetLastBidSize()
			spl.tmpPrcQtySlice2 = spl.tmpPrcQtySlice2[:0]       // signed big trade
			spl.tmpPrcQtySlice3 = spl.tmpPrcQtySlice3[:0]       // activeBuy - passiveBuy
			spl.tmpPrcQtySlice4 = spl.tmpPrcQtySlice4[:0]       // activeSell - passiveSell
			spl.tmpPrcQtySlice5 = spl.tmpPrcQtySlice5[:0]       // bigActiveBuy - smallActiveBuy
			spl.tmpPrcQtySlice6 = spl.tmpPrcQtySlice6[:0]       // bigActiveSell - smallActiveSell
			spl.tmpPrcQtySlice7 = spl.tmpPrcQtySlice7[:0]       // Active (buy pos, sell neg)
			spl.tmpPrcQtyTagSlice5 = spl.tmpPrcQtyTagSlice5[:0] //Buy
			spl.tmpPrcQtyTagSlice6 = spl.tmpPrcQtyTagSlice6[:0] //Sell

			spl.tmpPrcQtySlice8 = spl.tmpPrcQtySlice8[:0] // bigPassiveBuy - smallPassiveBuy
			spl.tmpPrcQtySlice9 = spl.tmpPrcQtySlice9[:0] // bigPassiveSell - smallPassiveSell

			spl.tmpPrcQtyOidTagSlice10 = spl.tmpPrcQtyOidTagSlice10[:0]
			// active tag 0 bigbuy, 1 smallbuy, 2 bigsell, 3 smallsell
			// Passive, tag 4 bigbuy, 5 smallbuy, 6 bigsell, 7 smallsell
			tagSlice10 := 0
			// active buy
			for prc, level := range ordByTypeByLevel.ActiveOnAsk {
				oidLevel := ordByTypeByLevel.OidActiveOnAsk[prc]
				for loc, qty := range level {
					bigqty := spl.tradeSizer.GetBigActiveTrade(sid, 1, qty, asize, bsize)
					if bigqty > 0 {
						spl.tmpPrcQtySlice2 = append(spl.tmpPrcQtySlice2, data.PriceQty{prc, bigqty})
						spl.tmpPrcQtySlice3 = append(spl.tmpPrcQtySlice3, data.PriceQty{prc, bigqty / ts_avg})
						spl.tmpPrcQtySlice5 = append(spl.tmpPrcQtySlice5, data.PriceQty{prc, bigqty})
						tagSlice10 = 0
					} else {
						spl.tmpPrcQtySlice5 = append(spl.tmpPrcQtySlice5, data.PriceQty{prc, -qty})
						tagSlice10 = 1
					}
					spl.tmpPrcQtySlice7 = append(spl.tmpPrcQtySlice7, data.PriceQty{prc, qty})
					qtyResized, tag := spl.tradeSizer.DifferActiveTradeSize(sid, 1, qty, asize, bsize)
					spl.tmpPrcQtyTagSlice5 = append(spl.tmpPrcQtyTagSlice5, data.PriceQtyTag{prc, qtyResized, tag})
					spl.tmpPrcQtyOidTagSlice10 = append(spl.tmpPrcQtyOidTagSlice10, data.PriceQtyOidTag{prc, qty, oidLevel[loc], tagSlice10})
				}
			}
			// passive buy
			for prc, level := range ordByTypeByLevel.PassiveOnBid {
				oidLevel := ordByTypeByLevel.OidPassiveOnBid[prc]
				for loc, qty := range level {
					bigqty := spl.tradeSizer.GetBigPassiveTrade(sid, 1, qty, asize, bsize)
					if bigqty > 0 {
						spl.tmpPrcQtySlice3 = append(spl.tmpPrcQtySlice3, data.PriceQty{prc, -bigqty / ts_avg})
						spl.tmpPrcQtySlice8 = append(spl.tmpPrcQtySlice8, data.PriceQty{prc, bigqty})
						tagSlice10 = 4
					} else {
						spl.tmpPrcQtySlice8 = append(spl.tmpPrcQtySlice8, data.PriceQty{prc, -qty})
						tagSlice10 = 5
					}
					spl.tmpPrcQtyOidTagSlice10 = append(spl.tmpPrcQtyOidTagSlice10, data.PriceQtyOidTag{prc, qty, oidLevel[loc], tagSlice10})
				}
			}
			// active sell
			for prc, level := range ordByTypeByLevel.ActiveOnBid {
				oidLevel := ordByTypeByLevel.OidActiveOnBid[prc]
				for loc, qty := range level {
					bigqty := spl.tradeSizer.GetBigActiveTrade(sid, -1, qty, asize, bsize)
					if bigqty > 0 {
						spl.tmpPrcQtySlice2 = append(spl.tmpPrcQtySlice2, data.PriceQty{prc, -bigqty})
						spl.tmpPrcQtySlice4 = append(spl.tmpPrcQtySlice4, data.PriceQty{prc, bigqty / ts_avg})
						spl.tmpPrcQtySlice6 = append(spl.tmpPrcQtySlice6, data.PriceQty{prc, bigqty})
						tagSlice10 = 2
					} else {
						spl.tmpPrcQtySlice6 = append(spl.tmpPrcQtySlice6, data.PriceQty{prc, -qty})
						tagSlice10 = 3
					}
					spl.tmpPrcQtySlice7 = append(spl.tmpPrcQtySlice7, data.PriceQty{prc, -qty})
					qtyResized, tag := spl.tradeSizer.DifferActiveTradeSize(sid, -1, qty, asize, bsize)
					spl.tmpPrcQtyTagSlice6 = append(spl.tmpPrcQtyTagSlice6, data.PriceQtyTag{prc, qtyResized, tag})
					spl.tmpPrcQtyOidTagSlice10 = append(spl.tmpPrcQtyOidTagSlice10, data.PriceQtyOidTag{prc, qty, oidLevel[loc], tagSlice10})
				}
			}
			// passive sell
			for prc, level := range ordByTypeByLevel.PassiveOnAsk {
				oidLevel := ordByTypeByLevel.OidPassiveOnAsk[prc]
				for loc, qty := range level {
					bigqty := spl.tradeSizer.GetBigPassiveTrade(sid, -1, qty, asize, bsize)
					if bigqty > 0 {
						spl.tmpPrcQtySlice4 = append(spl.tmpPrcQtySlice4, data.PriceQty{prc, -bigqty / ts_avg})
						spl.tmpPrcQtySlice9 = append(spl.tmpPrcQtySlice9, data.PriceQty{prc, bigqty})
						tagSlice10 = 6
					} else {
						spl.tmpPrcQtySlice9 = append(spl.tmpPrcQtySlice9, data.PriceQty{prc, -qty})
						tagSlice10 = 7
					}
					spl.tmpPrcQtyOidTagSlice10 = append(spl.tmpPrcQtyOidTagSlice10, data.PriceQtyOidTag{prc, qty, oidLevel[loc], tagSlice10})
				}
			}

			// APTLB and APTLB2 are different
			if feature, ok := spl.featureDict["APTLB2"]; ok && len(spl.tmpPrcQtySlice2) > 0 {
				feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice2)
			}

			if feature, ok := spl.featureDict["APBU"]; ok && len(spl.tmpPrcQtySlice3) > 0 { // buyer uergency (diff between big active buy and big passive buy)
				feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice3)
			}

			if feature, ok := spl.featureDict["APSU"]; ok && len(spl.tmpPrcQtySlice4) > 0 { // seller uergency
				feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice4)
			}

			if feature, ok := spl.featureDict["APDIB"]; ok && len(spl.tmpPrcQtySlice5) > 0 { // bigBuy -smallBuy
				feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice5)
			}

			if feature, ok := spl.featureDict["APDIS"]; ok && len(spl.tmpPrcQtySlice6) > 0 { // bigSell -smallSell
				feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice6)
			}

			if feature, ok := spl.featureDict["T-1"]; ok && len(spl.tmpPrcQtySlice7) > 0 {
				feature.UpdateSecPrcQtySliceSnap(sid, adj_src_epoch, spl.tmpPrcQtySlice7, spl.t_data)
			}

			if feature, ok := spl.featureDict["T-3"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceSnap(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data)
			}

			if feature, ok := spl.featureDict["T-4A"]; ok && len(spl.tmpPrcQtySlice5) > 0 {
				feature.UpdateSecPrcQtySliceDoubleSnap(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.t_data, spl.lastSnapshotDataT[sid])
			}

			if feature, ok := spl.featureDict["T-4B"]; ok && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateSecPrcQtySliceDoubleSnap(sid, adj_src_epoch, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid])
			}

			if feature, ok := spl.featureDict["T-5"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceSnap(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data)
			}

			if feature, ok := spl.featureDict["T-8"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map)
			}

			if feature, ok := spl.featureDict["T-9"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 && len(spl.tmpPrcQtySlice8) > 0 && len(spl.tmpPrcQtySlice9) > 0 {
				feature.UpdateQuadrupleSecPrcQtySliceSnapGroup(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.tmpPrcQtySlice8, spl.tmpPrcQtySlice9, spl.t_data, spl.groupMap.G1Map)
			}

			if feature, ok := spl.featureDict["T-10"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map)
			}

			if feature, ok := spl.featureDict["T-11"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map)
			}

			if feature, ok := spl.featureDict["T-12"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map)
			}

			if feature, ok := spl.featureDict["T-14A"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map, spl.extraInfo)
			}

			if feature, ok := spl.featureDict["T-14B"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map, spl.extraInfo)
			}

			if feature, ok := spl.featureDict["T-14C"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map, spl.extraInfo)
			}

			if feature, ok := spl.featureDict["T-14D"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map, spl.extraInfo)
			}

			if feature, ok := spl.featureDict["T-14E"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map, spl.extraInfo)
			}

			if feature, ok := spl.featureDict["T-15"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map)
			}

			if feature, ok := spl.featureDict["T-16"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map, spl.extraInfo)
			}

			if feature, ok := spl.featureDict["T-17"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map, spl.extraInfo)
			}

			if feature, ok := spl.featureDict["M-1"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map)
			}

			if feature, ok := spl.featureDict["M-2"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroup(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map)
			}

			if feature, ok := spl.featureDict["M-3"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map, spl.extraInfo)
			}

			if feature, ok := spl.featureDict["M-4"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map, spl.extraInfo)
			}

			if feature, ok := spl.featureDict["M-5"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map, spl.extraInfo)
			}

			if feature, ok := spl.featureDict["M-6"]; ok && len(spl.tmpPrcQtySlice5) > 0 && len(spl.tmpPrcQtySlice6) > 0 {
				feature.UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid, adj_src_epoch, spl.tmpPrcQtySlice5, spl.tmpPrcQtySlice6, spl.t_data, spl.lastSnapshotDataT[sid], spl.groupMap.G1Map, spl.extraInfo)
			}

			if spl.lastSnapshotDataT[sid] == nil {
				spl.lastSnapshotDataT[sid] = make([]float64, len(spl.z1_data2))
			}
			copy(spl.lastSnapshotDataT[sid], spl.z1_data2)
		}

		{
			feature1, ok1 := spl.featureDict["MPORB"]
			feature2, ok2 := spl.featureDict["MPORA"]
			feature3, ok3 := spl.featureDict["MPORBX"]
			feature4, ok4 := spl.featureDict["MPORAX"]

			feature21, ok21 := spl.featureDict["APORB"]
			feature22, ok22 := spl.featureDict["APORA"]

			if ok1 && ok2 || ok3 && ok4 || ok21 || ok22 { // mid-price-order-ratio-(buy at ask) and (sell at bid)
				activeOnAskCnt := 0
				passOnAskCnt := 0
				activeOnBidCnt := 0
				passOnBidCnt := 0
				for _, level := range ordByTypeByLevel.ActiveOnAsk {
					activeOnAskCnt += len(level)
				}
				for _, level := range ordByTypeByLevel.PassiveOnAsk {
					passOnAskCnt += len(level)
				}
				for _, level := range ordByTypeByLevel.ActiveOnBid {
					activeOnBidCnt += len(level)
				}
				for _, level := range ordByTypeByLevel.PassiveOnBid {
					passOnBidCnt += len(level)
				}

				ratio1 := 0.0
				if activeOnAskCnt+passOnAskCnt > 0 {
					ratio1 = float64(activeOnAskCnt-passOnAskCnt) / float64(activeOnAskCnt+passOnAskCnt)
				}

				ratio2 := 0.0
				if activeOnBidCnt+passOnBidCnt > 0 {
					ratio2 = float64(activeOnBidCnt-passOnBidCnt) / float64(activeOnBidCnt+passOnBidCnt)
				}

				if ok1 && ok2 {
					feature1.UpdateSecValue(sid, adj_src_epoch, ratio1)
					feature2.UpdateSecValue(sid, adj_src_epoch, ratio2)
				}
				if ok3 && ok4 {
					feature3.UpdateSecValue(sid, adj_src_epoch, ratio1)
					feature4.UpdateSecValue(sid, adj_src_epoch, ratio2)
				}

				if ratio1 != 0 && ok22 && book.GetLastAskPrice() > 0 {
					spl.tmpPrcQtySlice[0].Price = book.GetLastAskPrice()
					spl.tmpPrcQtySlice[0].Qty = ratio1 + 1.0
					feature22.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice[:1])
				}

				if ratio2 != 0 && ok21 && book.GetLastBidPrice() > 0 {
					spl.tmpPrcQtySlice[0].Price = book.GetLastBidPrice()
					spl.tmpPrcQtySlice[0].Qty = ratio2 + 1.0
					feature21.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice[:1])
				}

			}
		}

		{
			feature1, ok1 := spl.featureDict["MPPOS"] // passive-order-span
			feature2, ok2 := spl.featureDict["MPPOSX"]

			feature21, ok21 := spl.featureDict["APPOSA"]
			feature22, ok22 := spl.featureDict["APPOSB"]

			feature31, ok31 := spl.featureDict["APASB"]
			feature32, ok32 := spl.featureDict["APASS"]

			if ok1 || ok2 || ok21 || ok22 || ok31 || ok32 {
				spl.tmpPrcQtySlice2 = spl.tmpPrcQtySlice2[:0] // POS avg span for buy
				spl.tmpPrcQtySlice3 = spl.tmpPrcQtySlice3[:0] // POS avg span for sell
				sumA := 0.0
				cntA := 0.0
				sumB := 0.0
				cntB := 0.0
				for _, span := range orderSpans {
					if span.InferTimeSpan >= 0 { // discard auction orders
						if span.Qty < 0 { // ask side
							cntA++
							sumA += math.Pow(-span.Qty, 0.3)
							spl.tmpPrcQtySlice3 = append(spl.tmpPrcQtySlice3, data.PriceQty{span.Prc, -span.InferTimeSpan})
						} else { // bid side
							cntB++
							sumB += math.Pow(span.Qty, 0.3)
							spl.tmpPrcQtySlice2 = append(spl.tmpPrcQtySlice2, data.PriceQty{span.Prc, span.InferTimeSpan})
						}
					}
				}
				spl.tmpSlice[0] = sumA / cntA
				spl.tmpSlice[1] = sumB / cntB
				if ok1 {
					feature1.UpdateSecValueSlice(sid, adj_src_epoch, spl.tmpSlice)
				}
				if ok2 {
					feature2.UpdateSecValueSlice(sid, adj_src_epoch, spl.tmpSlice)
				}

				if cntA > 0 && ok21 && book.GetLastAskPrice() > 0 {
					spl.tmpPrcQtySlice[0].Price = book.GetLastAskPrice()
					spl.tmpPrcQtySlice[0].Qty = spl.tmpSlice[0]
					feature21.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice[:1])
				}
				if cntB > 0 && ok22 && book.GetLastBidPrice() > 0 {
					spl.tmpPrcQtySlice[0].Price = book.GetLastBidPrice()
					spl.tmpPrcQtySlice[0].Qty = spl.tmpSlice[1]
					feature22.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice[:1])
				}

				if ok31 && len(spl.tmpPrcQtySlice2) > 0 {
					feature31.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice2)
					//if sid == 185 {
					//	fmt.Printf("SPAN %.3f, %v\n", adj_src_epoch, spl.tmpPrcQtySlice2)
					//}
				}
				if ok32 && len(spl.tmpPrcQtySlice3) > 0 {
					feature32.UpdateSecPrcQtySlice(sid, adj_src_epoch, spl.tmpPrcQtySlice3)
				}
			}
		}

		//# features that depend on average price
		price_high, price_low, price_last, net_volume := book.GetEquityHighLowLast()

		hll := []float64{price_high, price_low, price_last}
		price_avg := (price_high + price_low + price_last) / 3

		if feature, ok := spl.featureDict["BB"]; ok {
			feature.UpdateValue(sid, price_avg)
		}
		if feature, ok := spl.featureDict["ADX"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, hll)
		}
		if feature, ok := spl.featureDict["CCI"]; ok {
			feature.UpdateValue(sid, price_avg)
		}
		if feature, ok := spl.featureDict["RSI"]; ok {
			feature.UpdateValue(sid, price_avg)
		}
		if feature, ok := spl.featureDict["TSI"]; ok {
			feature.UpdateValue(sid, price_avg)
		}
		if feature, ok := spl.featureDict["SOI"]; ok {
			feature.UpdateValueSlice(sid, hll)
		}

		//# unpack price, size and side from agg_trade
		t_size := book.AggTrade.Size //NOTE: t_price, t_side not used in this function
		nta := []float64{net_volume, t_size, avg_quote_size}

		if feature, ok := spl.featureDict["TOIE"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, nta)
		}
		if spl.smoothPriceBaseFeature != "" {
			chartist := spl.featureDict[spl.smoothPriceBaseFeature].(*Chartist)
			if chartist.sidUniverse[sid] {
				if feature, ok := spl.featureDict["TOIU"]; ok {
					ele_is_up_trend := chartist.ExtremaIsMax(sid)
					if ele_is_up_trend {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, nta)
					}
				}

				if feature, ok := spl.featureDict["TOID"]; ok {
					ele_is_up_trend := chartist.ExtremaIsMax(sid)
					if !ele_is_up_trend {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, nta)
					}
				}

				if feature, ok := spl.featureDict["TOIA"]; ok {
					if m_price > smoothed_price {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, nta)
					}
				}

				if feature, ok := spl.featureDict["TOIB"]; ok {
					if m_price < smoothed_price {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, nta)
					}
				}
			}
		}

		adj_price_high := price_high - adj_price
		adj_price_low := price_low - adj_price
		adj_price_last := price_last - adj_price
		adj_price_avg := price_avg - adj_price

		ahll := []float64{adj_price_high, adj_price_low, adj_price_last}
		hlsnab := []float64{price_high, price_low, t_size, net_volume, size_a, size_b}
		if feature, ok := spl.featureDict["DADX"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, ahll)
		}
		if feature, ok := spl.featureDict["DRSI"]; ok {
			feature.UpdateValue(sid, adj_price_avg)
		}
		if feature, ok := spl.featureDict["DTSI"]; ok {
			feature.UpdateValue(sid, adj_price_avg)
		}
		if feature, ok := spl.featureDict["DSOI"]; ok {
			feature.UpdateValueSlice(sid, ahll)
		}
		if feature, ok := spl.featureDict["DVOL"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, t_size)
		}
		if feature, ok := spl.featureDict["DVOL2"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, t_size)
		}
		if feature, ok := spl.featureDict["DRNG"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, price_high)
		}
		if feature, ok := spl.featureDict["DRNG2"]; ok {
			feature.UpdateSecValue(sid, adj_src_epoch, price_high)
		}
		if feature, ok := spl.featureDict["HPE"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, hlsnab)
		}
		if feature, ok := spl.featureDict["HPE2"]; ok {
			feature.UpdateSecValueSlice(sid, adj_src_epoch, hlsnab)
		}
	}

	// update mid price for MidBook
	if spl.eventFlags[QuoteIdx] {

		spl.tmpSlice[0] = book.GetAskPrice()
		spl.tmpSlice[1] = book.GetBidPrice()
		spl.tmpSlice[2] = m_price

		if feature, ok := spl.featureDict["MPS"]; ok { // mid-price-sweep
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPSX"]; ok { // mid-price-sweep
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPT"]; ok { // mid-price-trade
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPTX"]; ok { // mid-price-trade
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}

		if feature, ok := spl.featureDict["MPBR1"]; ok { // book-ratio
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPBR2"]; ok {
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPBR3"]; ok {
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPBR4"]; ok {
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}

		if feature, ok := spl.featureDict["MPBDR1"]; ok { // book-diff-ratio
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPBDR2"]; ok {
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPBDR3"]; ok {
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPBDR4"]; ok {
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}

		if feature, ok := spl.featureDict["MPBSR"]; ok {
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPBSS"]; ok {
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPDEV"]; ok {
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
		if feature, ok := spl.featureDict["MPAR"]; ok {
			feature.UpdateValueSlice(sid, spl.tmpSlice)
		}
	}
}
