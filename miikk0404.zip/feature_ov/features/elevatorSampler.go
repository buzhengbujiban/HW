/**
 * Author: Yingfa, yzhu
 * Date: 18-6-1
 */
package feature

import (
	MU "TES/QR/alpha_ov/mathUtils"
	"math"

	"gonum.org/v1/gonum/mat"
)

type SecPrice struct {
	SecEpoch float64
	Price    float64
}

type IdxSecPrice struct {
	Idx      int
	SecEpoch float64
	Price    float64
}

type SimpleRegResult struct {
	Beta  float64
	Rsq   float64
	Tsq   float64
	Sigma float64
}

func calc_beta_rsq(prices []SecPrice) SimpleRegResult {
	n := float64(len(prices))
	EX, EY := 0.0, 0.0
	SXX, SYY, SXY := 0.0, 0.0, 0.0
	for i := 0; i < len(prices); i++ {
		v := prices[i]
		EX += v.SecEpoch
		EY += v.Price
		SXX += v.SecEpoch * v.SecEpoch
		SYY += v.Price * v.Price
		SXY += v.SecEpoch * v.Price
	}

	EX /= n
	EY /= n
	SXX = SXX - n*(EX*EX)
	SYY = SYY - n*(EY*EY)
	SXY = SXY - n*(EX*EY)

	var beta, RSS, rsq, sigma_sq_hat, t_stat, se_beta float64

	if SXX > 0 {
		beta = SXY / SXX
		RSS = SYY - (SXY*SXY)/SXX
		if RSS < 0 {
			RSS = 0
		}
		if SYY > 0 {
			rsq = 1 - RSS/SYY
		} else {
			rsq = 1
		}
		sigma_sq_hat = 0
		if n > 2 {
			sigma_sq_hat = RSS / (n - 2)
		}
		se_beta = math.Sqrt(sigma_sq_hat / SXX)
		if se_beta == 0 {
			se_beta = 10000
		}
		t_stat = 0
		if n > 0 {
			t_stat = beta / se_beta
		}
	} else {
		beta = 0
		RSS = SYY
		if RSS < 0 {
			RSS = 0
		}
		rsq = 0
		sigma_sq_hat = 0
		if n > 2 {
			sigma_sq_hat = RSS / (n - 2)
		}
		t_stat = 0
	}
	return SimpleRegResult{beta, rsq, t_stat * t_stat, math.Sqrt(sigma_sq_hat)}
}

func smoother(prices []SecPrice, kernel_width float64, method string, order int) float64 {
	n := len(prices)
	var wSum, wxSum, wxxSum, wySum, wxySum float64
	lastSec := prices[n-1].SecEpoch
	if method == "tri-cube" {
		for i := 0; i < n; i++ {
			x := prices[i].SecEpoch
			y := prices[i].Price
			w := MU.TriCubeFloat(math.Abs(x-lastSec) / kernel_width)
			wSum += w
			wxSum += w * x
			wxxSum += w * x * x
			wySum += w * y
			wxySum += w * x * y
		}
	} else {
		for i := 0; i < n; i++ {
			x := prices[i].SecEpoch
			y := prices[i].Price
			w := MU.EpanechnikovFloat(math.Abs(x-lastSec) / kernel_width)
			wSum += w
			wxSum += w * x
			wxxSum += w * x * x
			wySum += w * y
			wxySum += w * x * y
		}
	}

	if order == 0 {
		return wySum / wSum
	} else if order == 1 {
		if n < 3 {
			return wySum / wSum
		} else {
			a, b, c, d := wSum, wxSum, wxSum, wxxSum
			//  (BWB)
			//                   1
			//  [a b]^(-1)  = ------- [d -b]
			//  [c d]          ad-bc  [-c a]
			det := a*d - b*c
			if math.Abs(det) < 1e-10 {
				//singular matrix, no inverse
				return wySum / wSum
			} else {
				a1, b1, c1, d1 := d/det, -b/det, -c/det, a/det
				x1 := lastSec
				// b        * BWB_Inv  * BWy
				//-----------------------------
				//            [a1 b1]    [wy ]
				//[1, x1]   * [c1 d1]  * [wxy]
				return (a1+x1*c1)*wySum + (b1+x1*d1)*wxySum
			}
		}
	} else {
		panic("smoother parameter order should be 0 or 1.")
	}
}

func smoother2(secEpochArr, priceArr []float64, kernelWidth float64, method byte, order int) float64 {
	if len(secEpochArr) != len(priceArr) {
		panic("Length of second array not equals with price array.")
	}
	w := make([]float64, len(secEpochArr))
	var wSum, wxSum, wxxSum, wySum, wxySum float64
	lastSec := secEpochArr[len(secEpochArr)-1]
	if method == 'T' {
		for i := 0; i < len(secEpochArr); i++ {
			w[i] = MU.TriCubeFloat(math.Abs(secEpochArr[i]-lastSec) / kernelWidth)
			wSum += w[i]
			wxSum += w[i] * secEpochArr[i]
			wxxSum += w[i] * secEpochArr[i] * secEpochArr[i]
			wySum += w[i] * priceArr[i]
			wxySum += w[i] * secEpochArr[i] * priceArr[i]
		}
	} else {
		for i := 0; i < len(secEpochArr); i++ {
			w[i] = MU.EpanechnikovFloat(math.Abs(secEpochArr[i]-lastSec) / kernelWidth)
			wSum += w[i]
			wxSum += w[i] * secEpochArr[i]
			wxxSum += w[i] * secEpochArr[i] * secEpochArr[i]
			wySum += w[i] * priceArr[i]
			wxySum += w[i] * secEpochArr[i] * priceArr[i]
		}
	}
	if order == 0 {
		return wySum / wSum
	} else if order == 1 {
		if len(priceArr) < 3 {
			return wySum / wSum
		}
		bwb := mat.NewDense(2, 2, []float64{wSum, wxSum, wxSum, wxxSum})
		var bwbInv mat.Dense
		bwbInv.Inverse(bwb)

		bwy := mat.NewDense(2, 1, []float64{wySum, wxySum})
		b := mat.NewDense(1, 2, []float64{1, lastSec})
		//fmt.Println("b:",b)
		//fmt.Println("bwb:", bwb)
		//fmt.Println("bwb_inv:", bwbInv)
		//fmt.Println("bwy:", bwy)

		var tmpD mat.Dense
		tmpD.Mul(b, &bwbInv)
		//fmt.Println("b*bwbinv:", tmpD)
		var retD mat.Dense
		retD.Mul(&tmpD, bwy)
		//fmt.Println("b*bwbinv*bwy",retD)
		return retD.At(0, 0)
	} else {
		panic("smoother parameter order should be 0 or 1.")
	}
}

//Elevator; Divide a price series into a few sections
type Elevator struct {
	num_sections int
	num_aux_vars int
	thres        float64

	//---state variables.
	idx               int //index of current price
	cur_entry         SecPrice
	trend_prob        float64
	has_new_extrema   bool
	has_new_candidate bool
	extrema_is_max    bool

	extrema_deque []*IdxSecPrice
	price_deque1  []SecPrice
	price_deque2  []SecPrice
	extrema_cand  *IdxSecPrice
	stat_deque    []SimpleRegResult

	aux_sum1 MU.Vector
	aux_sum2 MU.Vector

	// internal temp variables
	list_for_calc []SecPrice
	e_list        []*IdxSecPrice
	s_list        []SimpleRegResult
}

func (ele *Elevator) Init(num_sections int, thres float64, num_aux_vars int) {
	ele.num_sections = num_sections
	ele.thres = thres
	ele.num_aux_vars = num_aux_vars

	ele.extrema_deque = make([]*IdxSecPrice, 0)
	ele.trend_prob = 0
	//# state variables
	//# index of current price
	ele.idx = -1
	//# current entry (a tuple of (sec, price)
	ele.cur_entry = SecPrice{}
	//# candidate of extrema. value is a tuple: (idx, sec, price)
	ele.extrema_cand = nil
	//# whether extrema candidate is maximum
	ele.extrema_is_max = false
	//# auxiliary summary from last known extrema to extrema candidate
	//# (left exclusive right inclusive)
	//# note that aux_array is information for before the current price
	ele.aux_sum1 = MU.NewVector(num_aux_vars)
	//# auxiliary summary from extrema candidate to last entry
	//# (left exclusive right inclusive)
	ele.aux_sum2 = MU.NewVector(num_aux_vars)
	//# price deque from last known extrema to extrema candidate
	//# (left inclusive right exclusive)
	ele.price_deque1 = make([]SecPrice, 0)
	//# price deque from extrema candidate to last entry
	//# (left inclusive right inclusive)
	ele.price_deque2 = make([]SecPrice, 0)
	//# statistics deque
	ele.stat_deque = make([]SimpleRegResult, 0)

	return
}

func (ele *Elevator) Reset() {
	ele.extrema_deque = ele.extrema_deque[:0]
	ele.trend_prob = 0
	//# state variables
	//# index of current price
	ele.idx = -1
	//# current entry (a tuple of (sec, price)
	ele.cur_entry = SecPrice{}
	//# candidate of extrema. value is a tuple: (idx, sec, price)
	ele.extrema_cand = nil
	//# whether extrema candidate is maximum
	ele.extrema_is_max = false
	//# auxiliary summary from last known extrema to extrema candidate
	//# (left exclusive right inclusive)
	//# note that aux_array is information for before the current price
	ele.aux_sum1.SetZero()
	//# auxiliary summary from extrema candidate to last entry
	//# (left exclusive right inclusive)
	ele.aux_sum2.SetZero()
	//# price deque from last known extrema to extrema candidate
	//# (left inclusive right exclusive)
	ele.price_deque1 = ele.price_deque1[:0]
	//# price deque from extrema candidate to last entry
	//# (left inclusive right inclusive)
	ele.price_deque2 = ele.price_deque2[:0]
	//# statistics deque
	ele.stat_deque = ele.stat_deque[:0]
	//# flag for new extrema being confirmed
	ele.has_new_extrema = false
	//# flag for new extrema candidate has been formed
	ele.has_new_candidate = false
}

func (ele *Elevator) Update(sec_epoch float64, price float64, aux_array MU.Vector) bool {
	//fmt.Printf("XP,sec=%.2f prc=%.5f thres=%.5f\n", sec_epoch, price, ele.thres)
	ele.idx = ele.idx + 1
	ele.cur_entry = SecPrice{sec_epoch, price}
	//# if it's first entry
	if ele.idx == 0 {
		//# first entry is always considered as an extrema
		ele.extrema_deque = append(ele.extrema_deque, &IdxSecPrice{ele.idx, sec_epoch, price})
		ele.trend_prob = 0
		//# do nothing to sum1
		//# push price into deque1
		ele.price_deque1 = append(ele.price_deque1, SecPrice{sec_epoch, price})
		//# we haven't seen a new extrema/candidate
		ele.has_new_extrema = false
		ele.has_new_candidate = false
		//fmt.Printf("XP1,%d,%v\n",ele.idx,ele.price_deque1)
		return true
	}

	if ele.extrema_cand == nil {
		if price == ele.extrema_deque[0].Price {
			//# if we haven't seen a different price than the first entry
			ele.trend_prob = 0
			//# push aux_array into sum1
			ele.aux_sum1.AddInplace(aux_array)
			//# push price into deque1
			ele.price_deque1 = append(ele.price_deque1, SecPrice{sec_epoch, price})
			//# we haven't seen a new extrema/candidate
			ele.has_new_extrema = false
			ele.has_new_candidate = false
		} else {
			//# finally a different price
			//# update extrema candidate
			ele.extrema_cand = &IdxSecPrice{ele.idx, sec_epoch, price}
			//# check if it's larger than the first entry or not
			if price > ele.extrema_deque[0].Price {
				ele.extrema_is_max = true
				ele.trend_prob = 1
			} else {
				ele.extrema_is_max = false
				ele.trend_prob = -1
			}
			//# still push aux_array into sum1 because it's information
			//# before current price
			ele.aux_sum1.AddInplace(aux_array)
			//# push price into deque2
			ele.price_deque2 = append(ele.price_deque2, SecPrice{sec_epoch, price})
			//# we haven't seen a new extrema, but we have a candidate
			ele.has_new_extrema = false
			ele.has_new_candidate = true
		}
		//fmt.Printf("XP2,%d,%v,%v\n",ele.idx,ele.price_deque1, ele.price_deque2)
		return true
	}
	//# normal update
	if ele.extrema_is_max {
		//# if price keeps going up
		if price > ele.extrema_cand.Price {
			ele.extrema_cand = &IdxSecPrice{ele.idx, sec_epoch, price}
			ele.trend_prob = 1
			//# merge sum2 and current input into sum1
			ele.aux_sum1.AddInplace(ele.aux_sum2)
			ele.aux_sum1.AddInplace(aux_array)
			//# reset sum2 to zero
			ele.aux_sum2.SetZero()
			//# merge deque2 into deque1
			ele.price_deque1 = append(ele.price_deque1, ele.price_deque2...)
			//# push price into deque1
			ele.price_deque1 = append(ele.price_deque1, SecPrice{sec_epoch, price})
			//# reset deque2 to current price
			ele.price_deque2 = ele.price_deque2[:0]
			//# we haven't seen a new extrema, but we have a new candidate
			ele.has_new_extrema = false
			ele.has_new_candidate = true
			//# a new trend has been formed
		} else if price <= ele.extrema_cand.Price-ele.thres {
			ele.extrema_deque = append(ele.extrema_deque, ele.extrema_cand)
			ele.extrema_cand = &IdxSecPrice{ele.idx, sec_epoch, price}
			ele.extrema_is_max = !ele.extrema_is_max
			ele.trend_prob = -1
			//# run simple regression for the section with two known extrema
			ele.list_for_calc = ele.list_for_calc[:0]
			ele.list_for_calc = append(ele.list_for_calc, ele.price_deque1...)
			if len(ele.price_deque2) > 0 {
				ele.list_for_calc = append(ele.list_for_calc, ele.price_deque2[0])
			}
			//# output is (beta, rsq)
			var regRes SimpleRegResult
			if len(ele.list_for_calc) > 1 {
				regRes = calc_beta_rsq(ele.list_for_calc)
			} else {
				regRes = SimpleRegResult{0, 0, 0, 0}
			}
			//TODO: tmp.append(ele.aux_sum1)
			//# append (beta, rsq, aux_sum) to stat_deque
			ele.stat_deque = append(ele.stat_deque, regRes)
			//# move sum2 to sum1
			ele.aux_sum1.SetZero()
			ele.aux_sum1.AddInplace(ele.aux_sum2)
			ele.aux_sum1.AddInplace(aux_array)
			//# reset sum2 with current input
			ele.aux_sum2.SetZero()
			//# move deque2 to deque1
			ele.price_deque1 = ele.price_deque1[:0]
			ele.price_deque1 = append(ele.price_deque1, ele.price_deque2...)
			//# push price into deque1
			ele.price_deque1 = append(ele.price_deque1, SecPrice{sec_epoch, price})
			//# reset deque2 to current price
			ele.price_deque2 = ele.price_deque2[:0]
			//# we have seen a new extrema and a new candidate
			ele.has_new_extrema = true
			ele.has_new_candidate = true
		} else {
			ele.trend_prob = 1 - (ele.extrema_cand.Price-price)/ele.thres*2
			//# update sum2
			ele.aux_sum2.AddInplace(aux_array)
			//# update deque2
			ele.price_deque2 = append(ele.price_deque2, SecPrice{sec_epoch, price})
			//# we haven't seen a new extrema/candidate
			ele.has_new_extrema = false
			ele.has_new_candidate = false
		}
	} else {
		//# if price keeps going down
		if price < ele.extrema_cand.Price {
			ele.extrema_cand = &IdxSecPrice{ele.idx, sec_epoch, price}
			ele.trend_prob = -1
			//# merge sum2 and current input into sum1
			ele.aux_sum1.AddInplace(ele.aux_sum2)
			ele.aux_sum1.AddInplace(aux_array)
			//# reset sum2 to zero
			ele.aux_sum2.SetZero()
			//# merge deque2 into deque1
			ele.price_deque1 = append(ele.price_deque1, ele.price_deque2...)
			//# push price into deque1
			ele.price_deque1 = append(ele.price_deque1, SecPrice{sec_epoch, price})
			//# reset deque2 to current price
			ele.price_deque2 = ele.price_deque2[:0]
			//# we haven't seen a new extrema, but we have a new candidate
			ele.has_new_extrema = false
			ele.has_new_candidate = true

		} else if price >= ele.extrema_cand.Price+ele.thres {
			//# a new trend has been formed
			ele.extrema_deque = append(ele.extrema_deque, ele.extrema_cand)
			ele.extrema_cand = &IdxSecPrice{ele.idx, sec_epoch, price}
			ele.extrema_is_max = !ele.extrema_is_max
			ele.trend_prob = 1
			//# run simple regression for the section with two known extrema
			ele.list_for_calc = ele.list_for_calc[:0]
			ele.list_for_calc = append(ele.list_for_calc, ele.price_deque1...)
			if len(ele.price_deque2) > 0 {
				ele.list_for_calc = append(ele.list_for_calc, ele.price_deque2[0])
			}
			//# output is (beta, rsq)
			var regRes SimpleRegResult
			if len(ele.list_for_calc) > 1 {
				regRes = calc_beta_rsq(ele.list_for_calc)
			} else {
				regRes = SimpleRegResult{0, 0, 0, 0}
			}
			//TODO: tmp.append(ele.aux_sum1)
			//# append (beta, rsq, aux_sum) to stat_deque
			ele.stat_deque = append(ele.stat_deque, regRes)
			//# move sum2 to sum1
			ele.aux_sum1.SetZero()
			ele.aux_sum1.AddInplace(ele.aux_sum2)
			ele.aux_sum1.AddInplace(aux_array)
			//# reset sum2 with current input
			ele.aux_sum2.SetZero()
			//# move deque2 to deque1
			ele.price_deque1 = ele.price_deque1[:0]
			ele.price_deque1 = append(ele.price_deque1, ele.price_deque2...)
			//# push price into deque1
			ele.price_deque1 = append(ele.price_deque1, SecPrice{sec_epoch, price})
			//# reset deque2 to current price
			ele.price_deque2 = ele.price_deque2[:0]
			//# we have seen a new extrema and a new candidate
			ele.has_new_extrema = true
			ele.has_new_candidate = true
		} else {
			ele.trend_prob = (price-ele.extrema_cand.Price)/ele.thres*2 - 1
			//# update sum2
			ele.aux_sum2.AddInplace(aux_array)
			//# update deque2
			ele.price_deque2 = append(ele.price_deque2, SecPrice{sec_epoch, price})
			//# we haven't seen a new extrema/candidate
			ele.has_new_extrema = false
			ele.has_new_candidate = false
		}
	}
	//fmt.Printf("XP3,%d,%v,%v\n",ele.idx,ele.price_deque1,ele.price_deque2)
	return true
}

func (ele *Elevator) GetSections(num_sections int) []*IdxSecPrice {
	//# get extrema sections given number of sections

	//# if num_sections is not given then it's set to default
	if num_sections == 0 {
		num_sections = ele.num_sections + 1
	}

	//# collect all extrema
	ele.e_list = ele.e_list[:0]
	ele.e_list = append(ele.e_list, ele.extrema_deque...)
	//# append extrema candidate
	if ele.extrema_cand != nil {
		ele.e_list = append(ele.e_list, ele.extrema_cand)
	}

	//# append last index
	if len(ele.e_list) > 0 {
		if ele.e_list[len(ele.e_list)-1].Idx != ele.idx {
			ele.e_list = append(ele.e_list, &IdxSecPrice{ele.idx, ele.cur_entry.SecEpoch, ele.cur_entry.Price})
		}
	}

	//# reverse it
	for i, j := 0, len(ele.e_list)-1; i < j; i, j = i+1, j-1 {
		tmp := ele.e_list[i]
		ele.e_list[i] = ele.e_list[j]
		ele.e_list[j] = tmp
	}

	//# truncate if not enough sections
	if len(ele.e_list) < num_sections {
		num_sections = len(ele.e_list)
	}

	/*
		//# initialize results for output
		idx_array := np.ones(num_sections) * (-1)
		sec_array := np.ones(num_sections) * (-1)
		prc_array := np.ones(num_sections) * (-1)

		//# collect results
		for idx in range(num_sections){
			idx_array[idx] = e_list[idx][0]
			sec_array[idx] = e_list[idx][1]
			prc_array[idx] = e_list[idx][2]
		}
	*/

	//# return results as a tuple
	return ele.e_list[:num_sections]
}

func (ele *Elevator) GetSectionStats(num_sections int) []SimpleRegResult {
	//# get statistics associated with each section
	//# if num_sections is not given then it's set to default
	if num_sections == 0 {
		num_sections = ele.num_sections
	}

	//# collect all stats
	ele.s_list = ele.s_list[:0]
	ele.s_list = append(ele.s_list, ele.stat_deque...)

	//# append price deque 1
	if len(ele.price_deque1) > 0 {
		ele.list_for_calc = ele.list_for_calc[:0]
		ele.list_for_calc = append(ele.list_for_calc, ele.price_deque1...)

		if len(ele.price_deque2) > 0 {
			ele.list_for_calc = append(ele.list_for_calc, ele.price_deque2[0])
			//# output is (beta, rsq)
			var regRes SimpleRegResult
			if len(ele.list_for_calc) > 1 {
				regRes = calc_beta_rsq(ele.list_for_calc)
			} else {
				regRes = SimpleRegResult{0, 0, 0, 0}
			}
			//TODO: tmp.append(ele.aux_sum1)
			ele.s_list = append(ele.s_list, regRes)
		}
	}
	//# append price deque 2
	if len(ele.price_deque2) > 0 {
		ele.list_for_calc = ele.list_for_calc[:0]
		ele.list_for_calc = append(ele.list_for_calc, ele.price_deque2...)
		//# output is (beta, rsq)
		var regRes SimpleRegResult
		if len(ele.list_for_calc) > 1 {
			regRes = calc_beta_rsq(ele.list_for_calc)
		} else {
			regRes = SimpleRegResult{0, 0, 0, 0}
		}
		//TODO: tmp.append(ele.aux_sum2)
		ele.s_list = append(ele.s_list, regRes)
	}

	//#reverse it
	for i, j := 0, len(ele.s_list)-1; i < j; i, j = i+1, j-1 {
		tmp := ele.s_list[i]
		ele.s_list[i] = ele.s_list[j]
		ele.s_list[j] = tmp
	}

	//# truncate if not enough sections
	if len(ele.s_list) < num_sections {
		num_sections = len(ele.s_list)
	}

	/*
		result = np.zeros([ele.num_aux_vars+4, num_sections])

		for idx in range(num_sections){
			result[0, idx] = s_list[idx][0]
			result[1, idx] = s_list[idx][1]
			result[2, idx] = s_list[idx][2]
			try{
				result[3, idx] = s_list[idx][3]
			}
			except IndexError{
				print idx, s_list[idx]
				raise IndexError
			}
			result[4:, idx] = s_list[idx][4]
		}
	*/

	return ele.s_list[:num_sections]
}

func (ele *Elevator) GetAllSections() []*IdxSecPrice {
	return ele.GetSections(len(ele.extrema_deque) + 2)
}

func (ele *Elevator) GetAllSectionStats() []SimpleRegResult {
	return ele.GetSectionStats(len(ele.extrema_deque) + 2)
}

type SmoothElevator struct {
	Elevator

	kernel_width             float64
	smooth_method            string
	smooth_order             int
	original_price_deque     []SecPrice
	price_deque_for_smoother []SecPrice
	smooth_price_deque       []SecPrice
}

func (ele *SmoothElevator) Init(num_sections int, thres float64, num_aux_vars int, kernel_width float64, smooth_method string, smooth_order int) {
	ele.kernel_width = kernel_width
	if smooth_method == "" {
		ele.smooth_method = "tri-cube"
	} else {
		ele.smooth_method = smooth_method
	}
	ele.smooth_order = smooth_order

	ele.original_price_deque = make([]SecPrice, 0)
	ele.price_deque_for_smoother = make([]SecPrice, 0)
	ele.smooth_price_deque = make([]SecPrice, 0)

	ele.Elevator.Init(num_sections, thres, num_aux_vars)
}

func (ele *SmoothElevator) Update(sec_epoch float64, price float64, aux_array MU.Vector) bool {
	ele.original_price_deque = append(ele.original_price_deque, SecPrice{sec_epoch, price})
	ele.price_deque_for_smoother = append(ele.price_deque_for_smoother, SecPrice{sec_epoch, price})
	for ele.price_deque_for_smoother[0].SecEpoch <= sec_epoch-ele.kernel_width {
		ele.price_deque_for_smoother = ele.price_deque_for_smoother[1:] // pop left
	}
	smooth_price := smoother(ele.price_deque_for_smoother,
		ele.kernel_width,
		ele.smooth_method,
		ele.smooth_order)
	ele.smooth_price_deque = append(ele.smooth_price_deque, SecPrice{sec_epoch, smooth_price})
	//fmt.Printf("ELELL,%.2f,%f,%f\n", sec_epoch, price, smooth_price)
	return ele.Elevator.Update(sec_epoch, smooth_price, aux_array)
}
