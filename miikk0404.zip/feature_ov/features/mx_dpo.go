package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"log"
	"math"
)

// DPO: Detrended Price Oscillator (DPO)

/////////////////////////////////////////
// DPOItem
type DPOItem struct {
	IntervalValue
	prcEMA *MXEMA
}

const DPOCPNAME = "MXDPO"

var DPOCPNames = []string{"prcEma.wgt", "prcEma.sum", "prcEma.t"}

func (item *DPOItem) ToCP() []interface{} {
	r := []interface{}{
		item.prcEMA.wgt,
		item.prcEMA.sum,
		item.prcEMA.t}
	if len(r) != len(DPOCPNames) {
		log.Panicf("DPOItem CP value size(%d) != CP names size(%d)\n", len(r), len(DPOCPNames))
	}
	return r
}

func (item *DPOItem) FromCP(v []interface{}) {
	item.prcEMA.wgt = v[0].(float64)
	item.prcEMA.sum = v[1].(float64)
	item.prcEMA.t = v[2].(float64)
}

func (item *DPOItem) String() string {
	return fmt.Sprintf("last=%f prcEma=[%s] ", item.V, item.prcEMA)
}

// return true if corp action factor != 1.
func (item *DPOItem) OVRoll(ca, emaTime float64) bool {
	r := false
	if math.Abs(1.-ca) > 1e-8 {
		item.prcEMA.sum *= ca
		r = true
	}
	item.prcEMA.t -= emaTime
	item.Scale(ca)
	return r
}

var _ OVIterm = (*DPOItem)(nil)

/////////////////////////////////////////
// Term: MXDPO
type MXDPO struct {
	OVBase

	// DPO
	items []*DPOItem
	hl    float64
	debug bool
}

var (
	DPOTermnamesDebug = []string{"last", "prcEma", ""}
	DPOTermnames      = []string{""}
)

// prefs_name, feature_name, log_dir, datestr
func (t *MXDPO) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *MXDPO) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	t.UpdateCPInfo(t, DPOCPNAME, DPOCPNames)
	return nil
}

func (t *MXDPO) TermName() string {
	return "MXDPO"
}

func (t *MXDPO) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *MXDPO) names() []string {
	if t.debug {
		return DPOTermnamesDebug
	}
	return DPOTermnames
}

func (t *MXDPO) inputs() []int {
	return []int{INPUT_MSG_TOB}
}

func (t *MXDPO) loadFeaturePrefs() error {
	t.hl = t.prefs.GetFloat64PrefWithDefault(t.featureName+".hl", 300)
	t.debug = t.prefs.GetBoolPref(t.featureName + ".debug")
	log.Printf("MXDPO half life=%f debug=%v\n", t.hl, t.debug)
	return nil
}

func (t *MXDPO) loadDailyStats() {
}

//setFeatureNames: set column names.
func (t *MXDPO) setFeatureNames() {
	t.colNames = t.names()
	for i, n := range t.colNames {
		if len(n) > 0 {
			t.colNames[i] = fmt.Sprintf("%s.%s.%s", t.featureName, n, HLFormat(t.hl))
			continue
		}
		t.colNames[i] = fmt.Sprintf("%s.%s", t.featureName, HLFormat(t.hl))
	}
}

//initialize internal variables
func (t *MXDPO) initInternalVars() {
	t.OVInit()
	t.items = make([]*DPOItem, t.nSids)
	for idx, _ := range t.items {
		t.items[idx] = &DPOItem{
			IntervalValue: NewIntervalValue(10),
			prcEMA:        NewMXEMA(t.hl, 1.)}
	}
}

func (t *MXDPO) TermUpdateTOB(sid int, secs float64, it OVIterm, tob *MsgTOB) {
	item := it.(*DPOItem)
	price := tob.LastOrRobust()
	if math.IsNaN(price) {
		return
	}

	item.prcEMA.Update(secs, price)
	item.Update(secs, price)
}

// snap
func (t *MXDPO) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*DPOItem)
	prcEma := item.prcEMA.GetEma()
	lag := item.At(secs)
	r := .0
	if prcEma > 0 {
		r = lag/prcEma - 1
	}

	if t.debug {
		res[0] = item.V
		res[1] = prcEma
		res[2] = r
	} else {
		res[0] = r
	}
}

var _ OVInterface = (*MXDPO)(nil)

func init() {
	TermFactoryInstance().Register("MX-DPO", func() ITerm { return &MXDPO{} })
}
