package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"log"
	"math"
)

// PCG: price center gravity

/////////////////////////////////////////
// PCGItem
type PCGItem struct {
	IntervalValue
	roll      []float64
	last      float64
	rollValid bool
	buff      []float64
}

const CG_SIZE = 30
const PCGCPNAME = "MXPCG"

var PCGCPNames = []string{"prc.roll", "last"}

func (item *PCGItem) ToCP() []interface{} {
	// copy last CG_SIZE IntervalValue to roll
	if item.Length() >= CG_SIZE {
		for i := 0; i < CG_SIZE; i++ {
			ri := CG_SIZE - i - 1
			item.roll[ri] = item.AtIdx(item.lastIndex - i)
		}
	}
	r := []interface{}{&item.roll, item.last}
	if len(r) != len(PCGCPNames) {
		log.Panicf("PCGItem CP value size(%d) != CP names size(%d)\n", len(r), len(PCGCPNames))
	}
	return r
}

func (item *PCGItem) FromCP(v []interface{}) {
	for idx, i := range v[0].([]interface{}) {
		v := i.(float64)
		if v == 0 {
			// all zero roll
			break
		}
		item.roll[idx] = i.(float64)
		item.rollValid = true
	}
	item.last = v[1].(float64)
}

func (item *PCGItem) String() string {
	return fmt.Sprintf("%T", item)
}

// return true if corp action factor != 1.
func (item *PCGItem) OVRoll(ca, emaTime float64) bool {
	r := false
	if math.Abs(1.-ca) > 1e-8 {
		for idx, v := range item.roll {
			item.roll[idx] = v * ca
		}
		item.last *= ca
		r = true
	}
	return r
}

var _ OVIterm = (*PCGItem)(nil)

/////////////////////////////////////////
// Term: MXPCG
type MXPCG struct {
	OVBase

	// PCG
	items []*PCGItem
}

// prefs_name, feature_name, log_dir, datestr
func (t *MXPCG) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *MXPCG) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	t.UpdateCPInfo(t, PCGCPNAME, PCGCPNames)
	return nil
}

func (t *MXPCG) TermName() string {
	return "MXPCG"
}

func (t *MXPCG) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *MXPCG) names() []string {
	return []string{""}
}

func (t *MXPCG) inputs() []int {
	return []int{INPUT_MSG_TOB}
}

func (t *MXPCG) loadFeaturePrefs() error {
	return nil
}

func (t *MXPCG) loadDailyStats() {
}

//setFeatureNames: set column names.
func (t *MXPCG) setFeatureNames() {
	t.colNames = t.names()
	for i, _ := range t.colNames {
		t.colNames[i] = t.featureName
	}
}

//initialize internal variables
func (t *MXPCG) initInternalVars() {
	t.OVInit()
	t.items = make([]*PCGItem, t.nSids)
	for idx, _ := range t.items {
		t.items[idx] = &PCGItem{
			IntervalValue: NewIntervalValue(10),
			roll:          make([]float64, CG_SIZE),
			buff:          make([]float64, CG_SIZE),
		}
	}
}

func (t *MXPCG) TermUpdateTOB(sid int, secs float64, it OVIterm, tob *MsgTOB) {
	item := it.(*PCGItem)
	price := tob.LastOrRobust()
	if math.IsNaN(price) {
		return
	}
	item.Update(secs, price)
	item.last = price
}

// snap
func CenterGravity(iprc []float64) float64 {
	if len(iprc) != CG_SIZE {
		log.Panicf("invalid price array size=%d", len(iprc))
	}
	numerator := .0
	denominator := .0
	for i := 0; i < CG_SIZE; i++ {
		numerator += float64(i+1) * iprc[i]
		denominator += iprc[i]
	}
	if denominator == 0 {
		return 0
	}
	return numerator / denominator
}

func (t *MXPCG) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*PCGItem)
	cg := 0.
	if item.Length() >= CG_SIZE {
		iprc := item.Slice(item.Length()-CG_SIZE, item.Length())
		cg = CenterGravity(iprc)
	} else if item.rollValid {
		borrow := CG_SIZE - item.Length()
		for i := 0; i < CG_SIZE; i++ {
			if i < borrow {
				rIdx := CG_SIZE - borrow + i
				item.buff[i] = item.roll[rIdx]
			} else {
				rIdx := i - borrow
				item.buff[i] = item.AtIdx(rIdx)
			}
		}
		cg = CenterGravity(item.buff)
	} else {
		cg = CG_SIZE / 2
	}
	res[0] = -cg
}

var _ OVInterface = (*MXPCG)(nil)

func init() {
	TermFactoryInstance().Register("MX-PCG", func() ITerm { return &MXPCG{} })
}
