package feature

import (
	"fmt"
	"incremental/function"
	"math"
	"math/rand"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"table"
	"time"

	"golang.org/x/sys/unix"

	"TES/QR/alpha_ov/data"
	tu "TES/tesUtilsGo"
	"TES/tesUtilsGo/common"

	"incremental/function/median"
	"incremental/input"
)

/*
This impl does not work on some NFS/NAS
https://stackoverflow.com/questions/20026320/how-to-tell-if-folder-exists-and-is-writable
func IsPathWritable(path string) bool {
	return unix.Access(path, unix.W_OK) == nil
}
*/
func IsPathWritable(path string) bool {
	return unix.Faccessat(unix.AT_FDCWD, path, unix.W_OK, unix.AT_SYMLINK_NOFOLLOW) == nil
}

var chinaEquityIndexes = []int{data.SidCSI300, data.SidCSI500}

const NumStatsFeatures = 5

type EquitySampler struct {
	prefs       *tu.PreferenceAdapter
	prefName    string
	samplerName string
	datestr     string
	dateint     int
	secMorning  float64

	// related to tickupdate and frequently updated
	inTrading    data.TradingSessionInfo
	eventType    []SEvent
	flbBook      map[int]*data.FixedLevelBook
	seenDayEvent map[int]bool //ukey -> bool(has seen day event) map

	//mode SamplerMode // NOTE: EquitySampler/Alpha does not have SamplerMode

	sampler_file_fmt string

	sidUniverse          []int
	sidUniverseWithIndex []int

	fmidMap map[int]int // raw sid -> fmid

	tickSize   map[int]float64 // sid -> property
	toRatio    map[int]float64
	toRatioIdx map[int]int
	curMMIdx   map[int]int

	toRatioMedian function.Function

	featureNameList        []string                    //feature names sorted alphabetically
	featureDict            map[string]FeatureInterface //feature abbrev name -> feature object map
	smoothPriceBaseFeature string                      //NOTE: empty string denotes None

	// general prefs
	panelRoot        string // for daily & minute data
	outputDir        string // strictly speaking this is outputRoot, the dir is a date subdir under this root
	logDir           string
	sEventsStr       []string
	sEvents          []SEvent
	publishEventsStr []string
	publishEvents    []SEvent
	timerIntv        int
	numLevels        int

	//
	sampling_end_time int64

	timerIntvNum map[int]int //sid -> index map

	// output related
	header     string
	outputFile string

	numFeatures      int
	featurePosOffset []int
	outputMatrix     [][]float64
	outputSessionNum []int

	// fields for extra features
	extraFeatureNameList  []string
	extraNumFeatures      int
	extraFeaturePosOffset []int
	extraOutputMatrix     [][]float64

	DoAppendData bool // TODO: this is a hacking field, thinking about how to do dynamic dispatch gracefully

	// GroupSampler Specific:
	baseSidList     []int
	baseSidListName string
	baseSidSet      map[int]bool

	// equity specific
	active_sid_list []int
	active_sid_set  map[int]bool

	prev_day_avg_size   map[int]float64
	prev_day_volatility map[int]float64
	prev_day_volume     map[int]float64

	prev_minute_avg_size    *data.MinuteTable
	prev_minute_avg_size_01 *data.MinuteTable
	prev_minute_avg_size_99 *data.MinuteTable
	prev_minute_turnover    *data.MinuteTable

	oaInput []float64

	industry_type string // "l3" (default) or "l1"
	industry_code map[int]int
	concept_codes map[int][]int

	baseSidWgts map[int]float64
	regWgts     map[int]float64

	downSampleRate map[int]float64 // session -> down sample rate

	// temp variables/fields for some features
	bookStatusSlice []float64
}

func (spl *EquitySampler) loadDailyStats() {
	spl.prev_day_avg_size = make(map[int]float64)
	spl.prev_day_volatility = make(map[int]float64)
	spl.prev_day_volume = make(map[int]float64)

	prevdate := common.PreTradeDate(spl.datestr)

	spl.prev_day_avg_size = data.GetSidValueMapFromPanelData("daily-rollstats", prevdate, "00:00:00", "avg_top_size.rw22")
	spl.prev_day_avg_size = data.ConformSidValueMap(spl.prev_day_avg_size, spl.sidUniverse, 0.0)

	spl.prev_day_volatility = data.GetSidValueMapFromPanelData("daily-rollstats", prevdate, "00:00:00", "variance.rw22")
	spl.prev_day_volatility = data.ConformSidValueMap(spl.prev_day_volatility, spl.sidUniverse, 0.0)

	spl.prev_day_volume = data.GetSidValueMapFromPanelData("daily-rollstats", prevdate, "00:00:00", "volume.rw22")
	spl.prev_day_volume = data.ConformSidValueMap(spl.prev_day_volume, spl.sidUniverse, 0.0)

}

func (spl *EquitySampler) loadMinuteStats() {
	prevdate := common.EquityPrevBusdateRemoveMissingDates(spl.datestr)
	spl.prev_minute_avg_size = data.GetMinuteTableFromPanelData("minute-rollstats", prevdate, "topsize50.rw22")
	spl.prev_minute_avg_size_01 = data.GetMinuteTableFromPanelData("minute-rollstats", prevdate, "topsize01.rw22")
	spl.prev_minute_avg_size_99 = data.GetMinuteTableFromPanelData("minute-rollstats", prevdate, "topsize99.rw22")
	spl.prev_minute_turnover = data.GetMinuteTableFromPanelData("minute-rollstats", prevdate, "turnover.rw22")
}

func (spl *EquitySampler) loadIndustryCodes() {
	var industryInfoMap map[int][]common.EqIndustryInfo
	if spl.industry_type == "" || spl.industry_type == "l3" {
		industryInfoMap = common.EqIndustryInfoMap
		fmt.Printf("EquitySampler.loadIndustryCodes: Use L3 industry (original) in EquitySampler\n")
	} else if spl.industry_type == "l1" {
		industryInfoMap = common.EqIndustryL1InfoMap
		fmt.Printf("EquitySampler.loadIndustryCodes: Use L1 industry in EquitySampler\n")
	} else {
		panic(fmt.Sprintf("Unknown industry_type: %s", spl.industry_type))
	}

	spl.industry_code = make(map[int]int)
	industry2id := make(map[int]int)
	iid := 0
	for _, sid := range spl.baseSidList {
		records := industryInfoMap[sid]
		for _, record := range records {
			if record.StartDate <= spl.dateint {
				if id, ok := industry2id[record.IndustryCode]; ok {
					spl.industry_code[sid] = id
				} else {
					spl.industry_code[sid] = iid
					industry2id[record.IndustryCode] = iid
					iid++
				}
				break
			}
		}
	}
}

func (spl *EquitySampler) loadConceptCodes() {
	spl.concept_codes = make(map[int][]int)
	concept2id := make(map[string]int)
	cid := 0
	for _, sid := range spl.baseSidList {
		conceptStrs := common.ConceptsLookupBySid(sid, spl.dateint)
		for _, conceptStr := range conceptStrs {
			if id, ok := concept2id[conceptStr]; ok {
				spl.concept_codes[sid] = append(spl.concept_codes[sid], id)
			} else {
				spl.concept_codes[sid] = append(spl.concept_codes[sid], cid)
				concept2id[conceptStr] = cid
				cid++
			}
		}
	}
}

func (spl *EquitySampler) loadIndexWeight() {
	//NOTE: load both baseSidWgts and regWgts
	var wgt_list, wgt_list2 []common.EqIndexWeights
	if spl.baseSidListName == "hs300" {
		wgt_list, _ = common.HS300IndexWeightMap[spl.dateint]
	} else if spl.baseSidListName == "zz500" {
		wgt_list, _ = common.ZZ500IndexWeightMap[spl.dateint]
	} else if spl.baseSidListName == "csi800" || spl.baseSidListName == "topx" || spl.baseSidListName == "non300" ||
		spl.baseSidListName == "midx" || spl.baseSidListName == "botx" {
		wgt_list, _ = common.HS300IndexWeightMap[spl.dateint]
		wgt_list2, _ = common.ZZ500IndexWeightMap[spl.dateint]
	} else {
		panic(fmt.Sprintf("Unrecognized sidListName in loadIndexWeight: %s", spl.baseSidListName))
	}

	spl.baseSidWgts = make(map[int]float64)
	spl.regWgts = make(map[int]float64)

	if spl.baseSidListName == "hs300" || spl.baseSidListName == "zz500" {
		if len(wgt_list) > 0 {
			// find min wgt, used to fill non-index names
			min := wgt_list[0].Weight
			for i := 1; i < len(wgt_list); i++ {
				min = math.Min(min, wgt_list[i].Weight)
			}
			for _, sid := range spl.baseSidList {
				found := false
				for _, record := range wgt_list {
					if sid == record.SID {
						spl.baseSidWgts[sid] = record.Weight
						found = true
						break
					}
				}
				if !found {
					spl.baseSidWgts[sid] = min
				}
			}

		} else {
			for _, sid := range spl.baseSidList {
				spl.baseSidWgts[sid] = 1.0
			}
		}
		// regWgt is the same as index weight
		spl.regWgts = spl.baseSidWgts
	} else { // mixed universe
		// baseSidWgts (use free-floating mv as weight)
		pdate := common.EquityPrevBusdateRemoveMissingDates(spl.datestr)
		sid2freemv := data.GetSidValueMapFromPanelData("cap", pdate, "00:00:00", "free.mv")
		sid2freemv = data.ConformSidValueMap(sid2freemv, spl.baseSidList, 0)
		minValue := 1e15
		sum := 0.0
		for _, value := range sid2freemv {
			if value > 0 && value < minValue {
				minValue = value
			}
			sum += value
		}
		for sid, value := range sid2freemv {
			if value > 0 {
				spl.baseSidWgts[sid] = value / sum
			} else {
				spl.baseSidWgts[sid] = minValue / sum
			}
		}

		// regWgt (use hs300 and zz500 index weight as weight)
		defaultRegWgt := 0.0
		for _, record := range wgt_list2 {
			defaultRegWgt += record.Weight
		}
		defaultRegWgt = defaultRegWgt / float64(len(wgt_list2)) / 3 // 1/3 of the mean zz500 weight seems reasonable

		for _, sid := range spl.baseSidList {
			found := false
			// find in hs300
			for _, record := range wgt_list {
				if sid == record.SID {
					spl.regWgts[sid] = record.Weight
					found = true
					break
				}
			}
			if !found {
				// find in zz500
				for _, record := range wgt_list2 {
					if sid == record.SID {
						spl.regWgts[sid] = record.Weight
						found = true
						break
					}
				}
			}
			// still not found, use default regwgt
			if !found {
				spl.regWgts[sid] = defaultRegWgt
			}
		}
	}
}

func (spl *EquitySampler) Init(prefName string, samplerName string, datestr string, isAlphaReplay bool) {
	spl.DoAppendData = true
	//# preferences are loaded from file
	fmt.Println("EquitySampler prefs_name: ", prefName)
	spl.prefs = tu.NewPreferenceAdapter(prefName)
	spl.prefName = prefName
	spl.samplerName = samplerName
	if datestr == "" {
		spl.datestr = spl.prefs.GetStringPref("date")
	} else {
		spl.datestr = datestr
	}
	spl.dateint, _ = strconv.Atoi(spl.datestr)
	if spl.dateint <= 19700000 || spl.dateint >= 20500000 {
		panic(fmt.Sprintf("datestr must be a 8-digit string and be within [19700000, 20500000]"))
	}
	//# mark whether a day event has been seen
	spl.seenDayEvent = make(map[int]bool)
	spl.LoadGeneralPrefs()
	spl.loadFmidMap()

	// Do heavy initialization stuff when not replaying alpha
	if !isAlphaReplay {
		spl.createOutputDir()
		spl.LoadSamplerPrefs() // dynamic dispatch
		spl.SetHeader()        // dynamic dispatch
		//# daily stats file root

		//spl.dailyRoot = spl.prefs.GetStringPref("daily_root")
		//spl.minuteRoot = spl.prefs.GetStringPref("minute_root")
		//spl.minuteRw = spl.prefs.GetIntPref("minute_rolling_window")

		spl.loadDailyStats()
		spl.loadMinuteStats()
		//# tick size
		spl.tickSize = make(map[int]float64)
		//# ratio of up to last minute market turnover versus historical value
		spl.toRatio = make(map[int]float64)
		spl.toRatioMedian = median.NewMedianFunc(nil)
		//# index of available minute
		spl.toRatioIdx = make(map[int]int)
		//# current minute index
		spl.curMMIdx = make(map[int]int)
		for _, sid := range spl.sidUniverse {
			spl.tickSize[sid] = common.SecMasterMap[sid].TickSize
			spl.toRatio[sid] = 1
			spl.toRatioIdx[sid] = 0
			spl.curMMIdx[sid] = 0
		}

		spl.loadIndustryCodes()
		spl.loadConceptCodes()

		/*
			// dump industry and concept
			sids := make([]int, len(spl.baseSidList))
			copy(sids, spl.baseSidList)
			sort.Ints(sids)
			fmt.Printf("INDUSTRY\n")
			for _, sid := range sids {
				fmt.Printf("%d:%d\n", sid, spl.industry_code[sid])
			}
			fmt.Printf("CONCEPT\n")
			for _, sid := range sids {
				cs := spl.concept_codes[sid]
				fmt.Printf("%d",sid)
				for _, c := range cs {
					fmt.Printf(",%d",c)
				}
				fmt.Printf("\n")
			}
		*/

		for _, fn := range spl.featureNameList {
			spl.featureDict[fn].SetIndustryAndConcept(spl.industry_code, spl.concept_codes)
			spl.featureDict[fn].SetWeight(spl.baseSidWgts)
			// NOTE: this is the second time to call initInternalVars() method
			//       because the first time does not init weight/industry/concept
			spl.featureDict[fn].initInternalVars()
		}
	}

	// flbBook and eventType are both updated by tick
	// init flbBook and pre-allocate eventType
	spl.flbBook = make(map[int]*data.FixedLevelBook)
	spl.eventType = make([]SEvent, 0, 10)

	//# morning
	secondsEastOfUTC := int((8 * time.Hour).Seconds())
	beijing := time.FixedZone("Beijing Time", secondsEastOfUTC)
	date2MinuteStr := fmt.Sprintf("%s0930", datestr)
	t, _ := time.ParseInLocation("200601021504", date2MinuteStr, beijing)
	spl.secMorning = float64(t.Unix())
	//# output_data is used to store results
	spl.outputMatrix = make([][]float64, 0)
	spl.extraOutputMatrix = make([][]float64, 0)

	spl.active_sid_set = make(map[int]bool)
	spl.active_sid_list = make([]int, 0)
}

func (spl *EquitySampler) getOutputFileName(sessionNumber int) string {
	outputFile := filepath.Join(spl.outputDir, spl.datestr, fmt.Sprintf("%s_s%d.%s", spl.samplerName, sessionNumber, spl.sampler_file_fmt))
	return outputFile
}

func (spl *EquitySampler) createOutputDir() {
	// Create output dir
	outputDir := filepath.Join(spl.outputDir, spl.datestr)
	if _, err := os.Stat(outputDir); err != nil { //path not exist
		err := os.MkdirAll(outputDir, os.ModePerm)
		if err != nil {
			msg := fmt.Sprintf("cannot create folder %s; pleae check permission.", outputDir)
			panic(msg)
		}
	} else {
		// path already exists, test if it is writable
		if !IsPathWritable(spl.outputDir) {
			panic(fmt.Sprintf("I don't have write access to the output folder: %s", spl.outputDir))
		}
	}

	// Copy prefs file to output directory
	localFn := filepath.Join(spl.outputDir, fmt.Sprintf("%s.prefs", spl.samplerName))
	_, err := tu.Copy(spl.prefName, localFn, true)
	if err != nil {
		tu.Logger.Error(fmt.Sprintf("cannot copy prefs file %s to %s", spl.prefName, localFn))
	}
}

func (spl *EquitySampler) setupTimer() {
	spl.timerIntvNum = make(map[int]int)
}

func (spl *EquitySampler) LoadGeneralPrefs() {
	//# load output_dir
	spl.outputDir = spl.prefs.GetStringPref("output_dir")

	//# panel root
	spl.panelRoot = spl.prefs.GetStringPref("panel_root")
	data.SetPanelRoot(spl.panelRoot)

	//# load sampling events
	spl.sEventsStr = spl.prefs.GetStringListPref("sampling_events")
	spl.sEvents = SEventsFromStringSlice(spl.sEventsStr)
	if InSEventSlice(TIMER, spl.sEvents) {
		spl.timerIntv = spl.prefs.GetIntPref("timer_interval")
		spl.setupTimer()
	}
	//# order book number of levels
	spl.numLevels = spl.prefs.GetIntPref("FLB_num_levels")
	if spl.prefs.HasPref("sampling_end_time") {
		spl.sampling_end_time = spl.prefs.GetInt64Pref("sampling_end_time")
	} else {
		spl.sampling_end_time = 160000000
	}

	//# base sid is the sid we want to predict
	if spl.prefs.HasPref("base_sid_list") {
		spl.baseSidList = spl.prefs.GetIntListPref("base_sid_list")
	} else {
		spl.baseSidList = make([]int, 0)
	}

	spl.baseSidListName = spl.prefs.GetStringPref("base_sid_list_name")

	if len(spl.baseSidList) != 0 && spl.baseSidListName != "" {
		panic("Only one of base_sid_list and base_sid_list_name needs to be set.")
	}

	if len(spl.baseSidList) == 0 {
		spl.baseSidList = common.GetSidListByNameNew(spl.datestr, spl.baseSidListName, data.PanelRoot)
	}

	if len(spl.baseSidList) == 0 {
		tu.Logger.Fatal(fmt.Sprintf("alpha sid list empty."))
	}

	fmt.Printf("Number of sids in Sampler: %d\n", len(spl.baseSidList))

	// mirror a set for base_sid_list
	spl.baseSidSet = make(map[int]bool)
	for _, sid := range spl.baseSidList {
		spl.baseSidSet[sid] = true
	}

	spl.sidUniverse = spl.baseSidList
	spl.sidUniverseWithIndex = append(spl.sidUniverse, chinaEquityIndexes...)

	// output fmt
	if spl.prefs.HasPref("sampler_file_fmt") {
		spl.sampler_file_fmt = spl.prefs.GetStringPref("sampler_file_fmt")
		if spl.sampler_file_fmt != "zstd" && spl.sampler_file_fmt != "tbl" {
			panic(fmt.Sprintf("Unknown sampler_file_fmt: %s", spl.sampler_file_fmt))
		}
	} else {
		// default output fmt
		spl.sampler_file_fmt = "zstd"
	}
}

func (spl *EquitySampler) LoadSamplerPrefs() {
	//# feature values are published at publish events
	spl.publishEventsStr = spl.prefs.GetStringListPref("publish_events")
	spl.publishEvents = SEventsFromStringSlice(spl.publishEventsStr)

	spl.industry_type = spl.prefs.GetStringPref("industry_type")

	spl.loadIndexWeight()

	/*
		# load feature list
		# IMPORTANT:
		# feature name is just an alias
		# note that the feature class name here should be the full name so that
		# class instances can be instantiated by str_to_class
		# UNLESS it's under feature module in which case only the short name
		# is needed
	*/

	spl.featureDict = make(map[string]FeatureInterface)

	loadOneFeatureName := func(fn string) {
		className := spl.prefs.GetStringPref(fmt.Sprintf("%s_class_name", fn))
		prefsName := spl.prefs.GetStringPref(fmt.Sprintf("%s_prefs_name", fn))
		spl.featureDict[fn] = NewFeatureInst(prefsName, fn, className, spl.logDir, spl.datestr)
		if fn == "FWDMRET" || fn == "OVFWDRET" {
			spl.featureDict[fn].SetSidUniverse(spl.sidUniverseWithIndex[0], spl.sidUniverseWithIndex[1:])
		} else {
			spl.featureDict[fn].SetSidUniverse(spl.sidUniverse[0], spl.sidUniverse[1:])
		}
	}

	//NOTE: featureNameList is Python version's feature_name_tuple
	spl.featureNameList = spl.prefs.GetStringListPref("feature_list")
	sort.Strings(spl.featureNameList)
	for _, fn := range spl.featureNameList {
		loadOneFeatureName(fn)
	}

	if spl.prefs.HasPref("smooth_price_base_feature") {
		spl.smoothPriceBaseFeature = spl.prefs.GetStringPref("smooth_price_base_feature")
	} else {
		spl.smoothPriceBaseFeature = ""
	}

	// init extra feature list
	spl.extraFeatureNameList = spl.prefs.GetStringListPref("extra_feature_list")
	sort.Strings(spl.extraFeatureNameList)
	for _, efn := range spl.extraFeatureNameList {
		loadOneFeatureName(efn)
	}

	for _, sid := range spl.sidUniverse {
		spl.seenDayEvent[sid] = false
	}

	// down sample rate
	downSampleRateSpec := spl.prefs.GetStringPref("down_sample_rate")
	spl.downSampleRate = make(map[int]float64)
	if downSampleRateSpec != "" {
		fields := strings.Split(downSampleRateSpec, ",")
		for _, field := range fields {
			s := strings.Split(field, ":")
			session, _ := strconv.Atoi(s[0])
			rate, _ := strconv.ParseFloat(s[1], 64)
			if session >= 1 && session <= 5 && rate >= 0 && rate <= 1 {
				spl.downSampleRate[session] = rate
			} else {
				panic(fmt.Sprintf("Wrong down_sample_rate spec: %s", downSampleRateSpec))
			}
		}
	}
}

func (spl *EquitySampler) loadFmidMap() {
	m, err := common.MakeFmidMap(spl.sidUniverseWithIndex, spl.datestr)
	if err != nil {
		fmt.Printf("ERROR: %s\n", err.Error())
	}
	spl.fmidMap = m.Rsid2fmid
}

func (spl *EquitySampler) SetHeader() {
	//# output header is created here

	spl.header = "sid,rec_epoch,ex_time,date,open,prev-vol,adv,avg-size,index_wgt,to-ratio-group,to-ratio,tp-ratio"

	// normal feature names
	spl.numFeatures = 0
	spl.featurePosOffset = make([]int, len(spl.featureNameList))
	var allFeatureNames []string
	for i, fn := range spl.featureNameList {
		spl.featurePosOffset[i] = spl.numFeatures
		spl.numFeatures += len(spl.featureDict[fn].GetFeatureNames())
		allFeatureNames = append(allFeatureNames, spl.featureDict[fn].GetFeatureNames()...)
	}

	// extra feature names
	spl.extraNumFeatures = 0
	spl.extraFeaturePosOffset = make([]int, len(spl.extraFeatureNameList))
	var allExtraFeatureNames []string
	for i, efn := range spl.extraFeatureNameList {
		spl.extraFeaturePosOffset[i] = spl.extraNumFeatures
		spl.extraNumFeatures += len(spl.featureDict[efn].GetFeatureNames())
		allExtraFeatureNames = append(allExtraFeatureNames, spl.featureDict[efn].GetFeatureNames()...)
	}

	// standard header + all normal features + day_session + all extra features
	spl.header = spl.header + "," + strings.Join(allFeatureNames, ",") + ",day_session"
	if spl.extraNumFeatures > 0 {
		spl.header = spl.header + "," + strings.Join(allExtraFeatureNames, ",")
	}
}

func timeint_to_minute(timeint int64) (res int) {
	hmm := int(timeint) / 100000
	if hmm < 930 {
		res = 0
	} else if hmm < 1000 {
		res = hmm - 930 + 1
	} else if hmm < 1100 {
		res = hmm - 1000 + 31
	} else if hmm < 1130 {
		res = hmm - 1130 + 91
	} else if hmm < 1300 {
		res = 120
	} else if hmm < 1400 {
		res = hmm - 1300 + 121
	} else if hmm < 1500 {
		res = hmm - 1400 + 181
	} else {
		res = 240
	}

	return
}

func (spl *EquitySampler) OnTickdataUpdate(td *data.TesTOBSlice) bool {
	//defer profstats.Prof.TocWithBegin("BasicSampler", time.Now())

	// reset the slice (but will reuse the memory)
	spl.eventType = spl.eventType[:0]

	rawSid := td.Sid
	sid := spl.fmidMap[rawSid]

	//# update order book
	if _, ok := spl.flbBook[sid]; !ok {
		spl.flbBook[sid] = data.NewFixedLevelBook(rawSid, spl.numLevels, 0)
	}
	updateResult := spl.flbBook[sid].Update(td)

	if !updateResult {
		if td.ExTimeInt > 92500000 && td.ExTimeInt < 150000000 {
			tu.Logger.Error(fmt.Sprintf("Bad update: problematic time or volume. %d at %.3f", sid, td.ExTimestamp()))
		}
		return false
	}
	book := spl.flbBook[sid]

	// OA feature, update until 09:31
	if feature, ok := spl.featureDict["ZOA"]; ok && td.ExTimeInt < 93100000 {
		if len(spl.oaInput) == 0 {
			spl.oaInput = make([]float64, 7)
		}
		spl.oaInput[0] = book.CumVol
		spl.oaInput[1] = td.CumTo
		spl.oaInput[2] = book.PrevClose
		spl.oaInput[3] = book.GetLastPrice()
		spl.oaInput[4] = book.GetAskSize()
		spl.oaInput[5] = book.GetBidSize()
		spl.oaInput[6] = book.GetAskPrice()
		feature.UpdateSecValueSlice(sid, book.ExTimestamp, spl.oaInput)
	}

	// The following is for normal trading time, which defined as srcTime >= 09:30
	spl.inTrading = book.IsInTrading()
	if !spl.inTrading.InTrading {
		//msg = 'Not in trading hour. {} at {}-{}'
		//self.logger.debug(msg.format(sid, self.datestr, td.ex_time_int))
		return false
	}

	// ForwardStats features are independent of sampling_end_time
	// FWDRET gets the data independent of the event check
	if feature, ok := spl.featureDict["FWDRET"]; ok {
		mid := book.GetMidPrice()
		adj_src_epoch := common.SubtractBreakSeconds(book.ExTimestamp, spl.secMorning, book.EID)
		feature.UpdateSecValue(sid, adj_src_epoch, mid)
	}
	if feature, ok := spl.featureDict["FWDMRET"]; ok {
		var price float64
		if sid == data.SidCSI300 || sid == data.SidCSI500 {
			price = book.GetLastPrice()
		} else {
			price = book.GetMidPrice()
		}
		adj_src_epoch := common.SubtractBreakSeconds(book.ExTimestamp, spl.secMorning, book.EID)
		feature.UpdateSecValue(sid, adj_src_epoch, price)
	}
	if feature, ok := spl.featureDict["OVFWDRET"]; ok {
		var price float64
		if sid == data.SidCSI300 || sid == data.SidCSI500 {
			price = book.GetLastPrice()
		} else {
			price = book.GetMidPrice()
		}
		feature.UpdateSecValue(sid, book.ExTimestamp, price)
	}
	if feature, ok := spl.featureDict["BOOKST"]; ok {
		if len(spl.bookStatusSlice) == 0 {
			spl.bookStatusSlice = make([]float64, 5)
		}
		spl.bookStatusSlice[0] = book.GetAskPrice()
		spl.bookStatusSlice[1] = book.GetBidPrice()
		spl.bookStatusSlice[2] = book.GetAskSize()
		spl.bookStatusSlice[3] = book.GetBidSize()
		spl.bookStatusSlice[4] = book.CumVol
		feature.UpdateValueSlice(sid, spl.bookStatusSlice)
	}

	if td.ExTimeInt > spl.sampling_end_time {
		return false
	}

	var isFirstDayEvent bool
	if spl.inTrading.InTrading && !spl.seenDayEvent[sid] {
		isFirstDayEvent = true
		spl.seenDayEvent[sid] = true
	} else {
		isFirstDayEvent = false
	}

	if !spl.active_sid_set[sid] {
		spl.active_sid_set[sid] = true
		spl.active_sid_list = append(spl.active_sid_list, sid)
	}

	//# update turnover ratio
	spl.curMMIdx[sid] = timeint_to_minute(td.ExTimeInt)
	if spl.curMMIdx[sid] > spl.toRatioIdx[sid] {
		if spl.prev_minute_turnover.HasSid(sid) {
			pto := spl.prev_minute_turnover.Get(sid, spl.curMMIdx[sid]-1)

			if math.IsNaN(pto) || math.IsInf(pto, 0) {
				spl.toRatio[sid] = 1
			} else {
				spl.toRatio[sid] = td.CumTo / pto
			}

			spl.toRatioMedian.Update(&input.Data{0, sid, spl.toRatio[sid]})
		}
		spl.toRatioIdx[sid] = spl.curMMIdx[sid]
	}

	//# check SEvent.AGG event
	if book.IsAggPriceValid(0.04) {
		spl.eventType = append(spl.eventType, AGG)
	}
	//# check SEvent.TRADE event
	if book.IsTradeEvent() {
		spl.eventType = append(spl.eventType, TRADE)
	}
	//# check SEvent.PRICE
	if book.IsPriceEvent() || (isFirstDayEvent && book.IsValidPriceEvent()) {
		spl.eventType = append(spl.eventType, PRICE)
	}

	//# check SEvent.QUOTE
	if book.IsQuoteEvent() || (isFirstDayEvent && book.IsValidQuoteEvent()) {
		spl.eventType = append(spl.eventType, QUOTE)
	}

	//# check SEvent.TIMER
	if book.IsValidQuoteEvent() &&
		spl.timerIntvNum != nil { //<==> if SEvent.TIMER in self.s_events
		if _, ok := spl.timerIntvNum[sid]; !ok {
			spl.timerIntvNum[sid] = 0
		}
		srcEpoch := book.ExTimestamp
		tmp := int(math.Floor(srcEpoch / float64(spl.timerIntv)))
		if tmp > spl.timerIntvNum[sid] {
			spl.timerIntvNum[sid] = tmp
			spl.eventType = append(spl.eventType, TIMER)
		}
	}

	if !SEventIsIntersect(spl.sEvents, spl.eventType) {
		return false
	}

	return true
}

//TODO: refactor this as a feature
func (spl *EquitySampler) CalcStats(sid int, openPrice float64, topSize float64) []float64 {
	if openPrice < 0 {
		openPrice = 0
	}

	prevVola := spl.prev_day_volatility[sid]
	avgSize := openPrice * spl.prev_day_avg_size[sid]

	toRatioMedian := spl.toRatioMedian.CalcValue().(float64)
	toRatio := spl.toRatio[sid]

	avgMinuteSize := spl.prev_minute_avg_size.Get(sid, spl.curMMIdx[sid])

	var tpRatio float64
	if !math.IsNaN(avgMinuteSize) && avgMinuteSize > 0 {
		tpRatio = topSize / avgMinuteSize
	} else {
		tpRatio = 1.0
	}

	return []float64{
		prevVola,
		avgSize,
		toRatioMedian,
		toRatio - toRatioMedian,
		tpRatio,
	}
}

func (spl *EquitySampler) appendOutputData(sid int, book *data.FixedLevelBook) {
	//defer profstats.Prof.TocWithBegin("appendOutputD", time.Now())
	//# retrieve receive time stamp for calculating EMA
	origRecEpoch := book.RecSecSinceEpoch
	adjRecEpoch := common.SubtractBreakSeconds(origRecEpoch, spl.secMorning, book.EID)
	//# retrieve source time stamp for calculating lagging returns
	srcEpoch := book.ExTimestamp
	//# features are calculated based on bid/ask price/sizes
	priceM := book.GetMidPrice()
	//# only append output_data at PUBLISH events
	inTrading := spl.inTrading.InTrading
	if inTrading &&
		priceM > 0 &&
		spl.baseSidSet[sid] &&
		SEventIsIntersect(spl.eventType, spl.publishEvents) {

		openPrice := book.Open
		if openPrice < 0 {
			openPrice = 0
		}

		adv := spl.prev_day_volume[sid]
		idxWgt := spl.regWgts[sid] // index_wgt field in sampler output is regWgt instead

		stats := spl.CalcStats(sid, book.Open, book.GetTopSize())

		fields := make([]float64, 12+spl.numFeatures+1)
		fields[0] = float64(sid)
		fields[1] = book.RecSecSinceEpoch
		fields[2] = float64(book.ExTimeInt)
		fields[3] = float64(spl.dateint)
		fields[4] = openPrice
		fields[5] = stats[0]
		fields[6] = adv
		fields[7] = stats[1]
		fields[8] = idxWgt
		fields[9] = stats[2]
		fields[10] = stats[3]
		fields[11] = stats[4]
		fieldIdx := 12

		extraFields := make([]float64, spl.extraNumFeatures)
		extraFieldIdx := 0

		calculateOneFeature := func(fn string, isExtra bool) {
			var vals []float64
			vals, _ = spl.featureDict[fn].GetSidValues(sid, priceM, adjRecEpoch)
			numExpectedVals := len(spl.featureDict[fn].GetFeatureNames())
			if numExpectedVals != len(vals) {
				msg := fmt.Sprintf("feature %s expects %d values, but get %v", fn, numExpectedVals, vals)
				panic(msg)
			}
			if isExtra {
				for _, val := range vals {
					extraFields[extraFieldIdx] = val
					extraFieldIdx++
				}
			} else {
				for _, val := range vals {
					fields[fieldIdx] = val
					fieldIdx++
				}
			}
		}

		// calculate each feature and append each's values
		for _, fn := range spl.featureNameList {
			//profstats.Prof.Tic("c" + fn)
			calculateOneFeature(fn, false)
			//profstats.Prof.Toc("c" + fn)
		}

		// calculate each extra feature
		for _, efn := range spl.extraFeatureNameList {
			calculateOneFeature(efn, true)
		}

		//# add day_session
		sessionNumber := spl.SessionNumber(srcEpoch)
		fields[fieldIdx] = float64(sessionNumber)

		// Append a row
		spl.outputMatrix = append(spl.outputMatrix, fields)
		spl.extraOutputMatrix = append(spl.extraOutputMatrix, extraFields)
		spl.outputSessionNum = append(spl.outputSessionNum, sessionNumber)
	}
}

func (spl *EquitySampler) SessionNumber(srcEpoch float64) int {
	if srcEpoch-spl.secMorning <= 30*60 {
		//# 9:30 - 10:00
		return 1
	} else if srcEpoch-spl.secMorning <= 60*60 {
		//# 10:00 - 10:30
		return 2
	} else if srcEpoch-spl.secMorning <= 120*60 {
		//# 10:30 - 11:30
		return 3
	} else if srcEpoch-spl.secMorning <= 270*60 {
		//# 13:00 - 14:00
		return 4
	} else {
		//# 14:00-15:00
		return 5
	}
}

func (spl *EquitySampler) FinalizeExtraFeatures() {
	// finalize & revision (for Forward Stats)
	for featIdx, featName := range spl.extraFeatureNameList {
		spl.featureDict[featName].Finalize()
		revisionList := spl.featureDict[featName].GetRevisionList()
		if len(revisionList) > 0 {
			for _, update := range revisionList {
				spl.extraOutputMatrix[update.i][spl.extraFeaturePosOffset[featIdx]+update.j] = update.v
			}
		}
	}
}

func (spl *EquitySampler) PublishSamplerData() {
	books := len(spl.flbBook)
	fmt.Printf("Total books seens %d\n", books)

	spl.FinalizeExtraFeatures()
	// a temp array
	strs := make([]string, 12+spl.numFeatures+1+spl.extraNumFeatures)

	stringer := func(rowVec []float64, extraRowVec []float64) string {
		m := len(rowVec)
		// transform a row feature vector into a string
		for j, val := range rowVec {
			if j == 0 { // sid
				strs[j] = fmt.Sprintf("%.0f", val)
			} else if j == 1 { // rec_epoch
				strs[j] = fmt.Sprintf("%f", val)
			} else if j == 2 { // ex_time_int
				strs[j] = fmt.Sprintf("%.0f", val)
			} else if j == 3 { // date
				strs[j] = fmt.Sprintf("%.0f", val)
			} else if j == m-1 { // day_session
				strs[j] = fmt.Sprintf("%.0f", val)
			} else { // normal feature value
				strs[j] = fmt.Sprintf("%.6f", val)
			}
		}

		extraOff := 12 + spl.numFeatures + 1
		for j, val := range extraRowVec {
			strs[extraOff+j] = fmt.Sprintf("%g", val) // use %g for extra feature
		}

		rowStr := strings.Join(strs, ",")
		return rowStr
	}

	rand.Seed(37) // before publishing, set a fixed seed to the random generator

	session2matrix := make(map[int][][]float64)
	session2extraMatrix := make(map[int][][]float64)
	maxSession := 0
	for i, session := range spl.outputSessionNum {
		if maxSession < session {
			maxSession = session
		}
		if _, ok := session2matrix[session]; !ok {
			session2matrix[session] = make([][]float64, 0, 4000)
			session2extraMatrix[session] = make([][]float64, 0, 4000)
		}
		rate := spl.downSampleRate[session]
		if rate <= 0 || rate >= 1 || /* down sample enabled*/ rand.Float64() <= rate {
			session2matrix[session] = append(session2matrix[session], spl.outputMatrix[i])
			session2extraMatrix[session] = append(session2extraMatrix[session], spl.extraOutputMatrix[i])
		} else {
			//this sample is dropped
		}
	}

	writeTbl := func(header string, mat [][]float64, mat2 [][]float64, outputFile string) error {
		header_fields := strings.Split(header, ",")

		dt := table.NewDataTable(len(header_fields))
		dt.SetColNames(header_fields)
		dt.SetDefaultTypes(table.TYPE_F32)
		dt.SetColNameTypes([]string{"sid", "rec_epoch", "ex_time", "date"}, table.TYPE_F64)

		lineFields := make([]interface{}, len(header_fields))
		for i, row := range mat {
			row2 := mat2[i]
			for j := 0; j < len(row); j++ {
				lineFields[j] = row[j]
			}
			for j := 0; j < len(row2); j++ {
				lineFields[j+len(row)] = row2[j]
			}
			dt.AddRow(lineFields)
		}

		table.FWrite(outputFile, dt, table.COMPRESSION_ZSTD)
		return nil
	}

	for session := 1; session <= maxSession; session++ {
		outputFile := spl.getOutputFileName(session)
		var err error
		if spl.sampler_file_fmt == "zstd" {
			err = tu.DumpFloat64MatrixIntoZstdFile(spl.header, session2matrix[session], session2extraMatrix[session], stringer, outputFile)
		} else if spl.sampler_file_fmt == "tbl" {
			err = writeTbl(spl.header, session2matrix[session], session2extraMatrix[session], outputFile)
		}
		if err != nil {
			tu.Logger.Fatal(err.Error())
		} else {
			tu.Logger.Info(fmt.Sprintf("zstd sampler data for session %d dumped to %s", session, outputFile))
		}
	}
}

type EquityBookSampler struct {
	EquitySampler
}

func (spl *EquityBookSampler) Init(prefsName string, datestr string, isAlphaReply bool) {
	spl.EquitySampler.Init(prefsName, "EquityBookSampler", datestr, isAlphaReply)
}

func (spl *EquityBookSampler) OnTickDataUpdateUglyForward(td *data.TesTOBSlice) bool {
	return spl.OnTickDataUpdate(td)
}

func (spl *EquityBookSampler) OnTickDataUpdate(td *data.TesTOBSlice) bool {
	//defer profstats.Prof.TocWithBegin("EquitySamplerAll", time.Now())
	success := spl.EquitySampler.OnTickdataUpdate(td)
	if !success {
		return false
	}

	//# tickdata_replay passes in raw sid
	raw_sid := td.Sid
	//# need to convert it to generic sid if necessary
	sid := spl.fmidMap[raw_sid]
	//# retrieve book by generic sid
	book := spl.flbBook[sid]
	//# retrieve exchange time stamp for calculating lagging returns
	orig_src_epoch := book.ExTimestamp
	adj_src_epoch := common.SubtractBreakSeconds(orig_src_epoch, spl.secMorning, book.EID)

	//# do not update on first slice
	if book.IsFirstSlice {
		return false
	}

	//# returns are typically calculated as the change in mid_price
	m_price := book.GetMidPrice()
	if m_price <= 0 {
		return false
	}
	size_a := book.GetAskSize()
	size_b := book.GetBidSize()

	if !spl.prev_minute_avg_size_01.HasSid(sid) {
		return false
	}
	ts_lb := spl.prev_minute_avg_size_01.Get(sid, spl.curMMIdx[sid])
	ts_ub := spl.prev_minute_avg_size_99.Get(sid, spl.curMMIdx[sid])
	if math.IsNaN(ts_lb) || ts_lb < 100 {
		ts_lb = 100
	}
	if ts_ub < 100 {
		ts_ub = 100
	}
	size_a = math.Min(size_a, ts_ub)
	size_a = math.Max(size_a, ts_lb)
	size_b = math.Min(size_b, ts_ub)
	size_b = math.Max(size_b, ts_lb)
	avg_quote_size := (size_a + size_b) / 2.0

	delta_ask_liq, delta_bid_liq, taken_liq, sweep_level, new_line_list, cancel_line_list := book.GetDepthBookDeltaLiquidity()

	if false {
		fmt.Printf("NOT USED VARIABLES %v %v\n", new_line_list, cancel_line_list)
	}

	if InSEventSlice(TRADE, spl.eventType) || InSEventSlice(QUOTE, spl.eventType) {
		//# features that need to be updated at both TRADE and QUOTE
		//# features that depend on mid price
		if m_price != 0 {
			if feature, ok := spl.featureDict["LBR"]; ok {
				//profstats.Prof.Tic("uLBR")
				new_obs := []float64{m_price, book.PrevClose, book.Open}
				feature.UpdateSecValueSlice(sid, adj_src_epoch, new_obs)
				//profstats.Prof.Toc("uLBR")
			}
			if feature, ok := spl.featureDict["ELE"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELE0"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELES"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELEL"]; ok {
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
			}
			if feature, ok := spl.featureDict["ELEL0"]; ok {
				//profstats.Prof.Tic("uELEL0")
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
				//profstats.Prof.Toc("uELEL0")
			}
			if feature, ok := spl.featureDict["ELELL"]; ok {
				//profstats.Prof.Tic("uELELL")
				feature.UpdateSecValue(sid, adj_src_epoch, m_price)
				//profstats.Prof.Toc("uELELL")
			}
		}

		sizeSlice := []float64{size_b, size_a}
		//# features that do not depend on mid price
		if feature, ok := spl.featureDict["BAR"]; ok {
			//profstats.Prof.Tic("uBAR")
			feature.UpdateSecValueSlice(sid, adj_src_epoch, sizeSlice)
			//profstats.Prof.Toc("uBAR")
		}
		if feature, ok := spl.featureDict["BARD"]; ok {
			//profstats.Prof.Tic("uBARD")
			feature.UpdateSecValueSlice(sid, adj_src_epoch, sizeSlice)
			//profstats.Prof.Toc("uBARD")
		}
		if feature, ok := spl.featureDict["DAL"]; ok {
			//profstats.Prof.Tic("uDAL")
			feature.UpdateSecValue(sid, adj_src_epoch, delta_ask_liq)
			//profstats.Prof.Toc("uDAL")
		}
		if feature, ok := spl.featureDict["DBL"]; ok {
			//profstats.Prof.Tic("uDBL")
			feature.UpdateSecValue(sid, adj_src_epoch, delta_bid_liq)
			//profstats.Prof.Toc("uDQS")
		}
		if feature, ok := spl.featureDict["TL"]; ok {
			//profstats.Prof.Tic("uTL")
			feature.UpdateSecValue(sid, adj_src_epoch, taken_liq)
			//profstats.Prof.Toc("uTL")
		}
		if feature, ok := spl.featureDict["SL"]; ok {
			//profstats.Prof.Tic("uSL")
			feature.UpdateSecValue(sid, adj_src_epoch, sweep_level)
			//profstats.Prof.Toc("uSL")
		}
		if feature, ok := spl.featureDict["DALD"]; ok {
			//profstats.Prof.Tic("uDALD")
			feature.UpdateSecValue(sid, adj_src_epoch, delta_ask_liq)
			//profstats.Prof.Toc("uDALD")
		}
		if feature, ok := spl.featureDict["DBLD"]; ok {
			//profstats.Prof.Tic("uDBLD")
			feature.UpdateSecValue(sid, adj_src_epoch, delta_bid_liq)
			//profstats.Prof.Toc("uDBLD")
		}
		if feature, ok := spl.featureDict["TLD"]; ok {
			//profstats.Prof.Tic("uTLD")
			feature.UpdateSecValue(sid, adj_src_epoch, taken_liq)
			//profstats.Prof.Toc("uTLD")
		}
		if feature, ok := spl.featureDict["SLD"]; ok {
			//profstats.Prof.Tic("uSLD")
			feature.UpdateSecValue(sid, adj_src_epoch, sweep_level)
			//profstats.Prof.Toc("uSLD")
		}
		if feature, ok := spl.featureDict["DQS"]; ok {
			//profstats.Prof.Tic("uDQS")
			feature.UpdateSecValue(sid, adj_src_epoch, avg_quote_size)
			//profstats.Prof.Toc("uDQS")
		}

	}

	//# calculated detrended price
	mid_price_tick := math.Mod(m_price, spl.tickSize[sid]) //mid_price_tick = m_price % self.tick_size[sid]
	var smoothed_price float64
	//# use the smoothed price in ELE to adjust
	if spl.smoothPriceBaseFeature != "" {
		feature := spl.featureDict[spl.smoothPriceBaseFeature].(*Chartist)
		if feature.sidUniverse[sid] && len(feature.GetSmoothedPriceDeque(sid)) > 0 {
			smooth_price_deque := feature.GetSmoothedPriceDeque(sid)
			smoothed_price = math.Exp(smooth_price_deque[len(smooth_price_deque)-1].Price)
		} else {
			smoothed_price = m_price
		}
	} else {
		smoothed_price = m_price
	}
	adj_price := spl.tickSize[sid]*math.Floor(smoothed_price/spl.tickSize[sid]) + mid_price_tick
	// note: 1509413400.00,5.04(desired value: 5.05),smooth_price=5.039999999999999,ticksize=0.01,mid_price_tick0.00999999999999993
	// but math.Floor( (smoothed_price+1e-10) /spl.tickSize[sid]) has its own issues...

	//# features that need to be updated at QUOTE
	if InSEventSlice(QUOTE, spl.eventType) {
		max_size := spl.prev_minute_avg_size_99.Get(sid, spl.curMMIdx[sid])
		update_book := book.GetEquityQuoteDerivedBookUpdate(max_size)

		if feature, ok := spl.featureDict["LSB"]; ok {
			//profstats.Prof.Tic("uLSB")
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
			//profstats.Prof.Toc("uLSB")
		}
		if feature, ok := spl.featureDict["AB"]; ok {
			//profstats.Prof.Tic("uAB")
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
			//profstats.Prof.Toc("uAB")
		}
		if feature, ok := spl.featureDict["DLSB"]; ok {
			//profstats.Prof.Tic("uDLSB")
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, update_book, adj_price)
			//profstats.Prof.Toc("uDLSB")
		}
		if feature, ok := spl.featureDict["DAB"]; ok {
			//profstats.Prof.Tic("uDAB")
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, update_book, adj_price)
			//profstats.Prof.Toc("uDAB")
		}

		// Following three are not used in Equity now. D stands for NDiff
		if feature, ok := spl.featureDict["ABD"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["LSBD"]; ok {
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, update_book)
		}
		if feature, ok := spl.featureDict["DLSBD"]; ok {
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, update_book, adj_price)
		}
	}

	//# features that need to be updated at TRADE
	if InSEventSlice(TRADE, spl.eventType) {
		bd := book.GetEquityTradeDerivedBookDelta()
		trade_book, taken_book, sweep_book := bd.Trade_book, bd.Taken_book, bd.Sweep_book
		if feature, ok := spl.featureDict["TB"]; ok {
			//profstats.Prof.Tic("uTB")
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, trade_book)
			//profstats.Prof.Toc("uTB")
		}
		if feature, ok := spl.featureDict["TLB"]; ok {
			//profstats.Prof.Tic("uTLB")
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, taken_book)
			//profstats.Prof.Toc("uTLB")
		}
		if feature, ok := spl.featureDict["SLB"]; ok {
			//profstats.Prof.Tic("uSLB")
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, sweep_book)
			//profstats.Prof.Toc("uSLB")
		}
		if feature, ok := spl.featureDict["DTB"]; ok {
			//profstats.Prof.Tic("uDTB")
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, trade_book, adj_price)
			//profstats.Prof.Toc("uDTB")
		}
		if feature, ok := spl.featureDict["DTLB"]; ok {
			//profstats.Prof.Tic("uDTLB")
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, taken_book, adj_price)
			//profstats.Prof.Toc("uDTLB")
		}
		if feature, ok := spl.featureDict["DSLB"]; ok {
			//profstats.Prof.Tic("uDSLB")
			feature.UpdateSecPrcQtySliceAndValue(sid, adj_src_epoch, sweep_book, adj_price)
			//profstats.Prof.Toc("uDSLB")
		}
		if feature, ok := spl.featureDict["TLBD"]; ok {
			//profstats.Prof.Tic("uTLBD")
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, taken_book)
			//profstats.Prof.Toc("uTLBD")
		}
		if feature, ok := spl.featureDict["SLBD"]; ok {
			//profstats.Prof.Tic("uSLBD")
			feature.UpdateSecPrcQtySlice(sid, adj_src_epoch, sweep_book)
			//profstats.Prof.Toc("uSLBD")
		}

		//# features that depend on average price
		price_high, price_low, price_last, net_volume := book.GetEquityHighLowLast()

		hll := []float64{price_high, price_low, price_last}
		price_avg := (price_high + price_low + price_last) / 3

		if feature, ok := spl.featureDict["BB"]; ok {
			//profstats.Prof.Tic("uBB")
			feature.UpdateValue(sid, price_avg)
			//profstats.Prof.Toc("uBB")
		}
		if feature, ok := spl.featureDict["ADX"]; ok {
			//profstats.Prof.Tic("uADX")
			feature.UpdateSecValueSlice(sid, adj_src_epoch, hll)
			//profstats.Prof.Toc("uADX")
		}
		if feature, ok := spl.featureDict["CCI"]; ok {
			//profstats.Prof.Tic("uCCI")
			feature.UpdateValue(sid, price_avg)
			//profstats.Prof.Toc("uCCI")
		}
		if feature, ok := spl.featureDict["RSI"]; ok {
			//profstats.Prof.Tic("uRSI")
			feature.UpdateValue(sid, price_avg)
			//profstats.Prof.Toc("uRSI")
		}
		if feature, ok := spl.featureDict["TSI"]; ok {
			//profstats.Prof.Tic("uTSI")
			feature.UpdateValue(sid, price_avg)
			//profstats.Prof.Toc("uTSI")
		}
		if feature, ok := spl.featureDict["SOI"]; ok {
			//profstats.Prof.Tic("uSOI")
			feature.UpdateValueSlice(sid, hll)
			//profstats.Prof.Toc("uSOI")
		}

		//# unpack price, size and side from agg_trade
		t_size := book.AggTrade.Size //NOTE: t_price, t_side not used in this function
		nta := []float64{net_volume, t_size, avg_quote_size}

		if feature, ok := spl.featureDict["TOIE"]; ok {
			//profstats.Prof.Tic("uTOIE")
			feature.UpdateSecValueSlice(sid, adj_src_epoch, nta)
			//profstats.Prof.Toc("uTOIE")
		}
		if spl.smoothPriceBaseFeature != "" {
			chartist := spl.featureDict[spl.smoothPriceBaseFeature].(*Chartist)
			if chartist.sidUniverse[sid] {
				if feature, ok := spl.featureDict["TOIU"]; ok {
					//profstats.Prof.Tic("uTOIU")
					ele_is_up_trend := chartist.ExtremaIsMax(sid)
					if ele_is_up_trend {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, nta)
					}
					//profstats.Prof.Toc("uTOIU")
				}

				if feature, ok := spl.featureDict["TOID"]; ok {
					//profstats.Prof.Tic("uTOID")
					ele_is_up_trend := chartist.ExtremaIsMax(sid)
					if !ele_is_up_trend {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, nta)
					}
					//profstats.Prof.Toc("uTOID")
				}

				if feature, ok := spl.featureDict["TOIA"]; ok {
					//profstats.Prof.Tic("uTOIA")
					if m_price > smoothed_price {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, nta)
					}
					//profstats.Prof.Toc("uTOIA")
				}

				if feature, ok := spl.featureDict["TOIB"]; ok {
					//profstats.Prof.Tic("uTOIB")
					if m_price < smoothed_price {
						feature.UpdateSecValueSlice(sid, adj_src_epoch, nta)
					}
					//profstats.Prof.Toc("uTOIB")
				}
			}
		}

		adj_price_high := price_high - adj_price
		adj_price_low := price_low - adj_price
		adj_price_last := price_last - adj_price
		adj_price_avg := price_avg - adj_price

		ahll := []float64{adj_price_high, adj_price_low, adj_price_last}
		hlsnab := []float64{price_high, price_low, t_size, net_volume, size_a, size_b}
		if feature, ok := spl.featureDict["DADX"]; ok {
			//profstats.Prof.Tic("uDADX")
			feature.UpdateSecValueSlice(sid, adj_src_epoch, ahll)
			//profstats.Prof.Toc("uDADX")
		}
		if feature, ok := spl.featureDict["DRSI"]; ok {
			//profstats.Prof.Tic("uDRSI")
			feature.UpdateValue(sid, adj_price_avg)
			//profstats.Prof.Toc("uDRSI")
		}
		if feature, ok := spl.featureDict["DTSI"]; ok {
			//profstats.Prof.Tic("uDTSI")
			feature.UpdateValue(sid, adj_price_avg)
			//profstats.Prof.Toc("uDTSI")
		}
		if feature, ok := spl.featureDict["DSOI"]; ok {
			//profstats.Prof.Tic("uDSOI")
			feature.UpdateValueSlice(sid, ahll)
			//profstats.Prof.Toc("uDSOI")
		}
		if feature, ok := spl.featureDict["DVOL"]; ok {
			//profstats.Prof.Tic("uDVOL")
			feature.UpdateSecValue(sid, adj_src_epoch, t_size)
			//profstats.Prof.Toc("uDVOL")
		}
		if feature, ok := spl.featureDict["DRNG"]; ok {
			//profstats.Prof.Tic("uDRNG")
			feature.UpdateSecValue(sid, adj_src_epoch, price_high)
			//profstats.Prof.Toc("uDRNG")
		}
		if feature, ok := spl.featureDict["HPE"]; ok {
			//profstats.Prof.Tic("uHPE")
			feature.UpdateSecValueSlice(sid, adj_src_epoch, hlsnab)
			//profstats.Prof.Toc("uHPE")
		}
	}

	if spl.DoAppendData {
		spl.appendOutputData(sid, book)
	}
	return true
}

func RunEquityBookSampler(samplerPrefsFile string, datestr string) {
	// create sampler object
	spl := &EquityBookSampler{}
	//profstats.Prof.Tic("EqSamplerInit")
	spl.Init(samplerPrefsFile, datestr, false)
	//profstats.Prof.Toc("EqSamplerInit")

	// new replay object
	replay := data.NewFLBTickDataReplay(samplerPrefsFile, datestr, true)

	//register three callback functions
	replay.RegisterSetup(func(sidList []int) {
		fmt.Printf("I am in EquitySampler Setup and I see %d sids are available from the 'replay' center: \n", len(sidList))
		for i, sid := range sidList {
			if len(sidList) < 10 || i < 6 || i > len(sidList)-4 {
				fmt.Printf("%d ", sid)
			} else if len(sidList) >= 10 && i == 6 {
				fmt.Printf("... ")
			}
		}
		fmt.Println()
	})

	replay.RegisterTickdataUpdate(func(slice *data.TesTOBSlice) {
		spl.OnTickDataUpdate(slice)
	}, spl.sidUniverseWithIndex)

	replay.RegisterTeardown(spl.PublishSamplerData)

	// event loop
	replay.Replay()
}
