package feature

import (
	tu "TES/tesUtilsGo"
	"autosupply/bookmsg"
	"autosupply/cons"
	"autosupply/model"
	"encoding/csv"
	"fmt"
	"io"
	"math"
	"os"
	"strings"
	"time"
)

type FutIR struct {
	dateStr string

	SymEndDate map[string]string

	// future sid
	IHSids []int
	IFSids []int
	ICSids []int

	// index future prc/end dates
	FutPrc      map[int]float64 // fut sid -> prc
	FutDaysLeft map[int]int     // fut sid -> Days remaining from dateStr(Including holidays)

	// index prc
	IdxPrc map[int]float64 // index sid -> index prc
}

func NewFutIR(dateStr string) *FutIR {
	return &FutIR{
		dateStr: dateStr,

		FutPrc:      map[int]float64{},
		FutDaysLeft: map[int]int{},
		IdxPrc:      map[int]float64{},
	}
}

func (f *FutIR) InitSymEndDate() {
	file, err := os.Open("cons.SymEndDateFile") //todo:
	if err != nil {
		panic(err)
	}
	defer file.Close()

	symEndDates := make(map[string]string)
	reader := csv.NewReader(file)
	for {
		fields, err := reader.Read()
		if err != nil {
			if err == io.EOF {
				break
			} else {
				panic(err)
			}
		}

		symEndDates[fields[0]] = fields[1]
	}

	f.SymEndDate = symEndDates
}

func GetDiffDays(date1Str, date2Str string) int {
	//20190311 09:30:04.852940
	date1, err := time.ParseInLocation("20060102", date1Str, time.Local)
	if err != nil {
		panic(err)
	}
	date2, err := time.ParseInLocation("20060102", date2Str, time.Local)
	if err != nil {
		panic(err)
	}

	return int(math.Abs(date2.Sub(date1).Hours())) / 24
}

func (f *FutIR) InitIdxFut() {
	f.IdxPrc[cons.Hs300Sid] = 0
	f.IdxPrc[cons.Zz500Sid] = 0
	f.IdxPrc[cons.Sh50Sid] = 0

	sym2sid := map[string]int{}
	file, err := os.Open("cons.SidInfoFile") //todo:
	if err != nil {
		panic(err)
	}
	defer file.Close()
	csvReader := csv.NewReader(file)
	for {
		fields, err := csvReader.Read()
		if err != nil {
			if err == io.EOF {
				break
			}
			panic(err)
		}

		if fields[2] == "FUTURE" && fields[3] == "CFFEX" {
			sym2sid[fields[1]] = tu.ToInt(fields[0])
		}
	}

	// find IC01
	symIC01 := ""
	for sym, dateStr := range f.SymEndDate {
		if strings.Contains(sym, "IC") && f.dateStr <= dateStr {
			if symIC01 == "" || sym <= symIC01 {
				symIC01 = sym
			}
		}
	}

	monthMap := map[string][]int{
		"01": {0, 1, 2, 5},
		"02": {0, 1, 4, 7},
		"03": {0, 1, 3, 6},
		"04": {0, 1, 2, 5},
		"05": {0, 1, 4, 7},
		"06": {0, 1, 3, 6},
		"07": {0, 1, 2, 5},
		"08": {0, 1, 4, 95},
		"09": {0, 1, 3, 94},
		"10": {0, 1, 2, 93},
		"11": {0, 1, 92, 95},
		"12": {0, 89, 91, 94},
	}

	// IC2012
	month := symIC01[4:]
	yearMonth := tu.ToInt(symIC01[2:])

	ICSids := make([]int, 4, 4)
	IFSids := make([]int, 4, 4)
	IHSids := make([]int, 4, 4)
	prefixList := []string{"IC", "IF", "IH"}
	fmt.Printf("IC01--IC04 for date:%s, is:\n", f.dateStr)
	for i := 0; i < 4; i++ {
		suffix := tu.ToString(yearMonth + monthMap[month][i])
		for j, prefix := range prefixList {
			sym := prefix + suffix

			var diffDays = 0
			if endDateStr, ok := f.SymEndDate[sym]; ok {
				diffDays = GetDiffDays(f.dateStr, endDateStr)
			}

			if j == 0 {
				fmt.Printf("\t sym:%s, left days:%d\n", sym, diffDays)
			}

			if sid, ok := sym2sid[sym]; ok {
				f.FutDaysLeft[sid] = diffDays
				switch j {
				case 0:
					ICSids[i] = sid
				case 1:
					IFSids[i] = sid
				case 2:
					IHSids[i] = sid
				}
			}
		}
	}
	f.IFSids = IFSids
	f.IHSids = IHSids
	f.ICSids = ICSids
}

// symbol support IH01-IH04, IC01-IC04, IF01-IF04
func (f *FutIR) GetIR(symbol string) float64 {
	if len(symbol) != 4 {
		panic(fmt.Sprintf(`[GetIR] cannot parse symbol :%s`, symbol))
	}
	id := tu.ToInt(symbol[2:]) - 1
	if id < 0 || id >= 4 {
		panic(fmt.Sprintf(`[GetIR] cannot parse symbol :%s`, symbol))
	}
	var sid int
	var idxPrc float64
	switch symbol[:2] {
	case "IC":
		sid = f.ICSids[id]
		idxPrc = f.IdxPrc[cons.Zz500Sid]
	case "IF":
		sid = f.IFSids[id]
		idxPrc = f.IdxPrc[cons.Hs300Sid]
	case "IH":
		sid = f.IHSids[id]
		idxPrc = f.IdxPrc[cons.Sh50Sid]
	default:
		panic(fmt.Sprintf(`[GetIR] cannot parse symbol :%s`, symbol))
	}

	futPrc := f.FutPrc[sid]
	dayLefts := f.FutDaysLeft[sid]

	if futPrc > 0 && idxPrc > 0 {
		t := float64(dayLefts+1) * 1.0 / 365
		return math.Log(futPrc/idxPrc) / t
	}

	return math.NaN()
}

func (f *FutIR) Start() {
	f.InitSymEndDate()
	f.InitIdxFut()
}

func (f *FutIR) OnMsg(data model.IMsg) {
	switch msg := data.(type) {
	case *bookmsg.FLBEndBatchMsg:
		sid := msg.Sid
		if _, ok := f.FutDaysLeft[sid]; ok {
			f.FutPrc[sid] = msg.Extra.(*bookmsg.ChinaFutureSnapshotExtra).LastPrice
		}

		if _, ok := f.IdxPrc[sid]; ok {
			f.IdxPrc[sid] = msg.Extra.(*bookmsg.ChinaIndexSnapshotExtra).LastPrice
		}
	default:
		// Do not process
	}
}

func (f *FutIR) Final() {
	//do nothing
}
