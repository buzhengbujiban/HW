package feature

import (
	"TES/tesUtilsGo"
	"autosupply/bookmsg"
	"bufio"
	"bytes"
	"fmt"
	"log"
	"math"
	"os"
	"panel"
	"path"
	"strconv"
	"strings"
	"sync"
	"time"
	xa "xarray"
)

/*****************************************
 * utils
 */

const (
	INPUT_BOOKSIZE      = 1
	INPUT_SNAPSHOT_BOOK = 2
	INPUT_MSG_TOB       = 3
	INPUT_MSG_TRADE     = 4
	INPUT_MSG_INDEX     = 5
)

const (
	INPUT_MSG_TOB_N   = 13
	INPUT_MSG_TRADE_N = 3
	INPUT_MSG_INDEX_N = 3
)

func NetNormal(b, s float64) float64 {
	if b == 0 && s == 0 {
		return 0
	}
	return (b - s) / (b + s)
}

func CorZero(x, y []float64) float64 {
	s := len(x)
	if len(y) < s {
		s = len(y)
	}

	xSS := 0.
	ySS := 0.
	xyS := 0.
	for i := 0; i < s; i++ {
		xSS += x[i] * x[i]
		ySS += y[i] * y[i]
		xyS += x[i] * y[i]
	}
	ss := math.Sqrt(xSS) * math.Sqrt(ySS)
	if ss == 0 {
		return 0
	}
	return xyS / ss
}

func SafeSqrt(v float64) float64 {
	if v == 0 {
		return v
	}
	if v < 0 {
		return -math.Sqrt(math.Abs(v))
	}

	return math.Sqrt(v)
}

func PathExists(p string) bool {
	if _, err := os.Stat(p); err != nil {
		return false
	}
	return true
}

const (
	FIRST_OPEN              = 5400                // 09:30
	FIRST_CLOSE             = 12600               // 11:30
	SECOND_OPEN             = 18000               // 13:00
	SECOND_CLOSE            = (14-8)*3600 + 57*60 // 25020, 14:57
	SECOND_CHN_TO_GMT       = 8 * 3600
	FIRST_OPEN_SINCE_OPEN   = 0
	FIRST_CLOSE_SINCE_OPEN  = FIRST_CLOSE - FIRST_OPEN
	SECOND_OPEN_SINCE_OPEN  = FIRST_CLOSE_SINCE_OPEN
	SECOND_CLOSE_SINCE_OPEN = SECOND_CLOSE - SECOND_OPEN + (FIRST_CLOSE - FIRST_OPEN)
	OV_DECAY_SECONDS        = 7200 // 2 hours
)

func SecondsFromHHMMSS(timeSpec string) float64 {
	if len(timeSpec) == 0 {
		return 0
	}
	hour, _ := strconv.Atoi(timeSpec[:2])
	min, _ := strconv.Atoi(timeSpec[3:5])
	sec, _ := strconv.Atoi(timeSpec[6:])
	return float64(hour*3600 + min*60 + sec)
}

func SecsSinceOpen(epoch float64) float64 {
	seconds := math.Mod(epoch, 86400)
	passed := seconds - FIRST_OPEN
	if seconds < FIRST_CLOSE {
		return passed
	}
	lunchbreak := math.Min(seconds, SECOND_OPEN) - FIRST_CLOSE
	return passed - lunchbreak
}

func SecsPrettyFormat(seconds float64) string {
	var secs int64 = int64(seconds) // convert(Int64, secs)
	var buffer bytes.Buffer         // IOBuffer()
	hour := secs / 3600
	minute := secs % 3600 / 60
	second := secs % 3600 % 60
	if hour > 0 {
		fmt.Fprintf(&buffer, "%dh", hour)
	}
	if minute > 0 {
		fmt.Fprintf(&buffer, "%dm", minute)
	}
	if second > 0 {
		fmt.Fprintf(&buffer, "%ds", second)
	}
	return buffer.String()
}

var HLFormat = SecsPrettyFormat

func HMS_S(seconds float64) string {
	secs := int64(math.Floor(seconds))
	hour := secs / 3600
	minute := secs % 3600 / 60
	second := secs % 3600 % 60
	return fmt.Sprintf("%02d:%02d:%02d", hour, minute, second)
}

// ###########################################
const MX_LOG2 = 0.6931472

type MXEMA struct {
	hl      float64
	wgt     float64
	sum     float64
	t       float64
	normFac float64
}

func NewMXEMA(hl float64, tickSec float64) *MXEMA {
	return &MXEMA{
		hl:      hl,
		wgt:     0,
		sum:     0,
		t:       0,
		normFac: (1 - math.Pow(2, (-tickSec/hl))) / tickSec,
	}
}

func (e *MXEMA) Reset() {
	e.sum = 0
	e.wgt = 0
	e.t = 0
}

func (e *MXEMA) Update(epochSec float64, x float64) {
	if math.IsNaN(x) || math.IsInf(x, 0) { //20221110 add math.IsInf(x, 0)
		return
	}
	if e.t >= epochSec {
		epochSec = e.t
	}

	secSinceLast := epochSec - e.t
	e.t = epochSec

	n_halfs := secSinceLast / e.hl
	decay := 0.0
	if n_halfs <= 20 {
		decay = math.Exp(-n_halfs * MX_LOG2)
	}

	e.sum = e.sum*decay + x
	if math.Abs(e.sum) < 1e-10 {
		e.sum = 0
	}

	e.wgt = e.wgt*decay + 1
}

func (e *MXEMA) CalcDecay(epochSec float64) float64 {
	secSinceLast := 0.0
	if epochSec > e.t {
		secSinceLast = epochSec - e.t
	}
	n_halfs := secSinceLast / e.hl
	decay := 0.0
	if n_halfs <= 20 {
		decay = math.Exp(-n_halfs * MX_LOG2)
	}
	return decay
}

func (e *MXEMA) GetEms(epochSec float64) float64 {
	return e.sum * e.CalcDecay(epochSec)
}

func (e *MXEMA) GetEma() float64 {
	if e.wgt != 0 {
		return e.sum / e.wgt
	} else {
		return 0
	}
}

func (e *MXEMA) GetEmsNormed(epochSec float64) float64 {
	return e.GetEms(epochSec) * e.normFac
}

func (e *MXEMA) GetEmaDecayed(epochSec float64) float64 {
	return e.GetEma() * e.CalcDecay(epochSec)
}

func (e *MXEMA) String() string {
	return fmt.Sprintf("ema=%f ems=%f sum=%f wgt=%f t=%f", e.GetEma(), e.GetEms(e.t), e.sum, e.wgt, e.t)
}

func (e *MXEMA) Marshal() []interface{} {
	return []interface{}{e.wgt, e.sum, e.t}
}

func (e *MXEMA) Unmarshal(v []interface{}, i int) int {
	e.wgt = v[i].(float64)
	e.sum = v[i+1].(float64)
	e.t = v[i+2].(float64)
	return i + 3
}

/**********************************
 * pathenv
 */
var (
	CN_SEC_ROOT, CNEQ_PANEL_ROOT               string
	SID_INFO_FILE, FMID_FILE, EX_HOUR_FILE     string
	INDEX_DIR, UNIV_DIR, INDUSTRY1_DIR         string
	CONCEPT_DIR, CAP_DIR, DAILY_DIR            string
	DAILY_ROLL_STAS_DIR, MINUTE_DIR, BARRA_DIR string
	CORPACTION_DIR                             string
)

func LookupEnvD(key, def string) string {
	if v, ok := os.LookupEnv(key); ok {
		return v
	} else {
		return def
	}
}

func JoinTwo(a, b string) string {
	return strings.Join([]string{a, b}, "")
}

func init() {
	CN_SEC_ROOT = LookupEnvD("CN_SEC_ROOT", "/data/nas2Data/secdata")
	log.Println("PathEnv init CN_SEC_ROOT", CN_SEC_ROOT)

	CNEQ_PANEL_ROOT = LookupEnvD("CNEQ_PANEL_ROOT", "/data/nas2Data/chinaEquityData/panel")
	log.Println("PathEnv init CNEQ_PANEL_ROOT", CNEQ_PANEL_ROOT)

	// SID_INFO_FILE = JoinTwo(CN_SEC_ROOT, "/sid_info.csv")
	// log.Println("PathEnv init SID_INFO_FILE", SID_INFO_FILE)
	// FMID_FILE = JoinTwo(CN_SEC_ROOT, "/fmidMap.csv")
	// log.Println("PathEnv init FMID_FILE", FMID_FILE)
	// EX_HOUR_FILE = JoinTwo(CN_SEC_ROOT, "/exchange_hours.csv")
	// log.Println("PathEnv init EX_HOUR_FILE", EX_HOUR_FILE)
	INDEX_DIR = JoinTwo(CNEQ_PANEL_ROOT, "/index")
	log.Println("PathEnv init INDEX_DIR", INDEX_DIR)
	UNIV_DIR = JoinTwo(CNEQ_PANEL_ROOT, "/univ")
	log.Println("PathEnv init UNIV_DIR", UNIV_DIR)
	// INDUSTRY1_DIR = JoinTwo(CNEQ_PANEL_ROOT, "/industry1")
	// log.Println("PathEnv init INDUSTRY1_DIR", INDUSTRY1_DIR)
	// CONCEPT_DIR = JoinTwo(CNEQ_PANEL_ROOT, "/concept")
	// log.Println("PathEnv init CONCEPT_DIR", CONCEPT_DIR)
	// CAP_DIR = JoinTwo(CNEQ_PANEL_ROOT, "/cap")
	// log.Println("PathEnv init CAP_DIR", CAP_DIR)
	DAILY_DIR = JoinTwo(CNEQ_PANEL_ROOT, "/daily")
	log.Println("PathEnv init DAILY_DIR", DAILY_DIR)
	// DAILY_ROLL_STAS_DIR = JoinTwo(CNEQ_PANEL_ROOT, "/daily-rollstats")
	// log.Println("PathEnv init DAILY_ROLL_STAS_DIR", DAILY_ROLL_STAS_DIR)
	MINUTE_DIR = JoinTwo(CNEQ_PANEL_ROOT, "/1min")
	log.Println("PathEnv init MINUTE_DIR", MINUTE_DIR)
	BARRA_DIR = JoinTwo(CNEQ_PANEL_ROOT, "/barra")
	log.Println("PathEnv init BARRA_DIR", BARRA_DIR)
	CORPACTION_DIR = JoinTwo(CNEQ_PANEL_ROOT, "/daily-adjusted-2007")
	log.Println("PathEnv init CORPACTION_DIR", CORPACTION_DIR)
}

/*
 * PanelSDIV
 */
type PanelSDIV struct {
	*xa.XArray
	S []string
	D []string
	I []string
	V []string
}

const DAILY_I = "24:00:00"

func (x *PanelSDIV) CreateRaw(S, D, I, V []string) {
	x.S, x.D, x.I, x.V = S, D, I, V
	size := len(x.S) * len(x.D) * len(x.I) * len(x.V)
	data := make([]float64, size)
	for i, _ := range data {
		data[i] = math.NaN()
	}
	x.XArray = xa.New(
		xa.WithShape(len(x.S), len(x.D), len(x.I), len(x.V)),
		xa.WithDims("S", "D", "I", "V"),
		xa.WithArray(data),
		xa.WithCoords(
			xa.Coord("S", x.S...),
			xa.Coord("D", x.D...),
			xa.Coord("I", x.I...),
			xa.Coord("V", x.V...)),
	)
}

func (x *PanelSDIV) CreateDaily(S []string, date string, V []string) {
	x.CreateRaw(S, []string{date}, []string{DAILY_I}, V)
}

func (x *PanelSDIV) CreateDailyInt(S []int, date string, V []string) {
	Sstr := make([]string, len(S))
	for i, sid := range S {
		Sstr[i] = strconv.Itoa(sid)
	}
	x.CreateDaily(Sstr, date, V)
}

func (x *PanelSDIV) Write(p string) error {
	return panel.Panel.WriteSdivV2(p, x.XArray, panel.COMPRESSION_LZ4)
}

/*
 * Read Wrapper
 */
type DIContext struct {
	*PanelSDIV
	IdxD int
	IdxI int
}

func (x *DIContext) DI(sidx, vidx int) float64 {
	return x.At(sidx, x.IdxD, x.IdxI, vidx)
}

type SDIContext struct {
	*DIContext
	IdxS int
}

func (x *SDIContext) SDI(vidx int) float64 {
	if x.IdxS < 0 {
		return math.NaN()
	}
	return x.DI(x.IdxS, vidx)
}

func (x *SDIContext) SDIstr(v string) float64 {
	if x.IdxS < 0 {
		return math.NaN()
	}
	vidx := x.LabelIndex("V", v)
	return x.DI(x.IdxS, vidx)
}

type SDVContext struct {
	*PanelSDIV
	IdxS int
	IdxD int
	IdxV int
}

// THIS IS COPYING the data
func (x *SDVContext) SDV() []float64 {
	if x.IdxS < 0 {
		return []float64{}
	}
	isize := len(x.Coords()["I"])
	r := make([]float64, isize)
	for i := 0; i < isize; i++ {
		r[i] = x.SDVint(i)
	}
	return r
}

func (x *SDVContext) SDVint(iidx int) float64 {
	if x.IdxS < 0 {
		return math.NaN()
	}
	return x.At(x.IdxS, x.IdxD, iidx, x.IdxV)
}

func (x *SDVContext) SDVstr(i string) float64 {
	if x.IdxS < 0 {
		return math.NaN()
	}
	idx := x.LabelIndex("I", i)
	return x.At(x.IdxS, x.IdxD, idx, x.IdxV)
}

/*
 * Daily cache
 */
type PanelCache struct {
	cache map[string]*PanelSDIV
}

func (x *PanelCache) Read(fn string) *PanelSDIV {
	p, ok := x.cache[fn]
	if ok {
		return p
	}
	start := time.Now()
	a, err := panel.Panel.ReadSdiv(fn, "S", "D", "I", "V")
	if err != nil {
		panic(err)
	}
	coords := a.Coords()
	p = &PanelSDIV{
		S:      coords["S"],
		D:      coords["D"],
		I:      coords["I"],
		V:      coords["V"],
		XArray: a}
	x.cache[fn] = p
	elapsed := time.Since(start)
	log.Println("Reading", fn, "cost", elapsed)
	return p
}

var PanelCacheGlobal PanelCache

func init() {
	PanelCacheGlobal.cache = make(map[string]*PanelSDIV)
}

func SdivRead(fn string) *PanelSDIV {
	return PanelCacheGlobal.Read(fn)
}

/**********************************
 * busdates
 */

/* Utils */
func HolidaySSEFile() (string, error) {
	files := []string{fmt.Sprintf("%s/tcal_SSE.txt", os.Getenv("CN_SEC_ROOT"))}

	for _, f := range files {
		if _, err := os.Stat(f); err == nil {
			return f, nil
		}
	}
	return "", fmt.Errorf("can't find SSE holiday file. candidates: %v", files)
}

func StrToDate(yyyymmdd string) (time.Time, error) {
	dateInt, err := strconv.Atoi(yyyymmdd)
	if err != nil {
		return time.Time{}, fmt.Errorf("%s not in yyyymmdd format", yyyymmdd)
	}
	yyyy, mm, dd := dateInt/10000, dateInt%10000/100, dateInt%100
	date := time.Date(yyyy, time.Month(mm), dd, 0, 0, 0, 0, time.FixedZone("UTC8", 8*60*60))
	return date, nil
}

func Holidays(fn string) (r []string) {
	r = []string{}
	file, err := os.Open(fn)
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		r = append(r, line)
	}
	return
}

/* BusDate */
type BusDateEx int

const (
	BusDateSH BusDateEx = iota
	BusDateHK
)

type BusDates struct {
	holidays map[string]bool
}

func (x *BusDates) Init(exch BusDateEx) {
	if exch != BusDateSH {
		log.Fatalf("not supported BusDateEx=%d", exch)
	}
	hf, err := HolidaySSEFile()
	if err != nil {
		log.Fatalf("can't find holiday file. %s", err)
	}
	holidays := Holidays(hf)
	x.holidays = make(map[string]bool)
	for _, d := range holidays {
		x.holidays[d] = true
	}
	log.Printf("Loaded %d holidays from %s\n", len(holidays), hf)
}

// whether date is business date
func (x *BusDates) IsBDate(date string) bool {
	d, err := StrToDate(date)
	if err != nil {
		log.Fatalf("date=%s not in yyyymmdd format", date)
	}
	return x.IsTimeBDate(d)
}

// whether date is business date
func (x *BusDates) IsTimeBDate(date time.Time) bool {
	yyyymmdd := date.Format("20060102")
	if _, ok := x.holidays[yyyymmdd]; ok {
		return false
	}

	wd := date.Weekday()
	if wd == time.Saturday || wd == time.Sunday {
		return false
	}
	return true
}

// Businesss Dates bewteen [start, stop) date
func (x *BusDates) BDates(start, stop string) []string {
	if start > stop {
		log.Fatalf("start(%s) must < stop(%s)", start, stop)
	}
	r := []string{}
	timeStartDate, err := StrToDate(start)
	if err != nil {
		log.Fatalf("start=%s not in yyyymmdd", start)
	}
	timeStopDate, err := StrToDate(stop)
	if err != nil {
		log.Fatalf("stop=%s not in yyyymmdd", stop)
	}

	for t := timeStartDate; !t.Equal(timeStopDate); t = t.AddDate(0, 0, 1) {
		if x.IsTimeBDate(t) {
			r = append(r, t.Format("20060102"))
		}
	}
	return r
}
func (x *BusDates) ShiftBDateIntAsInt(date int, shift int) int {
	r, err := strconv.Atoi(x.ShiftBDate(strconv.Itoa(date), shift))
	if err != nil {
		panic("ShiftBDateIntAsInt ShiftBDate() not return string as YYYYMMDD")
	}
	return r
}

func (x *BusDates) ShiftBDateInt(date int, shift int) string {
	return x.ShiftBDate(strconv.Itoa(date), shift)
}

func (x *BusDates) ShiftBDate(dateStr string, shift int) string {
	date, err := StrToDate(dateStr)
	if err != nil {
		log.Fatalf("date=%s not in yyyymmdd", dateStr)
	}
	date = date.AddDate(0, 0, shift)
	for ; !x.IsTimeBDate(date); date = date.AddDate(0, 0, shift) {
	}
	return date.Format("20060102")
}

// Get Previous Businesss Date
func (x *BusDates) PrevBDate(dateStr string) string {
	return x.ShiftBDate(dateStr, -1)
}
func (x *BusDates) PrevBDateInt(date int) int {
	return x.ShiftBDateIntAsInt(date, -1)
}

// Get Next Businesss Date
func (x *BusDates) NextBDate(dateStr string) string {
	return x.ShiftBDate(dateStr, 1)
}
func (x *BusDates) NextBDateInt(date int) int {
	return x.ShiftBDateIntAsInt(date, 1)
}

var (
	BDSH BusDates
)

func init() {
	BDSH.Init(BusDateSH)
}

/**********************************
 * checkpoint
 */

type SidCP []interface{}

/*
 * CheckPoint: should be called in the following sequence
 *   Write OV:  Init -> Term Add -> Prepare -> Term Update (EOD) -> WriteData (EOD)
 *   Read  OV:  Init -> Term Add -> Prepare -> ReadData (SOD) -> Term Get (SOD)
 */
type CheckPoint struct {
	// PanelSDIV
	S            []int
	date, class  string
	rpath, wpath string
	names        []string            // all flatt names
	sections     []string            // all sections. 1 section : 1 term
	dict         map[string][]string // section of term -> its names
	sidIndex     map[int]int         // sid -> its index, starting from index 1. 0 for header
	varIndex     map[string]int      // ov name -> index

	// write data: order by sids
	wd []SidCP

	// read data
	rd map[int]SidCP // sid index -> value list
}

func (c *CheckPoint) Init(sids []int, date, rpath, wpath, class string) {
	c.S = sids
	c.date = date
	c.rpath = rpath
	c.wpath = wpath
	c.class = class
	c.dict = map[string][]string{}
	c.sidIndex = map[int]int{}
	c.varIndex = map[string]int{}
	for i, s := range c.S {
		c.sidIndex[s] = i + 1 // starting from 1, 0 for headers
	}
	c.wd = make([]SidCP, len(c.S)+1)
}

func (c *CheckPoint) Sections() int {
	return len(c.sections)
}

func (c *CheckPoint) Add(section string, names []string) {
	log.Printf("CheckPoint %p %s Add %s %v", c, c.class, section, names)
	if _, ok := c.dict[section]; ok {
		log.Panicf("CheckPoint section=%s already exist", section)
	}
	sectionNames := make([]string, len(names))
	for i, n := range names {
		rname := fmt.Sprintf("%s.%s", section, n)
		c.names = append(c.names, rname)
		sectionNames[i] = rname
		c.varIndex[rname] = len(c.names) - 1
	}
	c.dict[section] = sectionNames
	c.sections = append(c.sections, section)
}

func (c *CheckPoint) Prepare() {
	allnames := make([]string, len(c.names)+1)
	allnames[0] = "sid"
	for idx, n := range c.names {
		allnames[idx+1] = n
	}
	c.wd[0] = make([]interface{}, len(allnames))
	for idx, n := range allnames {
		c.wd[0][idx] = n
	}
	for idx, n := range c.names {
		c.varIndex[n] = idx
	}
}

func (c *CheckPoint) WriteData() {
	if c.Sections() == 0 {
		return
	}
	if len(c.wpath) == 0 {
		log.Print("CheckPoint skip writting with empty wpath")
		return
	}
	folder := path.Join(c.wpath, c.date)
	if _, err := os.Stat(folder); err != nil {
		if e := os.MkdirAll(folder, 0700); e != nil {
			log.Fatal(e)
		}
	}
	fn := fmt.Sprintf("%s/%s.%s.ov", folder, c.date, c.class)
	log.Printf("CheckPoint WriteData() writting check point to %s\n", fn)
	for idx, sdata := range c.wd {
		if len(sdata) != len(c.names)+1 {
			log.Panicf("CheckPoint %s invalid data idx=%d size=%d sid=%d expected %d",
				c.class, idx, len(sdata), c.S[idx], len(c.names)+1)
		}
	}
	tesUtilsGo.DumpObjsIntoZstdFile(c.wd, fn)
}

func (c *CheckPoint) Update(section string, sid int, values []interface{}) {
	snames, ok := c.dict[section]
	if !ok {
		log.Panicf("CheckPoint.Update can't find section=%s", section)
	}
	if len(values) != len(snames) {
		log.Panicf("section=%s values size=%d not equal to variables size=%d", section, len(values), len(snames))
	}
	idx, ok := c.sidIndex[sid]
	if !ok {
		log.Panicf("CheckPoint sid=%d not in universe", sid)
	}
	if idx >= len(c.wd) {
		log.Panicf("CheckPoint invalid idx=%d", idx)
	}
	if len(c.wd[idx]) == 0 {
		c.wd[idx] = make(SidCP, 0)
		c.wd[idx] = append(c.wd[idx], sid)
	}
	c.wd[idx] = append(c.wd[idx], values...)
	if c.class == "idx" {
		log.Printf("CheckPoint %s Update section=%s sid=%d values=%v idx=%d len(v)=%d\n",
			c.class, section, sid, values, idx, len(c.wd[idx]))
	}
}

func (c *CheckPoint) Get(section string, sid int) (values []interface{}) {
	// get names list for term section
	snames, ok := c.dict[section]
	if !ok {
		log.Panicf("CheckPoint.Get can't find section=%s", section)
	}

	values = make([]interface{}, len(snames))
	if len(snames) == 0 {
		return
	}

	// find value list for sid
	sv, ok := c.rd[sid]
	if !ok {
		log.Panicf("CheckPoint.Get %s can't find data for sid=%d", c.class, sid)
	}

	// compose value list for term section
	for i, n := range snames {
		values[i] = sv[c.varIndex[n]]
	}
	return
}

func (c *CheckPoint) CreateNameMap(header []interface{}) []int {
	fileNameIdx := map[string]int{}
	reqNameList := make([]int, len(c.names))
	for idx, n := range header {
		nstr := n.(string)
		fileNameIdx[nstr] = idx
	}
	for i, n := range c.names {
		idx, ok := fileNameIdx[n]
		if !ok {
			log.Fatalf("CheckPoint [%s] not found in ov\n", n)
		}
		reqNameList[i] = idx
	}
	return reqNameList
}
func (c *CheckPoint) ReadData() string {
	// open T-1 OV file
	prevDate := BDSH.PrevBDate(c.date)
	if len(c.rpath) == 0 {
		log.Print("CheckPoint skip reading with empty rpath")
		return prevDate
	}

	if len(c.names) == 0 {
		return prevDate
	}

	fn := fmt.Sprintf("%s/%s/%s.%s.ov", c.rpath, prevDate, prevDate, c.class)
	if _, err := os.Stat(fn); err != nil {
		log.Fatalf("ERROR: check point not exist: %s", fn)
	}
	c.rd = map[int]SidCP{}
	// load data from OV file
	log.Printf("CheckPoint ReadData() reading check point from %s\n", fn)
	objsPtr, err := tesUtilsGo.LoadObjsFromZstd(fn)
	if err != nil {
		log.Fatalf("CheckPoint ReadData() cannot data from %s\n", fn)
	}
	// read header, create names mapping
	header := (*objsPtr)[0].([]interface{})
	reqNameList := c.CreateNameMap(header)
	if len(reqNameList) != len(c.names) {
		log.Panic("len(reqNameList) != len(c.names)")
	}
	// read each row for 1 sid
	for idx, obj := range *objsPtr {
		if idx == 0 {
			// header
			continue
		}
		sv := obj.([]interface{})  // sid value list
		sid := int(sv[0].(uint64)) // the first is sid
		values := make([]interface{}, len(reqNameList))
		for i, nIdx := range reqNameList {
			if nIdx >= len(sv) {
				log.Fatalf("CheckPoint ReadData invalid idx=%d. sid=%d\n", nIdx, sid)
			}
			values[i] = sv[nIdx]
		}
		c.rd[sid] = values
		if sid == 0 {
			log.Printf("sid=%d idx=%d values=%d names=%d\n", sid, idx, len(values), len(c.names))
		}
	}
	return prevDate
}

type CPManager struct {
	cpRead, cpWrite string
	cp              *CheckPoint
	cpIndex         *CheckPoint
}

func (m *CPManager) SetCheckPointPath(cpRead, cpWrite string) {
	m.cpRead = cpRead
	m.cpWrite = cpWrite
}

func (m *CPManager) CPInit(sidUniverse []int, dateStr string) {
	m.cp = &CheckPoint{}
	m.cp.Init(sidUniverse, dateStr, m.cpRead, m.cpWrite, "stk")
	m.cpIndex = &CheckPoint{}
	m.cpIndex.Init([]int{HS300_SID, ZZ500_SID}, dateStr, m.cpRead, m.cpWrite, "idx")
	if m.cp == m.cpIndex {
		log.Panic(m.cp, "==", m.cpIndex)
	}
}

func (m *CPManager) CPRegisterTerm(ovterm OVInterface) {
	ovterm.RegisterCheckPoint(m.cp, m.cpIndex)
}

func (m *CPManager) CPReadFile(terms []ITerm) {
	prevDate := m.cp.ReadData()
	m.cpIndex.ReadData()
	dateInt, err := strconv.Atoi(m.cp.date)
	if err != nil {
		log.Fatal(err)
	}
	prevDateInt, err := strconv.Atoi(prevDate)
	if err != nil {
		log.Fatal(err)
	}
	for _, term := range terms {
		if ovterm, ok := term.(OVInterface); ok {
			ovterm.ReadCheckPoint(dateInt, prevDateInt)
		}
	}
}
func (m *CPManager) CPStart(terms []ITerm) {
	m.cp.Prepare()
	m.cpIndex.Prepare()
	if len(m.cpRead) > 0 {
		m.CPReadFile(terms)
	}
}

func (m *CPManager) CPFinal(terms []ITerm) {
	if len(m.cpWrite) > 0 {
		for _, term := range terms {
			if ovterm, ok := term.(OVInterface); ok {
				ovterm.WriteCheckPoint()
			}
		}
		m.cp.WriteData()
		m.cpIndex.WriteData()
	}
}

/**********************************
 * inverval
 */

type (
	// I: interval duration in seconds
	// N: max number of intervals in a day
	// S: start time in seconds
	// E: end time in seconds
	Interval struct {
		I, N int
		S, E float64
	}

	IntervalValue struct {
		Interval
		V         float64
		lastIndex int
		array     []float64
	}
)

func NewChinaInterval(I int) Interval {
	return Interval{
		I: I,
		N: SECOND_CLOSE_SINCE_OPEN / I,
		S: FIRST_OPEN_SINCE_OPEN,
		E: SECOND_CLOSE_SINCE_OPEN,
	}
}

func (x Interval) SecondsIndex(secs float64) int {
	if x.I == 0 {
		panic("Inverval does not init'ed")
	}
	idx := math.Floor(secs / float64(x.I))
	return int(idx)
}

func (x Interval) EpochIndex(epoch float64) (float64, int) {
	secs := SecsSinceOpen(epoch)
	return secs, x.SecondsIndex(secs)
}

func (x Interval) Idx(secs float64) (int, bool) {
	idx := x.SecondsIndex(secs)
	ok := true
	if idx < 0 {
		idx = 0
		ok = false
	}
	if idx >= x.N {
		idx = x.N - 1
		ok = false
	}
	return idx, ok
}

// IntervalValue
func NewIntervalValue(I int) IntervalValue {
	i := NewChinaInterval(I)
	return IntervalValue{
		Interval: i,
		array:    make([]float64, i.N)}
}

func (x *IntervalValue) Length() int {
	return x.lastIndex + 1
}

func (x *IntervalValue) Slice(s, e int) []float64 {
	re := e
	if re == -1 {
		re = x.lastIndex + 1
	}
	return x.array[s:re]
}

func (x *IntervalValue) UpdateOrAddAt(idx int, v float64, add bool) bool {
	if add {
		x.array[idx] += v
	} else {
		x.array[idx] = v
	}

	// TODO: error if not forward
	forward := idx >= x.lastIndex
	idxJump := idx > x.lastIndex
	// backfill the holes
	if idx > x.lastIndex {
		for i := x.lastIndex + 1; i < idx; i++ {
			x.array[i] = x.V
		}
		x.lastIndex = idx
	}

	// update latest
	if forward {
		x.V = v
	}

	return idxJump
}

func (x *IntervalValue) UpdateAt(idx int, v float64) bool {
	return x.UpdateOrAddAt(idx, v, false)
}

func (x *IntervalValue) AddTo(secs float64, v float64) bool {
	idx, ok := x.Idx(secs)
	if !ok {
		return false
	}
	return x.UpdateOrAddAt(idx, v, true)
}

func (x *IntervalValue) Update(secs float64, v float64) bool {
	idx, ok := x.Idx(secs)
	if !ok {
		return false
	}
	return x.UpdateOrAddAt(idx, v, false)
}

// keep the first update for same interval.
func (x *IntervalValue) UpdateOnlyFirst(secs float64, v float64) bool {
	idx, ok := x.Idx(secs)
	if !ok {
		return false
	}
	if idx <= x.lastIndex {
		return false
	}

	x.array[idx] = v

	for i := x.lastIndex + 1; i < idx; i++ {
		x.array[i] = x.V
	}
	x.V = v
	x.lastIndex = idx
	return true
}

func (x *IntervalValue) At(secs float64) float64 {
	idx, ok := x.Idx(secs)
	if !ok {
		return math.NaN()
	}
	return x.array[idx]
}

func (x *IntervalValue) AtIdx(idx int) float64 {
	return x.array[idx]
}

func (x *IntervalValue) Scale(factor float64) {
	x.V *= factor
	for i, _ := range x.array {
		x.array[i] *= factor
	}
}

func (x *IntervalValue) ResetIndex() {
	x.lastIndex = 0
}

func (x *IntervalValue) Unmarshal(v interface{}) {
	for idx, i := range v.([]interface{}) {
		x.array[idx] = i.(float64)
	}
}

// #################################################################################################
// OV
type OVIterm interface {
	ToCP() []interface{}
	FromCP([]interface{})
	OVRoll(ca, ovseconds float64) bool
}

type CorpActioner interface {
	OnCorpActionLoaded(sid int, epoch float64)
}

type TermCorpActioner interface {
	OnTermCorpActionLoaded(sid int, epoch float64)
}

// interface for OV Terms
type OVInterface interface {
	// check point
	RegisterCheckPoint(cp *CheckPoint, cpIndex *CheckPoint)
	ReadCheckPoint(date, prevDate int)
	WriteCheckPoint()

	// snap value names
	names() []string
	// required inputs
	inputs() []int

	TermName() string
	ItemForSid(sid int) OVIterm

	Snap(secs float64, it OVIterm, res []float64)
}

type IndexOVInterface interface {
	ToCPForIndex(cp *CheckPoint)
	FromCPForIndex(cp *CheckPoint)
}

type TOBProcessor interface {
	TermUpdateTOB(sid int, secs float64, it OVIterm, msg *MsgTOB)
}
type TradeProcessor interface {
	TermUpdateTrade(sid int, secs float64, it OVIterm, msg *MsgTrade)
}
type IndexProcessor interface {
	TermUpdateIndex(sid int, secs float64, msg *MsgIndex)
}

type AnyMsgProcessor interface {
	TermUpdateAny(sid int, secs float64, it OVIterm)
}

type CPWrap struct {
	cp        *CheckPoint
	cpSection string
	cpNames   []string
}
type OVBase struct {
	SidIdxMap
	FeatureBase

	termValues []float64
	termInput  map[int]bool

	self OVInterface
	CPWrap

	indexCP   CPWrap
	indexSelf IndexOVInterface

	requireUpdateBeforeOpen bool

	dateInt, prevDateInt int
}

func (x *OVBase) RequireUpdateBeforeOpen() {
	x.requireUpdateBeforeOpen = true
}

// return true for T-1 for writting OV data only, not calc terms
func (x *OVBase) DataOnly() bool {
	return len(x.cp.rpath) == 0
}

func (x *OVBase) OVInit() {
	x.termValues = make([]float64, len(x.self.names()))
	x.termInput = make(map[int]bool)
	for _, n := range x.self.inputs() {
		x.termInput[n] = true
	}
}

func (x *OVBase) TermInput() map[int]bool {
	return x.termInput
}

func (x *OVBase) UpdateCPInfo(self OVInterface, section string, names []string) {
	x.self = self
	x.cpSection = section
	x.cpNames = names
	// dates
	dateInt, err := strconv.Atoi(x.dateStr)
	if err != nil {
		log.Fatal(err)
	}
	prevDate := BDSH.PrevBDate(x.dateStr)
	prevDateInt, err := strconv.Atoi(prevDate)
	if err != nil {
		log.Fatal(err)
	}
	x.dateInt = dateInt
	x.prevDateInt = prevDateInt
}

func (x *OVBase) UpdateCPInfoIndex(indexSelf IndexOVInterface, section string, names []string) {
	x.indexSelf = indexSelf
	x.indexCP.cpSection = section
	x.indexCP.cpNames = names
}

func (x *OVBase) RegisterCheckPoint(cp *CheckPoint, cpIndex *CheckPoint) {
	x.cp = cp
	x.cp.Add(x.cpSection, x.cpNames)

	if x.indexSelf != nil {
		x.indexCP.cp = cpIndex
		x.indexCP.cp.Add(x.indexCP.cpSection, x.indexCP.cpNames)
	}
}

func (x *OVBase) ReadCheckPoint(dateInt, prevDateInt int) {
	// read values from check point, and do over night adjustment, like corp action price adjustment, ema adjustment
	for sid, idx := range x.sid2idx {
		item := x.self.ItemForSid(sid)
		values := x.cp.Get(x.cpSection, sid)
		item.FromCP(values)
		item.OVRoll(1, SECOND_CLOSE_SINCE_OPEN)
		if idx == -1 {
			log.Printf("%s ReadCheckPoint idx=%d sid=%d item=[%s] cp=%v\n",
				x.self.TermName(), idx, sid, item, values)
		}
	}
	if x.indexSelf != nil {
		x.indexSelf.FromCPForIndex(x.indexCP.cp)
	}
}

func (x *OVBase) OnCorpActionLoaded(sid int, epoch float64) {
	idx, ok := x.sid2idx[sid]
	if !ok {
		return
	}
	item := x.self.ItemForSid(sid)
	ca := CA.Factor(sid, x.prevDateInt, x.dateInt)
	item.OVRoll(ca, 0)
	if idx == 0 {
		log.Printf("%s OnCorpActionLoaded idx=%d sid=%d ca=%f item=[%s]\n",
			x.self.TermName(), idx, sid, ca, item)
	}

	if termCA, ok := x.self.(TermCorpActioner); ok {
		termCA.OnTermCorpActionLoaded(sid, epoch)
	}
}

func (x *OVBase) WriteCheckPoint() {
	for sid, idx := range x.sid2idx {
		item := x.self.ItemForSid(sid)
		v := item.ToCP()
		x.cp.Update(x.cpSection, sid, v)
		if idx == -1 {
			log.Printf("%s OnEod idx=%d sid=%d item=[%s] cp=%v\n",
				x.self.TermName(), idx, sid, item, v)
		}
	}
	if x.indexSelf != nil {
		x.indexSelf.ToCPForIndex(x.indexCP.cp)
	}
}

var GlobalMsgTOB *MsgTOB = NewMsgTOB()

func (t *OVBase) TermUpdate(sid int, epoch float64, inputType int, n int, data []float64) {
	secs := SecsSinceOpen(epoch)
	if secs <= 0 && !t.requireUpdateBeforeOpen {
		return
	}

	if inputType == INPUT_MSG_INDEX && t.termInput[INPUT_MSG_INDEX] {
		idxMsg := MsgIndex{}
		idxMsg.From(data)
		indexProc := t.self.(IndexProcessor)
		indexProc.TermUpdateIndex(sid, secs, &idxMsg)
		return
	}
	if _, ok := t.sid2idx[sid]; !ok {
		return
	}
	item := t.self.ItemForSid(sid)
	if inputType == INPUT_MSG_TOB && t.termInput[INPUT_MSG_TOB] {
		//tob := MsgTOB{} //局部
		tob := GlobalMsgTOB //全局
		tob.From(data)
		tobx := t.self.(TOBProcessor)
		//tobx.TermUpdateTOB(sid, secs, item, &tob) //局部
		tobx.TermUpdateTOB(sid, secs, item, tob) //全局
	} else if inputType == INPUT_MSG_TRADE && t.termInput[INPUT_MSG_TRADE] {
		trade := MsgTrade{}
		trade.From(data)
		tradex := t.self.(TradeProcessor)
		tradex.TermUpdateTrade(sid, secs, item, &trade)
	} else {
		return
	}

	if anyx, ok := t.self.(AnyMsgProcessor); ok {
		anyx.TermUpdateAny(sid, secs, item)
	}
}

func (t *OVBase) ResetTermValues() {
	for idx, _ := range t.termValues {
		t.termValues[idx] = 0
	}
}

func (t *OVBase) GetSidValues(sid int, mPrice, secEpoch float64) (res []float64, err error) {
	res = t.termValues
	err = nil

	if t.DataOnly() {
		return
	}

	if _, ok := t.sid2idx[sid]; !ok {
		t.ResetTermValues()
		return
	}

	secs := SecsSinceOpen(secEpoch)
	if secs <= 0 {
		t.ResetTermValues()
		return
	}

	item := t.self.ItemForSid(sid)
	t.self.Snap(secs, item, res)
	return
}

/**********************************
 * inverval
 */
type Pair struct {
	first, second interface{}
}

func (x Pair) String() string {
	return fmt.Sprint("(", x.first, ",", x.second, ")")
}

/**********************************
 * panel_1min
 */

const (
	PANEL_1MIN_ROWS        = 257
	PANEL_1MIN_OPEN_INDEX  = 15  // 09:30:00 index in the 1min panel with 0-start
	PANEL_1MIN_CLOSE_INDEX = 253 // 14:57 index in the 1min panel with 0-start
)

type Panel1Min struct {
	*PanelSDIV
	date string
}

func (x *Panel1Min) Init(date string) {
	fn := fmt.Sprintf("%s/1min-%s.sdiv", MINUTE_DIR, date)
	sdiv := PanelCacheGlobal.Read(fn)
	x.date = date
	x.PanelSDIV = sdiv
}

func (x *Panel1Min) SV(sid int, v string) *SDVContext {
	if x.PanelSDIV == nil {
		log.Fatal("Panel1Min not init", sid, x.date, v)
	}
	idxS := x.LabelIndex("S", strconv.Itoa(sid))
	idxV := x.LabelIndex("V", v)
	return &SDVContext{
		PanelSDIV: x.PanelSDIV,
		IdxS:      idxS,
		IdxD:      0,
		IdxV:      idxV,
	}
}

func SecondsTo1MinIndex(secs float64) int {
	s := math.Floor(secs / 60)
	return int(s) + PANEL_1MIN_OPEN_INDEX
}

/**********************************
 * panel_barra
 */

type PanelBarraStat struct {
	*DIContext
	date string
}

func (x *PanelBarraStat) Init(date string) {
	fn := fmt.Sprintf("%s/stats-%s.sdiv", BARRA_DIR, date)
	sdiv := SdivRead(fn)
	x.date = date
	x.DIContext = &DIContext{
		PanelSDIV: sdiv,
		IdxD:      0,
		IdxI:      0,
	}
}

func (x *PanelBarraStat) Sid(sid int) *SDIContext {
	if x.DIContext == nil {
		log.Fatal("PanelBarra not init", sid, x.date)
	}
	idxS := x.LabelIndex("S", strconv.Itoa(sid))
	return &SDIContext{
		DIContext: x.DIContext,
		IdxS:      idxS,
	}
}

/**********************************
 * panel_daily
 */

// wrapper to read panel from /data/nasData/chinaEquityData/panel/daily/daily-YYYYMMDD.sdiv
type PanelDaily struct {
	*DIContext
	date string
}

func (x *PanelDaily) Init(date string) {
	fn := fmt.Sprintf("%s/daily-%s.sdiv", DAILY_DIR, date)
	sdiv := SdivRead(fn)
	x.date = date
	x.DIContext = &DIContext{
		PanelSDIV: sdiv,
		IdxD:      0,
		IdxI:      0,
	}
}

func (x *PanelDaily) Sid(sid int) *SDIContext {
	if x.DIContext == nil {
		log.Fatal("PanelDaily not init", sid, x.date)
	}
	idxS := x.LabelIndex("S", strconv.Itoa(sid))
	return &SDIContext{
		DIContext: x.DIContext,
		IdxS:      idxS,
	}
}

/**********************************
 * corpaction
 */

type CorpAction struct {
	data    map[int]*PanelSDIV        // yyyymmdd -> sdiv array
	factors map[int64]map[int]float64 // yyyymmddyyyymmdd -> adjust factor

	runDate            int
	prevDate           int
	factorFromPanel    map[int]float64
	factorRunDate      map[int]float64
	prevCloseFromPanel map[int]float64
	notUpdated         map[int]bool
	epoch              float64
}

func (x *CorpAction) IsBootstrapFinished() bool {
	return len(x.notUpdated) == 0
}

func (x *CorpAction) InitForDate(date string, sids []int) {
	x.runDate, _ = strconv.Atoi(date)
	pdate := BDSH.PrevBDate(date)
	x.prevDate, _ = strconv.Atoi(pdate)
	daily := PanelDaily{}
	daily.Init(pdate)
	x.factorFromPanel = make(map[int]float64)
	x.factorRunDate = make(map[int]float64)
	x.prevCloseFromPanel = make(map[int]float64)
	x.notUpdated = make(map[int]bool)

	for _, sid := range sids {
		close := daily.Sid(sid).SDIstr("close")
		x.prevCloseFromPanel[sid] = close
		x.notUpdated[sid] = true
		factor := x.factor(sid, x.prevDate, 1)
		x.factorFromPanel[sid] = factor
		if sid == 0 {
			log.Printf("CorpAction FromPanel sid=%d date=%s close=%.02f factor=%f\n", sid, pdate, close, factor)
		}
	}
}
func (x *CorpAction) ReportBootstrapStatus(epoch float64) {
	if epoch-x.epoch < 10 {
		return
	}
	x.epoch = epoch
	example := []int{}
	for sid, _ := range x.notUpdated {
		example = append(example, sid)
		if len(example) > 5 {
			break
		}
	}
	log.Printf("CorpAction secs=%.03f %d/%d not updated, like: %v\n", SecsSinceOpen(epoch),
		len(x.notUpdated), len(x.prevCloseFromPanel), example)
}

// return true if corp action for sid first updated.
func (x *CorpAction) UpdateSnapshotPrevClose(sid int, close float64, epoch float64) bool {
	if close == 0 || math.IsNaN(close) {
		return false
	}

	if _, ok := x.notUpdated[sid]; !ok {
		// already updated
		return false
	}

	closeFromPanel, ok := x.prevCloseFromPanel[sid]
	if !ok {
		// not in the universe
		return false
	}

	delete(x.notUpdated, sid)
	x.ReportBootstrapStatus(epoch)

	cafactorPrev := x.factor(sid, x.prevDate, 1.0)
	cafactor := cafactorPrev
	result := false
	if closeFromPanel > 0 && math.Abs(close-closeFromPanel) > 1e-8 {
		// if closeFromPanel not available in panel, it is nan.
		cafactor = cafactorPrev * (closeFromPanel / close)
		result = true
		log.Printf("CorpAction FromSnapshot sid=%d prevclose=%.02f prevclosePanel=%.02f cafactor=%f:%f\n",
			sid, close, closeFromPanel, cafactor, cafactorPrev)
	}
	x.factorRunDate[sid] = cafactor
	/*
		cafactorPanel := x.factor(sid, x.runDate, 1.0)
		if math.Abs(cafactorPanel-cafactor) > 1e-8 {
			log.Panicf("sid=%d cafactor not rec. cafactor=%f cafactorPanel=%f\n", sid, cafactor, cafactorPanel)
		}
		if sid == 0 {
			log.Printf("CorpAction FromSnapshot sid=%d prevclose=%.02f prevclosePanel=%.02f cafactor=%f\n",
				sid, close, closeFromPanel, cafactor)
		}
	*/
	return result
}

func (x *CorpAction) DailyAdjPanel(date int) *PanelSDIV {
	if p, ok := x.data[date]; ok {
		return p
	}
	fn := fmt.Sprintf("%s/daily-adjusted-%d.sdiv", CORPACTION_DIR, date)
	p := SdivRead(fn)
	x.data[date] = p
	return p
}

// get corp action factor for sid, date, return def if cannot find
func (x *CorpAction) factorFromAdjPanel(sid int, date int, def float64) float64 {
	p := x.DailyAdjPanel(date)
	sidStr := strconv.Itoa(sid)
	sidIdx := p.LabelIndex("S", sidStr)
	if sidIdx == -1 {
		return def
	}
	caIdx := p.LabelIndex("V", "adj.factor.locf")
	if caIdx == -1 {
		log.Fatal("cannot find var adj.factor.locf")
	}
	ca := p.At(sidIdx, 0, 0, caIdx)
	return ca
}

func (x *CorpAction) factor(sid int, date int, def float64) float64 {
	if date == x.runDate {
		ca, ok := x.factorRunDate[sid]
		if !ok {
			log.Panicf("sid=%d can't find CorpAction factor for runDate=%d\n", sid, date)
		}
		return ca
	}
	return x.factorFromAdjPanel(sid, date, def)
}

func (x *CorpAction) Factor(sid int, date, basisDate int) float64 {
	key := int64(date)*100000000 + int64(basisDate)
	fmap, ok := x.factors[key]
	if ok {
		f, exist := fmap[sid]
		if exist {
			return f
		}
	} else {
		fmap = make(map[int]float64)
		x.factors[key] = fmap
	}

	fo, fn := x.factor(sid, date, 1.), x.factor(sid, basisDate, 1.)
	f := fo / fn
	fmap[sid] = f
	return f
}

var (
	CA CorpAction
)

func init() {
	CA.data = make(map[int]*PanelSDIV)
	CA.factors = make(map[int64]map[int]float64)
}

func CorpActionFactor(sid, date, basisDate int) float64 {
	return CA.Factor(sid, date, basisDate)
}

/**********************************
 * panel_univ
 */

const (
	ALL_GID   = -1
	HS300_SID = 8753
	ZZ500_SID = 8998
	SH50_SID  = 8404
)

type UniverseLoader struct {
	SidUniv map[string]map[int]string
}

var (
	UNIVMAP = map[string]string{
		"sh50":   "sh50",
		"csi300": "hs250",
		"csi500": "zz500",
		"topx":   "non800",
		"midx":   "midx",
		"botx":   "botx",
	}
	HS300UNIV = map[string]bool{
		"sh50":  true,
		"hs250": true,
		"hs300": true,
	}
	loader UniverseLoader
)

func init() {
	loader.SidUniv = make(map[string]map[int]string)
}

func LoadIndexPanel(date string) {
	tmap := loader.SidUniv[date]
	indexFn := fmt.Sprintf("%s/index-%s.sdiv", INDEX_DIR, date)
	w := SdivRead(indexFn)
	coords := w.Coords()
	for idxs, s := range coords["S"] {
		sid, err := strconv.Atoi(s)
		if err != nil {
			panic(err)
		}
		for idxv, v := range coords["V"] {
			if w.At(idxs, 0, 0, idxv) > 0 {
				if u, ok := UNIVMAP[v]; ok {
					tmap[sid] = u
				}
			}
		}
	}
}

func LoadUnivData(date string) {
	tmap := loader.SidUniv[date]
	fn := fmt.Sprintf("%s/univ-%s.sdiv", UNIV_DIR, date)
	w := SdivRead(fn)
	coords := w.Coords()
	for idxs, s := range coords["S"] {
		sid, err := strconv.Atoi(s)
		if err != nil {
			panic(err)
		}
		if _, ok := tmap[sid]; ok {
			// already in the map
			continue
		}
		for idxv, v := range coords["V"] {
			if w.At(idxs, 0, 0, idxv) > 0 {
				if u, ok := UNIVMAP[v]; ok {
					tmap[sid] = u
				}
			}
		}
	}
}

func UnivForDate(date string) map[int]string {
	m, ok := loader.SidUniv[date]
	if !ok {
		loader.SidUniv[date] = map[int]string{}
		LoadIndexPanel(date)
		LoadUnivData(date)
		m = loader.SidUniv[date]
	}
	return m
}

func SidUniv(date string, sid int) string {
	m := UnivForDate(date)
	if u, ok := m[sid]; ok {
		return u
	}
	return "nonx"
}

var MX_TOPX_UNIV = map[string]bool{"sh50": true, "hs250": true, "hs300": true, "zz500": true, "non800": true, "topx": true}

func FilterUnivData(date, univ string) []int {
	fn := fmt.Sprintf("%s/univ-%s.sdiv", UNIV_DIR, date)
	w := SdivRead(fn)
	coords := w.Coords()
	r := []int{}
	for idxs, s := range coords["S"] {
		sid, err := strconv.Atoi(s)
		if err != nil {
			panic(err)
		}

		for idxv, v := range coords["V"] {
			if w.At(idxs, 0, 0, idxv) > 0 {
				if v == univ {
					r = append(r, sid)
				}
			}
		}
	}
	return r
}

func TopxSids(date string) []int {
	return FilterUnivData(date, "topx")
}

var MX_WHOLE_UNIV = map[string]bool{
	"sh50": true, "hs250": true, "hs300": true, "zz500": true, "non800": true, "topx": true, "midx": true, "botx": true}

func WholeSids(date string) []int {
	r := []int{}
	m := UnivForDate(date)
	for sid, univ := range m {
		if _, exist := MX_WHOLE_UNIV[univ]; exist {
			r = append(r, sid)
		}
	}
	return r
}

func UnivSids(univ, date string) []int {
	if univ == "topx" {
		return TopxSids(date)
	} else if univ == "whole" {
		return WholeSids(date)
	} else {
		log.Panicf("Not supported univ:%s", univ)
	}
	return []int{}
}

func UnivToIndexSid(univ string) int {
	if _, ok := HS300UNIV[univ]; ok {
		return HS300_SID
	}
	return ZZ500_SID
}

// #################################################################################################
// TermFactory
type TermCreator func() ITerm

type TermFactory struct {
	mu       sync.RWMutex
	creaters map[string]TermCreator
}

func (x *TermFactory) New() {
	x.mu.Lock()
	defer x.mu.Unlock()
	x.creaters = map[string]TermCreator{}
}

func (x *TermFactory) Register(name string, creator TermCreator) {
	x.mu.Lock()
	defer x.mu.Unlock()
	x.creaters[name] = creator
	log.Println("Adding term creator for", name)
}

func (x *TermFactory) CreateIterm(name string) (string, ITerm, error) {
	x.mu.Lock()
	defer x.mu.Unlock()
	c, ok := x.creaters[name]
	if !ok {
		return name, nil, fmt.Errorf("cannot find term creator for %s", name)
	}
	log.Printf("Creating term %s\n", name)
	return name, c(), nil
}

func (x *TermFactory) CreateIterms(names []string) (map[string]ITerm, error) {
	terms := make(map[string]ITerm)
	for _, name := range names {
		name, term, err := x.CreateIterm(name)
		if err != nil {
			return terms, err
		}
		terms[name] = term
	}
	return terms, nil
}

var termFactory = TermFactory{creaters: make(map[string]TermCreator)}

func TermFactoryInstance() *TermFactory {
	if termFactory.creaters == nil {
		termFactory.New()
	}
	return &termFactory
}

/*************************
 * term msg
 */
type MsgTOB struct {
	open      float64
	high      float64
	low       float64
	prevClose float64
	mid       float64
	last      float64
	robust    float64
	notional  float64
	volume    float64
	askPrice  float64
	askSize   float64
	bidPrice  float64
	bidSize   float64

	askSizeBook      []float64
	askPriceBook     []float64
	bidSizeBook      []float64
	bidPriceBook     []float64
	AgTrade          []float64
	SnapshotBook     []float64
	lastSnapShotBook []float64
}

func NewMsgTOB() *MsgTOB {
	x := new(MsgTOB)
	x.lastSnapShotBook = make([]float64, 43)
	x.askPriceBook = make([]float64, 10)
	x.askSizeBook = make([]float64, 10)
	x.bidPriceBook = make([]float64, 10)
	x.bidSizeBook = make([]float64, 10)
	x.AgTrade = make([]float64, 6)
	x.SnapshotBook = make([]float64, 43)
	return x
}

func (tob MsgTOB) LastOrRobust() float64 {
	switch {
	case tob.last > 0:
		return tob.last
	case tob.robust > 0:
		return tob.robust
	default:
		return math.NaN()
	}
}

func Robust(mid float64, last float64, prevClose float64) float64 {
	switch {
	case !math.IsNaN(mid) && mid != 0:
		return mid
	case !math.IsNaN(last) && last != 0:
		return last
	}
	return prevClose
}

func FLBToBuf(msg bookmsg.FLBEndBatchMsg, dataBuf []float64, lastDataBufAllSids map[int][]float64) {
	extra := msg.Extra.(*bookmsg.ChinaEquitySnapshotExtra)
	mid := msg.GetMidPrice()
	dataBuf[0] = extra.OpenPrice
	dataBuf[1] = extra.HighPrice
	dataBuf[2] = extra.LowPrice
	dataBuf[3] = extra.PrevClose
	dataBuf[4] = mid
	dataBuf[5] = extra.LastPrice
	dataBuf[6] = msg.CumTo
	dataBuf[7] = msg.CumVol
	dataBuf[8] = Robust(mid, extra.LastPrice, extra.PrevClose)

	idx := 9
	for i := 0; i < 10; i++ {
		dataBuf[2*i+idx] = msg.GetAsk(i)
		dataBuf[2*i+1+idx] = msg.GetAsize(i)
	}
	for i := 10; i < 20; i++ {
		dataBuf[2*i+idx] = msg.GetBid(i - 10)
		dataBuf[2*i+1+idx] = msg.GetBsize(i - 10)
	}

	idx = 49
	if lastDataBufAllSids[msg.Sid] != nil {
		for i := 0; i < 40; i++ {
			dataBuf[i+idx] = lastDataBufAllSids[msg.Sid][i+9]
		}
		dataBuf[89] = lastDataBufAllSids[msg.Sid][1]
		dataBuf[90] = lastDataBufAllSids[msg.Sid][7]
		dataBuf[91] = lastDataBufAllSids[msg.Sid][6]
	} else {
		for i := 0; i < 40; i++ {
			dataBuf[i+idx] = math.NaN() //标记为无效， dataBuf里的每个元素必须refresh， 否则可能会是上个sid的数据
		}
		dataBuf[89] = math.NaN()
		dataBuf[90] = math.NaN()
		dataBuf[91] = math.NaN()
	}

}

func (x *MsgTOB) From(dataBuf []float64) {
	x.open = dataBuf[0]
	x.high = dataBuf[1]
	x.low = dataBuf[2]
	x.prevClose = dataBuf[3]
	x.mid = dataBuf[4]
	x.last = dataBuf[5]
	x.notional = dataBuf[6] //CumTo
	x.volume = dataBuf[7]   //CumVol
	x.robust = dataBuf[8]

	/* 必须要全局MsgTOB 才有用， 下面代码是默认没有调用NewMsgTOB初始化，
	if x.SnapshotBook != nil {
		if x.lastSnapShotBook == nil {
			x.lastSnapShotBook = make([]float64, 43)
		}
		for i := 0; i < 43; i++ {
			x.lastSnapShotBook[i] = dataBuf[i+49]
		}
	}
	if x.askPriceBook == nil {
		x.askPriceBook = make([]float64, 10)
		x.askSizeBook = make([]float64, 10)
		x.bidPriceBook = make([]float64, 10)
		x.bidSizeBook = make([]float64, 10)
		x.AgTrade = make([]float64, 6)
		x.SnapshotBook = make([]float64, 43)
	}
	*/

	for i := 0; i < 43; i++ {
		x.lastSnapShotBook[i] = dataBuf[i+49]
	}

	idx := 9
	for i := 0; i < 10; i++ {
		x.askPriceBook[i] = dataBuf[2*i+idx]
		x.askSizeBook[i] = dataBuf[2*i+1+idx]
		x.bidPriceBook[i] = dataBuf[2*i+idx+20]
		x.bidSizeBook[i] = dataBuf[2*i+1+idx+20]
	}
	for i := 0; i < 40; i++ {
		x.SnapshotBook[i] = dataBuf[9+i]
	}
	x.SnapshotBook[40] = dataBuf[1]
	x.SnapshotBook[41] = dataBuf[7]
	x.SnapshotBook[42] = dataBuf[6]

	x.askPrice = x.askPriceBook[0]
	x.askSize = x.askSizeBook[0]
	x.bidPrice = x.bidPriceBook[0]
	x.bidSize = x.bidSizeBook[0]

	E_prepareAgTrade(x.notional, x.volume, x.lastSnapShotBook, x.AgTrade) //x.lastSnapShotBook是nil或者为NaN()那么，x.AgTrade为0

}

type MsgTrade struct {
	price  float64
	shares float64
	dir    bookmsg.TradeDir
}

func TradeToBuf(msg bookmsg.OBTradeMsg, dataBuf []float64) {
	dataBuf[0] = msg.Prc
	dataBuf[1] = msg.Qty
	dataBuf[2] = float64(msg.Dir)
}

func (x *MsgTrade) From(dataBuf []float64) {
	x.price = dataBuf[0]
	x.shares = dataBuf[1]
	x.dir = bookmsg.TradeDir(dataBuf[2])
}

func (x *MsgTrade) String() string {
	dir := ""
	switch x.dir {
	case bookmsg.DirBuy:
		dir = "Buy"
	case bookmsg.DirSell:
		dir = "Sell"
	default:
		dir = "Unknown"
	}
	return fmt.Sprintf("%s:%.2f@%.0f", dir, x.price, x.shares)
}

type MsgIndex struct {
	price    float64
	notional float64
	volume   float64
}

func IndexToBuf(msg bookmsg.FLBEndBatchMsg, dataBuf []float64) {
	extra := msg.Extra.(*bookmsg.ChinaIndexSnapshotExtra)
	dataBuf[0] = extra.LastPrice
	dataBuf[1] = msg.CumTo
	dataBuf[2] = msg.CumVol
}

func (x *MsgIndex) From(dataBuf []float64) {
	x.price = dataBuf[0]
	x.notional = dataBuf[1]
	x.volume = dataBuf[2]
}

/*************************
 * term names encode
 */
var mapTermnames = map[string]string{
	/* TODO: uncomment this to turn on name encoding
	"MX.ATR.5m": "MX.v1",
	"MX.DPO.5m": "MX.v2",
	*/

	"": ""}

// return mapping name in mapTermnames if exists, otherwise itself.
func MapTermname(n string) string {
	if mn, ok := mapTermnames[n]; ok {
		return mn
	}
	return n
}
