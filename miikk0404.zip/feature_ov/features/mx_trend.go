package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"log"
	"math"
)

// Trend: Price Distance

/////////////////////////////////////////
// TrendItem
type TrendItem struct {
	high, low, last   float64
	lower, upper, dir float64
	prcEMA, atrEMA    *MXEMA
	updateSecs        float64
}

const TrendCPNAME = "MXTrend"

var TrendCPNames = []string{
	"prcEma.wgt", "prcEma.sum", "prcEma.t",
	"atrEma.wgt", "atrEma.sum", "atrEma.t",
	"high", "low", "lower", "upper", "last", "dir"}

func (item *TrendItem) ToCP() []interface{} {
	r := []interface{}{
		item.prcEMA.wgt,
		item.prcEMA.sum,
		item.prcEMA.t,
		item.atrEMA.wgt,
		item.atrEMA.sum,
		item.atrEMA.t,
		item.high,
		item.low,
		item.lower,
		item.upper,
		item.last,
		item.dir}
	if len(r) != len(TrendCPNames) {
		log.Panicf("TrendItem CP value size(%d) != CP names size(%d)\n", len(r), len(TrendCPNames))
	}
	return r
}

func (item *TrendItem) FromCP(v []interface{}) {
	item.prcEMA.wgt = v[0].(float64)
	item.prcEMA.sum = v[1].(float64)
	item.prcEMA.t = v[2].(float64)
	item.atrEMA.wgt = v[3].(float64)
	item.atrEMA.sum = v[4].(float64)
	item.atrEMA.t = v[5].(float64)
	item.high = v[6].(float64)
	item.low = v[7].(float64)
	item.lower = v[8].(float64)
	item.upper = v[9].(float64)
	item.last = v[10].(float64)
	item.dir = v[11].(float64)
}

func (item *TrendItem) String() string {
	return fmt.Sprintf("TrendItem high=%f prcEma=[%s] ", item.high, item.prcEMA)
}

// return true if corp action factor != 1.
func (item *TrendItem) OVRoll(ca, emaTime float64) bool {
	r := false
	if math.Abs(1.-ca) > 1e-8 {
		item.prcEMA.sum *= ca
		item.atrEMA.sum *= ca
		r = true
	}
	item.prcEMA.t -= emaTime
	item.atrEMA.t -= emaTime
	item.high *= ca
	item.low *= ca
	item.lower *= ca
	item.upper *= ca
	item.last *= ca
	return r
}

var _ OVIterm = (*TrendItem)(nil)

/////////////////////////////////////////
// Term: MXTrend
type MXTrend struct {
	OVBase

	// Trend
	items  []*TrendItem
	hl     float64
	trendM float64
}

// prefs_name, feature_name, log_dir, datestr
func (t *MXTrend) init(pref, featureName, logDir, datestr string) error {
	return t.initOVTerm(tu.NewPreferenceAdapter(pref), featureName, logDir, datestr)
}

func (t *MXTrend) initOVTerm(pref *tu.PreferenceAdapter, featureName, logDir, datestr string) error {
	t.prefs = pref
	t.featureName = featureName
	t.dateStr = datestr
	t.logDir = logDir
	t.UpdateCPInfo(t, TrendCPNAME, TrendCPNames)
	return nil
}

func (t *MXTrend) TermName() string {
	return "MXTrend"
}

func (t *MXTrend) ItemForSid(sid int) OVIterm {
	return t.items[t.sid2idx[sid]]
}

func (t *MXTrend) names() []string {
	return []string{"atr", "trd"}
}

func (t *MXTrend) inputs() []int {
	return []int{INPUT_MSG_TOB}
}

func (t *MXTrend) loadFeaturePrefs() error {
	t.hl = t.prefs.GetFloat64PrefWithDefault(t.featureName+".hl", 300)
	t.trendM = t.prefs.GetFloat64PrefWithDefault(t.featureName+".m", 3)
	return nil
}

func (t *MXTrend) loadDailyStats() {
}

//setFeatureNames: set column names.
func (t *MXTrend) setFeatureNames() {
	t.colNames = t.names()
	for i, n := range t.colNames {
		t.colNames[i] = fmt.Sprintf("%s.%s.%s", t.featureName, HLFormat(t.hl), n)
	}
}

//initialize internal variables
func (t *MXTrend) initInternalVars() {
	t.OVInit()
	t.items = make([]*TrendItem, t.nSids)
	for idx, _ := range t.items {
		t.items[idx] = &TrendItem{
			prcEMA: NewMXEMA(t.hl, 1.),
			atrEMA: NewMXEMA(t.hl, 1.)}
	}
}

func (t *MXTrend) TermUpdateTOB(sid int, secs float64, it OVIterm, tob *MsgTOB) {
	item := it.(*TrendItem)
	if !(tob.last > 0) {
		return
	}
	item.prcEMA.Update(secs, tob.last)
	if item.high == 0 || (tob.high > 0 && tob.high > item.high) {
		item.high = tob.high
	}
	if item.low == 0 || (tob.low > 0 && tob.low < item.low) {
		item.low = tob.low
	}
	item.last = tob.last
	tr := item.high - item.low
	item.atrEMA.Update(secs, tr)
	t.CalcBound(item, secs)
}

func (t *MXTrend) CalcDir(item *TrendItem) {
	// if lower < price < upper, then dir not change.
	if item.last > item.upper {
		item.dir = 1
	} else if item.last < item.lower {
		item.dir = -1
	}
}

func (t *MXTrend) CalcBound(item *TrendItem, secs float64) {
	if secs-item.updateSecs < 60 {
		return
	}
	item.updateSecs = secs

	hlm := (item.high + item.low) / 2.0
	upper := hlm + t.trendM*item.atrEMA.GetEma()
	lower := hlm - t.trendM*item.atrEMA.GetEma()
	t.CalcDir(item)
	if item.dir > 0 && lower < item.lower {
		lower = item.lower
	}
	if item.dir < 0 && upper > item.upper {
		upper = item.upper
	}

	// save and roll
	item.lower = lower
	item.upper = upper
}

// snap
func (t *MXTrend) Snap(secs float64, it OVIterm, res []float64) {
	item := it.(*TrendItem)
	atr := item.atrEMA.GetEma()
	prcEMA := item.prcEMA.GetEma()
	trend := item.upper
	if item.dir > 0 {
		trend = item.lower
	}
	trend /= prcEMA
	res[0] = SafeSqrt(atr / prcEMA)
	res[1] = trend
}

var _ OVInterface = (*MXTrend)(nil)

func init() {
	TermFactoryInstance().Register("MX-TRD", func() ITerm { return &MXTrend{} })
}
