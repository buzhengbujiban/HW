package feature

import (
	"TES/QR/alpha_ov/data"
	tu "TES/tesUtilsGo"
	"fmt"
	"os"
	"panel"
	"strconv"
	"strings"
	"time"
	xa "xarray"
)

func UpperBound(arr []float64, val float64) int {
	l := 0
	h := len(arr)

	if h == 0 {
		// empty array
		return -1
	}

	for l < h {
		mid := (l + h) / 2
		if arr[mid] <= val {
			l = mid + 1
		} else {
			h = mid
		}
	}
	// now l = h

	// all values in arr <= val
	if h == len(arr) {
		return len(arr)
	}

	return h
}

func Ival2epoch(date string, ival string) float64 {
	dateIval := date + " " + ival
	loc, _ := time.LoadLocation("Asia/Shanghai")
	t, err := time.ParseInLocation("20060102 15:04:05", dateIval, loc)
	if err != nil {
		panic(err)
	}
	return float64(t.Unix()) + float64(t.Nanosecond())/1e9
}

type PanelAlpha struct {
	datestr string
	prefs   *tu.PreferenceAdapter
	sidsSet map[int]bool

	alpName string

	sids       []int
	sid2idx    map[int]int
	slotName   string
	ivalEpochs []float64

	hl float64

	xarr   *xa.XArray
	alpMat [][]float64

	currTimeStamp float64
}

func (alp *PanelAlpha) Init(alphaCfgFile string, datestr string) {
	alp.datestr = datestr
	alp.prefs = tu.NewPreferenceAdapter(alphaCfgFile)
	alp.sidsSet = make(map[int]bool)

	// load panel
	panelPath := alp.prefs.GetStringPref("panel_path")
	panelPath = strings.Replace(panelPath, "YYYYMMDD", alp.datestr, 1)
	if _, err := os.Stat(panelPath); os.IsNotExist(err) {
		panic(fmt.Sprintf("Panel Alpha file does not exist %s", panelPath))
	}
	tu.Logger.Info(fmt.Sprintf("Loading Alpha Panel from %s", panelPath))

	// load other prefs
	alp.slotName = alp.prefs.GetStringPref("alpha_slot")
	alp.alpName = alp.prefs.GetStringPref("alpha_name")
	if alp.alpName == "" {
		alp.alpName = "UnnamedPanelAlpha"
	}
	alp.hl = alp.prefs.GetFloat64PrefWithDefault("alpha_decay_hl", 0)

	var err error
	alp.xarr, err = panel.Panel.ReadSdiv(panelPath, "S", "D", "I", "V")
	if err != nil {
		panic(fmt.Sprintf("Error in loadig the panel", err.Error()))
	}

	// parse sids
	alp.sid2idx = make(map[int]int)
	sidStrs := alp.xarr.Coords()["S"]
	for i, sidStr := range sidStrs {
		sid, err := strconv.Atoi(sidStr)
		if err != nil {
			panic("Sid error")
		}
		alp.sids = append(alp.sids, sid)
		alp.sid2idx[sid] = i
	}

	// parse ivals
	ivalStrs := alp.xarr.Coords()["I"]
	for _, ivalStr := range ivalStrs {
		epoch := Ival2epoch(alp.datestr, ivalStr)
		if len(alp.ivalEpochs) > 0 && epoch <= alp.ivalEpochs[len(alp.ivalEpochs)-1] {
			panic("Interval is not strictly increasing in the alpha panel!")
		}
		alp.ivalEpochs = append(alp.ivalEpochs, epoch)
	}

	// load in the values
	alp.alpMat = make([][]float64, len(sidStrs))
	for i := 0; i < len(sidStrs); i++ {
		vec := alp.xarr.GetView(xa.I(i), xa.I(0), nil, xa.L(alp.slotName))
		alp.alpMat[i] = vec.Data()
	}
}

func (alp *PanelAlpha) OnTickdataUpdate(td *data.TesTOBSlice) bool {
	if alp.sidsSet[td.Sid] {
		alp.currTimeStamp = td.RecSecSinceEpoch
		return true
	} else {
		return false
	}
}

func (alp *PanelAlpha) SidUniverse() []int {
	return alp.sids
}

func (alp *PanelAlpha) GetName() string {
	return alp.alpName
}

func (alp *PanelAlpha) GetAlpha(sid int) (alpha float64, epoch float64) {
	/*
		NOTE: why use O(log n) query here?
		If we can guarantee the non-decreasing time stamps in market data, we can use O(1) update
		however some historical data contain some bad timestamps
	*/
	if idx, ok := alp.sid2idx[sid]; ok {
		vec := alp.alpMat[idx]
		i := UpperBound(alp.ivalEpochs, alp.currTimeStamp) - 1
		if i < 0 { // currTimeStamp is just too small
			return 0, alp.currTimeStamp
		} else {
			//TODO: do alpha value decay if configured in prefs
			return vec[i], alp.currTimeStamp
		}
	} else {
		return 0, alp.currTimeStamp
	}
}

// ============= Dummy Methods ==================

func (alp *PanelAlpha) PublishData() {
	tu.Logger.Info("PanelAlpha's PublishData is just empty")
}

func (alp *PanelAlpha) UpdateAlphaMode(mode string) {
	tu.Logger.Info("PanelAlpha's UpdateAlphaMode is just empty")
}

func (alp *PanelAlpha) RegisterAlphaUpdate(key [3]byte, f func([3]byte, int, float64, float64, float64)) {
	panic("NoImplForPanelAlpha")
}

func (alp *PanelAlpha) GetAlphaPara(sid int, localTms float64) (float64, float64) {
	panic("NoImplForPanelAlpha")
}
