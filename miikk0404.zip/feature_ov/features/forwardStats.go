// A Forward Stat is a special feature
// yzhu, 2018-09-02

package feature

import (
	"barra"
	"fmt"
	"math"
	"strings"

	"TES/QR/alpha_ov/data"
	"TES/tesUtilsGo/common"

	tu "TES/tesUtilsGo"
)

type ForwardUpdate struct {
	i int     // i-th GetValues
	j int     // j-th feature
	v float64 // the new value
}

// used within Forward Stats
type timedPrices struct {
	getValuesId int
	secEpoch    float64
	price       float64
	indexPrice  float64
}

type OvHorizonType int

const (
	OvForwardHours OvHorizonType = iota
	OvForwardBoDWithOffset
	OvForwardEoD
)

type OvRetType int

const (
	OvRet OvRetType = iota
	OvMret
	OvBret
)

type OvHorizon struct {
	horType OvHorizonType
	day     int
	offset  float64 // hours
}

type OvForwardRet struct {
	FeatureBase

	sid2idx      map[int]int
	lastMidPrice []float64
	fvalues      []float64

	secSinceEpochAt0000 float64

	fwdDateStrs []string
	day2minTab  map[int]*data.MinuteTable
	sid2pbeta   map[int]float64
	hs300Univ   map[int]bool

	// adj ret related [currently supports one day only]
	day1ret        map[int]float64 // sid -> fwd day 1 adjusted ret
	day0adjLastMid map[int]float64 // sid -> day 0 last mid price (only for those needed adj)

	// average start price
	useAvgStartPrice bool
	queue1           []map[int][]timedPrices // sidIdx -> (getValuesId -> mid price queue)
	queue2           []ForwardUpdate         // revision list
	getValuesId      int                     // times of GetValues being called

	// parameters
	horizons []OvHorizon
	retType  OvRetType
	retBound float64
}

func getPbetaMap(dateStr string, sidList []int) map[int]float64 {
	barra.SetPanelRoot(data.PanelRoot)
	barra.SetPreBusDateFun(common.PreTradeDateEquityFix)
	pdate := common.PreTradeDateEquityFix(dateStr)
	risk := barra.GetRiskModel(pdate, sidList, false)

	pbeta_idx := -1
	for i, colName := range barra.StatCols {
		if colName == "PBeta" {
			pbeta_idx = i
		}
	}
	if pbeta_idx < 0 {
		panic("Could not find PBeta field in barra Stats")
	}

	sid2pbeta := make(map[int]float64)
	stat := risk.Stat
	for i, sid := range sidList {
		pbeta := stat.Get(i, pbeta_idx)
		sid2pbeta[sid] = pbeta
		//fmt.Printf("DEBUG_FRET sid=%d PBETA=%.2f\n", sid, pbeta)
	}
	return sid2pbeta
}

func hoursSinceOpenToSecsSinceMid(hoursSinceOpen float64) float64 {
	if hoursSinceOpen < 0 {
		hoursSinceOpen = 0
	}
	if hoursSinceOpen > 4 {
		hoursSinceOpen = 4
	}
	if hoursSinceOpen <= 2 {
		return 3600 * (9.5 + hoursSinceOpen)
	} else {
		return 3600 * (9.5 + 1.5 + hoursSinceOpen)
	}
}

func parseOvHorizonStr(horizonStr string) OvHorizon {
	if strings.HasPrefix(horizonStr, "f") {
		if horizonStr == "f24h" {
			return OvHorizon{OvForwardHours, 0, 24.0}
		} else {
			panic("f-prefix horizon only supports f24h now.")
		}
	} else if strings.HasPrefix(horizonStr, "b") {
		if strings.Contains(horizonStr, "+") {
			strs := strings.Split(horizonStr, "+")
			if len(strs) == 2 {
				fwdDays := tu.ToInt(strs[0][1:])
				offsetHours := tu.ToFloat64(strs[1])
				if offsetHours >= 10 {
					panic(fmt.Sprintf("Offset hours must < 10; %s", horizonStr))
				}
				return OvHorizon{OvForwardBoDWithOffset, fwdDays, offsetHours}
			} else {
				panic(fmt.Sprintf("Error parsing BoDWithOffset %s", horizonStr))
			}
		} else {
			fwdDays := tu.ToInt(horizonStr[1:])
			return OvHorizon{OvForwardBoDWithOffset, fwdDays, 0}
		}
	} else if strings.HasPrefix(horizonStr, "e") {
		fwdDays := tu.ToInt(horizonStr[1:])
		return OvHorizon{OvForwardEoD, fwdDays, 0}
	} else {
		panic(fmt.Sprintf("Unknown horizon string: %s", horizonStr))
	}
}

func (oret *OvForwardRet) loadFeaturePrefs() error {
	horizonStrs := oret.prefs.GetStringListPref(oret.featureName + "_h_list")

	// Parse horizons
	oret.horizons = make([]OvHorizon, len(horizonStrs))
	for i := 0; i < len(horizonStrs); i++ {
		oret.horizons[i] = parseOvHorizonStr(horizonStrs[i])
	}

	// Parse ret type [Hardcoded as mret now]
	oret.retType = OvMret

	// ret bound default as 20%
	oret.retBound = oret.prefs.GetFloat64PrefWithDefault(oret.featureName+"_ret_bound", 0.2)

	// use avg start price
	oret.useAvgStartPrice = oret.prefs.GetBoolPref(oret.featureName + "_use_ave_start_price")

	fmt.Printf("OvForwradRet retBound=%v %v\n", oret.retBound, oret.useAvgStartPrice)

	return nil
}

func (oret *OvForwardRet) setFeatureNames() {
	// ret label
	var retLablel string
	if oret.retType == OvMret {
		retLablel = "mret"
	} else {
		panic("NYI")
	}

	// colnames
	oret.colNames = make([]string, len(oret.horizons))
	for i, hor := range oret.horizons {
		if hor.horType == OvForwardHours {
			oret.colNames[i] = fmt.Sprintf("%s%.1fh", retLablel, hor.offset)
		} else if hor.horType == OvForwardBoDWithOffset {
			oret.colNames[i] = fmt.Sprintf("%s%dd%.0fm", retLablel, hor.day, 60*hor.offset)
		} else if hor.horType == OvForwardEoD {
			oret.colNames[i] = fmt.Sprintf("%s%de", retLablel, hor.day)
		} else {
			panic("Unknown horizon type")
		}
	}
}

func (oret *OvForwardRet) initInternalVars() {
	// init sid2idx map
	oret.sid2idx = make(map[int]int)
	for i, sid := range oret.sidUniverseList {
		oret.sid2idx[sid] = i
	}

	// add hs300/zz500 index to sid2idx
	if _, ok := oret.sid2idx[data.SidCSI300]; !ok {
		l := len(oret.sid2idx)
		oret.sid2idx[data.SidCSI300] = l
	}
	if _, ok := oret.sid2idx[data.SidCSI500]; !ok {
		l := len(oret.sid2idx)
		oret.sid2idx[data.SidCSI500] = l
	}

	// init state variables
	oret.lastMidPrice = make([]float64, len(oret.sid2idx))
	oret.fvalues = make([]float64, len(oret.horizons))

	// init fwdDateStrs
	fwdDates := 0
	for _, hor := range oret.horizons {
		if hor.day > fwdDates {
			fwdDates = hor.day
		}
	}

	oret.fwdDateStrs = make([]string, fwdDates+1)
	oret.fwdDateStrs[0] = oret.dateStr
	for i := 1; i <= fwdDates; i++ {
		oret.fwdDateStrs[i] = common.NextTradeDateEquityFix(oret.fwdDateStrs[i-1])
	}

	// load fwd 1MIN panels
	oret.day2minTab = make(map[int]*data.MinuteTable)
	for i := 0; i <= fwdDates; i++ {
		minTbl := data.GetMinuteTableFromPanelData("1min", oret.fwdDateStrs[i], "midPriceLastValid")
		minTbl2 := data.GetMinuteTableFromPanelData("1min", oret.fwdDateStrs[i], "lastTradePrice")
		// LOCF for lastTradePrice
		cols2 := minTbl2.GetDataPtr()
		for i, col := range cols2 {
			if i > 0 {
				for j, val := range col {
					if math.IsNaN(val) || val == 0 {
						cols2[i][j] = cols2[i-1][j] // last ival, j-th stock
					}
				}
			}
		}
		// Fill NA midPriceLastValid with lastTradePrice (mainly to fix index price)
		cols := minTbl.GetDataPtr()
		for i, col := range cols {
			for j, val := range col {
				if math.IsNaN(val) || val == 0 {
					cols[i][j] = cols2[i][j]
				}
			}
		}

		oret.day2minTab[i] = minTbl
	}

	// load daily panels [for fwdDay 1 only]
	oret.day1ret = data.ConformSidValueMap(
		data.GetSidValueMapFromPanelData("daily", oret.fwdDateStrs[1], "00:00:00", "ret"),
		oret.sidUniverseList,
		0.0)
	oret.day0adjLastMid = make(map[int]float64)
	for sid, ret := range oret.day1ret {
		ivalIdx := oret.day2minTab[1].FindMMIdxBySecSinceMid(15 * 3600)
		lastMid1 := oret.day2minTab[1].Get(sid, ivalIdx)
		ivalIdx = oret.day2minTab[0].FindMMIdxBySecSinceMid(15 * 3600)
		lastMid0 := oret.day2minTab[0].Get(sid, ivalIdx)

		outRightRet := lastMid1/lastMid0 - 1
		if math.IsNaN(outRightRet) || math.IsInf(outRightRet, 0) {
			//no logic
		} else if math.Abs(ret-outRightRet) < 0.01 {
			// outRightRet is mid-to-mid
			// ret is last-to-last
			// 1% abs difference is allowed
			//no logic
		} else {
			oret.day0adjLastMid[sid] = lastMid1 / (1 + ret)
		}
	}
	fmt.Printf("OvForwardRet: day0adjLstMid = %v\n", oret.day0adjLastMid)

	// load PBETA
	oret.sid2pbeta = getPbetaMap(oret.dateStr, oret.sidUniverseList)

	// HS300 index
	var err error
	oret.hs300Univ, err = common.GetHS300Universe(oret.dateStr)
	if err != nil {
		panic(err.Error())
	}

	oret.secSinceEpochAt0000 = common.DateTimeToSecSinceEpoch(oret.dateStr, 0, 0, 0)

	if oret.useAvgStartPrice {
		oret.queue1 = make([]map[int][]timedPrices, len(oret.sid2idx))
		oret.queue2 = make([]ForwardUpdate, 0, 50000) // size=0, cap=50000
		for i := 0; i < len(oret.sid2idx); i++ {
			oret.queue1[i] = make(map[int][]timedPrices)
		}
	}
}

func (oret *OvForwardRet) UpdateSecValue(sid int, secSinceEpoch float64, midPrice float64) bool {
	if idx, ok := oret.sid2idx[sid]; !ok {
		return false
	} else {
		oret.lastMidPrice[idx] = midPrice

		if oret.useAvgStartPrice {
			mq1 := oret.queue1[idx]
			getValuesIds := make([]int, 0, len(mq1))
			for k, _ := range mq1 {
				getValuesIds = append(getValuesIds, k)
			}

			for _, getValuesId := range getValuesIds {
				q1 := mq1[getValuesId]

				indexSid := oret.getIndexSid(sid)
				indexSidIdx := oret.sid2idx[indexSid]
				indexPrice := oret.lastMidPrice[indexSidIdx]

				q1 = append(q1, timedPrices{
					getValuesId: getValuesId,
					secEpoch:    secSinceEpoch,
					price:       midPrice,
					indexPrice:  indexPrice,
				})

				// 6 forward ticks or 1 minute timeout
				if len(q1) == 6 || secSinceEpoch-q1[0].secEpoch > 60 {
					priceSum := 0.0
					indexPriceSum := 0.0
					nzPrice := 0.0
					nzIndexPrice := 0.0
					// jump| calc avg
					//   0 | 1 2 3 4 5
					for j := 1; j < len(q1); j++ {
						if q1[j].price != 0 {
							priceSum += q1[j].price
							nzPrice++
						}
						if q1[j].indexPrice != 0 {
							indexPriceSum += q1[j].indexPrice
							nzIndexPrice++
						}
					}
					price := priceSum / nzPrice
					if nzPrice == 0 {
						price = 0
					}

					indexPrice := indexPriceSum / nzIndexPrice
					if nzIndexPrice == 0 {
						indexPrice = 0
					}

					// get forward prices and calculate fwdret
					getRet := func(day int, secsSinceMid float64) float64 {
						minTbl := oret.day2minTab[day]
						idx := minTbl.FindMMIdxBySecSinceMid(secsSinceMid)

						fwdPrice := minTbl.Get(sid, idx)
						stockRet := math.Log(fwdPrice) - math.Log(price)

						indexFwdPrice := minTbl.Get(indexSid, idx)

						// Apply Price Adjuster on stockRet
						if day == 1 {
							if adjLastMid, ok := oret.day0adjLastMid[sid]; ok {
								day0LastMidPrice := oret.day2minTab[0].Get(sid, oret.day2minTab[0].FindMMIdxBySecSinceMid(15*3600))
								ret0 := math.Log(day0LastMidPrice) - math.Log(price)
								ret1 := math.Log(fwdPrice) - math.Log(adjLastMid)
								stockRet = ret0 + ret1
							}
						}

						if math.IsNaN(fwdPrice) || fwdPrice == 0 || math.IsNaN(price) || price == 0 {
							// Bad Price
							return 0
						} else if math.IsNaN(indexPrice) || indexPrice == 0 || math.IsNaN(indexFwdPrice) || indexFwdPrice == 0 {
							// Bad Index Price
							return stockRet
						} else {
							pbeta := oret.getPBeta(sid)
							return stockRet - pbeta*(math.Log(indexFwdPrice)-math.Log(indexPrice))
						}
					}

					for j, hor := range oret.horizons {
						retVal := 0.0
						switch hor.horType {
						case OvForwardHours:
							// supports only fwd 24 hours now
							secSinceMid := secSinceEpoch - oret.secSinceEpochAt0000
							retVal = getRet(1, secSinceMid)
						case OvForwardBoDWithOffset:
							secsSinceMid := hoursSinceOpenToSecsSinceMid(hor.offset)
							retVal = getRet(hor.day, secsSinceMid)
						case OvForwardEoD:
							// 4 hours => sets to EOD
							secsSinceMid := hoursSinceOpenToSecsSinceMid(4)
							retVal = getRet(hor.day, secsSinceMid)
						default:
							panic("Unknown horType")
						}

						// Bound return
						if retVal > oret.retBound {
							retVal = oret.retBound
						} else if retVal < -oret.retBound {
							retVal = -oret.retBound
						}

						// insert to queue2
						oret.queue2 = append(oret.queue2, ForwardUpdate{getValuesId, j, retVal})
						//
						//if sid == 2 && j == 0 {
						//	fmt.Printf("D")
						//}
					}

					// remove this getValuesId
					delete(mq1, getValuesId)
				} else /* len(q1) < 6 */ {
					mq1[getValuesId] = q1
				}
			}
		}

		return true
	}
}

func (oret *OvForwardRet) getIndexSid(sid int) int {
	if oret.hs300Univ[sid] {
		return data.SidCSI300
	} else {
		return data.SidCSI500
	}
}

func (oret *OvForwardRet) getPBeta(sid int) float64 {
	if pbeta, ok := oret.sid2pbeta[sid]; ok {
		return pbeta
	} else {
		return 1
	}
}

func (oret *OvForwardRet) GetSidValues(sid int, midPrice, secSinceEpoch float64) ([]float64, error) {
	if !oret.sidUniverse[sid] {
		for j := 0; j < len(oret.horizons); j++ {
			oret.fvalues[j] = 0
		}
		return oret.fvalues, nil
	}

	if oret.useAvgStartPrice {
		sidIdx := oret.sid2idx[sid]
		oret.queue1[sidIdx][oret.getValuesId] = make([]timedPrices, 0, 7)
		oret.getValuesId++
		// Note: we don't return here, we'll now fill the old way of returns (i.e. instant mid to forward)
		// most of these values will be refilled
		// only the last few of them (at EOD) won't
	}

	sidIdx := oret.sid2idx[sid]
	indexSid := oret.getIndexSid(sid)
	indexSidIdx := oret.sid2idx[indexSid]

	getRet := func(day int, secsSinceMid float64) float64 {
		minTbl := oret.day2minTab[day]
		idx := minTbl.FindMMIdxBySecSinceMid(secsSinceMid)

		price := oret.lastMidPrice[sidIdx]
		indexPrice := oret.lastMidPrice[indexSidIdx]

		fwdPrice := minTbl.Get(sid, idx)
		indexFwdPrice := minTbl.Get(indexSid, idx)

		stockRet := fwdPrice/price - 1

		// Apply Price Adjuster on stockRet
		if day == 1 {
			if adjLastMid, ok := oret.day0adjLastMid[sid]; ok {
				day0LastMidPrice := oret.day2minTab[0].Get(sid, oret.day2minTab[0].FindMMIdxBySecSinceMid(15*3600))
				ret0 := day0LastMidPrice/price - 1
				ret1 := fwdPrice/adjLastMid - 1
				stockRet = (1+ret0)*(1+ret1) - 1
			}
		}

		if math.IsNaN(fwdPrice) || fwdPrice == 0 || math.IsNaN(price) || price == 0 {
			// Bad Price
			return 0
		} else if math.IsNaN(indexPrice) || indexPrice == 0 || math.IsNaN(indexFwdPrice) || indexFwdPrice == 0 {
			// Bad Index Price
			return stockRet
		} else {
			pbeta := oret.getPBeta(sid)
			return stockRet - pbeta*(indexFwdPrice/indexPrice-1)
		}
	}

	for j, hor := range oret.horizons {
		retVal := 0.0
		switch hor.horType {
		case OvForwardHours:
			// supports only fwd 24 hours now
			secSinceMid := secSinceEpoch - oret.secSinceEpochAt0000
			retVal = getRet(1, secSinceMid)
		case OvForwardBoDWithOffset:
			secsSinceMid := hoursSinceOpenToSecsSinceMid(hor.offset)
			retVal = getRet(hor.day, secsSinceMid)
		case OvForwardEoD:
			// 4 hours => sets to EOD
			secsSinceMid := hoursSinceOpenToSecsSinceMid(4)
			retVal = getRet(hor.day, secsSinceMid)
		default:
			panic("Unknown horType")
		}

		// Bound return
		if retVal > oret.retBound {
			retVal = oret.retBound
		} else if retVal < -oret.retBound {
			retVal = -oret.retBound
		}

		oret.fvalues[j] = retVal
	}

	return oret.fvalues, nil
}

func (oret *OvForwardRet) GetValues(midPrice, secSinceEpoch float64) ([]float64, error) {
	return oret.GetSidValues(oret.baseSid, midPrice, secSinceEpoch)
}

func (oret *OvForwardRet) Finalize() {
	// we don't finalize as in fret class
	// because the last few data points use simple forward return
}

func (oret *OvForwardRet) GetRevisionList() []ForwardUpdate {
	fmt.Printf("OvForwardRet DEBUG GetRevisionList called\n")
	return oret.queue2
}

type ForwardRet struct {
	FeatureBase

	// parameters
	horizons                      []float64
	addEOD                        bool
	overrideSpotMidWithForwardSrc bool
	retLabel                      string

	// mret
	mretIndexName   string
	indexSid        map[int]bool
	lastIndexPrices map[int]float64 // indexSid -> last index price
	hs300Univ       map[int]bool

	// states
	queue1        map[int][][]timedPrices // sid -> (horizon -> unfinished queue)
	queue2        []ForwardUpdate         // revision list
	getValuesId   int                     // times of GetValues being called
	histMidPrices map[int][]timedPrices   // sid -> all hist mid prices seq

	// PBETA
	use_pbeta bool
	sid2pbeta map[int]float64

	// tmp and result vals
	fvalues []float64
}

func (fret *ForwardRet) loadFeaturePrefs() error {
	fret.horizons = fret.prefs.GetFloat64ListPref(fret.featureName + "_h_list")

	if fret.prefs.HasPref(fret.featureName + "_mret_index") {
		// market return
		fret.mretIndexName = fret.prefs.GetStringPref(fret.featureName + "_mret_index")
		switch strings.ToLower(fret.mretIndexName) {
		case "hs300", "csi300":
			fret.mretIndexName = "hs300"
		case "zz500", "csi500":
			fret.mretIndexName = "zz500"
		case "csi800":
			//no alias
		default:
			panic(fmt.Sprintf("Unknown mret_index: %s", fret.mretIndexName))
		}
		fret.retLabel = "mret"
	} else {
		// normal return
		fret.retLabel = "ret"
	}

	// PBETA and barra
	if fret.prefs.HasPref(fret.featureName + "_use_pbeta") {
		fret.use_pbeta = fret.prefs.GetBoolPref(fret.featureName + "_use_pbeta")
	} else {
		fret.use_pbeta = false
	}

	// a few fixed parameters (can read from prefs file in the future)
	fret.addEOD = true
	fret.overrideSpotMidWithForwardSrc = true

	return nil
}

func (fret *ForwardRet) setFeatureNames() {
	fret.colNames = make([]string, len(fret.horizons))
	for i, hl := range fret.horizons {
		if hl > 0 {
			// to be consistent with the existing format ret60s, ret120s, etc.
			fret.colNames[i] = fmt.Sprintf("%s%.0fs", fret.retLabel, hl)
		} else {
			// ret_600s = backward 600s ret
			fret.colNames[i] = fmt.Sprintf("%s_%.0fs", fret.retLabel, -hl)
		}
	}

	if fret.addEOD {
		fret.colNames = append(fret.colNames, fmt.Sprintf("%sEOD", fret.retLabel))
		fret.horizons = append(fret.horizons, 3600*24*7) // one week forward for EOD marking
	}
}

func (fret *ForwardRet) GetLastIndexPrice(sid int) float64 {
	switch fret.mretIndexName {
	case "":
		return 0
	case "hs300":
		return fret.lastIndexPrices[data.SidCSI300]
	case "zz500":
		return fret.lastIndexPrices[data.SidCSI500]
	case "csi800":
		if fret.hs300Univ[sid] {
			return fret.lastIndexPrices[data.SidCSI300]
		} else {
			return fret.lastIndexPrices[data.SidCSI500]
		}
	default:
		panic(fmt.Sprintf("Unknown mretIndexName: %s", fret.mretIndexName))
	}
}

func (fret *ForwardRet) UpdateSecValue(sid int, secSinceEpoch float64, midPrice float64) bool {
	if !fret.sidUniverse[sid] || midPrice <= 0 || math.IsNaN(midPrice) {
		return false
	}

	if fret.indexSid[sid] {
		if midPrice > 1 {
			fret.lastIndexPrices[sid] = midPrice
		}
		return true
	}

	// find the belonging index for this sid
	lastIndexPrice := fret.GetLastIndexPrice(sid)

	// update histMidPrice[sid] array
	if _, ok := fret.histMidPrices[sid]; !ok {
		fret.histMidPrices[sid] = make([]timedPrices, 1, 2000) // size 1, capacity 2000
		fret.histMidPrices[sid][0] = timedPrices{-1, secSinceEpoch, midPrice, lastIndexPrice}
	} else {
		histPrices := fret.histMidPrices[sid]
		if histPrices[len(histPrices)-1].secEpoch <= secSinceEpoch {
			fret.histMidPrices[sid] = append(histPrices, timedPrices{-1, secSinceEpoch, midPrice, lastIndexPrice})
		} else {
			// ignore an outdated tick
		}
	}

	queue := fret.queue1[sid]
	for j, hor := range fret.horizons {
		if hor >= 0 {
			// non-empty & current time reaches the forwarded time
			for len(queue[j]) > 0 && queue[j][0].secEpoch+hor < secSinceEpoch {
				getValuesId := queue[j][0].getValuesId
				var prevPrice, prevIndexPrice float64
				if fret.overrideSpotMidWithForwardSrc {
					prevPrice, prevIndexPrice = fret.binarySearchPrice(sid, queue[j][0].secEpoch)
				} else {
					prevPrice, prevIndexPrice = queue[j][0].price, queue[j][0].indexPrice
				}
				pbeta := 1.0
				if fret.use_pbeta {
					pbeta = fret.getPBeta(sid)
				}
				ret := fret.calcReturn(prevPrice, midPrice, prevIndexPrice, lastIndexPrice, pbeta)
				//en-queue
				fret.queue2 = append(fret.queue2, ForwardUpdate{getValuesId, j, ret})
				//de-queue
				queue[j] = queue[j][1:]
			}
		} else {
			// hor < 0 is already processed at GetValues
		}
	}

	return true
}

func (fret *ForwardRet) initInternalVars() {
	fret.fvalues = make([]float64, len(fret.horizons))

	fret.queue1 = make(map[int][][]timedPrices)
	for sid := range fret.sidUniverse {
		fret.queue1[sid] = make([][]timedPrices, len(fret.horizons))
	}

	fret.histMidPrices = make(map[int][]timedPrices)

	// mret-related fields
	fret.indexSid = make(map[int]bool)
	fret.indexSid[data.SidCSI300] = true
	fret.indexSid[data.SidCSI500] = true

	fret.lastIndexPrices = make(map[int]float64)

	var err error
	fret.hs300Univ, err = common.GetHS300Universe(fret.dateStr)
	if err != nil && fret.mretIndexName != "" {
		panic(err.Error())
	}

	// PBETA
	if fret.use_pbeta {
		fret.sid2pbeta = getPbetaMap(fret.dateStr, fret.sidUniverseList)
	}
}

func (fret *ForwardRet) binarySearchPrice(sid int, secEpoch float64) (float64, float64) {
	// lower_bound impl (in the context of forward writer)
	a := fret.histMidPrices[sid]
	l := 0
	h := len(a)

	if h == 0 {
		// if empty, return NaN
		return math.NaN(), math.NaN()
	}

	for l < h {
		mid := (l + h) / 2
		if a[mid].secEpoch < secEpoch {
			l = mid + 1
		} else {
			h = mid
		}
	}

	// if all times are before the query, let's give an older price
	if h == len(a) {
		l = len(a) - 1
	}

	return a[l].price, a[l].indexPrice
}

func (fret *ForwardRet) getPBeta(sid int) float64 {
	if pbeta, ok := fret.sid2pbeta[sid]; ok {
		return pbeta
	} else {
		return 1
	}
}

func (fret *ForwardRet) calcReturn(p0 float64, p1 float64, i0 float64, i1 float64, pbeta float64) float64 {
	if math.IsNaN(p0) || math.IsNaN(p1) {
		return 0
	} else {
		if fret.mretIndexName == "" || math.IsNaN(i0) || math.IsNaN(i1) || i0 == 0 || i1 == 0 {
			// raw return
			return math.Log(p1) - math.Log(p0)
		} else {
			if fret.use_pbeta {
				// market return with PBETA
				return (math.Log(p1) - pbeta*math.Log(i1)) - (math.Log(p0) - pbeta*math.Log(i0))
			} else {
				// market return
				return (math.Log(p1) - math.Log(i1)) - (math.Log(p0) - math.Log(i0))
			}
		}
	}
}

func (fret *ForwardRet) GetSidValues(sid int, midPrice, secSinceEpoch float64) ([]float64, error) {
	for j, hor := range fret.horizons {
		if hor < 0 {
			// backward
			prevPrice, prevIndexPrice := fret.binarySearchPrice(sid, secSinceEpoch+hor)
			lastIndexPrice := fret.GetLastIndexPrice(sid)
			pbeta := 1.0
			if fret.use_pbeta {
				pbeta = fret.getPBeta(sid)
			}
			ret := fret.calcReturn(midPrice, prevPrice, lastIndexPrice, prevIndexPrice, pbeta)
			fret.queue2 = append(fret.queue2, ForwardUpdate{fret.getValuesId, j, ret})
		} else {
			// forward
			var lastMid float64
			histPrices := fret.histMidPrices[sid]
			if len(histPrices) > 0 {
				lastMid = histPrices[len(histPrices)-1].price
			} else {
				// rare case (no valid price before a GetSidValue)
				// e.g. 901007 on 20150324
				lastMid = math.NaN()
			}
			lastIndexPrice := fret.GetLastIndexPrice(sid)
			fret.queue1[sid][j] = append(fret.queue1[sid][j], timedPrices{fret.getValuesId, secSinceEpoch, lastMid, lastIndexPrice})
		}
	}
	fret.getValuesId++
	// return fake values first
	return fret.fvalues, nil

}

func (fret *ForwardRet) GetValues(midPrice, secSinceEpoch float64) ([]float64, error) {
	return fret.GetSidValues(fret.baseSid, midPrice, secSinceEpoch)
}

func (fret *ForwardRet) Finalize() {
	for sid := range fret.queue1 {
		histPrices := fret.histMidPrices[sid]
		if len(histPrices) > 0 {
			lastMid := histPrices[len(histPrices)-1].price
			queue := fret.queue1[sid]
			for j, _ := range fret.horizons {
				// non-empty & current time reaches EOD
				for len(queue[j]) > 0 {
					getValuesId := queue[j][0].getValuesId
					var prevPrice, prevIndexPrice float64
					if fret.overrideSpotMidWithForwardSrc {
						prevPrice, prevIndexPrice = fret.binarySearchPrice(sid, queue[j][0].secEpoch)
					} else {
						prevPrice, prevIndexPrice = queue[j][0].price, queue[j][0].indexPrice
					}
					lastIndexPrice := fret.GetLastIndexPrice(sid)
					pbeta := 1.0
					if fret.use_pbeta {
						pbeta = fret.getPBeta(sid)
					}
					ret := fret.calcReturn(prevPrice, lastMid, prevIndexPrice, lastIndexPrice, pbeta)
					//en-queue
					fret.queue2 = append(fret.queue2, ForwardUpdate{getValuesId, j, ret})
					//de-queue
					queue[j] = queue[j][1:]
				}
			}
		} else {
			// histPrice is nil/empty, that is no this fmid on this day
			// e.g. 901044 (SN@SH) on 20180516
		}
	}
}

func (fret *ForwardRet) GetRevisionList() []ForwardUpdate {
	return fret.queue2
}

const NumBookStatusFeatures = 5

type BookStatus struct {
	FeatureBase

	sid2fvalues map[int][]float64
	empty       []float64
}

func (bs *BookStatus) loadFeaturePrefs() error {
	// no need to load any prefs
	return nil
}

func (bs *BookStatus) setFeatureNames() {
	bs.colNames = make([]string, NumBookStatusFeatures)

	bs.colNames[0] = "book.ask"
	bs.colNames[1] = "book.bid"
	bs.colNames[2] = "book.asize"
	bs.colNames[3] = "book.bsize"
	bs.colNames[4] = "book.cumvol"
}

func (bs *BookStatus) initInternalVars() {
	bs.sid2fvalues = make(map[int][]float64)
	for _, sid := range bs.sidUniverseList {
		bs.sid2fvalues[sid] = make([]float64, NumBookStatusFeatures)
	}
	bs.empty = make([]float64, NumBookStatusFeatures)
}

func (bs *BookStatus) UpdateValueSlice(sid int, valueSlice []float64) bool {
	if !bs.sidUniverse[sid] {
		return false
	}
	if len(valueSlice) != NumBookStatusFeatures {
		panic("BookStatus accepts 5 values at UpdateValueSlice")
	}
	copy(bs.sid2fvalues[sid], valueSlice)
	return true
}

func (bs *BookStatus) GetSidValues(sid int, midPrice, secSinceEpoch float64) ([]float64, error) {
	if values, ok := bs.sid2fvalues[sid]; ok {
		return values, nil
	} else {
		return bs.empty, nil
	}
}
