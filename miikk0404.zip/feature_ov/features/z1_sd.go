package feature

import (
	tu "TES/tesUtilsGo"
	"fmt"
	"math"
	"strconv"
	"strings"
)

type Z1_SD struct {
	FeatureBase
	SidIdxMap

	ids       []int
	levelsVec [][]int
	halfLife  float64

	lastMidPrc []float64   // sid idx -> mid prc
	lastAsize  [][]float64 // sid idx -> ask size
	lastBsize  [][]float64 // sid idx -> bid size

	emaVec [][]*ema // sid idx -> emaVec

	termValues []float64
	termInput  map[int]bool
}

// prefs_name, feature_name, log_dir, datestr
func (t *Z1_SD) init(prefsPath, featureName, logDir, datestr string) error {
	t.prefs = tu.NewPreferenceAdapter(prefsPath)
	t.featureName = featureName
	return nil
}

func (t *Z1_SD) loadFeaturePrefs() error {
	t.ids = t.prefs.GetIntListPref(t.featureName + "_id_list")
	t.halfLife = t.prefs.GetFloat64Pref(t.featureName + "_half_life")
	levelStrList := t.prefs.GetStringListPref(t.featureName + "_level_list")

	t.levelsVec = make([][]int, len(t.ids))
	for i, levelStr := range levelStrList {
		str_list := strings.Split(levelStr, "_")
		levelVec := make([]int, len(str_list))
		for j, numStr := range str_list {
			num, _ := strconv.Atoi(numStr)
			levelVec[j] = num - 1
		}

		t.levelsVec[i] = levelVec
	}

	return nil
}

//setFeatureNames: set column names.
func (t *Z1_SD) setFeatureNames() {
	t.colNames = make([]string, len(t.ids))
	for i, id := range t.ids {
		t.colNames[i] = fmt.Sprintf("%s-%d", t.featureName, id)
	}
}

//initialize internal variables
func (t *Z1_SD) initInternalVars() {
	t.SidIdxMap.Init(t.sidUniverseList)

	t.termValues = make([]float64, len(t.ids))

	t.lastMidPrc = make([]float64, t.nSids)
	t.lastAsize = make([][]float64, t.nSids)
	t.lastBsize = make([][]float64, t.nSids)
	t.emaVec = make([][]*ema, t.nSids)

	for i := 0; i < t.nSids; i++ {
		t.lastMidPrc[i] = 0
		t.lastAsize[i] = make([]float64, 10)
		t.lastBsize[i] = make([]float64, 10)

		emaVec := make([]*ema, len(t.ids))
		for j := 0; j < len(t.ids); j++ {
			emaVec[j] = newEma(t.halfLife, 3)
		}
		t.emaVec[i] = emaVec
	}

	t.termInput = map[int]bool{Z1_INPUT_SNAPSHOT_BOOK: true}
}

func (t *Z1_SD) TermInput() map[int]bool {
	return t.termInput
}

func (t *Z1_SD) TermUpdate(sid int, epoch float64, inputType int, n int, data []float64) {
	if !inTrading(epoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	secsSinceTrade := secsSinceTrade(epoch)
	midPrc := midPrc(data[0], data[20])
	lastMidPrc := t.lastMidPrc[idx]
	lastAsize := t.lastAsize[idx]
	lastBsize := t.lastBsize[idx]
	emaVec := t.emaVec[idx]
	if lastMidPrc > 0 && math.Abs(lastMidPrc-midPrc) < Z1_EPS {
		for i := range t.ids {
			askDelta := 0.0
			bidDelta := 0.0
			ema := emaVec[i]

			for _, level := range t.levelsVec[i] {
				askDelta += data[1+2*level] - lastAsize[level]
				bidDelta += data[21+2*level] - lastBsize[level]
			}

			denominator := math.Abs(bidDelta) + math.Abs(askDelta)
			if denominator > Z1_EPS {
				signal := (bidDelta - askDelta) / denominator
				ema.update(secsSinceTrade, signal)
			}
		}
	}

	t.lastMidPrc[idx] = midPrc
	for i := 0; i < 10; i++ {
		lastAsize[i] = data[1+2*i]
		lastBsize[i] = data[21+2*i]
	}
}

// snap
func (t *Z1_SD) GetSidValues(sid int, mPrice, secEpoch float64) (res []float64, err error) {
	for i := range t.ids {
		t.termValues[i] = 0
	}
	res = t.termValues
	err = nil

	if !inTrading(secEpoch) {
		return
	}

	idx, ok := t.sid2idx[sid]
	if !ok {
		return
	}

	secsSinceTrade := secsSinceTrade(secEpoch)

	// secEpoch >= 9:30
	emaVec := t.emaVec[idx]
	for i := range t.ids {
		res[i] = emaVec[i].getEms(secsSinceTrade)
	}

	return
}
