package feature

import (
	"TES/QR/alpha_ov/data"
	MU "TES/QR/alpha_ov/mathUtils"
	"fmt"
	"math"
	"os"
	"sort"
	"strconv"
)

var i2nT14RO = map[string]int{
	"in":   0,
	"out":  1,
	"spec": 2,
}

//LOB
// T的起始时间是真实时刻的epoch，中间会减去午休的时间
// mx SecsSinceOpen进行了调节，是计算的时间

// RO没有将量价统计的ema进行隔天处理，如果要做的话还要复权
type T_14RO struct {
	FeatureBase
	hlList []float64
	pLen   int
	pow    float64

	doCross  bool
	crossers []*MU.WeightedNestedGroupMeanFast

	start map[int]bool

	tempBidPrice []float64
	tempAskPrice []float64
	tempVals     []float64
	tempVals2    []float64

	groupData map[int]int

	method             string
	levels             map[int]int
	roc                float64
	levelSpec          int64
	emaAskQtyIn        map[int][]*MXEMA
	emaBidQtyIn        map[int][]*MXEMA
	emaAskQtyOut       map[int][]*MXEMA
	emaBidQtyOut       map[int][]*MXEMA
	emaAskQtyLevelSpec map[int][]*MXEMA
	emaBidQtyLevelSpec map[int][]*MXEMA
	emaRatioInDelta    map[int][]*MXEMA
	emaRatioOutDelta   map[int][]*MXEMA
	emaRatioSpecDelta  map[int][]*MXEMA

	emaAskSlopeIn  map[int][]*MXEMA
	emaBidSlopeIn  map[int][]*MXEMA
	emaAskSlopeOut map[int][]*MXEMA
	emaBidSlopeOut map[int][]*MXEMA
	emaAskMciIn    map[int][]*MXEMA
	emaBidMciIn    map[int][]*MXEMA
	emaAskMci10    map[int][]*MXEMA
	emaBidMci10    map[int][]*MXEMA

	pricesSeenSnap  []map[int][]float64
	emaStatsSnap    []map[int]map[float64][]*MXEMA
	pricesSeenTrade map[int][]float64
	emaStatsTrade   map[int]map[float64][]*MXEMA

	tempQtys    []float64
	tempQtysAbs []float64

	midPriceMap map[int]float64

	//trade价格 snap价格区别

	//return
	ret []float64

	//
	cpAction   string
	cpRead     string
	cpWrite    string
	cp         *CheckPoint
	cpSection  string //这个是区分不同feature的，其实可以不用，如果一个checkpoint只对应一个feature的话
	tempV      []float64
	epochFirst float64
}

func (seb *T_14RO) loadFeaturePrefs() error {
	seb.hlList = seb.prefs.GetFloat64ListPref(seb.featureName + "_hl_list")
	seb.doCross = seb.prefs.GetBoolPref(seb.featureName + "_do_cross")
	seb.pLen = len(seb.hlList)
	seb.pow = seb.prefs.GetFloat64Pref(seb.featureName + "_power")
	seb.method = seb.prefs.GetStringPref(seb.featureName + "_method")
	if seb.method == "priceRatio" {
		seb.roc = seb.prefs.GetFloat64Pref(seb.featureName + "_roc")
	}
	if seb.method == "fixed" {
		seb.levelSpec = seb.prefs.GetInt64Pref(seb.featureName + "_levelSpec")
	}

	seb.cpAction = seb.prefs.GetStringPref(seb.featureName + "_cpAction")
	seb.cpRead = seb.prefs.GetStringPref(seb.featureName + "_cpRead")
	seb.cpWrite = seb.prefs.GetStringPref(seb.featureName + "_cpWrite")
	if len(seb.cpRead) > 0 {
		seb.cpRead = fmt.Sprintf("%s/%s", seb.cpRead, seb.featureName)
		if _, err := os.Stat(seb.cpRead); os.IsNotExist(err) {
			os.MkdirAll(seb.cpRead, 0700)
		}
	}
	if len(seb.cpWrite) > 0 {
		seb.cpWrite = fmt.Sprintf("%s/%s", seb.cpWrite, seb.featureName)
		if _, err := os.Stat(seb.cpWrite); os.IsNotExist(err) {
			os.MkdirAll(seb.cpWrite, 0700)
		}
	}

	return nil
}

//setFeatureNames: set column names.
func (seb *T_14RO) setFeatureNames() {
	seb.colNames = make([]string, seb.pLen*38*4)
	for i := 0; i < 38; i++ {
		for j := 0; j < seb.pLen; j++ {
			seb.colNames[j+i*seb.pLen] = fmt.Sprintf("%s-%draw-%ds", seb.featureName, i, int(seb.hlList[j]))
		}
	}

	bias := 38
	for i := 0; i < 38; i++ {
		for j := 0; j < seb.pLen; j++ {
			seb.colNames[bias+j] = fmt.Sprintf("%s-%dm-%ds", seb.featureName, i, int(seb.hlList[j]))
			seb.colNames[bias+1*seb.pLen+j] = fmt.Sprintf("%s-%dim-%ds", seb.featureName, i, int(seb.hlList[j]))
			seb.colNames[bias+2*seb.pLen+j] = fmt.Sprintf("%s-%dir-%ds", seb.featureName, i, int(seb.hlList[j]))
		}
		bias += seb.pLen * 3
	}
	// assign ret memory
	seb.ret = make([]float64, len(seb.colNames))
	if len(seb.ret) > len(RemoveDuplicateStr(seb.colNames)) {
		fmt.Println(seb.colNames)
		panic("duplicate feature names")
	}
}

func toEMA(ema *MXEMA) []float64 {
	return []float64{ema.wgt, ema.sum, ema.t}
}

func copyEMA(ema *MXEMA, v []interface{}, epoch float64, loc int) int {
	ema.wgt = v[loc].(float64)
	ema.sum = v[loc+1].(float64)
	if epoch > E_EPS {
		ema.t = epoch
	} else {
		ema.t = v[loc+2].(float64)
	}
	return loc + 3
}

//还是用mx_utils里的，因为可以支持每个sid，不同长度的数据结构如变长slice， 因此不使用tbl结构
func (seb *T_14RO) TiToCP(sid int) []interface{} {
	if len(seb.tempV) > 0 {
		seb.tempV = seb.tempV[:0]
	}
	v := seb.tempV
	for j := 0; j < seb.pLen; j++ {
		v = append(v, toEMA(seb.emaAskQtyIn[sid][j])...)
		v = append(v, toEMA(seb.emaBidQtyIn[sid][j])...)
		v = append(v, toEMA(seb.emaAskQtyOut[sid][j])...)
		v = append(v, toEMA(seb.emaBidQtyOut[sid][j])...)
		v = append(v, toEMA(seb.emaAskQtyLevelSpec[sid][j])...)
		v = append(v, toEMA(seb.emaBidQtyLevelSpec[sid][j])...)
		v = append(v, toEMA(seb.emaRatioInDelta[sid][j])...)
		v = append(v, toEMA(seb.emaRatioOutDelta[sid][j])...)
		v = append(v, toEMA(seb.emaRatioSpecDelta[sid][j])...)
		v = append(v, toEMA(seb.emaAskSlopeIn[sid][j])...)
		v = append(v, toEMA(seb.emaBidSlopeIn[sid][j])...)
		v = append(v, toEMA(seb.emaAskSlopeOut[sid][j])...)
		v = append(v, toEMA(seb.emaBidSlopeOut[sid][j])...)
		v = append(v, toEMA(seb.emaAskMciIn[sid][j])...)
		v = append(v, toEMA(seb.emaBidMciIn[sid][j])...)
		v = append(v, toEMA(seb.emaAskMci10[sid][j])...)
		v = append(v, toEMA(seb.emaBidMci10[sid][j])...)
	}
	vi := make([]interface{}, len(v))
	for i := 0; i < len(v); i++ {
		vi[i] = v[i]
	}
	return vi
}

func (seb *T_14RO) TiFromCP(sid int, v []interface{}) {
	loc := 0
	epoch := seb.epochFirst
	for j := 0; j < seb.pLen; j++ {
		loc = copyEMA(seb.emaAskQtyIn[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaBidQtyIn[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaAskQtyOut[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaBidQtyOut[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaAskQtyLevelSpec[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaBidQtyLevelSpec[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaRatioInDelta[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaRatioOutDelta[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaRatioSpecDelta[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaAskSlopeIn[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaBidSlopeIn[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaAskSlopeOut[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaBidSlopeOut[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaAskMciIn[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaBidMciIn[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaAskMci10[sid][j], v, epoch, loc)
		loc = copyEMA(seb.emaBidMci10[sid][j], v, epoch, loc)
	}
}

//initialize internal variables'
func (seb *T_14RO) initInternalVars() {
	seb.FeatureBase.initInternalVars()

	seb.cp = &CheckPoint{}
	seb.cp.Init(seb.sidUniverseList, seb.dateStr, seb.cpRead, seb.cpWrite, "stk")
	seb.cpSection = seb.featureName
	cpNames := make([]string, 17*3*seb.pLen)
	for i := 0; i < len(cpNames); i++ {
		cpNames[i] = strconv.Itoa(i)
	}
	seb.cp.Add(seb.cpSection, cpNames)
	seb.cp.Prepare()
	seb.tempV = make([]float64, 0, 200)
	seb.epochFirst = TimeStrToEpoch(fmt.Sprintf("%s 09:30:00.000000", seb.dateStr))

	seb.crossers = make([]*MU.WeightedNestedGroupMeanFast, 38)
	for i := 0; i < 38; i++ {
		seb.crossers[i] = MU.NewWeightedNestedGroupMeanFast(seb.sidUniverseList, seb.pLen, seb.baseSidWgts, seb.industryCode, seb.conceptCodes)
	}

	seb.start = make(map[int]bool)

	seb.tempBidPrice = make([]float64, 0, 10)
	seb.tempAskPrice = make([]float64, 0, 10)

	seb.groupData = make(map[int]int)

	seb.levels = make(map[int]int)

	seb.emaAskQtyIn = make(map[int][]*MXEMA)
	seb.emaBidQtyIn = make(map[int][]*MXEMA)
	seb.emaAskQtyOut = make(map[int][]*MXEMA)
	seb.emaBidQtyOut = make(map[int][]*MXEMA)
	seb.emaAskQtyLevelSpec = make(map[int][]*MXEMA)
	seb.emaBidQtyLevelSpec = make(map[int][]*MXEMA)
	seb.emaRatioInDelta = make(map[int][]*MXEMA)
	seb.emaRatioOutDelta = make(map[int][]*MXEMA)
	seb.emaRatioSpecDelta = make(map[int][]*MXEMA)

	seb.emaAskSlopeIn = make(map[int][]*MXEMA)
	seb.emaBidSlopeIn = make(map[int][]*MXEMA)
	seb.emaAskSlopeOut = make(map[int][]*MXEMA)
	seb.emaBidSlopeOut = make(map[int][]*MXEMA)
	seb.emaAskMciIn = make(map[int][]*MXEMA)
	seb.emaBidMciIn = make(map[int][]*MXEMA)
	seb.emaAskMci10 = make(map[int][]*MXEMA)
	seb.emaBidMci10 = make(map[int][]*MXEMA)

	seb.emaStatsSnap = make([]map[int]map[float64][]*MXEMA, 3)
	seb.emaStatsTrade = make(map[int]map[float64][]*MXEMA)

	seb.pricesSeenSnap = make([]map[int][]float64, 3)
	for i := 0; i < 3; i++ {
		seb.emaStatsSnap[i] = make(map[int]map[float64][]*MXEMA)
		seb.pricesSeenSnap[i] = make(map[int][]float64)
	}
	seb.pricesSeenTrade = make(map[int][]float64)
	seb.tempVals = make([]float64, seb.pLen)
	seb.tempVals2 = make([]float64, seb.pLen*5)

	seb.tempQtys = make([]float64, 0, 200)
	seb.tempQtysAbs = make([]float64, 0, 200)

	seb.midPriceMap = make(map[int]float64)

	for sid := range seb.sidUniverse {
		seb.start[sid] = false

		seb.emaAskQtyIn[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBidQtyIn[sid] = make([]*MXEMA, seb.pLen)
		seb.emaAskQtyOut[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBidQtyOut[sid] = make([]*MXEMA, seb.pLen)
		seb.emaAskQtyLevelSpec[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBidQtyLevelSpec[sid] = make([]*MXEMA, seb.pLen)
		seb.emaRatioInDelta[sid] = make([]*MXEMA, seb.pLen)
		seb.emaRatioOutDelta[sid] = make([]*MXEMA, seb.pLen)
		seb.emaRatioSpecDelta[sid] = make([]*MXEMA, seb.pLen)

		seb.emaAskSlopeIn[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBidSlopeIn[sid] = make([]*MXEMA, seb.pLen)
		seb.emaAskSlopeOut[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBidSlopeOut[sid] = make([]*MXEMA, seb.pLen)
		seb.emaAskMciIn[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBidMciIn[sid] = make([]*MXEMA, seb.pLen)
		seb.emaAskMci10[sid] = make([]*MXEMA, seb.pLen)
		seb.emaBidMci10[sid] = make([]*MXEMA, seb.pLen)

		for i := 0; i < 3; i++ {
			seb.emaStatsSnap[i][sid] = make(map[float64][]*MXEMA)
			seb.pricesSeenSnap[i][sid] = make([]float64, 0, 100)
		}
		seb.emaStatsTrade[sid] = make(map[float64][]*MXEMA)
		seb.pricesSeenTrade[sid] = make([]float64, 0, 100)

		for j := 0; j < seb.pLen; j++ {
			seb.emaAskQtyIn[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaBidQtyIn[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaAskQtyOut[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaBidQtyOut[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaAskQtyLevelSpec[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaBidQtyLevelSpec[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaRatioInDelta[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaRatioOutDelta[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaRatioSpecDelta[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaAskSlopeIn[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaBidSlopeIn[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaAskSlopeOut[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaBidSlopeOut[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaAskMciIn[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaBidMciIn[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaAskMci10[sid][j] = NewMXEMA(seb.hlList[j], 3)
			seb.emaBidMci10[sid][j] = NewMXEMA(seb.hlList[j], 3)
		}
	}

	if seb.cpAction == "readCP" {
		prevDate := seb.cp.ReadData()
		fmt.Printf("read checkpoint of %s in prevDate as %s\n", seb.featureName, prevDate)
		//ReadCheckPoint(dateInt, prevDateInt)
		for sid := range seb.sidUniverse {
			if _, ok := seb.cp.rd[sid]; ok {
				values := seb.cp.Get(seb.cpSection, sid)
				seb.TiFromCP(sid, values)
			}
		}

	} else if seb.cpAction == "" || seb.cpAction == "writeCP" {
	} else {
		panic("please use cpAction")
	}

}

func (seb *T_14RO) initializeEMAsSnap(sid int, price float64, k int) {
	if _, ok := seb.emaStatsSnap[k][sid][price]; !ok {
		seb.pricesSeenSnap[k][sid] = append(seb.pricesSeenSnap[k][sid], price)
		seb.emaStatsSnap[k][sid][price] = make([]*MXEMA, seb.pLen)
		for j, hl := range seb.hlList {
			seb.emaStatsSnap[k][sid][price][j] = NewMXEMA(hl, 3)
		}
	}
}

func (seb *T_14RO) updateEMAsSnap(sid int, secs float64, price float64, qty float64, k int) {
	seb.initializeEMAsSnap(sid, price, k)
	for j := 0; j < seb.pLen; j++ {
		seb.emaStatsSnap[k][sid][price][j].Update(secs, qty)
	}
}

func (seb *T_14RO) initializeEMAsTrade(sid int, price float64) {
	if _, ok := seb.emaStatsTrade[sid][price]; !ok {
		seb.pricesSeenTrade[sid] = append(seb.pricesSeenTrade[sid], price)
		seb.emaStatsTrade[sid][price] = make([]*MXEMA, seb.pLen)
		for j, hl := range seb.hlList {
			seb.emaStatsTrade[sid][price][j] = NewMXEMA(hl, 3)
		}
	}
}

func (seb *T_14RO) updateEMAsTrade(sid int, secs float64, price float64, qty float64) {
	seb.initializeEMAsTrade(sid, price)
	for j := 0; j < seb.pLen; j++ {
		seb.emaStatsTrade[sid][price][j].Update(secs, qty)
	}
}

//Update
func (seb *T_14RO) UpdateDoubleSecPrcQtySliceDoubleSnapGroupExtraInfo(sid int, secSinceEpoch float64, buyObs []data.PriceQty, sellObs []data.PriceQty, snapData []float64, snapDataLast []float64, groupData map[int]int, extraInfo map[int][]float64) bool { //spl.tmpPrcQtySlice5 spl.tmpPrcQtySlice6 spl.z1_data2
	if _, ok := seb.sidUniverse[sid]; !ok {
		return false
	}

	if seb.method == "lastTrade" {
		if snapDataLast == nil {
			return true
		}

		priceMax := -1.
		priceMin := math.MaxFloat64
		for _, psp := range buyObs {
			priceMax = math.Max(priceMax, psp.Price)
			priceMin = math.Min(priceMin, psp.Price)
		}
		for _, psp := range sellObs {
			priceMax = math.Max(priceMax, psp.Price)
			priceMin = math.Min(priceMin, psp.Price)
		}

		seb.tempBidPrice = seb.tempBidPrice[:0]
		seb.tempAskPrice = seb.tempAskPrice[:0]
		for i := 0; i < 10; i++ {
			seb.tempAskPrice = append(seb.tempAskPrice, snapDataLast[i*2])
			seb.tempBidPrice = append(seb.tempBidPrice, snapDataLast[i*2+20])
		}

		seb.levels[sid] = int(math.Min(9., math.Max(2., math.Max(float64(SearchNearLoc(seb.tempAskPrice, priceMax)), float64(SearchNearLoc(seb.tempBidPrice, priceMin))))))

	} else if seb.method == "priceRatio" {
		if seb.roc <= 0. {
			panic("roc should be positive")
		}
		if snapDataLast == nil {
			return true
		}
		priceUnit := math.Max(0.5*math.Abs(snapDataLast[8]-snapDataLast[0])/4.+0.5*math.Abs(snapDataLast[20]-snapDataLast[28])/4., snapDataLast[0]-snapDataLast[20])
		priceOpen := snapDataLast[40]
		seb.levels[sid] = int(math.Round(math.Max(2., math.Min(powerTransform(priceOpen*seb.roc/priceUnit, 0.5), 9.))))
	} else if seb.method == "fixed" {
		if seb.levelSpec <= 0 || seb.levelSpec > 10 {
			panic("level_spec should be positive and less than 10")
		}
		seb.levels[sid] = int(seb.levelSpec)
	} else {
		panic("only method lastTrade or priceRatio is valid")
	}

	level := seb.levels[sid]

	askQtyIn := 0.
	askQtyOut := 0.
	askQtySpec := 0.
	bidQtyIn := 0.
	bidQtyOut := 0.
	bidQtySpec := 0.
	askQty := 0.
	bidQty := 0.
	for i := 0; i < 10; i++ {
		askQty = powerTransform(snapData[i*2+1], seb.pow)
		bidQty = powerTransform(snapData[20+i*2+1], seb.pow)
		if i <= level {
			askQtyIn += askQty
			bidQtyIn += bidQty
			seb.updateEMAsSnap(sid, secSinceEpoch, snapData[i*2], -askQty, i2nT14RO["in"])
			seb.updateEMAsSnap(sid, secSinceEpoch, snapData[20+i*2], bidQty, i2nT14RO["in"])
		}
		if i == level {
			askQtySpec += askQty
			bidQtySpec += bidQty
			seb.updateEMAsSnap(sid, secSinceEpoch, snapData[i*2], -askQty, i2nT14RO["spec"])
			seb.updateEMAsSnap(sid, secSinceEpoch, snapData[20+i*2], bidQty, i2nT14RO["spec"])
		}
		if i >= level {
			askQtyOut += askQty
			bidQtyOut += bidQty
			seb.updateEMAsSnap(sid, secSinceEpoch, snapData[i*2], -askQty, i2nT14RO["out"])
			seb.updateEMAsSnap(sid, secSinceEpoch, snapData[20+i*2], bidQty, i2nT14RO["out"])
		}
	}
	for j := 0; j < seb.pLen; j++ {
		seb.emaAskQtyIn[sid][j].Update(secSinceEpoch, askQtyIn)
		seb.emaBidQtyIn[sid][j].Update(secSinceEpoch, bidQtyIn)
		seb.emaAskQtyOut[sid][j].Update(secSinceEpoch, askQtyOut)
		seb.emaBidQtyOut[sid][j].Update(secSinceEpoch, bidQtyOut)
		seb.emaAskQtyLevelSpec[sid][j].Update(secSinceEpoch, askQtySpec)
		seb.emaBidQtyLevelSpec[sid][j].Update(secSinceEpoch, bidQtySpec)
	}

	for _, psp := range buyObs {
		seb.updateEMAsTrade(sid, secSinceEpoch, psp.Price, math.Abs(powerTransform(psp.Qty, seb.pow)))
	}
	for _, psp := range sellObs {
		seb.updateEMAsTrade(sid, secSinceEpoch, psp.Price, -math.Abs(powerTransform(psp.Qty, seb.pow)))
	}

	if snapDataLast == nil {
		return true
	}

	for i := 0; i < 10; i++ {
		askQty = powerTransform(snapDataLast[i*2+1], seb.pow)
		bidQty = powerTransform(snapDataLast[20+i*2+1], seb.pow)
		if i <= level {
			askQtyIn -= askQty
			bidQtyIn -= bidQty
		}
		if i == level {
			askQtySpec -= askQty
			bidQtySpec -= bidQty
		}
		if i >= level {
			askQtyOut -= askQty
			bidQtyOut -= bidQty
		}
	}
	for j := 0; j < seb.pLen; j++ {
		seb.emaRatioInDelta[sid][j].Update(secSinceEpoch, DivIgNa(bidQtyIn-askQtyIn, math.Abs(bidQtyIn)+math.Abs(askQtyIn)))
		seb.emaRatioOutDelta[sid][j].Update(secSinceEpoch, DivIgNa(bidQtyOut-askQtyOut, math.Abs(bidQtyOut)+math.Abs(askQtyOut)))
		seb.emaRatioSpecDelta[sid][j].Update(secSinceEpoch, DivIgNa(bidQtySpec-askQtySpec, math.Abs(bidQtySpec)+math.Abs(askQtySpec)))
	}

	if level < 2 {
		panic("level should be greater than 2")
	}
	askQtyIn = 0.
	bidQtyIn = 0.
	askQtyOut = 0.
	bidQtyOut = 0.
	for i := 0; i < 10; i++ {
		askQty = snapData[i*2+1]
		bidQty = snapData[20+i*2+1]
		if i <= level && i > 0 {
			askQtyIn += askQty
			bidQtyIn += bidQty
		}
		if i > level {
			askQtyOut += askQty
			bidQtyOut += bidQty
		}
	}
	avgPrice := extraInfo[sid][4] / extraInfo[sid][3]
	avgQty := extraInfo[sid][2]
	nor := DivIgNa(avgPrice, avgQty) / 50
	askSlopeIn := DivIgNa(snapData[level*2]-snapData[0], askQtyIn) / nor
	bidSlopeIn := DivIgNa(snapData[20+level*2]-snapData[20], bidQtyIn) / nor
	askSlopeOut := DivIgNa(snapData[18]-snapData[level*2], askQtyOut) / nor
	bidSlopeOut := DivIgNa(snapData[38]-snapData[20+level*2], bidQtyOut) / nor
	for j := 0; j < seb.pLen; j++ {
		seb.emaAskSlopeIn[sid][j].Update(secSinceEpoch, askSlopeIn)
		seb.emaBidSlopeIn[sid][j].Update(secSinceEpoch, bidSlopeIn)
		seb.emaAskSlopeOut[sid][j].Update(secSinceEpoch, askSlopeOut)
		seb.emaBidSlopeOut[sid][j].Update(secSinceEpoch, bidSlopeOut)
	}

	askAmtCum := 0.
	bidAmtCum := 0.
	askQtyCumIn := 0.
	bidQtyCumIn := 0.
	askQtyCum := 0.
	bidQtyCum := 0.
	askPriceVWAPIn := 0.
	bidPriceVWAPIn := 0.
	askPriceVWAPIn10 := 0.
	bidPriceVWAPIn10 := 0.
	for i := 0; i < 10; i++ {
		askAmtCum += snapData[i*2+1] * snapData[i*2]
		bidAmtCum += snapData[20+i*2+1] * snapData[20+i*2]
		askQtyCum += snapData[i*2+1]
		bidQtyCum += snapData[20+i*2+1]
		if i == level {
			askPriceVWAPIn = askAmtCum / askQtyCum
			bidPriceVWAPIn = bidAmtCum / bidQtyCum
			askQtyCumIn = askQtyCum
			bidQtyCumIn = bidQtyCum
		}
	}
	askPriceVWAPIn10 = askAmtCum / askQtyCum
	bidPriceVWAPIn10 = bidAmtCum / bidQtyCum

	seb.midPriceMap[sid] = E_midPrc(snapData[0], snapData[20])

	AskMciIn := DivIgNa(askPriceVWAPIn10/seb.midPriceMap[sid]-1., askQtyCumIn/avgQty)
	AskMciIn10 := DivIgNa(askPriceVWAPIn/seb.midPriceMap[sid]-1., askQtyCum/avgQty)
	BidMciIn := DivIgNa(bidPriceVWAPIn10/seb.midPriceMap[sid]-1., bidQtyCumIn/avgQty)
	BidMciIn10 := DivIgNa(bidPriceVWAPIn/seb.midPriceMap[sid]-1., bidQtyCum/avgQty)
	for j := 0; j < seb.pLen; j++ {
		seb.emaAskMciIn[sid][j].Update(secSinceEpoch, AskMciIn)
		seb.emaBidMciIn[sid][j].Update(secSinceEpoch, BidMciIn)
		seb.emaAskMci10[sid][j].Update(secSinceEpoch, AskMciIn10)
		seb.emaBidMci10[sid][j].Update(secSinceEpoch, BidMciIn10)
	}

	/*
		if sid == 2406 {
			fmt.Println(seb.method, level, askSlopeOut, bidSlopeOut)
		}
	*/

	seb.start[sid] = true

	return true
}

//GetValues
func (seb *T_14RO) GetSidValues(sid int, mPrice float64, secEpoch float64) ([]float64, error) {
	for i := 0; i < len(seb.ret); i++ {
		seb.ret[i] = 0
	}
	if _, ok := seb.sidUniverse[sid]; !ok {
		return seb.ret, nil
	} else if !seb.start[sid] {
		return seb.ret, nil
	} else {
		a := 0.
		b := 0.
		for j := 0; j < seb.pLen; j++ {
			seb.ret[j+0*seb.pLen] = seb.emaRatioInDelta[sid][j].GetEma()
			seb.ret[j+1*seb.pLen] = seb.emaRatioOutDelta[sid][j].GetEma()
			seb.ret[j+2*seb.pLen] = seb.emaRatioSpecDelta[sid][j].GetEma()

			a = seb.emaBidQtyIn[sid][j].GetEms(secEpoch)
			b = seb.emaAskQtyIn[sid][j].GetEms(secEpoch)
			seb.ret[j+3*seb.pLen] = NaInf2Zero(DivIgNa(a-b, a+b))

			a = seb.emaBidQtyOut[sid][j].GetEms(secEpoch)
			b = seb.emaAskQtyOut[sid][j].GetEms(secEpoch)
			seb.ret[j+4*seb.pLen] = NaInf2Zero(DivIgNa(a-b, a+b))

			a = seb.emaBidQtyLevelSpec[sid][j].GetEms(secEpoch)
			b = seb.emaAskQtyLevelSpec[sid][j].GetEms(secEpoch)
			seb.ret[j+5*seb.pLen] = NaInf2Zero(DivIgNa(a-b, a+b))

			seb.ret[j+6*seb.pLen] = seb.emaAskSlopeIn[sid][j].GetEma()
			seb.ret[j+7*seb.pLen] = seb.emaBidSlopeIn[sid][j].GetEma()
			seb.ret[j+8*seb.pLen] = seb.emaAskSlopeOut[sid][j].GetEma()
			seb.ret[j+9*seb.pLen] = seb.emaBidSlopeOut[sid][j].GetEma()

			seb.ret[j+10*seb.pLen] = seb.emaAskMciIn[sid][j].GetEma()
			seb.ret[j+11*seb.pLen] = seb.emaBidMciIn[sid][j].GetEma()
			seb.ret[j+12*seb.pLen] = seb.emaAskMci10[sid][j].GetEma()
			seb.ret[j+13*seb.pLen] = seb.emaBidMci10[sid][j].GetEma()
		}
		bias := 14
		for k := 0; k < 3; k++ {
			seb.tempQtys = seb.tempQtys[:0]
			seb.tempQtysAbs = seb.tempQtysAbs[:0]
			qty := 0.
			sort.Float64s(seb.pricesSeenSnap[k][sid])
			for j := 0; j < seb.pLen; j++ {
				for _, price := range seb.pricesSeenSnap[k][sid] {
					qty = seb.emaStatsSnap[k][sid][price][j].GetEms(secEpoch)
					seb.tempQtys = append(seb.tempQtys, qty)
					seb.tempQtysAbs = append(seb.tempQtysAbs, math.Abs(qty))
				}
				seb.ret[j+bias*seb.pLen] = BuySellRatioIgNa(seb.tempQtys)
				seb.ret[j+(bias+1)*seb.pLen] = BuySellSpreadIgNa(seb.pricesSeenSnap[k][sid], seb.tempQtys, seb.midPriceMap[sid])
				seb.ret[j+(bias+2)*seb.pLen] = ClipIgNa(CalcTstatIgNa(seb.pricesSeenSnap[k][sid], seb.tempQtysAbs, seb.midPriceMap[sid]), 5.0)
				seb.ret[j+(bias+3)*seb.pLen] = CalcDevIgNa(seb.pricesSeenSnap[k][sid], seb.tempQtysAbs, seb.midPriceMap[sid])
			}
			bias += 4
		}
		seb.tempQtys = seb.tempQtys[:0]
		seb.tempQtysAbs = seb.tempQtysAbs[:0]
		qty := 0.
		sort.Float64s(seb.pricesSeenTrade[sid])
		for j := 0; j < seb.pLen; j++ {
			for _, price := range seb.pricesSeenTrade[sid] {
				qty = seb.emaStatsTrade[sid][price][j].GetEms(secEpoch)
				seb.tempQtys = append(seb.tempQtys, qty)
				seb.tempQtysAbs = append(seb.tempQtysAbs, math.Abs(qty))
			}
			a := BuySellRatioIgNa(seb.tempQtys)
			b := BuySellSpreadIgNa(seb.pricesSeenTrade[sid], seb.tempQtys, seb.midPriceMap[sid])
			c := ClipIgNa(CalcTstatIgNa(seb.pricesSeenTrade[sid], seb.tempQtysAbs, seb.midPriceMap[sid]), 5.0)
			d := CalcDevIgNa(seb.pricesSeenTrade[sid], seb.tempQtysAbs, seb.midPriceMap[sid])
			biasPrev := 14
			for k := 0; k < 3; k++ {
				seb.ret[j+bias*seb.pLen] = a - seb.ret[j+biasPrev*seb.pLen]
				seb.ret[j+(bias+1)*seb.pLen] = b - seb.ret[j+(biasPrev+1)*seb.pLen]
				seb.ret[j+(bias+2)*seb.pLen] = c - seb.ret[j+(biasPrev+2)*seb.pLen]
				seb.ret[j+(bias+3)*seb.pLen] = d - seb.ret[j+(biasPrev+3)*seb.pLen]
				bias += 4
				biasPrev += 4
			}
		}
		bias = 38
		for i := 0; i < 38; i++ {
			for j := 0; j < seb.pLen; j++ {
				seb.tempVals[j] = naInf2Zero(seb.ret[j+i*seb.pLen])
			}
			seb.crossers[i].Update(sid, seb.tempVals)
			seb.crossers[i].GetValue(sid, seb.tempVals2)
			for j := 0; j < seb.pLen; j++ {
				seb.ret[bias+j+0*seb.pLen] = seb.tempVals2[j+0*seb.pLen]
				seb.ret[bias+j+1*seb.pLen] = seb.tempVals2[j+1*seb.pLen]
				seb.ret[bias+j+2*seb.pLen] = seb.tempVals2[j+3*seb.pLen]
			}
			bias += seb.pLen * 3
		}
	}
	return seb.ret, nil
}

//
func (seb *T_14RO) WriteCheckPoint() {
	if seb.cpAction == "writeCP" {
		fmt.Printf("write checkpoint of %s in today as %s\n", seb.featureName, seb.dateStr)
		//WriteCheckPoint()
		for sid := range seb.sidUniverse {
			v := seb.TiToCP(sid)
			seb.cp.Update(seb.cpSection, sid, v)
		}
		seb.cp.WriteData()

	} else if seb.cpAction == "" || seb.cpAction == "readCP" {
	} else {
		panic("please use cpAction")
	}
}
