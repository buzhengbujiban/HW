// modified from Futures' alphaV2.go
// yzhu, 20190107
// Yingfa, add some new methods for PROD. Also some optimization on performance. 20190128
//NOTE:
// the few differences with alphaV2 include
// 1) underlying Sampler
// 2) in trading logic
// 3) multiple-alpha models
// 4) session numbers
// in the future, it is better to refactor code to have a single alpha class

package feature

import (
	"bufio"
	"bytes"
	"compress/gzip"
	"fmt"
	"io/ioutil"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"table"

	"TES/QR/alpha_ov/data"
	"TES/QR/alpha_ov/mathUtils"
	"TES/tesUtilsGo/common"

	"TES/QR/infer/regressor"
	tu "TES/tesUtilsGo"
)

const maxSessions = 5

type EquityAlpha struct {
	EquityBookSampler
	AlphaItf

	alphaMode         AlphaMode
	alpha_logging_all bool
	alpha_coefs_path  string
	use_prev_alpha    bool

	snap_sid_set map[int]bool
	snap_mod     int64
	snap_cnt     map[int]int64

	alpha_file_fmt string

	// model
	fitterName      string
	fitterTarget    string
	alpha_regressor *regressor.Regressor

	// alpha values
	sid2alphas    map[int][]timedAlpha
	sid2index     map[int]int
	sid2lastAlpha map[int]timedAlpha
	sid2prevAlpha map[int]float64

	// features
	hExtra       []string // extra header fields for all features
	numFeatures  int
	featureArray []float64

	// post-processing features
	bound_by_std int
	feature_std  map[string]float64 //featureName -> median of StdDev of this feature in past 3 days
	ret_name     string             //return normalized by
	fstats       *data.FeatureStats

	// log
	debug_sids_set map[int]bool

	//---prod--
	keyInAlphaServer      [3]byte
	func2TellAlphaUpdated func([3]byte, int, float64, float64, float64) // for prod usage. "alpha_value, exTms, localTms"
	outputLiveResultData  []float64                                     //for prod usage. Yingfa. Sim/batch mode should be also the same to use this,not to use outputData. But not now. todo
	prodOneFeatureVec     []float64
}

func (alp *EquityAlpha) Init(prefName string, samplerName string, datestr string, isAlphaReplay bool) {
	alp.EquityBookSampler.Init(prefName, datestr, isAlphaReplay)
	alp.LoadGeneralPrefs()
	alp.SetHeader()

	alp.EquityBookSampler.DoAppendData = false //HACK

	alp.fstats = &data.FeatureStats{}

	if alp.prefs.HasPref("alpha_file_fmt") {
		alp.alpha_file_fmt = alp.prefs.GetStringPref("alpha_file_fmt")
		if !tu.StringInSlice(alp.alpha_file_fmt, []string{"gz", "tbl"}) {
			panic(fmt.Sprintf("Unknown alpha_file_fmt: %s", alp.alpha_file_fmt))
		}
	} else /* default format */ {
		alp.alpha_file_fmt = "gz"
	}

	if isAlphaReplay {
		alp.setAlphaMode("replay")
	} else {
		alp.setAlphaMode(alp.prefs.GetStringPref("alpha_mode"))
		alp.createOutputDir()
		alp.numFeatures = 0
		for _, fn := range alp.featureNameList {
			alp.numFeatures += len(alp.featureDict[fn].GetFeatureNames())
		}
		//alp.featureArray = make([]float64, alp.numFeatures)
		alp.prodOneFeatureVec = make([]float64, alp.numFeatures+NumStatsFeatures)
	}

	alp.sid2alphas = make(map[int][]timedAlpha)
	alp.sid2index = make(map[int]int)
	alp.sid2lastAlpha = make(map[int]timedAlpha)

	alp.initAlphaModel()

	//# alpha_value is updated at alpha_update_sec
	if alp.prefs.HasPref("bound_by_std") {
		alp.bound_by_std = alp.prefs.GetIntPref("bound_by_std")
	} else {
		alp.bound_by_std = 0
	}

	if alp.bound_by_std != 0 {
		window := 3
		alp.feature_std = alp.fstats.LoadPrevDayStdMedian(alp.outputDir, alp.datestr, window)
	}

	if alp.prefs.HasPref("ret_normalized_by") {
		alp.ret_name = alp.prefs.GetStringPref("ret_normalized_by")
	} else {
		alp.ret_name = ""
	}

	alp.snap_sid_set = make(map[int]bool)
	alp.snap_cnt = make(map[int]int64)
	if alp.prefs.HasPref("snap_sid_list_name") {
		sid_list_name := alp.prefs.GetStringPref("snap_sid_list_name")
		snapSids := common.GetSidListByNameNew(alp.datestr, sid_list_name, data.PanelRoot)
		for _, sid := range snapSids {
			alp.snap_sid_set[sid] = true
		}
		alp.snap_mod = alp.prefs.GetInt64Pref("snap_mod")
	}

	alp.debug_sids_set = make(map[int]bool)
	if alp.prefs.HasPref("alp_debug_sids") {
		sids := alp.prefs.GetIntListPref("alp_debug_sids")
		for _, sid := range sids {
			alp.debug_sids_set[sid] = true
		}
	}

	//init output result data slice. yangyingfa
	alp.outputLiveResultData = make([]float64, 0, 4*4800*1300) //4 per line * ticks * sids, 190MB
	alp.func2TellAlphaUpdated = nil
}

//GetName, implement of interface method. //yang
func (alp *EquityAlpha) GetName() string {
	return "EquityAlpha"
}

func (alp *EquityAlpha) LoadGeneralPrefs() {
	//alp.SamplerV2.LoadGeneralPrefs()  //because go has no dyanmic dispatching, we have to call LoadGeneralPrefs explicitly!
	if alp.prefs.HasPref("fitter_name") {
		alp.fitterName = alp.prefs.GetStringPref("fitter_name")
	} else {
		panic("golang version requires fitter_name explicitly.")
	}

	if alp.prefs.HasPref("fitter_target") {
		alp.fitterTarget = alp.prefs.GetStringPref("fitter_target")
	} else {
		alp.fitterTarget = ""
	}
}

func (alp *EquityAlpha) SetHeader() {
	//# output header is created here
	alp.header = "sid,rec_epoch,ex_time,date"
	hExtra := make([]string, 0)
	for _, fn := range alp.featureNameList {
		hExtra = append(hExtra, alp.featureDict[fn].GetFeatureNames()...)
	}
	alp.hExtra = hExtra

	//# set alpha logging verbosity level
	if alp.prefs.HasPref("alpha_logging_all") {
		alp.alpha_logging_all = alp.prefs.GetBoolPref("alpha_logging_all")
	} else {
		alp.alpha_logging_all = false
	}
	if alp.alpha_logging_all {
		extraHeader := strings.Join(hExtra, ",")
		alp.header = alp.header + "," + extraHeader + ",day_session,alpha"
	} else {
		alp.header = alp.header + ",day_session,alpha"
	}

	//Add extra feature names if any
	var allExtraFeatureNames []string
	for _, efn := range alp.extraFeatureNameList {
		allExtraFeatureNames = append(allExtraFeatureNames, alp.featureDict[efn].GetFeatureNames()...)
	}

	if alp.extraNumFeatures != len(allExtraFeatureNames) {
		panic("alp.extraNumFeatures != len(allExtraFeatureNames): extraNumFeatures should be initialized in SamplerV2.Init method")
	}

	if len(allExtraFeatureNames) > 0 {
		alp.header = alp.header + "," + strings.Join(allExtraFeatureNames, ",")
	}
}

func (alp *EquityAlpha) setAlphaMode(alphaModeStr string) {
	// alphaModeStr -> alphaMode
	switch alphaModeStr {
	case "batch":
		alp.alphaMode = BatchAlpha
	case "live":
		alp.alphaMode = LiveAlpha
	case "replay":
		alp.alphaMode = ReplayAlpha
	default:
		panic(fmt.Sprintf("Unknown alpha mode: %s", alphaModeStr))
	}
	fmt.Println("Alpha mode is: ", alphaModeStr, alp.alphaMode)
}

func (alp *EquityAlpha) initAlphaModel() {
	alp.use_prev_alpha = false
	alp.sid2prevAlpha = make(map[int]float64)

	//# read alpha coefs location
	alp.alpha_coefs_path = alp.prefs.GetStringPref("alpha_coefs_path")
	//# load alpha regressor
	//# use current month
	//# only use this in live/batch mode
	if alp.alphaMode == LiveAlpha || alp.alphaMode == BatchAlpha {
		if alp.fitterName == "xgb" {
			panic("2022-04-11 Dead code, ignore init of regressor object")
		} else {
			panic(fmt.Sprintf("Unknown fitter name %s", alp.fitterName))
		}
	} else if alp.alphaMode == ReplayAlpha {
		alp.use_prev_alpha = alp.prefs.GetBoolPref("use_prev_alpha")
		alp.loadAlpha()
	}
}

func (alp *EquityAlpha) UpdateAlphaMode(alphaModeStr string) {
	alp.setAlphaMode(alphaModeStr)
	alp.createOutputDir()
	alp.initAlphaModel()
}

func (alp *EquityAlpha) loadAlpha() {
	//# this is for replay mode only
	//# assume alpha values are generated by batch/live mode
	outputDir := filepath.Join(alp.outputDir, alp.datestr)
	alphaFile := filepath.Join(outputDir, fmt.Sprintf("%s_alpha.gz", alp.fitterName))
	if alp.fitterTarget != "" {
		alphaFile = filepath.Join(outputDir, fmt.Sprintf("%s_alpha_%s.gz", alp.fitterName, alp.fitterTarget))
	}

	f, err := os.Open(alphaFile)
	defer f.Close()
	if err != nil {
		panic(fmt.Sprintf("cannot access alpha file %s", alphaFile))
	}

	gr, _ := gzip.NewReader(f)
	defer gr.Close()

	reader := bufio.NewReader(gr)

	firstLine := true
	sid_idx := -1
	rec_epoch_idx := -1
	alpha_idx := -1
	for {
		line, _, err := reader.ReadLine()
		lineStr := string(line)
		if err != nil {
			break
		}
		if firstLine {
			// Parse header and get field indexes
			colNames := strings.Split(strings.TrimRight(lineStr, "\n"), ",")
			for i, colName := range colNames {
				switch colName {
				case "sid":
					sid_idx = i
				case "rec_epoch":
					rec_epoch_idx = i
				case "alpha":
					alpha_idx = i
				}
			}
			if sid_idx == -1 || rec_epoch_idx == -1 || alpha_idx == -1 {
				panic(fmt.Sprintf("bad alpah header: %s", lineStr))
			}
			firstLine = false
			continue
		}
		fields := strings.Split(lineStr, ",")
		v, err := strconv.ParseFloat(fields[alpha_idx], 64)
		if err != nil {
			v = math.NaN()
		}
		sid, _ := strconv.Atoi(fields[sid_idx])
		secEpoch, _ := strconv.ParseFloat(fields[rec_epoch_idx], 64)
		if _, ok := alp.sid2alphas[sid]; !ok {
			// encounter a new sid, initialize alpha vector and position
			alp.sid2alphas[sid] = make([]timedAlpha, 0, 4000)
			alp.sid2index[sid] = 0
		}
		alp.sid2alphas[sid] = append(alp.sid2alphas[sid], timedAlpha{secEpoch, v})
	}
}

func (alp *EquityAlpha) createOutputDir() bool {
	// Create Output Dir if not exist
	outputDir := filepath.Join(alp.outputDir, alp.datestr)
	tu.CreateDirIfNotExist(outputDir)

	// Construct Output file path
	if alp.alphaMode == BatchAlpha || alp.alphaMode == ReplayAlpha {
		if alp.fitterTarget != "" {
			alp.outputFile = filepath.Join(outputDir, fmt.Sprintf("%s_alpha_%s.%s", alp.fitterName, alp.fitterTarget, alp.alpha_file_fmt))
		} else {
			alp.outputFile = filepath.Join(outputDir, fmt.Sprintf("%s_alpha.%s", alp.fitterName, alp.alpha_file_fmt))
		}
	} else if alp.alphaMode == LiveAlpha {
		timeStr := common.SecSinceEpochToTimestr(float64(time.Now().Unix()))
		if alp.fitterTarget != "" {
			alp.outputFile = filepath.Join(outputDir, fmt.Sprintf("%s_alpha_%s_live_%s.%s", alp.fitterName, alp.fitterTarget, timeStr, alp.alpha_file_fmt))
		} else {
			alp.outputFile = filepath.Join(outputDir, fmt.Sprintf("%s_alpha_live_%s.%s", alp.fitterName, timeStr, alp.alpha_file_fmt))
		}
		//# <-- alpha_live may break and continue for several times, so put the timestamp into filename. Yingfa.
	}

	// Check if Output file exits
	if alp.alphaMode == BatchAlpha || alp.alphaMode == LiveAlpha {
		if _, err := os.Stat(alp.outputFile); err == nil {
			return false //sampler outputFile already exists
		} else {
			return true //outputFile Not Exist, waiting to be written
		}
	} else if alp.alphaMode == ReplayAlpha {
		if _, err := os.Stat(alp.outputFile); err != nil {
			panic(fmt.Sprintf("In alpha replay mode, outputFile must exist. %s", alp.outputFile))
		}
		return false //if no error, file exists
	} else {
		panic("Unreachable code")
	}
}

func (alp *EquityAlpha) PublishData() {
	if alp.alphaMode == ReplayAlpha {
		// for Reply mode, we don't publish anything
		fmt.Printf("ReplayAlpha mode. No publish data. Existing alpha file should be at: %s\n", alp.outputFile)
	} else if alp.alphaMode == LiveAlpha {
		// live output is diff, to save time in every tick cal, we have some calculation job in publishdata when in live mode.
		alp.publishLiveData() //added by Yingfa.
	} else if alp.alphaMode == BatchAlpha {
		alp.FinalizeExtraFeatures()
		if alp.alpha_file_fmt == "gz" {
			alp.publishDataAsGzip()
		} else if alp.alpha_file_fmt == "tbl" {
			alp.publishDataAsTbl()
		} else {
			panic("unknown alpha_file_fmt")
		}
	} else {
		panic(fmt.Sprintf("Unsupported alpha mode: %d", alp.alphaMode))
	}
}

func (alp *EquityAlpha) publishDataAsGzip() {
	var buf bytes.Buffer
	resFloats := alp.outputLiveResultData
	w := gzip.NewWriter(&buf)
	w.Write([]byte(alp.header + "\n"))
	lineno := 0
	for i := 0; i < len(resFloats); i += 4 {
		sid := int(resFloats[i])
		w.Write([]byte(fmt.Sprintf("%d,%.2f,%s,%s,%d,%g",
			sid,            // sid
			resFloats[i+1], // rec_epoch
			common.SecSinceEpochToTimestr(resFloats[i+2]), // ex_time
			alp.datestr,                       // date
			alp.SessionNumber(resFloats[i+2]), // day_session
			resFloats[i+3],                    // alpha
		)))

		if len(alp.extraOutputMatrix) > 0 {
			rowVals := alp.extraOutputMatrix[lineno]
			for _, val := range rowVals {
				w.Write([]byte(fmt.Sprintf(",%g", val)))
			}
		}
		w.Write([]byte("\n"))
		lineno++
	}
	w.Close()
	err := ioutil.WriteFile(alp.outputFile, buf.Bytes(), 0666)
	if err != nil {
		panic(fmt.Sprintf("writing file to %s fails", alp.outputFile))
	} else {
		fmt.Printf("Alpha file written to %s\n", alp.outputFile)
	}
}

func (alp *EquityAlpha) publishDataAsTbl() {
	header := strings.Split(alp.header, ",")

	dt := table.NewDataTable(len(header))
	dt.SetColNames(header)
	dt.SetDefaultTypes(table.TYPE_F32)
	dt.SetColNameTypes([]string{"sid", "rec_epoch", "ex_time", "date", "day_session", "alpha"}, table.TYPE_F64)

	lineFields := make([]interface{}, len(header))
	resFloats := alp.outputLiveResultData
	lineno := 0
	for i := 0; i < len(resFloats); i += 4 {
		lineFields[0] = resFloats[i]                               // sid
		lineFields[1] = resFloats[i+1]                             // rec_epoch
		lineFields[2] = resFloats[i+2]                             // ex_time
		lineFields[3] = float64(alp.dateint)                       // date
		lineFields[4] = float64(alp.SessionNumber(resFloats[i+2])) // day_session
		lineFields[5] = resFloats[i+3]                             // alpha

		if len(alp.extraOutputMatrix) > 0 {
			rowVals := alp.extraOutputMatrix[lineno]
			for index, val := range rowVals {
				lineFields[6+index] = val
			}
		}
		lineno++
		dt.AddRow(lineFields)
	}

	table.FWrite(alp.outputFile, dt, table.COMPRESSION_ZSTD)
	tu.Logger.Info(fmt.Sprintf("Alpha file written to %s", alp.outputFile))
}

func (alp *EquityAlpha) appendOutputData(sid int, book *data.FixedLevelBook) {
	//# retrieve receive time stamp for calculating EMA
	origRecEpoch := book.RecSecSinceEpoch
	adjRecEpoch := common.SubtractBreakSeconds(origRecEpoch, alp.secMorning, book.EID)
	//# retrieve source time stamp for calculating lagging returns
	srcEpoch := book.ExTimestamp
	//# features are calculated based on bid/ask price/sizes
	priceM := book.GetMidPrice()

	//# only append output_data at PUBLISH events
	//# if would like to trade at night, check in_trading[0];
	inTrading := alp.inTrading.InTrading
	if inTrading &&
		alp.baseSidSet[sid] &&
		SEventIsIntersect(alp.eventType, alp.publishEvents) {

		// Check and Ignore feature calculation
		if len(alp.snap_sid_set) > 0 && !alp.snap_sid_set[sid] {
			cnt := alp.snap_cnt[sid]
			alp.snap_cnt[sid] = cnt + 1
			if cnt > 5 && (int64(sid)+cnt)%alp.snap_mod != 0 {
				return
			}
		}

		// Create a feature vector
		feature_idx := 0
		{
			// Append a few Stats features
			featValues := alp.CalcStats(sid, book.Open, book.GetTopSize())
			if len(featValues) != NumStatsFeatures {
				panic("length of Stats features should == NumStatsFeatures")
			}
			for j, value := range featValues {
				alp.prodOneFeatureVec[feature_idx+j] = value
			}
			feature_idx += NumStatsFeatures
		}

		// Calculate Normal features
		for _, fn := range alp.featureNameList {
			var featValues []float64
			featValues, _ = alp.featureDict[fn].GetSidValues(sid, priceM, adjRecEpoch)
			expectedNum := len(alp.featureDict[fn].GetFeatureNames())
			if len(featValues) != expectedNum {
				panic(fmt.Sprintf("feature %s does not return %d values: %v", fn, expectedNum, featValues))
			}

			// append values of one feature
			for j, value := range featValues {
				alp.prodOneFeatureVec[feature_idx+j] = value
			}
			feature_idx += expectedNum
		}

		// Ignore alpha prediction
		if len(alp.snap_sid_set) > 0 && !alp.snap_sid_set[sid] {
			return
		}

		// Calculate alpha value
		var alpha float64
		{
			session := alp.SessionNumber(srcEpoch)
			alpha := alp.alpha_regressor.PredictSerial(session, 0, alp.prodOneFeatureVec)
			alp.sid2lastAlpha[sid] = timedAlpha{book.ExTimestamp, alpha}
		}

		// Add alpha to Result array
		alp.outputLiveResultData = append(alp.outputLiveResultData,
			float64(sid),
			book.RecSecSinceEpoch,
			book.ExTimestamp,
			alpha)

		// Calculate Extra features
		if len(alp.extraFeatureNameList) > 0 {
			row := make([]float64, alp.extraNumFeatures)
			alp.extraOutputMatrix = append(alp.extraOutputMatrix, row)

			feature_idx := 0
			for _, fn := range alp.extraFeatureNameList {
				var featValues []float64
				featValues, _ = alp.featureDict[fn].GetSidValues(sid, priceM, adjRecEpoch)
				expectedNum := len(alp.featureDict[fn].GetFeatureNames())
				if len(featValues) != expectedNum {
					panic(fmt.Sprintf("feature %s does not return %d values: %v", fn, expectedNum, featValues))
				}
				copy(row[feature_idx:], featValues)
				feature_idx += expectedNum
			}
		}
	}
}

//-------------------------------
//--Begin of production methods---
// added by Yingfa Yang. 20180727

//predict and appendoutputdata. For live mode only. and for production.
// added by Yang.
func (alp *EquityAlpha) predictAndAppendResult(sid int, book *data.FixedLevelBook) {
	//# retrieve receive time stamp for calculating EMA
	origRecEpoch := book.RecSecSinceEpoch
	adjRecEpoch := common.SubtractBreakSeconds(origRecEpoch, alp.secMorning, book.EID)
	//# retrieve source time stamp for calculating lagging returns
	//srcEpoch := book.ExTimestamp
	//# features are calculated based on bid/ask price/sizes
	priceM := book.GetMidPrice()

	isInBaseSids := alp.baseSidSet[sid]
	//# only append output_data at PUBLISH events
	//# if would like to trade at night, check in_trading[0];
	inTrading := alp.inTrading.InTrading
	if inTrading &&
		isInBaseSids &&
		SEventIsIntersect(alp.eventType, alp.publishEvents) {

		if len(alp.snap_sid_set) > 0 && !alp.snap_sid_set[sid] {
			cnt := alp.snap_cnt[sid]
			alp.snap_cnt[sid] = cnt + 1
			if cnt > 5 && (int64(sid)+cnt)%alp.snap_mod != 0 {
				return
			}
		}

		/*//if alp.alphaModeStr == "live" {
		//live mode keeps only 1*p, i.e., the current feature vector
		if len(alp.featureMatrix) < 1 {
			alp.featureMatrix = append(alp.featureMatrix, make([]float64, alp.numFeatures))
		}*/ //20181224, will not create matrix every time.

		feature_idx := 0

		//i := len(alp.featureMatrix) - 1
		featValues := alp.CalcStats(sid, book.Open, book.GetTopSize())
		if len(featValues) != NumStatsFeatures {
			panic("length of Stats features should == NumStatsFeatures")
		}
		for j, value := range featValues {
			alp.prodOneFeatureVec[feature_idx+j] = value
		}
		//for j, value := range featValues {
		//	alp.featureMatrix[i][feature_idx+j] = value
		//}
		feature_idx += NumStatsFeatures

		debugAlpTerms := alp.debug_sids_set[sid]
		if debugAlpTerms {
			fmt.Printf("debugTerms sid=%d epoch=%f:", sid, origRecEpoch)
		}

		//prepare matrix for prediction.
		for _, fn := range alp.featureNameList {
			var featValues []float64
			featValues, _ = alp.featureDict[fn].GetSidValues(sid, priceM, adjRecEpoch)
			expectedNum := len(alp.featureDict[fn].GetFeatureNames())
			if len(featValues) != expectedNum {
				panic(fmt.Sprintf("feature %s does not return %d values: %v", fn, expectedNum, featValues))
			}
			//# bound by previous day's 3 * std
			if alp.bound_by_std != 0 {
				tmp_name := alp.featureDict[fn].GetFeatureNames()
				for idx, featName := range tmp_name {
					ub := 3 * alp.feature_std[featName]
					lb := -3 * alp.feature_std[featName]
					featValues[idx] = mathUtils.Bound(featValues[idx], lb, ub)
				}
			}

			// append values of one feature
			// live-batch same impl
			//i := len(alp.featureMatrix) - 1
			if debugAlpTerms {
				for _, termValue := range featValues {
					fmt.Printf(",%f", termValue)
				}
			}
			for j, value := range featValues {
				alp.prodOneFeatureVec[feature_idx+j] = value
			}
			feature_idx += expectedNum
		}

		srcEpoch := book.ExTimestamp

		// Ignore alpha prediction
		if len(alp.snap_sid_set) > 0 && !alp.snap_sid_set[sid] {
			return
		}

		//# calculate alpha value (only for live mode)
		session := alp.SessionNumber(srcEpoch)
		alpha := alp.alpha_regressor.PredictSerial(session, 0, alp.prodOneFeatureVec)
		//normalize
		if alp.ret_name != "" {
			//# predicted value is return divided by previous day's std
			//# need to multiply std back
			alpha *= alp.feature_std[alp.ret_name]
		}
		alp.sid2lastAlpha[sid] = timedAlpha{book.ExTimestamp, alpha}

		// update the result for alpha server.
		if alp.func2TellAlphaUpdated != nil {
			//fmt.Println(alp.keyInAlphaServer, sid, alpha, book.ExTimestamp, book.RecSecSinceEpoch)
			alp.func2TellAlphaUpdated(alp.keyInAlphaServer, sid, alpha, book.ExTimestamp, book.RecSecSinceEpoch)
		}

		//live-batch same impl
		alp.outputLiveResultData = append(alp.outputLiveResultData,
			float64(sid),
			book.RecSecSinceEpoch,
			book.ExTimestamp,
			alpha) // 4 float64 as a group for one line's output in result gz file.

		if debugAlpTerms {
			fmt.Printf(" alp=%f\n", alpha)
		}
	} else if inTrading && isInBaseSids && alp.func2TellAlphaUpdated != nil {
		// even not in events. we should also tell the alpha service that we have got the latest tick.
		//fmt.Println(alp.keyInAlphaServer, sid, -1, book.ExTimestamp, book.RecSecSinceEpoch)
		alp.func2TellAlphaUpdated(alp.keyInAlphaServer, sid, 0, -1, origRecEpoch) // -1 means return back the last stamp and alpha is fine.
	}
}

//whichSession, findout which session the ex_timestamp is in. This would be used in publish method.
//Not to use in live mode to save time.
// added by YangYingfa.

//live mode only. batch may use this.
func (alp *EquityAlpha) publishLiveData() {
	var buf bytes.Buffer
	resFloats := alp.outputLiveResultData
	w := gzip.NewWriter(&buf)
	w.Write([]byte(alp.header + "\n"))
	for i := 0; i < len(resFloats); i += 4 {
		sid := int(resFloats[i])
		w.Write([]byte(fmt.Sprintf("%d,%.2f,%s,%s,%d,%g\n",
			sid,            // sid
			resFloats[i+1], // rec_epoch
			common.SecSinceEpochToTimestr(resFloats[i+2]), // ex_time
			alp.datestr,                       // date
			alp.SessionNumber(resFloats[i+2]), // day_session
			resFloats[i+3],                    // alpha
		)))
	}
	w.Close()
	err := ioutil.WriteFile(alp.outputFile, buf.Bytes(), 0666)
	if err != nil {
		panic(fmt.Sprintf("writing file to %s fails", alp.outputFile))
	}
}

// "alpha_value, exTms, localTms"
func (alp *EquityAlpha) RegisterAlphaUpdate(key [3]byte, f func([3]byte, int, float64, float64, float64)) {
	alp.keyInAlphaServer = key
	alp.func2TellAlphaUpdated = f
}

//--End of production methods---
//-------------------------------

func (alp *EquityAlpha) GetAlpha(sid int) (float64, float64) {
	if a, ok := alp.sid2lastAlpha[sid]; ok {
		if alp.use_prev_alpha {
			prevAlpValue := alp.sid2prevAlpha[sid]
			return prevAlpValue, a.secEpoch // prev alpha value, but current epoch
		} else {
			return a.alpha, a.secEpoch
		}
	} else {
		return 0, 0
	}
}

func (alp *EquityAlpha) OnTickdataUpdate(td *data.TesTOBSlice) bool {
	//start := time.Now()
	//# tickdata_replay passes in raw sid
	rawSid := td.Sid
	//# need to convert it to generic sid if necessary
	if _, ok := alp.fmidMap[rawSid]; !ok {
		// in batch trader prefs, one alpha may get more symbols tick data than it really needs.
		return false
	}
	sid := alp.fmidMap[rawSid]

	if alp.alphaMode == ReplayAlpha {
		rec_epoch := td.RecSecSinceEpoch
		if alphas, ok := alp.sid2alphas[sid]; ok {
			i, _ := alp.sid2index[sid]
			for i < len(alphas)-1 && alphas[i+1].secEpoch-timeEps < rec_epoch {
				i++
			}
			//TODO: fix alp.sid2idx[sid] = i
			alp.sid2prevAlpha[sid] = alp.sid2lastAlpha[sid].alpha // save as prevAlpha before update
			if alphas[i].secEpoch-timeEps < rec_epoch {
				alp.sid2lastAlpha[sid] = timedAlpha{alphas[i].secEpoch, alphas[i].alpha}
			} else {
				// haven't found any time stamp before rec_epoch, mark alpha as zero
				alp.sid2lastAlpha[sid] = timedAlpha{alphas[i].secEpoch, 0}
			}
			return true
		} else {
			// replay a non-alpha universe sid
			return false
		}
	}

	// AlphaMode == Batch or Live

	//# sample only at registered events
	if alp.EquityBookSampler.OnTickDataUpdateUglyForward(td) {
		//# retrieve book by generic sid
		book := alp.flbBook[sid]
		if alp.alphaMode == LiveAlpha {
			alp.predictAndAppendResult(sid, book) //added by Yang
		} else /* Batch Mode */ {
			//NOTE: EquitySampler.OnTickDataUpdate would call its own appendOutputData (because go has no dynamic dispatch)
			alp.appendOutputData(sid, book)
		}
		//dur := time.Now().Sub(start)
		//fmt.Println(td.Sid, td.RecSecSinceEpoch, start.UnixNano(),  dur )
		return true
	} else {
		//dur := time.Now().Sub(start)
		//fmt.Println(td.Sid, td.RecSecSinceEpoch, start.UnixNano(),  dur , "sampler not")
		// update the result for alpha server.
		// added by Yang. Only in prod
		if alp.alphaMode == LiveAlpha && alp.baseSidSet[sid] &&
			alp.func2TellAlphaUpdated != nil {
			alp.func2TellAlphaUpdated(alp.keyInAlphaServer, sid, 0, -1, td.RecSecSinceEpoch) // -1 means return back the last stamp and alpha is fine.
		}
		return false // sampler not successful
	}
}

func (alp *EquityAlpha) SidUniverse() []int {
	return alp.sidUniverse
}

func GenerateEquityAlpha(prefsName string, datestr string) {
	replay := data.NewFLBTickDataReplay(prefsName, datestr, true)

	alp := &EquityAlpha{}
	alp.Init(prefsName, "EquityAlpha", datestr, false)

	replay.RegisterTickdataUpdate(func(slice *data.TesTOBSlice) {
		alp.OnTickdataUpdate(slice)
	}, alp.sidUniverseWithIndex)

	replay.RegisterTeardown(alp.PublishData)

	replay.RegisterTeardown(func() {
		fmt.Println("I am in EquityAlpha's Teardown.")
	})

	// event loop
	replay.Replay()
}
