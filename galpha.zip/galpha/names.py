# global unique name producer
from itertools import count

global_counter = count()
global_prefix = "__GALPHA__"

def unique_name(prefix=None):
    if prefix is None:
        return "{}{}".format(global_prefix, next(global_counter))
    return "{}_{}".format(prefix, next(global_counter))
def setup_prefix(n):
    global global_prefix
    old = global_prefix
    global_prefix = n
    return old