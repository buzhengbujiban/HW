from .galpha import TickSupplyNode


def tick_supply(type, id, **kwargs):
    return TickSupplyNode(type=type, id=id, **kwargs)


def clock_tick_supply(id, start_hms="09:30:00", end_hms="15:00:00", interval = 60, all_sids = False, market=""):
    return tick_supply("clock_tick_supply", id=id, start_hms=start_hms, end_hms=end_hms, interval = interval, all_sids = all_sids, market=market)


def tbl_tick_supply(id, fn, srcEpochCol="src_epoch", ourEpochCol="rec_epoch", sizeCol="", sizeThreshold=0, dataColumns=None, verbose=False):
    return tick_supply(
        "tbl_tick_supply", id=id, fn=fn,
        srcEpochCol=srcEpochCol, ourEpochCol=ourEpochCol,
        sizeCol=sizeCol, sizeThreshold=sizeThreshold,
        dataColumns=dataColumns,
        verbose=verbose,
    )


def sdiv_tick_supply(id, fn, dataColumns=None):
    if dataColumns is None:
        return tick_supply("sdiv_tick_supply", id=id, fn=fn)
    return tick_supply("sdiv_tick_supply", id=id, fn=fn, dataColumns=dataColumns)
