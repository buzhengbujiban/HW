from .galpha import (XSNode, reset_nodes, nodes, Node, GAlpha)

import os
import json

def picker(name, **kwargs):
    return XSNode("picker", name, **kwargs)

def demean(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_dm"
    return XSNode("demean", name, input=[x.name], **kwargs)

def barra_residual(x, regType, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_{regType}"
    return XSNode("barra", regType=regType, name=name, input=[x.name], **kwargs)

def barra_mean(x, regType, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_{regType}_mean"
    return XSNode("barra_mean", regType=regType, name=name, input=[x.name], **kwargs)

def univ_mean(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_univ_mn"
    return unary("univ_mn", x, name=name, **kwargs)

def univ_sum(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_univ_sm"
    return unary("univ_sm", x, name=name, **kwargs)
    
def univ_rank(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_univ_rank"
    return XSNode("univ_rank", name=name, input=[x.name], **kwargs)

def sw2_mean(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_sw2_mn"
    return XSNode("sw_mn", name=name, input=[x.name], **kwargs)
    
def sw2_sum(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_sw2_sm"
    return XSNode("sw_sm", name=name, input=[x.name], **kwargs)

def sw2_rank(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_sw2_rank"
    return XSNode("sw_rank", name=name, input=[x.name], **kwargs)

def sw2_sd(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_sw2_sd"
    return XSNode("sw_sd", name=name, input=[x.name], **kwargs)

def sw2_z(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_sw2_z"
    return div(sw2_mean(x), sw2_sd(x), name=name, invalidTo=0, **kwargs)

def rank(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_rank"
    return XSNode("rank", name=name, input=[x.name], **kwargs)

def mean(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_mn"
    return XSNode("mean", name=name, input=[x.name], **kwargs)

def scale(x, scale, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_scale{scale}"
    return XSNode("scale", scale=scale, name=name, input=[x.name], **kwargs)

def std(x, name=None, **kwargs):
    if name is None: 
        name = f"{x.name}_std"
    return XSNode("std", name=name, input=[x.name], **kwargs)

def ema(x, hl, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_{hl}_ema"
    return XSNode("Ema", input=[x.name], hl=hl, name=name, **kwargs)

def ems(x, hl, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_{hl}_ems"
    return XSNode("Ems", input=[x.name], hl=hl, name=name, **kwargs)

def rolling_mean(x, window, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_rm{window}"
    return unary("rolling_mean", x, name=name, window=window, **kwargs)

def shift(x, window, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_shift{window}"
    return unary("shift", x, name=name, window=window, **kwargs)

def firstPass(x,fpass="09:30:00", name=None, **kwargs):
    if name is None:
        name = f"{x.name}_first"
    return unary("FirstPass", x, name=name, fpass=fpass, **kwargs)

def clip(x, lower, upper, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_clip_{lower}_{upper}"
    return unary("Clip", x, name=name, lower=lower, upper=upper, **kwargs)

def winsorize(x, probs=(0.05, 0.95), name=None, **kwargs):
    l, u = probs
    if name is None:
        name = f"{x.name}_winsorize_q{u}_{l}"
    return unary("Winsorize", x, name=name, lowerQuantile=l, upperQuantile=u, **kwargs)

# Binary operators
def binary(ntype, a, b, name=None, **kwargs):
    return XSNode(ntype, input=[a.name,b.name], name=name, **kwargs)

def add(a, b, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{b.name}_p"
    return binary("Add", a, b, name=name, **kwargs)

def sub(a, b, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{b.name}_s"
    return binary("Sub", a, b, name=name, **kwargs)

def sub_scalar(a, scalar, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{scalar}_s"
    return unary("SubScalar", a, scalar=scalar, name=name, **kwargs)

def div(a, b, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{b.name}_d"
    return binary("Div", a, b, name=name, **kwargs)

def div_scalar(a, scalar, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{scalar}_d"
    return unary("DivScalar", a, scalar=scalar, name=name, **kwargs)

def mul(a, b, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{b.name}_m"
    return binary("Mul", a, b, name=name, **kwargs)

def mid(a, b, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{b.name}_mid"
    return binary("Mid", a, b, name=name, **kwargs)

def logret(a, b, invalidToZero=False, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{b.name}_logret"
    return binary("Logret", a, b, invalidToZero=invalidToZero, name=name, **kwargs)

def greater(a, b, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{b.name}_greater"
    return binary("Greater", a, b, name=name, **kwargs)

def less(a, b, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{b.name}_less"
    return binary("Less", a, b, name=name, **kwargs)

def deviate(a, b, mode, clip=None, invalidToZero=False, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{b.name}_dev_{mode}"
    assert mode in ["div", "sub", "sub_div"]
    param = {}
    param.update(kwargs)
    if clip is not None:
        lower, upper = clip
        param['lower'] = lower
        param['upper'] = upper
    return binary("Deviate", a, b, mode=mode, invalidToZero=invalidToZero, name=name, **param)

def pressure_ab(a, b, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{b.name}_abp"
    return binary("PressureAB", a, b, name=name, **kwargs)

# Unary operaotors
def unary(ntype, a, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_{ntype}"
    return XSNode(ntype, input=[a.name], name=name, **kwargs)

def invalid_to_zero(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_itz"
    return unary("invalidToZero", x, name=name, **kwargs)

def cumsum(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_cumsum"
    return unary("cumsum", x, name=name, **kwargs)

def tsmean(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_tsmean"
    return unary("tsmean", x, name=name, **kwargs)

def greater_scalar(a, scalar, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_greater_{scalar}"
    return unary("GreaterScalar", a, name=name, scalar=scalar, **kwargs)

def less_scalar(a, scalar, name=None, **kwargs):
    if name is None:
        name = f"{a.name}_less_{scalar}"
    return unary("LessScalar", a, name=name, scalar=scalar, **kwargs)

### generated from codegen/xs_unary_codegen.py 
def log(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_log"
    return unary("Log", x, name=name, **kwargs)

def log10(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_log10"
    return unary("Log10", x, name=name, **kwargs)

def log1p(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_log1p"
    return unary("Log1p", x, name=name, **kwargs)

def log2(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_log2"
    return unary("Log2", x, name=name, **kwargs)

def abs(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_abs"
    return unary("Abs", x, name=name, **kwargs)

def cbrt(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_cbrt"
    return unary("Cbrt", x, name=name, **kwargs)

def ceil(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_ceil"
    return unary("Ceil", x, name=name, **kwargs)

def floor(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_floor"
    return unary("Floor", x, name=name, **kwargs)

def exp(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_exp"
    return unary("Exp", x, name=name, **kwargs)

def exp2(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_exp2"
    return unary("Exp2", x, name=name, **kwargs)

def expm1(x, name=None, **kwargs):
    if name is None:
        name = f"{x.name}_expm1"
    return unary("Expm1", x, name=name, **kwargs)


### generated from codegen/xs_unary_codegen.py 

class SDIVNode(Node):
    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)

def sdiv_provider(fn, primary=False, **kwargs):
    return SDIVNode(fn=fn, primary=primary, **kwargs)

class XSDag():
    def __init__(self, out='', **kwargs) -> None:
        self.params = {}
        self.out = out
        self.sdivs = []
        self.xsnodes = []
        self.params.update(kwargs)

    def add(self, *ns):
        for node in ns:
            clz = type(node)
            if issubclass(clz, (XSNode, )):
                self.xsnodes.append(node)
            elif issubclass(clz, SDIVNode):
                self.sdivs.append(node)
            else:
                raise RuntimeError(f"not supported node {node}")

    def getcfg(self, **kwargs):
        params = self.params.copy()
        params.update(kwargs)
        xs_param = []
        sdiv_param = []
        for sdiv in self.sdivs:
            sdiv_param.append(sdiv.params)
        for xsn in self.xsnodes:
            xs_param.append(xsn.params)
        params["sdiv"] = sdiv_param
        params["node"] = xs_param
        params['out'] = self.out
        return params

    def cfggen(self, json_fn, **kwargs):
        cfg = self.getcfg(**kwargs)
        folder = os.path.dirname(json_fn)
        if not os.path.exists(folder):
            print("creating", folder)
            os.makedirs(folder)
        with open(json_fn, "w") as fh:
            json.dump(cfg, fh, indent=2)

    def __enter__(self):
        reset_nodes()
        return self

    def __exit__(self, *exc_details):
        self.add(*nodes())
        

class XSAnalysis(object):
    def __init__(self, graph) -> None:
        assert isinstance(graph, (GAlpha, XSDag)), f"require GAlpha, got {type(graph)}"
        self.name_map = XSNode.name_map
        self.graph = graph
        self.xsnodes = graph.xsnodes

    def detect_dead(self):
        pass

    def build_graph(self):
        import matplotlib.pyplot as plt
        import networkx as nx
        G = nx.DiGraph()
        name_map = self.name_map
        sinks = []
        starts = []
        for n in self.xsnodes:
            n.__onodes__ = []
            n.__inodes__ = []
            G.add_node(n.name)
            if 'input' not in n.params:
                # starting node
                starts.append(n.name)
                continue
            inputs = n.params['input']
            if 'sink' in n.params and n.params['sink']:
                sinks.append(n.name)
            for iname in inputs:
                inode = name_map[iname]
                inode.__onodes__.append(n)
                n.__inodes__.append(inode)
                G.add_edge(inode.name, n.name)
        self.G = G
        self.sinks = sinks
        self.starts = starts

    def plot(self, fn, **kwargs):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import networkx as nx
        self.build_graph()
        pos = nx.spring_layout(self.G)
        # pos = nx.spiral_layout(self.G)
        param = {
            "node_size": 30,
            "font_size": 8,
        }
        param.update(**kwargs)
        # plt.figure(num=None, figsize=(30, 30), dpi=80)
        # plt.axis('off')
        # fig = plt.figure(1)
        nx.draw(self.G, pos, with_labels=True, **param)
        nx.draw_networkx_nodes(self.G, pos, nodelist=self.starts, node_color="yellow", **param)
        nx.draw_networkx_nodes(self.G, pos, nodelist=self.sinks, node_color="red", **param)
        plt.savefig(fn)
        # del fig
        # from networkx.drawing.nx_agraph import write_dot
        # write_dot(self.G, f"{fn}.dot")
    
    def build_graph_dot(self):
        import graphviz
        # refer to https://graphviz.org/doc/info/shapes.html
        G = graphviz.Digraph(format="svg")
        name_map = self.name_map
        sinks = []
        starts = []
        for n in self.xsnodes:
            n.__onodes__ = []
            n.__inodes__ = []
            if 'input' not in n.params:
                # starting node
                starts.append(n.name)
                G.node(n.name, shape="box")
                continue
            inputs = n.params['input']
            if 'sink' in n.params and n.params['sink']:
                sinks.append(n.name)
                G.node(n.name, color="red", shape="diamond")
            else:
                G.node(n.name, color="blue")
            for iname in inputs:
                inode = name_map[iname]
                inode.__onodes__.append(n)
                n.__inodes__.append(inode)
                G.edge(inode.name, n.name)
        self.sinks = sinks
        self.starts = starts
        return G

    def dot_plot(self, fn, **kwargs):
        import graphviz
        G = self.build_graph_dot()
        G.render(fn)

    def detect_dead(self, remove=False, expected=None):
        self.build_graph()
        visited = {n:False for n in self.name_map}
        def visit_node(node):
            for n in node.__inodes__:
                if visited[n.name]:
                    continue
                visited[n.name] = True
                visit_node(n)
        # if expected is set
        if expected is not None:
            assert isinstance(expected, list)
            sink_map = {s:True for s in self.sinks}
            # check expected names are all included.
            for n in expected:
                assert n in sink_map, f"[{n}] not found."
            # mark sink nodes as not sink if not in expected
            removed_sinks = []
            for sink in self.sinks:
                if sink not in expected:
                    node = self.name_map[sink]
                    node.params['sink'] = False
                    removed_sinks.append(sink)
            self.sinks = [s for s in self.sinks if s not in removed_sinks]
            print(f"flip {len(removed_sinks)} sink nodes")
        for sink in self.sinks:
            node = self.name_map[sink]
            visited[sink] = True
            visit_node(node)
        dead = []
        for n in self.xsnodes:
            if not visited[n.name]:
                dead.append(n)
        if remove:
            self.graph.xsnodes = [i for i in self.graph.xsnodes if i not in dead]
            self.xsnodes = self.graph.xsnodes
        return dead