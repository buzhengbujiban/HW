import qr
import pandas as pd
from itertools import product

class XYReader(object):
    def __init__(self, p) -> None:
        self.path = p
        self.xx = qr.tbl_read(p.replace("%XY%", "xx"))
        self.xy = qr.tbl_read(p.replace("%XY%", "xy"))
        self.yy = qr.tbl_read(p.replace("%XY%", "yy"))
        self.xy.index = self.xx.columns
        self.xx.index = self.xx.columns
        self.yy.index = self.yy.columns

    def cor(self, x, y):
        xy = self.xy.loc[x, y]
        xx = self.xx.loc[x, x]
        yy = self.yy.loc[y, y]
        return xy / (xx**0.5 * yy**0.5)
    
    def cor_df(self):
        df = pd.DataFrame(0, index=self.xy.index, columns=self.xy.columns)
        for x, y in product(df.index.values, df.columns.values):
            df.loc[x, y] = self.cor(x, y)
        return df