import qr
import nda
import numpy as np
import pandas as pd
import xarray as xr

def load_xr_dataset(path) -> xr.DataArray:
    return load_dataset(path, quiet=True)

def load_dataset(path, quiet=False) -> xr.DataArray:
    if not quiet:
        print(f"loading {path}")
    data = qr.sdiv_read(path)
    data['S'] = data['S'].astype(int)
    data['D'] = data['D'].astype(int)
    return data.to_dataset(dim='V')

def read_stream_sdiv_coords(meta_path):
    with open(meta_path, "r") as f:
        lines = [l.strip() for l in f.readlines()]
        dims = lines[0].split("|")
        return dict(zip(dims, [l.split("|") for l in lines[1:]]))

def read_stream_sdiv_as_xr(stream_path, dtype):
    meta_path = stream_path + ".meta"
    coords = read_stream_sdiv_coords(meta_path)
    arr = np.memmap(stream_path, dtype=dtype, mode="r", shape=tuple(len(coords[dim]) for dim in coords))
    res = xr.DataArray(arr, coords=coords, dims=list(coords.keys()))
    res['S'] = res['S'].astype(int)
    res['D'] = res['D'].astype(int)
    return res

def compare_csv(a, b):
    dta = pd.read_csv(a)
    dtb = pd.read_csv(b)
    return _compare_df(a, b, dta, dtb)

def compare_nda(a, b):
    nda1, nda2 = nda.NDAFile(a), nda.NDAFile(b)
    return nda1.read_all().equals(nda2.read_all())
    
def compare_tbl(a, b, cor_threshold=None):
    dta = qr.tbl_read(a)
    dtb = qr.tbl_read(b)
    return _compare_df(a, b, dta, dtb, cor_threshold=cor_threshold)

def compare_sdiv(a, b, acol=None, bcol=None, cor_threshold=None):
    aa = load_xr_dataset(a)
    bb = load_xr_dataset(b)
    if acol is not None:
        aa = aa[[acol]]
    if bcol is not None:
        bb = bb[[bcol]]
    dta = aa.to_dataframe()
    dtb = bb.to_dataframe()
    if len(dta.columns) == 1 and len(dtb.columns) == 1:
        dtb.columns = dta.columns
    return _compare_df(a, b, dta, dtb, cor_threshold=cor_threshold)

def compare_stream_sdiv_with_gold(stream_path, gold_path, dtype=np.float64):
    gold = load_xr_dataset(gold_path)
    sdiv = read_stream_sdiv_as_xr(stream_path, dtype).to_dataset(dim='V')
    dt_gold = gold.to_dataframe()
    dt_stream = sdiv.to_dataframe()

    if len(dt_stream.columns) == 1 and len(dt_gold.columns) == 1:
        dt_stream.columns = dt_gold.columns
    return _compare_df(stream_path, gold_path, dt_stream, dt_gold)


def _compare_df(a, b, dta, dtb, cor_threshold=None):
    same = dta.equals(dtb)
    if same:
        print("{} {} are same".format(a, b))
        return True

    print("{} {} diff".format(a, b))
    # check shape
    if dta.shape != dtb.shape:
        print(f"shape diff: {dta.shape} {dtb.shape}")
        return False
    print(f"columns(a) - columns(b) = {dta.columns.difference(dtb.columns).values}")
    print(f"columns(b) - columns(a) = {dtb.columns.difference(dta.columns).values}")
    cols = dta.columns.intersection(dtb.columns)
    result = True
    for i, col in enumerate(cols):
        r = dta[col].equals(dtb[col])
        if r:
            continue
        cor = dta[col].corr(dtb[col])
        if cor_threshold is not None:
            if cor >= cor_threshold:
                print(f"{i+1}th {col} OK with cor={cor}")
                continue
        result = False
        print(f"{i+1}th {col} error cor={cor}")
    return result

def corr_dfs(dta, dtb, quiet=True):
    df = pd.merge(dta, dtb, on=["sid", "rec_epoch"])
    cols = dta.columns.intersection(dtb.columns)
    cols = [i for i in dta.columns[5:].values if i in cols]
    corr = []
    for col in cols:
        xy = [f"{col}_x", f"{col}_y"]
        cc = df[xy].corr().iloc[0, 1]
        corr.append(cc)
        if not quiet:
            print(f"{col} corr={cc}")
    return corr

def corr_tbl(a, b, quiet=False):
    dta = qr.tbl_read(a)
    dtb = qr.tbl_read(b)
    return corr_tbl_impl(a, b, dta, dtb, quiet=quiet)

def corr_sdiv(a, b, acol=None, bcol=None):
    aa = load_xr_dataset(a)
    bb = load_xr_dataset(b)
    if acol is not None:
        aa = aa[[acol]]
    if bcol is not None:
        bb = bb[[bcol]]
    dta = aa.to_dataframe()
    dtb = bb.to_dataframe()
    if len(dta.columns) == 1 and len(dtb.columns) == 1:
        dtb.columns = dta.columns
    dta = dta.reset_index(['D', 'I', 'S'])
    dtb = dtb.reset_index(['D', 'I', 'S'])
    return corr_tbl_impl(a, b, dta, dtb, on=['D', 'I', 'S'])

def corr_tbl_impl(a, b, dta, dtb, quiet=False, on=['sid', 'rec_epoch']):
    """ report correlation of gold/test tbl
    """
    same = dta.equals(dtb)
    if same:
        print("{} {} are same".format(a, b))
        return True
    # check shape
    if dta.shape != dtb.shape:
        print(f"shape diff: {dta.shape} {dtb.shape}")
        #if dta.shape[0] != dtb.shape[0]:
        #    return False
    df = pd.merge(dta, dtb, on=on)
    cols = dta.columns.intersection(dtb.columns)
    black_list = ['event']
    cols = [i for i in cols if i not in on and i not in black_list]    
    corr = {}
    for col in cols:
        xy = [f"{col}_x", f"{col}_y"]
        cc = df[xy].corr().iloc[0, 1]
        corr[col] = cc
        if not quiet:
            print(f"{col} corr={cc}")
    return pd.Series(corr)
