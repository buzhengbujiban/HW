from .galpha import PullerNode, TermNode, TermValue
from .names import unique_name
from .alpha import default_alpha


def term(termType, name, alp, **kwargs):
    if name is None:
        name_prefix = kwargs.get("_name_prefix_")
        if name_prefix is not None:
            name = unique_name(prefix=name_prefix)
            del kwargs["_name_prefix_"]
        else:
            name = unique_name()
    if alp is None:
        alp = default_alpha()
    return TermNode(ttype=termType, name=name, alpha=alp, **kwargs)


def index_term(name=None, alp=None, **kwargs):
    return term("term_index", name=name, alp=alp, **kwargs)


def tob_term(name=None, alp=None, field="ask", **kwargs):
    # refer to variable tob_getters from term_tob.go for field allowed values
    return term("tob", name, alp, field=field, **kwargs)


def tob(name=None, alp=None, fields=None, **kwargs):
    allowed_fields = [
        "ask",
        "bid",
        "open",
        "high",
        "low",
        "asize",
        "bsize",
        "notional",
        "volume",
        "mid",
        "robust",
        "prevClose",
        "last",
        "oi",
    ]
    if fields is None:
        fields = allowed_fields
    else:
        for f in fields:
            assert f in allowed_fields, f"{f} not supported"
    return term("tob_whole", name, alp, fields=fields, **kwargs)


def oper_output(oname, name=None, alp=None):
    return term("holder", name=name, alp=alp, operOutputName=oname)


def dob_term(name=None, alp=None, **kwargs):
    return term("dob", name, alp, **kwargs)


def topn_term(nLevels, name=None, alp=None, **kwargs):
    return term("term_topn", name=name, alp=alp, nLevels=nLevels)


def lag_ret_term(
    name=None,
    alp=None,
    horizons=[60],
    ret_sod=1,
    use_for_alpha=False,
    use_ob_price=False,
    **kwargs,
):
    assert isinstance(horizons, list)
    return term(
        "ret_lag",
        name,
        alp,
        h_list=horizons,
        ret_label="ret",
        ret_sod=ret_sod,
        use_pbeta=0,
        use_for_alpha=use_for_alpha,
        use_ob_price=use_ob_price,
        **kwargs,
    )


def lag_mret_term(
    name=None,
    alp=None,
    horizons=[60],
    ret_sod=1,
    use_for_alpha=False,
    use_ob_price=False,
    **kwargs,
):
    assert isinstance(horizons, list)
    return term(
        "ret_lag",
        name,
        alp,
        h_list=horizons,
        ret_label="mret",
        ret_sod=ret_sod,
        use_pbeta=1,
        use_for_alpha=use_for_alpha,
        use_ob_price=use_ob_price,
        **kwargs,
    )


def ret_term(
    name=None,
    alp=None,
    horizons=[60],
    ret_eod=1,
    use_for_alpha=False,
    use_ob_price=False,
    **kwargs,
):
    assert isinstance(horizons, list)
    return term(
        "ret_in_day",
        name,
        alp,
        h_list=horizons,
        ret_label="ret",
        ret_eod=ret_eod,
        use_pbeta=0,
        use_for_alpha=use_for_alpha,
        use_ob_price=use_ob_price,
        **kwargs,
    )


def mret_term(
    name=None,
    alp=None,
    horizons=[60],
    ret_eod=1,
    use_pbeta=1,
    use_ob_price=False,
    **kwargs,
):
    assert isinstance(horizons, list)
    return term(
        "ret_in_day",
        name,
        alp,
        h_list=horizons,
        ret_label="mret",
        ret_eod=ret_eod,
        use_pbeta=use_pbeta,
        use_ob_price=use_ob_price,
        **kwargs,
    )


def ovret_term(horizons, ret_label, ret_bound=0.2, name=None, alp=None):
    assert ret_label in ["ret", "mret"]
    return term(
        "ret_cross_day",
        name,
        alp,
        h_list=horizons,
        ret_label=ret_label,
        ret_bound=ret_bound,
    )


def mret_term_ic(name=None, alp=None, horizons=[60], ret_eod=1, use_pbeta=1, **kwargs):
    """mret terms using self index price calc version"""
    assert isinstance(horizons, list)
    return term(
        "ret_in_day",
        name,
        alp,
        h_list=horizons,
        ret_label="mret",
        ret_eod=ret_eod,
        use_pbeta=use_pbeta,
        calc_index_price=True,
        **kwargs,
    )


def date_term(name=None, alp=None, **kwargs):
    return term("date", name=name, alp=alp, **kwargs)


def wgt_term(name=None, alp=None, **kwargs):
    return term("wgt", name=name, alp=alp, **kwargs)


def session_term(name=None, alp=None, **kwargs):
    return term("session", name=name, alp=alp, **kwargs)


def pull_term(
    pullType, freq, k=0, lagDays=0, mean=False, header="", name=None, alp=None
):
    return term(
        "pull",
        pullType=pullType,
        freq=freq,
        k=k,
        lagDays=lagDays,
        mean=mean,
        header=header,
        name=name,
        alp=alp,
    )


def puller_term(
    puller: PullerNode, k=0, lagDays=0, mean=False, header="", name=None, alp=None
):
    return term(
        "pull",
        pullType=puller.ptype,
        key=puller.Key(),
        k=k,
        lagDays=lagDays,
        mean=mean,
        header=header,
        name=name,
        alp=alp,
    )


def tick_supply_term(numData: int, supplyId=-1, name=None, alp=None):
    return term(
        "term_tick_supply", name=name, alp=alp, supplyId=supplyId, numData=numData
    )


def ob_add(name=None, alp=None):
    return term("OBAdd", name=name, alp=alp)


def ob_trade(name=None, alp=None):
    return term("OBTrade", name=name, alp=alp)


def ob_cancel(name=None, alp=None):
    return term("OBCancel", name=name, alp=alp)


def ob_count_term(name=None, alp=None):
    return term("OBCount", name=name, alp=alp)


def ob_spread(name=None, alp=None):
    return term("OBSpread", name=name, alp=alp)


def ob_book_term(name=None, alp=None):
    return term("OBBook", name=name, alp=alp)


def ob_ordersize(level, item, side, fromFreqTab, name=None, alp=None):
    return term(
        "OB_ordersize",
        name=name,
        alp=alp,
        level=level,
        item=item,
        side=side,
        fromFreqTab=fromFreqTab,
    )


def ob_levelsize(level, item, side, fromFreqTab, name=None, alp=None):
    return term(
        "OB_levelsize",
        name=name,
        alp=alp,
        level=level,
        item=item,
        side=side,
        fromFreqTab=fromFreqTab,
    )


def ob_orderslice(level, useOrderSlice, name=None, alp=None):
    return term(
        "OB_orderslice", name=name, alp=alp, level=level, useOrderSlice=useOrderSlice
    )


""" startIndex=5 is the default term starting position, but may be changed.
"""
def tbl_term(
    tbl_fn,
    startIndex=5,
    endIndex=-1,
    sidCol="sid",
    epochCol="rec_epoch",
    offset=-0.01,
    name=None,
    alp=None,
    useForAlpha=True,
    **kwargs,
):
    return term(
        "tbl",
        name=name,
        alp=alp,
        fn=tbl_fn,
        startIndex=startIndex,
        endIndex=endIndex,
        sidCol=sidCol,
        epochCol=epochCol,
        offset=offset,
        useForAlpha=useForAlpha,
        **kwargs,
    )


def sdiv_term(
    fn, startIndex=0, endIndex=-1, name=None, alp=None, useForAlpha=True, **kwargs
):
    return term(
        "sdiv",
        name=name,
        alp=alp,
        fn=fn,
        startIndex=startIndex,
        endIndex=endIndex,
        useForAlpha=useForAlpha,
        **kwargs,
    )


def sdiv_roll_term(inFn, ndays, suffix, name=None, alp=None):
    return term("sdiv_roll", inFn=inFn, ndays=ndays, suffix=suffix, name=name, alp=alp)


def dailystat(header, colname, logscale=False, name=None, alp=None):
    return term(
        "DailyStat",
        header=header,
        colname=colname,
        logscale=logscale,
        name=name,
        alp=alp,
    )


def daily_adv_term(colname="adv", name=None, alp=None):
    return dailystat(
        header="turnover.rw22", colname=colname, logscale=True, name=name, alp=alp
    )


def daily_spread_term(colname="spread", name=None, alp=None):
    return dailystat(header="avg_spread_bps.rw22", colname=colname, name=name, alp=alp)


def daily_topsize_term(colname="topsize", name=None, alp=None):
    return dailystat(
        header="avg_top_size.rw22", colname=colname, logscale=True, name=name, alp=alp
    )


def barrastat(header, colname, logscale=False, name=None, alp=None):
    return term(
        "BarraRisk",
        header=header,
        colname=colname,
        logscale=logscale,
        name=name,
        alp=alp,
    )


def barra_cap_term(colname="cap", name=None, alp=None):
    return barrastat(header="Capt", colname=colname, logscale=True, name=name, alp=alp)


def barra_trisk_term(colname="trisk", name=None, alp=None):
    return barrastat(header="TRisk", colname=colname, name=name, alp=alp)


def barra_srisk_term(colname="srisk", name=None, alp=None):
    return barrastat(header="SRisk", colname=colname, name=name, alp=alp)


def univ_term(colname="univ", name=None, alp=None):
    return term("Univ", colname=colname, name=name, alp=alp)


def comp_term(name=None, alp=None, debug=False, **kwargs):
    return term("comp", name=name, alp=alp, debug=debug, **kwargs)


def recorder_term(name=None, alp=None):
    return term("recorder", name=name, alp=alp)


def luld_term(name=None, alp=None, debugTerm=False, **kwargs):
    return term("luld", name=name, alp=alp, debugTerm=debugTerm, **kwargs)


def next_book_term(name=None, alp=None, fields=["ask1", "bid1"], **kwargs):
    return term("next.book", name, alp, fields=fields, **kwargs)


def fwd_mid_term(fwdSecs, avgMidPeriod, name=None, alp=None, **kwargs):
    return term(
        "term_fwd_mid", name, alp, fwdSecs=fwdSecs, avgMidPeriod=avgMidPeriod, **kwargs
    )


def fwd_ret_term(
    fwdSecs, midType="spot", gapSecs=0, avgMidPeriod=1, name=None, alp=None, **kwargs
):
    """midType could be spot or avg. avgMidPeriod only used when midType=avg"""
    return term(
        "term_fwd_ret",
        name,
        alp,
        fwdSecs=fwdSecs,
        midType=midType,
        avgMidPeriod=avgMidPeriod,
        gapSecs=gapSecs,
        **kwargs,
    )


def fwd_mret_term(
    fwdSecs, midType="spot", gapSecs=0, avgMidPeriod=1, name=None, alp=None, **kwargs
):
    """midType could be spot or avg. avgMidPeriod only used when midType=avg"""
    return term(
        "term_fwd_mret",
        name,
        alp,
        fwdSecs=fwdSecs,
        midType=midType,
        avgMidPeriod=avgMidPeriod,
        gapSecs=gapSecs,
        **kwargs,
    )


def fwd_price_range_term(fwdSecs, useOBMid, gapSecs=0, name=None, alp=None, **kwargs):
    return term(
        "term_fwd_range",
        name,
        alp,
        fwdSecs=fwdSecs,
        useOBMid=useOBMid,
        gapSecs=gapSecs,
        **kwargs,
    )


def bwd_price_range_term(useOBMid, name=None, alp=None, **kwargs):
    return term("term_bwd_range", name, alp, useOBMid=useOBMid, **kwargs)


def stream_latency_term(name=None, alp=None, **kwargs):
    return term("StreamLatency", name, alp, **kwargs)


def volatility_term(h_list, name=None, alp=None):
    return term("volatility", name=name, alp=alp, h_list=h_list)


def tk_basic_unary(op, inputCol: TermValue, name=None, alp=None, **kwargs):
    assert isinstance(inputCol, TermValue)
    if name is None:
        name = f"{inputCol.col}_{op}"
    return term(
        "term_unary", name=name, alp=alp, op=op, inputs=[inputCol._asdict()], **kwargs
    )


def tk_log(inputCol: TermValue, name=None, alp=None, **kwargs):
    return tk_basic_unary("log", inputCol=inputCol, name=name, alp=alp, **kwargs)


def tk_basic_binary(
    op, inputA: TermValue, inputB: TermValue, name=None, alp=None, **kwargs
):
    assert isinstance(inputA, TermValue)
    assert isinstance(inputB, TermValue)
    if name is None:
        name = f"{inputA.col}_{op}_{inputB.col}"
    return term(
        "term_binary",
        name=name,
        alp=alp,
        op=op,
        inputs=[inputA._asdict(), inputB._asdict()],
        **kwargs,
    )


def tk_sub(inputA: TermValue, inputB: TermValue, name=None, alp=None, **kwargs):
    return tk_basic_binary(
        "sub", inputA=inputA, inputB=inputB, name=name, alp=alp, **kwargs
    )


def tk_div(inputA: TermValue, inputB: TermValue, name=None, alp=None, **kwargs):
    return tk_basic_binary(
        "div", inputA=inputA, inputB=inputB, name=name, alp=alp, **kwargs
    )


def tk_rolling_mean(inputA: TermValue, window, name=None, alp=None, **kwargs):
    if name is None:
        name = f"{inputA.col}_rm{window}"
    return term(
        "term_rolling_mean",
        name=name,
        alp=alp,
        inputs=[inputA._asdict()],
        window=window,
        **kwargs,
    )


def tk_rolling_sum(inputA: TermValue, window, name=None, alp=None, **kwargs):
    if name is None:
        name = f"{inputA.col}_rs{window}"
    return term(
        "term_rolling_sum",
        name=name,
        alp=alp,
        inputs=[inputA._asdict()],
        window=window,
        **kwargs,
    )


def tk_ema(inputA: TermValue, hl_window, name=None, alp=None, **kwargs):
    if name is None:
        name = f"{inputA.col}_ema{hl_window}"
    return term(
        "term_exp_mean",
        name=name,
        alp=alp,
        inputs=[inputA._asdict()],
        hl=hl_window,
        **kwargs,
    )

def tk_diff(inputA: TermValue, fill_null = 0, name=None, alp=None, **kwargs):
    if name is None:
        name = f"{inputA.col}_diff"
    return term(
        "term_diff",
        name=name,
        alp=alp,
        inputs=[inputA._asdict()],
        fill_null = fill_null,
        **kwargs,
    )

def tk_expr(expr, inputs, name=None, alp=None, **kwargs):
    inputs = [i._asdict() for i in inputs]
    return term("term_expr", name=name, alp=alp, expr=expr, inputs=inputs, **kwargs)


def tk_max_ret(inputA: TermValue, window, name=None, alp=None, **kwargs):
    """
    calc max(rolling(window)) / current
    """
    if name is None:
        name = f"{inputA.col}_xr{window}"
    return term(
        "term_max_ret",
        name=name,
        alp=alp,
        inputs=[inputA._asdict()],
        window=window,
        **kwargs,
    )


def tk_min_ret(inputA: TermValue, window, name=None, alp=None, **kwargs):
    """
    calc min(rolling(window)) / current
    """
    if name is None:
        name = f"{inputA.col}_mr{window}"
    return term(
        "term_min_ret",
        name=name,
        alp=alp,
        inputs=[inputA._asdict()],
        window=window,
        **kwargs,
    )


def tk_range_ret(inputA: TermValue, window, name=None, alp=None, **kwargs):
    """
    calc (max(rolling(window)) - min(rolling(window))) / current
    """
    if name is None:
        name = f"{inputA.col}_rr{window}"
    return term(
        "term_range_ret",
        name=name,
        alp=alp,
        inputs=[inputA._asdict()],
        window=window,
        **kwargs,
    )


def tk_freq_diff(inputA: TermValue, freq, name=None, alp=None, **kwargs):
    """
    calc v - shift(v, 1)
    """
    if name is None:
        name = f"{inputA.col}_d{freq}"
    return term(
        "term_freq_diff",
        name=name,
        alp=alp,
        inputs=[inputA._asdict()],
        freq=freq,
        **kwargs,
    )


def tk_max(inputs, name=None, alp=None, **kwargs):
    inputs = [i._asdict() for i in inputs]
    return term("term_max", name=name, alp=alp, inputs=inputs, **kwargs)


def tk_min(inputs, name=None, alp=None, **kwargs):
    inputs = [i._asdict() for i in inputs]
    return term("term_min", name=name, alp=alp, inputs=inputs, **kwargs)


def tk_return_to_first(inputA: TermValue, name=None, alp=None, **kwargs):
    if name is None:
        name = f"{inputA.col}_ret_to_first"
    return term(
        "term_return_to_first", name=name, alp=alp, inputs=[inputA._asdict()], **kwargs
    )
