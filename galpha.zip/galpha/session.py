from argparse import ArgumentParser
import shutil
import subprocess
import shlex
import os

from .galpha import nodes, GAlpha
from .xs import XSDag
from .utils import relative

class Session:
    def __init__(self, date, univ, 
        exe = None, stopTime = None, market = "cneq", profile = None, memprofile = None, json_fn = None) -> None:
        self.date = date
        self.univ = univ
        self.stopTime = stopTime
        self.market = market
        if exe is None:
            self.exe = os.path.expanduser("~/git/galpha_admin/src/cmd/galpha-hist/galpha_sim_exe")
        else:
            self.exe = exe
        self.profile = profile
        self.memprofile = memprofile
        self.json_fn = json_fn

    def build(self, srcFile, goPath = None, trimpath=True, debug = False):
        OPT=""
        if trimpath:
            OPT="-trimpath"

        if debug:
            OPT += " -gcflags='all=-N -l'"

        if goPath is None:
            cmd = "cd {}; go build {} -o {} {}".format(os.path.dirname(self.exe), OPT, os.path.basename(self.exe), srcFile)
        else:
            cmd = "cd {}; export GOPATH={}; go build {} -o {} {}".format(os.path.dirname(self.exe), goPath, OPT, os.path.basename(self.exe), srcFile)
            
        print("Building {}".format(cmd))
        subprocess.run(cmd, shell=True, check=True)

    def _process(self, ga, wdir=".", **kwargs):
        json_fn = kwargs.get("json_fn")
        if json_fn is None:
            json_fn = self.json_fn
        else:
            del kwargs["json_fn"]
        if json_fn is None:
            json_fn = os.path.join(wdir, "galpha_cfg.json")
        stopTime = kwargs.get("stopTime")
        if stopTime is None:
            stopTime = self.stopTime
        date = kwargs.get("date")
        if date is None:
            date = self.date
        else:
            del kwargs["date"]
        univ = kwargs.get("univ")
        if univ is None:
            univ = self.univ
        else:
            del kwargs["univ"]
        assert isinstance(ga, (GAlpha, XSDag))
        if isinstance(ga, GAlpha) and len(ga.alphas) == 0:
            ga.add(*nodes())
        return json_fn, stopTime, date, univ
    
    def _gencmd(self, ga: GAlpha, date, stopTime, univ, json_fn, **kwargs):
        cmd = [self.exe, "--date", date, "--univ", univ, "--market", self.market]
        if 'out' in kwargs:
            out = kwargs['out']
            del kwargs['out']
            cmd.extend(['--out', out])
        else:
            assert len(ga.out) > 0, "missing [out] parameter"
        if stopTime is not None:
            cmd.extend(["--stopTime", stopTime])
        cmd += ["--json", json_fn]
        if self.profile is not None:
            cmd.extend(["--cpuprofile", self.profile])
        if self.memprofile is not None:
            cmd.extend(["--memprofile", self.memprofile])
        return cmd

    def install(self, ga: GAlpha, outdir, **kwargs):
        json_fn, stopTime, date, univ = self._process(ga, wdir=outdir, **kwargs)
        if not os.path.exists(outdir):
            os.makedirs(outdir)
        for i in ['json_fn', 'date', 'stopTime', 'univ']:
            if i in kwargs:
                del kwargs[i]
        ga.cfggen(json_fn, **kwargs)
        if os.path.dirname(self.exe) != outdir:
            print(f"copying {self.exe} to {outdir}")
            shutil.copy(self.exe, outdir)
        if os.path.dirname(json_fn) != outdir:
            print(f"copying {json_fn} to {outdir}")
            shutil.copy(json_fn, outdir)
        self.exe = os.path.join(outdir, os.path.basename(self.exe))
        cmd = self._gencmd(ga, date, stopTime, univ, json_fn, **kwargs)
        cmd_q = shlex.quote(' '.join(cmd))
        ga.cmd_template = cmd
        print('Command to run: {}'.format(cmd_q))

    def run(self, ga, wdir=".", **kwargs):
        json_fn, stopTime, date, univ = self._process(ga, wdir=wdir, **kwargs)
        for i in ['json_fn', 'date', 'stopTime', 'univ']:
            if i in kwargs:
                del kwargs[i]
        ga.cfggen(json_fn, **kwargs)
        cmd = self._gencmd(ga, date, stopTime, univ, json_fn, **kwargs)
        print('Running: {}'.format(shlex.quote(' '.join(cmd))))
        env = kwargs.get('env')
        if env:
            myenv = os.environ.copy()
            myenv.update(env)
            print(f"Running with {env}")
            subprocess.run(cmd, check=True, env=myenv)
        else:
            subprocess.run(cmd, check=True)

def arg_parser(understore_file):
    import datetime
    parser = ArgumentParser()
    parser.add_argument("--date", help="running date", default=datetime.datetime.today().strftime("%Y%m%d"))
    parser.add_argument("--univ", help="universe to run", default="topx")
    parser.add_argument("--exe", help="galpha binary", default=None)
    parser.add_argument("--stopTime", help="stop time", default="10:00:00")
    parser.add_argument("--market", help="market to run", default="CNEQ")
    # parser.add_argument("--out", help="output sampling", default="YYYYMMDD.tbl")
    parser.add_argument("--action", help="actions", default="run", choices=["build", "run", "install"])
    parser.add_argument("--json_fn", help="the json cfg path", default=relative(understore_file, ".log", "galpha.cfg.json"))
    parser.add_argument("--cpuprofile", help="cpu pprof file", default=None)
    return parser

def new_session(args):
    return Session(
        date=args.date, univ=args.univ, exe=args.exe, 
        stopTime=args.stopTime, market=args.market, profile=args.cpuprofile, json_fn=args.json_fn,
        )