from .galpha import EventNode, SnapEvent, PublishEvent
from .names import unique_name

def event(etype, name, **kwargs):
    if name is None:
        name = unique_name()
    return EventNode(etype=etype, name=name, **kwargs)

def eod_event(name=None):
    return event(etype="eod", name=name)

def trade_event(name=None, **kwargs):
    return event(etype="trade", name=name, **kwargs)

def dob_event(name=None, **kwargs):
    return event(etype="dob", name=name, **kwargs)

def topn_event(nLevels, name=None, **kwargs):
    return event("topn", name=name, nLevels=nLevels, **kwargs)

def tob_event(name=None, **kwargs):
    return event(etype="tob", name=name, **kwargs)

def index_event(name=None, IndexSids = [8753, 8998, 8581], **kwargs):
    return event(etype="index", name=name, IndexSids=IndexSids, **kwargs)

def flb_quote_event(name="flb_quote"):
    return event(etype="flb_quote", name=name)

def flb_agtrade_event(name="flb_agtrade"):
    return event(etype="flb_agtrade", name=name)

def flb_mid_event(name="flb_mid", **kwargs):
    return event(etype="flb_mid", name=name, **kwargs)

def tick_event(name=None, **kwargs):
    return event(etype="ticker", name=name, **kwargs)

def tick_rand_event(n, seed, name=None):
    return tick_event(name=name, producerType="rand", n=n, seed=seed)

def tick_from_tbl_event(tbl, sidCol="sid", epochCol="rec_epoch", offset=-0.01, name=None):
    return tick_event(name=name, producerType="tbl", tbl=tbl, sidCol=sidCol, epochCol=epochCol, offset=offset)

def snap(e):
    return SnapEvent(e)

def publish(e):
    return PublishEvent(e)

""" per sid timer event. """
def timer_event(useSrcTime, name=None, freq=60, skipFirst="1", useVolClock=False, **kwargs):
    return event(
        etype="timer",
        name=name,
        freq=freq,
        skipFirst=skipFirst,
        useSrcTime=useSrcTime,
        useVolClock=useVolClock,
        **kwargs
        )

""" global wall clock event. """
def clock_event(useSrcTime, name=None, freq=60, skipFirst="1", enforceBoundary=False, offsetToBoundary=0):
    return event(
        etype="clock",
        name=name,
        freq=freq,
        skipFirst=skipFirst,
        useSrcTime=useSrcTime,
        enforceBoundary=enforceBoundary,
        offsetToBoundary=offsetToBoundary,
        )

def clock_tick_supply_event(name = None, tick_supply_id = -1, is_global_event = True):
    return event(etype = "clock_tick_supply", name = name, tick_supply_id = tick_supply_id, is_global_event = is_global_event)

def tick_supply_event(name = None):
    return event(etype = "tick_supply", name = name)

def ob_add_event(name = None):
    return event(etype="ob_add_event", name=name)

def ob_trade_event(name = None):
    return event(etype="ob_trade_event", name=name)

def ob_cancel_event(name = None):
    return event(etype="ob_cancel_event", name=name)