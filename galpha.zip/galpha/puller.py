from .galpha import PullerNode
from .names import unique_name
from .alpha import default_alpha

def puller(ptype, freq="", key="", **kwargs):
    return PullerNode(ptype, freq=freq, key=key, **kwargs)


class Book(object):
    def __init__(self, freq):
        self.freq = freq
    
    @property
    def open(self): return puller("open", self.freq)
    @property
    def prev_close(self): return puller("prevclose", self.freq)
    @property
    def ret(self): return puller("ret", self.freq)
    @property
    def volume(self): return puller("volume", self.freq)
    @property
    def notional(self): return puller("notional", self.freq)
    @property
    def mid(self)    : return puller("mid"    , self.freq)
    @property
    def last(self)   : return puller("last"   , self.freq)
    @property
    def robust(self) : return puller("robust" , self.freq)
    @property
    def lrobust(self): return puller("lrobust", self.freq)
    @property
    def ask(self)    : return puller("ask"    , self.freq)
    @property
    def asize(self)  : return puller("asize"  , self.freq)
    @property
    def bid(self)    : return puller("bid"    , self.freq)
    @property
    def bsize(self)  : return puller("bsize"  , self.freq)
    @property
    def high(self)   : return puller("high"   , self.freq)
    @property
    def low(self)    : return puller("low"    , self.freq)

    @property
    def ask2(self)    : return puller("ask2"    , self.freq)
    @property
    def asize2(self)  : return puller("asize2"  , self.freq)
    @property
    def bid2(self)    : return puller("bid2"    , self.freq)
    @property
    def bsize2(self)  : return puller("bsize2"  , self.freq)

    @property
    def ask3(self)    : return puller("ask3"    , self.freq)
    @property
    def asize3(self)  : return puller("asize3"  , self.freq)
    @property
    def bid3(self)    : return puller("bid3"    , self.freq)
    @property
    def bsize3(self)  : return puller("bsize3"  , self.freq)


    @property
    def ask4(self)    : return puller("ask4"    , self.freq)
    @property
    def asize4(self)  : return puller("asize4"  , self.freq)
    @property
    def bid4(self)    : return puller("bid4"    , self.freq)
    @property
    def bsize4(self)  : return puller("bsize4"  , self.freq)

    @property
    def ask5(self)    : return puller("ask5"    , self.freq)
    @property
    def asize5(self)  : return puller("asize5"  , self.freq)
    @property
    def bid5(self)    : return puller("bid5"    , self.freq)
    @property
    def bsize5(self)  : return puller("bsize5"  , self.freq)

    @property
    def ask6(self)    : return puller("ask6"    , self.freq)
    @property
    def asize6(self)  : return puller("asize6"  , self.freq)
    @property
    def bid6(self)    : return puller("bid6"    , self.freq)
    @property
    def bsize6(self)  : return puller("bsize6"  , self.freq)

    @property
    def ask7(self)    : return puller("ask7"    , self.freq)
    @property
    def asize7(self)  : return puller("asize7"  , self.freq)
    @property
    def bid7(self)    : return puller("bid7"    , self.freq)
    @property
    def bsize7(self)  : return puller("bsize7"  , self.freq)

    @property
    def ask8(self)    : return puller("ask8"    , self.freq)
    @property
    def asize8(self)  : return puller("asize8"  , self.freq)
    @property
    def bid8(self)    : return puller("bid8"    , self.freq)
    @property
    def bsize8(self)  : return puller("bsize8"  , self.freq)

    @property
    def ask9(self)    : return puller("ask9"    , self.freq)
    @property
    def asize9(self)  : return puller("asize9"  , self.freq)
    @property
    def bid9(self)    : return puller("bid9"    , self.freq)
    @property
    def bsize9(self)  : return puller("bsize9"  , self.freq)

    @property
    def ask10(self)    : return puller("ask10"    , self.freq)
    @property
    def asize10(self)  : return puller("asize10"  , self.freq)
    @property
    def bid10(self)    : return puller("bid10"    , self.freq)
    @property
    def bsize10(self)  : return puller("bsize10"  , self.freq)

class Trade(object):
    def __init__(self, freq:str):
        self.freq = freq

    @property
    def price(self): return puller("trade_price", self.freq)
    @property
    def share(self): return puller("trade_share", self.freq)
    @property
    def notional(self): return puller("trade_notional", self.freq)
    @property
    def buyShare(self): return puller("trade_buyShare", self.freq)
    @property
    def buyNotional(self): return puller("trade_buyNotional", self.freq)
    @property
    def sellShare(self): return puller("trade_sellShare", self.freq)
    @property
    def sellNotional(self): return puller("trade_sellNotional", self.freq)
    @property
    def shareCum(self): return puller("trade_shareCum", self.freq)
    @property
    def notionalCum(self): return puller("trade_notionalCum", self.freq)
    @property
    def buyShareCum(self): return puller("trade_buyShareCum", self.freq)
    @property
    def buyNotionalCum(self): return puller("trade_buyNotionalCum", self.freq)
    @property
    def sellShareCum(self): return puller("trade_sellShareCum", self.freq)
    @property
    def sellNotionalCum(self): return puller("trade_sellNotionalCum", self.freq)
    @property
    def shareSeg(self): return puller("trade_shareSeg", self.freq)
    @property
    def notionalSeg(self): return puller("trade_notionalSeg", self.freq)
    @property
    def buyShareSeg(self): return puller("trade_buyShareSeg", self.freq)
    @property
    def buyNotionalSeg(self): return puller("trade_buyNotionalSeg", self.freq)
    @property
    def sellShareSeg(self): return puller("trade_sellShareSeg", self.freq)
    @property
    def sellNotionalSeg(self): return puller("trade_sellNotionalSeg", self.freq)

class Minute(object):
    @property
    def askPrice         (self): 
        return puller("minute_askPrice", freq="1m")         
    @property
    def bidPrice         (self): 
        return puller("minute_bidPrice", freq="1m")         
    @property
    def askSize          (self): 
        return puller("minute_askSize", freq="1m")         
    @property
    def bidSize          (self): 
        return puller("minute_bidSize", freq="1m")          
    @property
    def lastTradePrice   (self): 
        return puller("minute_lastTradePrice", freq="1m")   
    @property
    def volumeTotal      (self): 
        return puller("minute_volumeTotal", freq="1m")      
    @property
    def dollarVolumeTotal(self): 
        return puller("minute_dollarVolumeTotal", freq="1m")
    @property
    def midPriceLastValid(self): 
        return puller("minute_midPriceLastValid", freq="1m")



""" Price Range: High, Low, Open, Close per interval
"""
class PRange(object):
    def __init__(self, freq:str):
        self.freq = freq

    @property
    def high(self): return puller("range_high", self.freq)

    @property
    def low(self): return puller("range_low", self.freq)

    @property
    def open(self): return puller("range_open", self.freq)

    @property
    def close(self): return puller("range_close", self.freq)

def add(a:PullerNode, b:PullerNode, key: str):
    return puller("bi_add", key=key, akey=a.Key(), bkey=b.Key())

def lag(a:PullerNode, key: str=None):
    if key is None:
        key = unique_name()
    return puller("unary_lag", key=key, akey=a.Key())
