from .galpha import OperNode, EventNode
from .names import unique_name

def operator(creator_type, name, input, output, events, operatorType="Global", **kwargs):
    if name is None:
       name = unique_name()
    return OperNode(
        otype=creator_type, operatorType=operatorType, 
        name=name, input=input, output=output, 
        events=events,
        **kwargs)

def op_demean(input, output, events, name=None):
    return operator("demean", name, input, output, events)