import json
import os
from galpha.names import unique_name
from .utils import relative

GF_ROOT = relative(__file__, "../..")
GF_SIM_EXE = relative(__file__, "../..", "src/cmd/galpha-hist/galpha_sim_exe")
class Node:
    nodes = []
    alpha_names = {}
    def __init__(self, **kwargs) -> None:
        self.params = {}
        self.params.update(kwargs)
        self.__class__.nodes.append(self)

    def update_param(self, **kwargs):
        assert 'name' not in kwargs
        self.params.update(kwargs)
    
    def get_param(self, key, d):
        return self.params.get(key, d)

def reset_nodes():
    Node.nodes = []
    Node.alpha_names.clear()

def nodes():
    return Node.nodes

def add_node(n):
    assert n not in nodes()
    Node.nodes.append(n)

def query_alpha(n):
    if n not in Node.alpha_names:
        return None
    return Node.alpha_names[n]

def add_alpha(n, ins):
    Node.alpha_names[n] = ins

class EventNode(Node):
    def __init__(self, etype, name, **kwargs) -> None:
        self.name = name
        super().__init__(type=etype, name=name, **kwargs)

class AlphaNode(Node):
    def __init__(self, atype, name, **kwargs) -> None:
        self.name = name
        super().__init__(type=atype, name=name, **kwargs)

def test_key(n, v):
    if v in n and n[v]:
        return True
    return False

class XSNode(Node):
    name_map = {}
    def __init__(self, atype, name, **kwargs) -> None:
        self.name = name
        if name in self.__class__.name_map:
            # dedup logic
            tmp = dict(type=atype, name=name)
            tmp.update(**kwargs)
            old = self.__class__.name_map[name]
            if test_key(tmp, 'sink') or test_key(old.params, 'sink'):
                # if any is sink node, then it is sink node
                tmp['sink'] = True
                old.params['sink'] = True
            if 'sink' in tmp or 'sink' in old.params:
                if 'sink' not in tmp:
                    tmp['sink'] = old.params['sink']
                if 'sink' not in old.params:
                    old.params['sink'] = tmp['sink']
            if tmp == old.params:
                self = old
                return
            raise RuntimeError(f"{name} dup with different params. {old.params} {tmp}")
        self.__class__.name_map[name] = self
        super().__init__(type=atype, name=name, **kwargs)
    def update_name(self, name):
        old = self.__class__.name_map[self.name]
        del self.__class__.name_map[self.name]
        self.name = name
        self.__class__.name_map[self.name] = old
        self.params['name'] = name


from collections import namedtuple
TermValue = namedtuple('TermValue', ['term', 'col'])

class TermNode(Node):
    def __init__(self, ttype, name, alpha, **kwargs) -> None:
        self.name = name
        self.alpha = alpha
        assert issubclass(type(alpha), AlphaNode)
        super().__init__(type=ttype, name=name, alpha=alpha.name, **kwargs)

    def v(self, col_name=None):
        if col_name is None:
            col_name = self.name
        return TermValue(self.name, col_name)

class PullerNode(Node):
    def __init__(self, ptype, freq="", key="", **kwargs) -> None:
        self.key = key
        self.freq = freq
        self.ptype = ptype
        super().__init__(type=ptype, freq=freq, key=key, **kwargs)

    def Key(self):
        if len(self.key) > 0: return self.key
        return "{}-{}".format(self.ptype, self.freq)

    def SetKey(self, s:str):
        self.key = s
        self.params['key'] = s

    def __add__(self, b):
        if isinstance(b, PullerNode):
            return PullerNode("bi_add", key=unique_name(), akey=self.Key(), bkey=b.Key())
        return PullerNode("bi_add", key=unique_name(), akey=self.Key(), bval=float(b))
    def __sub__(self, b):
        if isinstance(b, PullerNode):
            return PullerNode("bi_sub", key=unique_name(), akey=self.Key(), bkey=b.Key())
        return PullerNode("bi_sub", key=unique_name(), akey=self.Key(), bval=float(b))
    def __mul__(self, b):
        if isinstance(b, PullerNode):
            return PullerNode("bi_mul", key=unique_name(), akey=self.Key(), bkey=b.Key())
        return PullerNode("bi_mul", key=unique_name(), akey=self.Key(), bval=float(b))
    def __truediv__(self, b):
        if isinstance(b, PullerNode):
            return PullerNode("bi_div", key=unique_name(), akey=self.Key(), bkey=b.Key())
        return PullerNode("bi_div", key=unique_name(), akey=self.Key(), bval=float(b))

class OperNode(Node):
    def __init__(self, otype:str, operatorType:str, name:str, input:TermNode, output:TermNode, events, **kwargs):
        self.name = name
        assert issubclass(type(input), TermNode)
        assert issubclass(type(output), TermNode)
        ot = operatorType.lower()
        assert ot in ["global", "persid"], f"not supported operator type: {operatorType}"
        params = {}
        params.update(kwargs)
        # change input and output to in and out
        params["in"] = input.name
        params["out"] = output.name
        params["operType"] = operatorType
        params["namespace"] = "term"
        if isinstance(events, EventNode):
            events = [events.name]
        if isinstance(events, str):
            events = [events]
        params["events"] = events
        super().__init__(type=otype, name=name, **params)

class SnapEvent:
    def __init__(self, e) -> None:
        assert isinstance(e, EventNode)
        self.e = e
        add_node(self)

    def name(self):
        return self.e.name

class PublishEvent:
    def __init__(self, e) -> None:
        assert isinstance(e, EventNode)
        self.e = e
        add_node(self)

    def name(self):
        return self.e.name

class TickSupplyNode(Node):
    def __init__(self, type, id, **kwargs) -> None:
        self.id = id
        super().__init__(type=type, id=id, **kwargs)

class GAlpha():
    def __init__(self, out='', **kwargs) -> None:
        self.params = {}
        self.pullers = []
        self.alphas = []
        self.terms = []
        self.opers = []
        self.events = []
        self.ticksupplys = []
        self.snapEvent = []
        self.publishEvent = []
        self.out = out
        self.xsnodes = []
        self.params.update(kwargs)

    def add(self, *ns):
        for node in ns:
            clz = type(node)
            if issubclass(clz, PullerNode):
                self.pullers.append(node)
            elif issubclass(clz, EventNode):
                self.events.append(node)
            elif issubclass(clz, AlphaNode):
                self.alphas.append(node)
            elif issubclass(clz, TermNode):
                self.terms.append(node)
            elif issubclass(clz, OperNode):
                self.opers.append(node)
            elif issubclass(clz, SnapEvent):
                self.snapEvent.append(node.name())
            elif issubclass(clz, PublishEvent):
                self.publishEvent.append(node.name())
            elif issubclass(clz, TickSupplyNode):
                self.ticksupplys.append(node)
            elif issubclass(clz, XSNode):
                self.xsnodes.append(node)
            else:
                raise RuntimeError(f"not supported node {node}")

    def getcfg(self, **kwargs):
        params = self.params.copy()
        params.update(kwargs)
        alpha_param = []
        term_param = []
        event_param = []
        oper_param = []
        puller_param = []
        ticksupply_param = []
        for puller in self.pullers:
            puller_param.append(puller.params)
        for alpha in self.alphas:
            alpha_param.append(alpha.params)
        for term in self.terms:
            term_param.append(term.params)
        for event in self.events:
            event_param.append(event.params)
        for oper in self.opers:
            oper_param.append(oper.params)
        for ticksupply in self.ticksupplys:
            ticksupply_param.append(ticksupply.params)
        if len(puller_param) > 0:
            params['puller'] = puller_param
        params['event'] = event_param
        params['alpha'] = alpha_param
        params['term'] = term_param
        params['tick_supply'] = ticksupply_param
        if len(self.xsnodes) > 0:
            xs_param = []
            for xsn in self.xsnodes:
                xs_param.append(xsn.params)
            if "XSDAG" in params:
                params["XSDAG"]["node"] = xs_param
            else:
                params["XSDAG"] = {"node": xs_param}
        if len(oper_param) > 0:
            params['oper'] = oper_param
        params['snapEvent'] = self.snapEvent
        if len(self.publishEvent) > 0:
            params['publishEvent'] = self.publishEvent
        params['out'] = self.out
        # reorder
        if 'XSDAG' in params:
            keys = [k for k in params if k != 'XSDAG'] + ['XSDAG']
            params = {k:params[k] for k in keys}
        return params

    def cfggen(self, json_fn, **kwargs):
        cfg = self.getcfg(**kwargs)
        folder = os.path.dirname(json_fn)
        if not os.path.exists(folder):
            print("creating", folder)
            os.makedirs(folder)
        with open(json_fn, "w") as fh:
            json.dump(cfg, fh, indent=2)

    def __enter__(self):
        reset_nodes()
        return self

    def __exit__(self, *exc_details):
        self.add(*nodes())
        