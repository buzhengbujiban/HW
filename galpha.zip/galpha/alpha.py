from .galpha import AlphaNode, add_alpha, query_alpha
from .names import unique_name

g_alpha = None

def default_alpha(a=None):
    global g_alpha
    if a is not None:
        g_alpha = a
    assert g_alpha is not None
    return g_alpha

def alpha(atype, name, **kwargs):
    if name is not None:
        ins = query_alpha(name)
        if ins is not None:
            return ins
    else:
        name = unique_name()
    ins = AlphaNode(atype=atype, name=name, **kwargs)
    add_alpha(name, ins)
    return ins
    
def dummy_alpha(name=None, **kwargs):
    return alpha("dummy", name, **kwargs)

def flbdiff_alpha(name=None, **kwargs):
    return alpha("alpha_flbdiff", name=name, **kwargs)
    
def null_alpha(name=None, **kwargs):
    return alpha("null", name, **kwargs)