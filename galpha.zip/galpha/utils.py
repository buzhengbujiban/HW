import os

def relative(dotdotfiledotdot, *args):
    dir = os.path.abspath(os.path.dirname(dotdotfiledotdot))
    return os.path.abspath(os.path.join(dir, *args))

def plugin(so, config):
    return {
        "so": so,
        "config": config,
    }