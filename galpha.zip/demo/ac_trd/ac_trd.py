#!/usr/bin/env python

import pqsum_py.msg_info as mi
import pqsum_py.runner as runner
from jobs.rnodes.rnode import RNode
from pqsum_py.models import *
import gflow as gf
import os
import copy

pqNode = PQNode()

filters = [
    # PQFilter(name="act", expr=mi.act.IsValid),
    PQFilter(
        name="cl1", expr=(mi.act.IsValid & mi.act.CL)
    ),  # 千万注意：不可以使用 and 操作符，python中 and/or是无法override的
    # PQFilter(name="cl2", expr=mi.act.IsValid & mi.act.LV >= 1),
]
pqNode.pq_filters.extend(filters)

terms = [
    PQTerm(name="ap0", snap=True, expr=mi.bk.AP0),
    PQTerm(name="bp0", snap=True, expr=mi.bk.BP0),
    PQTerm(name="aq0", snap=True, expr=mi.bk.AQ0),
    PQTerm(name="bq0", snap=True, expr=mi.bk.BQ0),
    PQTerm(name="lap0", snap=True, expr=mi.bk.LastAP0),
    PQTerm(name="lbp0", snap=True, expr=mi.bk.LastBP0),
    PQTerm(name="laq0", snap=True, expr=mi.bk.LastAQ0),
    PQTerm(name="lbq0", snap=True, expr=mi.bk.LastBQ0),
    PQTerm(name="oid", snap=True, expr=mi.act.ID),
    PQTerm(name="tp", snap=True, expr=mi.act.P),
    PQTerm(name="tq", snap=True, expr=mi.act.Q),
    PQTerm(name="tss", snap=True, expr=mi.act.TSS),
    PQTerm(name="d", snap=True, expr=mi.act.D),
    PQTerm(name="d2", snap=True, expr=mi.act.D2),
    PQTerm(name="n", snap=True, expr=mi.act.N),
    PQTerm(name="lv", snap=True, expr=mi.act.LV),
    PQTerm(name="cl", snap=True, expr=mi.act.CL),
    PQTerm(name="sp", snap=True, expr=mi.act.SP),
    PQTerm(name="lq", snap=True, expr=mi.act.LQ),
    PQTerm(name="isA", snap=True, expr=mi.act.IsS),
    PQTerm(name="isB", snap=True, expr=mi.act.IsB),
]
pqNode.pq_stats.extend(terms)


RNode.RNODE_ROOT = gf.relative(__file__, ".log")
os.system(f"rm -rf {RNode.RNODE_ROOT}")
RNode.GLOBAL_TASKNAME = "actrd"
node = runner.PQSumNode([pqNode])
node.clockFreq = 300
node.startTime = "09:35:00"
node.stopTime = "15:01:00"
node.build_orderbook = True
# node.use_persid_md = False
# node.univ = "all"
node.univ = "sids:1,1988"
# node.univ = "~/git/golibs/src/TES/QR/alpbase_foobar/dg/pqsum/sids.csv"
node.sdate = "20231212"
node.edate = "20231212"
node.exclude_dates = []
node.parallel_spec = "1"
# node.use_persid_md = False
# node.persid_threads = 4
node.eod_out = f"{node.proj}/YYYYMMDD_eod.sdiv"

# node.msg_info_cfgs["act"] = {"test": "hello world"}

# node.slurm_enable = True
# node.slurm_cfg = {
#             "slurm": 1,
#             "slurmQueue": 'fqueue', "slurmJobName": "pq_sum",
#             "slurmForceProgress": 1, "retries": 1,
#             "slurmNfs": 'nas6:2', "smem": 20000,
# }

node.init_galpha()

pub0 = node.galpha_meta["pubs"][0]
pub_filter = copy.deepcopy(pub0)
pub_filter["out"] = f"{node.proj}/new_YYYYMMDD.sdiv"
pub_filter["SdivPublish"]["vFilters"] = ["cl1.ap0.p1", "cl1.bp0.p1"]
node.galpha_meta["pubs"].append(pub_filter)

# pub_shm = copy.deepcopy(pub0)
# pub_shm["out"] = f"/dev/shm/ac_trd_YYYYMMDD.sdiv"
# node.galpha_meta["pubs"].append(pub_shm)

node.run()