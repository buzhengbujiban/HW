#!/usr/bin/env python

import pqsum_py.msg_info as mi
import pqsum_py.runner as runner
from jobs.rnodes.rnode import RNode
from pqsum_py.models import *
import gflow as gf
import os

pqNode = PQNode()

filters = [
    PQFilter(name="add_order", expr=(mi.add.IsValid)), 
]
pqNode.pq_filters.extend(filters)

terms = [
    PQTerm(name="ID", snap=True, expr=mi.add.ID),
    PQTerm(name="P", snap=True, expr=mi.add.P),
    PQTerm(name="Q", snap=True, expr=mi.add.Q),
    PQTerm(name="TSS", snap=True, expr=mi.add.TSS),
    PQTerm(name="TSO", snap=True, expr=mi.add.TSO),
    PQTerm(name="D", snap=True, expr=mi.add.D),
    PQTerm(name="D2", snap=True, expr=mi.add.D2),
    PQTerm(name="L", snap=True, expr=mi.add.L),
    PQTerm(name="QB", snap=True, expr=mi.add.QB),
    PQTerm(name="NB", snap=True, expr=mi.add.NB),
    PQTerm(name="TTQB", snap=True, expr=mi.add.TTQB),
    PQTerm(name="TTNB", snap=True, expr=mi.add.TTNB),
]
pqNode.pq_stats.extend(terms)


RNode.RNODE_ROOT = gf.relative(__file__, ".log")
os.system(f"rm -rf {RNode.RNODE_ROOT}")

RNode.GLOBAL_TASKNAME = "add"
node = runner.PQSumNode([pqNode])
node.clockFreq = 300
node.startTime = "09:35:00"
node.stopTime = "15:01:00"
node.build_orderbook = True
# node.univ = "hs300"
node.univ = "sids:1,1988" 
# node.univ = "sids:241" 
node.sdate = "20231212"
node.edate = "20231212"
node.exclude_dates = []
node.parallel_spec = "1"
# node.use_persid_md = False
# node.persid_threads = 4
# node.eod_out = f"{node.proj}/YYYYMMDD_eod.sdiv"

node.init_galpha()
node.run()