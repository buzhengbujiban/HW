import os
import sys
from pathlib import Path
from jobs.rnodes.rnode import RNode
from dash import Dash, dcc, html
import plotly.graph_objects as go
from pqsum_py.apps.tick_chart_plotter import TickChartPlotter
import pqsum_py.msg_info as mi
from pqsum_py.runner import PQSumNode

if __name__ == '__main__':
    RNode.RNODE_ROOT = f"/tmp/{os.environ['USER']}/rroot"
    RNode.GLOBAL_TASKNAME = f"{Path(__file__).stem}"

    DATE = int(sys.argv[-1])
    # DATE = 20240930
    # DATE = 20210803
    # DATE = 20231211
    # DATE = 20241127
    # DATE = 20241126
    # DATE = 20241128
    # DATE = 20241129
    # DATE = 20241205

    SYMBOL = "1"
    SYMBOL = "1009"
    SYMBOL = "1362"
    # DATE = "20240314"
    SYMBOL = "1"
    SYMBOL = "10214"
    SYMBOL = "1749"
    SYMBOL = "631"
    SYMBOL = "43"
    SYMBOL = "10059"
    SYMBOL = "10234"
    SYMBOL = "1100"
    SYMBOL = "1969"

    # SYMBOL = "1988"

    pq_node = TickChartPlotter.base_pq_node(max_levels=20)
    # pq_node.use_persid_md = False
    pq_node.EXE = PQSumNode.PQSUM_RELEASE_EXE
    pq_node.EXE = PQSumNode.PQSUM_DEBUG_EXE
    pq_node.build_exe()
    price = 11.88

    def is_aft_trd(info, thres=0.1):
        return ((info.TSO - mi.act.LastT) < mi.ut.C(thres)) & ((info.TSO - mi.act.LastT) > mi.ut.C(0.001))

    TickChartPlotter.add_markers_to_pq(
        pq_node, mi.act.IsValid & mi.act.IsValid & is_aft_trd(mi.act, thres=0.1),
        mi.act.P, mi.act.Q, "act"
    )
    TickChartPlotter.add_markers_to_pq(
        pq_node, mi.act.IsValid & mi.act.IsValid & is_aft_trd(mi.act, thres=1),
        mi.act.P, mi.act.TSO - mi.act.LastT, "TS_O_LastT"
    )

    # TickChartPlotter.add_markers_to_pq(
    #     pq_node, mi.act.IsValid & mi.act.IsValid & is_aft_trd(mi.act, thres=0.1),
    #     mi.act.P, mi.act.TSO-mi.bk.TTS, "TS_O_TF"
    # )

    pq_node.clockFreq = 60
    pq_node.startTime = "09:31:00"
    pq_node.stopTime = "15:05:00"
    pq_node.univ = f"sids:{SYMBOL}"


    # pq_node.build_exe()
    pq_node.run(single_date=DATE)

    tcp = TickChartPlotter.from_pq_node(pq_node) 
    tcp.load_data(DATE, True)
    # tcp.load_data(DATE, False)
    import hashlib
    port = 8000 + int(hashlib.sha256(str(DATE).encode()).hexdigest(), 16) % 1000
    tcp.run_server(port)
