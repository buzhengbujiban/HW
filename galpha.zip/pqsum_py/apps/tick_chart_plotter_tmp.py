from dash import Dash, dcc, html
import plotly.graph_objects as go
import numpy as np
import pandas as pd
import datetime

# 生成模拟股票数据的函数
def generate_stock_data(date_str="20250226", steps=1440):
    np.random.seed(42)
    base_time = datetime.datetime.strptime(f"{date_str} 09:30:00", "%Y%m%d %H:%M:%S")
    timestamps = [base_time + datetime.timedelta(minutes=i) for i in range(steps)]

    # 价格和成交量模拟
    open_price = 100.0
    prices = [open_price]
    volumes = [np.random.poisson(500)]  # 添加初始成交量
    for _ in range(steps - 1):
        price_change = np.random.normal(0, 0.05) + np.random.choice([0, 0.1, -0.1], p=[0.9, 0.05, 0.05])
        prices.append(prices[-1] + price_change)
        volumes.append(np.random.poisson(1000 if abs(price_change) > 0.05 else 500))

    prices = np.array(prices)
    volumes = np.array(volumes)
    df = pd.DataFrame({
        "timestamp": timestamps,
        "open": prices,
        "high": prices + np.random.uniform(0, 0.1, steps),
        "low": prices - np.random.uniform(0, 0.1, steps),
        "close": prices + np.random.normal(0, 0.05, steps),
        "volume": volumes
    })

    # 计算买卖压力信号
    price_change = df["close"].diff()
    buy_pressure = np.where((price_change > 0) & (df["volume"] > df["volume"].mean()), df["volume"], 0)
    sell_pressure = np.where((price_change < 0) & (df["volume"] > df["volume"].mean()), df["volume"], 0)

    return df, buy_pressure, sell_pressure

# 主类：量价关系和 Alpha 信号分析
class StockAlphaPlotter:
    def __init__(self, date_str="20250226"):
        self.date = date_str
        self.df = None
        self.buy_pressure = None
        self.sell_pressure = None
        self.candlestick = None
        self.volume_heatmap = None
        self.pressure_scatter = []

    def load_data(self):
        self.df, self.buy_pressure, self.sell_pressure = generate_stock_data(self.date)
        self.gen_candlestick()
        self.gen_volume_heatmap()
        self.gen_pressure_scatter()

    def gen_candlestick(self):
        self.candlestick = go.Candlestick(
            x=self.df["timestamp"],
            open=self.df["open"],
            high=self.df["high"],
            low=self.df["low"],
            close=self.df["close"],
            name="Price",
            increasing_line_color="#2ecc71",
            decreasing_line_color="#e74c3c"
        )

    def gen_volume_heatmap(self):
        price_bins = np.linspace(self.df["low"].min(), self.df["high"].max(), 50)
        volume_dist = np.histogram(self.df["close"], bins=price_bins, weights=self.df["volume"])[0]
        self.volume_heatmap = go.Heatmap(
            z=volume_dist[np.newaxis, :],
            x=self.df["timestamp"][::len(self.df) // 50],
            y=price_bins[:-1],
            colorscale="Blues",
            showscale=False,
            opacity=0.5,
            hovertemplate="Price: %{y:.2f}<br>Volume: %{z:,}"
        )

    def gen_pressure_scatter(self):
        buy_mask = self.buy_pressure > 0
        sell_mask = self.sell_pressure > 0
        self.pressure_scatter = [
            go.Scatter(
                x=self.df["timestamp"][buy_mask],
                y=self.df["close"][buy_mask],
                mode="markers",
                name="Buy Pressure",
                marker=dict(color="#27ae60", size=self.buy_pressure[buy_mask] / 500, opacity=0.7),
                hovertemplate="Time: %{x}<br>Price: %{y:.2f}<br>Volume: %{text:,}",
                text=self.buy_pressure[buy_mask]
            ),
            go.Scatter(
                x=self.df["timestamp"][sell_mask],
                y=self.df["close"][sell_mask],
                mode="markers",
                name="Sell Pressure",
                marker=dict(color="#c0392b", size=self.sell_pressure[sell_mask] / 500, opacity=0.7),
                hovertemplate="Time: %{x}<br>Price: %{y:.2f}<br>Volume: %{text:,}",
                text=self.sell_pressure[sell_mask]
            )
        ]

    def run_server(self, port=8050):
        app = Dash(__name__)
        app.layout = html.Div([
            dcc.Graph(
                id='stock_alpha',
                style={'height': '98vh', 'width': '98vw'},
                figure=go.Figure(
                    data=[self.volume_heatmap, self.candlestick, *self.pressure_scatter],
                    layout=dict(
                        title=f"Stock Price and Alpha Signals - {self.date}",
                        xaxis_title="Time",
                        yaxis_title="Price",
                        yaxis2=dict(title="Volume", overlaying="y", side="right", showgrid=False),
                        template="plotly_white"
                    )
                )
            )
        ])
        app.run_server(host="0.0.0.0", debug=False, port=port)

    def figure_in_nb(self):
        return go.Figure(
            layout=dict(
                width=1200,
                height=800,
                title=f"Stock Price and Alpha Signals - {self.date}",
                xaxis_title="Time",
                yaxis_title="Price"
            ),
            data=[self.volume_heatmap, self.candlestick, *self.pressure_scatter]
        )

# 运行示例
if __name__ == "__main__":
    plotter = StockAlphaPlotter(date_str="20250226")
    plotter.load_data()
    plotter.run_server(port=8050)