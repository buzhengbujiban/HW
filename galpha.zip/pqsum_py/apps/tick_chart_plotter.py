from dash import Dash, dcc, html
import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np
import datetime
import os

import panel
import pytbl

from pqsum_py.runner import PQSumNode
import pqsum_py.msg_info as mi

class TickChartPlotter:
    def __init__(self, book_snaps_path=None, bbo_traces_path=None, markers_paths=None):
        self.book_snaps_path = book_snaps_path
        self.bbo_traces_path = bbo_traces_path
        self.markers_paths = markers_paths
        self.date = None
        self.timezone = 8
        self.heatmap_freq = 60

        self.book_snaps = None
        self.bbo_series = None
        self.marker_dfs = None
        self.markers = []

    @staticmethod
    def from_pq_node(pq_node):
        result = TickChartPlotter()
        result.book_snaps_path = f"{pq_node.stage_dir()/'YYYYMMDD.sdiv'}"
        result.bbo_traces_path = f"{pq_node.stage_dir()/'YYYYMMDD.bbo.mtbl'}"
        result.markers_paths = []
        for i in pq_node.node_config:
            # for j in i["pq_filters"]:
            if i["pq_filters"][0]["name"] in ["BBO", "HEATMAP"]:
                continue
            result.markers_paths.append(f"{pq_node.stage_dir()}/YYYYMMDD.markers.{i['pq_stats'][0]['name']}_{i['pq_filters'][0]['name']}.mtbl")
        # print(result.markers_paths)
        return result

    @staticmethod
    def from_pq_dir(pq_node_dir):
        result = TickChartPlotter()
        result.book_snaps_path = f"{pq_node_dir}/YYYYMMDD.sdiv"
        result.bbo_traces_path = f"{pq_node_dir}/YYYYMMDD.bbo.mtbl"
        result.markers_paths = []
        for i in os.listdir(pq_node_dir):
            if i.split(".")[-1] != "mtbl":
                continue
            if len(i.split(".")) < 2 or i.split(".")[1] != "markers":
                continue
            stats_name = i.split(".")[2].split("_")[0]
            filters_name = i.split(".")[2].split("_")[1]
            market_pattern = f"{pq_node_dir}/YYYYMMDD.markers.{stats_name}_{filters_name}.mtbl"
            if market_pattern not in result.markers_paths:
                result.markers_paths.append(market_pattern)
        return result

    @staticmethod
    def base_pq_node(max_levels=30):
        result = PQSumNode([])
        bbo_trace_stats = {
            "pq_filters": [
                {
                    "name": "BBO",
                    "expr": mi.ut.TRUE() | mi.bk.TF,
                },
            ],
            "pq_stats": [
                {
                    "name": "bbo_tbl",
                    "expr": mi.mptbl_write(
                    (f"{result.stage_dir()}/YYYYMMDD.bbo.mtbl"),
                    [mi.ut.TSO, mi.bk.AP(0), mi.bk.BP(0)],
                    [("TS"), ("AP0"), ("BP0")], 
                    ),
                },
            ]
        }

        bk_lvls = []
        for i in range(max_levels):
            bk_lvls += [
                {
                "snap": True,
                "name": f"AP{i}",
                "expr": mi.bk.AP(i),
                },
                {
                "snap": True,
                "name": f"BP{i}",
                "expr": mi.bk.BP(i),
                },

                {
                "snap": True,
                "name": f"AQ{i}",
                "expr": mi.bk.AQ(i),
                },
                {
                "snap": True,
                "name": f"BQ{i}",
                "expr": mi.bk.BQ(i),
                },
            ]
        book_heatmap_lvls = {
            "pq_filters": [
                {
                    "name": "HEATMAP",
                    "expr": mi.ut.TRUE(),
                },
            ],
            "pq_stats":bk_lvls
        }
        result.node_config = [
            bbo_trace_stats,
            book_heatmap_lvls
        ]
        return result

    @staticmethod
    def add_markers_to_pq(pq_node,  msg_filter, p, q, filter_name, pq_name="PQ"):
        pq_node.node_config.append(
            {
                "pq_filters": [
                    {
                        "name": filter_name,
                        "expr": msg_filter,
                    },
                ],
                "pq_stats": [
                    {
                        "name": pq_name,
                        "expr": mi.mptbl_write(
                        (f"{pq_node.stage_dir()}/YYYYMMDD.markers.{pq_name}_{filter_name}.mtbl"),
                        [mi.ut.TSO, p, q],
                        [("TS"), ("P"), ("Q")], 
                        ),
                    }
                ]
            }
        )


    def load_data(self, date, regen_heatmap=True):
        self.date = date
        if self.book_snaps is None:
            df = panel.read(self.book_snaps_path.replace("YYYYMMDD", str(self.date)))[0,0,:,:].to_pandas()
            self.book_snaps = df.reset_index(drop=False)
        if self.bbo_series is None:
            self.bbo_series = pytbl.mptbl_read(self.bbo_traces_path.replace("YYYYMMDD", str(self.date)))
        if self.marker_dfs is None:
            self.marker_dfs = [pytbl.mptbl_read(i.replace("YYYYMMDD", str(self.date))) for i in self.markers_paths]

        self.gen_heatmap_df(regen_heatmap)
        self.gen_bbo_series()
        self.gen_plotly_objects()
        # self.B_trd_df = self.trans[self.trans["side"]=="B"][["timestamp", "price", "qty"]]
        # self.B_trd_df = self.B_trd_df[self.B_trd_df["qty"]>=1000]
        # self.S_trd_df = self.trans[self.trans["side"]=="S"][["timestamp", "price", "qty"]]
        # self.S_trd_df = self.S_trd_df[self.S_trd_df["qty"]>=1000]
        # if self.trans is None:
        #     self.trans = read_trans_file(sameple_trans_file)
    
    def gen_heatmap_df(self, regen=True):
        # self.load_data()
        if not regen:
            self.heatmap_df = pd.read_csv(f"/tmp/{os.environ['USER']}/{self.date}.heatmap.csv")
            return
        print("generating heatmap ...")
        all_p_cols = [i for i in self.book_snaps.columns if len(i.split("."))==3 and i.split(".")[0] == "HEATMAP" and i.split(".")[1][:2] in ["BP", "AP"]]
        all_q_cols = [i for i in self.book_snaps.columns if len(i.split("."))==3 and i.split(".")[0] == "HEATMAP" and i.split(".")[1][:2] in ["BQ", "AQ"]]
        # print(self.book_snaps)
        # print(self.book_snaps[["I"]+all_p_cols+all_q_cols])
        all_pxs = self.book_snaps[all_p_cols]
        all_pxs = np.unique(all_pxs.values)
        all_pxs = all_pxs[~np.isnan(all_pxs)]
        all_pxs = all_pxs[all_pxs!=0]
        all_pxs_iloc = dict(zip(all_pxs, range(len(all_pxs))))
        result_df = self.book_snaps[["I"]].copy()
        result_df = result_df.reindex(columns=["I"]+list(all_pxs))
        for i in range(len(self.book_snaps["I"])):
            for df_ipi,df_ip in enumerate(self.book_snaps.iloc[i, :][all_p_cols]):
                if not np.isnan(df_ip) and not df_ip==0:
                    result_df.iloc[i, all_pxs_iloc[df_ip]+1] = self.book_snaps.iloc[i, :][all_q_cols].iloc[df_ipi]
        result_df = result_df[~result_df["I"].isna()]
        # for i in result_df["I"]:
        #     print(i)
        # ss = self.heatmap_freq//2+
        result_df["I"] = [
            datetime.datetime(
                int(str(self.date)[:4]), 
                int(str(self.date)[4:6]),
                int(str(self.date)[6:]),
                int(str(i)[:2]),
                int(str(i)[3:5]) if int(str(i)[6:8]) < 60 else int(str(i)[3:5])+1,
                (int(str(i)[6:8])+self.heatmap_freq//2)%60,
            ) for i in result_df["I"]
        ]
        # return result_df
        self.heatmap_df = result_df
        self.heatmap_df.to_csv(f"/tmp/{os.environ['USER']}/{self.date}.heatmap.csv", index=False)
        print("generating heatmap finished.")

    def epoch_to_datetime(self, epoch):
        YY = int(str(self.date)[:4])
        MM = int(str(self.date)[4:6])
        DD = int(str(self.date)[6:])
        HH = int(epoch % 86400 // 3600)+self.timezone
        mm = int(epoch % 3600 // 60)
        ss = int(epoch % 60)
        ms = int(epoch % 1 * 1000000)
        return datetime.datetime(YY,MM,DD,HH,mm,ss,ms)

    def gen_bbo_series(self):
        # TODO: slow
        def fill_new_ts(series):
            return sum(zip(series, series[1:]+[0]), ())[:-1]
        def fill_old_v(series):
            return sum(zip(series, series[:-1]+[0]), ())[:-1]

        # self.load_data()
        bbo_series_valid = self.bbo_series[(self.bbo_series.BP0<self.bbo_series.AP0)]
        timestamps = list(bbo_series_valid["TS"].copy())
        bid0ps     = list(bbo_series_valid["BP0"].copy())
        ask0ps     = list(bbo_series_valid["AP0"].copy())

        self.bbo_ts_series = fill_new_ts(timestamps)
        self.bbo_ts_series = [self.epoch_to_datetime(i) for i in self.bbo_ts_series]
        self.bid0p_series = fill_old_v(bid0ps)
        self.ask0p_series = fill_old_v(ask0ps)

    def gen_plotly_objects(self):
        self.bid0p_scatter = go.Scatter(x=self.bbo_ts_series, y=self.bid0p_series, name="BP0", line=dict(width=1))
        self.ask0p_scatter = go.Scatter(x=self.bbo_ts_series, y=self.ask0p_series, name="AP0", line=dict(width=1))

        heatmap_v = self.heatmap_df[self.heatmap_df.columns[1:]].values.T
        heatmap_v_q90_r = np.nanquantile(heatmap_v, 0.9)/np.nanmax(heatmap_v)
        self.heatmap = go.Heatmap(
            z=heatmap_v,
            # z=heatmap_v.ravel().argsort().argsort().reshape(heatmap_v.shape),
            x=self.heatmap_df["I"],
            y=self.heatmap_df.columns[1:],
            text=heatmap_v,
            hovertemplate = "t: %{x} <br>" + "p: %{y} <br>" + "q: %{text:,}",
            hoverongaps=False,
            showscale=False,
            colorscale=[[0, 'rgb(230,230,230)'], [heatmap_v_q90_r, 'rgb(50,50,50)'], [1, 'rgb(0,0,0)']]
        )

        if len(self.marker_dfs) > 0:
            trd_q90_v = np.nanquantile(pd.concat([i["Q"] for i in self.marker_dfs]).values, 0.9)
            trd_max_v = np.nanmax(pd.concat([i["Q"] for i in self.marker_dfs]).values)

            for i,p in enumerate(self.markers_paths):
                # print(p)
                # print(p.split("/")[-1])
                marker_name = p.split("/")[-1].split(".")[2]
                markers = self.marker_dfs[i]
                self.markers += [
                    go.Scatter(
                        x=[self.epoch_to_datetime(i) for i in markers["TS"]], y=markers["P"], 
                        hovertemplate="%{x|%H:%M:%S.%L}<br>%{hovertext}@%{y}",
                        mode="markers", name=marker_name, hovertext=markers["Q"], marker=dict(
                            size=2+np.clip(markers["Q"]/trd_q90_v*6, 0, 15)
                        )
                    )
                ]

    def run_server(self, port=8049):
        app = Dash(__name__)
        app.layout = html.Div([
            dcc.Graph(
                id='tick_chart',
                style={
                    'height': '98vh',
                    'width': '98vw',
                },
                figure=go.Figure(
                    data=[
                        self.heatmap,
                        self.bid0p_scatter,
                        self.ask0p_scatter,
                        *self.markers,
                    ],
                ),
            )
        ])
        app.run_server(host="0.0.0.0", debug=False, port=port)

    def figure_in_nb(self):
        return go.Figure(
            layout=dict(
                width=2000,
                height=1000,
            ),
            data=[
                self.heatmap,
                self.bid0p_scatter,
                self.ask0p_scatter,
                *self.markers,
            ],
        )