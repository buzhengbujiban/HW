import qr_utils
import copy

class PQBase(qr_utils.Map):
    def __deepcopy__(self, memo):
        return PQBase(copy.deepcopy(dict(self), memo))
        

class PQNode(PQBase):
    def __init__(self, pq_filters=[], pq_stats=[]):
        self.pq_filters = pq_filters
        self.pq_stats = pq_stats


class PQFilter(PQBase):
    def __init__(self, name, expr=""):
        self.name = name
        self.expr = expr


class PQTerm(PQBase):
    def __init__(self, name, expr="", pows=[1], snap=False, dump=True):
        self.name = name
        self.expr = expr
        self.pows = pows
        self.snap = snap
        self.dump = dump
