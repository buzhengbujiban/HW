import copy
import pandas as pd

from pattern_helper import *


class PQLabel:
    def __init__(self, ss=None, s=None, ft=None, pq=None, p=None):
        self.ss = str(ss)
        self.s = str(s)
        self.ft = str(ft)
        self.pq = str(pq)
        self.p = str(p)

    @staticmethod
    def from_label(label):
        result =  PQLabel()
        assert len(label.split(".")) == 5, f"Invalid label: {label}"
        result.ss = label.split(".")[0]
        result.s = label.split(".")[1]
        result.ft = label.split(".")[2]
        result.pq = label.split(".")[3]
        result.p = label.split(".")[4]
        return result

    def __str__(self):
        return f"{self.ss}.{self.s}.{self.ft}.{self.pq}.{self.p}"

    def to_str(self):
        return str(self)
    
    def to_short_str(self):
        return f"{self.ss}.{self.ft}.{self.pq}"

    def new_ss_label(self, ss):
        result = copy.deepcopy(self)
        result.ss = ss
        return result
    
    def new_s_label(self, s):
        result = copy.deepcopy(self)
        result.s = s
        return result
    
    def new_ft_label(self, ft):
        result = copy.deepcopy(self)
        result.ft = ft
        return result

    def new_pq_label(self, pq):
        result = copy.deepcopy(self)
        result.pq = pq
        return result
    
    def new_p_label(self, p):
        result = copy.deepcopy(self)
        result.p = p
        return result

class BKLabel:
    def __init__(self, bk=None, s=None, v=None, op=None, lv=None):
        self.bk = str(bk)
        self.s = str(s)
        self.v = str(v)
        self.op = str(op)
        self.lv = str(lv)

    @staticmethod
    def from_label(label):
        result =  PQLabel()
        assert len(label.split(".")) == 5, f"Invalid label: {label}"
        result.bk = label.split(".")[0]
        result.s = label.split(".")[1]
        result.v = label.split(".")[2]
        result.op = label.split(".")[3]
        result.lv = label.split(".")[4]
        return result

    def __str__(self):
        return f"{self.bk}.{self.s}.{self.v}.{self.op}.{self.lv}"

    def to_str(self):
        return str(self)
    
    def to_short_str(self):
        return f"{self.bk}.{self.v}.{self.op}"

    def new_bk_label(self, bk):
        result = copy.deepcopy(self)
        result.bk = bk
        return result
    
    def new_s_label(self, s):
        result = copy.deepcopy(self)
        result.s = s
        return result
    
    def new_v_label(self, v):
        result = copy.deepcopy(self)
        result.v = v
        return result

    def new_op_label(self, op):
        result = copy.deepcopy(self)
        result.op = op
        return result
    
    def new_lv_label(self, lv):
        result = copy.deepcopy(self)
        result.lv = lv
        return result


@lru_cache(maxsize=32)
def gen_pq_stats_labels_df(stats_pattern):
    pq_stats_labels = read_columns_from_pattern(stats_pattern) 
    pq_stats_list = [
        [
            i,
            i.split(".")[0], 
            i.split(".")[1],
            i.split(".")[2],
            i.split(".")[3],
            i.split(".")[4]
        ]
        for i in pq_stats_labels
    ]
    return pd.DataFrame(pq_stats_list, columns=["label", "ss", "s", "ft", "pq", "p"])

@lru_cache(maxsize=32)
def get_labels_by_pow(pattern, p):
    assert isinstance(p, str) and p[0] == "p"
    result = []
    label_df = gen_pq_stats_labels_df(pattern)
    for _, row in label_df.iterrows():
        if row["p"] == p:
            result.append(row["label"])
    return result

 

def gen_pqsum_config(filters={}, p1={}, p2={}, p3={}):
    return {
        "pq_filters": [{
            "name": k,
            "expr": v,
        } for k, v in filters.items()],
        "pq_stats": [{
            "name": k,
            "expr": v,
            "pows": [1],
        } for k, v in p1.items()] + [{
            "name": k,
            "expr": v,
            "pows": [1, 2],
        } for k, v in p2.items()] + [{
            "name": k,
            "expr": v,
            "pows": [1, 2, 3],
        } for k, v in p3.items()],
    }

def pqsum_names_from_config(pqsum_config):
    result = []
    filter_names = [f["name"] for f in pqsum_config["pq_filters"]]
    stat_names = []
    for s in pqsum_config["pq_stats"]:
        for p in s["pows"]:
            stat_names.append(s["name"]+".p"+str(p))
    for filter_name in filter_names:
        for stat_name in stat_names:
            result.append(filter_name+"."+stat_name)
    return result


def gen_pqsum_config_snap(filters={}, p1={}):
    return {
        "pq_filters": [{
            "name": k,
            "expr": v,
        } for k, v in filters.items()],
        "pq_stats": [{
            "name": k,
            "expr": v,
            "pows": [1],
            "snap": True,
        } for k, v in p1.items()],
    }
