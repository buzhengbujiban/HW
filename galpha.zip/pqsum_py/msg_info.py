


import copy

class Base(object):
    def __init__(self, v, key = None):
        self.v = str(v)
        if key is not None:
            if isinstance(key, set):
                self.key = key
            else:
                self.key = set()
                self.key.add(key)
 
    def __deepcopy__(self, memo):
        return Base(self.v, copy.deepcopy(self.key, memo))
    
    def __repr__(self) -> str:
        return self.v
 
    def __add__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} + {other.v})", self.key)
 
    def __sub__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} - {other.v})", self.key)
 
    def __mul__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} * {other.v})", self.key)
 
    def __truediv__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} / {other.v})", self.key)
 
    def __floordiv__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"(math.Floor({self.v} / {other.v}))", self.key)

    def __mod__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} % {other.v})", self.key)

    def __pow__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} ^ {other.v})", self.key)

    def __and__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} && {other.v})", self.key)

    def __or__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} || {other.v})", self.key)

    def __xor__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} ^ {other.v})", self.key)

    def __lt__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} < {other.v})", self.key)

    def __le__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} <= {other.v})", self.key)

    def __eq__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} == {other.v})", self.key)

    def __ne__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} != {other.v})", self.key)

    def __gt__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} > {other.v})", self.key)

    def __ge__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} >= {other.v})", self.key)

    def __neg__(self):
        # if isinstance(other, Base):
        #     self.key = self.key.union(other.key)
        # else:
        #     other = Base(other)
        return Base(f"(-{self.v})", self.key)

    def __pos__(self):
        # if isinstance(other, Base):
        #     self.key = self.key.union(other.key)
        # else:
        #     other = Base(other)
        return Base(f"(+{self.v})", self.key)

    def __abs__(self):
        # if isinstance(other, Base):
        #     self.key = self.key.union(other.key)
        # else:
        #     other = Base(other)
        return Base(f"(math.Abs({self.v}))", self.key)

    def __invert__(self):
        # if isinstance(other, Base):
        #     self.key = self.key.union(other.key)
        # else:
        #     other = Base(other)
        return Base(f"(!{self.v})", self.key)

    def __lshift__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} << {other.v})", self.key)

    def __rshift__(self, other):
        if isinstance(other, Base):
            self.key = self.key.union(other.key)
        else:
            other = Base(other)
        return Base(f"({self.v} >> {other.v})", self.key)

    def __getitem__(self, key):
        if isinstance(key, str):
            key = '"'+key+'"'
        return Base(f"{self.v}[{key}]", self.key)

    def __call__(self, *args, **kwargs):
        def convert_format(arg):
            if isinstance(arg, str):
                arg = '"'+arg+'"'
            if isinstance(arg, bool):
                return "true" if arg else "false"
            # if isinstance(arg, list):
            #     assert len(arg) > 0
            #     if isinstance(arg[0], str):
            #         return "[]string{"+",".join([convert_format(i) for i in arg])+"}"
            #     else:
            #         return "[]float64{"+",".join([convert_format(i) for i in arg])+"}"
            # if isinstance(arg, list):
            #     return ";".join([convert_format(i) for i in arg])
            return str(arg)
            # TODO: special formats
            # else:
            #     return str(arg)
        args_list   = ",".join([str(convert_format(i)) for i in args])
        # print(kwargs)
        kwargs_list = ",".join([f"{k}={convert_format(v)}" for k,v in kwargs.items()])
        for arg in args:
            if isinstance(arg, Base):
                self.key = self.key.union(arg.key)
            elif isinstance(arg,list):
                for i in arg:
                    if isinstance(i, Base):
                        self.key = self.key.union(i.key)
        for _,w in kwargs.items():
            if isinstance(w, Base):
                self.key = self.key.union(w.key)
            elif isinstance(arg,list):
                for i in arg:
                    if isinstance(i, Base):
                        self.key = self.key.union(i.key)
        if kwargs_list != "":
            kwargs_list = "," + kwargs_list
        return Base(f"{self.v}({args_list}{kwargs_list})", self.key)

    def __getattr__(self, name):
        return Base(f"{self.v}.{name}", self.key)




def sdiv(sdiv_path, vname, inclusive = False, allow_missing_S = True, allow_missing_V = False):
    return Base(f'sdiv("{sdiv_path}", "{vname}", "{inclusive}", "{allow_missing_S}", "{allow_missing_V}")', "ut")

def mptbl_write(output_path, exprs, names):
    expr_str = ""
    name_str = ""
    assert len(exprs) == len(names)
    for i in range(len(exprs)):
        expr_str += f';{exprs[i]}'
        name_str += f';{names[i]}'
    
    expr_str = expr_str[1:]
    name_str = name_str[1:]
    return Base(f'OpMpTblWrt("{output_path}", "{expr_str}", "{name_str}")', "ut")



class ut:

    LastMsgType = Base("ut.LastMsgType()", "ut")

    TSS = Base("ut.TSS", "ut")
    """
    src
    """


    TSO = Base("ut.TSO", "ut")
    """
    our
    """


    Reset = Base("ut.Reset", "ut")

    C = Base("ut.C", "ut")

    Sid = Base("ut.Sid", "ut")

    Pow = Base("ut.Pow", "ut")

    Log = Base("ut.Log", "ut")

    Sqrt = Base("ut.Sqrt", "ut")

    Floor = Base("ut.Floor", "ut")

    Ceil = Base("ut.Ceil", "ut")

    Round = Base("ut.Round", "ut")

    Mod = Base("ut.Mod", "ut")

    IntDiv = Base("ut.IntDiv", "ut")

    DirSign = Base("ut.DirSign", "ut")

    PEQ = Base("ut.PEQ", "ut")

    IsE10 = Base("ut.IsE10", "ut")

    S = Base("ut.S", "ut")

    TRUE = Base("ut.TRUE", "ut")

    FALSE = Base("ut.FALSE", "ut")



class cxl:

    LastMsgType = Base("cxl.LastMsgType()", "cxl")

    P = Base("cxl.P", "cxl")
    """
    price
    """


    Q = Base("cxl.Q", "cxl")
    """
    qty
    """


    TSS = Base("cxl.TSS", "cxl")
    """
    src
    """


    TSO = Base("cxl.TSO", "cxl")
    """
    our
    """


    D = Base("cxl.D", "cxl")
    """
    distance to bbo
    """


    D2 = Base("cxl.D2", "cxl")
    """
    distance to opposite bbo
    """


    T = Base("cxl.T", "cxl")
    """
    lifetime
    """


    L = Base("cxl.L", "cxl")
    """
    level
    """


    ID = Base("cxl.ID", "cxl")


    NB = Base("cxl.NB", "cxl")
    """
    order num before the canceled order
    """


    NA = Base("cxl.NA", "cxl")
    """
    order num after  the canceled order
    """


    QB = Base("cxl.QB", "cxl")
    """
    shares before the canceled order
    """


    QA = Base("cxl.QA", "cxl")
    """
    shares after  the canceled order
    """


    TTQ = Base("cxl.TTQ", "cxl")
    """
    total qty before the canceled order until bbo
    """


    TTN = Base("cxl.TTN", "cxl")
    """
    total num before the canceled order until bbo
    """


    ORIG = Base("cxl.ORIG", "cxl")


    IsSoleOrder = Base("cxl.IsSoleOrder", "cxl")


    IsB = Base("cxl.IsB", "cxl")


    IsS = Base("cxl.IsS", "cxl")


    IsValid = Base("cxl.IsValid", "cxl")


    Reset = Base("cxl.Reset", "cxl")

    Orig = Base("cxl.Orig", "cxl")

    Orig_P = Base("cxl.Orig_P", "cxl")

    Orig_Q = Base("cxl.Orig_Q", "cxl")

    Orig_TSS = Base("cxl.Orig_TSS", "cxl")

    Orig_TSO = Base("cxl.Orig_TSO", "cxl")

    Orig_D = Base("cxl.Orig_D", "cxl")

    Orig_D2 = Base("cxl.Orig_D2", "cxl")

    Orig_L = Base("cxl.Orig_L", "cxl")

    Orig_QB = Base("cxl.Orig_QB", "cxl")

    Orig_NB = Base("cxl.Orig_NB", "cxl")

    Orig_TTQB = Base("cxl.Orig_TTQB", "cxl")

    Orig_TTNB = Base("cxl.Orig_TTNB", "cxl")

    OnOBCancelPre = Base("cxl.OnOBCancelPre", "cxl")



class bk3:

    LastMsgType = Base("bk3.LastMsgType()", "bk3")

    MAX_LEVEL = Base("bk3.MAX_LEVEL", "bk3")


    LEVEL_WIDTH = Base("bk3.LEVEL_WIDTH", "bk3")


    B = Base("bk3.B", "bk3")


    A = Base("bk3.A", "bk3")


    LvStats = Base("bk3.LvStats", "bk3")


    InTrading = Base("bk3.InTrading", "bk3")


    IsValid = Base("bk3.IsValid", "bk3")


    BVal = Base("bk3.BVal", "bk3")

    AVal = Base("bk3.AVal", "bk3")

    Reset = Base("bk3.Reset", "bk3")

    ResetOnTimer = Base("bk3.ResetOnTimer", "bk3")



class add:

    LastMsgType = Base("add.LastMsgType()", "add")

    P = Base("add.P", "add")
    """
    price
    """


    Q = Base("add.Q", "add")
    """
    qty
    """


    TSS = Base("add.TSS", "add")
    """
    src
    """


    TSO = Base("add.TSO", "add")
    """
    our
    """


    D = Base("add.D", "add")
    """
    distance to bbo
    """


    D2 = Base("add.D2", "add")
    """
    distance to opposite bbo
    """


    L = Base("add.L", "add")
    """
    level
    """


    ID = Base("add.ID", "add")
    """
    order id
    """


    QB = Base("add.QB", "add")
    """
    shares on the level
    """


    NB = Base("add.NB", "add")
    """
    num of order on the level
    """


    TTQB = Base("add.TTQB", "add")
    """
    multi level total qty before
    """


    TTNB = Base("add.TTNB", "add")
    """
    multi level total num before
    """


    IsB = Base("add.IsB", "add")


    IsS = Base("add.IsS", "add")


    IsValid = Base("add.IsValid", "add")


    IsAuctionValid = Base("add.IsAuctionValid", "add")


    IsSHRemainder = Base("add.IsSHRemainder", "add")


    IsSZRemainder = Base("add.IsSZRemainder", "add")


    LastTrdIdA = Base("add.LastTrdIdA", "add")


    LastTrdIdB = Base("add.LastTrdIdB", "add")


    LastTrdIsB = Base("add.LastTrdIsB", "add")


    AskOrders = Base("add.AskOrders", "add")


    BidOrders = Base("add.BidOrders", "add")


    AskIdToDelete = Base("add.AskIdToDelete", "add")
    """
    Id to delete in order status, late delete is for other dependencies to reference in this round
    """


    BidIdToDelete = Base("add.BidIdToDelete", "add")


    OrderStatusPool = Base("add.OrderStatusPool", "add")


    Reset = Base("add.Reset", "add")

    SaveOrderStatus = Base("add.SaveOrderStatus", "add")

    GetOrderStatus = Base("add.GetOrderStatus", "add")

    SetSelfToOrderStatus = Base("add.SetSelfToOrderStatus", "add")

    OnOBAddPre = Base("add.OnOBAddPre", "add")



class ppq:
    """
    passive trade 相关统计信息
    """

    LastMsgType = Base("ppq.LastMsgType()", "ppq")

    P = Base("ppq.P", "ppq")
    """
    price
    """


    Q = Base("ppq.Q", "ppq")
    """
    qty
    """


    TSS = Base("ppq.TSS", "ppq")
    """
    timestamp
    """


    TSO = Base("ppq.TSO", "ppq")
    """
    timestamp
    """


    IsB = Base("ppq.IsB", "ppq")


    IsS = Base("ppq.IsS", "ppq")


    IsValid = Base("ppq.IsValid", "ppq")


    IsAdd = Base("ppq.IsAdd", "ppq")


    IsCxl = Base("ppq.IsCxl", "ppq")


    IsTrd = Base("ppq.IsTrd", "ppq")


    Reset = Base("ppq.Reset", "ppq")



class pq:

    LastMsgType = Base("pq.LastMsgType()", "pq")

    P = Base("pq.P", "pq")
    """
    price
    """


    Q = Base("pq.Q", "pq")
    """
    qty
    """


    D = Base("pq.D", "pq")
    """
    distance to bbo
    """


    D2 = Base("pq.D2", "pq")
    """
    distance to opposite bbo
    """


    T = Base("pq.T", "pq")
    """
    lifetime
    """


    L = Base("pq.L", "pq")
    """
    level
    """


    IsB = Base("pq.IsB", "pq")


    IsS = Base("pq.IsS", "pq")


    IsAdd = Base("pq.IsAdd", "pq")


    IsCxl = Base("pq.IsCxl", "pq")


    IsPas = Base("pq.IsPas", "pq")


    IsAct = Base("pq.IsAct", "pq")


    LastBP0 = Base("pq.LastBP0", "pq")


    LastBQ0 = Base("pq.LastBQ0", "pq")


    LastAP0 = Base("pq.LastAP0", "pq")


    LastAQ0 = Base("pq.LastAQ0", "pq")


    LastTrdTs = Base("pq.LastTrdTs", "pq")


    LastTrdPx = Base("pq.LastTrdPx", "pq")


    LastTrdIsB = Base("pq.LastTrdIsB", "pq")


    OB = Base("pq.OB", "pq")

    SaveLastBBO = Base("pq.SaveLastBBO", "pq")

    Reset = Base("pq.Reset", "pq")



class tproxy:

    LastMsgType = Base("tproxy.LastMsgType()", "tproxy")

    AC = Base("tproxy.AC", "tproxy")
    """
    addCount
    """


    TC = Base("tproxy.TC", "tproxy")
    """
    tradeCount
    """


    TN = Base("tproxy.TN", "tproxy")
    """
    tradeNotl
    """


    SSO = Base("tproxy.SSO", "tproxy")

    BboC = Base("tproxy.BboC", "tproxy")
    """
    the number of times bid1 or ask1 changes
    """


    BboC1 = Base("tproxy.BboC1", "tproxy")
    """
    the number of times bid1>= last ask1 or vice versa
    """


    BboC2 = Base("tproxy.BboC2", "tproxy")
    """
    the number of times both bid1/ask1 changes
    """


    BboC3 = Base("tproxy.BboC3", "tproxy")
    """
    the number of times bid1> last ask1 or vice versa)
    """




class psq:

    LastMsgType = Base("psq.LastMsgType()", "psq")

    Reset = Base("psq.Reset", "psq")

    Q = Base("psq.Q", "psq")



class tf:

    LastMsgType = Base("tf.LastMsgType()", "tf")

    TFS = Base("tf.TFS", "tf")


    Reset = Base("tf.Reset", "tf")



class act:

    LastMsgType = Base("act.LastMsgType()", "act")

    P = Base("act.P", "act")
    """
    price
    """


    Q = Base("act.Q", "act")
    """
    qty
    """


    TSS = Base("act.TSS", "act")
    """
    src
    """


    LastT = Base("act.LastT", "act")
    """
    our
    """

    TSO = Base("act.TSO", "act")
    """
    our
    """


    D = Base("act.D", "act")
    """
    distance to bbo
    """


    D2 = Base("act.D2", "act")
    """
    distance to opposite bbo
    """


    ID = Base("act.ID", "act")


    N = Base("act.N", "act")
    """
    number of passive trade triggered
    """


    LV = Base("act.LV", "act")
    """
    sweep level
    """


    CL = Base("act.CL", "act")
    """
    is clean sweep
    """


    SP = Base("act.SP", "act")
    """
    spread when trade happen
    """


    LQ = Base("act.LQ", "act")
    """
    opposite side liquidity
    """


    IsB = Base("act.IsB", "act")


    IsS = Base("act.IsS", "act")


    IsValid = Base("act.IsValid", "act")


    LastTrdIdA = Base("act.LastTrdIdA", "act")


    LastTrdIdB = Base("act.LastTrdIdB", "act")


    LastTrdIsB = Base("act.LastTrdIsB", "act")


    LastTrdPrc = Base("act.LastTrdPrc", "act")


    Reset = Base("act.Reset", "act")



class bk:

    LastMsgType = Base("bk.LastMsgType()", "bk")

    SP = Base("bk.SP", "bk")
    """
    spread
    """


    MP = Base("bk.MP", "bk")
    """
    mid price
    """


    TCH = Base("bk.TCH", "bk")
    """
    touch
    """


    TF = Base("bk.TF", "bk")


    TSS = Base("bk.TSS", "bk")
    """
    srcEpoch
    """


    TSO = Base("bk.TSO", "bk")
    """
    ourEpoch
    """


    TTS = Base("bk.TTS", "bk")
    """
    trade ts
    """


    TFTS = Base("bk.TFTS", "bk")
    """
    tick flip ts
    """


    TMIN = Base("bk.TMIN", "bk")
    """
    minute
    """


    TSEC = Base("bk.TSEC", "bk")
    """
    second
    """


    TDEC = Base("bk.TDEC", "bk")
    """
    decimal part of sec
    """


    BP0 = Base("bk.BP0", "bk")


    AP0 = Base("bk.AP0", "bk")


    BQ0 = Base("bk.BQ0", "bk")


    AQ0 = Base("bk.AQ0", "bk")


    BQTotalSnap = Base("bk.BQTotalSnap", "bk")


    AQTotalSnap = Base("bk.AQTotalSnap", "bk")


    BNTotalSnap = Base("bk.BNTotalSnap", "bk")


    ANTotalSnap = Base("bk.ANTotalSnap", "bk")


    BPQTotalSnap = Base("bk.BPQTotalSnap", "bk")


    APQTotalSnap = Base("bk.APQTotalSnap", "bk")


    InTrading = Base("bk.InTrading", "bk")


    ThisBP0 = Base("bk.ThisBP0", "bk")


    ThisBQ0 = Base("bk.ThisBQ0", "bk")


    ThisAP0 = Base("bk.ThisAP0", "bk")


    ThisAQ0 = Base("bk.ThisAQ0", "bk")


    LastBP0 = Base("bk.LastBP0", "bk")


    LastBQ0 = Base("bk.LastBQ0", "bk")


    LastAP0 = Base("bk.LastAP0", "bk")


    LastAQ0 = Base("bk.LastAQ0", "bk")


    IsCross = Base("bk.IsCross", "bk")


    Valid = Base("bk.Valid", "bk")


    APQCOUNT = Base("bk.APQCOUNT", "bk")


    OB = Base("bk.OB", "bk")

    SaveLastBBO = Base("bk.SaveLastBBO", "bk")

    Reset = Base("bk.Reset", "bk")

    Lvl = Base("bk.Lvl", "bk")

    BLTotal = Base("bk.BLTotal", "bk")

    ALTotal = Base("bk.ALTotal", "bk")

    BQTotal = Base("bk.BQTotal", "bk")

    AQTotal = Base("bk.AQTotal", "bk")

    BNTotal = Base("bk.BNTotal", "bk")

    ANTotal = Base("bk.ANTotal", "bk")

    BPQTotal = Base("bk.BPQTotal", "bk")

    APQTotal = Base("bk.APQTotal", "bk")

    BP = Base("bk.BP", "bk")

    BQ = Base("bk.BQ", "bk")

    BN = Base("bk.BN", "bk")

    AP = Base("bk.AP", "bk")

    AQ = Base("bk.AQ", "bk")

    AN = Base("bk.AN", "bk")

    PrettyString = Base("bk.PrettyString", "bk")
    """
    TODO: any level
    """




class auc:
    """
    passive trade 相关统计信息
    """

    LastMsgType = Base("auc.LastMsgType()", "auc")

    P = Base("auc.P", "auc")
    """
    price
    """


    Q = Base("auc.Q", "auc")
    """
    qty
    """


    TSS = Base("auc.TSS", "auc")
    """
    timestamp
    """


    TSO = Base("auc.TSO", "auc")
    """
    timestamp
    """


    InTrading = Base("auc.InTrading", "auc")


    IsB = Base("auc.IsB", "auc")


    IsS = Base("auc.IsS", "auc")


    IsValid = Base("auc.IsValid", "auc")


    IsAM1 = Base("auc.IsAM1", "auc")


    IsAM2 = Base("auc.IsAM2", "auc")


    IsPM = Base("auc.IsPM", "auc")


    IepAM1 = Base("auc.IepAM1", "auc")


    IepAM2 = Base("auc.IepAM2", "auc")


    IepPM = Base("auc.IepPM", "auc")


    MatchQtyAM1 = Base("auc.MatchQtyAM1", "auc")


    MatchQtyAM2 = Base("auc.MatchQtyAM2", "auc")


    MatchQtyPM = Base("auc.MatchQtyPM", "auc")


    IepMaxAM1 = Base("auc.IepMaxAM1", "auc")


    IepMinAM1 = Base("auc.IepMinAM1", "auc")


    IepMaxAM2 = Base("auc.IepMaxAM2", "auc")


    IepMinAM2 = Base("auc.IepMinAM2", "auc")


    IepMaxPM = Base("auc.IepMaxPM", "auc")


    IepMinPM = Base("auc.IepMinPM", "auc")


    IsAdd = Base("auc.IsAdd", "auc")


    IsCxl = Base("auc.IsCxl", "auc")


    IsTrd = Base("auc.IsTrd", "auc")


    TrdOrigBP = Base("auc.TrdOrigBP", "auc")


    TrdOrigAP = Base("auc.TrdOrigAP", "auc")


    AdjPClose = Base("auc.AdjPClose", "auc")


    CNEQOB = Base("auc.CNEQOB", "auc")

    Reset = Base("auc.Reset", "auc")

    OnOBTradePre = Base("auc.OnOBTradePre", "auc")

    CalcIEPQ = Base("auc.CalcIEPQ", "auc")



class bk2:

    LastMsgType = Base("bk2.LastMsgType()", "bk2")

    MAX_LEVEL = Base("bk2.MAX_LEVEL", "bk2")


    B = Base("bk2.B", "bk2")


    A = Base("bk2.A", "bk2")


    LvStats = Base("bk2.LvStats", "bk2")


    InTrading = Base("bk2.InTrading", "bk2")


    IsValid = Base("bk2.IsValid", "bk2")


    BVal = Base("bk2.BVal", "bk2")

    AVal = Base("bk2.AVal", "bk2")

    SideSumImba = Base("bk2.SideSumImba", "bk2")

    Reset = Base("bk2.Reset", "bk2")

    ResetOnTimer = Base("bk2.ResetOnTimer", "bk2")



class pas:
    """
    passive trade 相关统计信息
    """

    LastMsgType = Base("pas.LastMsgType()", "pas")

    OrdType = Base("pas.OrdType", "pas")
    """
    PassiveOrderType: -1: unknonw, 0: from passive order, 1: from active order
    """


    SoPrc = Base("pas.SoPrc", "pas")
    """
    passive order 的最初发单价格
    """


    SoQty = Base("pas.SoQty", "pas")
    """
    passive order 的最初发单数量
    """


    ExPrc = Base("pas.ExPrc", "pas")
    """
    当前passive trade的成交价格
    """


    ExQty = Base("pas.ExQty", "pas")
    """
    当前passive trade的成交数量
    """


    P = Base("pas.P", "pas")
    """
    price
    """


    Q = Base("pas.Q", "pas")
    """
    qty
    """


    TSS = Base("pas.TSS", "pas")
    """
    src
    """


    TSO = Base("pas.TSO", "pas")
    """
    our
    """


    T = Base("pas.T", "pas")


    PL = Base("pas.PL", "pas")


    AL = Base("pas.AL", "pas")


    IsB = Base("pas.IsB", "pas")


    IsS = Base("pas.IsS", "pas")


    IsValid = Base("pas.IsValid", "pas")
    """
    partial full + fully fill
    """


    Reset = Base("pas.Reset", "pas")

    Orig = Base("pas.Orig", "pas")
