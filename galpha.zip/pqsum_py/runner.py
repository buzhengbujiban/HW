import qr_utils
import gflow as gf
import os
import jobs.cfggen as cf
import subprocess
from datetime import datetime, timedelta
from jobs.rnodes.rnode import RNode


class PQSumNode(RNode):
    class_id = "pq"
    PQSUM_RELEASE_EXE = "/data/nasData/apps/autobld/equity/pqsum"
    PQSUM_RELEASE_EXE = "/data/beef2/bin/unstable/PQ/pqsum"
    PQSUM_DEBUG_EXE = qr_utils.realpath("~/git/golibs/src/TES/QR/alpbase_foobar/cmd/runAlpbase/runAlpbase")
    def __init__(self, node_config, exe=PQSUM_RELEASE_EXE, *args, **kwargs):
        super().__init__(node_config=node_config, *args, **kwargs)
        self.clockFreq = 300
        self.startTime = "09:35:00"
        self.stopTime = "15:00:00"
        self.univ = "hs300"
        self.sdate = None
        self.edate = None
        self.exclude_dates = []
        self.dates_reverse = False
        self.pq_filters = []
        self.pq_sums = []
        self.msg_info_cfgs = {}
        # self.terms = node_config
        self.build_orderbook = True
        self.use_persid_md = True
        self.cpuprofile = None
        self.memprofile = None
        self.locale = "loc_szgta"
        self.EXE = exe

        # threads config
        self.slurm_enable = False
        self.slurm_cfg = {
            # "slurm": 1000, 
            # "slurmQueue": 'squeue', "slurmJobName": "pq_sum",
            # "slurmForceProgress": 1, "retries": 1,
            # "slurmNfs": 'nas6:2', "smem": 20000,
        }
        self.parallel_spec = '1'
        self.persid_threads = 1

        # paths
        self.output_dir = qr_utils.realpath(f"{self.stage_dir()}/")
        output_dir_name = self.output_folder_name()
        self.galpha_json = output_dir_name + ".json"
        self.proj = f"{qr_utils.realpath(self.output_dir + '/..')}/{output_dir_name}"
        self.out = f"{self.proj}/YYYYMMDD.sdiv"
        self.eod_out =""
        self.script = f"{self.proj}/script"
        self.jf_sample = f"{self.proj}/jf_sample"
        
        # session/galpha
        self.sess = None
        self.galpha = None
        self.galpha_meta = None

    def get_sess(self):
        if self.sess is None:
            args = qr_utils.Map({
                "date": self.edate,
                "univ": self.univ,
                "exe": self.EXE,
                "stopTime": self.stopTime,
                "market": "CNEQ",
                "action": "run",
                "json_fn": self.galpha_json,
                "cpuprofile": None,
                "memprofile": None,
            })

            self.sess = gf.new_session(args)
        return self.sess


    def build_exe(self, trimpath: bool = False, debug: bool = True):
         # generate ops
        print(f"\n generating alpbase_foobar/terms/pqsum/msginfo/models/ops.go ...")
        os.system("~/git/golibs/src/TES/QR/alpbase_foobar/py/pqsum/ops_gen.py")
        print(f"generating done ...\n")
        
        self.get_sess().build("", trimpath=trimpath, debug = debug)
        
    def init_galpha(self):
        self.galpha = gf.GAlpha()
        with self.galpha as g:
            # tick supply
            if self.stopTime > "11:30:00":
                gf.tick_supply("pq_timer_supply", id=1, start_hms=self.startTime, end_hms="11:30:00", interval = self.clockFreq, snap_timeout_sec = 0.02)
                if self.clockFreq == 300:
                    gf.tick_supply("pq_timer_supply", id=1, start_hms="13:05:00", end_hms=self.stopTime, interval = self.clockFreq, snap_timeout_sec = 0.02)
                elif self.clockFreq == 60:
                    gf.tick_supply("pq_timer_supply", id=1, start_hms="13:01:00", end_hms=self.stopTime, interval = self.clockFreq, snap_timeout_sec = 0.02)
                else:
                    raise Exception("clockFreq must be 300 or 60")
            else:
                gf.tick_supply("pq_timer_supply", id=1, start_hms=self.startTime, end_hms=self.stopTime, interval = self.clockFreq, snap_timeout_sec = 0.02)

            # snap events
            gf.snap(gf.clock_tick_supply_event(tick_supply_id = 1, is_global_event = False))
            if self.eod_out != "":
                gf.snap(gf.eod_event())
                
            gf.default_alpha(gf.alpha("PQSum", name= "", configs = self.msg_info_cfgs))

            for i, term_cfg in enumerate(self.node_config):

                pq_filters = []
                for f in term_cfg["pq_filters"]:
                    filter_name = f["name"]
                    expr = f["expr"]
                    on = ",".join(list(expr.key))
                    if len(on) <= 0:
                        raise Exception(f"pq filter:{filter_name} does not use any msg stats")

                    pq_filter = {
                        "name": filter_name,
                        "on": on,
                        "expr": str(expr),
                    }
                    pq_filters.append(pq_filter)

                pq_terms = []
                for s in term_cfg["pq_stats"]:
                    expr = s["expr"]
                    on = ",".join(list(expr.key))
                    pq_sum = {
                        "name": s["name"],
                        "expr": str(s["expr"]),
                        "pows": s.get("pows", [1]),
                        "snap": s.get("snap", False),
                        "dump": s.get("dump", True),
                        "on": on
                    }
                    pq_terms.append(pq_sum)

                gf.term("PQSum", name=f"PQSum_{i}", alp=None,
                        filters=pq_filters,
                        pq_terms=pq_terms,
                        configs = term_cfg.get("configs", {})
                        )

        md_univ = self.univ
        if md_univ.startswith("sids:"):
            md_univ = md_univ.split("sids:")[1]
        
        if self.use_persid_md:
            supply = [
                {
                    "source":  ["YamlCfgStream"],
                    "extraParam": f"-cfg /data/nasData/supplycfg/cneq/cneq_all_evotar.yaml -cneq.dob.univ {md_univ} -cneq.trade.univ {md_univ} -cneq.order.univ {md_univ}"
                }
            ]
        else:
            supply = [
                {
                    "source":  ["YamlCfgStream"],
                    "extraParam": f"-cfg /data/nasData/supplycfg/cneq/cneq_all_evogta.yaml -cneq.dob.univ {md_univ} -cneq.trade.univ {md_univ} -cneq.order.univ {md_univ}"
                    # "extraParam": f"-cfg /data/nasData/supplycfg/cneq/cneq_all_evogta_jq3.yaml -cneq.dob.univ {md_univ} -cneq.trade.univ {md_univ} -cneq.order.univ {md_univ}"
                }
            ]
        
        sp_adapter = [
            {
                "name":"CneqTrdEndbatch",
                "param":"-limit.sec 0.1"
            }
        ]
        params = {
            "supply": supply,
            "spAdapter":sp_adapter,
            "BuildOrderBook": self.build_orderbook,
            "pivot": "NoQueue",
            "locale": self.locale,
            "out": "",
            "pubs": [{
                "out": self.out,
                "SdivPublish": {
                    "freq": f"{self.clockFreq}s",
                    "start": (datetime.strptime("09:30:00", "%H:%M:%S")+timedelta(seconds=self.clockFreq)).strftime("%H:%M:%S"),
                    "end": "15:00:00",
                    "usePrevILabel": True,
                    "ivalsReplace": "11:30:00->13:00:00"
                }}],
            "adapters":[
                {
                    "type": "pq_timer_adapter",
                }
            ],
            "json_fn": f"{self.script}/{self.galpha_json}", 
            "univSidColumn": "sid",
            "startTime": "09:15:00",
            "stopTime": self.stopTime,
            # "extension":[{"type":"httpprof","port":6060}],
        }
        if self.persid_threads > 1:
            params["pivot"] = "PerSidQueue"
            params["GOMAXPROCS"] = self.persid_threads
        else:
            params["GOMAXPROCS"] = 1

        if self.eod_out != "":
            params["pubs"].append({
                "out": self.eod_out,
                "SdivPublish": {
                    "freq": "daily",
                    "usePrevILabel": True,
                }
            })
        self.galpha_meta = params
        
        
    def run_internal(self, config_only: bool = False, single_date: int = None):
        if self.galpha is None:
            self.init_galpha()
            
        if self.slurm_enable:
            self.slurm_cfg['slurm'] = 1
        else:
            self.slurm_cfg['slurm'] = 0

        print("\nOUTPUT: ")
        for pub in self.galpha_meta.get("pubs", []):
            print(f"out: {pub['out']}")
        print()

        # installing
        if not os.path.exists(self.script):
            os.makedirs(self.script)
        self.get_sess().install(self.galpha, self.script, date='YYYYMMDD', **self.galpha_meta)
        subprocess.run(f"chmod 770 -R {self.script}", shell=True)
        
        # print(config_only)
        if single_date is not None:
            single_date_command = self.galpha.cmd_template
            for i in range(0, len(single_date_command)):
                if single_date_command[i] == "--date":
                    single_date_command[i + 1] = str(single_date)
            subprocess.run(single_date_command, check=True)
        elif not config_only:
            self.sampling()


    def sampling(self):
        flow = cf.CJobFlow(self.jf_sample)
        flow.add(
            cf.CGalpha(
                bin=os.path.join(self.script, os.path.basename(self.EXE)),
                univ=self.univ,
                market="cneq", stopTime=self.stopTime,
                json=os.path.join(self.script, self.galpha_json),
                out="", sdate=self.sdate, edate=self.edate,
                exclude_dates=self.exclude_dates, skipIfExist=False,
                dates_reverse=self.dates_reverse,
                spec=self.parallel_spec,
                cpuprofile= self.cpuprofile,
                memprofile= self.memprofile,
                **self.slurm_cfg,
            ),
        )
        sample_jf_json = f"{self.jf_sample}/jobflow.json"
        flow.write_cfg(sample_jf_json)
        subprocess.run(f"python ~/git/pqsum_py/pqsum_py/jobflow_main.py {sample_jf_json} --run run", shell=True, check=True)